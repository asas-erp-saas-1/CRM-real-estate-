# SYSTEM ARCHITECTURE

## Stack
Next.js 16.1.3 (App Router, Turbopack dev) · React 19 · TypeScript 5 (strict) · Tailwind CSS 4 + shadcn/ui (New York) · Prisma 6 + SQLite (`db/custom.db`) · zod 4 · zustand 5 (client state) · @tanstack/react-query 5 (server state) · framer-motion · sonner toasts · next-themes (dark mode).

## Topology (sandbox constraints — load-bearing)
- **Single `/` route** — the ONLY user-visible page. All CRM "views" are client-side via zustand hash routing (`#/dashboard`, `#/leads`, …). No other routes may be added.
- **Backend = API routes only** (`src/app/api/**`), NO server actions (project rule).
- **One external port** (3000) behind a Caddy gateway; cross-service calls must use `?XTransformPort={port}` query (never absolute URLs, incl. WebSocket `io("/?XTransformPort=…")`).
- **`bun run build` is FORBIDDEN** in this environment — validation = lint + tsc + curl + agent-browser + dev.log.
- Mini-services (independent bun projects on own ports) allowed under `mini-services/` when needed (none active).

## Layers
```
src/app/page.tsx → providers (react-query, theme, toaster)
  └─ crm-app.tsx — auth gate: BootSplash | LoginOverlay | shell
       └─ shell.tsx — sidebar-nav + header (search palette ⌘K, notifications bell, theme, lang ع/FR) + view router
            └─ views/* (9) + drawers/dialogs (lead-detail-drawer and friends)
src/lib/client/*  — api fetch client (ApiError + code map), zustand store (view/lang/drawer), types, whatsapp helper
src/lib/server/*  — session (HMAC cookies, requireUser RBAC), auth (scrypt, lockout, temp passwords), validation (zod parseBody/qp/qpEnum),
                    leads (findLead+DTO), audit (logAudit), csv, documents, matching, settings, expiry (reservation sweeper)
src/app/api/**    — 54 route files / 68 handlers (post P2-R2): uniform try/catch → ok()/fail(), ApiError codes, org-scoped queries
prisma/           — schema.prisma (25 models) + seed.ts (db managed via `bun run db:push`; migrations = roadmap)
```

## Request lifecycle (trace)
UI (react-query `useQuery`/`useMutation`) → `api.get/post/patch/del` (fetch, JSON, ApiError parsing) → API route → `requireUser(role?)` (HMAC cookie verify → user load incl. passwordChangedAt) → zod validation → Prisma query (`where: { id, orgId }` pattern) → side effects (Activity + AuditLog via helpers) → `ok(data)` → react-query cache invalidation → UI.

## Cross-cutting
- **Auth**: cookie `asas_user` = `${userId}.${issuedAtMs}.${hmacSHA256}` (secret in .env; ephemeral fallback warns). 30d, httpOnly, sameSite=lax. `ASAS_DEMO_MODE` (default on in this workspace) gates persona quick-login + demoUsers listing; production sets `0`.
- **Rate limiting** (in-memory, single-instance — accepted D-002): login 5 fails/15min per email (429 ACCOUNT_LOCKED, applies to quick-login too post P2-R1), copilot 20s/lead, VLM analyze 30s/user.
- **i18n**: `src/lib/i18n.ts` — fr/en/ar dicts (~3k lines; append-only marked blocks at dict ends — convention holding). RTL via `dir` attr + logical properties.
- **Errors**: routes throw `ApiError(status, message, code, details)` → `fail()`; unknown errors → generic 500 `INTERNAL` (details only in server console). 403 → view-level lock screens; 401 → login overlay. **App-level render failures** (Phase 1 Task 3): `src/app/error.tsx` (segment boundary — trilingual fr/en/ar + RTL, self-contained copy since the app i18n lives inside the crashed tree; reset + reload recovery; one-way `error.digest` reference surfaced, full error → console only) and `src/app/global-error.tsx` (root-layout failures — own `<html>/<body>`, inline styles immune to CSS-pipeline failure). Dev-validated: intentional page/layout throws render the boundaries; reset re-mounts without white screen; `[app-error-boundary]` console diagnostics confirmed; app boots normally after revert. Production digest display: follows the official Next.js error-file contract.
- **AI integrations** (server-only): LLM copilot (`z-ai-web-dev-sdk` chat), VLM document OCR (vision) — both currently degrade gracefully (error rows/dialogs) when the gateway is down.

## Verified properties (P2-a)
- Zero `@/lib/server`/`@/lib/db` imports in client code; z-ai SDK confined to 2 server routes.
- Org-scoping universal; 0 data routes without requireUser.
- react-query: consistent key prefixes (`leads`, `lead`, `dashboard`, `visits`, …) + invalidation graph; `placeholderData` used on paginated views.

## Known architectural debt (details → TECHNICAL_DEBT.md)
i18n monolith; 20 components >400 lines (dashboard-view 1162, leads-view 1083); 12 duplicated units (useDebounced ×3, ROLE_TONE ×4, startOfDay ×5, load-or-404 ×17→9 adopted); `next.config.ts` ignoreBuildErrors:true + reactStrictMode:false (roadmap). ~~no error boundary in app/~~ — added Phase 1 Task 3 (`error.tsx` + `global-error.tsx`).
