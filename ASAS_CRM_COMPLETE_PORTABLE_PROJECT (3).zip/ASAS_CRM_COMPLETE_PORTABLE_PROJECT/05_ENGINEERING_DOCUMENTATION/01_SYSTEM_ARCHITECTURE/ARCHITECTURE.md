# ARCHITECTURE — Handoff Overview

This document is the front-door architecture description of ASAS CRM for the
GitHub/Supabase/Vercel handoff: what the system is, how the one page and the
API surface fit together, what lives in the server and client libraries, how
authorization is enforced, and how the pieces deploy. It carries the verified
current-state census (59 API route files, 26 data models, 21 server modules —
all counted from the repository, not estimated). Deeper engineering detail,
including the sandbox-era constraints under which the system was built, lives
in `05_ENGINEERING_DOCUMENTATION/01_SYSTEM_ARCHITECTURE/SYSTEM_ARCHITECTURE.md`; this file describes the
deliverable as it ships.

## 1. System overview

```
                         ┌─────────────────────────────────────────────┐
                         │                  Browser                    │
                         │  Single route "/" — hash-routed SPA         │
                         │  (fr / en / ar + full Arabic RTL)           │
                         └───────────────────┬─────────────────────────┘
                                             │ fetch (JSON, same-origin)
                                             ▼
                         ┌─────────────────────────────────────────────┐
                         │        Next.js 16 (App Router) server        │
                         │  src/app/api/** — 59 route files,            │
                         │  77 handlers (29 GET · 29 POST · 10 PATCH ·  │
                         │  8 DELETE · 1 PUT) — the ONLY server surface │
                         │  (no server actions, binding project rule)   │
                         │                                             │
                         │  src/lib/server/** — 21 domain modules:      │
                         │  session/RBAC · D-021 visibility · lifecycle │
                         │  gates · audit · documents · AI guard · …    │
                         └───────────────────┬─────────────────────────┘
                                             │ Prisma 6 (org-scoped queries)
                                             ▼
                ┌────────────────────────────────────────────────────────┐
                │  Local dev:  SQLite (db/custom.db)                     │
                │               chain: prisma/migrations/ (13 migrations)│
                │  Production:  Supabase PostgreSQL                     │
                │               chain: supabase/migrations/ (canonical;  │
                │               0001 schema · 0002 CHECK constraints +  │
                │               partial unique index · 0003 RLS)         │
                └────────────────────────────────────────────────────────┘
                                             │
                   optional AI provider: `.z-ai-config` JSON file
                   (z-ai-web-dev-sdk — lead copilot + document analysis;
                   absent ⇒ both routes return 503, CRM fully functional)
```

The authoritative model definition is `prisma/schema.prisma` (SQLite);
`prisma/schema.postgres.prisma` is its PostgreSQL rendering for Supabase
deployments. See `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md` for the
single-source-of-truth law.

## 2. Application topology — one page, 59 API routes

- **Single visible route** (`src/app/page.tsx`): the whole CRM is a
  hash-routed SPA (`#/dashboard`, `#/leads`, …). All "views" are client
  components switched by a zustand store; URLs are deep-linkable via the hash
  fragment. This is a binding architecture decision — never add page routes.
- **API routes only** (`src/app/api/**`): no Next.js server actions. Every
  mutation goes through a route handler following the standard pattern
  `requireUser()` → zod `parseBody()` → org-scoped Prisma query → side
  effects (Activity + AuditLog) → `ok()/fail()`.
- **Route census (verified)**: 59 `route.ts` files exposing 77 handlers.
  56 files are auth-gated via `requireUser`; 3 are public by design (the auth
  routes — see `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md` for the coverage table and
  their mitigations).
- Error handling: app-level render failures are caught by
  `src/app/error.tsx` (trilingual segment boundary) and
  `src/app/global-error.tsx` (root layout failures); API errors flow through
  a uniform `ApiError` → `fail()` contract with stable error codes.

## 3. Server module inventory (`src/lib/server/` — 21 modules)

| Module | Responsibility |
|---|---|
| `session.ts` | HMAC-SHA256 cookie session (`asas_user`), `requireUser()` RBAC gate, same-origin (CSRF) enforcement, `ApiError`/`ok()`/`fail()` contract |
| `auth.ts` | scrypt password hashing/verification (N=16384/r=8/p=1), per-email login lockout, temp-password issuance |
| `visibility.ts` | **D-021**: the single record-visibility primitive — `leadScope/taskScope/visitScope/…` Prisma where-fragments composed by every data route |
| `validation.ts` | zod v4 body/query parsing (`parseBody`, `parseQp`) — uniform 422 `VALIDATION_ERROR` failures |
| `audit.ts` | `logAudit()` — AuditLog writes, transaction-aware (optional `$transaction` client) |
| `leads.ts` | Lead DTO helpers (flat tag array over the LeadTag join model) |
| `matching.ts` | weighted apartment↔requirement matching engine (weights from org settings) |
| `matches.ts` | matching route helpers — PropertyMatch include + JSON-string `reasons` ↔ array DTO |
| `duplicates.ts` | the ONE duplicate-pair predicate shared by scan API, dashboard KPI and notifications |
| `reservation-lifecycle.ts` | reservation status machine, interactive transactional double-booking guard (D-008) |
| `reservation-economics.ts` | deal-economics write orchestration (MANAGER+ money gate, audits, incentive activity) |
| `reservation-trust.ts` | pure economics decision laws (§37/§38 — recorded calculation basis, never invented rates) |
| `reservation-dto.ts` | the reservation serialization choke point — server-side financial-field minimization (FIN-MIN-Q10) |
| `visit-gate.ts` | successful-closure visit/report gate — the no-bypass enforcement for every CLOSED_WON path |
| `expiry.ts` | reservation expiry sweeper (lazy, idempotent ACTIVE → EXPIRED transitions) |
| `documents.ts` | document binary storage on the LOCAL FILESYSTEM (`db/docs/`) — see §7 caveat |
| `csv.ts` | RFC-4180-ish CSV import parser + export escaping (formula-injection defanging) |
| `settings.ts` | org settings service (key/value JSON over OrgSetting, defaults merged) |
| `ai-provider.ts` | Z.ai SDK availability guard — 503 `AI_PROVIDER_UNAVAILABLE` when unconfigured (see §6) |
| `zip.ts` | dependency-free ZIP writer for the export bundle (small-bundle scope guards) |
| `faults.ts` | deterministic fault-injection hook for transactional-integrity regression tests |

## 4. Client architecture

- **Server state** — `@tanstack/react-query` 5: consistent query-key prefixes
  (`leads`, `dashboard`, `visits`, …) with an invalidation graph;
  `placeholderData` on paginated views.
- **UI state** — zustand 5 (`src/lib/client/store.ts`): the view router
  (URL hash ↔ view), persisted language (`fr` default, `en`, `ar`), density
  preference. `src/lib/client/workspace-store.ts` keeps per-view workspace
  state (filters/search/sort) alive across view switches.
- **Typed fetch client** — `src/lib/client/api.ts`: relative URLs only,
  `ApiError` mirroring the server error contract.
- **Session hook** — `src/lib/client/session.ts` (react-query wrapper of
  `GET /api/auth/session`).
- **i18n** — `src/lib/i18n/domains/*` (18 domain modules), fr/en/ar with
  genuine Arabic; RTL via `<html dir>` sync + logical CSS properties. No
  hardcoded user-facing strings in components (binding rule).
- **UI surface** — `src/components/crm/**`: 9 views (dashboard, leads,
  pipeline, visits, tasks, properties, analytics, audit, settings) plus
  drawers, dialogs, tables and loading/error states on shadcn/ui primitives.

## 5. Authorization — the two-layer model

1. **Application layer (operative)** — every authed route runs
   `requireUser()` (HMAC session + role rank) and composes D-021 visibility
   fragments from `src/lib/server/visibility.ts` into its Prisma queries.
   Ghost and foreign-org records return byte-identical 404s. Full model:
   `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/AUTHORIZATION_MODEL.md`, summary +
   RLS interplay: `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md`.
2. **Database layer (defense-in-depth, PostgreSQL/Supabase deployments)** —
   Row Level Security enabled on all 26 tables with default-deny,
   org-scoped policies keyed on the request JWT `org_id` claim
   (`supabase/migrations/20261030000003_rls_policies.sql`). The application connects
   via the pooler/service connection, which bypasses RLS — Layer 1 is the
   operative enforcement boundary; Layer 2 protects against any future
   direct-to-database data path.

## 6. AI provider boundary

The two AI surfaces (lead copilot `POST /api/leads/[id]/copilot`, document
analysis `POST /api/documents/[id]/analyze`) call `z-ai-web-dev-sdk`, which
reads a `.z-ai-config` JSON file (`process.cwd()` → `~/.z-ai-config` →
`/etc/.z-ai-config`) — **no environment variables**. On independent
deployments without that file both routes answer
`503 AI_PROVIDER_UNAVAILABLE` and the rest of the CRM is fully functional.
AI surfaces resolve the underlying record through the same D-021 visibility
predicate first — the AI layer can never widen access. Deployment contract:
`05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md` § "AI provider".

## 7. Deployment architecture

- **Database: Supabase PostgreSQL** (canonical production target). Setup
  walkthrough: `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md`.
- **Application host: optional Vercel** — `next build` (Vercel handles the
  build; `output: "standalone"` in `next.config.ts` is for self-hosted
  `node .next/standalone/server.js`). Setup: `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md`.
- **⚠ Document storage gap (known limitation, NOT implemented)**: document
  binaries are written to the local filesystem under `db/docs/` by
  `src/lib/server/documents.ts` (`DOCS_DIR = <cwd>/db/docs`). Vercel's
  filesystem is ephemeral — uploaded files will NOT survive there. Production
  deployments need a Supabase Storage adoption (bucket + policies + a
  storage adapter in `documents.ts`) before relying on the documents module.
- **Sessions/rate limits are in-memory** (single-instance by accepted
  decision D-002): login lockout, copilot/analyze rate limits reset on
  restart; move to a shared store if the app is ever scaled horizontally.

## 8. Document map

| Topic | Document |
|---|---|
| Sandbox-era engineering detail, request lifecycle trace | `05_ENGINEERING_DOCUMENTATION/01_SYSTEM_ARCHITECTURE/SYSTEM_ARCHITECTURE.md` |
| Data model, migration chains, type decisions | `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md` · `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md` |
| Supabase setup | `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` |
| Real-data migration pipeline (blocked status) | `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATA_MIGRATION_GUIDE.md` |
| Authorization model, RLS, security posture | `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md` · `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/AUTHORIZATION_MODEL.md` · `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_HARDENING.md` |
| Environment variables, Vercel | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md` · `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md` |
| GitHub import, owner checklist, blocked export | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/GITHUB_IMPORT.md` · `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/HANDOFF_CHECKLIST.md` · `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/DATA_EXPORT_BLOCKED.md` |
| Test strategy | `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/TEST_STRATEGY.md` |

Note: `SYSTEM_ARCHITECTURE.md` is the living engineering record and predates
the handoff packaging (it still carries sandbox-era counts such as 54 route
files / 25 models and the Caddy-gateway constraints). Where the two files
disagree on a census number, this document's counts (59 route files /
77 handlers / 26 models / 21 server modules) are the verified current state.
