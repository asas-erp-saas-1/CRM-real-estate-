# ASAS CRM — Lead Identity & Deduplication (Phase 11 stance)
## Existing laws preserved verbatim (A2 discovery — zero reimplementation)
- Identity key: canonical E.164 phone, @@unique([orgId, phone]); phoneRaw preserved; fullNameAr folded alias; whatsapp canonical defaults to phone; secondaryPhone.
- Duplicate detection layers: exact normalized phone · exact email (case-insensitive) · existing linked identity · NAME exact-normalized (weak, warning-only).
- Merge workflow: MANAGER+ (leads.dedupe), fill-if-empty survivorship, re-points activities/tasks/visits/opportunities/documents/tags/contact+requirement, stale-guards both sides, 409 MERGE_BOTH_CONVERTED; LeadDuplicateDismissal for false positives; nothing silently deleted.
- Public capture dedup: duplicate → NOTE activity on the EXISTING lead + audit flagged duplicate (renewed interest, no second record).
## Phase 11 additions
None required — the existing engine already exceeds the §A2-C requirements. The inbox surfaces the duplicates KPI; the merge dialog remains the resolution surface. Phone normalization for Algerian formats (+213, 00, bare-213 double-prefix bug handled) was verified present and tested.
