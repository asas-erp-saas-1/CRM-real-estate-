# ASAS CRM — Phase 11 Native Deployment Forensic Report
Date: 2026-11-10 · Investigator: Principal (read-only sweep) + Agent A3 · HEAD at investigation: c90ddac (clean tree)

## Complaint
Owner reports the native Z.ai Publish/Deploy fails ("Sorry, there was a problem deploying the code.").

## Evidence chain
1. Two failed publish attempts this session: /tmp/build_fullstack_1794314799 (12:46:39) and /tmp/build_fullstack_1794314846 (12:47:26) — BOTH EMPTY (no tar.gz). The platform's build.sh died in `bun run build`, before artifact collection.
2. Build trace (attempt 2): `next-build` span 12:47:27.49 → 12:48:03.22 (35.7s), ends immediately after `run-turbopack` — no page-data/typecheck/static-gen spans; process self-exited (not OOM/SIGKILL; dmesg clean).
3. dev.log carried `Module not found: Can't resolve 'tailwindcss-animate'` on every compile — sourced from tailwind.config.ts:2.
4. tailwind.config.ts (64 lines, re-added by HEAD c90ddac) imports `tailwindcss-animate` — a package NOT in package.json (purged at a3a2c27; absent from node_modules). Dev tolerates unresolved imports as warnings; PRODUCTION `next build` treats them as fatal → build exits → empty BUILD_DIR → platform reports failure.
5. Secondary latent blocker: `next build` typechecks the whole project — 25 TS errors existed in never-built code (ghost shadcn v3 components referencing never-installed packages; journey-stats/journey-worklist drift after a lib/journey refactor; unreachable customers-view/journey-stage-chip).

## Environment forensics (R13 pattern, documented recurrence #10)
- The container restore (12:45:17) wiped untracked state: the live November dev DB and db/backups/ were lost; git-tracked db/custom.db (an Oct-2 snapshot, 44 leads/22 visits/7 users, pre-p20 schema) was restored. The last `bun run db:push` (12:46:18) failed: required Visit.proposedAt without default on 22 rows → dev.sh aborted → dev server DOWN at investigation start.
- .env restored complete (DATABASE_URL + ASAS_SESSION_SECRET + ASAS_DEMO_MODE=1 — the sandbox law).
- Phase 7.1 fix intact: .env.production tracked, contains ONLY ASAS_DEMO_MODE=0.

## Verdict
Project-side defect CONFIRMED as the current publish blocker (fatal unresolved import + typecheck-failing dead files). Platform-side facts (owner-action required): the Publish button itself, and the R13 restore behavior, remain outside agent reach.
