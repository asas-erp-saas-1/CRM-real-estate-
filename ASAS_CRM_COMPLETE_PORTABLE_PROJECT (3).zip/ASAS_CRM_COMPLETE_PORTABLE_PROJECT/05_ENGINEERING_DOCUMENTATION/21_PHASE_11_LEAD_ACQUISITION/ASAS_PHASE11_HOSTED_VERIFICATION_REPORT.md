# ASAS CRM — Phase 11 Hosted Verification Report
Status: PENDING OWNER ACTION — the native Publish button is platform-side and cannot be invoked by agents.

## Pre-publish project-side posture (verified)
- .env.production tracked with ONLY ASAS_DEMO_MODE=0 (no secrets — D-012 law).
- Production boot gate ACTIVE (src/instrumentation.ts → src/lib/server/boot.ts): SESSION_SECRET missing/placeholder/weak and DEMO_MODE_PRODUCTION each exit(1) — NOT weakened by any Phase 11 change.
- build.sh/start.sh contract untouched; hosted DB path law (DATABASE_URL=file:/app/db/custom.db) untouched; live-hold partial unique indexes shipped via live-hold-indexes.sql (idempotent).
- Migration chain extended additively (20261110150000_p11_lead_acquisition) — hosted `prisma migrate deploy` picks it up.

## Post-publish checklist (to run after the owner presses Publish)
1. Health: /api/health → status ok, demoMode FALSE, demoModeMisconfigured false.
2. DB identity: hosted /app/db/custom.db (schema-only + first-run bootstrap law — login 401s until the owner runs the in-app first-run bootstrap; this is by design, not a broken deploy).
3. Authenticated access with the owner account; role restrictions for SALES_AGENT/FIELD_REP.
4. Core lead operations available (inbox, campaigns, routing console, acquisition analytics).
Verdict: cannot be issued until the owner publishes. No unverified success is claimed.
