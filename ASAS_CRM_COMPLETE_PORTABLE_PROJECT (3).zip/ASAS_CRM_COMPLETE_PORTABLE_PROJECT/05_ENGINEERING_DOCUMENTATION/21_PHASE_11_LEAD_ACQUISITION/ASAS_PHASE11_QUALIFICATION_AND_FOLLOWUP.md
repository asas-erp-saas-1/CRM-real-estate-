# ASAS CRM — Qualification & Follow-up (Phase 11)
## Qualification facts (Lead, additive + nullable — explicit unknown, never fabricated)
- preferredContact: PHONE | WHATSAPP | EMAIL (intake preference).
- decisionReadiness: READY_NOW | READY_3M | READY_6M | EXPLORING.
- mainObjections: free text ≤500.
- Matching inputs live in the 1:1 Requirement (budget range, propertyType, surface, district, floor, bedrooms, payment, purpose, timeframe + Phase 10 enrichment with hard/soft filter distinction) — already wired to the deterministic matching engine.
- The drawer's Qualification card PATCHes the three facts; the PATCH transaction already refreshes the score through the single writer (W2-A2 law — the 8-signal engine reads hasRequirement etc.).
## Follow-up
Existing architecture reused: nextFollowUpAt + Task.leadId + drawer Tasks tab + overdue chips. No duplicate task system created. Follow-up overdue state is an inbox facet (overdue_followups queue) and a workload metric.
## Conversion (preservation contract closed)
Single tx: Contact (fullName, fullNameAr, secondaryPhone, whatsapp, phone, email, notes) + Opportunity (stage QUALIFIED, value=budgetMax, birth next action, sourceOrigin=lead.source, campaignId=lead.campaignId stamped once) + lead flip + CONVERSION Activity + LEAD_CONVERTED audit; race-safe 409 via unique indexes; repeated conversion requests answer ALREADY_CONVERTED.
