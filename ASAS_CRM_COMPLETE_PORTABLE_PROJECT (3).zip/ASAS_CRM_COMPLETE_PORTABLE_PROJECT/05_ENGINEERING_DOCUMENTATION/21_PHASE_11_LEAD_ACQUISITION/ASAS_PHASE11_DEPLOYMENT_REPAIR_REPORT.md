# ASAS CRM — Phase 11 Deployment Repair Report
Commit: bcf650a "fix(p0): native publish repair" (22 files, +33/−3297)

## Root cause fix
1. DELETED tailwind.config.ts — vestigial Tailwind v3 shadcn config; Tailwind 4 is CSS-first (globals.css `@import "tw-animate-css"`; postcss uses @tailwindcss/postcss); ZERO references anywhere (verified: no @config directive, no imports). Its only live effect was the fatal unresolved `tailwindcss-animate` import.
2. DELETED 19 dead files that fatal production typecheck: ghost shadcn components (accordion, aspect-ratio, carousel, collapsible, context-menu, drawer, hover-card, input-otp, menubar, navigation-menu, radio-group, resizable, toast, toaster, tooltip, sidebar, use-toast) + unreachable customers-view.tsx + journey-stage-chip.tsx — each verified ZERO real importers first.
3. RESTORED journey engine exports: lib/journey.ts gained `JourneyStatEntry` (the computeJourneyStats input row) + `isJourneyStalled` (verbatim velocity-panel law: age≥0 && age > JOURNEY_STAGE_SLA_DAYS[stage]) — journey-stats.ts and journey-worklist.ts (both live code: /api/journey/stats + /api/journey/export) had drifted after a refactor.

## Verification
- tsc --noEmit: 0 errors (was 25). eslint: 0 errors (40 pre-existing warnings).
- Dev server restarted (reaper-proof double-fork, PID→1): /api/health 200 {dbOk:true, demoMode:true (sandbox), sessionSecretConfigured:true}.
- 0 module-not-found warnings in the post-restart dev.log tail.
- Browser E2E: login → dashboard → Prospects (real data) — pass.

## Database reconciliation (same session, pre-repair — data-safe, no reset)
- Verified backup created: db/backups/backup-pre-p11-20261110-140532/custom.db (6,086,656 bytes).
- p20-pattern Visit rebuild executed (exact prisma/migrations/20261009080000 recipe): 22/22 rows preserved, proposedAt backfilled from scheduledAt, FK check clean.
- `prisma db push --accept-data-loss` (the only flagged change — unique [projectId,name] on Building — verified ZERO duplicate values first, so nothing could be dropped) + live-hold-indexes.sql executed.
- Result: 39/39 tables, 7 users/44 leads/22 visits/46 apartments intact, PRAGMA integrity_check ok.

## Owner action required
Press the native Z.ai Publish control once. Project-side preflight now passes (no fatal imports, typecheck clean). If it still fails, the platform-side execute_command log is the next evidence source (only Z.ai can retrieve it).
