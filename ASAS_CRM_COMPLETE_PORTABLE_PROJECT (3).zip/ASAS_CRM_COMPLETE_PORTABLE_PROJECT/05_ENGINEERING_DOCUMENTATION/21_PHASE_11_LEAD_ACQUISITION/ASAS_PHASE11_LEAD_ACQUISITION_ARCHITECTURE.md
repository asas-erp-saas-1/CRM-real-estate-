# ASAS CRM — Phase 11 Lead Acquisition Architecture
## Discovery-first law
Six-agent read-only discovery preceded any code: A1 (Phase 10 exit gate — 17/17 verified), A2 (lead domain map — existing phone normalization, scoring, dedup, capture, conversion, i18n inventoried; 9 duplication-risk laws cataloged), A3 (deployment forensics — root cause isolated). Architecture approved by the Principal on that evidence.

## What already existed (and was REUSED, not rebuilt)
Phone E.164 normalization (lib/phone.ts) · 8-signal explainable scoring (scoring.ts, single-writer law) · layered duplicate detection EMAIL/PHONE_CROSS/NAME + dismiss/merge with cascade re-pointing (duplicates.ts) · token-gated public capture with honeypot + rate limits (lead-capture.ts) · LeadTouch multi-touch attribution · conversion single-tx with race-safe 409 · i18n ×3 with parity guard · reassignLeadCascade assignment law · Activity/AuditLog trail law.

## What Phase 11 added
1. Campaign entity (A1): code-keyed attribution, soft lifecycle, budget; Lead.campaignId + full UTM quartet.
2. Lead Inbox (A3): queue facets over the EXISTING status vocabulary (no new statuses), contact-SLA chips, role-scoped (org vs own+pool).
3. Deterministic routing engine (A3): MANUAL / ROUND_ROBIN (persistent cursor) / WORKLOAD (min active assigned, stable tie-break); eligibility = active SALES_AGENT with MANAGER fallback, never ADMIN/OWNER, never disabled accounts; every assignment writes the full cascade+Activity+Audit trail.
4. Qualification flow (A4): preferredContact / decisionReadiness / mainObjections on Lead; structured wizard in the drawer; Requirement model already carried the matching inputs (budget/type/surface/district/rooms/purpose/timeframe).
5. Conversion preservation (A4): Contact inherits fullNameAr + secondaryPhone + whatsapp; Opportunity inherits sourceOrigin + campaignId (stamped once).
6. Acquisition analytics (A5): bySource / byCampaign / contactDelays / repFunnel / lostReasons with precise windowed metric definitions.
7. Capture token surface completed with the campaigns/settings console; capture payload accepts campaignCode + UTM quartet + preferredContact.

## Integration boundaries (honest)
Meta Lead Ads / WhatsApp Business API: NO credentials exist — integration-ready design only (capture token API + campaign code resolution). No fake integrations, no invented webhooks.
