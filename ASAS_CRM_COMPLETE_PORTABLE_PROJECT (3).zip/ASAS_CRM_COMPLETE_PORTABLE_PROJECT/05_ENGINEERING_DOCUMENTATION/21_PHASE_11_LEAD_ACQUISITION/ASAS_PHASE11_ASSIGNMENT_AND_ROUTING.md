# ASAS CRM — Assignment & Routing (Phase 11)
## The engine (src/lib/server/routing.ts)
- Policies: MANUAL (default — zero behavior change) · ROUND_ROBIN (OrgSetting cursor "leads.routing.cursor", stable order createdAt→id, wrap-around) · WORKLOAD (fewest active assigned leads; ties → stable order).
- Config: OrgSetting "leads.routing" {policy, autoAssign} — GET/PUT /api/leads/routing (leads.routing permission, MANAGER+, audited ROUTING_POLICY_UPDATED).
- Explainability: GET returns the DRY-RUN next decision with a human reason ("Tourniquet — tour de Amine Cherif (position 2/3)" / "Charge minimale — Lina porte 4 prospect(s) actif(s)"); the inbox console shows it BEFORE any lead is routed.
- Eligibility: active SALES_AGENT users; MANAGER fallback when no agents exist; ADMIN/OWNER never auto-assigned; disabled accounts excluded (verified query filters).
## Trail law (every assignment — auto AND manual)
reassignLeadCascade (open opps, OPEN tasks, future active visits follow the new owner) + per-lead ASSIGNMENT Activity {before, after, method, reason, cascade counts} + LEAD_ASSIGNED audit row — one transaction.
## Surfaces
- Inbox bulk/single assign dialog → POST /api/leads/routing/assign {leadIds, ownerId, reason} (leads.assign, MANAGER+, org-forgery guard, inactive-owner 422).
- Workload metrics: GET /api/leads/workload + the routing console table (activeAssigned / uncontacted / overdueContact / overdueFollowUps / converted per rep).
- Auto-assign hooks: public capture + house create (only when no ownerId chosen and autoAssign on) — inside the creation tx.
## SLA
LEAD_CONTACT_SLA_HOURS = 24: a NEW lead uncontacted beyond 24h reads overdue in inbox chips + workload (derived at read time — no cron).
