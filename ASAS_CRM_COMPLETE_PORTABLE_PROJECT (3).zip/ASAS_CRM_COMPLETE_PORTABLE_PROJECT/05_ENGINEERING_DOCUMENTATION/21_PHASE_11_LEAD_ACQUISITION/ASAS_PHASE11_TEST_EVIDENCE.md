# ASAS CRM — Phase 11 Test Evidence
## Static gates
- TypeScript (tsc --noEmit): 0 errors (was 25 at session start — all eliminated).
- ESLint: 0 errors (40 pre-existing warnings, none new).
- i18n parity guard: green across fr/en/ar (module-load law).
- Permissions module-load guards (template closure + tier monotonicity): green.
## Unit suite
`bun run test:unit` → 36 files, 605/605 tests PASS (includes view-registry test extended to 14 views with the inbox.view floor assertion).
## API smoke (authenticated session, real data)
- GET /api/campaigns → 200 {data:[]}
- GET /api/leads/inbox?queue=new → 200 {counts:{new:13, unassigned:1, awaiting_contact:12, overdue_contact:13,…}}
- GET /api/leads/routing → 200 {config:{policy:"MANUAL",autoAssign:false}, next:{…}, assignees:[Amine Cherif…]}
- GET /api/leads/workload → 200 per-rep workload
- GET /api/analytics/acquisition?days=365 → 200 bySource populated (FACEBOOK_ADS 7 leads, 42.9%…)
## Browser E2E (agent-browser, evidence screenshots v01–v13)
OWNER: login → inbox (chips + rows + routing console) → unassigned queue → assign dialog → assignment applied (owner visible, count decremented) → routing policy set ROUND_ROBIN + autoAssign (dry-run line updates) → reverted to MANUAL → campaign created in settings → analytics Acquisition tab (bySource/contactDelays/repFunnel/lostReasons) → create-lead with campaign picker + preferred contact → lead lands unassigned under MANUAL policy → drawer Qualification card saved + persisted → Arabic RTL (dir=rtl, no overflow) → mobile 390px (cards, no horizontal overflow). SALES_AGENT: inbox personal slice, no routing console, no campaigns-manage section.
## Database
40 tables; PRAGMA integrity_check ok; FK check clean; pre-existing row counts preserved.
