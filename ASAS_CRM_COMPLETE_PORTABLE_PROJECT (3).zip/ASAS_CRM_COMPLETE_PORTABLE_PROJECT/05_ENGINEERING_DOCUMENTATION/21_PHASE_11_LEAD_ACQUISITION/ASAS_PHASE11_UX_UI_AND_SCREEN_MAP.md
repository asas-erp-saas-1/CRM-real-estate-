# ASAS CRM — Phase 11 UX/UI & Screen Map
## New/extended surfaces
1. INBOX VIEW (view id "inbox", nav "Réception" / "الاستقبال" / "Intake"): 9 queue chips (new · unassigned · awaiting_contact · overdue_contact · overdue_followups · qualified · converted · lost · reactivated) with real counts; zebra table (desktop) / cards (390px); tel: + WhatsApp quick links; campaign code chip; unassigned marker; score meter; relative times; selection + bulk bar; MANAGER+ routing console card (policy select + autoAssign switch + dry-run next-assignee line + workload table).
2. ASSIGN DIALOG: rep roster with live workload line + reason → POST assign → toast + query invalidation (inbox/leads/lead/dashboard/notifications/routing).
3. CAMPAIGNS SECTION (Settings, campaigns.manage): table (name, copy-code chip, channel, inline status PATCH, leads, budget, dates) + create dialog (slug-validated code, SOURCES channel select, dates, DZD budget, notes; 409 surfaces the server message).
4. ACQUISITION TAB (Analytique): window selector; bySource table; byCampaign table; contactDelays bucket chart; repFunnel table (shared workload-table component); lostReasons list; totals.
5. CREATE-LEAD DIALOG: campaign picker (label "name (code)", ACTIVE+PAUSED default + show-ended toggle) + "Préférence de contact" segmented control.
6. LEAD DRAWER: Qualification card (readiness / preferred contact / objections → PATCH → persistence verified).
## i18n
New "intake" domain: 118 keys × 3 dictionaries (354 entries), real professional Arabic; parity guard green (fr=en=ar total). RTL verified live (html dir=rtl, mirrored nav/chips).
## Evidence
05_ENGINEERING_DOCUMENTATION/21_PHASE_11_LEAD_ACQUISITION/evidence/p11-v01…v13 (13 screenshots: login, inbox, unassigned, assign dialog, assigned, routing console, campaigns, acquisition, create, qualification, AR RTL, mobile 390, SALES_AGENT scope).
