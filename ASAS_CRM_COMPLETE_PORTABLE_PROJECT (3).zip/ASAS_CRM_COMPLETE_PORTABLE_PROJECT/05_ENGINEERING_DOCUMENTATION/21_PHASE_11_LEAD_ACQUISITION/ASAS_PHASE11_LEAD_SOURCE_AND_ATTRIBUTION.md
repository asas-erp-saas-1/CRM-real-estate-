# ASAS CRM — Lead Source & Attribution (Phase 11)
## Source taxonomy (unchanged, verified complete)
SOURCES = FACEBOOK_ADS, INSTAGRAM, WHATSAPP, WEBSITE, OUEDKNISS, GOOGLE, TIKTOK, REFERRAL, WALK_IN, PHONE, EXISTING_CUSTOMER, DEVELOPER_REFERRAL, PUBLIC_CAPTURE, OTHER.
## Attribution model
- ORIGINAL attribution is immutable by construction: Lead.source/campaignId/utm* appear on NO PATCH schema.
- Latest interactions ride LeadTouch (multi-touch, inbound/outbound) — never overwrite origin.
- Campaign: closed code key unique per org (@@unique([orgId,code])); resolution is EXACT match. House create path: unknown code → 422 CAMPAIGN_CODE_UNKNOWN. Public capture: unknown code preserved as null attribution (never invented, no 409 on the public surface).
- Conversion stamps Opportunity.sourceOrigin + campaignId once — revenue analytics never joins back.
## Campaign lifecycle
ACTIVE | PAUSED | ENDED (soft — deletion would orphan attribution; ENDED keeps reporting). Code + channel immutable after creation. budgetPlanned optional DZD (null = unknown, never fabricated).
