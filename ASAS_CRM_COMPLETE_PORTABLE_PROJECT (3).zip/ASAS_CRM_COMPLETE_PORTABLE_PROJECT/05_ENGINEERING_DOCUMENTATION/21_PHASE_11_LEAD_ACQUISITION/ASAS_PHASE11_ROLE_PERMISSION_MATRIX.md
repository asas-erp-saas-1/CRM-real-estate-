# ASAS CRM — Phase 11 Role Permission Matrix (catalog additions)
New permissions (enforced by live route gates; tier monotonicity + template closure guards run at module load):
| Permission | OWNER | ADMIN | MANAGER | SALES_AGENT | FIELD_REP | Enforced by |
|---|---|---|---|---|---|---|
| campaigns.view | ✓ | ✓ | ✓ | ✓ | — | GET /api/campaigns |
| campaigns.manage | ✓ | ✓ | ✓ | — | — | POST /api/campaigns, PATCH /api/campaigns/:id |
| leads.routing | ✓ | ✓ | ✓ | — | — | GET/PUT /api/leads/routing, GET /api/leads/workload |
| inbox.view | ✓ | ✓ | ✓ | ✓ | — | GET /api/leads/inbox |
Data-level scoping (unchanged D-021 law): the inbox is leadScope-scoped — SALES_AGENT reads OWN + POOL; MANAGER+ reads the org; FIELD_REP has no inbox at all (nav hidden + API 403). The routing console renders only for leads.routing holders. The settings Campagnes section is gated on campaigns.manage. Acquisition analytics is analytics.view (MANAGER+), same floor as the existing analytics view.
