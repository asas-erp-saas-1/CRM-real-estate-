# ASAS CRM — Phase 10 Exit Gate (Phase 11 entry audit)
Auditor: Agent A1, READ-ONLY code audit at HEAD c90ddac. Method: actual code inspection (models + API guards + UI wiring), NOT documentation claims.

## Result: 17/17 exit-gate claims VERIFIED in code
a) OWNER adds developer+project — properties.manage ∈ OWNER_ALL; POST developers/projects guarded.
b) Authorized users add properties/units — MANAGER+ floor (apartments/buildings routes + property-authoring.ts one-tx event-anchored).
c) Conditional fields on creation — LAND type-conditional law (add-property-dialog + server constants validation).
d) Edit permitted property info — apartments/[id] PATCH with transition guards + in-tx events.
e) Approvals/publishing enforced — RECORD_TRANSITIONS law + recordStatus default DRAFT on interactive authoring, APPROVED for import/legacy.
f) Project/construction/commercial states separate — 4 axes: Project.status / Apartment.status / deliveryStatus / recordStatus.
g) Availability+freshness — availabilityVerifiedAt + UnitAvailabilityEvent stream + freshness classification policy.
h) Pricing semantics + history — UnitPriceEvent stream + priceUpdatedAt, events recorded on create/PATCH.
i) Matching explainable — PropertyMatch score/reasons; scoreMatch reasons; unit tests.
j) Unavailable units excluded — OPEN_APARTMENT_STATUSES=["AVAILABLE"] + recordStatus APPROVED filter in matching.
k) Proposals versioned — Offer.version/supersededById revise chain.
l) Price snapshots — frozen base/parking/options/discount/finalTotal at create + revise; UI never sends basePrice.
m) Discount approval by role — SELF/MANAGER/OWNER lanes, mandatory motive, route lane checks.
n) Holds+reservations conflict-protected — 4 partial unique indexes CONFIRMED LIVE in db/custom.db + in-tx guards + P2002 mapping.
o) ADMIN explicit — ADMIN_TEMPLATE = full catalog, rank 90, ROLE_CEILING enforced.
p) SALES restricted to approved inventory — recordStatus=APPROVED hard filter below MANAGER.
q) FIELD_REP restricted — assignedProjects/visitScope/leadScope projections; no inventory/reservation-create permissions.

## Decision
Phase 10 exit gate: PASSED. Phase 11 feature development authorized. Minor backlog items (GET /developers list endpoint, project identity PATCH, apartment identity editability) recorded in the defects file — all MINOR.
