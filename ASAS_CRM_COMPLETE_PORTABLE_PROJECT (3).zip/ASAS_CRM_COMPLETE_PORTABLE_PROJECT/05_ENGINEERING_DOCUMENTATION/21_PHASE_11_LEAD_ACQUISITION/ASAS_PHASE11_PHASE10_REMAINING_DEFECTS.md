# ASAS CRM — Phase 10 Remaining Defects Register (as found at Phase 11 entry)
| # | Item | Severity | Evidence | Status |
|---|------|----------|----------|--------|
| 1 | No GET /api/properties/developers list route (UI derives from projects include) | Minor | developers/route.ts POST only; add-property-dialog.tsx:30-35 | OPEN (backlog) |
| 2 | No PATCH on project identity (create-only) | Minor | projects/[id]/route.ts GET only | OPEN (backlog) |
| 3 | Apartment identity (code/buildingId/unitType) not editable post-create | Minor by design | apartments/[id]/route.ts:36-58 | OPEN (by design) |
| 4 | Test suite had environment-bound execution issues (server-only stub resolution under bun test) | Environment, not code | tests run green under vitest (605/605 unit) | RESOLVED this session — 605/605 unit tests pass |
| 5 | Stale DB state after R13 platform restore (pre-p20 schema restored from git) | Critical (data continuity) | db/custom.db Oct-2 snapshot; db:push failed on Visit.proposedAt | RESOLVED this session — data-safe rebuild, all rows preserved |

No blocking inventory/price/reservation inconsistency remains.
