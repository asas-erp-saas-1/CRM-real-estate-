# ASAS CRM — Phase 11 Security & Data Integrity
## Authorization
Every new route gated: requirePermission("campaigns.view"/"campaigns.manage"/"leads.routing"/"inbox.view"/"leads.assign"/"analytics.view"). The assign endpoint re-verifies every leadId belongs to the caller's org (mass cross-tenant assignment impossible) and the target owner is ACTIVE + in-org (forged/disabled IDs → 422/404). Attribution fields immutable (never on any PATCH schema). Campaign code immutable post-creation.
## Public intake hardening (unchanged laws, extended surface)
Token gate (sha256-hashed, generic 401 no-oracle) · honeypot · in-memory rate limits (10/min token, 30/min IP, 60s per-phone) · strict body whitelist (campaignCode/utm*/preferredContact length-fenced) · unknown campaign code → null attribution (no enumeration) · duplicate → NOTE on existing lead · auto-assign runs inside the creation tx.
## Data integrity
Migration 20261110150000_p11_lead_acquisition is 100% additive + nullable (zero row rebuilds; verified on the live DB: 40 tables, FK check clean, integrity_check ok, all pre-existing rows intact — 7 users/44 leads/22 visits/46 apartments). Backup taken before any DB work (db/backups/backup-pre-p11-20261110-140532/). No reset, no reseed, no destructive operation at any point.
## Boot gate
Untouched and ACTIVE (production + demoMode → exit(1); secret strength check). .env.production still tracked with ONLY ASAS_DEMO_MODE=0.
