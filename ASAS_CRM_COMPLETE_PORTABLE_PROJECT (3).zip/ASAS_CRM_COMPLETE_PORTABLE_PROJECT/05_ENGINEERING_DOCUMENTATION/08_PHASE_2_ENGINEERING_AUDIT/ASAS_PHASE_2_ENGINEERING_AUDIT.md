# PHASE 2 — ENGINEERING AUDIT (Executive Summary)

Phase: P2 (audit + repair). Date: 2026-10-02. Method: 4 parallel forensic audits (architecture / security / database+domain / UX) → evidence-driven repairs (P2-R1 security, P2-R2 database) → validation loop. Full evidence: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/*`.

## What exists (V1, rounds R1–R10)
Production-shaped CRM for Algerian real-estate sales: 9 client-routed views (dashboard w/ range filter + targets ring, leads w/ AI copilot + bulk copilot + WhatsApp click-to-chat + CSV import/undo, pipeline kanban, visits list+calendar, tasks, properties w/ documents + VLM OCR, analytics, audit trail, settings w/ team + targets), 55 API route files / 69 handlers, auth (scrypt + lockout + login overlay), RBAC (5 roles), tenant org-scoping on every query, i18n fr/en/ar + RTL, dark mode. 25 Prisma models, seeded demo dataset incl. won-deal history (7 CLOSED_WON, 236.2M DZD).

## What works (verified this phase)
- **Boundaries clean**: zero server imports in client code; z-ai-web-dev-sdk confined to 2 server routes. 0 data routes lack `requireUser` (auth endpoints by design).
- **Tenant isolation**: universal orgId scoping — 13 [id]-route IDOR probes → all 404, never 500.
- **RBAC**: MANAGER 403s, self-guards (SELF_ROLE_CHANGE/DEACTIVATION, LAST_OWNER) all live-verified.
- **Crypto**: scrypt N=16384/r=8/p=1, timingSafeEqual, per-user salt; passwordHash never serialized.
- **Data integrity**: 0 duplicate phones/emails, 0 orphans, R10-2 won-deal coherence 7/7.
- **UX**: 10 live workflow checks — 6 PASS, mobile 390 + RTL Arabic + zero console errors throughout.
- lint exit 0 / tsc 0 src errors / GET / 200 at every checkpoint.

## What was broken (found + FIXED this phase)
1. **P0 — unauthenticated full account takeover** (chain: `/api/auth/session` leaked all userIds to unauth callers × passwordless `{userId}` quick-login × unsigned raw-id cookie). Live-reproduced forging an OWNER session with zero credentials. → **FIXED (P2-R1)**: HMAC-signed cookies (`userId.issuedAt.hmac`, timingSafeEqual) + `ASAS_DEMO_MODE` gate + lockout-aware quick-login. Forged raw cookie now → 401 (independently re-verified by main session).
2. **ADMIN→OWNER escalation** (ADMIN could create/promote OWNER-rank users). → **FIXED**: ROLE_CEILING 403s on POST/PATCH/reset-password.
3. **Reservation expiry = fake completeness** (PARTIAL): nothing ever transitioned ACTIVE→EXPIRED; past-due holds blocked apartments forever + unique index deadlocked re-booking. → **FIXED (P2-R2)**: lazy sweeper `expireDueReservations()` (tx + audit RESERVATION_EXPIRED + apartment release) wired into notifications/reservations GET; unique index replaced by in-tx guards (re-test: re-book after expiry 201; concurrent 409s).
4. **AuditLog entity drift** ("User" 51 rows vs "USER"): → backfilled + call-sites normalized; audit filter coherent.
5. Session not invalidated on password change → `passwordChangedAt` check (old cookie 401 after change, live-verified).
6. Misc: generic 500 messages (no internal leak), document PATCH RBAC, analyze rate limit (429), CSPRNG temp passwords, task priority enum guard, dead scaffold route removed, N-21 null-expiry repaired.

## Highest remaining risks (open → RISK_REGISTER.md)
- **R1 Secrets in git**: `.env` + `db/custom.db` (scrypt hashes) are tracked; needs history purge + rotation (deferred — requires coordinated git rewrite; documented steps).
- **R2 No migrations**: `db:push --accept-data-loss` workflow (silent data-loss risk; R10-4 stale-client 500s = live evidence). Baseline migration adoption = roadmap P1.
- **R3 No automated tests**: validation is manual (lint/tsc/curl/browser). Test harness = roadmap P1.
- **R4 Seed/regression drift**: won-deal seeding lives only in `tmp-scripts/`; fresh install regresses to 0 won deals.
- **R5 Data quality (business decisions)**: 7 seed-legacy RESERVED/OPTIONED apartments with no reservation row; possible duplicate lead (Mohamed Larbaoui ×2, different phones).
- **R6 Single-instance assumptions**: in-memory limiters/rate-limits reset on restart (accepted trade-off at current scale — see DECISION_LOG D-002).

## Scorecard (evidence-based status)
| Dimension | Status | Evidence |
|---|---|---|
| Architecture | **Verified** (+ debt) | 55 routes mapped; boundaries clean; ADR trail |
| Code quality | **Needs work** | 20 files >400 lines; 12 duplicated units; i18n monolith 3k lines |
| Database | **Verified** (+ risk) | integrity 0 anomalies; migration posture = Risk R2 |
| Security | **Needs work → repaired** | P0 chain fixed + verified; P3 hardening remains (timing oracle, CSV formula injection…) |
| Authentication | **Verified** (post P2-R1) | signed cookies, lockout, scrypt |
| Authorization | **Verified** (+ ceiling fix) | RBAC + org-scoping live-tested |
| CRM domain | **Needs work** | state machines partially enforced; missing concepts (Campaign, Offer, Commission…) |
| API | **Verified** | uniform ok/fail/ApiError (54/55), zod on every mutation |
| Frontend | **Verified** | clean boundaries, react-query discipline |
| UX/UI | **Needs work** (P3 polish) | 6/10 PASS; bugs B1–B8 (no delete for tasks/visits, focus restore…) |
| Testing | **Incomplete** | no test framework; manual protocol only |
| Performance | **Verified** (at scale) | R6 10k benchmark; index coverage good; 5 composites roadmap |
| Observability | **Incomplete** | console logging + audit trail only; no metrics/tracing |
| DevOps | **Incomplete** | no CI/CD, no backups, auto-commit UUID history, secrets in git |
| Documentation | **Verified** (this phase) | worklog 1000+ lines, audits, this tree, AGENTS.md |
| Maintainability | **Needs work** | no commit discipline (48 uncommitted paths pre-phase), no migrations |

## Phase 2 changes (exact)
- Security (P2-R1, 13 files backend-only): session.ts (HMAC sign/verify + passwordChangedAt), login/session/logout/change-password/users×3/documents×2 routes, auth.ts (generateTempPassword CSPRNG), schema.prisma (User.passwordChangedAt), .env (ASAS_SESSION_SECRET, ASAS_DEMO_MODE=1). New lib: expiry-ready helpers.
- Database (P2-R2): NEW src/lib/server/expiry.ts; notifications + reservations routes (sweeper wiring); tasks/[id] (priority guard); schema.prisma (Reservation @@unique([apartmentId]) removed + @@index([status,expiresAt]) added); entity backfill 51 rows; dead scaffold deleted.
- Residue hygiene: all audit/repair test data reverted (DB back to handover baselines).

## Validation performed
- curl matrix: forged cookies (raw + wrong-sig) → 401 ×4 shapes; legit signed → 200; quick-login lockout → 429; ADMIN ceiling → 403 ×3; password-change invalidation → old cookie 401; analyze double-fire → 429; doc RBAC → 403; re-booking after expiry → 201; concurrent → 409 ×2; priority garbage → 422; /api scaffold → 404.
- lint exit 0; tsc 0 src errors (also 0 tmp-scripts after hygiene); dev.log clean; agent-browser E2E green post-repairs (dashboard/visits/audit, zero console errors).
