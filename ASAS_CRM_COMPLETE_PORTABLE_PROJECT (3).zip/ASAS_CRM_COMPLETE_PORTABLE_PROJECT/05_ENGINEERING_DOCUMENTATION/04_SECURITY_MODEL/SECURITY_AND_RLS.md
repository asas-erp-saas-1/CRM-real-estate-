# SECURITY AND RLS — THE TWO-LAYER AUTHORIZATION MODEL

This document is the handoff security reference: how ASAS CRM enforces
authentication, CSRF protection and record-level privacy, and how the
application-layer model relates to the Row Level Security layer shipped in
the PostgreSQL chain. It summarizes and links the deeper engineering records
(`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/AUTHORIZATION_MODEL.md` for the full D-021 model,
`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_HARDENING.md` for the fix history F-01..F-15,
`05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/SECURITY_AUDIT.md` for the forensic evidence). Read it before
touching anything security-related.

## 1. The two-layer model

| Layer | Where | Status | Role |
|---|---|---|---|
| **1 — Application** | Every API route: `requireUser()` (HMAC session + role rank) + D-021 visibility fragments (`src/lib/server/visibility.ts`) composed into every Prisma query | **Operative — the enforcement boundary** | Enforces identity, role and record-level privacy for the application. Verified by live HTTP batteries (cross-org 404s byte-identical to ghost ids; the phase-c-probe battery and the P12 40/40 visibility matrix). |
| **2 — Database (RLS)** | `supabase/migrations/20261030000003_rls_policies.sql` — RLS enabled on all 26 tables, org-scoped default-deny policies | **Defense-in-depth (PostgreSQL/Supabase deployments)** | Protects against any future direct-to-database data path (a Supabase-Auth adoption, an edge function, a stray service-role query) and prevents accidental public exposure of tenant data. |

The application connects via the **pooler/service connection, which
bypasses RLS** (table-owner semantics; `0003` deliberately never uses
`FORCE ROW LEVEL SECURITY` — forcing it would break the owner/service
connections the app relies on). Layer 1 is therefore the boundary the
application actually runs on; Layer 2 is the backstop underneath it.

## 2. Route authentication coverage

Census: 59 route files — **56 auth-gated** via `requireUser()`, **3 public
by design** (all in `src/app/api/auth/`):

| Route | Why public | Mitigations |
|---|---|---|
| `POST /api/auth/login` | must accept credentials from the unauthenticated login overlay | scrypt verification with dummy-hash timing equalization (no email-enumeration oracle), per-email lockout (5 failures / 15 min → 429 `ACCOUNT_LOCKED`), same-origin check in `readJson()`, identical 401 bodies for wrong-email vs wrong-password |
| `GET /api/auth/session` | the login overlay needs to know whether a session exists | read-only; unauthenticated response carries only `demoUsers` (id/name/role) **and only in demo mode** — with `ASAS_DEMO_MODE=0` it returns an empty list, never disclosing user ids |
| `POST /api/auth/logout` | idempotent session teardown on stale cookies | clears the cookie only; no data access; deliberately not `requireUser`-gated |

Everything else — including all data reads/writes, search, dashboard,
analytics, AI routes — requires a valid session, and role ceilings
(e.g. ADMIN can never create/modify/reset an OWNER — 403 `ROLE_CEILING`)
are server-side only.

## 3. Session design

- Cookie `asas_user` = `${userId}.${issuedAtMs}.${hmacSHA256}` — HMAC-SHA256
  over the payload with `ASAS_SESSION_SECRET`, compared with
  `timingSafeEqual` (`src/lib/server/session.ts`). Forged/raw cookies fail
  401 (live-verified, fix F-01/F-02).
- httpOnly, `sameSite=lax`, path `/`, 30-day maxAge. The `secure` flag and a
  shorter lifetime are deployment-time items for HTTPS production hosts.
- **Stateless invalidation**: `User.passwordChangedAt` — any cookie issued
  before the stamp is rejected (password change/reset kills every existing
  session; live-verified, fix F-05).
- Credential storage: Node scrypt (N=16384, r=8, p=1, 32-byte key,
  per-user random salt), constant-time compare; hashes are never serialized
  in any API response.
- Dev fallback: when `ASAS_SESSION_SECRET` is unset, an ephemeral
  per-process secret is generated with a console warning — sessions reset on
  every restart. Production MUST set a strong persistent secret.

## 4. CSRF — same-origin enforcement

`assertSameOrigin()` runs inside `requireUser()` (every authed route, any
method — covers body-less DELETEs) and inside `readJson()` (pre-auth
mutations: login). Semantics (D-018/019/020): an absent `Origin` is allowed
(non-browser clients); a parseable Origin is allowed iff
`Sec-Fetch-Site: same-origin|none` (browser-vouched Fetch Metadata) OR the
host matches `X-Forwarded-Host` entries / the direct `Host` (gateway chains
that rewrite Host). Verified with a 6-case curl matrix plus a real-browser
cross-origin attack test (server 403).

## 5. D-021 record-level privacy — composition law summary

Record scopes resolved server-side per request: `ORG` (MANAGER+), `OWN+POOL`
(SALES_AGENT — own + unassigned pool + shared catalogue), PROJECT-SCOPED
(FIELD_REP via ProjectAssignment). One primitive,
`src/lib/server/visibility.ts`, feeds every data route. Ghost records and
foreign-org records return **byte-identical 404s** (no existence leak).

**Composition law (learned from a real caught leak)**: when a route's
`where` needs BOTH the scope fragment AND its own `OR`/match terms, they
must be composed as separate `AND` array elements —
`{ orgId, AND: [scope(user) ?? {}, { OR: […] }] }`. NEVER spread a scope
fragment into an object literal that also declares an `OR` key: JS
last-key-wins silently deletes the scope. Full model, enforcement-point
inventory and the 40-case test matrix:
`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/AUTHORIZATION_MODEL.md`.

## 6. RLS policy reference (`20261030000003_rls_policies.sql`)

- **Claims convention**: every policy compares the row's org key against
  `current_setting('request.jwt.claims', true)::json ->> 'org_id'` — the
  Supabase request-JWT claim. Supabase sets it natively for Auth-issued
  JWTs; a custom trusted gateway can `SET LOCAL request.jwt.claims =
  '{"org_id":"…"}'::jsonb` inside a transaction.
- **Default-deny**: with no claims set, `current_setting(...)` returns NULL
  and every policy evaluates to NULL → denied for `anon`/`authenticated`
  roles. No policy omits the org predicate.
- **Pattern per table**: four policies (SELECT/INSERT/UPDATE/DELETE);
  `USING` (row visibility) + `WITH CHECK` (write guard) on the org key.
  Join tables without `orgId` (`LeadTag`, `VisitApartment`, `Building`,
  `PipelineStage`, `PropertyMatch`) scope through their parent's org via an
  `EXISTS` subquery; `Organization` scopes on its own id.
- **What bypasses and why**: the application's pooler/service connection
  (table-owner semantics, no FORCE RLS). This is why the two-layer model
  keeps Layer 1 operative — RLS here is not the app's runtime boundary.
- **Never**: add a policy without the org predicate; use
  `FORCE ROW LEVEL SECURITY`; grant the anon key write access.

## 7. Demo mode — production warning

`ASAS_DEMO_MODE` unset or `1` enables the persona quick-login grid and a
passwordless `{userId}` login surface for the seeded demo roster. **Production
deployments MUST set `ASAS_DEMO_MODE=0`** (all demo surfaces then return 403
`DEMO_MODE_DISABLED` and hide). Leaving demo mode on with a seeded roster is a
documented account-takeover vector: anyone who knows a seeded userId can log
in without a password. Quick-login still respects the credentials lockout,
but that is a throttle, not a boundary. Environment reference:
`05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md`.

## 8. Secrets inventory + rotation

| Secret | Where it lives | Rotation |
|---|---|---|
| `ASAS_SESSION_SECRET` (HMAC-SHA256 cookie key) | `.env` (git-ignored), generated `openssl rand -hex 32` | Change the value — all sessions invalidate immediately |
| Supabase database password / service-role key | Supabase dashboard only | Rotate in the dashboard; update `DATABASE_URL` and redeploy |
| User passwords | scrypt hashes in the `User` table | Per-user reset (ADMIN surface) or password change (self-service) — both invalidate sessions via `passwordChangedAt` |
| `.z-ai-config` (AI provider credentials) | Server filesystem only — never in the repo, never in `NEXT_PUBLIC_*` | Rotate with the provider; see §9 |

The real `.env` is never committed; `.env.example` carries placeholders only
(`.gitignore` enforces `.env*` with `!.env.example`).

## 9. AI provider boundary

The two AI routes (`/api/leads/[id]/copilot`, `/api/documents/[id]/analyze`)
call `z-ai-web-dev-sdk`, configured by a `.z-ai-config` JSON file on the
server (cwd → `~/.z-ai-config` → `/etc/.z-ai-config`) — **no environment
variables**. Without it both routes return `503 AI_PROVIDER_UNAVAILABLE`
(`src/lib/server/ai-provider.ts`) and the rest of the CRM is fully
functional. Authorization is unaffected: AI routes resolve the underlying
record through the same D-021 predicate first — the AI layer can never widen
access. Deployment contract: `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md`
§ "AI provider".

## 10. Git history caveat

The handoff package is a **clean source ZIP without `.git`** — the source
tree itself contains no secrets. The ORIGINAL development history, however,
still contains historical secret objects (a committed session-secret value
and an old demo database with scrypt hashes —
`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md`). Consequences:

- Do NOT publish or push the original history anywhere — the owner-gated
  purge documented there must run FIRST if history preservation is wanted.
- The handoff import path (`05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/GITHUB_IMPORT.md`) starts a fresh
  history from the clean snapshot, which sidesteps the problem entirely.
- The leaked session-secret value is confirmed no longer in use (fresh
  production secrets are generated per `.env.example`), but any value that
  was ever committed must never be reused.

## 11. Future: Supabase Auth adoption (owner decision, NOT undertaken)

Adopting Supabase Auth for the application's own users would activate
Layer 2 for the app path — but the app's `User.id` values are cuid TEXT
strings, not Supabase auth UUIDs, so it requires an id-mapping decision
(auth.users ↔ public."User") plus issuing JWTs carrying the `org_id` claim.
It is documented as a future owner decision in `20261030000003_rls_policies.sql`'s
header and was deliberately not undertaken by the handoff. Until then the
HMAC cookie session (§3) remains the authentication mechanism.

## 12. Production checklist (condensed)

`ASAS_DEMO_MODE=0` · strong fresh `ASAS_SESSION_SECRET` · rotate the seeded
demo password (`asas1234`) before real users arrive · HTTPS (secure cookies)
· `bun run db:snapshot`-style scheduled backups · multi-instance? → move
rate limits + sessions to a shared store · read
`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_HARDENING.md` § "Production checklist" for the full
deployment-time list.
