# AUTHORIZATION MODEL

**Status: BINDING (Phase 12, D-021).** This document defines the authorization architecture of ASAS:
identity → session → role rank → **record-level data visibility** → API enforcement → testing.
Supersedes the informal "granular permissions = open product decision" boundary by explicit
user mandate (Premium CRM UX/UI + Role-Based Product Transformation, §3–§7, §15, §36, §40).

Companion docs: `ROLE_DATA_VISIBILITY_MATRIX.md` (the per-resource matrix),
`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_HARDENING.md` (fix history F-01..F-15), `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/SECURITY_AUDIT.md`.

---

## 1. Identity & session (existing, verified — unchanged)

| Layer | Mechanism | Evidence |
|---|---|---|
| Credential storage | Node scrypt (N=16384, r=8, p=1, 32B key), constant-time compare | `lib/server/auth.ts` |
| Login hardening | Per-email sliding-window lockout (5 fails / 15 min) + dummy-scrypt timing oracle (F-12) | `lib/server/auth.ts` |
| Session cookie | `asas_user` = `userId.issuedAt.HMAC-SHA256` (F-02); invalidation on `passwordChangedAt` (F-05) | `lib/server/session.ts` |
| Request forgery | `assertSameOrigin()` inside `requireUser()` + `readJson()` (D-018/019/020: Host ∨ X-Forwarded-Host ∨ Sec-Fetch-Site same-origin/none) | `lib/server/session.ts` |
| Demo mode | `ASAS_DEMO_MODE` gates quick-login + persona grid (D-007; sandbox ON, production OFF) | `lib/server/session.ts` |

## 2. Role model (existing — the product's actual roles, not invented)

Single agency (developer-side sales), no team hierarchy — **the MANAGER's "team" is the whole
org's sales floor**. Roles are a total order (`ROLE_RANK`, `lib/constants.ts`):

| Role | Rank | Authority class (P18 / D-025 — `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/AGENCY_OPERATING_MODEL.md`) |
|---|---|---|
| OWNER | 100 | Président · CEO — everything; adds delegates, assigns them projects; may conduct field visits personally (rank path) |
| ADMIN | 90 | System administration — users, roles, config, audit, global data |
| MANAGER | 70 | Directeur exécutif — **org-wide operational data** (team = the agency); sets deal economics; confirms visits by rank |
| SALES_AGENT | 40 | Représentant commercial (the follow-up rep) — own + unassigned records + shared inventory; **schedules visits but never confirms them**; sees own incentives |
| FIELD_REP | 40 | Représentant terrain — **project-scoped visibility** (§3.1b): assigned projects' visits/leads/opps/activities; own tasks only; **confirms visits on-site** |

MARKETING / ACCOUNTING / OPERATIONS were REMOVED (P18 — outside the agency's operational life; finance → future ERP).

Role-rank gates stay the coarse mechanism for *management surfaces* (audit, settings, import,
export, analytics, user administration, WIP limits). Record-level visibility (§3) is the
fine-grained mechanism for *operational data*.

## 3. Record-level data visibility (NEW — Phase 12 / D-021)

### 3.1 The model

Two record scopes, resolved **server-side, per request, from the session**:

```
ORG   — MANAGER and above. Every record in the organization.
OWN+POOL — below MANAGER. Records the user owns (ownerId/agentId = user.id)
        PLUS unassigned records (owner IS NULL) — the shared intake pool
        PLUS shared operational data (inventory: projects, buildings, apartments,
        unit types — the agency's catalogue; team roster: user names + roles).
```

```
PROJECT-SCOPED — FIELD_REP (P18 / D-025). Every surface resolves through
        ProjectAssignment: visits on assigned projects, the leads/opps/contacts/
        activities those visits belong to, own tasks. NO intake pool (the pool is
        a SALES concern — a field rep's clients arrive via scheduled visits).
        "No information appears for any other representative." (mandate)
```

`OWN+POOL` (not OWN-only) is a deliberate product decision, on three grounds:
1. **Precedent** — the notifications route already shipped exactly this predicate
   (`isManager ? {} : { OR: [{ ownerId: user.id }, { ownerId: null }] }`) as the carefully
   engineered reference implementation.
2. **Business model** — single-agency intake: unassigned leads are the pool every agent
   works; hiding the pool would strand every imported/walk-in lead.
3. **Mandate §5** — "An agent should normally see: own leads … properties available to the
   sales team, relevant shared information." The pool is the shared information floor.

### 3.2 What an agent can NOT see (enforced, not hidden)

Other agents' owned leads, opportunities, tasks, visits, notes/activities, client documents,
reservations; management-only aggregates (analytics, org funnel/source performance, targets).
Bypassing the frontend (curl, direct API, search autocomplete, counts, AI endpoints) yields
**404/403 indistinguishable from nonexistence** — no existence leak (mandate §15).

### 3.3 The primitive — `src/lib/server/visibility.ts`

ONE module, imported by every data route. It maps `(SessionUser, resource)` → Prisma
`where` fragments. Routes compose it into their existing `conditions[]` arrays:

```ts
seesAllRecords(user)            // boolean — MANAGER+
leadScope(user)                 // undefined | { OR: [{ ownerId: id }, { ownerId: null }] }
taskScope(user) / oppScope(user)  // same shape (ownerId)
visitScope(user)                // agentId variant
activityScope(user)             // actorId ∨ visible lead ∨ visible opp ∨ visible task ∨ visible visit
documentScope(user)             // uploader ∨ inventory docs (APARTMENT/PROJECT) ∨ visible-entity docs
reservationScope(user)          // agentId ∨ visible opportunity
canConfirmVisit(user, visit)     // P18/D-025 — the assigned FIELD_REP of the visit's
                                 // project, or MANAGER+ (confirmation is presence);
                                 // P20/D-026 — REJECT + counter-proposal share this
                                 // basis. P20-B/D-027 — status CHANGES additionally
                                 // pass the VISIT_TRANSITIONS matrix (422 otherwise);
                                 // the CONFIRMED→SCHEDULED reset is MANAGER+-only.
```

Detail/mutation routes use the scoped `findFirst({ where: { id, orgId, …scope } })` —
foreign records resolve **404 NOT_FOUND**, exactly like nonexistent ids.

### 3.4 Enforcement points (audit-verified inventory — 55 route files)

| Surface | Enforcement |
|---|---|
| List reads (leads/tasks/visits/opps/activities/documents/reservations) | scope fragment in base conditions |
| Detail reads + mutations (`[id]` routes + all lead subroutes: activities, tasks, tags, requirements, whatsapp, copilot, convert, reactivate) | scoped findFirst → 404 |
| POST referencing a foreign entity (task/visit/opp with leadId) | reference visibility validated → 404 LEAD_NOT_FOUND |
| `/api/search` (palette + global search) | scope fragments per entity — no autocomplete/counts leak |
| `/api/dashboard` | role-aware computation (agent = own+pool scope; management cards null) — §5 below |
| `/api/analytics` | `requireUser("MANAGER")` — management-only metrics |
| `/api/leads/bulk` | scope fragment inside the `updateMany` where |
| `/api/leads/check-duplicates` + POST `force` path | visible duplicates → details; foreign duplicate → generic 409 (no name/owner leak) |
| `/api/matching/leads/[id]`* | lead visibility → 404 |
| `/api/pipeline` stages | per-stage opp counts scoped for agents |
| `/api/leads/import`, `/api/export/*`, `/api/audit`, `/api/settings`, `/api/targets` (write), `/api/pipeline/stages/[id]` | unchanged — already MANAGER+/ADMIN rank gates |
| P18 `/api/visits` PATCH CONFIRMED | `canConfirmVisit` guard — assigned FIELD_REP of the visit's project or MANAGER+; 403 `VISIT_CONFIRM_FORBIDDEN` otherwise (stamps confirmedAt/confirmedById; optional final date rides the same PATCH) |
| P20 `/api/visits/[id]` decision vocabulary (D-026) + consolidated transition matrix (D-027) | **matrix guard fires first**: any status change not in `VISIT_TRANSITIONS` → 422 `VISIT_ILLEGAL_TRANSITION` (COMPLETED/CANCELLED/REJECTED terminal; NO_SHOW's only exit is RESCHEDULED; RESCHEDULED keeps the pending vocabulary; same-status PATCHes keep their own guards). REJECT/counter share the `canConfirmVisit` basis (403 `VISIT_REJECT_FORBIDDEN`/`VISIT_PROPOSE_FORBIDDEN`; reason required 422). Customer-reconfirm = the visit's agent or MANAGER+ (403 `VISIT_RECONFIRM_FORBIDDEN`; 422 `NO_COUNTER_PENDING`). **Executive reset CONFIRMED→SCHEDULED = MANAGER+ only** (403 `VISIT_RESET_FORBIDDEN` — the field rep who confirmed cannot un-confirm), **unwinds the presence stamps** and is **audit-logged** (`VISIT_RESET_TO_SCHEDULED`). Optional `expectedUpdatedAt` → 409 `VISIT_STALE` |
| P18 `/api/properties/projects/:id/assignments` | POST/DELETE `requireUser("MANAGER")` — assignee MUST be FIELD_REP (422 `ASSIGNEE_NOT_FIELD_REP`) and, since P20-C (D-028/§17.2), **ACTIVE** (422 `ASSIGNEE_INACTIVE` — an inactive user never receives new assignments); audited PROJECT_ASSIGNED/UNASSIGNED with the affected-future-work facts (`pendingVisitsCovered` / `pendingVisitsAffected` + `remainingFieldReps`) |
| P20-C `/api/dashboard` `unstaffedVisits` KPI + visits-GET `projectHasFieldRep` decoration (D-028/§17.3) | the no-eligible-rep exception is a **management surface**: the KPI computes to null below MANAGER (the funnel/sourcePerformance null convention — the attention cell hides on null, no client-side role check) and the row chip is informational below MANAGER, actionable (deep-link to the Équipe terrain assign flow) for MANAGER+; eligibility = assignment to an ACTIVE FIELD_REP (`user: { active: true, role: "FIELD_REP" }`) — the same predicate in the KPI, the row decoration and the assignment-change audits |
| P18 `/api/reservations/:id` economics branch | commissionAmount/commissionFrom/agentIncentive writes are MANAGER+ (403 `COMMISSION_FORBIDDEN`); pairing law 422 `COMMISSION_PAIRING`; audited COMMISSION_SET |

Deliberate non-restrictions (documented decisions, not oversights):
- **Team roster** (`GET /api/users` list: names + roles): shared operational context for a
  single agency; account operations (create/reset/deactivate) remain ADMIN-gated.
- **Inventory** (projects/buildings/apartments/unit-types): shared by design — the sales
  floor sells the same catalogue.
- **Agent reassigning their own record** (`PATCH ownerId`): allowed (self-service handover
  in a small agency); foreign records are unreachable regardless.

### 3.5 RLS readiness

SQLite has no row-level security. The primitive centralizes the predicate so a future
PostgreSQL migration can move it to RLS policies (session `app.current_user_id` +
`app.is_manager`) — one module to port, 55 routes untouched. Not done now (over-engineering ban).

## 4. AI authorization (mandate §34/§35)

Every AI surface resolves the underlying record **through the same visibility predicate
first**: copilot (`/api/leads/[id]/copilot`) and document analysis
(`/api/documents/[id]/analyze`) are detail routes — scoped findFirst → 404 for foreign
records. The AI layer can therefore never widen access, only summarize what the caller
already sees. AI responses inherit the same org + role context as the requesting session.

## 5. Role-aware dashboard (mandate §8)

`/api/dashboard` computes against the caller's scope and echoes it:

| Caller | KPIs & agenda | funnel / sourcePerformance / targets |
|---|---|---|
| MANAGER+ | org-wide (unchanged) | present |
| below MANAGER | own+pool (newLeads, uncontacted, overdueTasks, todayTasks/Visits, upcomingVisits, hotOpportunities, pipelineValue, wonInRange, conversionRate, recentLeads, todayTasks, todayVisits, hotOpportunities) | **null** → UI hides the management cards |

The UI captions reflect the scope ("Mes prospects récents" vs "Nouveaux prospects") — the
agent dashboard reads as *My Day*, the manager dashboard as *team overview*.

## 6. Testing (mandate §40 — the authorization test matrix)

The 34-case guard matrix (`tmp-scripts/p4-guard-matrix.ts`) gains a visibility suite
(`tmp-scripts/p12-visibility-matrix.ts`), run against the seeded demo org:

1. Agent A GET /api/leads → no row owned by agent B; total count excludes B's rows.
2. Agent A GET /api/leads/[B-lead-id] → 404 (byte-identical to a random id).
3. Agent A PATCH/DELETE B's lead/opportunity/task/visit → 404.
4. Agent A GET /api/activities → no activity whose only link is B's lead.
5. Agent A /api/search?q=B's lead name → zero hits; count fields agree.
6. Agent A /api/dashboard → `scope:"own"`, KPIs exclude B's records, targets/funnel null.
7. Agent A /api/analytics → 403.
8. Agent A check-duplicates with B's phone → generic 409, empty duplicates list.
9. Agent A matching + copilot on B's lead id → 404.
10. Manager (sarah) → org-wide totals; ADMIN (karim) → org-wide + admin surfaces.
11. Agent sees unassigned pool rows in every list (OWN+POOL regression guard).

Each case is an HTTP-level probe (cookie session, same-origin headers) — UI hiding is never
accepted as evidence. Residue: zero (read-only probes + exact-state restores where mutation
probes run).

**Executed 2026-10-08: 40/40 PASS** — including D1b byte-equality (foreign 404 body
byte-identical to a ghost id), M3b (a POST referencing a foreign lead persists nothing),
and zero residue. The first run caught a REAL leak in the stranded draft: `api/search`
composed scope via object spread next to the route's own `OR` key — JS last-key-wins
silently DROPPED the scope (amine searching "Bilal" received lina's lead + opportunity).
This produced the composition law below (§7, rule 3).

## 7. Change protocol

- New data route ⇒ import the primitive, apply scope to base conditions + scoped detail
  lookups. A route without it fails code review (this doc is the review checklist).
- New role ⇒ re-derive `ROLE_RANK` + the matrix doc in the same session.
- Schema change adding an ownership-bearing model ⇒ add its scope builder to the primitive.
- **Composition law (learned the hard way)**: when a route's `where` needs BOTH the scope
  fragment AND its own `OR`/match terms, they MUST be composed as separate `AND` array
  elements (`{ orgId, AND: [scope(user) ?? {}, { OR: [...] }] }`) or as separate elements
  of a `conditions[]` array. NEVER spread a scope fragment into an object literal that
  also declares an `OR` key — the explicit key overwrites the scope's `OR` and the scope
  silently vanishes. The §40 matrix (search case) is the regression guard for this class.

---

## ADDENDUM — 2026-10-26 (UX-OWNER-PLAN-2): the owner-approved authorization rules (planning-level)

The owner's 2026-10-26 answers (canonical record: `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md` §1a)
fixed these authorization rules. **They are approved for planning; implementation is gated on the
owner's review of the revised plan (`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/NEXT_PHASE_PLAN.md` v2).** Nothing below weakens
D-021, org isolation, or any standing rule.

1. **Strict visit/report gate — NO override (GATE-Q2):** the Opportunity boundary-crossing transition
   (pre-visit {NEW, QUALIFIED, VISIT_SCHEDULED} → beyond-visit {VISIT_COMPLETED, NEGOTIATION, OPTION,
   RESERVATION, CONTRACT}; formalization NP§2.1) must not proceed until a COMPLETED visit linked to the
   SAME opportunity carries a satisfied report. **No role may bypass it — including manager
   correction-class PATCHes; no `waiveVisitGate` mechanism may exist.** A D6 economics waiver
   (`waiveEconomics`) clears ONLY the economics-completeness rejection — the two controls are separate
   enforcement points by design.
2. **Visit-report authority (REPORT-Q5):** the assigned FIELD_REP (live ProjectAssignment derivation —
   the existing `canConfirmVisit` pattern) submits the report; absent a field rep, the representative
   responsible for the customer (the visit's `agentId` ?? the lead's `ownerId`); MANAGER+ may review
   and correct (audited, history-preserving); ordinary valid transitions need no per-report manager
   approval.
3. **Pool self-assignment carve-out (POOL-Q6b):** below MANAGER, `ownerId` changes on leads become
   permitted ONLY as null→self (a genuinely available pool record, verified in the caller's scope);
   every other agent-initiated ownership change stays 403; the existing in-tx LEAD_ASSIGNED audit +
   ASSIGNMENT activity fire unchanged. A representative must NEVER obtain a colleague-assigned lead.
4. **Direct representative transitions (TRANSITIONS-Q6c):** representatives perform otherwise-permitted
   Opportunity transitions directly when server validations pass — no mandatory manager-request queue.
   This grants NO scope expansion beyond existing D-021 rules.
5. **Field-level response minimization (FIN-MIN-Q10) — the new companion law to D-021:** server
   responses must not serialize unauthorized FINANCIAL fields to roles below MANAGER+ (the §37/§38
   family on reservations — the full matrix + the verified current deviation live in
   `ROLE_DATA_VISIBILITY_MATRIX.md`'s 2026-10-26 addendum). Record-level scoping (D-021) and
   field-level minimization are TWO layers; both are server-authoritative. UI hiding is never
   sufficient.
6. **Workspace visibility (WORKSPACE-Q6a):** a representative sees their own workspace (existing
   visibility rules only); MANAGER+ may inspect representative workspaces within organization scope;
   peer-record restrictions remain intact.

**Also recorded this round (verified at HEAD `494b87a`):** `fullName` IS PATCH-able today with a
silent trail (a Wave-2B spec reconciliation item — NP§1.2-7); opportunity reassignment is trail-silent
(an AUDIT-Q11-adjacent gap — NP§7.2); `logAudit`'s optional transaction parameter is post-commit on
the whole reservation lifecycle/economics module (the F-06 same-tx discipline gap on the money path).
All three are documented as planning items in `NEXT_PHASE_PLAN.md` — no code was changed.
