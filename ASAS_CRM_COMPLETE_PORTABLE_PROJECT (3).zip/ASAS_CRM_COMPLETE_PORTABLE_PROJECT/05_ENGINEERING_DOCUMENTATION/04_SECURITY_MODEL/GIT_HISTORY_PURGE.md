# GIT HISTORY PURGE — DEFERRED PLAN (requires explicit authorization)

Status: **DOCUMENTED, NOT EXECUTED** (Phase 1 Task 1 output). Per the Phase 1 mandate, history
rewriting is never performed automatically. This file is the complete, ready-to-execute plan.
Executing it requires an explicit instruction from the repository owner.

## Why it would be required

Secret-bearing objects are embedded in git history of the local `main` branch:

| Object | Content | Commits affected | Risk if history is ever published/cloned |
|---|---|---|---|
| `.env` | `ASAS_SESSION_SECRET=<48-hex>` (session-cookie HMAC key) + `ASAS_DEMO_MODE=1` | **1** — commit `66b7c13` only (verified: `git grep -l 'ASAS_SESSION_SECRET=[0-9a-f]{20,}' $(git rev-list --all)` → exactly one match) | Session-cookie forgery for any deployment still using that secret value |
| `db/custom.db` | All user rows: emails, userIds, roles, **scrypt password hashes** (7 users, shared public demo password) | **10** — every commit except `adf78e6` (Initial) | Offline credential cracking + PII disclosure |
| `db/docs-test.pdf` | Test document fixture (no secrets) | several | none (hygiene only) |

Current exposure containment (already DONE in Phase 1, see `worklog.md` Task P3-1):
- All of the above are **untracked from the index** (removed from future commits; files preserved on disk).
- `.gitignore` covers `.env*` (except the tracked `.env.example` template), `/db/`, `/tool-results/`, `.zscripts/*.pid`.
- The leaked `ASAS_SESSION_SECRET` value is **no longer in use anywhere**: the running dev server already
  restarted onto the ephemeral fallback secret (dev.log shows the `[session] ASAS_SESSION_SECRET not set`
  warning). Production deployments generate a fresh secret per `.env.example`.
- The repo has **no remote** (`git remote -v` empty) — history exists only on this machine. No third
  party can have cloned it. This materially lowers the urgency of the rewrite.

## Affected objects / commands (execution plan)

Tool of record: `git filter-repo` (pip-installed; safer and faster than BFG for this shape).
Before running: create a full safety mirror: `git clone --mirror . ../asas-backup-pre-purge.git`.

```bash
git filter-repo --force --invert-paths \
  --path .env \
  --path db/custom.db \
  --path db/docs-test.pdf \
  --path db/docs/.gitkeep \
  --path tool-results \
  --path .zscripts/dev.pid
```

Then: `git log --all -- .env db/custom.db | wc -l` → must be **0** (validation gate from the roadmap).

## Risks

1. **Commit-hash rewrite**: every commit after the initial one gets a new hash — all references to
   commit ids in `docs/` and `worklog.md` become stale (only `66b7c13` is referenced, in this file).
2. **Working-tree divergence**: filter-repo requires a clean tree; run it only with a clean status.
3. **Irreversibility**: without the mirror backup, the pre-purge history is unrecoverable.

## Required coordination

- None in this sandbox (single machine, no remote, no other clones). If a remote is ever added,
  the rewrite must happen BEFORE the first push (pushing then force-pushing would leak the secrets
  to the remote's reflog server-side — a purge-after-push is NOT sufficient).

## Rollback / recovery

- Safety mirror `../asas-backup-pre-purge.git` (created as step 0 above) can be pushed back:
  `git push ../asas-backup-pre-purge.git 'refs/*:refs/*' --force` from within the purged repo is NOT
  the direction — instead re-clone from the mirror and replace the working copy if the purge must be undone.
- Post-purge validation: `bun run lint` · `bunx tsc --noEmit` (src clean) · `GET /` 200 · login works ·
  `git fsck --full` clean.

## Decision

DEFERRED (D-013, 05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md): with no remote and current-tree remediation
complete, the residual risk is contained to this machine. The rewrite is justified only if the repo
is about to be published or a remote is added. The rotation side of the roadmap item is complete:
the leaked secret is not used by any running process, and production guidance (fresh secret per
`.env.example`) is documented.
