# SECURITY — CURRENT STATE (post P2-R1 + Phase 1 Task 1) & PRODUCTION CHECKLIST

Forensic evidence with curl transcripts: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/SECURITY_AUDIT.md` (F-01..F-19). Fix track: P2-R1 (worklog). Secrets purge: Phase 1 Task 1 (worklog P3-1) — F-04 remediated in the current tree; history purge documented and deferred (`GIT_HISTORY_PURGE.md`).

## Fixed & independently verified (2026-10-02)
- **F-01/F-02 (P0 chain)**: forged raw cookie → 401 (was: full OWNER takeover); forged signed-format w/ wrong sig → 401; legit signed cookie → 200. Cookie = `${userId}.${issuedAtMs}.${hmacSHA256}` (timingSafeEqual).
- **F-03**: quick-login respects lockouts (429 ACCOUNT_LOCKED live-verified on a locked account) + gated by `ASAS_DEMO_MODE`.
- **F-05**: password change/reset invalidates existing sessions (`passwordChangedAt` vs cookie issuedAt — old cookie 401, live-verified).
- **F-07**: ADMIN→OWNER escalation blocked (ROLE_CEILING 403 on create/modify/reset; regression: ADMIN/OWNER normal management still 200).
- **F-08**: document PATCH/DELETE uploader-or-MANAGER (403 DOC_FORBIDDEN, live).
- **F-09**: unknown errors → generic `INTERNAL` 500 (details server-side only).
- **F-11**: VLM analyze rate-limited 30s/user (429 ANALYSIS_RATE_LIMITED, live).
- **F-13**: temp passwords from CSPRNG (`randomInt`, same Asas-XXXXXX format).

## Verified-good controls (inherited)
Universal orgId tenant scoping (13-route IDOR probe: 404-only) · scrypt N=16384/r=8/p=1 + timingSafeEqual + per-user salt · passwordHash never serialized · audits store no password material · zod on every mutation (0 direct req.json) · zero raw SQL · XSS surface = stock shadcn chart.tsx only · CSV import caps (600KB / 2000 rows) · filename sanitization + path containment on document storage · CSRF: sameSite=lax + JSON-only parsing (form-urlencoded → 400 INVALID_JSON) · pageSize clamps.

## Accepted trade-offs (documented, D-002/D-003)
- **Demo mode default ON** (`ASAS_DEMO_MODE=1` in .env): persona quick-login grid + shared demo password are demo-workspace features. In production set `ASAS_DEMO_MODE=0` (quick-login → 403 DEMO_MODE_DISABLED; unauth session → demoUsers: []).
- In-memory rate limiters (login/copilot/analyze): single-instance, reset on restart. Fine at current scale; Redis/DB-backed if ever multi-instance.
- 30d cookie, no rotation, `secure` flag absent (HTTP sandbox).

## Fixed this phase (Phase 1 — F-04 current-tree remediation)
- **F-04 (secrets in VCS)**: `.env`, `db/custom.db`, `db/docs-test.pdf`, `db/docs/.gitkeep`, `.zscripts/dev.pid`, `tool-results/` (73 files) untracked from the index; `.gitignore` hardened (`/db/`, `/tool-results/`, `.zscripts/*.pid`, `!.env.example`); redacted `.env.example` committed. The leaked `ASAS_SESSION_SECRET` is confirmed **not in use** (running server restarted onto the ephemeral fallback; production generates fresh per template). Residual: history still holds the objects — full plan + authorization gate in `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` (D-013).
- **R9 mitigation**: `bun run db:snapshot` → timestamped copy under `db/backups/` (git-ignored) replaces the (now-removed) accidental git-tracking of the DB as the backup mechanism.

## OPEN items (post P5 — all code-level items CLOSED; remaining are deployment-time)
1. ~~Secrets in git~~ — current tree DONE (Phase 1); **history rewrite DEFERRED with authorization gate** (`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md`). Password rotation (kill `asas1234`) remains a production-deployment step: the sandbox demo password is intentionally public (D-007).
2. ~~Login timing oracle~~ — **DONE P4 (F-12)**: dummy-scrypt on unknown email; measured unknown 37-46ms vs known 38-41ms (median Δ 1.3ms, indistinguishable). Lockout + identical 401 bodies unchanged.
3. ~~CSV export formula injection~~ — **DONE P4 (F-14)**: csvEscape defangs leading `=+-@`/TAB/CR with `'` prefix (composed with RFC-4180 quoting); import strips exactly one defang marker so export→import round-trips. Live-verified with `=SUM(1+1)`, `+1|REM`, `=CMD("del *")` payloads.
4. ~~Origin-header check on mutations~~ — **DONE P5** (`assertSameOrigin()` enforced in `requireUser()` (every authed route, any method — covers body-less DELETEs) + `readJson()` (pre-auth mutations: login/quick-login — closes login-CSRF) + logout explicitly. Semantics: Origin absent → allow (non-browser clients); Origin parseable → allow iff `Sec-Fetch-Site: same-origin|none` (**D-020**: browser-vouched Fetch Metadata — JS-forbidden, covers platform-proxy chains that rewrite every Host-derived header) OR host ∈ {X-Forwarded-Host entries, direct Host} (**D-019 amendment**: the live gateway rewrites Host to bare `localhost` and vouches the original host in X-Forwarded-Host — client-forged XFH is replaced by Caddy, probed; Host-only comparison 403'd every browser login through the exposed :81 port). `Origin: null` (sandboxed frames) → allow through this layer (sameSite=lax already withholds cookies from opaque origins). 6-case curl matrix (direct + gateway, legit + evil + Sec-Fetch-Site variants) + real-browser E2E **through the gateway** (login + notes PATCH mutation persisted, `window.__errs`=0) + **real-browser cross-origin CSRF attack test (server 403)** all pass.
5. ~~clientIp trusts XFF verbatim~~ — **DONE P5 (F-15)**: XFF parsed from the RIGHT (rightmost = the entry our infrastructure vouches for). Live-verified: forged chain `1.2.3.4, 9.8.7.6` → audit records `9.8.7.6`; forged `6.6.6.6` through the Caddy gateway → audit records `::1` (gateway replace semantics).
6. Demo users listing not org-scoped (matters only in multi-org future).
7. Caddy `request_body max_size` (8MB cap currently enforced post-parse in app) — deployment-time.
8. Cookie `secure` + shorter lifetime for production — deployment-time (HTTPS precondition).

## Production checklist (before any real deployment)
`ASAS_DEMO_MODE=0` · strong `ASAS_SESSION_SECRET` (not in VCS — copy `.env.example`) · rotate all seeded passwords (kill asas1234) · execute `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` BEFORE adding any remote · HTTPS (secure cookies) · `bun run db:snapshot` backups (scheduled) · multi-instance? → move rate limits + sessions to shared store · NextAuth migration if SSO/multi-device needed.
