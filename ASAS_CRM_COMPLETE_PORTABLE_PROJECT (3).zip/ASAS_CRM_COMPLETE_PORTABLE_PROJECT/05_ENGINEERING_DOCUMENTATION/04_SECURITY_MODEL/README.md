# 04_SECURITY_MODEL

**Purpose (EN):** Authorization model, RLS, security hardening, secrets and git-purge policy.
**الغرض:** نموذج التفويض وسياسة الأمن والأسرار.
**Documents:** 5 · **Renamed from:** `security`

| # | File | Title | Bytes |
|---:|---|---|---:|
| 1 | `AUTHORIZATION_MODEL.md` | AUTHORIZATION MODEL | 18,193 |
| 2 | `GIT_HISTORY_PURGE.md` | GIT HISTORY PURGE — DEFERRED PLAN (requires explicit authorization) | 4,144 |
| 3 | `ROLE_DATA_VISIBILITY_MATRIX.md` | ROLE × DATA VISIBILITY MATRIX | 13,771 |
| 4 | `SECURITY_AND_RLS.md` | SECURITY AND RLS — THE TWO-LAYER AUTHORIZATION MODEL | 11,122 |
| 5 | `SECURITY_HARDENING.md` | SECURITY — CURRENT STATE (post P2-R1 + Phase 1 Task 1) & PRODUCTION CHECKLIST | 6,455 |

--- Part of `ASAS_CRM_COMPLETE_PORTABLE_PROJECT/05_ENGINEERING_DOCUMENTATION` — see root `README.md` for the master index.
