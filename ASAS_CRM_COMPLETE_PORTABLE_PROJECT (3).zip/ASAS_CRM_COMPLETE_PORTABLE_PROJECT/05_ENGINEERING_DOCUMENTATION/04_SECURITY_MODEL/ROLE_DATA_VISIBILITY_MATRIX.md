# ROLE × DATA VISIBILITY MATRIX

> **GOV-3 verification stamp (2026-10-19):** re-verified against live code + the GOV-2 runtime
> probes (matrix 231/231). Two rows carried **confirmed deviations** (annotated inline): Notifications
> (F-02) — **FIXED 2026-10-19 (G5-P3-1, D-GOV-5): the `RESERVATIONS_EXPIRING` group now spreads
> `reservationScope` like every sibling group; permanent regression probes FR37a–e in the matrix
> (238/238)** — and Team roster (F-14 — **FIXED 2026-10-19, G5-P3-4/D-GOV-5: below-MANAGER roster = names+roles; MANAGER+ keeps email for the Équipe management table; probes FR39a–e, matrix 254/254; B-6 re-run inverted**). Four stale rows were refreshed to the
> live surface (targets/collections removed by D-025; check-duplicates superseded by the P30/P53
> duplicates machine; the MARKETING role header — the role was removed at P18). Contracts not
> annotated are verified current.

**Status: BINDING (Phase 12, D-021).** Derived from the actual ASAS business model
(single agency, developer-side sales, assignment-based ownership, shared inventory,
WhatsApp-first) — NOT copied from a generic template. The enforcement mechanism for every
cell is defined in `AUTHORIZATION_MODEL.md` §3; this file is the per-resource contract.

Scopes: **ORG** = every record in the org · **OWN+POOL** = records the user owns + unassigned
records + shared operational data · **SHARED** = the same catalogue/roster for all roles ·
**NONE/404** = indistinguishable from nonexistence.

## 1. Operational records

| Resource (model · owner field) | SALES_AGENT / FIELD_REP (§1.b) | MANAGER | ADMIN | OWNER |
|---|---|---|---|---|
| Prospects (`Lead` · ownerId) | OWN+POOL | ORG | ORG | ORG |
| Opportunities (`Opportunity` · ownerId) | OWN+POOL | ORG | ORG | ORG |
| Tasks (`Task` · ownerId) | OWN+POOL | ORG | ORG | ORG |
| Visits (`Visit` · agentId) | OWN+POOL | ORG | ORG | ORG |
| Activities / notes (`Activity` · actorId + links) | own actions + activities on OWN+POOL leads/opps/tasks/visits | ORG | ORG | ORG |
| Contacts (`Contact` · leadId) | follows the lead's scope (OWN+POOL) | ORG | ORG | ORG |
| Documents (`Document` · uploadedById + entity) | own uploads + inventory docs + docs on OWN+POOL entities | ORG | ORG | ORG |
| Reservations (`Reservation` · agentId + opportunityId) | own + on OWN+POOL opportunities | ORG | ORG | ORG |
| Deal economics (`Reservation.commissionFrom/amount · agentIncentive`, P18/D-025) | reads: `agentIncentive` on own reservations (the "see the incentive" mandate); commission is management-only | ORG + writes (MANAGER+, 403 COMMISSION_FORBIDDEN) | same | same |
| Matching requirements (`MatchingLead` · leadId) | follows the lead's scope | ORG | ORG | ORG |
| Saved searches (`SavedSearch` · userId) | own + org-TEAM-shared rows (P7-2, unchanged) | same | same | same |
| Notifications | own + OWN+POOL-derived reminders (unchanged — the reference pattern) · **✅ FIXED 2026-10-19 (G5-P3-1, D-GOV-5): the `RESERVATIONS_EXPIRING` group now spreads `reservationScope` — peer agents excluded, FIELD_REP through the assigned-project visits path, MANAGER org-wide; regression probes FR37a–e (matrix 238/238); the B-1 probe re-run inverted: peer-agent leak refuted, field-rep sight verified legitimate (lead's visit on an assigned project)** | org-derived | same | same |

### 1.b FIELD_REP (Représentant terrain — P18 / D-025)

The field representative's row in every table above reads as: **assigned-project-scoped**
(pure relation predicates through `ProjectAssignment` — see AUTHORIZATION_MODEL §3.1b):
visits on their projects, the leads/opps/contacts/activities those visits belong to,
own tasks only, NO intake pool, shared inventory. Leads/pipeline nav items are hidden
(hideFor FIELD_REP) — their life is the agenda + inventory. Cross-rep isolation is
404-byte-identical (matrix FR1/FR2/FR10).

## 2. Shared operational data (all authenticated roles — by design)

| Resource | Scope | Rationale |
|---|---|---|
| Projects, buildings, apartments, unit types | SHARED | the sales floor sells the same inventory; property matching depends on it |
| Team roster (`GET /api/users` — names + roles) | SHARED · **✅ FIXED 2026-10-19 (G5-P3-4, D-GOV-5): below-MANAGER roster = names+roles exactly (emails stripped — data minimization, probes FR39a–c); MANAGER+ keeps email (the Équipe management table, FR39d/e)** | single-agency collaboration context; account admin ops stay ADMIN-gated |
| Pipeline stage definitions | SHARED | the process is common vocabulary |
| Sources, tags | SHARED | org taxonomies |

## 3. Management surfaces (rank gates — coarse RBAC, unchanged where already correct)

| Surface | SALES_AGENT | MANAGER | ADMIN | OWNER |
|---|---|---|---|---|
| `/api/analytics` (revenue, funnel, conversion, cycle) | **403** | yes | yes | yes |
| Dashboard funnel / source performance / targets card | hidden (null) | yes | yes | yes |
| `/api/audit` | 403 | yes | yes | yes |
| `/api/settings` (org settings) | 403 | yes | yes | yes |
| `/api/leads/import` + undo | 403 | yes | yes | yes |
| `/api/leads/export` · `/api/export/bundle` | 403 | yes | yes | yes |
| User administration (create/update/reset/deactivate) | 403 | 403 | yes | yes (LAST_OWNER guards) |
| Targets write (`POST/PATCH/DELETE`) | **REMOVED (D-025 — SalesTarget deleted, `/api/targets` route removed P26/P32; row kept for history)** | — | — | — |
| WIP limits (`PATCH /api/pipeline/stages/[id]`) | 403 | 403 | yes | yes |
| P18 economics writes (commission/incentive PATCH on reservations) | **403** COMMISSION_FORBIDDEN | yes (Directeur exécutif+) | yes | yes |
| P18 visit confirmation (PATCH status CONFIRMED) | **403** VISIT_CONFIRM_FORBIDDEN (the follow-up rep never confirms) | yes (rank path) | yes | **assigned FIELD_REP only** |
| P18 assignment management (POST/DELETE assignments) | **403** | yes | yes | **403** (field reps are assigned, not assigners) |
| P13 dashboard finance block (collections card) | **REMOVED (D-025 — finance → ERP; row kept for history)** | — | — | — |
| Change own password | yes | yes | yes | yes |

## 4. Leakage channels — all closed to the record scope (mandate §15)

| Channel | Rule |
|---|---|
| Search / command palette autocomplete | scope fragments per entity — foreign rows are not hits, not even counts |
| Duplicate detection (`/api/leads/duplicates/*` scan/merge/dismiss — P30/P53; the old `check-duplicates` route was removed P34/D-042) | **403 below MANAGER** (D-021 scope law — FR36c live); the KPI/bell waypoint is null-gated identically through the shared `duplicates.ts` predicate — scan ≡ KPI ≡ bell by construction |
| Error messages | foreign id → 404 byte-identical to random id (LEAD_NOT_FOUND etc.) |
| AI endpoints (copilot, document analyze) | scoped findFirst before any model call → 404 |
| Dashboard KPIs / totals | computed inside the caller's scope |
| Bulk operations | scope fragment inside updateMany where — foreign ids simply don't match |
| CSV export | MANAGER+ only (rank gate) |

## 5. Mutation rights

| Operation | SALES_AGENT | MANAGER+ |
|---|---|---|
| Create records (lead/task/visit/opp/doc) referencing an entity | reference must be in the caller's scope, else 404 | org any |
| Update / delete own or pool records | yes | yes |
| Update / delete another agent's records | **404** | yes |
| Reassign ownership (`ownerId` change) | on records already in own scope (self-service handover) | any |
| Lifecycle transitions (convert, reactivate, stage moves, reservations) | only on in-scope records; server state machines unchanged | any |

---

## ADDENDUM — 2026-10-26 (UX-OWNER-PLAN-2): reservation financial-field law + the field-by-role matrix

**Owner decision FIN-MIN-Q10 (approved 2026-10-26, planning-level):** commission, incentive, and
related financial-basis fields **must NOT be returned by server responses to roles below the authorized
manager/administration boundary** (MANAGER 70 / ADMIN 90 / OWNER 100 — `ROLE_RANK`,
constants.ts:354-360). **Hiding fields in the UI is insufficient — the target is server-side response
minimization: unauthorized financial fields are not serialized at all.** Existing authorization rules
are not weakened by this decision; field minimization is a SECOND layer on top of the D-021 row scoping
(`reservationScope`, visibility.ts:138-149), never a replacement.

### A. The verified current deviation (the defect this decision closes)

- **GET `/api/reservations`** — `requireUser()` with **no role gate** (route.ts:76) +
 `findMany({ where, include: reservationInclude })` — **`include`, NOT a field-level `select`**
 (route.ts:112-116): the FULL Reservation model — the entire §37/§38 family below — is serialized to
 SALES_AGENT and FIELD_REP on every in-scope row. **POST `/api/reservations`** returns the full model
 on 201 (route.ts:189-194, 239-240). This deviated from THIS document's §1 "Deal economics" row
 (commission reads management-only; agentIncentive on own reservations) and from the schema's own
 visibility comment (schema.prisma:593-596). **Status at record time: SECURITY REMEDIATION PRIORITY +
 implementation blocker** — plan: `NEXT_PHASE_PLAN.md` §6 (workstream S, scheduled FIRST among
 implementation phases). No runtime behavior was changed by the documentation task that recorded this.
 **STATUS FLIP (2026-10-26, WS-S-EXEC): FIXED at this HEAD** — the owner authorized Workstream S
 (register §1c.1 decision 7) and it was executed: the shared role-aware serializer
 `src/lib/server/reservation-dto.ts` (this addendum's target state, row-for-row) now guards EVERY
 reservation response path — GET list + all four query variants, POST 201, and both PATCH branch
 returns (including `request_closure`, the responsible-SALES_AGENT-reachable surface whose old return
 spread the full row — a path the original deviation record above did not list; found by live
 re-inspection during S). §37/§38 keys are ABSENT (key-level, not null) from every floor-role
 response; MANAGER+ responses pass through byte-identical; D-021 row scoping untouched. Verified by
 the 448-check live battery + browser E2E (`download/qa-ws-s/`); the negative-test column below was
 executed exactly as specified.
- Clean surfaces (verified the same round): dashboard (field-selected + null-gated below MANAGER —
 the agent keeps the pure-aggregate "Mes incentives" surface; FIELD_REP neither) · notifications
 (id/label/leadId only) · export bundle + analytics (MANAGER+ rank-gated) · apartments (count-only).
- **GET `/api/reservations/[id]` does not exist** (PATCH-only route file → 405 on GET).

### B. The field-by-role matrix (the canonical target state)

Field family references: `prisma/schema.prisma:575-616`. "MUST be absent" = not serialized at all
(key-level absence, not null).

| Field family (schema lines) | OWNER / ADMIN / MANAGER | SALES_AGENT | FIELD_REP | Write path (audited) | API return below MANAGER+ | Negative tests required |
|---|---|---|---|---|---|---|
| §37 commission: `commissionAmount` (597) · `commissionFrom` (598) · `commissionBasis` (605) · `commissionStatus` (606) · `commissionEarnedAmount` (607) · `commissionReceivedAmount` (608) · `commissionReceivedAt` (609) | read ✅ | ❌ | ❌ | MANAGER+ only — `applyReservationEconomics`, 403 COMMISSION_FORBIDDEN below (reservation-economics.ts:61-64); COMMISSION_SET / COMMISSION_REBASE audit rows carry before/after + decidedBy stamps | **MUST be absent** (today: PRESENT — the defect) | floor-role GET (list + `?id=` / `?opportunityId=` / `?apartmentId=` variants) + POST 201: assert JSON keys ABSENT; manager shape unchanged |
| §38 incentive: `agentIncentive` (599) · `incentiveBasis` (610) · `incentiveStatus` (611) · `incentiveDecidedById` (614) · `incentiveDecidedAt` (615) · `incentivePaidAt` (616) | read ✅ | ❌ raw values — own-incentive visibility lives ONLY through the clean dashboard aggregate ("Mes incentives", pure aggregate, no record ids — dashboard/route.ts:385-411) | ❌ | MANAGER+ only (same gate); INCENTIVE_SET / INCENTIVE_DECIDED / INCENTIVE_PAID / INCENTIVE_REBASE audit rows | **MUST be absent** (today: PRESENT — the defect) | same absence probes + the My Day aggregate regression pair (agent still sees own aggregate) |
| Booking facts: `amount` (575) · `depositPaid` (576) | read ✅ | read in-scope (RECOMMENDED — commercial facts of the booking; the owner may narrow in a future answer) | read in-scope (same) | `amount`: creator/manager; `depositPaid`: MANAGER+ economics path | stays serializable in-scope (RECOMMENDED) | if narrowed later: absence probes |
| Workflow facts: `status` (577) · `expiresAt` · `notary` · `contractRef` · `reason` · closure stamps (`closureRequestedById/At`, `convertedById/At`) | read ✅ | read in-scope — the closure workflow requires them at floor tier (request_closure is the responsible agent's action) | same | per existing lifecycle rules (request: responsible agent/MANAGER+; validate/reject/cancel: MANAGER+ — reservation-lifecycle.ts:83-100) | stays (workflow necessity) | unchanged matrix probes |

**Record scope:** every row above rides the D-021 `reservationScope` row set (agent = own agentId ∨
unassigned ∨ own/pool opportunity; FIELD_REP = project-derived; MANAGER+ = org). **Audit:** all §37/§38
writes are already audited with before/after + decidedBy receipts; the FIN-MIN-Q10 remediation adds no
new audit event (it narrows SERIALIZATION, not writes). **Remediation plan + acceptance criteria:**
`NEXT_PHASE_PLAN.md` §6.3 (role-aware field-level serializer; byte-level absence assertions; the
standing suites re-run; rollback = single-module revert).
