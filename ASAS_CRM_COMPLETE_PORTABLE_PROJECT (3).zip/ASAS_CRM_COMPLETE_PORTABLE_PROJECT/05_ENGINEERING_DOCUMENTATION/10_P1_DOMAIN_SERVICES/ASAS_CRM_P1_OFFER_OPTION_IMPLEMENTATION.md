# ASAS CRM — P1 / W1-A1: Offer/Option Domain Implementation Report

**Agent:** 1 — Offer/Option Domain & Database Architect (W1-A1, Wave 1)
**Date:** 2026-11-05
**Scope:** The negotiable commercial proposal + provisional-unit-hold stage between Opportunity and Reservation (the missing sales-lifecycle stage), end to end: schema → migration → lifecycle law module → API → expiration sweep → UI → seed → live data → tests → live evidence.

**Headline:** The domain is IMPLEMENTED, TESTED and live-VERIFIED. Final gates: `prisma migrate deploy` → 21 migrations (no pending) · health `migrations:21` · `bun run test` → **228/228** (204 baseline + 16 unit + 8 security, 0 skipped) · `bun run typecheck` → 0 errors · `bun run lint` → 0 errors (37 pre-existing warnings, none in offer files) · one full live workflow proven over HTTP with DB reads and full residue-free rollback.

---

## 1. Status matrix (task → status + evidence)

| Plan task | Status | Evidence |
|---|---|---|
| `Offer` model in `prisma/schema.prisma` (+ back-relations `offers Offer[]` on Organization/Opportunity/Apartment) | **VERIFIED** | `git diff prisma/schema.prisma`; schema law block documented inline (Reservation comment style). `bunx prisma validate` implied green via generate; deployed via migration. |
| Hand-written migration `prisma/migrations/20261105180000_p1_offer_option/migration.sql` (table + 4 plain indexes + 2 partial unique indexes) | **VERIFIED** | Migration SQL (below §3); `_prisma_migrations` lists it; `migrate deploy` reports 21 found / 0 pending. |
| Partial unique indexes appended to `prisma/live-hold-indexes.sql` (R13 rebuild reapply file) | **VERIFIED** | `git diff prisma/live-hold-indexes.sql` — `Offer_apartment_live_hold_uq` + `Offer_opportunity_live_hold_uq` with `IF NOT EXISTS`. |
| `src/lib/server/offer-lifecycle.ts` — the single authoritative business-rule module (pure transition table + orchestrators) | **VERIFIED** | 1,142 lines; pure functions unit-tested without DB (`tests/unit/offer-lifecycle.test.ts`); routes stay thin (24–105 lines each). |
| `constants.ts` offer vocabulary (`OFFER_STATUSES`, `OFFER_LIVE_STATUSES`, `OFFER_TERMINAL_STATUSES`, `OFFER_ACTIONS`, `OFFER_LIFECYCLE`, `OFFER_STATUS_TONE`) | **VERIFIED** | `git diff src/lib/constants.ts` (additive block at EOF + `OFFER` ActivityType; no existing constant touched). |
| API surface `/api/offers/**` (GET list, POST create, GET/PATCH `[id]`, POST `[id]/activate|confirm|cancel|convert`) | **VERIFIED** | `src/app/api/offers/route.ts` (105 lines), `[id]/route.ts` (62), 4 action routes (24–33 each). Live curls + test suite hit every endpoint. |
| Symmetric cross-guard in `POST /api/reservations` (live Offer → 409 `UNIT_OPTIONED`) — the ONE sanctioned edit in that route | **VERIFIED** | `git diff src/app/api/reservations/route.ts` — 18 added lines, nothing else changed; proven by security test 2; all 204 pre-existing tests still green. |
| Offer expiration sweep in `src/lib/server/expiry.ts` + `expiry-scheduler.ts` | **VERIFIED** | `expireDueOffers()` (reservation-sweeper law restated: guarded `updateMany`, same-tx audit + activity, guarded unit release); lazy at `GET /api/offers` + same scheduler tick (60 s). Proven by security test 4. |
| Frontend "Offres / Options" section in the opportunity cockpit | **VERIFIED** | `src/components/crm/pipeline/opportunity-offers.tsx` (625 lines) mounted in `opportunity-detail-dialog.tsx` (2-line import + 1 JSX block); role-aware actions, French copy, i18n keys ×3 languages (43 keys × fr/en/ar = 129 entries), shadcn/ui only, `formatDZD`, query invalidation via `useInvalidateDealMutations` + offers/reservations/apartments projections, `h-11` (44px) mobile touch targets, ErrorState/EmptyState/loading. |
| `OPTIONED` apartment chip | **VERIFIED** (pre-existing, confirmed distinct) | `APARTMENT_STATUS_TONE.OPTIONED` = orange chip (distinct from RESERVED amber), labels `apartment.status.OPTIONED` fr/en/ar pre-existed — per the brief ("do not fork a new badge system") the mapping was reused as-is. Offer rows use the new `OfferStatusBadge` (violet ACTIVE family, D-UX-010 tone law). |
| Timeline surface for offer lifecycle rows | **VERIFIED** | `ACTIVITY_TYPES` + `TYPE_ICON.OFFER = Handshake`, `TYPE_DOT.OFFER = bg-violet-500`, `activity.offer` i18n ×3 languages (`lead-tab-activities.tsx`). |
| Seed block in `prisma/seed.ts` | **VERIFIED** | `seedOffers()` — ACTIVE offer on Leila Ferhat's OPTION-stage deal holding H-12 (unit seeds OPTIONED), unit-less DRAFT on Abdelhak Slimani, CONVERTED linked to the oldest won-deal reservation; standalone-idempotent; audit/activity mirrors of the live route shapes. |
| Live-DB seed rows (one-off script, INSERT-only, deleted after) | **VERIFIED** | DB carries exactly 3 offer rows (CONVERTED/ACTIVE/DRAFT), H-12 = OPTIONED, agent/audit rows present. Script deleted; verified zero `scripts-tmp-*` residue. |
| `tests/unit/offer-lifecycle.test.ts` (pure state machine) | **VERIFIED** | 16 tests, no DB (vitest `@/lib/db` throwing stub imported but never called at module scope). |
| `tests/security/offer-concurrency.test.ts` (live-server + direct PrismaClient) | **VERIFIED** | 8 tests; preflight THROWS when server unreachable (no silent skip); markers `P1-OFFER-*`; full teardown restores apartments/opp stage, deletes this run's rows. |
| Contract test migration-count update | **VERIFIED** | `tests/contract/api.test.ts` — health bookkeeping `[20, null]` → `[21, null]`. |
| Live workflow demonstration (login → create → activate → confirm → convert → DB proof) | **VERIFIED** | §7 below — curl-level status codes + DB reads, residue-free rollback. |
| Report (this file) | **DELIVERED** | — |

Legend per plan §5: NOT STARTED → … → VERIFIED (evidence required). Nothing is claimed above its evidence.

---

## 2. Data model (deployed)

```
model Offer {
  id            String   @id @default(cuid())
  orgId         String                     // tenant isolation (org-scoped everything)
  opportunityId String                     // anchor — offers live on a deal
  apartmentId   String?                    // nullable BY DESIGN: unit-less negotiation
  agentId       String?                    // owning rep — Reservation.agentId no-relation pattern
  amount        Float?                     // offered price DZD
  paymentPlan   String?                    // CASH | INSTALLMENT | NOTARY_1_3 (APARTMENT_PAYMENT_PLANS)
  terms         String?                    // free-text commercial terms (≤1000)
  status        String   @default("DRAFT") // DRAFT|ACTIVE|CONFIRMED|CANCELLED|EXPIRED|CONVERTED
  expiresAt     DateTime?                  // REQUIRED for ACTIVE/CONFIRMED (service law)
  confirmedAt   DateTime?
  convertedReservationId String?            // in-memory join (no relation, Reservation.id)
  cancelledById String? / cancelledAt / cancelReason (REQUIRED on cancel, service law)
  createdById   String
  createdAt / updatedAt
  @@index([orgId, status, expiresAt])  // listing + sweep
  @@index([opportunityId])
  @@index([orgId, createdAt])           // analytics range
  @@index([orgId, agentId])             // rep aggregation
}
```

Back-relations: `Organization.offers`, `Opportunity.offers`, `Apartment.offers`.

### Migration: `20261105180000_p1_offer_option` (applied — chain now 21)

```sql
CREATE TABLE "Offer" ( … FK orgId→Organization, opportunityId→Opportunity (RESTRICT),
                       apartmentId→Apartment (SET NULL) … );
CREATE INDEX "Offer_orgId_status_expiresAt_idx" ON "Offer"("orgId","status","expiresAt");
CREATE INDEX "Offer_opportunityId_idx"           ON "Offer"("opportunityId");
CREATE INDEX "Offer_orgId_createdAt_idx"          ON "Offer"("orgId","createdAt");
CREATE INDEX "Offer_orgId_agentId_idx"            ON "Offer"("orgId","agentId");
-- D12-family live-hold backstops (raw SQL — Prisma cannot express partial uniques):
CREATE UNIQUE INDEX "Offer_apartment_live_hold_uq"
  ON "Offer"("apartmentId")
  WHERE "status" IN ('ACTIVE','CONFIRMED') AND "apartmentId" IS NOT NULL;
CREATE UNIQUE INDEX "Offer_opportunity_live_hold_uq"
  ON "Offer"("opportunityId")
  WHERE "status" IN ('ACTIVE','CONFIRMED');
```

Both partial uniques are ALSO appended to `prisma/live-hold-indexes.sql` (the R13-rebuild reapply file) with `IF NOT EXISTS`.

---

## 3. Design decisions & laws (the "why")

1. **Partial-unique strategy (the concurrency core).** In-tx guards are the first line (precise business error codes), but SQLite serializes writes — the race between two concurrent `POST /api/offers {activate:true}` on the same unit is closed ABSOLUTELY by `Offer_apartment_live_hold_uq`: the loser's INSERT violates the index inside its `$transaction` and rolls back whole (row + hold flip + audit + activity). A `P2002` is mapped (`mapOfferP2002`) back to the same 409 vocabulary (`UNIT_ALREADY_OPTIONED` / `OPPORTUNITY_ALREADY_OPTIONED`) — the reservations route's `ALREADY_RESERVED` mapping pattern. This mirrors the D12 Reservation decision exactly.
2. **ONE live offer per opportunity (index `Offer_opportunity_live_hold_uq`).** Adopted deliberately — Reservation-parity law (a deal holds at most one live unit). Competing parallel options on one deal would strand units behind a single client; the guard answers `OPPORTUNITY_ALREADY_OPTIONED` (409) first, the index backstops.
3. **`apartmentId` nullable.** An offer can be a pure price/terms negotiation before any unit is chosen; the hold starts at the earliest ACTIVE-with-unit (or on activate via PATCH).
4. **`apartment.status = OPTIONED` is the hold mirror.** The enum value existed unused; the offer domain now gives it meaning: flip to OPTIONED happens in the SAME transaction as the offer row (D-GOV-5 §2), release is GUARDED (`updateMany WHERE status='OPTIONED' AND no live reservation`) — a manual inventory move is never overwritten, and a unit never goes back to AVAILABLE when it no longer mirrors the hold.
5. **An offer NEVER silently becomes a reservation.** `convert` is an explicit MANAGER+ endpoint that re-creates the reservation under the SAME guard sequence `POST /api/reservations` applies (in-tx apartment re-read, `APARTMENT_NOT_AVAILABLE` unless OPTIONED, live-reservation check, terminal-row revive + DOM-D1 dependents guard, one-live-hold-per-deal, stage advance with `OPPORTUNITY_TRANSITIONS`-legal pre-booking stages, full payload-reset family). The law is currently stated twice (route + convert branch) in deliberate lockstep — **W2-A3 owns the extraction into a shared service; its brief explicitly requires preserving this convert path and Agent 1's reservations cross-guard.**
6. **RBAC mirrors reservations.** Any authenticated role creates offers (POST parity); floor actions (activate/confirm) belong to the responsible agent OR MANAGER+; cancel and convert are managerial decisions (reservation cancel/closure authority parity). Authority is enforced server-side in `offer-lifecycle.ts` (`OFFER_LIFECYCLE[action].managerOnly`) — UI hiding is never authorization.
7. **Expiry clock (the W1-5 lesson applied at birth).** ACTIVE/CONFIRMED REQUIRE a future `expiresAt` (`EXPIRY_REQUIRED` / `EXPIRES_AT_PAST`); confirm/convert refuse a past-due offer (`OFFER_EXPIRED`) — the sweeper alone owns the death. `expireDueOffers()` restates the reservation-sweeper law: per offer, short interactive transaction, status+clock-preconditioned `updateMany` (a concurrent manual action that wins the race makes the sweep a no-op), guarded unit release, `OFFER_EXPIRED` audit + timeline activity in the same commit. Runs lazily at `GET /api/offers` and on the existing 60 s scheduler tick (one interval, two indexed scans — no new scheduler infra).
8. **F-06 audit law.** Every mutation (create/activate/edit/confirm/cancel/convert/expire) writes AuditLog before/after + Activity rows INSIDE the same `$transaction`; every route folds an `injectTxFault` site after the primary mutation (`offer:create|patch|activate|confirm|cancel|convert:post-mutation`) so fault injection proves atomicity (security test 7: no orphan Offer/AuditLog/Activity row, no stale OPTIONED flip).
9. **History = AuditLog before/after JSON.** No separate version table (per the brief; the `OFFER_UPDATED` audit row with before/after amount/terms/expiry/unit IS the modification history).
10. **Concurrency-safe state claims.** Each action uses a status-preconditioned `updateMany` claim (e.g. `WHERE id AND status='CONFIRMED'` for convert) — a concurrent duplicate action flips zero rows and answers the precise 409 (`OFFER_ALREADY_*`), never double side effects.
11. **D-021 scoping.** `offerScope()` composes `oppScope` (offers are opportunity-anchored): MANAGER+ org-wide, SALES_AGENT own+pool deals, FIELD_REP project-derived deals. Detail/mutation routes use scoped `findFirst` → foreign ids are byte-identical 404 ghosts (`OFFER_NOT_FOUND`), proven by security test 8 against a real foreign-org row.
12. **Cross-domain guard placement.** In `POST /api/reservations` the `UNIT_OPTIONED` check sits BEFORE the availability check (a live option explains the unit's state); in the offer domain, `assertUnitHoldable` checks the live Reservation FIRST (`ALREADY_RESERVED`) then unit status (`UNIT_NOT_HOLDABLE` — AVAILABLE/OPTIONED only; an orphan OPTIONED unit is adoptable).
13. **Offer vs Reservation vocabulary is symmetric and precise:** offer-side errors `ALREADY_RESERVED`/`UNIT_OPTIONED`; reservation-side errors `UNIT_OPTIONED`/`ALREADY_RESERVED`. One shared `APARTMENT_STATUS_CHANGED` audit action covers the unit flips (already in the audit i18n dicts).

---

## 4. API contract

| Endpoint | Method | Contract |
|---|---|---|
| `/api/offers` | GET | Org-scoped list; filters `opportunityId`, `status` (OFFER_STATUSES), `agentId`, `apartmentId`; pagination `page`/`pageSize` (leads house pattern, defaults 1/200, max 500); runs `expireDueOffers()` first; `{data, total, page, pageSize}`; rows carry opportunity + apartment (+building/project) includes and in-memory `agent {id,name}` join. |
| `/api/offers` | POST | Body: `{opportunityId (req), apartmentId?, amount? ≥0, paymentPlan? ∈ APARTMENT_PAYMENT_PLANS, terms? ≤1000, expiresAt?, activate?}`; DRAFT default; `activate:true` creates ACTIVE + takes the hold in ONE transaction (requires future expiresAt — 422 `EXPIRY_REQUIRED`/`EXPIRES_AT_PAST`); opportunity must be in scope (404 ghost) and open (422 `OPPORTUNITY_NOT_OFFERABLE` on CLOSED_WON/LOST). 201 `{offer}`; precise 409s (`UNIT_NOT_HOLDABLE`, `ALREADY_RESERVED`, `UNIT_ALREADY_OPTIONED`, `OPPORTUNITY_ALREADY_OPTIONED`) incl. P2002 backstop. |
| `/api/offers/[id]` | GET | Scoped detail (404 `OFFER_NOT_FOUND` ghost). |
| `/api/offers/[id]` | PATCH | Edit while DRAFT/ACTIVE (422 `OFFER_NOT_EDITABLE` terminal); responsible agent OR MANAGER+ (403); unit change transfers the hold atomically (guards on the NEW unit first — a rejected transfer rolls back release+take); every edit audited before/after. |
| `/api/offers/[id]/activate` | POST | DRAFT→ACTIVE + apartment OPTIONED (same tx); authority responsible OR MANAGER+; 409 `OFFER_ALREADY_ACTIVE` on races. |
| `/api/offers/[id]/confirm` | POST | ACTIVE→CONFIRMED + `confirmedAt`; refused when past-due (422 `OFFER_EXPIRED`); 409 `OFFER_ALREADY_CONFIRMED` family on races. |
| `/api/offers/[id]/cancel` | POST | Body `{reason}` REQUIRED (422 `REASON_REQUIRED`, ≤500); MANAGER+ (403); DRAFT/ACTIVE/CONFIRMED→CANCELLED + guarded unit release; terminal refusal 422 `OFFER_ILLEGAL_TRANSITION`. |
| `/api/offers/[id]/convert` | POST | MANAGER+ (403 `FORBIDDEN_ROLE` for agents); CONFIRMED-only (422 `OFFER_ILLEGAL_TRANSITION`); unit required (422 `OFFER_HAS_NO_UNIT`); creates the Reservation in the SAME transaction (guard sequence of `POST /api/reservations`), links `convertedReservationId`, apartment OPTIONED→RESERVED, stage advance + STAGE_CHANGE trail; `{offer, reservation}` (reservation rides the shared role-aware DTO). |
| `POST /api/reservations` | *(cross-guard only)* | Live Offer on the apartment → 409 `UNIT_OPTIONED` (the single sanctioned edit in that route; Agent 3 must preserve it). |

Error codes (French messages, `fail()`/`ApiError` envelope): `OFFER_NOT_FOUND`, `OPPORTUNITY_NOT_OFFERABLE`, `EXPIRY_REQUIRED`, `EXPIRES_AT_PAST`, `OFFER_ILLEGAL_TRANSITION`, `OFFER_NOT_EDITABLE`, `OFFER_EXPIRED`, `OFFER_HAS_NO_UNIT`, `OFFER_ALREADY_{ACTIVE|CONFIRMED|CANCELLED|CONVERTED}`, `UNIT_NOT_HOLDABLE`, `ALREADY_RESERVED`, `UNIT_ALREADY_OPTIONED`, `OPPORTUNITY_ALREADY_OPTIONED`, `APARTMENT_NOT_AVAILABLE`, `APARTMENT_NOT_FOUND`, `RESERVATION_HAS_DEPENDENTS`, `OPPORTUNITY_ALREADY_BOOKED`, `REASON_REQUIRED`, `FORBIDDEN_ROLE`.

---

## 5. Test results (exact)

| Gate | Result |
|---|---|
| `bunx prisma migrate deploy` | 21 migrations found in `prisma/migrations` — **no pending**; health `{"migrations":21,"dbOk":true}` |
| `bunx prisma generate` | OK (client regenerated; dev-only stale-client self-heal guarded in `src/lib/db.ts`) |
| `bun run test` (vitest) | **16 files, 228/228 passed, 0 skipped** (baseline 204/204 in 14 files + 16 unit + 8 security) |
| `bun run typecheck` (tsc) | **0 errors** |
| `bun run lint` | **0 errors**; 37 warnings — all pre-existing (zero in offer files; verified by filtered scan) |

New suites:
- `tests/unit/offer-lifecycle.test.ts` — 16 tests, pure rules (transition table integrity, partition law, authority law, editable-while law, expiry-clock rules, P2002 mapping).
- `tests/security/offer-concurrency.test.ts` — 8 tests against the LIVE server + direct PrismaClient: (1) two concurrent activated offers on one unit → exactly one 201 + one 409, one live row, unit OPTIONED, loser fully rolled back; (2) reservation POST on optioned unit → 409 `UNIT_OPTIONED`, no row; (3) offer on reserved unit → 409 `ALREADY_RESERVED`, no row; (4) confirm after forced past-due → refused, sweep flips EXPIRED + releases unit + one audit row, terminal 422 afterwards; (5) agent convert → 403; manager convert → offer CONVERTED + link + reservation ACTIVE + apartment RESERVED + negotiated amount + owning rep carried through + audits; (6) cancel without reason → 422 `REASON_REQUIRED`, with reason → CANCELLED + unit AVAILABLE; (7) `x-test-inject: offer:create:post-mutation` → 500 `FAULT_INJECTED` + zero orphan offer/audit/activity rows + unit un-flipped; (8) foreign-org offer → byte-identical 404 ghost (incl. mutation), row untouched. Teardown restores probe apartments + opp stage, deletes this run's marker rows.

---

## 6. Seed & live data

- `prisma/seed.ts` — `seedOffers()` (idempotent by existing-row guard): ACTIVE offer on Leila Ferhat's OPTION-stage deal holding **H-12** (43.8 M DA, CASH, 6-day validity — unit seeds OPTIONED, with OFFER_CREATED/OFFER_ACTIVATED/APARTMENT_STATUS_CHANGED audits + timeline row), unit-less DRAFT on Abdelhak Slimani (52 M DA, INSTALLMENT), CONVERTED offer linked to the oldest seeded won-deal reservation (backdated trail). Summary line extended with `offers:` count.
- Live DB — same three rows INSERTED via a one-off `scripts-tmp-*.mjs` (node + PrismaClient direct, cuid ids, INSERT-only, apartment AVAILABLE→OPTIONED consistently), script deleted after. Verified live: `SELECT` shows `['CONVERTED','ACTIVE','DRAFT']`, H-12 = `OPTIONED`, both partial unique indexes present in `sqlite_master`.

---

## 7. Live workflow evidence (curl-level, 2026-11-05 16:48 UTC)

Login as sarah@asas.dz (MANAGER) → fixtures: apartment **A-11** (AVAILABLE), a VISIT_SCHEDULED opportunity with no live offer/option:

```
[0] login sarah=200 | fixtures: apt=A-11 (AVAILABLE) opp=cmw3q2g0v00a4tozoy5vz37v6 (stage=VISIT_SCHEDULED)
[1] POST /api/offers          -> 201 | offer.id=cmw3s521w009jto9i8t5d8n8o status=DRAFT
[2] POST /api/offers/:id/activate -> 200 | status=ACTIVE | DB apartment=OPTIONED
[3] POST /api/offers/:id/confirm   -> 200 | status=CONFIRMED confirmedAt=2026-11-05T16:48:28.741Z
[4] POST /api/offers/:id/convert   -> 200 | offer=CONVERTED convertedReservationId=cmw3s52b3009zto9ivlwoj1j2
                                       reservation.id=cmw3s52b3009zto9ivlwoj1j2
[5] DB truth: offer=CONVERTED link=true | reservation=ACTIVE apt=true amount=12300000 (negotiated offer
    price carried) | apartment=RESERVED | OFFER audits=4 OFFER activities=4
[6] rollback complete | leftover offers=0 apartment restored=AVAILABLE
```

Additional smoke: `GET /api/offers?status=ACTIVE` → 200 with the seeded Leila Ferhat option (amount 43 800 000, expiresAt 2026-11-11); `GET /api/offers?status=DRAFT` → `total: 1`. Zero residue after the demonstration (apartment restored, opp stage restored, marker rows deleted).

---

## 8. Files created / changed (complete inventory)

**Created:**
- `prisma/migrations/20261105180000_p1_offer_option/migration.sql`
- `src/lib/server/offer-lifecycle.ts` (the authoritative domain module)
- `src/app/api/offers/route.ts`, `src/app/api/offers/[id]/route.ts`, `.../activate/route.ts`, `.../confirm/route.ts`, `.../cancel/route.ts`, `.../convert/route.ts`
- `src/components/crm/pipeline/opportunity-offers.tsx`
- `tests/unit/offer-lifecycle.test.ts`, `tests/security/offer-concurrency.test.ts`
- `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_OFFER_OPTION_IMPLEMENTATION.md` (this file)

**Changed (owned surface):**
- `prisma/schema.prisma` (Offer model + 3 back-relations), `prisma/live-hold-indexes.sql` (+2 partial uniques), `prisma/seed.ts` (seedOffers block + summary field)
- `src/app/api/reservations/route.ts` (the ONE cross-guard — 18 lines, additive, first guard inside the tx)
- `src/lib/server/expiry.ts` (+`expireDueOffers`), `src/lib/server/expiry-scheduler.ts` (offer sweep on the same tick)
- `src/components/crm/pipeline/opportunity-detail-dialog.tsx` (mount the section — 1 import + 1 JSX block)

**Shared-file additions (additive + minimal, listed per ownership discipline):**
- `src/lib/constants.ts` — `OFFER` ActivityType + the OFFER_* block + `OFFER_STATUS_TONE` (EOF block + one list entry; nothing existing edited)
- `src/components/crm/badges.tsx` — `OfferStatusBadge` (new export beside ReservationStatusBadge)
- `src/components/crm/lead-tab-activities.tsx` — `TYPE_ICON.OFFER` + `TYPE_DOT.OFFER` (two map entries)
- `src/lib/i18n/domains/{enums,pipeline,leads,audit}.ts` — offer status / offers-section / timeline / audit-entity+action keys in ALL THREE languages (fr/en/ar)
- `src/lib/client/types.ts` — `Offer` / `OfferStatus` client types (additive)
- `src/app/api/properties/apartments/route.ts` — `orphanHolds` predicate gains `offers: { none: { status in LIVE } }` so a live OPTIONED hold is not reported as a decision-awaiting orphan (2-line additive condition)
- `tests/contract/api.test.ts` — health bookkeeping 20→21
- `src/lib/db.ts` — dev-only stale-Prisma-client self-heal guard (see deviations §9)

---

## 9. Deviations from the brief (documented)

1. **`src/lib/db.ts` dev self-heal guard** (beyond the declared surface). Rationale: the AGENTS.md P8-9 hazard — after `prisma generate` on a RUNNING dev server (the only kind here — restarts are forbidden), Node's require cache keeps serving the pre-`Offer` client and every offer route 500s with "Unknown argument". The guard detects the stale DMMF (dev only, one small file read per module evaluation) and evicts/rebuilds the singleton in place. It was necessary to run the live evidence without a restart (which the brief forbids). Listed here as a shared-file change for the Principal's arbitration; it is gated OFF in production.
2. **`OPTIONED` chip tone is orange, not amber.** The brief said "distinct chip (amber) **if a mapping exists**; do not fork a new badge system if one exists" — a mapping already existed (orange, distinct from RESERVED's amber), so it was kept as-is (no fork). Offer status chips use the new violet-family `OfferStatusBadge`.
3. **Convert re-states the reservation-create guard sequence inline** (rather than extracting a shared helper). The brief allowed either ("factor a shared helper if needed"), but extraction is explicitly Agent 3's W2-A3 ownership; duplicating the law beside the route in deliberate lockstep avoids touching `POST /api/reservations` beyond the one sanctioned guard. All 204 pre-existing tests confirm zero regression; W2-A3's plan row explicitly requires preserving this convert path and the cross-guard.
4. **Cancel authority is MANAGER+** (the brief listed cancel among actions with "reason required" without stating authority). Decision: reservation-cancel parity (`RESERVATION_LIFECYCLE.cancel.managerOnly: true`) — an administrative unit-release is a managerial decision. Documented in `OFFER_LIFECYCLE` and the UI (floor roles do not see the CTA; the server 403s regardless).
5. **PATCH authority: responsible agent OR MANAGER+** — same rule as reservations' `request_closure` (the closest analogue for editing live commercial paper).

## 10. Known limitations

- The 60 s in-process scheduler is single-instance (D-002 accepted trade-off) — a multi-instance deploy needs the documented cron/systemd end-state; the lazy sweep at `GET /api/offers`/`GET /api/reservations`/`GET /api/notifications` bounds staleness at one read.
- SQLite `DATETIME` second-truncation: expiry comparisons at sub-second boundaries round — harmless (clock law uses `<= now` for create, `< now` for sweep).
- The convert branch duplicates the reservation-create law (deliberate, see §9.3) until W2-A3 extracts the service; drift risk is flagged in both files' comments.
- Offer amount is a single negotiated price (`Float?` money house-style); no multi-line offer positions — out of P1 scope.
- `GET /api/offers` list is not projected through a role-aware DTO (offers carry no restricted financial family — amount/plan are the rep's own commercial paper; §37/§38 families live on Reservation only).
- UI: the offer list surfaces in the deal cockpit only (no standalone offers view) — the opportunity-anchored surface matches the domain; a global offers list view is a later-wave UX decision (Agent 6's view registry).

**Hand-off notes for later waves:** W2-A3 must preserve the `UNIT_OPTIONED` guard when extracting `POST /api/reservations` into a service, and fold `applyOfferAction(convert)`'s branch onto the same extracted reservation-create service. Agent 6's query-key factory should adopt `["offers"]` and the `["offers", oppId]` key used here.
