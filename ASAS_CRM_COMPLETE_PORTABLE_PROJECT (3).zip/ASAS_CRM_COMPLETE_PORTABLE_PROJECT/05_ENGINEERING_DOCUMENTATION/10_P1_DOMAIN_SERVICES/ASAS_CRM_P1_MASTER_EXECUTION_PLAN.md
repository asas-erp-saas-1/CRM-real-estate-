# ASAS CRM — P1 Master Execution Plan

**Mission:** Core Business Engineering, Domain Completion & Product Functionality Implementation (P1).
**Principal:** Principal Software Architect / Engineering Director (GLM-5.3, six specialized agents).
**Approved by:** ASAS CRM Master Engineering Blueprint (P1 scope), user directive 2026-11-05.
**Mode:** ACTUAL IMPLEMENTATION — source code, schemas, migrations, APIs, services, pages, tests.

## 1. Entry gate — P0 verification (completed 2026-11-05, before Wave 1)

| Check | Evidence | Verdict |
|---|---|---|
| P0-1…P0-7 reports | `05_ENGINEERING_DOCUMENTATION/09_P0_FOUNDATION_HARDENING/ASAS_CRM_P0_FINAL_ACCEPTANCE_REPORT.md` — all 7 VERIFIED (WAL sub-item BLOCKED by documented safety rule; remote CI NOT VERIFIED — no remote) | PASS |
| Live health | `/api/health` → `dbOk:true · migrations:20 · demoMode:true · sessionSecretConfigured:true` | PASS |
| Test baseline | 204/204 (14 files: unit + contract + security), run by Principal in R15/R16 restores | PASS |
| Git | Clean chain through `b2ecea4` (six-agent environment audit: "code innocent, environment guilty" + R13 self-heal boot guard) | PASS |
| Stack | Next.js 16 · React 19 · TS 5 · Tailwind 4 · Bun · Prisma 6 · **SQLite authoritative** (`db/custom.db`, deploy-only migration law) | CONFIRMED |
| DB safety | Snapshot `db/backups/custom-20261105-161115.db` taken before Wave 1 | DONE |

No critical P0 regression found → P1 authorized to start.

## 2. Six-agent implementation team & file ownership

| Agent | Task ID | Scope (exclusive ownership) | Wave |
|---|---|---|---|
| 1 — Offer/Option Domain & DB Architect | W1-A1 | `prisma/schema.prisma` (Offer), `prisma/migrations/*p1_offer*`, `prisma/live-hold-indexes.sql`, `prisma/seed.ts` (offer block), `src/lib/server/offer-*.ts`, `src/app/api/offers/**`, one cross-guard in `src/app/api/reservations/route.ts`, offer sweep in `src/lib/server/expiry*.ts`, opportunity/pipeline UI integration, offer tests | 1 |
| 2 — Lead Scoring & Financial Consistency | W2-A2 | `src/lib/server/scoring.ts` (new), `src/lib/server/financial-semantics.ts` (new), value/amount fix in `src/lib/server/reservation-lifecycle.ts` + `src/app/api/opportunities/[id]/route.ts` + `src/lib/constants.ts` (gate docs), lead score API surface (`src/app/api/leads/**`), scoring tests | 2 |
| 3 — Domain Service Extraction | W2-A3 | `src/lib/services/**` (new dir), refactor `src/app/api/finance/payments/route.ts`, `finance/installments/**`, `finance/overview` if needed, `src/app/api/dashboard/route.ts`, `src/app/api/reservations/route.ts` (POST→service, preserving Agent 1's cross-guard) | 2 |
| 4 — Security Test Automation & Fault Injection | W3-A4 | `tests/security/permission-matrix.test.ts` (new, data-driven), `tests/security/fault-injection.test.ts` (new), `tests/helpers/**` (new); MAY add `injectTxFault` call sites in routes it tests (1-line, coordinated) | 3 |
| 5 — Public Lead Capture & Document Security | W3-A5 | `prisma/schema.prisma` (LeadCaptureToken), migration `*p1_capture_token*`, `src/app/api/public/lead-capture/route.ts` (new), `src/lib/server/lead-capture.ts` (new), `src/lib/server/documents.ts`, `src/app/api/documents/**`, capture/doc-security tests | 3 |
| 6 — Data Recovery, UI Architecture & Forms | W4-A6 | `scripts/backup/*` + `package.json` scripts, `.gitignore`, `src/lib/client/query-keys.ts` + `query-invalidation.ts`, view registry unification, focus-token contract, RHF+Zod migration of selected dialogs, touch-target fixes, UI tests | 4 |

**Central coordination (Principal, non-delegated):** shared-file arbitration, `prisma migrate deploy` supervision, DB snapshots before each wave, full-suite verification after each wave, git commits per wave, final acceptance.

## 3. Waves & dependencies

- **Wave 1 — Domain/DB foundation (Agent 1):** Offer/Option model + migration + partial unique index + OPTIONED unit-state + lifecycle + API + UI + concurrency tests. Must land first: Agents 3 (reservation service refactor) and 6 (forms) depend on the stabilized reservation/offer surface.
- **Wave 2 — Financial/CRM correctness (Agents 2 & 3, parallel, disjoint files):** A2 fixes value/amount semantics FIRST-principle in lifecycle/gates; A3 extracts payments/installments/dashboard/reservation-create into `src/lib/services/**`. `reservations/[id]/route.ts` is owned by A2 in this wave (closure semantics); A3 does not touch it.
- **Wave 3 — Security/public ops (Agents 4 & 5, parallel):** A4 automates the permission matrix + fault injection (black-box against the live server, isolated fixtures, no silent skips); A5 ships tokenized public capture + document upload/download hardening (magic bytes, size caps, path traversal, download audit).
- **Wave 4 — Reliability/shared architecture (Agent 6):** SQLite-consistent backups (`VACUUM INTO`) + `db/docs` coordination + restore drill; unified view registry + query-key factory + focus-token contract; RHF+Zod standardization starting from `create-lead-dialog.tsx`, migrating high-value dialogs (not mechanical); touch-target corrections.

## 4. Non-negotiable engineering laws (all agents)

1. **Bun + IPv4:** `bun run test` / `bun run typecheck` / `bun run lint`; live server ONLY at `http://127.0.0.1:3000` (already running — never restart/kill it; never start a second instance).
2. **Never** `bun run build` / `next build`; **never** `git commit`/`git push` (Principal owns commits); **never** `prisma migrate dev` / `db push` on the live DB — hand-written migration folders + `bunx prisma migrate deploy` + `bunx prisma generate` (deploy-only law).
3. Partial unique indexes are raw SQL (migration + `prisma/live-hold-indexes.sql` reapply file).
4. French-first UI, Arabic RTL-safe, DZD money, org-scoped everything, RBAC per `src/lib/server/visibility.ts`.
5. Tests may not silently skip — preflight throws (see `tests/security/financial-atomicity.test.ts`); concurrency tests use unique markers, never global counts.
6. Every capability is wired to the real application and proven by tests + live evidence before status leaves IMPLEMENTED.

## 5. Status legend

NOT STARTED → IN PROGRESS → IMPLEMENTED → INTEGRATED → TESTED → VERIFIED (evidence required) · BLOCKED / DEFERRED (documented reason required).

## 6. Deliverables

1. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_MASTER_EXECUTION_PLAN.md` (this file)
2. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_OFFER_OPTION_IMPLEMENTATION.md` (Agent 1)
3. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_SCORING_AND_FINANCIAL_CONSISTENCY.md` (Agent 2)
4. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_DOMAIN_SERVICES_IMPLEMENTATION.md` (Agent 3)
5. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_SECURITY_AND_FAULT_TEST_AUTOMATION.md` (Agent 4)
6. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_PUBLIC_CAPTURE_AND_DOCUMENT_SECURITY.md` (Agent 5)
7. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_BACKUP_AND_UI_FOUNDATIONS.md` (Agent 6)
8. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_EXECUTION_LOG.md` (Principal, live)
9. `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_FINAL_ACCEPTANCE_REPORT.md` (Principal, evidence-gated)
