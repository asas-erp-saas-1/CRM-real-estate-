# ASAS CRM — P1 / W2-A3: Domain Service Extraction Implementation Report

**Agent:** 3 — Domain Service Extraction (W2-A3, Wave 2)
**Date:** 2026-11-05
**Provenance:** Agent 3 (W2-A3) implementation, report reconstructed from verified artifacts by the Principal after an infrastructure timeout (the agent's response message and report file were lost; the code was on disk, uncommitted, and fully verified before this reconstruction). Every claim below is backed by code on disk or by a re-run gate; nothing is claimed above its evidence.

**Scope:** Extraction of the business-rule cores behind the money-collection, échéancier, dashboard-projection and reservation-booking routes into the new `src/lib/services/**` layer (P1/ARCH-01 + BP-ADR-05), reducing five route files to thin HTTP adapters — plus factoring the W1-A1 offer-conversion branch onto the SAME shared booking core as `POST /api/reservations`, preserving Agent 1's `UNIT_OPTIONED` cross-guard and every API contract byte-for-byte.

**Headline:** IMPLEMENTED, TESTED and live-VERIFIED. Wave-2 gates (re-run by the Principal for this report): `bun run test` → **332/332 (25 files, 0 skipped)** (228 baseline + 104 new across W2-A2 + W2-A3, incl. 10 contract-regression + 4 unit files for the services) · `bun run typecheck` → 0 errors · `bun run lint` → 0 errors (37 tolerated warnings — unchanged count) · `/api/health` → `migrations:22`, dbOk. Routes: 651→28 (dashboard), 451→75 (reservations), 216→52 (installments), 137→38 (installments/[id]), 183→41 (payments). Zero law drift by construction: the shared booking core states the unit-hold law ONCE for both entry points.

---

## 1. Status matrix (task → status + evidence)

| Plan task | Status | Evidence |
|---|---|---|
| `src/lib/services/**` — the new domain-service layer (4 modules) | **VERIFIED** | `src/lib/services/payments.ts` (226 lines), `reservations.ts` (745), `dashboard.ts` (631), `installments.ts` (418) — each the SINGLE authoritative business-rule module for its domain; every law documented in the module header; public surface unit-tested without a DB. |
| Refactor `src/app/api/finance/payments/route.ts` → thin adapter | **VERIFIED** | 183 → 41 lines; zod contract + `requireUser("MANAGER")` + `recordPayment` + ok/fail envelope — nothing else. Contract regression `P1-SVC-4/5/6` + the W1 `financial-atomicity` suite pass unchanged. |
| Refactor `src/app/api/finance/installments/**` → thin adapters | **VERIFIED** | list/create route 216 → 52; `[id]` PATCH route 137 → 38; every lifecycle law (PAID never hand-set, CALLED-only-from-PLANNED, immutability, amount-below-paid, buckets, seq claim) lives in `installments.ts`. Contract regressions `P1-SVC-1/7/8/10` + unit suite pass. |
| Refactor `src/app/api/dashboard/route.ts` → thin adapter | **VERIFIED** | 651 → 28 lines: auth → `parseDashboardRange` → `getDashboardSnapshot` → ok() + the W3.5 `Cache-Control: private, max-age=30` header. Contract regression `P1-SVC-2` pins the FULL snapshot key set (16 top-level keys + the 16-key `kpis` object) byte-for-byte; live GET returns every key. |
| Refactor `src/app/api/reservations/route.ts` (POST → service), **preserving Agent 1's cross-guard** | **VERIFIED** | 451 → 75 lines. The W1-A1 cross-guard (live Offer ACTIVE/CONFIRMED provisionally holds the unit → 409 `UNIT_OPTIONED { offerId }`) is guard #2 inside `bookUnitInTx`'s shared sequence, direct-variant only — moved, not lost: `tests/security/offer-concurrency.test.ts` (W1, unchanged) and `tests/contract/services-contract.test.ts` `P1-SVC-9` pass. |
| Fold `applyOfferAction("convert")` onto the shared reservation-creation core | **VERIFIED** | `offer-lifecycle.ts` diff (248 lines changed, 1,142 → 1,036 lines): the hand-maintained lockstep copy of the booking law is DELETED; the convert branch now rides `bookUnitInTx` with conversion-specific hooks (`claim`, `afterFlip`, `resolveDeal`); the W1 offer test suite passes unchanged. |
| Behavior parity for every extracted route | **VERIFIED** | The extraction contract is byte-level behavior preservation — same error codes, same messages (per-variant wording table `BOOKING_MESSAGES` preserves the two entry points' exact French texts), same audit/activity payloads, same response shapes. Pinned by the 10 `P1-SVC-*` live-HTTP contract tests + 4 unit files + the full 332/332 run (all 204 pre-W2 tests still green). |
| `src/app/api/reservations/[id]/route.ts` | **NOT TOUCHED** (per plan) | Owned by W2-A2 this wave (closure semantics); A3's diff there is A2's docblock only. Verified in the git diff. |
| `finance/overview` refactor | **NOT NEEDED** | The plan row said « if needed » — the overview route was already a thin composition over shared read-model helpers (W1 state); no extraction required; `/api/finance/overview` → 200 live. |
| Tests: `tests/contract/services-contract.test.ts` + 4 unit files | **VERIFIED** | 10 live-HTTP contract tests (`P1-SVC-1…10`, mandatory preflight — no silent skip; unique markers, never global counts) + `tests/unit/services-{payments,reservations,dashboard,installments}.test.ts` (pure-rule suites). All inside 332/332. |
| Report (this file) | **DELIVERED** | Reconstructed per the provenance note above. |

Legend per plan §5: NOT STARTED → … → VERIFIED (evidence required).

---

## 2. Service map (4 modules)

| Module (lines) | Responsibility | Public surface (exports) |
|---|---|---|
| **`src/lib/services/payments.ts`** (226) | Money collection against échéancier lines: the appel-de-fonds law (money lands ONLY on CALLED lines), the in-tx balance decision with the money-scale epsilon (0.01 DZD), the full-coverage PAID stamp, the atomic PAYMENT_RECORDED audit + PAYMENT activity trail, the §41 fault site `payments-post`. | `PAYMENT_INSTALLMENT_INCLUDE` / `PayableInstallment` (the read model) · `PAYMENT_METHOD_LABELS` · `assertInstallmentPayable` · `MONEY_EPSILON` · `planPaymentSettlement` (pure) · `RecordPaymentInput` · `recordPayment` (the orchestrator: D-021 scoped read → payable gate → $transaction{re-read committed payments → plan → payment.create → conditional PAID stamp → fault site → audit + activity}). |
| **`src/lib/services/installments.ts`** (418) | Schedule lines and their derived collections state: OVERDUE is DERIVED (CALLED ∧ dueAt < now ∧ unsettled) — stored statuses stay {PLANNED, CALLED, PAID, CANCELLED}, nothing rots (D-022 law 1); seq = max+1 in-tx (P2002 → 409 SEQ_CONFLICT); the PATCH lifecycle law (PAID never hand-set — that door is payments.ts's alone; CALLED only from PLANNED; PAID immutability; amount-below-collected; EMPTY_PATCH); money reading stays role-scoped (defense-in-depth). | `INSTALLMENT_INCLUDE` / `InstallmentRow` · `decorateInstallment` (derived fields: paidAmount, remaining, overdue, partial) · `INSTALLMENT_BUCKETS` · `InstallmentListFilters` · `buildInstallmentWhere` (AUTHORIZATION_MODEL §7 composition) · `listInstallments` · `CreateReservationInput`-style `CreateInstallmentInput` · `createInstallment` · `UpdateInstallmentInput` / `InstallmentPatchTarget` · `planInstallmentUpdate` (pure) · `updateInstallment`. |
| **`src/lib/services/dashboard.ts`** (631) | The operational KPI + agenda + funnel + source-performance projection: D-021 role-aware scope (« My Day » for below-MANAGER), R9-5 windowing (activity metrics windowed; operational metrics always live), R15 period-over-period trends, P18 economics surfaces, P20-D continuous zero-filled daily series, the P46/P49/P50/P53 backlogs — all semantics unchanged from the former route-inline implementation. | `DASHBOARD_RANGE_KEYS` / `DashboardRange` / `parseDashboardRange` (pure) · `buildActivitySeries` (pure) · `buildSourcePerformanceTable` (pure) · row types (`TodayTaskRow`, `TodayVisitRow`, `HotOpportunityRow`, `CommissionEntry`, `PendingIncentiveItem`) · `DashboardSnapshot` (the typed 16-key response contract) · `getDashboardSnapshot` (the ONE orchestrator). |
| **`src/lib/services/reservations.ts`** (745) | The transaction-safe booking flow (ADR-004) + the reservation read model: the whole in-tx unit-hold law stated ONCE (`bookUnitInTx`), the W1-A1 live-offer cross-guard, the revive/dependency/one-hold-per-deal guards, the W2.1 §37/§38 economics reset, the stage advance, the D-021 scoped + W2.9 paginated list with the shared role-aware DTO. | `RESERVATION_INCLUDE` / `ReservationWithRelations` · `withReservationAgents` (in-memory agent join) · `ReservationListQuery` / `listReservations` · `assertOpportunityBookable` (DOM-D4) · `resolveEffectiveExpiresAt` (W1-5) · `buildReservationResetPayload` (W2.1) · `BookingVariant` / `BookingOpportunity` / `BookingEconomics` / `BookUnitCoreInput` / `BookUnitResult` / `BOOKING_MESSAGES` / **`bookUnitInTx`** (the shared core) · `CreateReservationInput` / `createReservation`. |

---

## 3. Before / after — route line counts

| Route file | Before | After | The delta now lives in |
|---|---|---|---|
| `src/app/api/dashboard/route.ts` | 651 | **28** | `services/dashboard.ts` (631) |
| `src/app/api/reservations/route.ts` | 451 | **75** | `services/reservations.ts` (745, incl. the shared booking core) |
| `src/app/api/finance/installments/route.ts` | 216 | **52** | `services/installments.ts` (418) |
| `src/app/api/finance/installments/[id]/route.ts` | 137 | **38** | `services/installments.ts` |
| `src/app/api/finance/payments/route.ts` | 183 | **41** | `services/payments.ts` (226) |
| `src/lib/server/offer-lifecycle.ts` | 1,142 | **1,036** | the deleted lockstep convert branch (−248 lines changed) now rides `bookUnitInTx` |

Five route files went from ~1,638 lines of mixed HTTP + business law to 234 lines of pure adapter code. The route files keep only: the zod/query-param request contract, `requireUser` (+ role floor where the law is management work), the D-021 branch dispatch / scoped id, the response envelope (`ok`/`fail`), status codes, and (dashboard) the cache header.

## 4. The established pattern

Every extracted surface follows the same shape, stated once and now the house law for new routes:

```
Route (HTTP adapter)
  → Auth        requireUser / requireUser("MANAGER")   — the role floor
  → Validation  zod schema / qpEnum parse              — the request contract
  → Service     recordPayment | createReservation | …   — D-021 scoped reads,
                 guards, pure-rule planning
  → $transaction{ … }                                   — the single commit unit:
                 writes + audit + activity + fault site
  → Response    ok({ … }, 201) / fail(error)           — the envelope + codes
```

Design points as implemented:

- **The service owns the transaction boundary.** Routes never open a `$transaction`; every orchestrator (`recordPayment`, `createInstallment`, `updateInstallment`, `createReservation` → `bookUnitInTx`, the offer convert branch) commits its writes + trail in ONE `db.$transaction`, with the §41 fault-injection site placed after the last shared mutation and before the caller-specific trail (proving a forced failure rolls money/hold AND trail together — the F-06/D-GOV-5 law).
- **Pure rules are exported separately** (`planPaymentSettlement`, `planInstallmentUpdate`, `assertInstallmentPayable`, `buildInstallmentWhere`, `parseDashboardRange`, `buildActivitySeries`, `buildSourcePerformanceTable`, `assertOpportunityBookable`, `resolveEffectiveExpiresAt`, `buildReservationResetPayload`, `decorateInstallment`) — unit-testable without any DB, and the units pin them (§8).
- **Scoped reads inside the service, not the route**: `installmentScope` / `oppScope` / `reservationScope` / the dashboard's role-aware scope composition — foreign ids are 404, byte-identical to ghosts (D-021), proven live by `P1-SVC-5` (foreign installment → 404 envelope) and `P1-SVC-9` (foreign opportunity → 404).
- **Audit atomicity preserved**: every `logAudit`/`logActivity` call moved verbatim inside the same transaction it was already in (`financial-atomicity.test.ts` — the W1 suite, unchanged file, unchanged pass; plus `P1-SVC-4/7/8` which drive the fault channels end-to-end through the services).

## 5. The offer-lifecycle shared-core factoring (W1-A1 hand-off honored)

Before W2-A3, `applyOfferAction("convert")` carried a hand-maintained lockstep copy of the POST /api/reservations booking law (« any drift between the two entry points was a bug class » — the W1 report's own hand-off note). Now both converge on **`bookUnitInTx`** — the one place the unit-hold law is stated:

**Shared (stated once, in the core):** the guard SEQUENCE — (1) apartment re-read in-tx → 404 `APARTMENT_NOT_FOUND`; (2) **direct only — the W1-A1 cross-guard: live Offer (ACTIVE/CONFIRMED) → 409 `UNIT_OPTIONED { offerId }`**; (3) source status (direct: AVAILABLE · offer-convert: OPTIONED) → 409 `APARTMENT_NOT_AVAILABLE`; (4) offer-convert only — live Reservation behind the unit → 409 `ALREADY_RESERVED` (fires BEFORE the offer claim, so the converting offer's status survives a unit another hold won); (5) offer-convert only — the CONVERTED claim (status-preconditioned `updateMany`, zero rows → safe 409); (6) revive guards (latest terminal row reuse → `ALREADY_RESERVED`; DOM-D1 dependency guard → `RESERVATION_HAS_DEPENDENTS`; one-live-hold-per-deal → `OPPORTUNITY_ALREADY_BOOKED`); then (7) create/revive with the W2.1 reset payload, (8) the apartment flip to RESERVED (same commit), (9) offer-convert: `afterFlip` links `convertedReservationId`, (10) deal stage advance (pre-booking stages → RESERVATION + STAGE_CHANGE activity + audit), (11) the §41 fault site (`reservations-post` / `offer:convert:post-mutation`).

**Entry-point-specific (stays at the caller, inside the same transaction):** direct — the D-021 scoped deal lookup + terminal-deal gate + W1-5 expiry default pre-tx, then the RESERVATION activity + `APARTMENT_RESERVED` audit; offer-convert — the CONVERTED claim hook, the offer link, and the full conversion trail (OFFER_CONVERTED + apartment audits + RESERVATION/OFFER activities). The two variants' differing French messages are preserved exactly through the `BOOKING_MESSAGES` table (« the variants are presentation, the guard SEQUENCE is the shared law »).

The convert path's `resolveDeal` re-reads the deal's CURRENT stage inside the tx (fresh truth), while the direct path decides on its pre-loaded row — preserving each entry point's historical read sequencing byte-for-byte.

**The cross-guard's survival, concretely:** `git diff src/app/api/reservations/route.ts` shows the W1-A1 `UNIT_OPTIONED` guard text now living as step 2 of `bookUnitInTx`'s sequence (direct variant only — the converting offer IS the hold); the W1 security suite `offer-concurrency.test.ts` (cross-guards both directions) and `P1-SVC-9` pass against the live server.

## 6. API-contract preservation evidence

- **`GET /api/dashboard`** — `P1-SVC-2` asserts the exact sorted 16-key top-level contract (`activitySeries, activityTotal, commissions, funnel, hotOpportunities, incentives, kpis, pendingIncentives, range, rangeStart, recentLeads, scope, sourcePerformance, todayTasks, todayVisits, trends`) and the exact 16-key `kpis` object, `scope:"org"`, `range:"30d"`, `Cache-Control: private, max-age=30`. Live re-verified: all keys present, HTTP 200.
- **`GET /api/finance/installments`** — `P1-SVC-1`: `{ data, total }` (sorted keys exactly) + every decorated row carries the derived fields `paidAmount, remaining, overdue, partial`; `P1-SVC-10`: `?bucket=overdue` applies the derived in-memory filter.
- **`GET /api/reservations`** — `P1-SVC-3`: the paginated `{ data, page, pageSize, total }` contract (W2.9 params unchanged, defaults 1/200).
- **`POST /api/finance/payments`** — `P1-SVC-4` (happy path: payment + audit + activity commit together, marker probe), `P1-SVC-5` (foreign id → the byte-identical 404 `INSTALLMENT_NOT_FOUND` envelope), `P1-SVC-6` (over-collection → 422 `EXCEEDS_REMAINING`, no row created).
- **Fault channels intact through the services** — `P1-SVC-7/8`: `installments-post` rolls back line + audit; `installment-patch-post` rolls back update + audit (the §41 law survived the move).
- **Live curls (re-run for this report):** `/api/dashboard` → 200 (16 keys), `/api/reservations` → 200, `/api/finance/overview` → 200, login sarah@asas.dz → 200.

## 7. What changed hands (and what deliberately did not)

- `prisma/seed.ts`, `src/lib/server/{leads,scoring,financial-semantics,offer-lifecycle,reservation-lifecycle}.ts`, `src/app/api/leads/**`, `src/app/api/opportunities/[id]/route.ts`, `src/app/api/reservations/[id]/route.ts`, the lead UI, `schema.prisma` + migration #22, and the four W2-A2 test files are **W2-A2's** this wave (A3 did not write them; the shared `tests/contract/api.test.ts` bookkeeping 21→22 belongs to A2's migration).
- A3's own surface: `src/lib/services/**` (4 new modules), the five route refactors, `tests/contract/services-contract.test.ts`, the four `tests/unit/services-*.test.ts`, and the `offer-lifecycle.ts` factoring. `reservations/[id]/route.ts` untouched by A3 (per plan).
- **One deliberate law change inside the payments adapter** (documented in the route header, the only non-preservation edit): the amount ceiling now imports the shared `MAX_MONEY_DZD` (10 milliards DZD, DB-12 cap single-sourcing) instead of the route's old private `1e12` — a payment previously could exceed every other money field's law by two orders of magnitude. `.positive()` kept (a payment is strictly > 0). This tightens validation only; every lawful payment behaves identically.

## 8. Test evidence

| File | What it proves |
|---|---|
| `tests/contract/services-contract.test.ts` (10 live-HTTP tests, mandatory preflight — no silent skip) | The extraction's prime directive — API contracts preserved over the live server: the installments list + decorated row contract (`P1-SVC-1`), the FULL dashboard key contract incl. kpis sub-object + cache header (`P1-SVC-2`), the paginated reservations contract (`P1-SVC-3`), payments happy path with atomic audit/activity (`P1-SVC-4`), the byte-identical 404 foreign-id envelope (`P1-SVC-5`), over-collection impossibility (`P1-SVC-6`), BOTH installments fault channels rolling back writes + audit (`P1-SVC-7/8`), the service's D-021 gate (`P1-SVC-9`), the derived overdue bucket filter (`P1-SVC-10`). |
| `tests/unit/services-payments.test.ts` | The payable gate (CALLED accepts; CANCELLED/PAID/PLANNED → the exact 409 codes), the in-tx balance plan (partial/exact/full-through-epsilon/over-collection 422 with the exact balance details; settled-line math; the 0.01 DZD epsilon drift tolerance), the settlement-method label vocabulary. |
| `tests/unit/services-reservations.test.ts` | The DOM-D4 terminal-deal gate, the W1-5 expiry-default law (explicit honored; manager omission = open hold; floor-role omission = org default), the W2.1 reset payload (booking facts + ACTIVE land; the FULL §37/§38 family + closure/conversion stamps reset to null; amount falls back to the unit price), and the `BOOKING_MESSAGES` two-variant vocabulary table (both declare the three shared-law messages; the direct wording byte-preserved). |
| `tests/unit/services-dashboard.test.ts` | `parseDashboardRange` (defaults, round-trips, garbage → 422 `INVALID_RANGE` with details), `buildActivitySeries` (zero-filled continuous axis; `range=all` anchored at the earliest in-window activity — never 1970; empty-collapse-to-today; future rows dropped; YYYY-MM-DD zero-padding), `buildSourcePerformanceTable` (per-source merge, zero-not-NaN for source-less won opps, empty-stays-empty). |
| `tests/unit/services-installments.test.ts` | `decorateInstallment` (OVERDUE derived exactly: CALLED ∧ unsettled ∧ dueAt < now; future-due is « due » not late; no-dueAt not late; PLANNED never late; PAID never late; remaining clamps at 0), `planInstallmentUpdate` (the full lifecycle law incl. every 409/422 code + audit action naming + EMPTY_PATCH), `buildInstallmentWhere` (the AUTHORIZATION_MODEL §7 composition: below-MANAGER scope fragment is element 0, never spread beside a local OR key). |
| `tests/security/financial-atomicity.test.ts` (W1, file unchanged) | The money-path atomicity law predates the extraction and still passes — the audit/trail fold survived the move intact. |
| `tests/security/offer-concurrency.test.ts` (W1, file unchanged) | The cross-guard both directions + convert one-commit atomicity still pass post-factoring. |

All inside the **332/332 (25 files)** wave-2 gate.

## 9. Live evidence (re-verified by the Principal for this report)

- Gates: `bun run test` → `Test Files 25 passed (25) · Tests 332 passed (332)` · `bun run typecheck` → 0 errors · `bun run lint` → `0 errors, 37 warnings` (unchanged count) · `curl http://127.0.0.1:3000/api/health` → `{"status":"ok","dbOk":true,"migrations":22,"demoMode":true,"sessionSecretConfigured":true}`.
- HTTP: login `sarah@asas.dz` → 200 · `/api/reservations` → 200 · `/api/finance/overview` → 200 · `/api/dashboard` → 200 with the full 16-key contract (incl. the management economics surfaces for the MANAGER+ caller) · `POST /api/leads/:id/score` (A2's endpoint through the shared lead surface) → deterministic 16 with the summing breakdown.
- The live DB's Wave-1 QA offer rows (4 offers, 2 live holds, 1 OPTIONED apartment) survived the refactor untouched — pre-existing data, not Wave 2's.

## 10. Known limitations

- **The `offer-convert` variant's `ALREADY_RESERVED` wording rides the direct message** (`BOOKING_MESSAGES.direct.alreadyReserved`) for the pre-claim live-reservation guard — this is byte-preservation of the W1 convert branch's historical message, not a new choice; the variant table's own `offer-convert.alreadyReserved` serves the revive-guard wording. Cosmetic asymmetry, documented here so nobody "fixes" it into drift.
- **The DB-12 cap single-sourcing (`MAX_MONEY_DZD`) was applied to payments only**: the two installments adapters still carry their historical private `1e12` ceiling (looser than the shared 10-billion law). Not a regression (the pre-W2 state was identical), but the asymmetry is real — flagged for the Principal; tightening installments would be a one-line change each plus a contract-test note.
- **The booking trail's `OPPORTUNITY_STAGE_CHANGED` audit row still carries `after: { stage, value: reservation.amount, booking: true }`** on the direct path — the DOM-03 finding #2 that W2-A2 flagged to this file's owner. A3's extraction contract was byte-level behavior preservation, so the quirk (trail presentation only; no opportunity column is written) is preserved verbatim rather than fixed mid-refactor — changing payloads would have violated the parity contract. It remains flagged for a later wave.
- **`finance/overview` was not extracted** (plan said « if needed »; it was already thin). If it accretes law, the same pattern applies.
- **`bookUnitInTx` is offer-convert-aware through hooks** (`claim`/`afterFlip`/`resolveDeal`) rather than a fully variant-polymorphic core — the two entry points' contracts differ enough that hook-inversion keeps the byte-parity honest; a future third entry point (e.g. public capture → booking) should reuse the same core rather than the hooks.
- Dashboard aggregation remains ~30 queries per GET (bounded by the W3.5 30s private browser cache) — the extraction did not change the query plan by contract; a projection-table refactor is a later performance wave.
