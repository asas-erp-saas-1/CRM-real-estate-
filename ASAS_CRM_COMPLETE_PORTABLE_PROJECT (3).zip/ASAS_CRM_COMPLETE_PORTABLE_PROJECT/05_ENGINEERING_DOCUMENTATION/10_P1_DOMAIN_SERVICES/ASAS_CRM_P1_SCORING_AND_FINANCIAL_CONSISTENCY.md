# ASAS CRM — P1 / W2-A2: Lead Scoring & Financial Consistency Implementation Report

**Agent:** 2 — Lead Scoring & Financial Consistency (W2-A2, Wave 2)
**Date:** 2026-11-05
**Provenance:** Agent 2 (W2-A2) implementation; this report was reconstructed from the verified on-disk artifacts (git diff vs HEAD `3a852eb`, live HTTP evidence, passing gates) by the Principal after an infrastructure timeout lost the agent's original response and report file. Every claim below is backed by code on disk or by a re-run gate; nothing is claimed above its evidence.

**Scope:** The deterministic, explainable lead score (0–100) end to end — engine, cache schema/migration, recalculation triggers across the lead API surface, on-demand recalc endpoint, UI badge + « Pourquoi ce score ? » card, seed refresh — plus the DOM-03 value/amount financial-consistency fix (the concept separation + the one sanctioned CLOSED_WON alignment), with the teaching retirement of the manual score write path.

**Headline:** IMPLEMENTED, TESTED and live-VERIFIED. Wave-2 gates (re-run by the Principal for this report): `bun run test` → **332/332 (25 files, 0 skipped)** (228 baseline + 104 new across W2-A2 + W2-A3) · `bun run typecheck` → 0 errors · `bun run lint` → 0 errors (37 tolerated warnings — unchanged count) · `/api/health` → `dbOk:true · migrations:22` · live POST `/api/leads/:id/score` on lead « Réda Mokrani » → **score 16**, breakdown summing exactly to 16 (budget 12/12, preferences 4/10, all other signals 0).

---

## 1. Status matrix (task → status + evidence)

| Plan task | Status | Evidence |
|---|---|---|
| `src/lib/server/scoring.ts` — the single authoritative, deterministic, rule-based score engine (NOT AI: an opaque model is unverifiable; an agency needs a number it can argue with, signal by signal) | **VERIFIED** | On disk, 552 lines; pure function `computeLeadScore(facts, now)` — no DB, no clock, no randomness (`now` injected); pinned by `tests/unit/scoring.test.ts` (34 tests: maxima sum to 100, full-credit lead = 100, empty lead = 0, breakdown always sums to score, byte-identical determinism, clamps). |
| `src/lib/server/financial-semantics.ts` — the centralized home of every value/amount comparison rule (DOM-03 fix) | **VERIFIED** | On disk, 202 lines; concept table + pure accessors (`agreedAmount` / `expectedValue` / `closureValueConsistency`) + `findClosurePriceSource` + the ONE sanctioned alignment `alignWonDealValue`; pinned by `tests/unit/financial-semantics.test.ts` (7 pure tests). |
| Migration `prisma/migrations/20261105190000_p1_lead_score/migration.sql` (#22) | **VERIFIED** | Two additive nullable columns (`scoreComputedAt DATETIME`, `scoreBreakdown TEXT`); the historical `score INTEGER NOT NULL DEFAULT 0` column is untouched (no table rebuild on the live shared DB); health reports `migrations:22`; `tests/contract/api.test.ts` bookkeeping updated 21→22. |
| Lead cache columns in `prisma/schema.prisma` (+ concept-separation law block) | **VERIFIED** | `git diff prisma/schema.prisma` — `score` re-documented as the computed cache, + `scoreComputedAt DateTime?` + `scoreBreakdown String?` with the full law block (single-writer, transparency law: the number is never shown without its derivation). |
| Recalculation triggers wired through the single writer (`refreshLeadScore` in `src/lib/server/leads.ts`) | **VERIFIED** | POST create (in-tx), PATCH edit (in-tx), POST requirements (in-tx — the qualification act), POST `/score` (on demand), GET detail (lazy when stale); proven live by `tests/security/lead-score.test.ts` TESTS 1–6. |
| `POST /api/leads/:id/score` — the explicit recalculation endpoint | **VERIFIED** | `src/app/api/leads/[id]/score/route.ts` (47 lines); D-021 scoped (foreign lead = 404 byte-identical), no role floor (the score is a read-derived cache; every writer is the same engine); live: Réda Mokrani → 16 + full breakdown + `version:1`. |
| UI: list Score cell + drawer « Pourquoi ce score ? » card + i18n (fr/en/ar) | **VERIFIED** | `score-badge.tsx` (132 lines — the ONE presentation vocabulary: 5-band tones, signal label keys, tooltip builder); `lead-row.tsx` score cell (P8 meter idiom, band-colored fill, full derivation in the native tooltip, honest em-dash for never-computed rows); `lead-tab-overview.tsx` `LeadScoreCard` (expandable per-signal rows + « Recalculer » wired to POST /score); i18n keys ×3 languages (22 keys × fr/en/ar in `leads.ts`). Browser evidence: leads view shows a « Score » column with progressbar + value 16; screenshot `/tmp/p1-wave2-score-ui.png`. |
| DOM-03 fix — validate_closure aligns the WON card's value with the agreed price | **VERIFIED** | `git diff src/lib/server/reservation-lifecycle.ts` — `alignWonDealValue(tx, { agreed: agreedAmount(reservation), … })` inside the closure transaction, after the status-preconditioned claim; proven live by `tests/security/closure-value-consistency.test.ts` TEST 1 (same-tx + audited). |
| DOM-03 fix — manager correction path into CLOSED_WON applies the same law | **VERIFIED** | `git diff src/app/api/opportunities/[id]/route.ts` — `findClosurePriceSource` + `alignWonDealValue` when the PATCH carries no explicit `value` (an explicit manager-typed value WINS, alignment skipped); proven live by closure tests TESTS 2–3. |
| Manual score write path retired (teaching 422) | **VERIFIED** | PATCH `/api/leads/:id` answers `422 SCORE_IS_COMPUTED` (the historical copilot « Appliquer le score » / bulk-apply path); schema entry kept in the zod contract ONLY so a client still sending it gets the teaching error, not a silent strip; proven live by lead-score test TEST 3. |
| Seed refresh of every seeded lead's cache through the engine | **VERIFIED** | `git diff prisma/seed.ts` — `seedLeadScores()` (three org-wide batched queries, no N+1) recomputes every lead through `computeLeadScore`; static legacy `score:` demo numbers overwritten by the same rules the routes apply (one truth). |
| Scoring tests (4 files) | **VERIFIED** | `tests/unit/scoring.test.ts` (34), `tests/unit/financial-semantics.test.ts` (7), `tests/security/lead-score.test.ts` (6 live-HTTP), `tests/security/closure-value-consistency.test.ts` (4 live-HTTP) — all inside the 332/332 run. |
| Report (this file) | **DELIVERED** | Reconstructed per the provenance note above. |

Legend per plan §5: NOT STARTED → … → VERIFIED (evidence required).

---

## 2. The scoring contract (8 signals · 100 points · every weight justified)

`computeLeadScore(facts, now)` returns `{ score, breakdown[], version }`; every breakdown row is `{ signal, points, max, reason }` with a short French reason sentence (house precedent: activity/audit titles are French-only; signal LABELS are i18n'd client-side via `leads.score.signal.<id>`).

| # | Signal (id) | Max | Ladder as written in code | Why it weighs that much |
|---|---|---|---|---|
| 1 | `qualification` | 15 | Requirement row 8 · payment method 3 · purpose 4 | A lead whose needs are structured is MATCHABLE (the whole matching engine — PropertyMatch — keys off the Requirement row); payment + purpose are the financing/intent axes of the QUALIFIED stage's own triad (opportunity-gates.ts). |
| 2 | `budget` | 12 | any bound known 6 · full min–max range +6 | Budget is the #1 real-world disqualifier (the seed's own lost-deal taxonomy « Budget insuffisant ») and 35% of the matching engine's weight; a lead without a budget is a conversation, not a pipeline entry. |
| 3 | `timeframe` | 10 | IMMEDIATE 10 · ≤3M 8 · ≤6M 6 · ≤12M 3 · unknown 0 | Demand urgency — the ladder the sales team already triages by; an immediate buyer is worked now, a 12-month buyer is a nurture list. |
| 4 | `engagement` | 18 | last team activity ≤7d 10 / ≤14d 7 / ≤30d 4 / older-or-none 0 · +5 at ≥3 activities · +3 at ≥10 | The relationship's recency AND depth; mirrors the rotting ladder's 7/14d thresholds (lead-row.tsx) so ONE notion of « recent » exists across surfaces. Only the five §12.4 outcome-bearing contact channels + manual NOTE + VISIT rows count — pure system rows (LEAD_CREATED, STATUS_CHANGE, STAGE_CHANGE, RESERVATION, CONVERSION, TAG…) are bookkeeping and never inflate the score. |
| 5 | `response` | 10 | lastContactAt ≤7d 6 / ≤14d 4 / ≤30d 2 / never 0 · +4 when the latest outcome-bearing contact activity is positive | The customer's side of the conversation, not ours. Positive = INTERESTED / QUALIFIED / CALLBACK_REQUESTED / NEEDS_MORE_INFO (§12.4 vocabulary). |
| 6 | `visit` | 15 | ≥1 COMPLETED visit 8 · best interest VERY_INTERESTED +5 / INTERESTED +3 (else +0) · a visit linked to an opportunity +2 | The strongest pre-deal buying signal in this domain — the closure gate itself refuses a WON without one. |
| 7 | `followUp` | 10 | next follow-up in the future 6 / overdue 2 / none 0 · +4 with ≥1 OPEN task | The PIPE-01 law's mirror: « an open deal without a next activity rots » — a rotting relationship scores lower. |
| 8 | `preferences` | 10 | propertyType 2 · location 2 · any structured surface/floor/bedrooms preference 2 · ≥1 property match 2 · best match ACCEPTED +2 | Enriched preferences make the matching engine useful; recorded matches mean inventory interest has begun. |

**Sum of maxima = 100 exactly** (unit-pinned). Determinism: same facts + same clock ⇒ byte-identical result (unit-pinned). Clamps: partial points can never escape a signal's max; the total clamps to [0,100].

**The 5-band scale** (shared client/server vocabulary law — `LEAD_SCORE_BANDS` / `leadScoreBand` in `src/lib/constants.ts`): `excellent 80–100 · good 60–79 · medium 40–59 · weak 20–39 · cold 0–19` — contiguous, no gap, no overlap (unit-pinned). The hues ride the temperature trio's palette (emerald/teal/amber/rose/muted) so « hot » reads the same everywhere — but the bands are their OWN concept, not the copilot's temperature.

**Engine version:** `LEAD_SCORE_VERSION = 1` — stamped on every result and persisted with the cache; increments on any signal-set/weight change so stale pre-version caches can be told apart.

---

## 3. The concept-separation contract (W2-A2 deliverable #4)

The CRM carries FIVE distinct lead/deal concepts that were quietly drifting into each other. They are NOT the same thing and never merge:

| Concept | Field(s) | Nature | Who writes it |
|---|---|---|---|
| **Lead STATUS** | `Lead.status` (NEW…CONVERTED/CLOSED_LOST/REACTIVATED) | workflow stage (where in the funnel) | humans, via the transitions matrix (PATCH /convert / bulk) |
| **Lead PRIORITY** | `Lead.priority` (LOW…URGENT) | human URGENCY judgment | humans — a manager's call, deliberately **NOT a score input**: a HIGH-priority lead with no data must still score LOW (the badge then says « données incomplètes »); `priority` is carried in the facts for CONSUMERS (journey), not the engine (unit-pinned: LOW and URGENT score identically) |
| **QUALIFICATION** | budget/needs/preferences fields + the Requirement row | DATA-COMPLETENESS facts (quality flags) | humans typing facts; the score READS them as inputs; also the QUALIFIED status's meaning |
| **Lead SCORE** | `Lead.score` + `scoreBreakdown` + `scoreComputedAt` (the cache) | deterministic computed number | the ENGINE (scoring.ts) — the only writer; explains itself |
| **Opportunity STAGE** | `Opportunity.stage` (NEW…CLOSED_WON/LOST) | deal pipeline position | stage moves + lifecycle coupling (validate_closure etc.) |

Adjacent vocabularies audited and KEPT as their own concepts (no field overwritten by this work):

- Copilot « temperature » (HOT/WARM/COLD, Activity.COPILOT payload) — an AI advisory snapshot on the timeline; NOT persisted on the lead, NOT the score; its « suggestedScore » is advice only — the « apply score » write path is RETIRED (PATCH answers 422 `SCORE_IS_COMPUTED`).
- `PropertyMatch.score` — the requirement↔apartment FIT percentage (matching.ts). Same 0–100 scale, a completely different question (« does this unit fit this need », not « how hot is this lead »).
- `Opportunity.probability` — the DEAL's forecast, human/lifecycle-set.
- `Lead.priority` — see the table above.

Visual identity law (UI): the score is NOT a status and NOT a priority — it renders as a numeric chip with a Gauge glyph + « /100 » + the band word, and the list cell keeps the P8 progress-meter idiom (band-colored fill): one glance separates *where the lead is* (status), *how urgent we judge it* (priority, human) and *how strong the recorded facts are* (score, computed).

---

## 4. The recalculation trigger matrix + staleness

Every cache write goes through `refreshLeadScore` (leads.ts) — the single writer — **inside the caller's transaction**:

| Event | Recompute |
|---|---|
| `POST /api/leads` (create) | in-tx initial compute (a brand-new lead scores low — the honest number; the cache is born fresh) |
| `PATCH /api/leads/:id` (any edit) | in-tx recompute — the fresh budget/status/follow-up this request wrote feeds the engine through the same tx; a mid-tx fault rolls the edit AND the cache back together |
| `POST /api/leads/:id/requirements` (upsert) | in-tx recompute — the qualification act (47 of 100 points change here) |
| `POST /api/leads/:id/score` (explicit) | recompute on demand — its own transaction (facts load → engine → three-column write, all-or-nothing) |
| `GET /api/leads/:id` (detail) | LAZY recompute when STALE (the expiry-sweeper precedent for writes-on-GET: idempotent, bounded to this one row; the aggregate already carries every staleness signal — zero extra reads). The LIST stays read-only (25 rows × engine loads would be abuse); the drawer recomputes on open so every surface converges through the same single writer. |
| visit/task/activity/opportunity mutations (routes owned by other agents) | none this wave — the cache goes STALE, refreshed by the next row above |

**STALE** (`isScoreStale`, the single predicate — nobody re-derives staleness locally): `scoreComputedAt` IS NULL (never computed — legacy/seed rows before the engine) OR any relevant event STRICTLY newer than the cache stamp — latest activity `occurredAt`, latest visit `updatedAt`, lead `updatedAt`. Fail-safe: an unparseable stamp is stale.

**No audit/activity trail rows for score refreshes:** a score is a DERIVATION (like `updatedAt`), not a business event — its provenance IS `scoreComputedAt` + `scoreBreakdown`. Trail spam would drown real events.

**Facts loading (`loadLeadScoreFacts`):** ONE bounded projection query — the lead's signal columns + the 1:1 requirement with its matches + the latest 30 activities (recency from the head; ≥10 counts « deep history » within a bounded window) + the last 50 visits' status/interest/link + the OPEN task count. No N+1; cheap enough inside any lead transaction.

**Breakdown (de)serialization:** `serializeScoreBreakdown` writes stable key order; `parseScoreBreakdown` is tolerant of null/garbage/shape-drift (legacy rows) — an unparseable breakdown must never break a lead response, and zero valid rows is treated as absent. The raw JSON string never crosses the server boundary (`toLeadDTO` parses it into the typed array).

---

## 5. DOM-03 — diagnosis and fix design

### 5.1 What was actually wrong

1. **`validate_closure` flipped opportunities to CLOSED_WON (probability 100) while leaving `value` as the STALE pre-deal estimate — or null.** Live-closed won deals therefore contributed wrong/zero value to every won-value KPI (dashboard `wonValue`, analytics bySource), diverging from the seed's own convention (every seeded won deal carries `value == amount == price` — and every won-value KPI reads `Opportunity.value`).
2. **The booking-coupled `OPPORTUNITY_STAGE_CHANGED` audit row in POST /api/reservations wrote `after: { …, value: created.amount }`** — presenting the reservation's agreed price as the opportunity's value IN THE TRAIL while the column itself was never written. This file is owned this wave by W2-A3 (A2 does not write it); the trail-shape quirk was flagged to the route's owner and is preserved verbatim under A3's byte-preservation contract (see §10 — it remains a known limitation, NOT a Wave-2 regression).

### 5.2 The concept table (financial-semantics.ts header, faithfully summarized)

| Concept | Field | Meaning & authoritative for |
|---|---|---|
| **Pipeline ESTIMATE** | `Opportunity.value` | Pre-deal DZD estimate. Feeding pipeline analytics (dashboard wonValue, leads-with stats, analytics bySource). Human/lifecycle-set; NOT the contract. |
| **AGREED PRICE** | `Reservation.amount` | The agreed contractual price of the hold (defaults to the apartment price at booking — POST /api/reservations). The truth for the money path. |
| **Deal ECONOMICS** | Reservation `commission*` + `agentIncentive` family | §37/§38 — the agency's own margin, NEVER the deal price (P18/P29 laws in the schema). |

These are DIFFERENT concepts: an estimate and a contract price are allowed to differ while the deal is open — that gap is commercial reality (the negotiated price vs the pipeline's working number), NOT an inconsistency. There is deliberately **NO silent synchronization** between them at any stage.

### 5.3 The ONE sanctioned alignment

At the moment the deal becomes **CLOSED_WON**, a won deal's « estimate » is no longer an estimate — the agreed price is the only honest number for a closed card (seed convention + every won-value KPI reads `Opportunity.value`). The alignment is **EXPLICIT**:

- same transaction as the closure event;
- one dedicated audit row: `OPPORTUNITY_VALUE_CHANGED` (pre-existing action, pre-existing i18n — the key had been missing and is now mandatory in all three languages, `audit.action.OPPORTUNITY_VALUE_CHANGED` fr/en/ar);
- never a hidden side write.

**`alignWonDealValue(tx, params)`** runs inside the caller's closure transaction, re-reads the live value in-tx (no TOCTOU), writes ONLY when there is something to write (agreed price known AND different from the current value), carries before/after + the alignment reason + the source reservation in the audit row, and NEVER throws on consistency — it enforces it. Cross-org ids no-op (the caller's scoped lookups own the 404 discipline).

**`findClosurePriceSource(tx, orgId, opportunityId)`** — the deterministic preference order for which reservation's price is authoritative: (1) CONVERTED — an already-validated sale (the manager correction path); (2) a LIVE hold (ACTIVE / CLOSURE_REQUESTED) — the two-step closure's own row; (3) null — no sale-backing row, the estimate stands. Terminal dead holds (CANCELLED / EXPIRED) are deliberately NOT price sources: a cancelled price is not the deal's truth.

### 5.4 Where the fix lands

- **The canonical money path** — `reservation-lifecycle.ts` `validate_closure`: after the status-preconditioned claim flips the hold CONVERTED + the opportunity CLOSED_WON (probability 100), `alignWonDealValue` runs in the SAME transaction with `agreed = agreedAmount(reservation)` and its own audit row. Runs after the claim, so 409-retry/concurrent paths never re-align.
- **The manager correction path** — `opportunities/[id]/route.ts` PATCH into CLOSED_WON (after the closure visit gate): the SAME law via `findClosurePriceSource` + `alignWonDealValue`. An explicit `value` in the SAME request WINS — the manager typed that number deliberately, and the alignment is skipped for it. No-op when the amounts already agree or no price source exists.
- The pure verdict `closureValueConsistency(opportunity, reservation)` returns `{ estimate, agreed, consistent, gap, alignedValue }` and is the unit-tested definition of « needs alignment » (a null estimate with a known agreed price is inconsistent — the DOM-03 live-closure case; no reservation / no agreed price ⇒ legitimately consistent — NO forced sync while the deal is open).

---

## 6. The cache data model (migration #22)

`prisma/migrations/20261105190000_p1_lead_score/migration.sql` — additive, nullable, no data change:

```sql
ALTER TABLE "Lead" ADD COLUMN "scoreComputedAt" DATETIME;   -- NULL = never computed (legacy rows)
ALTER TABLE "Lead" ADD COLUMN "scoreBreakdown" TEXT;        -- JSON [{signal, points, max, reason}, …]
```

The `score` column itself is UNTOUCHED (historical `INTEGER NOT NULL DEFAULT 0`) — SQLite cannot ALTER nullability without the full table-rebuild dance, and rebuilding the central Lead table on the live, shared dev DB (a parallel agent writes to it) is an avoidable blast radius. « Never computed » is carried by `scoreComputedAt IS NULL`, NOT by a null score (0 is a legitimate computed value — a fresh empty lead). The migration backfills nobody: every existing row starts never-computed and is refreshed through the engine on its next touch (drawer open, edit, or explicit POST /score).

---

## 7. API + UI surfaces

- **`POST /api/leads/:id/score`** — D-021 scoped (foreign lead = 404 byte-identical to a missing one — the PATCH parity rule); no role floor on purpose (read-derived cache, single writer); responds `{ score, breakdown, version, scoreComputedAt }`; no trail rows.
- **PATCH `/api/leads/:id`** — `score` in the request body answers the teaching `422 SCORE_IS_COMPUTED` (« Le score d'un prospect est calculé automatiquement… »); every other edit recomputes the cache in-tx.
- **GET `/api/leads/:id`** — serves the parsed breakdown array (never a raw JSON string); lazily refreshes when stale.
- **List cell (`lead-row.tsx`)** — P8 meter (h-1.5, band-colored fill) + tabular number + the FULL per-signal derivation in the native tooltip; `scoreComputedAt == null` renders the honest em-dash instead of a fabricated 0.
- **Drawer card (`LeadScoreCard` in `lead-tab-overview.tsx`)** — the 5-band `LeadScoreBadge` chip + expandable « Pourquoi ce score ? » rows (label i18n'd, engine's French reason verbatim, per-signal progress) + the « Recalculer » button wired to POST /score (invalidates `["lead", id]` + `["leads"]`). The score is NEVER editable in the UI.
- **i18n** — 22 new keys × fr/en/ar (`leads.score.*`: why / notComputed / recompute / recomputing / recomputed / aria / 5 band words / 8 signal labels + unknown fallback) + `audit.action.OPPORTUNITY_VALUE_CHANGED` ×3.

---

## 8. Files changed (A2 surface)

**New:** `src/lib/server/scoring.ts` · `src/lib/server/financial-semantics.ts` · `prisma/migrations/20261105190000_p1_lead_score/migration.sql` · `src/app/api/leads/[id]/score/route.ts` · `src/components/crm/views/leads/score-badge.tsx` · `tests/unit/scoring.test.ts` · `tests/unit/financial-semantics.test.ts` · `tests/security/lead-score.test.ts` · `tests/security/closure-value-consistency.test.ts`.

**Modified (owned surface):** `prisma/schema.prisma` (Lead cache columns + law block) · `prisma/seed.ts` (`seedLeadScores` block + summary field) · `src/app/api/leads/route.ts` (POST in-tx initial compute) · `src/app/api/leads/[id]/route.ts` (GET lazy refresh + PATCH 422 + in-tx recompute) · `src/app/api/leads/[id]/requirements/route.ts` (in-tx recompute) · `src/app/api/opportunities/[id]/route.ts` (DOM-03 correction-path alignment) · `src/lib/server/reservation-lifecycle.ts` (DOM-03 validate_closure alignment) · `src/app/api/reservations/[id]/route.ts` (docblock: the value/amount semantics this route serves are owned by financial-semantics.ts — comment only, A2's owned file this wave) · `src/lib/server/leads.ts` (the score hooks: `loadLeadScoreFacts` / `refreshLeadScore` / `LeadDTO` with parsed breakdown) · `src/lib/constants.ts` (`LEAD_SCORE_BANDS` + `leadScoreBand`) · `src/lib/client/types.ts` (`LeadScoreSignal` + cache fields) · `src/lib/i18n/domains/leads.ts` + `audit.ts` (i18n ×3) · `src/components/crm/lead-tab-overview.tsx` (LeadScoreCard) · `src/components/crm/views/leads/lead-row.tsx` (score cell) · `tests/contract/api.test.ts` (health bookkeeping 21→22 — A2's migration #22).

---

## 9. Test evidence

| File | What it proves |
|---|---|
| `tests/unit/scoring.test.ts` (34 tests, pure — no DB, no server, injected clock) | The CONTRACT: 8 maxima sum to exactly 100; full-credit lead = 100, empty lead = 0; **breakdown always sums to score** (the explainability invariant); byte-identical determinism; clamps. Concept separation: `priority` and `status` are NOT inputs (LOW/URGENT and NEW/QUALIFIED score identically). Every signal ladder pinned exactly (qualification 8+3+4, budget 6+6, timeframe 10/8/6/3/0, engagement 10/7/4/0 + 5 + 3, response 6/4/2/0 + 4, visit 8 + 5/3 + 2, followUp 6/2/0 + 4, preferences 2×4 + 2). Band scale: 5 contiguous bands, no gap/overlap, documented boundaries, clamps. Staleness predicate: never-computed always stale; strictly-newer event stale, equal/older not; each of the three sources alone; updatedAt fallback; Date objects tolerated, garbage stamps fail safe. Serialization round-trips byte-exactly; parse tolerates null/garbage/shape-drift. |
| `tests/unit/financial-semantics.test.ts` (7 pure tests) | The typed accessors read exactly the right fields (null stays null); the closure verdict: equal ⇒ consistent; differing agreed price ⇒ inconsistent with gap + `alignedValue = agreed` (the won card's honest number); **null estimate + known agreed price ⇒ inconsistent (the DOM-03 live-closure case: a won deal contributing 0 to won-value KPIs)**; no reservation ⇒ legitimately consistent (NO forced sync while open); no agreed price ⇒ consistent; both null ⇒ consistent. |
| `tests/security/lead-score.test.ts` (6 live-HTTP tests, mandatory preflight — no silent skip; unique `P1-SCORE-A2-*` markers, never global counts) | The trigger matrix END-TO-END over the live server: TEST 1 create computes in-tx with breakdown; TEST 2 PATCH recomputes (follow-up scheduled → +6); TEST 3 the retired manual path answers 422 `SCORE_IS_COMPUTED`; TEST 4 the qualification act lands qualification 15 + timeframe 10; TEST 5 POST /score recalculates on demand and returns the same deterministic number; TEST 6 GET serves the parsed breakdown array (never a raw JSON string). |
| `tests/security/closure-value-consistency.test.ts` (4 live-HTTP tests; completed-visit gate satisfied via `createCompletedVisit`) | The DOM-03 fix END-TO-END: TEST 1 validate_closure aligns the WON card's value with the agreed price (same tx, audited); TEST 2 the manager correction path into CLOSED_WON aligns from the live hold's agreed price; TEST 3 an explicit `value` in the closure PATCH WINS over the alignment (no audit row). |

All inside the **332/332 (25 files)** wave-2 gate. The pre-existing `tests/security/financial-atomicity.test.ts` (W1) still passes unchanged inside the same run.

---

## 10. Live evidence (re-verified by the Principal for this report)

- `bun run test` → `Test Files 25 passed (25) · Tests 332 passed (332) · Duration 10.22s`; `bun run typecheck` → `tsc --noEmit`, 0 errors; `bun run lint` → `0 errors, 37 warnings` (unchanged count); `curl /api/health` → `{"status":"ok","dbOk":true,"migrations":22,"demoMode":true,"sessionSecretConfigured":true}`.
- Login `sarah@asas.dz` → 200. `POST /api/leads/cmw3q2fzo…/score` (lead **« Réda Mokrani »**) → **`score: 16`, `version: 1`**, breakdown: `qualification 0/15 · budget 12/12 (fourchette budgétaire définie 13 000 000 – 16 500 000 DA) · timeframe 0/10 · engagement 0/18 · response 0/10 · visit 0/15 · followUp 0/10 · preferences 4/10` — the 8 rows sum to exactly 16.
- `/api/dashboard` → 200 with every contract key present (`scope, range, rangeStart, kpis, trends, recentLeads, todayTasks, todayVisits, hotOpportunities, funnel, sourcePerformance` + the role-dependent `activitySeries`/`activityTotal` and the P18 economics surfaces `incentives`/`commissions`/`pendingIncentives` — MANAGER+ caller). `/api/reservations` → 200. `/api/finance/overview` → 200.
- Browser evidence: the leads view shows a « Score » column; the lead row renders a score cell with progressbar + value « 16 »; screenshot `/tmp/p1-wave2-score-ui.png` (151,927 bytes, 2026-11-05 17:38).
- The live DB still carries the Wave-1 QA offer on the « Nesrine K. » (Nesrine Kaci) opportunity — 4 offers total, 2 live holds (ACTIVE on H-12 / ACTIVE unit-less), 1 OPTIONED apartment — pre-existing Wave-1 data, untouched by Wave 2.

---

## 11. Deviations from the brief (documented)

1. **The manual score write path was RETIRED, not merely de-documented.** PATCH keeps `score` in the zod contract solely so a client still sending it receives the teaching 422 `SCORE_IS_COMPUTED` (a silent strip would look like success while writing nothing). The copilot's « apply score » write path is the collateral casualty — deliberately, per the single-writer law.
2. **Migration #22 is deliberately two additive columns, not a score-column rebuild.** SQLite table-rebuild on the live shared DB is an avoidable blast radius; « never computed » is carried by `scoreComputedAt IS NULL` instead (documented in the migration header and the schema law block).
3. **GET detail lazily recomputes (a write-on-GET).** The expiry-sweeper precedent makes this house-legal; it is idempotent and bounded to the one row. The LIST stays read-only.
4. **The `OPPORTUNITY_VALUE_CHANGED` audit action was pre-existing without an i18n key** (titleCase fallback); the DOM-03 path now writes it at closure too, so the fr/en/ar keys were added (AGENTS.md law 6).

## 12. Known limitations

- **Recalculation on visit/task/activity mutations is deferred**: those routes are owned by other agents; the cache goes stale on such events and self-heals on the next lead touch (detail open, edit, or POST /score). The staleness predicate is already event-driven, so wiring those triggers later is additive.
- **The booking `OPPORTUNITY_STAGE_CHANGED` audit row still carries `after.value = reservation.amount`** (the DOM-03 trail-shape finding #2): the file is W2-A3's this wave, and A3's extraction contract was byte-level behavior preservation — the quirk is preserved verbatim and remains flagged for a later wave. It is trail presentation only: no opportunity column is written.
- **The engine is v1 and deliberately conservative**: no negative signals (a cold lead simply scores low), no time-decay on recorded facts beyond the recency ladders, `scoreBreakdown` JSON in a TEXT column (SQLite-tolerant, size-bounded by the 8 fixed rows).
- **Bounded scans cap the facts**: latest 30 activities / last 50 visits (recency is read from the head; ≥10 counts « deep history » within the window) — a pathological lead with 500 visits reads the same as one with 50 recent ones.
- **No role floor on POST /score** — deliberate (read-derived cache, single writer), documented here for the Principal's arbitration if a stricter posture is wanted.
- **Seed demo scores are overwritten at seed time** (`seedLeadScores`): a fresh install shows engine-true numbers, but the static `score:` literals in `leadDefs` remain in the source as dead legacy data (kept verbatim — additive-only law).
