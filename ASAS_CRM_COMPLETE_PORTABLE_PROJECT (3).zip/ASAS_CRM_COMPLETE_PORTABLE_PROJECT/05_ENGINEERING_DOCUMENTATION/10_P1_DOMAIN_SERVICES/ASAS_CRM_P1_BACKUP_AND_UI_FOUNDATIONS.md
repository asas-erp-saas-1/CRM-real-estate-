# ASAS CRM — P1 / W4-A6: Backup & Recovery + UI Foundations (registries, focus, forms)

> **Provenance.** This work was implemented by **Agent 6 (W4-A6a + W4-A6b)**. Part A (W4-A6a —
> the automated backup & recovery system) was delivered, gate-verified and committed by Agent 6
> itself as `56a5ccf` (67 new tests, 621/621 at the time). Part B (W4-A6b — view-registry
> unification, typed query-key factory, the single focus contract, RHF/Zod form migration,
> touch-target fixes) was fully implemented on disk (81 uncommitted entries; the dev server was
> OOM-reaped mid-run and durably restored — health OK, `migrations:23`), but Agent 6's response
> was lost after the OOM server-reap, before its browser-verification, screenshots and report.
> Assessment of the delivered diff, gate re-runs, browser verification, this report, the worklog
> entry and the commit were produced by the **Principal's completion agent**. Everything marked
> VERIFIED below was re-run or re-read end-to-end by the completion agent; the completion agent
> changed **ZERO lines of Agent 6's source code** — the delivered state needed no fixes.

## 1. Status matrix (deliverable → status + evidence)

| # | Deliverable | Status | Evidence |
|---|---|---|---|
| **Part A — W4-A6a (QA-05), committed at `56a5ccf`** | | | |
| 1 | `scripts/backup.sh` + `scripts/lib/{backup-run.mjs, backup-logic.mts, backup-engine.mjs}` — VACUUM INTO snapshot + docs tarball + strict manifest | DELIVERED (by A6) · RE-VERIFIED | full read; **live re-run by the completion agent** — snapshot 1,298,432 bytes sha256-verified, `integrity ok — PRAGMA integrity_check run ON THE SNAPSHOT`, census `users=8 leads=43 opportunities=21 reservations=8 apartments=46 documents=0`, manifest written, `retention kept=4 deleted=0 (guard: nothing younger than 1 h is ever deleted)` |
| 2 | `scripts/restore.sh` + `scripts/lib/restore-run.mjs` — interlocked restore (drill vs live) | DELIVERED (by A6) · RE-VERIFIED | **live drill re-run** → `artifacts verified — sha256 + size match the manifest`, restored db byte-identical to the snapshot, `integrity ok` on the restored copy, `census … MATCHES MANIFEST`, `original db/custom.db — NOT TOUCHED`, `PASS — drill restore verified end-to-end`; live path requires BOTH `--confirm-restore` AND the typed `--i-understand-this-overwrites-the-live-db` flag (exit code 2 on refusal, vitest-covered in `parseRestoreArgs`) |
| 3 | Retention guard (keep-N default 14 via `ASAS_BACKUP_KEEP`, 1 h age floor) + manifest strictness (integrity + census + per-artifact sha256/bytes) | DELIVERED (by A6) · VERIFIED | `tests/unit/backup-manifest.test.ts` (574 lines, **67 tests**: stamps, `parseKeepCount`, `selectRetentionDeletions` keep-N + 1 h guard, `compareCensus` mismatch detection, `validateManifest` the manifest contract incl. tamper shapes, `verifyFileEntry` artifact reality, `parseRestoreArgs` interlock) — re-run green by the completion agent; live backup printed the guard line verbatim |
| 4 | Engine honesty + zero new deps | DELIVERED (by A6) · VERIFIED | no `sqlite3` CLI in this sandbox → the runner logs `engine=node:sqlite (Node built-in…)` on every run (never silent); no new npm dependencies |
| 5 | Backup artifacts ignored by git | DELIVERED (by A6) · VERIFIED | `.gitignore` `/db/backups/`, `/db/restore-drills/`; drill outputs on disk (`db/restore-drills/<ts>/`, 5 runs incl. the completion agent's) leave the tree clean |
| **Part B — W4-A6b (ARCH-03/05/06 + UX-02/UX-01)** | | | |
| 6 | `src/lib/client/view-registry.ts` — the ONE view registry (ARCH-03) | DELIVERED (by A6b) · VERIFIED | 4 drifting copies → 1 with full deletion (§3); 8 contract tests green; browser: 12-view nav, per-view topbar titles, hash routing + unknown-id fallback all live |
| 7 | `src/lib/client/query-keys.ts` — the ONE typed query-key factory (ARCH-06) | DELIVERED (by A6b) · VERIFIED | 231 raw `queryKey: [` literals across 62 files at baseline → **0** (completion agent grep + a source-scan unit test that keeps it at 0); `query-invalidation.ts` factory-built; 16 tests green |
| 8 | `src/lib/client/focus.ts` — the ONE focus-token contract (ARCH-05) | DELIVERED (by A6b) · VERIFIED | 6 parallel store mechanisms → 1 discriminated-union contract with full deletion (§5); ~20 consumer files migrated; 13 tests green |
| 9 | RHF/Zod form migration of the manual capture dialogs (UX-02) | DELIVERED (by A6b) · VERIFIED | **5 dialogs migrated**: create-opportunity, schedule-visit, sav-create, add-installment, record-payment (§6); 24 pure schema tests green; browser-verified on opportunity + lead incl. the preserved-values law |
| 10 | Touch-target floor fixes (UX-01) | PARTIAL (by A6b) · VERIFIED as partial | 2 real fixes with `crm-hit` (§7): the archived-lead restore action (28 px raw → 44 px effective) and the schedule-visit unit-chip remove (14 px raw → 42 px effective); **no full sweep — deferred with reasons (§8)** |
| 11 | Tests for part B | DELIVERED (by A6b) · VERIFIED | **61 new tests** (682 = 621 + 61): `view-registry.test.ts` 8 · `query-keys.test.ts` 16 · `focus.test.ts` 13 · `form-schema.test.ts` 24 — all re-run green inside the 682/682 full-suite gate |
| 12 | Browser verification + screenshots | **NOT done by A6b** (OOM-reaped) → done by the completion agent | §7: two dialogs exercised end-to-end (validation visible, values preserved, async lead picker, dirty-discard guard), zero console errors; `/tmp/p1-w4-form-opportunity.png` + `/tmp/p1-w4-form-lead.png` |
| 13 | Report + worklog + commit | **NOT done by A6b** → done by the completion agent | this file; Wave-4 worklog entry; commit hash in §9 |

## 2. Part A in one page — the backup & recovery law (W4-A6a)

**Snapshot truth = VACUUM INTO.** `bun run db:backup` opens the live `db/custom.db` on a
**read-only** connection and produces a consistent snapshot via `VACUUM INTO` (never a file
copy — no torn WAL, no locked pages). Alongside it, `db/docs/` is archived as a tarball. Both
artifacts land in `db/backups/backup-<UTC-stamp>/`.

**The strict manifest.** `manifest.json` per run: `runId` (16 hex), `ts`, `integrity` (the
verdict of `PRAGMA integrity_check` run **on the snapshot**), `census` (row counts of the six
business tables: users, leads, opportunities, reservations, apartments, documents), `files[]`
(per artifact: name + `sha256` + `bytes`), `keep`. Any failed step exits non-zero — *a backup
without verified integrity is a failure*, not a warning. The pure decision layer
(`backup-logic.mts`, 482 lines) is vitest-covered end-to-end (67 tests), including the tamper
shapes: a manifest whose census lies, whose artifact hashes/bytes don't match reality, or whose
shape violates the contract is rejected (the `validateManifest`/`verifyFileEntry`/
`compareCensus` describe blocks).

**Retention guard.** Keep the newest N (env `ASAS_BACKUP_KEEP`, default **14**) and **never
delete anything younger than 1 h** — a clock-skew or an accidental future stamp can never wipe
the fresh backups. Verified live: `retention kept=4 deleted=0`.

**Interlocked restore.** `scripts/restore.sh <backupDir> --drill` (npm:
`bun run db:restore:drill`) restores into `db/restore-drills/<ts>/` ONLY — re-verify integrity
on the restored copy, demand the census match the manifest byte-for-manifest, print `PASS`,
never touch the live DB. The live path needs **two** flags: `--confirm-restore` AND
`--i-understand-this-overwrites-the-live-db` — the second is a typed confirmation (its exact
name is the value; a misspelling is rejected as an unknown flag). A safety snapshot of the
current DB (VACUUM INTO) is taken first. Exit codes: 0 verified success, 1 verification
failure, 2 interlock refusal. The completion agent re-ran a full drill against
`backup-20261105T200957Z`: sha256 + size match, byte-identical restored db, integrity ok,
census match, `original db/custom.db — NOT TOUCHED`, `PASS`.

**Engine honesty.** The `sqlite3` CLI is preferred when present (path exported, engine logged
every run); this sandbox has none, so the verified Node built-in `node:sqlite` engine does the
SQL — logged as `engine=node:sqlite`, never silent, zero new dependencies.

## 3. Part B — ARCH-03: the ONE view registry (4 drifting copies → 1)

Before W4-A6b the 12 main views were enumerated in **four** copies that could (and did) drift
independently. The unification, with the old code **deleted** (no dead code left behind):

| Site | Before (deleted) | After (consumer of the registry) |
|---|---|---|
| `src/lib/client/store.ts` | the `View` union (12 string literals) + the `VIEWS` id array (hash parsing included `(VIEWS as string[]).includes`) | `import { isView, type View } from "@/lib/client/view-registry"`; `parseHash` uses `isView(rawView)`; a `export type { View }` re-export keeps the ~30 type importers on one definition site |
| `src/components/crm/sidebar-nav.tsx` | `SECTIONS`/`NavItemDef` (label · icon · role floor duplicated per nav entry) | derives its structural map from `NAV_SECTIONS` + `VIEW_REGISTRY` (JSX identical to the former SECTIONS rendering) |
| `src/components/crm/shell.tsx` | `VIEW_META` (12 title/subtitle/icon entries for the topbar) | `viewDef(view)` — unknown ids degrade to the dashboard def |
| `src/components/crm/crm-app.tsx` | 12 `lazy()` import consts + a 12-branch `renderView` switch | `VIEW_COMPONENTS[viewDef(view).id]` — the lazy map the registry builds once |

The registry (`src/lib/client/view-registry.ts`, 251 lines) is the single authoritative
implementation: `ViewDef` carries the full routing identity per view — `id`, `labelKey`
(nav), `titleKey`/`subtitleKey` (topbar + `document.title`), `icon` (one glyph per view),
`minRole` (nav-only role floor mirroring the server's API gates: finance/analytics/audit/
settings are MANAGER+), `hideFor` (leads/pipeline hidden for FIELD_REP — the D-025
agenda+inventory law), `badge` (tasks' overdue count), and `load` (the lazy chunk loader —
**W5-2 per-view code splitting preserved verbatim**: the chunks come from the dynamic imports
themselves, wherever the `lazy()` closures live; nothing eager imports a view module, so the
`store.ts → view-registry` import has no cycle at module-eval time). `NAV_SECTIONS` groups the
12 views into the sidebar's three sections (main / ops / admin), each view exactly once —
pinned by test. `VIEWS` keeps the canonical order for hash parsing; `isView` accepts exactly
the registry ids; `viewDef` degrades unknown ids to the dashboard (the parseHash law — a stale
hash never crashes the boot; **browser-verified**: `#/nonsense` → dashboard fallback, live).

**Tests (8):** exact id set + canonical order; full routing identity per entry; MANAGER+ floors
+ FIELD_REP visibility law; section grouping with no orphans/duplicates; overdue badge on tasks
only; `isView` exact acceptance; unknown-id degradation.

## 4. Part B — ARCH-06: the ONE typed query-key factory (231 literals → 0)

Before W4-A6b, **231 raw `queryKey: [...]` literals across 62 files** (counted at baseline
`56a5ccf` by the completion agent with a git-stash scan) hand-built the React Query cache's
entity inventory — invalidation fan-outs re-typed the same prefix per call site (a missed key =
a stale lie on screen), sub-key shapes drifted independently, and no single place knew the
cache's inventory.

`src/lib/client/query-keys.ts` (194 lines) is the ONE factory: **~70 members across ~30 entity
families** — session/users/leads/lead/dashboard/targets/pipeline/pipelineStages/opportunities/
oppGates/reservations/offers/apartments/projects/visits/visitFiche/tasks/journey/journeyStats/
analytics/audit/search/savedSearches/sav/finance/matching/notifications/settings/activities/
leadDuplicates/documents — each detail or sub-surface shape carrying the exact discriminants it
always had (`"picker"`, `"visit-link"`, `"audit-target"`, `"dup-precheck"`, …), params riding
list keys verbatim (the qs()-built query strings).

**THE BYTE-IDENTITY LAW** (module header + test suite): every factory member produces EXACTLY
the array the migrated call site held before — element-for-element, no renames, no reordering —
because React Query keys the cache by deep array equality; any deviation would fork caches and
silently break invalidation semantics (prefix matching included).

**Migration coverage (verified):** all 231 raw `queryKey: [` literals are gone — the completion
agent's `rg 'queryKey:\s*\[' src/` returns **zero** matches (the only remaining `queryKey:` line
is query-invalidation.ts's pass-through `queryClient.invalidateQueries({ queryKey: key })`
iterating factory-built arrays), and a **source-scan unit test** (`no hand-written queryKey
array literal remains in the migrated tree`) walks every `.ts/.tsx` under
`src/components/crm` + `session.ts` + `query-invalidation.ts` and fails on any future
`queryKey: [` literal — the unification is now regression-guarded, not just performed. A second
scan asserts every file using `qk.` imports the factory. 64 files import it; 247 `qk.*`
references in the tree. `query-invalidation.ts`'s `DEAL_MUTATION_KEYS` (12 prefixes) and
`CONVERT_MUTATION_KEYS` (14) are factory-built (prefix invalidation semantics preserved);
`documents/shared.tsx`'s `docsQueryKey` delegates to `qk.documents` (import surface stable);
`session.ts` migrated.

**No leftover raw keys, documented dynamic constructions:** none were needed — every former
dynamic key shape (nullable ids for disabled queries, per-open tokens forcing fresh fetches,
qs()-serialized list params) is expressed as a typed factory member. The only non-factory
`queryKey:` is the pass-through described above.

**Tests (16):** per-family byte identity against the frozen literal forms (incl. nullable-id
and token shapes) + the two source-scan guards.

## 5. Part B — ARCH-05: the ONE focus contract (6 parallel mechanisms → 1)

Before W4-A6b the UI store carried **six** parallel transient focus mechanisms, each with its
own state slot, its own `open*/consume*` action pair and its own payload shape — the same law
implemented six times: `scheduleVisit` (P28 prefill), `duplicatesToken`, `propertiesFocus`
(palette deep-link scope), `pipelineFocus` (hot columns), `financeFocus` (pre-seeded client
filter), `savFocusId` (case cockpit target).

`src/lib/client/focus.ts` (183 lines) is the single emitter/resolver: **ONE request slot** (a
true discriminated union `FocusRequest<K>` = `{ kind, payload, token }` with the payload typed
per kind), **ONE route table** (`FOCUS_VIEW`: `schedule-visit → null` — it arms the shell-level
global dialog, routes nothing; `duplicates → leads` and additionally closes the lead drawer
(the dialog IS the destination); `properties/pipeline/finance/sav →` their views + hash sync),
**ONE consumption law** (`resolveFocus(kind)` is kind-scoped, `resolveFocus()` clears; one slot
at a time — arming a new focus replaces any stale token instead of letting it re-fire on a
later plain navigation). Session-lifetime, memory-only, deliberately NOT persisted (payloads
carry customer ids and typed search predicates). The former open* vocabulary survives as thin
typed wrappers over the one emitter (`openScheduleVisit`, `openDuplicates`,
`openPropertiesFocus`, `openPipelineFocus`, `openFinanceFocus`, `openSavCase`) so call sites
read as domain acts; readers are `useFocusRequest` (reactive per-kind), `getFocusRequest`
(mount-time — the finance view's consume-once-at-mount law) and `useSavFocusId`.

**Deletion (verified):** the six mechanisms' state slots, payload interfaces and action pairs
are **gone from `store.ts`** (−~150 net lines there; the store now keeps only view/hash
routing, lang/density/pane preferences, palette recents and the lead-drawer overlay contract —
the `ARCH-05` comment in store.ts says exactly this); zero references to the old store API
remain anywhere in `src/` (completion agent grep). ~20 consumer files were migrated to the new
contract (drawer surfaces, notifications bell, search palette, dashboard attention strip +
right panels, properties/pipeline/finance/sav views, stage playbook, opportunity detail,
apartment demand panel, field-team panel, shell's P28 schedule-visit mount…).

**Tests (13):** arm lifecycle + fresh token; empty-payload default; the FOCUS_VIEW routing
table; duplicates' drawer-close law; kind-scoped vs clear-all resolution; the wrapper
vocabulary 1:1; the sav id reader.

## 6. Part B — UX-02: RHF/Zod form migration (5 dialogs; preserved values by construction)

**The reference law.** `create-lead-dialog.tsx` was already React Hook Form + Zod before this
wave (the pre-existing reference implementation); in W4-A6b it received only the query-key
migration. **Five manual `useState`-field dialogs were migrated onto that reference law** —
same rules, same contracts, but validation now VISIBLE (field-level messages on submit) instead
of a silently disabled button, and user-entered values always surviving recoverable validation
errors:

| Dialog | Former manual gate → now the Zod contract | Lines |
|---|---|---|
| `pipeline/create-opportunity-dialog.tsx` | required trio lead · title · next action (trimmed) + the terminal-stage contract (closedAt at CLOSED_WON/CLOSED_LOST, lostReason additionally for Perdue); next-action chips write through `form.setValue(..., { shouldDirty: true })`; PIPE-06 async lead picker + lead context preview + duplicate-open-deal probe ride along | 845 |
| `visits/schedule-visit-dialog.tsx` | required pair lead · date; the B6 unit multi-picker + P28 preselection derivation ride the form's `apartmentIds` field (derivation law unchanged) | 564 |
| `views/sav/sav-create-dialog.tsx` | required pair title · description (the former silent `invalid` gate) | 308 |
| `views/finance/add-installment-dialog.tsx` | reservation · label required, amount strictly positive finite | 251 |
| `views/finance/record-payment-dialog.tsx` | amount strictly positive, capped at the remaining balance with the SAME exceeds message (+0.005 float tolerance — the exact former guard) | 241 |

Each schema is a **pure factory bound to the live translator** (`createOpportunitySchema(t)` …)
so the validation branches are unit-testable with a stub translator: `form-schema.test.ts`
(**24 tests**) exercises every branch — the valid case, each required-field hole, the
cross-field contracts (terminal-stage deal contract, payment cap with float tolerance), the
money-domain guards (strictly positive, finite).

**The preserved-values mechanism** is structural, not bolted on: RHF owns the draft — a failed
`handleSubmit` renders field-level messages without unmounting or resetting anything, so typed
values survive every recoverable error (the create-lead dialog's P2.5 law, now the pattern for
all five). The dirty draft additionally routes close attempts through the discard-confirm guard
(`leads.form.discard.*`) — **browser-verified live** on both surfaces (§7).

## 7. Browser verification (completion agent, live dev server `127.0.0.1:3000`)

Login `sarah@asas.dz`/`asas1234` → the app boots to the dashboard with the registry-driven
12-view nav (badge « Tâches 7 ») and **zero console errors** across the whole session (only
React DevTools info + HMR logs).

**Create-opportunity dialog (the required surface).** Pipeline → « Créer une opportunité » →
submit empty → **three field-level « Champ requis »** (prospect, titre, prochaine action — the
required trio, now visible; the former behavior was a silently disabled button). Filled
« Sofiane — F4 Hydra » / 12 500 000 DA / next-action chip « Appeler » → switched the stage to
« Perdue » → submit → the **terminal contract errors** (closedAt + motif de perte « Champ requis »
+ the stade-final explainer line) **while every typed value was preserved** (title, formatted
value, next action, stage Perdue, probability 0). The async lead picker (debounced server-side
search, `keepPreviousData`, 50-row page) listed the book and selected « Sofiane Menad ». Screenshot:
`/tmp/p1-w4-form-opportunity.png` (1280×577).

**Prospects + create-lead dialog (the second surface).** Prospects view loads with the **Score
column** (sortable, the W2 scoring surface intact under the registry refactor). « Nouveau
prospect » → submit empty → « Champ requis » ×2 + « Numéro de téléphone invalide »; filled
« Yasmine Belkacem » + invalid phone « 0551 » → the phone error + source error **with both typed
values preserved**; closing the dirty draft fired the **« Abandonner la saisie ? » guard** (RHF
`isDirty`) — « Abandonner » discards and closes. Screenshot: `/tmp/p1-w4-form-lead.png`
(1280×577).

**Registry routing spot-checks.** `#/sav` → « SAV — ASAS CRM », `#/journey` → « Parcours
client », `#/nonsense` → **dashboard fallback** (the parseHash degrade law), `document.title`
following `viewDef` per view; the shell-level create-lead dialog stays mounted across view
switches (the W5-2 shell-overlay law) while the view behind it changes.

**Touch-target evidence in the delivered diff (UX-01, partial).** Two real `crm-hit` fixes,
each with a `W4-A6b (UX-01)` comment: `views/leads/lead-row.tsx` — the archived-lead restore
icon action was icon-only at 28 px (`size-7`) without the row-action `crm-hit` law its sibling
quick-actions carry → now `crm-hit size-7` (44 px effective); `visits/schedule-visit-dialog.tsx`
— the unit-chip remove `X` was the codebase's smallest raw target at 14 px → `crm-hit` rides
the chip-remove law (42 px effective). The create-opportunity next-action chips already carried
`crm-hit` (unchanged, only re-indented in the migration). **No systematic sweep of all icon-only
actions was performed — see §8.**

## 8. Honest status: what is DEFERRED, and why

- **Touch-target sweep (UX-01) — PARTIAL/DEFERRED.** Only the two sites encountered during the
  dialog migrations were fixed (with the codebase's `crm-hit` law, verified in the diff). A full
  audit of every sub-44-px interactive target across the 12 views was not in the delivered diff
  and is not claimed. Follow-up: one a11y pass with the pointer-size audit (the existing
  `crm-hit` utility makes it mechanical).
- **RHF migration queue (UX-02) — 12 dialog surfaces remain manual** (each still `useState`
  fields + a silent submit gate, listed here as the follow-up queue): `bulk-copilot-dialog`,
  `change-password-dialog`, `duplicates-dialog`, `import-leads-dialog`, `gate-dialog`,
  `reason-dialog`, `pipeline/opportunity-detail-dialog`, `properties/apartment-detail-dialog`,
  `settings/team/add-member-dialog`, `settings/team/temp-password-dialog`,
  `visits/visit-dialogs` (the outcome form), `visits/visit-fiche-dialog`. All received the
  query-key/focus migrations where applicable — only their form layer is manual. The five
  migrated dialogs are the pattern + the test harness (`form-schema.test.ts`) to copy.
- **`query-keys.ts` naming.** `leads.picker` is create-opportunity's async lead search while
  `leads.combobox` is the generic combobox page — the names mirror the former literal shapes
  (byte-identity law), so they document history rather than intent; a rename would fork caches
  and is deliberately not done.
- **Part A operational notes.** Backup/restore run on the dev sandbox's live DB; the live-restore
  path was exercised only through its interlock refusal tests and the drill (never fired against
  the real DB — by design). `node:sqlite` is the engine here (no sqlite3 CLI); a host with the
  CLI will automatically prefer it (logged every run).

## 9. Gates, evidence trail and commit

**Gates (all re-run by the completion agent on the live server, post-restore):**

| Gate | Result |
|---|---|
| `bun run test` | **Test Files 35 passed (35) · Tests 682 passed (682)** (621 baseline + **61 new** = 8 view-registry + 16 query-keys + 13 focus + 24 form-schema; 0 skips) |
| `bun run typecheck` | **0 errors** (`tsc --noEmit`, exit 0) |
| `bun run lint` | **0 errors, 37 tolerated warnings** (unchanged from the 56a5ccf baseline count) |
| `/api/health` | `{"status":"ok","dbOk":true,"migrations":23,"demoMode":true,…}` before, during and after the verification session |

**Deviation (process, not code):** the kernel's OOM killer reaped `next-server` during Agent 6's
W4-A6b run (the documented 4 GB sandbox condition of Waves 3–4); per the laws the server was
durably restored (double-fork daemonizer, `/tmp/restore-server.mjs`) before this completion
session — the completion agent verified health first (OK, `migrations:23`) and never restarted
or killed it; no restore script was needed. No `git push`, no `bun run build`, no schema
changes, no server-side file touched by part B (the diff is 100% client-tree: 74 modified files
+ 7 new, +1,785/−1,521).

**Fixes applied by the completion agent: NONE.** The delivered diff was complete and green as
found — no leftover imports, no dead files, no raw query keys, no dangling old-store API; the
only work was assessment, gates, browser verification, screenshots, this report, the worklog and
the commit.

**Commit:** `feat(p1/w4-a6b): unified view-registry + typed query-key factory + single focus contract (ARCH-03/05/06) + RHF/Zod form migration 5 dialogs (UX-02) — 61 new tests (682/682)` — single local commit (never pushed; this report + the worklog entry ride in it; hash in `git log`); part A remains `56a5ccf`.
