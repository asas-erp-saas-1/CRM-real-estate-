# ASAS CRM — P1 / W3-A5: Tokenized Public Lead Capture + Document Security

> **Provenance.** This work was implemented by **Agent 5 (W3-A5)**: the capture-token model +
> migration #23, the public intake endpoint, the token management API, the magic-byte file
> verification module, and the document upload/download hardening. Agent 5's final response was
> lost in transit; its source code and migration were on disk uncommitted (verified against
> `HEAD 4ea34e1`, health already reporting `migrations:23`), but its **tests and report were never
> written**. Tests, gate verification, this report, the worklog entry and the commit were produced
> by the **completion agent**. Everything marked VERIFIED below was re-run end-to-end by the
> completion agent on the live dev server; the completion agent changed **ZERO lines of A5's
> source code** (see §7 — only tests, the two stale-test bookkeeping pins, this report and the
> worklog were touched).

## 1. Status matrix (deliverable → status + evidence)

| # | Deliverable | Status | Evidence |
|---|---|---|---|
| 1 | `LeadCaptureToken` model + migration `20261105200000_p1_capture_token` (#23) | DELIVERED (by A5) · VERIFIED | `/api/health` → `"migrations":23`; schema + migration SQL read (unique `tokenHash`, `orgId` index, RESTRICT FKs); the suite reads/writes rows through it |
| 2 | `src/lib/server/lead-capture.ts` — the single authoritative capture module | DELIVERED (by A5) · VERIFIED | full module read; 15-test black-box suite (`tests/security/public-capture.test.ts`) green twice back-to-back |
| 3 | `src/lib/server/file-verification.ts` — pure magic-byte sniffer | DELIVERED (by A5) · VERIFIED | 22-test unit suite (`tests/unit/file-verification.test.ts`) green |
| 4 | `GET/POST /api/lead-capture-tokens` + `POST /api/lead-capture-tokens/:id/revoke` | DELIVERED (by A5) · VERIFIED | mint/list/revoke + AGENT 403 + idempotent revoke + ghost-pair tests |
| 5 | `POST /api/public/lead-capture` — the token-gated public intake | DELIVERED (by A5) · VERIFIED | honeypot / interval / duplicate / no-oracle / rate-limit / isolation tests |
| 6 | Document upload content gate (`src/app/api/documents/route.ts`) | DELIVERED (by A5) · VERIFIED | real PNG/PDF uploads, lying-MIME, random bytes, OOXML, 8 MB+1 → 413, field discipline |
| 7 | Document download hardening (`src/app/api/documents/[id]/file/route.ts` + `documents.ts` realpath guard) | DELIVERED (by A5) · VERIFIED | bytes/headers/audit assertions, org ghost pair, traversal row, symlink swap, legacy-mime sniff override |
| 8 | `SOURCES`/`SOURCE_ICON` + i18n vocabulary ×3 languages (`audit.ts`, `enums.ts`) | DELIVERED (by A5) · VERIFIED by reading + the full i18n/constant unit suites in the 554/554 gate |
| 9 | Tests for all of the above | **NOT written by A5** → written by the completion agent | 52 new tests, all green (§5) |
| 10 | Report file | **NOT written by A5** → written by the completion agent | this file |
| 11 | Worklog entry + local commit | by the completion agent | `worklog.md` Wave-3/A5 entry; commit hash in §8 |

## 2. The capture-token design (DOM-04) — as delivered, now proven

**Secret format.** `asas_lc_` + 32 hex chars (`randomBytes(16)` → 128 bits of entropy). The secret
is embedded in a landing page / WhatsApp bio; `POST /api/public/lead-capture` carries it in the
body — **the token IS the org scope**: no cookie, no org id, no session is read (a logged-in
caller gets byte-identical treatment; the route deliberately bypasses `requireUser()`/
`assertSameOrigin()` because CSRF is a session-forgery class and cross-origin is *the feature* —
proven by the foreign-`Origin` 200 test).

**Hash-only storage.** The DB row keeps `sha-256(secret)` in `tokenHash` (unique — the O(1) lookup
key). The plaintext exists exactly once, in the 201 mint response `{ token, secret }`. Verified by
test: `tokenHash === sha256(secret)` (64 hex, ≠ secret), and the whole list surface + the mint
audit row are scanned for the secret — absent. Audit payloads carry the token's **row id** as
provenance, never the secret.

**No-oracle verification.** `verifyCaptureToken` funnels unknown / expired / revoked secrets into
ONE byte-identical 401 `INVALID_TOKEN` envelope (format sanity → hash → unique-index lookup →
timing-safe hash re-compare as defense-in-depth → revoked → expired). Verified by a three-way
`JSON.stringify` equality test (unknown vs direct-expired vs direct-revoked rows).

**Revocation.** Soft (`revokedAt`): mint history, label and `useCount` survive for the audit
trail. The revoke endpoint is idempotent — a re-revoke returns the row and writes NO second audit
row (verified: exactly one `CAPTURE_TOKEN_REVOKED` row). Foreign-org and nonexistent ids answer
the same 404-ghost `CAPTURE_TOKEN_NOT_FOUND` (verified byte-identical pair), and a revoked secret
then gets the generic 401 (verified).

**Rate limiting — scale + honesty.** Process-local sliding windows: **10/min per token** (key =
the DB row id — bounded), **30/min per IP** (key = `clientIp()`, i.e. XFF parsed from the right —
the Caddy gateway replaces it in prod). The IP gate runs **before** token resolution (bounds
anonymous work); the token gate runs after verification. 429s carry `RATE_LIMITED` + a `Retry-After`
header. Map hygiene: entries pruned past 4096 keys. **Documented honesty** (source comments +
tests): single-instance architecture, no Redis by the over-engineering ban — a restart resets the
windows and a multi-instance deploy would need the documented shared-store end-state (§8).

**Anti-spam stack.** (1) **Honeypot** `companyWebsite` — a hidden field no human fills: any
non-empty value answers the SAME `{ ok: true }` while creating nothing and freezing `useCount`
(zero DB side effects; the check precedes token verification). (2) **Strict whitelist** —
`.strict()` zod: any smuggled key (`ownerId`, `status`, `source`…) is 422 `VALIDATION_ERROR`
(mass-assignment fence). (3) **DZ phone discipline** — canonical E.164 with `+213` required, else
422 `INVALID_PHONE` `{field:"phone"}`. (4) **Min-interval** — org+phone keyed 60 s in-memory
swallow: generic success, no DB round-trip, `useCount` frozen. (5) **Durable duplicate fence** —
same-org same-phone (or same email when provided) never creates a second lead: a `NOTE` activity
("Nouvelle demande via capture publique", `meta.duplicate`) lands on the EXISTING lead + a
`LEAD_CAPTURE_PUBLIC` audit row flagged `duplicate:true` + `useCount` advance, all in ONE
transaction (F-06); the `@@unique([orgId, phone])` index is the race backstop (P2002 → degrade to
the duplicate path).

**Generic success law.** Every accepted outcome — created, duplicate, honeypot, interval
swallowed — answers the SAME `{ ok: true }` with exactly the key `ok`: no lead id, no org data, no
enumeration signal (exact response-key assertions in the tests).

**Safe defaults + attribution.** New leads land `ownerId: null` (the unassigned intake pool —
assignment stays managerial, D-GOV-5), `source: "PUBLIC_CAPTURE"` (the closed-vocabulary SOURCES
member added in `constants.ts`, label "Capture publique"/"Public capture"/"استقبال عام (استمارة)" ×3
languages), with `campaign`/`utmSource` passthrough, notes composed from interest+message, the
score cache born fresh through the single writer (`refreshLeadScore` in the same tx), and
provenance = the token id/label in the `LEAD_CREATED` activity meta + the `LEAD_CAPTURE_PUBLIC`
audit `after` (actor null — anonymous by design).

## 3. Document-security hardening (SEC-06 + BE-06) — threat → control → test

| Threat | Control (as delivered by A5) | Test that proves it |
|---|---|---|
| Executable/script disguised with an image Content-Type | Magic-byte sniffing (`file-verification.ts`) is the acceptance truth; whitelist = `DOC_ALLOWED_MIME_TYPES` {pdf, png, jpeg, webp} | upload random bytes → **422 INVALID_FILE_CONTENT**; unit: ELF / MZ / shebang / gzip / random / truncated sigs → `sniffMime` null |
| DOCX/XLSX/PPTX container smuggling | PK-zip family (`PK\x03\04/05\06/07\08`) sniffed as `application/zip` — detector ready, NOT whitelisted today | upload real OOXML opening (declared the real DOCX mime) → **422 INVALID_FILE_CONTENT** with `details.sniffedMime:"application/zip"`; unit: all PK variants |
| A lying declaration granting or blocking a type | The declared Content-Type never gates: sniffed type is the STORED `Document.mimeType`; the declaration only flips the audit discrepancy signal | PNG bytes declared `application/pdf` → **201, stored `image/png`**, audit `after.mimeType:"image/png"` + `after.declaredMimeType:"application/pdf"`; unit: lying declaration on rejected content stays rejected |
| Memory exhaustion via oversized body | Content-Length pre-gate (> 8 MB + 64 KB) BEFORE `formData()` + the authoritative `file.size` cap (8 MB) | 8 MB+1 buffer → **413 DOC_TOO_LARGE** `{sizeBytes, maxBytes:8388608}`, no row |
| Multipart field smuggling / missing metadata | zod schema on the text fields (`title`/`category`/`entityType`/`entityId`/`notes?`); no file part → 400 `NO_FILE` | no-file → 400; no-title → 422 `VALIDATION_ERROR` |
| Path traversal through a crafted `storedName` row (DB compromise / legacy row) | READ path resolves through **realpath** and requires the target strictly INSIDE the real `db/docs` root — violations share the missing-file 404-ghost | row with `../../../etc/passwd` → **404 DOC_NOT_FOUND**, no `/etc/passwd` bytes, no audit row |
| Symlink swap inside the storage root | Same realpath containment (symlinks followed, escape flattened) | symlink `db/docs/p1doc-…-link` → `/etc/passwd` → **404 DOC_NOT_FOUND** |
| Content-type confusion on egress (stored-XSS / sniff attacks) | Download re-derives the Content-Type from the BYTES (sniff wins over the stored column for whitelisted types) + `X-Content-Type-Options: nosniff` on every response | downloads assert exact `content-type` + `nosniff`; a legacy row with stored `application/octet-stream` over real PNG bytes is **served as `image/png`**; the lying-declaration doc is served as its sniffed type |
| Cross-tenant document theft | Org-scoped `findFirst` + record visibility (`documentScope`) | foreign-org doc id → **404**, byte-identical to the nonexistent-id ghost; the org-B file is never served, never audited |
| Enumeration of document ids | The 404-ghost pair (status + code + full envelope equality) | `JSON.stringify(foreign) === JSON.stringify(nonexistent)` |
| Un-audited egress | ONE `DOC_DOWNLOADED` audit row per successful download (entity = the doc's entity, `after.documentId/fileName/mimeType/sizeBytes/inline`); deliberately NOT transactional (a read path — a trail hiccup must not deny a legitimate read) | 4 successful downloads → exactly 4 rows on the marker entity; ghosts/traversal/symlink → 0 rows |
| Disk/DB disagreement on failed uploads | File written FIRST, row+trail in ONE tx, file compensated away on failure (G5-P3-5/F-15) | (pre-existing W3-A4 fault-injection probe, re-run green in the 554/554 gate — its db/docs snapshot is now `qa4-`-scoped, see FINDING 3) |

**Actual error codes / limits asserted against** (read from the delivered code, not assumed):
upload → 422 `INVALID_FILE_CONTENT` (message = `INVALID_FILE_CONTENT_MESSAGE`, details
`sniffedMime`/`declaredMimeType`/`sizeBytes`), 413 `DOC_TOO_LARGE`, 400 `NO_FILE` /
`INVALID_FORM_DATA`, 422 `VALIDATION_ERROR`, 404 `DOC_NOT_FOUND` (row-level ghost:
"Document introuvable"; disk-level ghost: "Fichier document introuvable sur le disque" — same
status+code); the OLD 415 `DOC_BAD_TYPE` declared-MIME gate is fully retired. Capture → 401
`INVALID_TOKEN`, 429 `RATE_LIMITED` (+`Retry-After`), 422 `INVALID_PHONE`/`VALIDATION_ERROR`,
400 `INVALID_JSON`, 403 `FORBIDDEN_ROLE` (mint/list/revoke are MANAGER+), 404
`CAPTURE_TOKEN_NOT_FOUND`.

## 4. What the completion agent wrote (all new files)

- **`tests/unit/file-verification.test.ts` (22 tests)** — pure sniffer table: real PNG (the
  canonical 67-byte 1×1), real JPEG (SOI+JFIF+EOI), real PDF 1.5 body, real WEBP (RIFF…WEBP),
  real OOXML opening; PK variant signatures; RIFF-not-WEBP and truncated containers; ELF/MZ/
  shebang/gzip; random bytes; empty buffer; truncated signatures; HTML-prefixed polyglot
  (prefix-strict); the acceptance law (truthful/lying/absent declarations, case-insensitivity,
  `mismatch` semantics, OOXML rejected today) + the French-first rejection message.
- **`tests/security/public-capture.test.ts` (15 tests)** — house style (throwing preflight,
  IPv4 `127.0.0.1:3000`, direct `@prisma/client`, unique `P1-CAP-*` markers, never global counts,
  full marker-scoped teardown with a residue check, no silent skips). Mint (201 + secret format +
  exact response keys + hash-only + audit redaction) · AGENT 403 · list projection/redaction ·
  honeypot · valid capture (no cookie + foreign origin → DB truth, activity/audit/useCount in-tx) ·
  min-interval swallow · duplicate law (NOTE + flagged audit + single row) · three-way no-oracle
  401 · strict whitelist · DZ phone discipline · token-budget burst (10 admitted, 11th 429 +
  `Retry-After`, only ONE lead created) · IP-budget burst (30 admitted then 429 — proves the IP
  gate precedes token resolution) · cross-org isolation both directions · revoke ghosts ·
  idempotent revoke + revoked-secret 401.
- **`tests/security/document-security.test.ts` (15 tests)** — same house style, `P1-DOC-*`
  markers, direct fs access to the ACTUAL storage root (`{cwd}/db/docs`), rows AND files fully
  cleaned in afterAll (leaving `db/docs` byte-identical). Upload content gate (real PNG/PDF,
  lying MIME accepted-as-sniffed with the audit discrepancy signal, random bytes, OOXML,
  8 MB+1 → 413, no-file/no-title) · download hardening (exact bytes, sniffed Content-Type,
  `nosniff`, disposition, ONE `DOC_DOWNLOADED` audit row each) · legacy lying-mime sniff override ·
  org ghost pair (byte-identical) · traversal row · symlink swap · the ghost/probe trails stay empty.

## 5. Test evidence (exact counts)

| Gate | Result |
|---|---|
| `bun run test` | **554 / 554 passed — 30 files, 0 skips** (502/502 baseline + **52 new**: 22 unit + 15 public-capture + 15 document-security; run #1 surfaced the one stale migration-count pin below → fixed → run #2 fully green) |
| focused re-runs (determinism) | `public-capture` 15/15 twice back-to-back inside the 60 s rate window (per-run vouched IPs — see FINDING 1); `document-security` 15/15 twice; `file-verification` 22/22 |
| `bun run typecheck` | **0 errors** |
| `bun run lint` | **0 errors, 37 warnings** (the tolerated baseline count, unchanged) |
| `curl /api/health` | `{"status":"ok","dbOk":true,"migrations":23,"demoMode":true,...}` before, during and after the gates |
| post-run hygiene | `db/docs` empty; DB residue scan for `P1-CAP-*`/`P1-DOC-*` (leads, documents, tokens, probe orgs) = **0 rows** |

## 6. Findings register (mismatches found while writing the tests — all finding-only unless stated)

1. **F1 — Medium (environment reality, no source change).** `clientIp()` (session.ts:188) is
   XFF-derived and the module comment assumes "no vouched IP (direct dev probes)" — but **next
   dev INJECTS `x-forwarded-for: <socket addr>` on direct requests**, so in dev `clientIp()`
   returns `::ffff:127.0.0.1`, the null-IP branch is unreachable, and every no-XFF probe lands on
   ONE shared per-IP budget (30/min) that survives across test runs inside 60 s (confirmed live:
   a bare `curl` got 429 with a 6 s `retryAfterSec` right after a run; LOGIN audit rows record
   `ip:"::ffff:127.0.0.1"`). Disposition: this is STRICTER, not looser (the IP gate applies in
   dev); prod behind the Caddy gateway behaves as documented. Tests vouch a per-run XFF for
   determinism and keep one raw no-XFF probe (the honeypot) to cover the direct path. No source
   change (comment-only inaccuracy; recorded here).
2. **F2 — Low (stale test bookkeeping, fixed in the test).** `tests/contract/api.test.ts` pinned
   the migration count to `[22, null]`; A5's migration #23 made the truthful count 23. Updated to
   `[23, null]` with the comment chain extended — the exact precedent of the W2 completion agent
   ("api.test.ts bookkeeping 21→22" in the worklog). Full suite 553/554 → 554/554.
3. **F3 — Low (cross-suite coupling in a PRIOR wave's test, fixed in that test).** W3-A4's
   fault-injection `documents-post` probe snapshots the WHOLE `db/docs` listing
   (`readdirSync("db/docs").sort()`); the new document-security suite legitimately writes real
   files there, and vitest runs test files in parallel workers → the global snapshot would flake.
   Fixed by scoping BOTH sides of the snapshot to the suite's own probe files
   (`f.includes("qa4-")` — their upload's storedName embeds `qa4-<RUN>.png`). Semantics preserved
   exactly (their probe file is still asserted compensated away). This is the only change to
   another agent's delivered artifact.
4. **F4 — Info (asserted-as-designed).** A lying declaration is NOT rejected: sniffing is
   independent of client headers, so the file is stored with the sniffed type and the declaration
   rides the audit row as `declaredMimeType`. Tests assert THIS behavior (201 + stored
   `image/png` + discrepancy signal). The retired 415 `DOC_BAD_TYPE` gate is gone by design.
5. **F5 — Info (future-ready, rejected today).** The PK-zip family (OOXML/DOCX containers) sniffs
   as `application/zip` — a distinct detector for a future whitelist extension; today it is simply
   not whitelisted → `INVALID_FILE_CONTENT`.
6. **F6 — Info (budget ordering, verified).** Honeypot hits consume an IP hit (the IP gate is
   first) but NO token budget (the honeypot check precedes verification); invalid/expired/revoked
   secrets likewise consume no token budget (the token key is the DB row id — bounded). Invalid
   phones DO consume a token-budget hit (the phone check follows the token gate) but move no
   `useCount`. All verified by the useCount/burst assertions.
7. **F7 — Info (process-local honesty, as documented by A5).** Rate-limit windows and the
   phone-interval map are in-memory: a dev-server restart resets them, and a multi-instance
   deploy would need the documented shared-store end-state. Tests acknowledge this with per-run
   keys (fresh token ids, fresh vouched IPs, fresh phones).
8. **F8 — Info (session-equivalence claim).** The route comments claim a logged-in caller gets
   identical treatment ("the endpoint never reads the session"). Code-verified by reading (no
   `getCurrentUser`/cookie read on the path); the no-cookie tests exercise the primary contract.
   A cookie-carrying probe was deliberately not added — the foreign-Origin 200 probe already
   proves the absence of the auth choke-points.
9. **F9 — Process deviation (sandbox, not the codebase).** The kernel OOM-killer reaped
   `next-server` mid-session (dmesg: 2.0 GB RSS; the known 4 GB sandbox constraint, W3-A4 hit the
   same). Per the laws: 3 × 30 s probes first (no watchdog restore), then the server was restored
   ONCE via the pre-existing double-fork daemonizer (`/tmp/daemon-dev.mjs`) — no restart-KILL of a
   live server ever happened, and the restored server stayed alive through BOTH full-suite gate
   runs and all focused re-runs.

## 7. Files changed by the completion agent (vs `HEAD 4ea34e1`)

- NEW `tests/unit/file-verification.test.ts` (22 tests) · NEW
  `tests/security/public-capture.test.ts` (15) · NEW `tests/security/document-security.test.ts`
  (15).
- MODIFIED `tests/contract/api.test.ts` (migration-count bookkeeping 22→23 — FINDING 2) ·
  MODIFIED `tests/security/fault-injection.test.ts` (db/docs snapshot scoped to `qa4-` probes —
  FINDING 3).
- NEW this report · `worklog.md` (Wave-3/A5 entry).
- **A5's delivered source/migration: untouched** (`git diff` on `src/`, `prisma/` = A5's own
  uncommitted work only).

## 8. Limitations & hand-off

- Rate limiting + min-interval remain process-local (single-instance law); a shared-store variant
  is the documented end-state if the deploy ever scales horizontally.
- The mint surface has no expiry-edit/rotate operation (by scope: v1 = mint/list/revoke; rotation
  = mint + revoke, which the audit trail records as the pair).
- The `[id]/file?inline=1` preview disposition is covered implicitly (the audit `after.inline`
  flag is asserted false for the plain download path); an inline-disposition probe was not added —
  the header construction is shared code with the asserted path.
- UI surfaces for token management (a settings page listing tokens) are not part of W3-A5's
  delivered scope — the API is the complete surface; any UI wave can consume it as-is.
- Commit: see the worklog Wave-3/A5 entry (single local commit, never pushed).
