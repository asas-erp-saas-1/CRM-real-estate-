# ASAS CRM — P2 Master Execution Plan

**Phase P2: Advanced Engineering, Observability, Performance, Session Governance & Integration Maturity**

- **Mission order:** user P2 directive (this session) — implementation mission, not an audit.
- **Principal:** Z.ai Principal Platform Architect (this session).
- **Team:** 6 Z.ai Full-Stack agents with distinct responsibilities (§3).
- **Started:** 2026-11-06 · **Status tracking:** `ASAS_CRM_P2_EXECUTION_LOG.md` (companion file).
- **Status vocabulary:** NOT STARTED / IN PROGRESS / IMPLEMENTED / INTEGRATED / TESTED / VERIFIED / BLOCKED / FAILED / DEFERRED. No status is marked VERIFIED without fresh evidence.

---

## 1. Entry gate — verdict: **PASSED** (2026-11-06, independently verified)

| # | Gate item | Evidence (fresh, this session) | Verdict |
|---|---|---|---|
| 1 | P0 final acceptance | `05_ENGINEERING_DOCUMENTATION/09_P0_FOUNDATION_HARDENING/ASAS_CRM_P0_FINAL_ACCEPTANCE_REPORT.md` exists; P0 suites green inside the fresh full run below | PASS |
| 2 | P1 final acceptance | `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_FINAL_ACCEPTANCE_REPORT.md` — 15/15 criteria (13 VERIFIED / 1 TESTED / 1 INTEGRATED); all 8 companion P1 docs on disk | PASS |
| 3 | Current Git state | Clean tree at `5611155` ("P1 complete: 6 agents, 8 commits, 23 migrations, 682/682 tests") | PASS |
| 4 | SQLite architecture | Health live probe: `dbOk:true · migrations:23 · demoMode:true · sessionSecretConfigured:true`; 23 migrations on disk; schema.prisma 1051 lines; SQLite remains the authoritative runtime DB | PASS |
| 5 | Existing authentication | HMAC-signed `asas_user` cookie (`userId.issuedAtMs.hmac`), scrypt passwords, 7-day absolute expiry, password-change invalidation, same-origin CSRF defense, demo-mode boot gate. **Gap (P2 scope): no server-side session revocation — logout only clears the client cookie** | VERIFIED + gap |
| 6 | Existing rate limiting | In-memory per-email sliding window (5 failures / 15 min → 429 ACCOUNT_LOCKED). **Gaps (P2 scope): resets on restart; process-local; P1 finding F1 — zero automated tests** | VERIFIED + gap |
| 7 | Notification implementation | Client hook polls `/api/notifications` every 60 s per tab (`refetchOnWindowFocus:true`, `staleTime:30 s`); server route executes 7 parallel queries + 6–10 conditional counts + settings read ≈ **13–21 queries per poll** (role-dependent) | VERIFIED + gap |
| 8 | Activity/AuditLog structure | `Activity` (business timeline, closed type vocabulary) and `AuditLog` (actor/action/entity/before/after JSON, 4 composite indexes) — **no retention policy anywhere** | VERIFIED + gap |
| 9 | Existing error handling | `fail()` = `console.error("[api]", error)` — console-only, no request IDs, no correlation, no categories, no metrics | VERIFIED + gap |
| 10 | Current performance measurements | None instrumented (no metrics endpoint, no baselines, no budgets) | VERIFIED + gap |
| 11 | External integration credentials | `.env` contains only `DATABASE_URL`, `ASAS_SESSION_SECRET`, `ASAS_DEMO_MODE` — **no provider credentials present** → Agent 6A email/SMS is scoped to evaluation + decision doc, integration honestly BLOCKED until credentials are approved | VERIFIED |
| 12 | Fresh baseline re-run | Full suite re-run this session: **682/682 passing (35 files)** before any P2 change | PASS |

**Entry-gate conclusion:** P1 acceptance is established; P2 may begin. All findings above become Wave inputs.

---

## 2. Non-negotiable safety rules (carried from P0/P1 + P2 directive)

1. No destructive operations against `db/custom.db` (retention apply is dry-run-first, backup-gated, operator-approved).
2. No real emails/SMS to customers without explicit authorization; no external provider connection without approved credentials.
3. Never log: passwords, session secrets, authorization cookies, full sensitive customer records, financial secrets (redaction enforced in code + tests).
4. No push to GitHub. No deploy. No Redis/WebSockets/new infrastructure without demonstrated requirement.
5. SQLite stays the authoritative runtime DB; migrations append-only.
6. No disabled failing tests; no background automation without explicit approval.
7. House law: `bun run test` (not `bun test`); dev server on 127.0.0.1:3000 only; never `bun run build`.

---

## 3. Six-agent division of labor

| Agent | Responsibility (P2) | Wave | Key deliverable |
|---|---|---|---|
| **1 — Observability & reliability** | Structured JSON logs, request IDs, correlation IDs, error categories, redaction, health v2, metrics store | W1 | `ASAS_CRM_P2_OBSERVABILITY_IMPLEMENTATION.md` |
| **2 — Session governance & shared security** | Server-side session revocation (single + all), DB-backed login lockout, security events, rate-limit strategy decision | W2 | `ASAS_CRM_P2_SESSION_AND_RATE_LIMITING.md` |
| **3 — Data retention & audit lifecycle** | Retention classes (protected/operational/diagnostic), dry-run report, guarded apply with backup precondition | W3 | `ASAS_CRM_P2_DATA_RETENTION_IMPLEMENTATION.md` |
| **4 — Notification architecture & performance** | Measure polling cost, server TTL cache, adaptive + visibility-aware polling, dedup, SSE evaluation | W3 | `ASAS_CRM_P2_NOTIFICATION_OPTIMIZATION.md` |
| **5 — Performance engineering & metrics** | `/api/metrics`, measured baselines (API p50/p95, query costs, page weight), targeted optimizations, evidence-based budgets | W4 | `ASAS_CRM_P2_PERFORMANCE_ENGINEERING.md` |
| **6 — Integrations, attribution & UX reliability** | A. Email/SMS evaluation (credential-gated). B. Multi-touch attribution model (source preserved). C. RTL/heading/Sonner/dialog/motion fixes | W5–W6 | `ASAS_CRM_P2_INTEGRATION_AND_UX_RELIABILITY.md` |

**Coordination law (from P1, kept):** schema/financial/auth/shared-component changes are centrally coordinated by the Principal; independent research and bounded suites may be delegated. Every agent output is re-verified before a status is written.

---

## 4. Implementation waves (dependency order)

```
W1 Observability foundation ──► W2 Session & security governance ──► W3 Data & notification lifecycle
                                                                        │
                                           W4 Performance ◄────────────┘
                                                │
                                    W5 Communication & attribution ──► W6 UX reliability
```

- **Wave 1** — `src/lib/server/logger.ts` (structured, redacting), `src/lib/server/obs.ts` (process metrics), `src/middleware.ts` (request-ID + start-stamp on `/api/*`), `ok()/fail()` integration (correlation + error categories + metrics), health v2, tests.
- **Wave 2** — migration #24 (`RevokedSession`, `User.sessionsRevokedAt`, `LoginAttempt`), revocation checks in `getCurrentUser`, logout revocation, `POST /api/auth/sessions/revoke-all`, DB-backed login lockout, LOGIN_FAILED/LOCKED audit events, F1 test coverage.
- **Wave 3** — notification: server TTL cache (30 s, per-scope key) + adaptive client polling (60 s active / 300 s quiet / paused background) + measurement; retention: `src/lib/server/retention.ts` + `scripts/retention.ts` dry-run/apply with backup gate.
- **Wave 4** — `/api/metrics` (ADMIN+), `scripts/perf-baseline.ts` measured baselines, budgets, targeted query optimizations only where measurements justify.
- **Wave 5** — migration #26 (`LeadTouch`), touches API, source-effectiveness analytics, original-source preservation guard; email/SMS provider evaluation doc (integration BLOCKED without credentials).
- **Wave 6** — RTL hydration flash root-cause fix (SSR `dir`), heading hierarchy, Sonner a11y, dialog focus, reduced-motion, remaining touch targets.

**Per-task 12-step discipline (from P1, kept):** inspect existing → root cause → implement → update affected modules → migrate → wire real frontend → add/update tests → run tests → verify actual persistence → regression check → review git diff → log result.

---

## 5. Acceptance criteria mapping (mission §6 → evidence plan)

| # | Mission criterion | Evidence that will be produced |
|---|---|---|
| 1 | Structured observability operational | JSON log lines observed live; request-ID end-to-end (client → response header → error log); health v2 output |
| 2 | Sensitive info protected in logs | Redaction unit tests (passwords/secrets/cookies/PII keys) + negative grep on log output |
| 3 | Session revocation works | Replay-attack test: pre-logout cookie rejected post-logout; revoke-all kills all sessions |
| 4 | Rate limits enforced across deployment model | F1 closed: 429 lockout suite green; DB-backed lockout survives restart (verified live) |
| 5 | Retention documented + safely implemented | Class table, dry-run report output, apply refusal without fresh backup, archive-then-delete path |
| 6 | Notification load measured and improved | Before/after query-count + poll-frequency measurement table |
| 7 | Performance budgets evidence-based | Baselines from `scripts/perf-baseline.ts` + budgets derived ×headroom, documented |
| 8 | Communication integrations real where approved | Honest status: no credentials → evaluation + BLOCKED integration section (nothing faked) |
| 9 | Attribution preserves source history | Original source immutability guard test + touch timeline + funnel analytics |
| 10 | Accessibility & RTL defects corrected | Root-cause fix for dir flash; heading/role/label evidence via browser snapshot |
| 11 | All critical changes have automated tests | Suite count grows from 682; zero disabled tests |

---

## 6. Risk register (pre-execution)

| Risk | Mitigation |
|---|---|
| Middleware addition destabilizes dev server | Add after tests baseline; watch dev.log; D-042 restart procedure documented in worklog |
| `ok()`/`fail()` becoming async breaks call sites | Only 5 non-`return` call sites exist (dashboard, login ×2, logout); each updated + type-checked |
| Contract tests pin `migrations:23` | Pin ratchets to 24–26 in the same commits that add the migrations (designed mechanism) |
| Session revocation adds per-request query cost | Revocation check piggybacked on the existing user lookup (filtered select) — no extra round-trip |
| Retention apply destructive | Dry-run default, fresh-backup precondition, JSONL archive before delete, explicit operator confirmation |
| OOM server-reap (P1 incident) | Watchers on dev.log; probes-first law; no parallel heavy builds |

---

## 7. Document map (P2 deliverables — all in `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/`)

1. `ASAS_CRM_P2_MASTER_EXECUTION_PLAN.md` — this file
2. `ASAS_CRM_P2_OBSERVABILITY_IMPLEMENTATION.md` — W1/A1
3. `ASAS_CRM_P2_SESSION_AND_RATE_LIMITING.md` — W2/A2
4. `ASAS_CRM_P2_DATA_RETENTION_IMPLEMENTATION.md` — W3/A3
5. `ASAS_CRM_P2_NOTIFICATION_OPTIMIZATION.md` — W3/A4
6. `ASAS_CRM_P2_PERFORMANCE_ENGINEERING.md` — W4/A5
7. `ASAS_CRM_P2_INTEGRATION_AND_UX_RELIABILITY.md` — W5–W6/A6
8. `ASAS_CRM_P2_EXECUTION_LOG.md` — running status
9. `ASAS_CRM_P2_FINAL_ACCEPTANCE_REPORT.md` — final verdict with fresh evidence
