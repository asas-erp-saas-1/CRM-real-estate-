# ASAS CRM — P2 Observability Implementation (Wave 1 / Agent 1)

**Status: VERIFIED** (live-server evidence below; suite 707/707) · Date: 2026-11-06

---

## 1. What existed before (entry-gate findings)

| Surface | Before | Gap |
|---|---|---|
| Logging | `console.error("[api]", error)` in `fail()`; raw Prisma `log:['query']` dev lines | Unstructured, uncorrelated, unbounded, no redaction |
| Request IDs | None | No way to connect a reported failure to its log line |
| Correlation | None | Multi-step operations untraceable |
| Error taxonomy | HTTP status only | No stable categories for metrics/alerting |
| Health | booleans + migration count | No latency/uptime/process posture |
| Metrics | None | No measurement basis for Wave 4 budgets |

## 2. What was implemented (real source changes)

### 2.1 Structured logger — `src/lib/server/logger.ts` (NEW)
- **One JSON object per line** (`{ts, level, event, …fields}`) — greppable by humans, parseable by any future log shipper. **No external service introduced** (mission rule).
- **Deep, pattern-based redaction** (`redact()`): any key matching `/password|passphrase|secret|token|cookie|authorization|credential|api[-_]?key|private[-_]?key|session/i` becomes `[REDACTED]`, at every nesting depth (≤6) and inside arrays (≤50 head + marker).
- **Size bounding**: strings >512 chars truncated, stacks truncated to 5 frames/400 chars, messages to 200 chars — a runaway object cannot DoS the console.
- **Levels**: `ASAS_LOG_LEVEL=debug|info|warn|error` (default: debug in dev, info in production). At info+, successful request lines are silent; warnings/errors always surface.
- **`errorFields()`**: bounded diagnostics for any throwable (Errors → name/bounded message/5-frame stack; objects → redacted shape; scalars → stringified).

### 2.2 Process metrics store — `src/lib/server/obs.ts` (NEW)
- Per-route ring buffer (last 256 durations) → `count / errors / avgMs / p50Ms / p95Ms / maxMs`; **linear-interpolated percentiles**.
- Route keys are **normalized patterns** (`GET /api/leads/:id`) — bounded key space, **no record ids in metric labels** (verified by a live contract assertion).
- Error counters by stable **category** (never by message). Bounded memory: ≤200 route keys + fixed ring sizes.
- **Single-instance law documented**: numbers describe this process; the deployment model is single-instance (P1 law); a horizontal deploy needs a shared store — explicitly out of P2 scope (no Redis by default).

### 2.3 Request correlation — `src/proxy.ts` (NEW; Next.js 16 convention)
- The dev log itself surfaced the Next 16 convention change: *"The 'middleware' file convention is deprecated. Please use 'proxy' instead"* — implemented as `src/proxy.ts` exporting `proxy()` (matcher `/api/:path*`).
- Stamps on every API request: `x-request-id` (accepted from a trusted edge when well-formed `[A-Za-z0-9._-]{8,64}`, **else generated** — garbage ids are replaced, closing the log-forgery-via-id channel), `x-asas-route` (normalized pattern), `x-asas-method`, `x-asas-request-start` (epoch-ms).
- Edge-runtime safe (`crypto.randomUUID`, no Node APIs). Pages/static assets excluded — observability scope = API operations per the mission.

### 2.4 Response-builder integration — `src/lib/server/session.ts` (`ok()`/`fail()`)
- `ok()`/`fail()` became async and now: read the proxy stamps (`requestContext()`), **measure the true route-execution latency** (proxy stamp → response build), record metrics, echo `x-request-id` on EVERY response (200s, 401/403/404/409/429s, catch-all 404s), and emit the structured line.
- **Error categories** (`categorizeError()`): `AUTH | AUTHZ | VALIDATION | NOT_FOUND | CONFLICT | RATE_LIMIT | DEMO_GATE | DB | INTERNAL` — mapped from ApiError codes/statuses + duck-typed Prisma codes (P2002→CONFLICT, P2025→NOT_FOUND, other P####→DB).
- `fail()` logs `event:"api_error"` with requestId+route+category+bounded diagnostics; **client bodies byte-identical to before** (F-09 law preserved — 500s stay generic client-side; full detail server-side only).
- 5 non-`return` call sites updated (`await ok(...)`): dashboard, login ×2, logout, analytics; + 1 `fail()` site (public lead-capture Retry-After).

### 2.5 Health v2 — `src/app/api/health/route.ts`
- Kept the pinned P0 envelope **byte-identical** (status/dbOk/migrations/demoMode/demoModeMisconfigured/sessionSecretConfigured/checkedAt) — additive law.
- Added: `dbLatencyMs` (measured connectivity probe duration), `uptimeSec`, `nodeEnv`, `rssMb`.
- **Deliberately NOT on the public probe**: request counters/per-route metrics (attack-surface metadata) — those live behind auth.

### 2.6 `/api/metrics` (NEW, ADMIN+ only)
- Full obs snapshot (uptime, totals, per-route p50/p95, errors by category) + `dbLatencyMs` + memory (`rss/heapUsed/heapTotal`).
- RBAC-gated: anonymous → 401; SALES_AGENT → 403 FORBIDDEN_ROLE; ADMIN → 200 (all verified live).

## 3. Sensitive-information protection (P2 mission §3 A1 — "Never log")

Enforced **in code + tests**, not convention:
- `tests/unit/logger.test.ts` (12 tests): top-level + nested + array redaction of password/sessionSecret/authorization/cookie/token/apiKey/privateKey patterns; size bounding (depth/arrays/strings); defensive Error serialization; non-Error throwables redacted.
- The only values the observability path handles are: request ids, route patterns, methods, statuses, durations, categories, cuid identifiers, memory numbers. **No customer payloads, no names, no financial values enter the log path by construction.**
- Residual documented risk: Prisma error *messages* may embed fragments of failing query args — bounded to 200 chars, server-console only, never in client bodies (F-09), access-controlled environment.

## 4. Sentry / external monitoring evaluation (mission requirement)

**Decision: NOT installed, not connected.** Reasons (all mission-compliant):
1. Zero credentials exist for any monitoring provider (entry-gate item 11).
2. The mission forbids connecting an external provider "without verifying compatibility and obtaining the necessary project configuration".
3. The JSON-lines foundation is **shippable**: any future Sentry/OTLP shipper consumes these lines without application changes — observability value now, integration decision deferred with a clean seam.
4. Privacy: routing customer-adjacent error data to a third party deserves an explicit data-processing decision, not a default.

## 5. Live evidence (fresh, this session)

- Server restarted post-OOM with the orphaned-subshell pattern + `NODE_OPTIONS=--max-old-space-size=1536` (incident #1 in the execution log).
- `GET /api/health` → `{"status":"ok","dbOk":true,"dbLatencyMs":34,"migrations":23,…,"uptimeSec":5,"nodeEnv":"development","rssMb":477}` — v2 fields live.
- Correlation chain (curl): generated UUID on bare request ✓; `edge-trace-12345678` echoed ✓; garbage id replaced by UUID ✓; 404 catch-all carries id ✓; 401 carries id ✓.
- Structured error line observed in `dev.log`:
  `{"ts":"…","level":"error","event":"api_error","requestId":"7a2c732b…","route":"/api/notifications","method":"GET","status":401,"category":"AUTH","code":"NO_SESSION","errorName":"Error","errorMessage":"No active session…","errorStack":"…[truncated 548]"}` — the SAME id as the response header.
- Structured request lines: `{"level":"debug","event":"http_request","requestId":"47497d20…","route":"/api/auth/login","method":"POST","status":200,"durationMs":194}`.
- `/api/metrics` as ADMIN: per-route p50/p95 (`POST /api/auth/login` 194 ms first-hit, `GET /api/metrics` 81 ms), `errorsByCategory:{AUTH:1}`, memory — **and no cuid/uuid in any route key** (asserted).

## 6. Test evidence

| Suite | Tests | Covers |
|---|---|---|
| `tests/unit/logger.test.ts` | 12 | redaction depth/patterns, level filtering, channels, error fields bounding |
| `tests/unit/obs.test.ts` | 4+1 | percentile math (known samples), ring-buffer boundedness (400→last 256), method/route keys, category counters, route normalization |
| `tests/contract/observability.test.ts` | 9 | live correlation chain (echo/generate/replace/404/401), metrics RBAC (401/403/200 + shape + no-id-labels), health v2 envelope + no counters leak |

**Full gate: 707/707 (38 files)** — includes the entire P0/P1 suite (no regression; tsc 0 errors; eslint 0 errors, 37 tolerated warnings unchanged).

## 7. Limitations / follow-ups

- Metrics are process-local (single-instance law) — a future multi-instance deploy needs a shared sink; decision documented, not defaulted to Redis.
- First-hit dev compilation inflates the first request's latency per route (ring buffers smooth this; Wave 4 baselines use warm requests).
- `ok()`/`fail()` measure middleware→response-build; responses streamed outside these builders (none exist today) would be unmeasured.
- The dev-server OOM incident class persists (2.3 GB RSS reaped once this session); mitigation = heap cap on relaunch + the orphaned-subshell daemonizer (documented in the execution log).
