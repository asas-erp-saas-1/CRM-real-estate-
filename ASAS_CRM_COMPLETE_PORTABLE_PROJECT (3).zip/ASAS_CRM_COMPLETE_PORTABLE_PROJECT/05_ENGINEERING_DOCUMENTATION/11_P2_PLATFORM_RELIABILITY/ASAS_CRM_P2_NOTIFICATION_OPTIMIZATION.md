# ASAS CRM — P2 Notification Optimization (Wave 3 / Agent 4)

**Status: VERIFIED** (measured before AND after; suite 761/761) · Date: 2026-11-06

---

## 1. Measure first: the ACTUAL polling cost (entry-gate, live server)

The mission said: *"Investigate the reported notification polling cost of approximately 11 database queries per minute per active tab. Do not assume the previous measurement is still valid."* — Good call: it was **understated**.

Fresh measurement (Prisma `log:['query']` lines in dev.log, bounded windows around single requests):

| Caller | Queries per poll | Frequency before P2 | Load |
|---|---|---|---|
| MANAGER persona | **35–40** | fixed 60 s × every active tab | ~35–40 q/min/tab |
| SALES_AGENT persona | **16–21** | fixed 60 s × every active tab | ~16–21 q/min/tab |

Poll composition (manager): 1 settings read + 7 parallel aggregates + 9–13 conditional count/list queries (incentives/closure/reconfirm/field-decision/duplicates/overdue/uncontacted) + expiry sweep reads.

Other pre-P2 facts: `refetchOnWindowFocus:true` fired a full recomputation per refocus per tab; every tab had its own poller and its own QueryClient (no cross-tab dedup); TanStack's default `refetchIntervalInBackground:false` already paused background tabs — the cost was per **active** tab, exactly as the mission phrased it.

## 2. What was implemented

### 2.1 Scoped TTL cache — `src/lib/server/notification-cache.ts` (NEW)
- **One TTL bucket per visibility scope**, never per bare user identity: all MANAGER+ ranks share `org:${orgId}` (they see the identical org-wide payload); SALES_AGENT → `agent:${orgId}:${id}`; FIELD_REP → `field:${orgId}:${id}`. The key derives from the same visibility primitives the route uses — **two users who would see different data can never share a bucket** (unit-tested).
- **TTL = 30 s** — exactly the client `staleTime` (the freshness contract the UI already promised). Mutation-triggered refetches within the window see ≤30 s of aggregation lag — identical to the pre-existing tolerance.
- Bounded (≤64 entries, LRU-trimmed), lazy expiry, hit/miss counters exposed on `/api/metrics`.
- `globalThis`-anchored singleton — the db.ts pattern — after live evidence showed Turbopack dev-mode route chunks holding **duplicate module instances** (the notifications route had a working cache while /api/metrics saw a fresh empty one). Dev and prod now share one instance.
- The route's payload is byte-identical; RBAC, visibility semantics unchanged; the expiry sweeper runs on misses only (the in-process scheduler keeps sweeping independently).
- **Process-local by design** — no Redis, no pub/sub (mission rule; single-digit-user workload).

### 2.2 Adaptive + visibility-aware client polling — `use-notifications.ts`
- `refetchInterval` is now a **function of the last payload** (pure, exported, unit-tested): any urgent/warning → **60 s** (attention state needs freshness); quiet book (info-only/empty/unloaded) → **300 s**.
- `refetchIntervalInBackground: false` — now explicit and source-scan-guarded by a test (background tabs cost **zero** queries; TanStack default made explicit so a future edit cannot silently regress it).
- `refetchOnWindowFocus: true` + `staleTime: 30_000` unchanged — refocus stays instant, and the server cache now absorbs refocus bursts across tabs.

### 2.3 SSE / WebSockets / Redis — evaluated and rejected (documented decision)
- WebSockets: explicitly forbidden by the mission absent demonstrated need; also blocked by the sandbox's single-port gateway topology.
- SSE: would hold a long-lived connection per tab and demand invalidation plumbing across mutation routes; the measured load (single-digit users, slow-moving aggregates) is served by polling + TTL dedup at a fraction of the operational complexity. Revisit trigger documented: >30 concurrent actives or sub-10 s freshness requirements.

## 3. Measured AFTER (same methodology)

| Scenario | Before | After | Note |
|---|---|---|---|
| Cold poll (cache miss, manager) | 36 queries | 36 queries | ≤1 miss per scope per 30 s |
| **Warm poll (cache hit)** | 36 | **2** (auth lookup only) | `generatedAt` replayed verbatim — the externally observable hit signal (contract-tested) |
| Quiet book, active tab | 36 q/min | **7.2 q/min** (36 per 300 s) | 5× reduction |
| Attention state, active tab | 36 q/min | 36 q/min (1 miss + 1 hit per 60 s ≈ 38) | honest: attention data changing → recompute is the correct cost |
| N aligned tabs (opened together) | N × 36/min | ~36 + 2(N−1)/min | 63% reduction at N=3 |
| Background tabs | 0 (already default) | 0 (now explicit + guarded) | codified |
| Refocus storm (N tabs refocusing within 30 s) | N recomputations | 1 recomputation + N−1 hits | burst absorption |

**Honest limitation:** a single active tab polling at 60 s in attention state gains nothing from a 30 s TTL (every poll is a miss by design — TTL < interval preserves the freshness contract). The cache's deterministic wins are multi-tab dedup, refocus-burst absorption and cross-suite/query sharing; the single-tab lever is the adaptive cadence. Raising TTL above the poll interval was rejected: it would break the 30 s mutation-freshness tolerance ("I completed the task but the bell still shows it").

## 4. Test evidence

| Suite | Tests | Covers |
|---|---|---|
| `tests/unit/notification-cache.test.ts` | 13 | TTL hit/expiry (lazy eviction), overwrite, LRU bounding (touch + trim), delete/clear, **scope-key isolation** (manager-ranks share, agents per-user, field scope, org isolation), adaptive cadence pure function (60 s/300 s boundaries), TTL=staleTime contract, quiet-cadence multiple-of-TTL, source-scan guard for the poll options |
| `tests/contract/notification-optimization.test.ts` | 5 | live: same-manager rapid polls replay identical `generatedAt` (TTL hit), manager-vs-agent rapid polls compute independently + agent payload excludes manager-only groups (no cross-visibility leakage), payload shape + severity ordering unchanged, 401 stays 401 (cache never bypasses auth), cache stats on /api/metrics |

**Full gate: 761/761 (43 files)** — includes the entire P0/P1 suite.

## 5. Duplicate-notification / multi-tab behavior (mission test list)

- Notification creation/dedup: the payload is computed from domain state (no persisted notifications to duplicate); group keys are stable (`tasks-overdue`, …) — unchanged.
- Read/unread + counters: client-side keyed by the same stable group keys — unchanged.
- Multiple tabs: each tab keeps its own React Query cache (read-state per tab), while the server collapses their recomputations within the TTL — the measured multi-tab table above.
- Background tabs: zero polls (explicit law).
- Network interruption/reconnection: TanStack retry + refetchOnWindowFocus; the server cache serves the first successful response after reconnection.
