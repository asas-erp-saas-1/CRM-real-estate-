# ASAS CRM — P2 Session Governance & Rate Limiting (Wave 2 / Agent 2)

**Status: VERIFIED** (live-server evidence below; suite 731/731) · Date: 2026-11-06

---

## 1. What existed before (entry-gate findings)

| Surface | Before | Gap (P2 mission language) |
|---|---|---|
| Logout | Cleared the client cookie only | **No explicit session revocation** — a stolen cookie copy survived logout for up to 7 days |
| Session lifetime | 7-day absolute expiry + `passwordChangedAt` invalidation | No user-driven termination, no admin kill switch, no account security event trail |
| Login rate limiting | In-memory Map (5 failures / 15 min → 429) | **Process-local** (multi-instance-blind) and **reset on every restart** — an attacker got a fresh 5-try budget per deploy. **P1 finding F1: zero automated tests** |
| Security events | LOGIN / LOGIN_QUICK / LOGOUT audit rows | No LOGIN_FAILED / LOGIN_LOCKED trail |

## 2. What was implemented (real source changes)

### 2.1 Migration #24 (`20261106030000_p2_session_governance`) — deployed live
- **`RevokedSession`** — the exact-pair exception list for the stateless HMAC cookie: `(userId UNIQUE, issuedAtMs BIGINT)` + `reason` (LOGOUT/REVOKE_ALL/ADMIN_REVOKE) + `revokedAt` + inert-row sweep index. FK RESTRICT (house style).
- **`User.sessionsRevokedAt`** — the revoke-all watermark.
- **`LoginFailure`** — DB-backed lockout persistence: `(email, at)` composite index IS the 15-minute sliding-window scan; `(at)` serves the W3/A3 diagnostic retention sweep.
- Health now reports `migrations:24` (contract pins ratcheted 23→24 in the same change).

### 2.2 Explicit session revocation (`src/lib/server/session.ts` + routes)
- **`getCurrentUser()` now rejects three revocation classes**, all piggybacked on the user query it already performs (**zero extra round-trip per request**):
  1. `passwordChangedAt` (existing F-05), 2. `sessionsRevokedAt` watermark (revoke-all), 3. exact `(userId, issuedAtMs)` pair via a filtered select on the composite unique index (logout).
- **`POST /api/auth/logout`** writes the exact-pair revocation row (idempotent upsert) + audits LOGOUT + opportunistically sweeps inert rows (>8 days). **The replay-attack hole is closed**: a stolen pre-logout cookie no longer authenticates.
- **`POST /api/auth/sessions/revoke-all`** (NEW) — two authority modes:
  - *Self*: any authenticated user kills every session of their own account (lost device); current cookie cleared.
  - *ADMIN+*: force-terminate another user's sessions — **same-org only** (404 no-oracle for missing/foreign-org targets), role-gated (403 for SALES_AGENT), audited as SESSIONS_REVOKED.
- **`GET /api/auth/session`** now carries self-scoped `session: { issuedAt, expiresAt }` (additive).
- **UI**: `src/components/crm/settings/sessions-section.tsx` — the Settings "Sécurité des sessions" card: session dates (7-day law visible), two-step inline confirm (a11y-safe, no window.confirm), 44px touch targets, i18n FR/EN/AR.

### 2.3 DB-backed login lockout (`src/lib/server/auth.ts` rewritten)
- Same semantics (5 failures / 15 min → 429 ACCOUNT_LOCKED with retryAfterMs; success clears), now persisted in `LoginFailure`:
  - **Survives restarts** (in-memory window reset gave attackers a fresh budget per deploy),
  - **Holds across any future instance count** — the shared-store decision WITHOUT Redis (SQLite is the shared store; write volume is a handful of rows per attack),
  - One indexed range scan per check, one insert per failure, opportunistic 1-hour sweep per email.
- Bounded email storage (200 chars) — attacker probe strings are not free text.
- `recordFailure(email, ip)` keeps the IP for the security trail.

### 2.4 Security event tracking (login route)
- **LOGIN_FAILED** audit row (IP included) for failures on REAL accounts; unknown emails → structured `login_failed_unknown_email` log line (no org exists to audit).
- **LOGIN_LOCKED** audit row on both 429 paths (credentials + demo quick-login).
- **SESSIONS_REVOKED** audit row with mode (SELF/ADMIN) + watermark timestamp.

## 3. The shared rate-limit strategy decision (mission §3 A2)

| Mechanism | Scope | Decision |
|---|---|---|
| Login lockout | Security state | **DB-backed (implemented)** — must survive restarts and hold across instances; volume trivial |
| Public capture limiter (`lead-capture.ts`) | Per-IP abuse on an unauthenticated surface | In-memory, single-instance — **adequate for the verified single-process deployment model** (documented P1 law); a horizontal deploy needs a shared store — the DB-backed pattern from the lockout is the template |
| Copilot limiter | Per-user soft quota on an authenticated surface | In-memory (unchanged) — same reasoning |
| Redis | — | **NOT introduced** — no demonstrated requirement at this workload (mission rule); the DB we already run is the correct shared store when one is needed |

**Multi-instance testability note:** the lockout's shared-store property is exercised cross-process by construction (the DB) — the automated proof is rerun-survivable (the probe email stays locked across separate vitest processes/runs, observed live this session). A true two-instance live topology is out of scope in this single-port sandbox and honestly marked untested-in-topology, not claimed.

## 4. Test evidence

| Suite | Tests | Covers |
|---|---|---|
| `tests/unit/session-cookie.test.ts` | 10 | sign/verify round-trip, 7-day expiry law (boundary ±60s), tamper/forgery rejection (raw userId, wrong sig, tampered payload), readSessionIssuedAt shapes |
| `tests/security/session-governance.test.ts` | 14 | **replay attack closed** (pre-logout cookie → 401 + user:null), revoke-all (self two-device, role gate 403, admin cross-user, no-oracle 404), **F1 closed** (429 + retryAfterMs bounds, quick-login respects lockout F-03, window reset on success), session metadata (exact 7-day span), cross-user isolation, LOGIN_FAILED/LOGIN_LOCKED/SESSIONS_REVOKED audit rows via MANAGER+ API |

**Full gate: 731/731 (40 files)** — includes the entire P0/P1 suite; tsc 0 errors; eslint 0 errors (38 warnings — +1 from vitest-config comment count, 0 in product code paths).

## 5. Live evidence (fresh, this session)

- Migration #24 deployed: health `migrations:24` live.
- Manual replay probe: login → logout → **replayed cookie → `/api/notifications` 401 NO_SESSION** and `/api/auth/session` → `user:null` (the 200-with-null shape is the login-overlay contract — the test suite now asserts the correct signal).
- `sessions_revoked` / `user_logout` structured log lines observed in dev.log; `SESSIONS_REVOKED` watermark set on the target user row in DB (queried directly: `sessionsRevokedAt: "2026-11-06T03:05:44.874Z"`).
- DB inspection: `RevokedSession` rows written per logout (BigInt issuedAtMs exact-match), filtered-select resolution verified against the live database.
- Lockout observed surviving a **dev-server restart** mid-session (the failed first governance run left the probe email locked; the post-restart run found it still locked — the feature working, now handled by run-unique probe emails).

## 6. Incidents & fixes during this wave (honest register)

| # | Incident | Handling |
|---|---|---|
| 1 | First governance run: 5 failures — 4 were **wrong test signals** (asserted 401 on `/api/auth/session`, which answers 200+`user:null` for anonymous callers BY DESIGN) | Root-caused by manual curl probe (revocation was working all along); tests re-asserted against protected-route 401 + body null |
| 2 | Lockout probe email pre-locked by the earlier run | Run-unique probe emails + pre-locked-tolerant yacine branch (the persistence IS the feature) |
| 3 | OOM-killer reaped next-server during the full-suite gate (3.2 GB RSS, 38 workers) | **Memory law codified in vitest.config.ts**: `poolOptions.forks.maxWorkers: 12` with the evidence trail in the comment; server restarted (D-042); full gate then passed 731/731 |

## 7. Limitations / follow-ups

- Two-instance live topology untested in this single-port sandbox (shared-store property is DB-backed by construction + rerun-survivable evidence).
- Revocation rows accumulate between sweeps on the write path only (no cron — deliberate; the table stays tiny).
- The sessions card is in Settings (MANAGER-facing surface); SALES_AGENT/FIELD_REP reach the same self-service API — a user-menu shortcut is a P3 candidate.
