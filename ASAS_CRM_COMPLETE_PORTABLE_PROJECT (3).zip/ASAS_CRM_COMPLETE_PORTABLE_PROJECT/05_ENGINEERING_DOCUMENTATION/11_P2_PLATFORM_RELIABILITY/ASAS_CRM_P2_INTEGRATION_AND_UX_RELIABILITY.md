# ASAS CRM — P2 Integration & UX Reliability (Wave 5 / Agent 6)

**Status: attribution VERIFIED (772/772) · email/SMS evaluation DELIVERED, integration honestly BLOCKED** · Date: 2026-11-06

---

## A. Email & SMS (Agent 6A) — evaluation delivered, integration BLOCKED (by evidence)

### A.1 The verified fact
The entry gate found **zero provider credentials** in the environment (`.env` holds only `DATABASE_URL`, `ASAS_SESSION_SECRET`, `ASAS_DEMO_MODE`). The mission's own rule — "Implement only the integration scope supported by approved credentials and provider configuration" — therefore scopes this wave to evaluation + decision. **Nothing is faked**: no outbound link is claimed as an integration, no customer message is sent.

### A.2 The evaluation deliverable
`05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/ASAS_CRM_P2_EMAIL_SMS_EVALUATION.md` (Agent 6A, subagent-delivered — 299 lines, all 9 mandated sections):
- **Email recommendation:** Brevo primary (EU/French-market fit, free tier 300 emails/day covering every volume tier, Node SDK + delivery webhooks), Amazon SES fallback (cheapest at volume).
- **SMS recommendation:** Infobip primary *conditional on a sandbox gate*, Twilio fallback — with **live-verified pricing**: Twilio Algeria outbound = **$0.273/SMS** (checked against the dedicated DZ pricing page this session); Brevo/SES/Postmark tier facts live-verified where publicly reachable.
- Knowledge-based claims (non-Twilio DZ unit prices, tier tables, webhook event enums, alpha-sender registration rules for DZ, law 18-07 specifics) are **marked [KB] must-re-verify** in the document.
- Cost models at 500 / 2,000 / 5,000 messages per channel; requirements matrix; **design-only integration architecture** (adapter interface, DeliveryRecord persistence fields, consent management, template management, retry policy, test-mode sandbox strategy); per-provider credentials checklist; GDPR + Algerian law 18-07 privacy notes.

### A.3 The blocked-status contract
Before ANY implementation begins, the operator must supply §8 of the evaluation (per provider): API key, sender identity verification, webhook endpoint registration, sandbox/test-mode credentials. Until then the honest status in every report is **BLOCKED — awaiting approved credentials**. Message templates, consent handling and delivery-record persistence were designed (not implemented) so the future integration lands on a reviewed contract rather than ad-hoc code.

---

## B. Multi-touch attribution (Agent 6B) — IMPLEMENTED & VERIFIED

### B.1 The model (migration #25, deployed live — health `migrations:25`)
`LeadTouch`: `channel` (TOUCH_CHANNELS closed vocabulary — the SOURCES interaction channels + EMAIL/SMS/OTHER), `direction` (INBOUND customer-initiated / OUTBOUND our follow-up), bounded `note` (500) + `campaign` (120), `actor`, `occurredAt` (its own clock — backdating capped at 1 year, future dates rejected), indexes `(orgId, leadId, occurredAt)` + `(orgId, channel)`. FK RESTRICT (house style).

### B.2 The mission's attribution vocabulary — where each concept lives
| Concept | Implementation |
|---|---|
| **Original lead source** | `Lead.source` — IMMUTABLE via the API: the PATCH schema has no `source` field and unknown keys are dropped (zod). **Guard-tested**: PATCHing `{source}` leaves it byte-identical; touches never touch it (separate table, separate API) |
| **First touch** | earliest INBOUND LeadTouch; falls back to lead creation (explicit `firstTouchIsFallback` flag) |
| **Subsequent interactions** | the LeadTouch history (desc, take 100) |
| **Conversion attribution** | last INBOUND touch before each winning reservation's creation — `GET /api/analytics/attribution` → `conversionAttribution` (with honest `fallbackToOriginalSource` count for historical leads without touches) |
| **Campaign attribution** | the `campaign` marker field on touches (bounded, optional) |

### B.3 The surfaces
- **`POST /api/leads/:id/touches`** — visibility-scoped (`leadScope`: agents touch their own/unassigned leads; foreign = no-oracle 404), closed-vocabulary validation, honest-date guard, audited (`LEAD_TOUCH_RECORDED`).
- **`GET /api/leads/:id/touches`** — touch history + the attribution summary (original source + first touch).
- **`GET /api/analytics/attribution`** (MANAGER+) — the source-effectiveness report: original-source funnel (leads → opportunities → won → revenue → conversion %), per-channel engagement (inbound/outbound), conversion attribution.
- **UI** — `LeadAttributionCard` in the drawer's Aperçu tab (after the activity composer): immutable-source lock chip, first-touch line, last 5 touches, add-touch form (channel + direction + note, 44px targets, FR/EN/AR i18n). Query key `qk.lead.touches(id)`.

### B.4 Test evidence — `tests/security/attribution.test.ts` (11 tests, live)
Recording (201 + shape, closed-vocabulary 422s, honest-date 400s, foreign-lead no-oracle 404, 401); the attribution summary (INBOUND first-touch resolution); **the immutability law (2 tests)**; the analytics surface (funnel with non-zero revenue on the seeded book, engagement rows reflecting this suite's own touches, conversion attribution math, 403/401 RBAC). Full gate: **772/772 (44 files)**; contract migration pins ratcheted 24→25.

### B.5 Implementation incidents (honest)
- esbuild JSX parsing quirk: interpolated template literals as `t()` keys inside nested JSX expression sequences produced misleading cascading parse errors — root-caused by minimal repro, fixed by plain string concatenation in JSX expressions (documented in the component).
- The analytics route initially assumed `Reservation.value`/`Opportunity.source` — the schema truth is `amount` and lead-level source; corrected against the schema before any test ran.

---

## C. UX & accessibility refinement (Agent 6C — Wave 6)

Delivered in Wave 6 (next section of the execution log): RTL hydration flash root-cause fix, heading hierarchy, Sonner a11y, dialog focus verification, reduced-motion preference, and the deferred touch-target sweep. See `ASAS_CRM_P2_EXECUTION_LOG.md` → Wave 6 for the verified evidence; the complete findings live in this report's Wave-6 addendum below (added after Wave 6 closes).

---

## D. Honest limitations

- Email/SMS: integration BLOCKED pending credentials (verified fact); the design is reviewed but unimplemented BY RULE, not by omission.
- Conversion attribution for the 7 seeded won deals falls back to the original source (they predate the touch system) — the fallback is counted and surfaced (`fallbackToOriginalSource: 7`), never hidden.
- `campaign` is a free-form marker; a structured campaign entity (with spend/UTM tracking) is a P3 candidate if reporting demands it.
