# ASAS CRM — P2 Data Retention Implementation (Wave 3 / Agent 3)

**Status: VERIFIED** (live dry-run + refusal gate exercised; suite 761/761) · Date: 2026-11-06

---

## 1. Investigation (what exists, what grows)

| Store | Current volume (measured live, this session) | Growth driver |
|---|---|---|
| AuditLog | **635 rows**, oldest 2026-08-20 | every audited mutation + auth events (LOGIN_QUICK per persona switch, LOGOUT, and — new in P2/W2 — LOGIN_FAILED/LOGIN_LOCKED/SESSIONS_REVOKED) |
| Activity | **187 rows**, oldest 2026-07-30 | the business timeline (notes/calls/status changes per lead touch) |
| LoginFailure | 39 rows | failed-login probes (P2/W2); swept opportunistically at 1 h |

Business/legal constraints weighed (documented reasoning, not invented numbers):
- **Financial/commercial traceability** (payments, closures, price changes, reservations, imports, merges, user administration, security administration) — must be retained indefinitely: Algerian real-estate transaction disputes operate on horizons far beyond any operational need.
- **Operational history** (the day-to-day timeline) — sales cycles run months; 24 months preserves year-over-year comparability while bounding the table.
- **Diagnostic noise** (failed/locked/quick logins, logouts, lockout bookkeeping) — a 90-day window covers any realistic security-incident investigation; the security-RELEVANT auth events (password change, session revocation, user administration) are classified PROTECTED, not diagnostic.
- **Backup/recovery** interplay: the P1 backup system (VACUUM INTO + verified manifest) is the recovery floor; the retention apply gate builds directly on it.

## 2. The documented retention classes (`src/lib/server/retention.ts`)

| Class | Horizon | Action | Population |
|---|---|---|---|
| **PROTECTED** | forever | KEEP | All AuditLog actions EXCEPT the four diagnostic ones (conservative default: unlisted → PROTECTED); Activity types PAYMENT / RESERVATION / CONVERSION / MERGE / INCENTIVE / SAV / DOCUMENT |
| **OPERATIONAL** | 730 days | ARCHIVE_THEN_DELETE | All other Activity types (notes, calls, status changes, visits, tasks…) |
| **DIAGNOSTIC** | 90 days | DELETE | AuditLog actions LOGIN_FAILED / LOGIN_LOCKED / LOGIN_QUICK / LOGOUT; the whole LoginFailure table |

**The safety invariant (tested):** the deletion WHERE-clauses are built from these lists — `action IN (diagnostic)` and `type NOT IN (protected)` — so a PROTECTED row is **unreachable by construction**, not by convention. Unlisted future actions/types default to the SAFE class (audit → PROTECTED, activity → OPERATIONAL).

## 3. The mechanisms

### 3.1 Dry-run (always safe): `bun run retention:dry`
Full JSON report: per-store totals, class breakdowns, eligibility counts (the EXACT where-clauses apply would use), oldest-record stamps, 5-row redacted samples (action/entity/date — no customer payloads), the policy itself, and the apply-guard status. **Live output this session:** 635 audit (97 diagnostic / 538 protected, **0 eligible** — all rows younger than 90 days), 187 activity (123 operational / 64 protected, **0 eligible**), 39 LoginFailure (0 eligible), guard `freshBackupFound:false`.

### 3.2 Apply (operator-only, triple-gated): `bun run retention:apply --confirm-purge`
1. **Typed confirmation**: without `--confirm-purge` the script prints the dry-run and exits — **verified live** (the flag reached the script and the backup gate refused before any DB call).
2. **Fresh-backup gate** (inside `retentionApply`, not the CLI — cannot be bypassed): a manifest-verified backup (`integrity === "ok"`) younger than 15 minutes MUST exist, else REFUSE — **verified live: `REFUSED: no verified backup younger than 15 minutes… Run bun run db:backup first`** with exit 1 and zero DB calls (unit-asserted).
3. **Archive-first**: every to-be-deleted row is written to `db/backups/retention-archive-<ts>/*.jsonl` (per class) BEFORE the deletes — belt-and-braces on top of the DB backup.

Additional laws: apply is a CLI, **never an API route** (no remote destructive surface); no background automation exists (mission §5); the original `db/custom.db` is never destructively "restored over" (P1 law).

### 3.3 Wiring notes
- `retention.ts` is dependency-injected (`RetentionDb` parameter — a `Pick` of the Prisma model surface): the script passes its own `PrismaClient` (a plain-bun script cannot import `@/lib/db` whose `server-only` guard is a Next-bundler alias — root-caused and documented in the module), and the unit suite passes test doubles. This also keeps the module pure for future reuse.
- `findFreshBackup` reads the P1 backup system's manifests directly (integrity + ts + runId) — reusing the existing verified artifact rather than a new bookkeeping mechanism.

## 4. Test evidence

| Suite | Tests | Covers |
|---|---|---|
| `tests/unit/retention.test.ts` | 12 | classification (incl. conservative defaults + vocabulary-membership guard), policy horizons, **WHERE-clauses cannot match PROTECTED rows**, backup-gate fixtures (fresh/failing-integrity/stale/newest-of-several), apply REFUSES with zero DB calls, dry-run math on a fake db (counts/classes/eligibility verbatim) |

Live operator evidence (this session): dry-run report printed above; apply-refusal exercised with exit 1; no row was deleted (eligibility = 0 — the demo data is younger than every horizon, which is the safest possible first run of the mechanism).

**Full gate: 761/761 (43 files).**

## 5. Honest limitations

- The apply path has NOT deleted real rows in this session (nothing is eligible yet — the seed is weeks old, horizons are 90/730 days). The mechanism is verified by: unit tests of every invariant, the live refusal gate, and the dry-run's exact-where-clause accounting. The first real eligibility window (oldest diagnostic rows, ~90 days from 2026-08-20) arrives ≈ 2026-11-18.
- Retention is operator-run; an scheduled automation was deliberately NOT built (mission §5: no background automation without explicit approval). If the operator later approves scheduling, the cron tool can wrap `retention:dry` with alerting — the gate design already supports it.
- `LoginFailure` rows are swept opportunistically on writes (1 h) — the retention apply is the belt-and-braces backstop, not the primary cleaner.
