# ASAS CRM — P2 Email & SMS Provider Evaluation (W5-1 / W5-2)

| | |
|---|---|
| **Mission** | ASAS CRM Phase 2 — transactional notifications: visit reminders, reservation-expiry warnings, payment confirmations |
| **Tasks** | W5-1 (email providers), W5-2 (SMS providers with Algeria +213 focus) |
| **Agent** | 6A — RESEARCH-ONLY. No source code modified, no packages installed, no messages sent. |
| **Stack context** | Next.js 16 + Prisma 6 + SQLite, French-first UI (Arabic RTL), DZD, WhatsApp-first product; ~500–5,000 messages/month/channel |
| **Date** | 2026-11-06 |
| **Cross-refs** | `ASAS_CRM_P2_MASTER_EXECUTION_PLAN.md` (W5), `ASAS_CRM_P2_NOTIFICATION_OPTIMIZATION.md` (in-app notifications only — different scope) |

**Verification legend — applies to every claim below:**

- **[LIVE]** — verified against the live provider website/API during this session (2026-11-06, HTTP fetch)
- **[REACH]** — provider domain/page reachable this session, but content is JS-rendered; unit prices not extractable
- **[KB]** — training-knowledge claim (knowledge cutoff ≈ 2025); **must be re-verified at the provider's pricing/docs pages before purchase**
- **[CRED-BLOCKED]** — requires account credentials; not verifiable in this environment (probed where possible)

> **HONEST STATUS — INTEGRATION BLOCKED PENDING CREDENTIALS.**
> No provider credentials exist in this environment. This is a **verified fact, not an assumption**: an environment-variable scan and an inspection of `.env` / `.env.example` key *names* (values never printed) found **zero** Brevo / SendGrid / SES / Twilio / Vonage / Infobip / Bird / Mailgun / Postmark keys — `.env` contains only `DATABASE_URL`, `ASAS_SESSION_SECRET`, `ASAS_DEMO_MODE` (cross-verified against the P2 master plan environment audit, finding #11, status VERIFIED). This document is an **evaluation + decision** deliverable only; implementation cannot begin until an operator supplies the checklist in §8.

---

## 1. Executive summary

| Channel | Primary | Fallback | Contingency |
|---|---|---|---|
| **Email** | **Brevo** (ex-Sendinblue) | **Amazon SES** (EU region) | SendGrid (if single-vendor consolidation with Twilio is ever preferred) |
| **SMS (+213)** | **Infobip** — *conditional on sandbox validation gate* | **Twilio** (price already LIVE-verified: $0.273/SMS to Algeria) | Local Algerian aggregator (RFQ — potentially cheapest + best DZ delivery, unverified) |

**Rationale (short):**

- **Email — Brevo:** French/EU provider (best GDPR + Algerian law 18-07 transfer posture), free tier of **300 emails/day [LIVE]** already covers all three ASAS volume tiers, first-class transactional REST API (endpoint live-checked, 401 without key [LIVE]) + official Node SDK, hosted templates, delivery webhooks. **Amazon SES** is the cost-floor fallback (**$0.11–$0.23 per 1,000 emails by region [LIVE]**, EU regions selectable) at the cost of higher ops overhead (IAM, SNS, production-access request).
- **SMS — Infobip:** EU-based (Croatia) aggregator with deep MENA routing; Algeria present in its pricing selector **[LIVE]** but unit price is account-gated **[CRED-BLOCKED]** — hence the *conditional* primary. **Twilio** is the verified fallback: public page confirms Algeria coverage and a **$0.273/SMS outbound list price [LIVE]**, best-in-class Node SDK. Switch primary to Twilio if Infobip's written DZ quote is ≥ $0.27 or its 50-message sandbox test delivers < 90%.
- **At 500–5,000 messages/month, every provider evaluated handles the volume trivially.** The real differentiators are (a) Algeria delivery quality and DLR depth for SMS, (b) EU/data-protection posture, (c) ops simplicity, (d) SMS unit price — in that order, because a missed visit costs ASAS more than a year of SMS for that client.

**Decision gates before final lock-in (run in sandbox once credentials exist):**
1. Email deliverability seed test (Brevo vs SES) across major mailbox providers.
2. SMS live test: **50 messages to consenting DZ numbers** (Infobip vs Twilio): delivery %, latency, DLR completeness.
3. Re-verify every **[KB]**-marked price at the provider's pricing pages on the purchase day.

**Status: INTEGRATION BLOCKED pending credentials (see §8).**

## 2. Evaluation methodology + verification status

This agent had shell access only (no browser/search tool). Live verification was **attempted** via HTTP fetch (curl) of provider pricing pages and public APIs. Results:

| Probe (2026-11-06) | Result | Verification gain |
|---|---|---|
| `brevo.com/pricing` | HTTP 200 | Free tier "**300 emails per day**" extracted from page FAQ strings — **[LIVE]**; Lite plan exists but exact price is JS-calculator — **[KB]** |
| `sendgrid.com/pricing` | HTTP 200, but 919-byte JS shell | Page reachable **[REACH]**; all prices **[KB]** |
| `aws.amazon.com/ses/pricing` | HTTP 200 | Regional table extracted: **$0.11 / $0.12 / $0.14 / $0.16 / $0.17 / $0.18 / $0.22 / $0.23 per 1,000 emails** — **[LIVE]**; free tier = 12-month credits **[LIVE]** |
| `mailgun.com/pricing` | HTTP **403** (bot protection) | Not verifiable live — all Mailgun claims **[KB]** |
| `postmarkapp.com/pricing` | HTTP 200 | "**$15/month for 10,000 emails**" and dev tier "**100 emails/month** … never expires" extracted — **[LIVE]**; a $75 figure also present (tier mapping unverified) |
| `twilio.com/en-us/sms/pricing/dz` | HTTP 200, dedicated Algeria page | **Outbound SMS to Algeria: $0.273** (headline price); inbound $0.015/$0.025; "starting at $1.15/mo" numbers; failed-message fee $0.001 — **[LIVE]** |
| `twilio.com/docs/sms/guidelines-algeria` (+ alt URL) | Redirected to docs home | Alpha-sender-ID rules for DZ remain **[KB]** — unverified |
| `vonage.com/communications-apis/pricing/` | HTTP 200 | "Algeria / +213" present in country selector — coverage **[LIVE]**; unit price JS-loaded — **[KB]** |
| `infobip.com/pricing` | HTTP 200 | "Algeria / dz / 213" present in country selector — coverage **[LIVE]**; unit price JS-loaded — **[KB]** |
| `bird.com/en/pricing/` | HTTP 200 | Pricing page exists for email+SMS+WhatsApp — **[LIVE]**; Algeria not present in static HTML — DZ coverage **[KB]** |
| `api.brevo.com/v3/account` | HTTP **401** | Brevo API is live and credential-gated — **[CRED-BLOCKED]** |
| `pricing.twilio.com/v1/Messaging/Countries/DZ` | HTTP **401** | Per-country pricing API requires account auth — per-account prices **[CRED-BLOCKED]** |
| Environment + `.env` key-name scan | none found | No credentials exist here — **[LIVE] fact** |

**Claim discipline:** every table row below carries its verification label. Approximate prices are given as **ranges**, never fake-precise single numbers. Knowledge-cutoff is ≈ 2025; several providers restructured pricing tiers in 2023–2025, so treat **[KB]** prices as ±30–50% until verified. No live sends, no DZ delivery tests, no real webhook inspection were possible — the sandbox validation plan (§7.6, §8) exists precisely to close that gap.

## 3. Email providers comparison

All five are viable at ASAS volumes. "Verify" = check the provider pricing page before purchase.

| Dimension | Brevo (ex-Sendinblue) | SendGrid (Twilio) | Amazon SES | Mailgun (Sinch) | Postmark (ActiveCampaign) |
|---|---|---|---|---|---|
| **Pricing model** | Monthly plan by email volume; contacts unlimited **[KB]** | Plan + per-email overage **[KB]** | Pure pay-per-email + data **[LIVE]** | Plan-based, or Flex pay-as-you-go **[KB]** | Volume bands (per-email) **[LIVE]** |
| **Approx tier pricing** | Free = **300 emails/day [LIVE]**; Lite ≈ $9–25/mo by volume step **[KB, VERIFY]** | Free ≈ 100 emails/day **[KB]**; Essentials ≈ $19.95/mo for ~50k **[KB, VERIFY]**; Pro ≈ $30+/mo **[KB]** | **$0.11–$0.23 per 1,000 emails by region [LIVE]**; attachments ≈ $0.12/GB **[KB]** | No permanent free tier (trial ≈ 5k sends, time-boxed) **[KB]**; Foundation ≈ $35/mo incl ~50k **[KB, VERIFY]**; Flex ≈ $0.80–1.00 per 1,000 **[KB]** | **$15/mo for 10,000 emails [LIVE]**; ≈ $1.25–1.50 per additional 1,000 **[KB, VERIFY]**; dev tier **100 emails/month, never expires [LIVE]** |
| **Free tier fits 500 / 2,000 / 5,000 per month?** | OK / OK / OK (≤300/day incl. bursts; 5,000/mo ≈ 167/day avg) | OK / PARTIAL (≈67/day avg vs 100/day cap → burst risk) / NO | NO (12-month intro credits only) | NO (trial only) | NO (100/mo) |
| **REST API + Node SDK** | v3 REST `api.brevo.com` — endpoint live, 401 without key **[LIVE]**; `@getbrevo/brevo` official **[KB]** | v3 REST + `@sendgrid/mail` official **[KB]** | SESv2 API + `@aws-sdk/client-sesv2` official; SMTP interface too **[KB]** | REST + `mailgun.js` official **[KB]** | REST + `postmark` npm **[KB]** |
| **Webhook delivery-status events** | delivered, opened, clicked, hard_bounce, soft_bounce, blocked, spam, invalid, error, unsubscribe **[KB]** | processed, delivered, deferred, bounce, dropped, open, click, spamreport, unsubscribe; ECDSA-signed webhooks **[KB]** | Bounce / Complaint / Delivery (and Send) via **SNS notifications** to an HTTPS endpoint — not classic webhooks **[KB]** | delivered, failed (temp/permanent), bounced, dropped, complained, unsubscribed, opened, clicked **[KB]** | delivery, bounce, spam complaint, open, click, subscription change **[KB]** |
| **Rate limits** | Free: 300/day hard cap **[LIVE]**; paid higher; API request limits per plan **[KB]** | Free 100/day **[KB]**; plan throughput; API request limits generous **[KB]** | Sandbox: ≈200/day, 1/s → production default ≈ 50k/day & 14/s, region/account dependent, raisable **[KB, VERIFY]** | Plan-based sending limits **[KB, VERIFY]** | ≈300 msgs/min/server default **[KB, VERIFY]** |
| **EU/GDPR hosting posture** | French company, EU infrastructure, GDPR DPA — **best fit [KB]** | US-based; GDPR via DPA/SCCs; regional processing limited **[KB, VERIFY]** | **EU regions selectable** (eu-west-1 / eu-central-1) + AWS DPA — strong **[KB]** | Sinch (Sweden/EU) ownership; EU sending region selectable **[KB, VERIFY]** | US company; EU region option (eu.postmarkapp.com) **[KB, VERIFY]** |
| **Transactional templates** | Hosted editor + API; SMTP relay also **[KB]** | Dynamic templates (Handlebars) **[KB]** | SESv2 JSON templates; no visual editor **[KB]** | Handlebars templates via API **[KB]** | Templates + layouts via API/dashboard **[KB]** |
| **Ops complexity** | Low | Low–medium | **High** (IAM, SNS topics, production-access request) | Medium | Low |
| **Notable caveat** | Branding on free plan; scope API keys narrowly | Aggressive reputation policing — suspension risk if bounces spike | Deliverability depends on your DNS/DMARC hygiene | Live pricing page blocked our probe (403) — least verifiable | Email-only (no SMS) |

**Email notes:**
- **Brevo** is the only EU-headquartered option whose free tier covers all three ASAS tiers; French-language dashboard/docs suit the local team. Production should use paid Lite (branding removed) even where the free tier would numerically fit.
- **Amazon SES** is ~2 orders of magnitude cheaper than everything else at these volumes (5,000 emails ≈ $0.55–1.15/mo **[LIVE]** basis) but costs engineering time: sandbox → production-access request, IAM, SNS wiring. Selected as fallback and future bulk channel.
- **SendGrid** is a solid consolidator (one Twilio account = email + SMS) with excellent docs; the 100/day free cap makes it marginal at 5,000/mo without paying.
- **Mailgun** lost its permanent free tier and its live pricing page blocked automated verification — no decisive advantage at ASAS volumes; deprioritized.
- **Postmark** has arguably the best transactional deliverability and bounce handling, with a **[LIVE]**-verified $15/10k price — but it is email-only and has a $15/mo floor; honorable mention, not selected.

## 4. SMS providers — Algeria (+213) focus

| Dimension | Twilio | Vonage | Infobip | Bird (ex-MessageBird) | Orange Business / local DZ aggregators |
|---|---|---|---|---|---|
| **Algeria (+213) coverage** | OK — dedicated public DZ pricing page exists **[LIVE]** | OK — Algeria (+213) in pricing selector **[LIVE]** | OK — Algeria (dz/213) in pricing selector **[LIVE]** | UNVERIFIED — pricing page live but DZ not in static HTML **[KB]** | Orange Business: international A2P to DZ, quote-based **[KB]**; local aggregators: domestic direct routes **[KB]** |
| **Approx price / SMS to +213** | **$0.273 outbound list price [LIVE, 2026-11-06]**; inbound $0.015–0.025 **[LIVE]**; failed-msg fee $0.001 **[LIVE]**; account-level price may differ **[CRED-BLOCKED]** | ≈ $0.10–0.35 **[KB, VERIFY]** (JS-gated) | ≈ €0.05–0.15 **[KB, VERIFY]** (account-negotiated) | ≈ $0.10–0.30 **[KB, VERIFY]** | Orange: quote; local: DZD tariffs, potentially cheapest — **[KB, RFQ required]** |
| **Alphanumeric sender-ID in DZ** | Reported supported; pre-registration enforcement is operator-dependent and **uncertain — VERIFY** against Twilio's Algeria country guidelines (probe redirected; unverified) | Reported supported; registration via support recommended **[KB, VERIFY]** | Supported; Infobip registers DZ senders where required via account team **[KB, VERIFY]** | Reported supported **[KB, VERIFY]** | Locally registered with Mobilis / Djezzy / Ooredoo — typically reliable for domestic traffic **[KB]** |
| **Delivery-receipt webhooks** | Status callbacks: queued → sent → delivered / undelivered / failed **[KB]** | DLR callback webhooks **[KB]** | Delivery-report push (webhooks) **[KB]** | DLR webhooks **[KB]** | Varies; local aggregators can provide carrier-grade DLR **[KB]** |
| **REST API + Node SDK** | `twilio` npm official; Messaging Service recommended **[KB]** | `@vonage/server-sdk` official **[KB]** | First-class REST; official Node SDK availability **[KB, VERIFY]** | Legacy `messagebird` npm; new Bird platform API — **[KB, VERIFY current SDK]** | Orange Business REST **[KB, VERIFY]**; local: HTTP APIs of varying maturity, some SMPP |
| **Company / data posture** | US (DPA + SCCs needed) | US (Ericsson) | **EU (Croatia)** — best law 18-07 alignment | EU (Netherlands) | France / Algeria — best alignment |

**SMS notes (important):**

- **The only trustworthy per-SMS DZ price obtained is Twilio's public $0.273 [LIVE].** Vonage/Infobip/Bird load per-country prices via JavaScript and/or hide them behind accounts (**[CRED-BLOCKED]** — Twilio's own pricing API returned 401 without credentials). All non-Twilio DZ prices are **[KB] ranges** until a written quote or a logged-in console check.
- **DLR depth in Algeria is operator-dependent:** some international routes return only carrier-level acceptance ("sent") rather than handset "delivered". The 50-message sandbox test (§7.6) is the only honest way to rank providers on this.
- **French accents and GSM-7:** the GSM 03.38 default alphabet natively includes é è à ç É (160 chars/segment), so normal French copy is safe — but **œ, typographic apostrophes/quotes and em-dashes force UCS-2 encoding (70 chars/segment ≈ 2–3× cost)** **[KB]**. SMS templates must be linted for GSM-7 safety.
- **Throughput:** 5,000 SMS/month ≈ 2.5/min average — trivial. Reminder batches should still be paced (≈1–5 msg/s) to respect route pacing and operator anti-spam thresholds **[KB]**.
- **Orange is not an Algerian mobile operator** (DZ market: Mobilis, Djezzy, Ooredoo **[KB]**); the Orange Developer free-tier SMS API only covers Orange footprint countries, so it does **not** apply to DZ recipients. Orange Business (enterprise arm) can still route international A2P to +213 on quote **[KB]**.
- **Local aggregator option:** Algerian A2P is also resold by local aggregators connected to the three operators, with DZD pricing, local alpha-sender registration, and often better domestic DLR — but API maturity, docs and SLAs vary, and procurement requires a local RFQ. **No vendor is named in this document because none could be live-verified from this environment.**

## 5. Requirements matrix vs providers

Legend: OK = meets · PARTIAL = conditional/gap · NO = gap. All cells are design-level judgments from **[KB]** provider documentation; re-verify during sandbox.

**Email:**

| Requirement | Brevo | Amazon SES | SendGrid | Mailgun | Postmark |
|---|---|---|---|---|---|
| Transactional triggers (reminder / expiry / payment) | OK | OK | OK | OK | OK |
| Scheduled sends (T-24h reminders) | PARTIAL — schedule app-side (portable) | PARTIAL — app-side | PARTIAL — `send_at` exists but app-side preferred | PARTIAL — app-side | PARTIAL — app-side |
| Consent / opt-out handling | OK — unsubscribe link + events | PARTIAL — DIY list hygiene | OK — unsubscribe groups | OK — unsubscribe webhooks | OK — subscription-change webhook |
| Delivery records persistence (webhook events) | OK | OK — via SNS | OK | OK | OK |
| Error handling / retry signals | OK — bounce/blocked/invalid | OK — bounce + complaint | OK — bounce/drop/deferred | OK — failed(temp/permanent) | OK — bounce |
| Rate limits at 500 / 2,000 / 5,000 per month | OK all tiers (free ≤300/day **[LIVE]**) | OK after sandbox exit | PARTIAL — 5k needs paid | OK — paid only | OK — $15/mo floor |
| Node SDK + REST | OK | OK | OK | OK | OK |
| EU / GDPR / law 18-07 posture | OK — EU native | OK — EU region | PARTIAL — US + SCCs | PARTIAL — EU region opt-in | PARTIAL — EU region opt-in |
| Templates for French copy | OK — hosted editor | PARTIAL — JSON only | OK — dynamic | OK | OK |

**SMS (Algeria focus):**

| Requirement | Twilio | Infobip | Vonage | Bird | Local DZ |
|---|---|---|---|---|---|
| +213 coverage | OK **[LIVE]** | OK **[LIVE]** | OK **[LIVE]** | PARTIAL **[KB]** | OK |
| Alpha sender-ID (DZ) | PARTIAL — verify registration | PARTIAL — register via account team | PARTIAL | PARTIAL | OK — locally registered |
| DLR webhooks | OK | OK | OK | OK | PARTIAL — varies |
| REST + Node SDK | OK | PARTIAL — REST yes, SDK verify | OK | PARTIAL — SDK verify | PARTIAL — varies |
| Retry/error classification | OK | OK | OK | OK | PARTIAL |
| Volume 500 / 2,000 / 5,000 per month | OK — trivial | OK — trivial | OK — trivial | OK — trivial | OK — contractual |
| EU / 18-07 posture | PARTIAL — US | OK — EU | PARTIAL — US | OK — EU | OK — best |
| STOP / opt-out tooling | PARTIAL — DIY keyword handling app-side | PARTIAL — DIY | PARTIAL — DIY | PARTIAL — DIY | PARTIAL — DIY |

## 6. Cost model at the three volume tiers (APPROXIMATE — labeled)

**Email — estimated monthly cost (provider list prices; excludes DNS/domain/ops):**

| Provider | 500/mo | 2,000/mo | 5,000/mo | Basis |
|---|---|---|---|---|
| Brevo free | $0 | $0 | $0 (≈167/day avg; burst days must stay < 300) | 300/day free **[LIVE]** |
| Brevo Lite (recommended production) | ≈ $9–25 | ≈ $9–25 | ≈ $9–25 | **[KB, VERIFY]** — flat plan |
| SendGrid free | $0 | $0 — burst risk (100/day cap) | — | **[KB]** |
| SendGrid Essentials | ≈ $20 | ≈ $20 | ≈ $20 | **[KB, VERIFY]** |
| Amazon SES | ≈ $0.06–0.12 | ≈ $0.22–0.46 | ≈ $0.55–1.15 | $0.11–0.23 per 1,000 **[LIVE]** |
| Mailgun (Flex PAYG) | ≈ $0.40–0.50 | ≈ $1.60–2.00 | ≈ $4.00–5.00 (or Foundation ≈ $35 flat) | **[KB, VERIFY]** |
| Postmark | $15 | $15 | $15 (dev tier $0 up to 100) | $15/10k **[LIVE]** |

**SMS — estimated monthly cost to +213 (unit prices approximate unless marked LIVE):**

| Provider | ≈ price/SMS | 500/mo | 2,000/mo | 5,000/mo |
|---|---|---|---|---|
| Twilio | **$0.273 [LIVE]** | ≈ $137 | ≈ $546 | ≈ $1,365 (+ $0.001 × failed msgs) |
| Vonage | $0.10–0.35 **[KB]** | $50–175 | $200–700 | $500–1,750 |
| Infobip | €0.05–0.15 **[KB]** | €30–75 | €120–300 | €300–750 |
| Bird | $0.10–0.30 **[KB]** | $50–150 | $200–600 | $500–1,500 |
| Local aggregator (RFQ) | possibly €0.02–0.06 **[speculative]** | €10–30 | €40–120 | €100–300 |

**Cost-model conclusions:**

- Email cost is **negligible** for every provider except Postmark's floor — choose email on deliverability + data posture, not price.
- SMS unit price is the **dominant** variable: at 5,000/mo the spread is ≈ €300 (local route, speculative) vs ≈ $1,365 (Twilio, verified). A 30-minute RFQ to a local aggregator is potentially worth >€500/mo — but only if DLR and delivery rates pass the sandbox gate.
- Reminder economics: a missed visit or a lapsed reservation costs ASAS far more than a year of SMS for that client — **reliability and DLR quality outrank €/SMS.**

## 7. Integration architecture recommendation — DESIGN ONLY

*(No implementation, no code changes in this mission. The sketches below define the contract a future W5-3+ implementation must satisfy. Grounded in the existing stack: Next.js 16 route handlers, Prisma 6 over SQLite.)*

### 7.1 Provider adapter interface (uniform for email + SMS)

```ts
// DESIGN SKETCH ONLY — not implemented, not added to the repo
type Channel = 'email' | 'sms';           // extensible to 'whatsapp' later (product is WhatsApp-first)
type TemplateKey = 'visit_reminder' | 'reservation_expiry_warning' | 'payment_confirmation';

interface SendRequest {
  channel: Channel;
  templateKey: TemplateKey;
  locale: 'fr' | 'ar';
  recipientRef: { clientId: string; address: string };  // address NEVER logged raw
  params: Record<string, string | number | Date>;
  idempotencyKey: string;      // e.g. `visit_reminder:{visitId}:{occurrence}` → duplicate-send guard
  scheduledAt?: Date;          // reminders: send at T-24h
  correlation: { entityType: 'visit' | 'reservation' | 'payment'; entityId: string };
}

interface SendResult { providerMessageId: string; accepted: boolean; rawStatus?: string; }

interface DeliveryEvent {
  providerMessageId: string;
  type: 'delivered' | 'soft_bounce' | 'hard_bounce' | 'complained' | 'failed' | 'dropped';
  occurredAt: string; raw?: string;
}

interface ProviderAdapter {
  readonly providerId: 'brevo' | 'ses' | 'sendgrid' | 'twilio' | 'infobip' | 'dryrun';
  readonly channel: Channel;
  send(req: SendRequest): Promise<SendResult>;
  verifyAndParseWebhook(headers: Headers, rawBody: string): DeliveryEvent[]; // signature check inside
}
```

- Webhook ingestion route: `POST /api/webhooks/notifications/[provider]` — read the **raw body before JSON parsing** (signature verification needs it), respond `2xx` immediately, process events asynchronously.
- One adapter per provider; primary/fallback selection via environment config, per channel, gated by the mode flag below.

### 7.2 DeliveryRecord persistence (SQLite via Prisma — field design only)

| Field | Type | Notes |
|---|---|---|
| `id` | String (uuid) | PK |
| `channel` | String | `'email' | 'sms'` |
| `providerId` | String | `'brevo' | 'ses' | 'infobip' | … | 'dryrun'` |
| `providerMessageId` | String | UNIQUE — webhook join key |
| `idempotencyKey` | String | UNIQUE — duplicate-send guard |
| `templateKey` | String | which template |
| `correlationEntityType` / `correlationEntityId` | String | visit / reservation / payment |
| `status` | String | `queued → sent → delivered | bounced | failed | opted_out` |
| `providerStatusRaw` | String | provider's own enum, for audit |
| `errorCode` / `errorMessage` | String? | sanitized — no PII |
| `attemptCount` / `nextRetryAt` | Int / DateTime? | retry engine |
| `queuedAt` / `sentAt` / `deliveredAt` / `lastEventAt` | DateTime? | lifecycle timestamps |
| `scheduledAt` | DateTime? | reminder T-24h |
| `segments` | Int? | SMS billing units (UCS-2 aware) |
| `consentSnapshotId` | String | FK — proof of consent at send time |

Plus a `WebhookEvent` audit table: `(id, deliveryRecordId, eventType, signatureValid, receivedAt, payloadRedacted)`.

### 7.3 Consent management fields

`ConsentRecord`: `(id, clientId, channel, scope 'transactional' | 'marketing', status 'opted_in' | 'opted_out', source, evidence, capturedAt, updatedAt, optedOutAt)`.

- Transactional operational messages (visit reminders tied to an active reservation) ride on the business relation; **marketing** traffic requires explicit opt-in and one-tap opt-out.
- SMS `STOP` keyword is handled app-side — none of the evaluated providers fully automates opt-out for DZ traffic.
- Every `SendRequest` snapshots consent (`consentSnapshotId`) → auditable "we held consent at send time".

### 7.4 Template management approach

- **Local-first:** templates as versioned code (French copy first, Arabic later), rendered server-side to a provider-agnostic payload. Benefits: portability across primary/fallback providers, diff-reviewable, unit-testable, no vendor lock on copy.
- SMS templates get a GSM-7-safety lint (see §4) so French copy stays 160 chars/segment.
- Provider-hosted templates (Brevo editor) optional later, for marketing blasts only — never for transactional copy.

### 7.5 Retry policy

- **Outbox pattern:** writer persists `DeliveryRecord(status=queued)` and the send job in one transaction; a worker performs the send → at-least-once delivery, `idempotencyKey` dedupes.
- **Transient errors** (network timeout, HTTP 429, 5xx, provider temp-fail): exponential backoff **1 min → 5 min → 30 min, max 3 attempts**, with jitter.
- **Permanent errors** (hard bounce, invalid number, content rejection, opted-out): fail fast, no retry, staff notification.
- Reminder safety margin: schedule at T-24h, retry window closes at T-18h; reservation-expiry warnings triggered by a scheduled sweep of the database, not by user action.

### 7.6 Test-mode / sandbox strategy

| Mode | Behavior |
|---|---|
| `local` | `DryRunAdapter`: persists DeliveryRecord (`providerId='dryrun'`, simulated status), logs to dev console, sends nothing |
| `sandbox` | Provider test facilities: SendGrid `sandbox_mode`; SES sandbox account (verified recipients only); Twilio trial (verified numbers + trial prefix); Brevo → internal test addresses; Infobip → test destinations (VERIFY) |
| `live` | Env-gated + explicit operator action; feature-flagged per channel |

- Webhook signature tests run against recorded signed fixtures — never live webhooks.
- **Go-live gate:** email seed test + the **50-SMS live test to consenting DZ numbers** (Infobip vs Twilio) comparing delivery %, latency and DLR completeness; re-run whenever routes or contracts change.

## 8. Decision + BLOCKED status — operator credentials checklist

> **BLOCKED (verified fact):** none of the items below exist in this environment. Implementation (W5-3+) must not start until an operator provides them.

**Email primary — Brevo:** account with 2FA · API v3 key scoped to transactional email · sending domain verified (SPF/DKIM DNS records — requires DNS admin) · DMARC record · webhook endpoint registered + secret · plan chosen (free vs Lite) · reply-to/bounce addresses · signed DPA.

**Email fallback — Amazon SES:** AWS account · IAM user/role limited to `sesv2:SendEmail` in eu-west-1 or eu-central-1 · domain verified via easy-DKIM CNAMEs · SNS topics (bounce / complaint / delivery) with HTTPS subscription to the app webhook · **production-access request approved** (exit sandbox) · reputation + quota alarms · DPA via AWS Artifact.

**SMS primary — Infobip:** account + API key · base URL/region · **DZ alpha sender registered** · DLR callback URL configured · **written DZ price list** (must beat Twilio's live $0.273) · test credit · DPA.

**SMS fallback — Twilio:** Account SID · API key SID + secret (preferred over static Auth Token) · Messaging Service SID · DZ alpha-sender registration status confirmed · status-callback URL · trial verified numbers (sandbox) · billing top-up + usage alerts · DPA.

**Contingency — local DZ aggregator:** RFQ to 2–3 Algerian aggregators (DZD price, DLR quality, alpha sender, API docs, SLA) · contract + data-processing terms · test route.

**Common prerequisites:** DNS admin access · secrets vault plan (never in git) · outbound egress allowlist to provider API hosts · public HTTPS webhook endpoint with valid certificate · legal review — ANPDP declaration under law 18-07.

## 9. Security / privacy notes

- **No customer data in monitoring:** never log recipient emails/phone numbers or message bodies in application logs, Sentry, or APM — log `deliveryRecordId` only. Provider error strings frequently embed the recipient address → sanitize before persistence/logging. Redact raw webhook payloads (keep truncated/hashed recipient + reference) and purge them on a schedule (e.g., ≤ 90 days).
- **GDPR:** all providers act as processors → signed DPAs are mandatory (all evaluated providers offer them **[KB]**); US-based processors (SendGrid, Twilio, Vonage) additionally require SCCs. Prefer EU-hosted (Brevo, SES-EU, Infobip, Bird) to minimize transfer exposure.
- **Algerian law 18-07 (2018) [KB — requires legal review]:** personal-data processing must be declared to the **ANPDP**; cross-border transfers require authorization/adequacy — EU-based providers (Brevo for email, Infobip for SMS) materially simplify this; keep DPA + transfer records on file. Appoint an internal data-protection referent.
- **Provider data-retention implications:** provider-side activity history is short and plan-dependent (e.g., SendGrid email activity ≈ 3–30 days by plan, Postmark bounce data ≈ 45 days **[KB, VERIFY]**) — the local `DeliveryRecord` table (§7.2) is the durable source of truth for audit; retain it per commercial/audit requirements.
- **SMS content minimization:** no payment amounts or financial details in SMS bodies — reference IDs plus a link into the authenticated app only.

## 10. Next actions

1. Operator obtains **Brevo + Infobip** credentials per §8 (primary path).
2. Run the sandbox validation gates (§7.6): email seed test + 50-SMS comparative DZ test (Infobip vs Twilio).
3. Re-verify every **[KB]**-marked price at the provider pricing pages on the purchase day; obtain Infobip's written DZ quote and compare against Twilio's $0.273 **[LIVE]** anchor.
4. RFQ to local Algerian aggregators (contingency economics + DLR comparison).
5. Only then open the implementation mission (W5-3+) against the §7 design contract.

---
*Research-only deliverable by Agent 6A — ASAS CRM P2, tasks W5-1/W5-2, 2026-11-06. No source code, dependencies, or messages were touched. All approximate prices are labeled; live-verified claims are dated.*
