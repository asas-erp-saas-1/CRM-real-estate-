# ASAS CRM — P2 Performance Engineering (Wave 4 / Agent 5)

**Status: VERIFIED** (measured, not asserted; suite 761/761) · Date: 2026-11-06

---

## 1. Instrumentation implemented (measure-first law)

| Capability | Implementation | Where visible |
|---|---|---|
| API latency per route (p50/p95/max/avg) | proxy.ts start-stamp → `ok()/fail()` → obs ring buffers (W1) | `/api/metrics` (ADMIN+) |
| Request counts + error rate by category | obs counters (W1) | `/api/metrics` |
| **DB query duration histogram** (W4) | db.ts Prisma `$on('query')` events → obs ring (dual-emit log config: stdout lines preserved for the measurement methodology + events for metrics; idempotent attachment — the globalThis singleton survives Turbopack re-evaluations) | `/api/metrics → dbQueries` |
| Notification cache effectiveness (W3) | hit/miss counters | `/api/metrics → notificationCache` |
| DB connectivity latency | timed `SELECT 1` | `/api/health → dbLatencyMs` (public) + `/api/metrics` |
| Memory posture | `process.memoryUsage()` | both |
| Endpoint timing harness | `scripts/perf-baseline.ts` (`bun run perf:baseline`) — N warm requests per endpoint, first-hit (cold) reported separately, machine-readable copy to `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/perf-baseline-*.json` | operator CLI |

**Sentry/external APM:** evaluated and NOT installed (same decision + reasoning as W1: zero credentials, privacy decision deferred, JSON-lines seam ready).

## 2. Measured baselines (live server, seeded MANAGER persona, N=30 warm requests)

Fresh-server run (2026-11-06T03:35Z, `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/perf-baseline-2026-11-06T03-35-14-333Z.json`):

| Endpoint | p50 | p95 | max | cold (first-hit incl. dev compile) |
|---|---|---|---|---|
| GET /api/dashboard | 39 ms | **51 ms** | 110 ms | 162 ms |
| GET /api/analytics?days=30 | 24 ms | **50 ms** | 98 ms | 112 ms |
| GET /api/leads?page=1&pageSize=50 | 15 ms | **24 ms** | 36 ms | 18 ms |
| GET /api/pipeline/stages | 11 ms | **11 ms** | 14 ms | 86 ms |
| GET /api/search?q=cher | 17 ms | **29 ms** | 39 ms | 141 ms |
| GET /api/notifications | 10 ms | **28 ms** | 101 ms | 159 ms |
| GET /api/journey/stats | 14 ms | **15 ms** | 26 ms | 104 ms |

Server-side cross-evidence on the SAME traffic (from `/api/metrics` after the run):
- `dbQueries`: 256 recorded, p50 = 0 ms (sub-millisecond SQLite point/range queries), max = 19 ms.
- `notificationCache`: **hits 30 / misses 1 (97% hit rate)** — the baseline itself exercised the W3 cache; the notifications p50 of 10 ms IS the cached path.
- Route-level p50s agree with the harness (e.g. `GET /api/notifications` ≈ 10 ms, `GET /api/leads` ≈ 15 ms).

**Dev-mode caveat (printed by the harness, repeated here):** these are Turbopack dev numbers (per-route dev overhead, no prod bundling). They are the DEV-GATE truth; production profiling is out of P2 scope (no deploy allowed).

## 3. Targeted optimizations — what the measurements justified (and what they rejected)

| Candidate | Measurement verdict | Action |
|---|---|---|
| Notifications recomputation per poll | 35–40 queries/poll → 2 on hit; 97% hit rate under load | **Done in W3** (scoped TTL cache + adaptive cadence) |
| Dashboard query surgery | p95 51 ms, well inside any interactive budget | **Rejected** — no evidence of a problem (mission: do not invent improvements) |
| Analytics aggregation rewrite | p95 50 ms | **Rejected** — same reasoning |
| Leads pagination | already paginated (pageSize 50, p95 24 ms) | None needed |
| Redundant fetching (client) | React Query cache + staleTime already dedupe; refetchOnWindowFocus bounded by the W3 server cache | Verified by design + cache hit evidence; no client fetch pattern change justified |
| DB indexes | max single query 19 ms | **Rejected** — no slow query exists to index for |

**The honest performance finding:** on the current dataset (43 leads / 21 opportunities / 8 users), every surface is fast; the REAL measured costs of P2 were the notification polling load (fixed in W3) and the observability gaps (fixed in W1). No speculative optimization was performed.

## 4. Evidence-based performance budgets (dev-gate)

Derived as measured p95 × ~2–3 headroom (dev variance from compile/GC/scheduler is the dominant noise) — these gate future regressions, `bun run perf:baseline` is the probe:

| Surface | Measured p95 | Budget (fail if exceeded) |
|---|---|---|
| GET /api/dashboard | 51 ms | **≤ 150 ms** |
| GET /api/analytics | 50 ms | **≤ 150 ms** |
| GET /api/leads (page) | 24 ms | **≤ 100 ms** |
| GET /api/pipeline/stages | 11 ms | **≤ 60 ms** |
| GET /api/search | 29 ms | **≤ 100 ms** |
| GET /api/notifications (cache warm) | 28 ms | **≤ 100 ms** |
| GET /api/journey/stats | 15 ms | **≤ 80 ms** |
| DB single query (max) | 19 ms | **≤ 100 ms** |
| API error rate (5xx) | 0 observed | **< 1%** of requests |
| Notification cache hit rate under steady load | 97% | **> 60%** (multi-tab/refocus dedup healthy) |

Frontend bundle budget: dev-mode bundles are not representative (unminified, per-route dev overhead) — measuring the production Initial JS size honestly requires `next build`, which house law forbids in this environment. Documented as a **P3 gate** (`next build` → bundle analysis → budget), not faked with dev numbers.

## 5. Incidents during this wave (honest register)

| # | Incident | Root cause + fix |
|---|---|---|
| 1 | `/api/metrics` saw an empty notification cache while the route's cache worked | Turbopack dev chunk duplication of shared modules → `globalThis` anchoring (the db.ts pattern), documented in the module |
| 2 | dbQueries stayed 0 after wiring `$on('query')` | TWO stacked root causes: (a) `log:['query']` emits stdout only — fixed with the dual-emit config `{query: stdout} + {query: event}` (verified in isolation: both fire); (b) the `globalForPrisma` singleton survives module re-evaluation so the listener never attached to the reused client — fixed with idempotent, unconditional attachment; obs state also globalThis-anchored |
| 3 | OOM #3 reaped next-server during the db.ts hot-recompile (2.5 GB RSS) | D-042 clean restart; the memory law (12-worker vitest cap) already in place from W2 |

## 6. Test evidence

Full gate **761/761 (43 files)** — the obs unit suite (6 tests incl. db-query ring math) green after the globalThis refactor; lint 0 errors. The measurement harness itself is GET-only + one login (never mutates).

## 7. Limitations / follow-ups

- Dev-mode numbers only (documented; production profiling = P3 with `next build`).
- The baseline runs against the seeded demo dataset; at 10× data volume the budgets should be re-measured (the harness + metrics store make that a one-command operation).
- dbQueries duration resolution is 1 ms (Prisma event rounding) — sub-ms queries read as 0, which is honest for local SQLite.
