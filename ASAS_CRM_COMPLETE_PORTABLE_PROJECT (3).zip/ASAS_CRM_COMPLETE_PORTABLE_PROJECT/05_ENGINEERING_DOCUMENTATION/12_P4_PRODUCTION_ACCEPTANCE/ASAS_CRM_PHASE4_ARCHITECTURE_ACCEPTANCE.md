# ASAS CRM — Phase 4 Architecture & Technical-Debt Acceptance Audit (P4-A1)

**Agent:** 1 of 6 — Software Architecture, Codebase & Technical Debt Auditor (Task P4-1)
**Date:** 2026-11-06 (session of the Phase 4 independent audit)
**Mode:** READ-ONLY. No file under `src/`, `prisma/`, `scripts/`, `tests/`, or `package.json` was modified. Permitted validation commands run: `bunx tsc --noEmit`, `bun run lint`. Probe artifacts written only under `tmp-scripts/p4-a1-*` (git-ignored convention).
**Audited tree:** git `main` @ `62014966b4693d40c343b4e18af2dd332fbb3445` (matches the mandated HEAD `6201496`), working tree clean over `src/`.

---

## 1. Executive summary

**VERDICT: ARCHITECTURE ACCEPTED WITH FINDINGS — score 83/100.**

The load-bearing architecture is real, verified, and unusually disciplined for its size: a four-layer modular monolith (route handler → domain service / DTO module → shared authorization-validation kernel → Prisma) with **zero circular dependencies, zero client/server boundary violations, zero hand-written query keys, zero server actions, zero direct `req.json()` bypasses, 0 TypeScript errors and 0 lint errors**. The D-021 visibility composition law is applied consistently across every domain I probed (12+ routes, service layer included), and the P1 domain-service extraction claims **reproduced exactly** (all five route line counts byte-verified).

The findings that keep this from a clean acceptance are **not runtime defects** — they are (a) a materially stale architecture handoff document that misstates the system's size and attack surface, (b) a violated zombie-file law (D-040/D-041) with 4 files of suspect provenance at HEAD (all live, none dead), (c) an unevenly applied domain-service pattern (4 of ~10 domains extracted; five route handlers >450 lines still carry business law inline), and (d) residual enum/dead-export duplication debt. None of these blocks production acceptance on their own; all of them deserve scheduled remediation.

---

## 2. Verified architecture (fresh module map)

### 2.1 Runtime topology (all counts fresh from `rg --files`)

| Layer | Verified contents |
|---|---|
| **Route surface** | `src/app/api/**` — **87 `route.ts` files, 112 handlers** (45 GET · 45 POST · 13 PATCH · 1 PUT · 8 DELETE). Plus `src/app/api/[...path]/route.ts` (23 lines, JSON-404 catch-all — HTML 404s impossible on `/api/*`). **83/87 gated by `requireUser`**; 4 ungated by design: `auth/login`, `auth/session`, `health`, catch-all. |
| **Domain services** | `src/lib/services/` — **4 modules**: `payments.ts` (226 l.), `installments.ts` (418), `dashboard.ts` (631), `reservations.ts` (745). Own the transaction boundary; every orchestrator commits writes + audit + activity in ONE `db.$transaction` with fault-injection sites. |
| **Server kernel** | `src/lib/server/` — **40 modules** (import map built: every module has ≥1 live importer — zero dead modules). Kernel: `session.ts` (425 l.: HMAC cookie, `requireUser`, `ApiError`, `ok/fail`, `assertSameOrigin`, `clientIp`), `visibility.ts` (245 l.: the D-021 scope factory), `validation.ts` (163 l.: `parseBody`/`readJson` + shared zod money/ID schemas + `MAX_MONEY_DZD`). Domain support: `leads/visits/tasks/opportunities.ts` (house DTO-module pattern — `findX` + `include` + DTO), `offer-lifecycle.ts` (1,036 l.), `reservation-lifecycle.ts`, `opportunity-gates.ts`, `visit-gate.ts`, `visit-facets.ts` (canonical predicate home — imported by both the visits route and the dashboard service), `scoring.ts`, `financial-semantics.ts`, `expiry.ts` + `expiry-scheduler.ts` (in-process singleton sweeper, HMR-safe, `.unref()`, production cron guidance documented), `audit.ts`, `faults.ts` (fault injection, double-gated: `NODE_ENV=production` → inert), `obs.ts`, `logger.ts`, `route-pattern.ts`, `boot.ts`, `retention.ts`, `duplicates.ts`, `notification-cache.ts`, `documents.ts`, `ai-provider.ts`, `lead-capture.ts`, `matching.ts`, `csv.ts`, `zip.ts`, `settings.ts`, `demo-org.ts`, `reservation-{economics,trust,dto}.ts`, `journey-facts.ts`, `auth.ts`, `matches.ts`, `file-verification.ts`. |
| **Client lib** | `src/lib/client/` — 10 modules, all `"use client"`: `api.ts` (typed fetch + client-side `ApiError`), `store.ts` (219 l.: zustand hash routing — `parseHash`/`hashchange`), `view-registry.ts` (251 l.: **the ONE registry** — 12 views, `VIEW_REGISTRY`/`VIEWS`/`NAV_SECTIONS`/`VIEW_COMPONENTS` lazy map), `query-keys.ts` (197 l.: the ONE typed key factory `qk`), `query-invalidation.ts` (82 l.: the ONE deal/convert fan-out), `focus.ts` (183 l.: the ONE focus-token contract, 6 former mechanisms collapsed), `session.ts`, `workspace-store.ts`, `types.ts` (1,207 l. — the API type mirror), `whatsapp.ts`. |
| **Shared root (isomorphic)** | `src/lib/{constants,db,format,phone,dates,arabic,journey,metrics,utils}.ts` — pure modules legally imported by both server and client. `journey.ts` (769 l.) is explicitly "pure functions, no DB imports — the same derivation runs server-side and client-side" (one function, one truth). `metrics.ts` (58 l.) centralizes metric math (three former drifting "conversion" formulas). `constants.ts` (799 l., 125 exports) is the shared enum vocabulary + transition matrices (`OPPORTUNITY_TRANSITIONS`, `RESERVATION_ACTIONS`…). |
| **i18n** | `src/lib/i18n/domains/` — 21 domain modules, each a `DomainDict` with **fr/en/ar side-by-side** (verified structure in `search.ts`:8-73; genuine Arabic strings, e.g. `"search.placeholder": "ابحث عن كل شيء… (⌘K)"`). |
| **Components** | 161 `.tsx` files: `components/crm/views/` (49 — one folder per view), `pipeline/` (17), `visits/` (12), `settings/` (9), `properties/` (8), `import/` (7), `documents/` (6) + shell (`shell.tsx`, `crm-app.tsx` 95 l., `sidebar-nav.tsx` consumes registry). |
| **Shell** | `src/app/page.tsx` — **15 lines** (Providers + CrmApp only). Confirmed NOT a monolith. |
| **Proxy** | `src/proxy.ts` (54 l., Next 16 convention replacing deprecated middleware): stamps `x-request-id`/`x-asas-route`/`x-asas-method`/`x-asas-request-start` for `ok()/fail()` correlation; matcher `/api/:path*`; edge-safe. |
| **Error boundaries** | `src/app/error.tsx` (180 l., trilingual segment boundary) + `src/app/global-error.tsx` (83 l.) — both present. |

### 2.2 The composition law (mission item 3) — VERIFIED

`src/lib/server/visibility.ts` is the single authorization primitive: `leadScope/taskScope/oppScope/visitScope/contactScope/activityScope/reservationScope/installmentScope/savScope/documentScope/canConfirmVisit/assertLeadVisible` (lines 67-245), all deriving from `seesAllRecords` (MANAGER+ → `undefined` fragment), `ownOrPool`, and `assignedProjects` (FIELD_REP project scoping). Spot-checks (file:line):

| Route / service | Evidence |
|---|---|
| `api/leads/route.ts:40` | `conditions: [{ orgId, ...leadScope(user) }]` (AND-composed array) |
| `api/leads/[id]/route.ts:33-34,78` | scoped `findFirst({ id, orgId, ...leadScope(user) })` → 404 `LEAD_NOT_FOUND` |
| `api/opportunities/[id]/route.ts:86-87, 478-479` | `findFirst({ id, orgId, ...oppScope(user) })` → 404 `OPPORTUNITY_NOT_FOUND` (GET + PATCH) |
| `api/sav/[id]/route.ts:66-77, 111` | scoped findFirst → 404 "byte-identical to ghosts", then rights |
| `api/activities/route.ts:24` | `[{ orgId, ...activityScope(user) }]` |
| `api/search/route.ts:72-86, 100-114, 153-165, 171-185, 208-224` | AND-composition of `leadScope/oppScope/contactScope/savScope/installmentScope` — with the exact "never spread a scope next to an explicit OR key" comment |
| `api/notifications/route.ts:84-91` | `taskScope/visitScope/leadScope/reservationScope` spread into every group |
| `services/payments.ts:130` | `where: { id: body.installmentId, orgId, ...installmentScope(user) }` (scope INSIDE the service) |
| `services/installments.ts:115, 188, 363` | list/create/update all scope-composed |
| `services/reservations.ts:144` | `[{ orgId, ...reservationScope(user) }]` |
| `services/dashboard.ts:256-260, 478` | role-aware scope composition for the whole projection |

Only 2 narrow inline re-implementations of the FIELD_REP project predicate exist outside `visibility.ts` (`api/notifications/route.ts:426`, `services/dashboard.ts:389`) — both are pending-visit-backlog scopes with in-code rationale, not naked copies (MINOR).

### 2.3 Frontend state architecture (mission item 6) — VERIFIED

- Query-key factory: **217/217 `queryKey:` occurrences in `src/components/**` go through the `qk` factory** (PCRE2 negative scan for non-`qk` keys: 0 hits). 178 `useQuery`/`useInfiniteQuery` call sites.
- Invalidation: centralized in `query-invalidation.ts` (`DEAL_MUTATION_KEYS` = 13 prefixes, `CONVERT_MUTATION_KEYS` adds reservations+finance) — consumed via hooks by all mutating surfaces.
- Focus tokens: `focus.ts` single discriminated request slot, consumed-on-arrival, session-memory-only; tests `tests/unit/focus.test.ts` + `view-registry.test.ts` + `query-keys.test.ts` pin the three contracts.
- Hash routing: `store.ts:48` `parseHash`, `:164-176` boot sync + `hashchange` listener; `view-registry.ts:242-244` `VIEW_COMPONENTS` lazy map; `crm-app.tsx:29-31` renders through the registry (former 12-branch switch deleted — comment documents it).

### 2.4 Error handling (mission item 7) — VERIFIED

`ApiError(status, message, code?, details?)` (`session.ts:174-184`) used **293 times across route files**; `fail()` present in **85/87 routes** (the 2 exceptions are the catch-all 404 and `health`, both by design). `categorizeError` maps to a stable 9-value error category vocabulary; 500s leak nothing but the generic French message client-side. Client mirror `lib/client/api.ts` re-throws typed `ApiError`. Zero direct `req.json()` calls in routes — `readJson()`/`parseBody()` choke-points hold (which also carry `assertSameOrigin` for pre-auth mutations, `validation.ts:9-18`).

### 2.5 Static quality gates (mission item 8) — VERIFIED

- `bunx tsc --noEmit` → **exit 0, zero output** (run twice: backgrounded + synchronous confirmation).
- `bun run lint` → **`✖ 41 problems (0 errors, 41 warnings)`** — breakdown: 28 `@typescript-eslint/no-unused-vars`, 10 `react-hooks/exhaustive-deps`, 3 `prefer-const`.

---

## 3. Critical defects

**NONE.** No finding in this audit constitutes a runtime defect, a security regression, or a production blocker. The defects below are ranked as the most severe *architectural* findings.

### 3.1 MAJOR — Stale architecture handoff document misstates the shipped system

`05_ENGINEERING_DOCUMENTATION/01_SYSTEM_ARCHITECTURE/ARCHITECTURE.md` (182 l.) claims a "verified current-state census (59 API route files, 26 data models, 21 server modules — all counted from the repository)". Fresh census at HEAD:

| Claim in ARCHITECTURE.md | Actual (evidence) |
|---|---|
| 59 route files, 77 handlers | **87 files, 112 handlers** (`rg --files src/app/api \| rg 'route\.ts$' \| wc -l`; per-method `export function GET/POST/...` counts: 45/45/13/1/8) |
| 21 server modules | **40 `lib/server` modules + 4 `lib/services` modules** |
| 26 data models | **35 models** (`rg -c "^model " prisma/schema.prisma`) |
| 13 migrations | **25** (`ls prisma/migrations \| rg '^[0-9]' \| wc -l`; entry-assessment §4 confirms 25 applied in `_prisma_migrations`) |
| "56 of 59 gated; 3 public by design" | 83 of 87 gated; 4 ungated (login, session, health, catch-all) |

The document still describes the pre-P0/P1/P2 system. For a production-readiness phase whose deliverable is a GitHub/Vercel handoff, a front-door architecture doc that understates the route surface by 28 files is a real liability (security reviewers and integrators would audit the wrong perimeter). Also stale: it presents Supabase PostgreSQL as the production chain while the binding operating law (AGENTS.md DB constraint) makes SQLite+migrations authoritative — the supabase/ tree exists but its parity posture must be re-stated. **Fix: regenerate the census (one `rg`/`wc` pass) and re-date the doc, or explicitly mark it superseded.**

### 3.2 MAJOR — D-040/D-041 zombie law violated in letter: 4 suspect-provenance files at HEAD

The mandated sweep (`git log --all --diff-filter=D --name-only` × `git ls-files`) was re-run fresh: **22 files are ever-deleted ∧ in-HEAD**. Content-hash purity proof (last-deleting-commit parent blob vs HEAD blob):

- **18 legitimately recreated** (content differs — the Phase D finance/SAV/targets re-implementation).
- **4 are byte-identical to their pre-purge content**: `src/components/crm/views/finance/finance-attention.tsx`, `src/components/crm/views/finance/installment-detail-dialog.tsx`, `src/components/crm/views/sav/sav-attention.tsx`, `src/components/crm/views/sav/sav-table.tsx`. All four were (re)introduced at commit `9cdf1fb` (2026-10-30) whose message is a **raw UUID** (`1396e253-026a-4271-8bdd-26984207f8e3`) — the environment's auto-commit signature, violating both the D-041 zero-tolerance law and the conventional-commit rule (28 such UUID commits exist in history).

**Mitigating evidence (why this is not dead code):** all four files have live importers (`finance-view.tsx` imports the two finance files; `sav-view.tsx` imports the two SAV files), reference the current type mirror (`@/lib/client/types` `FinanceOverview`) and current design system (D-UX-015 two-tier law), and the models they render (Installment/SavCase) are live again post-Phase-D. tsc/lint/tests are green with them. **Required action:** the Principal must either ratify them as intentional Phase-D assets (worklog + provenance note, breaking the content-identity with a documented touch) or re-delete and rebuild per D-041. The law's mandated sweep was demonstrably not re-run after Phase D reintroduced the feature set.

### 3.3 MAJOR — Domain-service extraction covers only the money quartet; five fat handlers remain

The P1 service pattern (route = zod + requireUser + service call + ok/fail) is exemplary where applied, but only 4 of ~10 domains were extracted. Largest route handlers still carrying business law inline:

| Route | Lines | Nature of embedded logic |
|---|---|---|
| `api/visits/[id]/route.ts` | 628 | visit decision lifecycle, confirmation entitlement, status machine |
| `api/opportunities/[id]/route.ts` | 548 | stage-move law, PIPE-02 hard gates, two-step closure, corrections, in-tx guards |
| `api/notifications/route.ts` | 500 | 11 notification groups computed inline (read-only projection) |
| `api/leads/route.ts` | 489 | multi-facet query builder, per-row stats aggregation, create+dedupe transaction |
| `api/leads/[id]/route.ts` | 464 | update cascade, archive/convert guards |

Counterweights verified: rule *matrices* and gates are shared even where handlers are fat (`OPPORTUNITY_TRANSITIONS` in `constants.ts:192`, `opportunity-gates.ts` used by 4 files, `visit-gate.ts` used by 9 files, DTO modules `leads/visits/tasks/opportunities.ts`, `visit-facets.ts` canonical for 2 consumers). So this is orchestration debt, not rule duplication. Still, the P1 report's own "house law for new routes" (§4) is not yet retro-applied, and `notifications` recomputes ~35 queries per manager poll (bounded by the 30s cache, `notification-cache.ts`).

**Also open (carried forward, honestly flagged by P1 as F2):** the installments money-cap asymmetry — `api/finance/installments/route.ts:36` and `api/finance/installments/[id]/route.ts:21` still use the private `.max(1e12)` while payments uses the shared `MAX_MONEY_DZD` (10^10). Verified still present at HEAD.

---

## 4. Remaining technical debt (ranked)

1. **Fat route handlers (see §3.3)** — visits/[id], opportunities/[id], notifications, leads, leads/[id] (~2,529 lines of handler-embedded domain logic). Migration path exists (the services pattern); each is a contained, contract-pinnable refactor.
2. **Stale handoff docs (see §3.1)** — ARCHITECTURE.md census + the pre-remediation `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_REMAINING_DEFECTS_REGISTER.md` (entry assessment §3 already warns on the latter).
3. **Zombie-law provenance gap (see §3.2)** — 4 files need ratification or re-deletion; 28 UUID-noise commits pollute history (history-purge gate D-013 already documented for pre-remote cleanup).
4. **Enum single-sourcing residue (see §5)** — the live-hold status pair re-typed ×5; one inline `z.enum` subset; 16 dead exports in `constants.ts`.
5. **Lint warnings 37 → 41** (0 errors): new dead vars since P1 — `auth.ts:34-36` (`SCRYPT_N/R/P` — scrypt tuning constants now unused after parameterization), `obs.ts:68` (`errorCategories`, `dbQueryRing`), `reservation-lifecycle.ts:418` (`apartmentReleased`), plus 10 `react-hooks/exhaustive-deps` patterns (e.g. `leads-view.tsx:318`, `workspace-store.ts:206`).
6. **Known carried-forward items confirmed open at HEAD:** dashboard ~30 queries per GET (P1 §10); P1-F3 direct-booking audit `after.value` semantics; in-process expiry scheduler vs. multi-instance cron (documented production guidance in `expiry-scheduler.ts` header); `offer-lifecycle.ts` at 1,036 lines (largest server module).
7. **`analytics/route.ts` (301 l.)** — projection logic inline (same class as notifications), metrics math centralized in `metrics.ts` but assembly not extracted.

---

## 5. Duplicate implementation findings

1. **Live-hold status pair `["ACTIVE", "CLOSURE_REQUESTED"]` re-typed inline in 5 sites** (no shared constant exists; `RESERVATION_STATUSES` has the full vocabulary but not the subset): `api/properties/apartments/[id]/route.ts:104`, `api/notifications/route.ts:148`, `api/opportunities/[id]/route.ts:275`, `services/reservations.ts:456,514`. Drift risk if a pre-closure status is ever added — exactly the class AGENTS.md invariant #6 warns about. **MINOR.** Fix: export `RESERVATION_LIVE_HOLD_STATUSES` from `constants.ts`.
2. **Inline `z.enum(["CALLED", "CANCELLED"])`** in `api/finance/installments/[id]/route.ts:25` — a literal subset of `INSTALLMENT_STATUSES` (`constants.ts:618`). Partially contradicts AGENTS.md's "SAV inline-enum drift class is closed" claim (letter, not spirit — it is a deliberate subset, but it re-declares members locally). **MINOR.** (Other inline `z.enum`s found — `saved-searches/[id]:16`, `leads/bulk:21`, `leads/import:52`, whatsapp/copilot verb+lang enums — are request-verb contracts, not persisted model enums; acceptable. 49 `z.enum` sites correctly import constants.)
3. **In-file duplicated predicate** — `components/crm/views/finance/finance-table.tsx:98` and `:268` both compute `const cancellable = canCancel && (row.status === "PLANNED" || row.status === "CALLED")` (desktop + mobile branches). **MINOR.**
4. **16 dead exports in `constants.ts`** with zero references outside the file (src+tests+scripts+prisma scanned): `ApartmentPaymentPlan, ApartmentStatus, ContactType, FieldPendingStatus, InstallmentKind, InstallmentStatus, ORIENTATIONS, OutcomeBearingType, PROJECT_STATUSES, PaymentMethod, ReservationStatus, SavCategory, SavStatus, TouchChannel, TouchDirection, VisitInterestLevel` (plus 3 test-only exports: `LostReason`, `OFFER_ACTIONS`, `TASK_TRANSITIONS` — these are vocabulary pins, keep). Dead surface = drift bait. **MINOR.**
5. **Legacy parallel paths: NONE FOUND.** Import map over all 44 `lib/server`+`lib/services` modules: every module has ≥1 live importer in `src/` (not just tests). The old i18n monolith is gone (`src/lib/i18n.ts` absent; 21 domain modules + index only). No old visibility implementations beside `visibility.ts` (OWN+POOL pattern grep: 0 hits outside). The offer-convert lockstep duplicate was genuinely deleted (P1 §5 — `bookUnitInTx` shared core; `offer-lifecycle.ts` now imports it, verified via import map).
6. **No dead zombie modules**: see §3.2 for the only provenance findings (4 live files).

---

## 6. Maintainability risks

- **`offer-lifecycle.ts` (1,036 l.) + `services/reservations.ts` (745 l.) + `services/dashboard.ts` (631 l.)** — the three largest server modules are the money-path core. They are heavily documented and unit-pinned, but each is at the edge of what one engineer can hold in mind; further growth should go through new modules, not additions.
- **`lib/client/types.ts` (1,207 l.)** — a hand-maintained API type mirror. It is the deliberate client/server boundary (server types never imported into components — verified), but every API shape change requires a synchronized manual edit; drift is caught only by UI≡API probes, not by the compiler. A codegen step would remove the class.
- **i18n domain dictionaries** (`leads.ts` 1,468 l., `pipeline.ts` 1,020 l.) — inherent to the 3-language side-by-side law; acceptable, but key additions require triple discipline (tested by `tests/unit/i18n.test.ts`).
- **`notifications/route.ts`** — 11 groups × bespoke scope spreads; the second-most-complex read route after dashboard; cache mitigates cost, not complexity.
- **Route-handler hotspots** (see §3.3) — the `visits/[id]` + `opportunities/[id]` pair encode the two most intricate state machines in handlers; tests cover them (permission-matrix, opportunity-gates suites), but refactors there are the highest-risk in the codebase.
- **Process risk**: the environment's resurrect-and-auto-commit behavior (28 UUID commits) means every future phase must re-run the D-040 sweep — the law exists, the execution lapsed once (§3.2).

---

## 7. Architecture acceptance verdict — 83/100

**Methodology.** Six weighted dimensions, each scored from fresh evidence only (no prior-report PASS was taken on faith):

| Dimension | Weight | Score | Evidence basis |
|---|---|---|---|
| Module boundaries & layering | 25 | **24** | §2.1 map; cycles: NONE (Tarjan SCC over full `src` import graph, `tmp-scripts/p4-a1-cycles.ts`); boundary violations server→client / components→server / api→client: NONE; page.tsx 15-line shell; view-registry & focus & query-key single sources verified (217/217 keys) |
| Domain logic separation | 20 | **14** | §3.3: 4 domains fully extracted (thin adapters verified line-by-line), 5 fat handlers remain (~2,529 lines); rule matrices shared; P1-F2 cap asymmetry open |
| Authorization composition (D-021) | 20 | **19** | §2.2: 12+ route/service composition sites verified; 404-byte-identical ghost law in detail routes; only 2 narrow documented inline predicates |
| Duplication & dead code | 15 | **11** | §5: no dead modules / no legacy parallel paths; but live-hold pair ×5, inline enum subset, 16 dead exports, in-file duplicate, 4 provenance-suspect files (§3.2) |
| Static quality (types/lint) | 10 | **9** | tsc exit 0 / 0 errors; lint 0 errors / 41 warnings (all minor classes); 0 console.log debris; 0 TODO/FIXME markers |
| Documentation accuracy | 10 | **6** | AGENTS.md accurate and binding; but ARCHITECTURE.md census materially stale (§3.1) |
| **Total** | **100** | **83** | |

**Verdict: ARCHITECTURE ACCEPTED WITH FINDINGS.** The system's structural laws (single route, API-only, scope composition, service-owned transactions, single-source registries, enum centralization) are not aspirational documentation — they are enforced in code and reproducible by grep. The deduction is concentrated in documentation staleness, an unevenly completed service migration, and enum/dead-surface residue — all remediable without architectural change. **No finding requires re-architecture; three require scheduled action (§3.1 census regen, §3.2 provenance adjudication, §3.3 continued extraction).**

### 7.1 Contradictions with prior phase reports (explicit list)

| # | Prior claim | Fresh evidence | Class |
|---|---|---|---|
| C-1 | `05_ENGINEERING_DOCUMENTATION/01_SYSTEM_ARCHITECTURE/ARCHITECTURE.md`: "verified current-state census — 59 route files / 21 server modules / 26 models / 13 migrations, counted from the repository" | 87 / 40+4 / 35 / 25 (§3.1) | **CONTRADICTION** (doc predates P0-P2 and was never refreshed) |
| C-2 | AGENTS.md: "the SAV inline-enum drift class is closed — keep it closed" | `installments/[id]/route.ts:25` inline `z.enum(["CALLED","CANCELLED"])` subset of `INSTALLMENT_STATUSES` | **PARTIAL CONTRADICTION** (letter; scope is a deliberate subset) |
| C-3 | AGENTS.md D-041: "NOTHING ever-deleted ∧ in-HEAD is tolerable" | 22 ever-deleted ∧ in-HEAD at HEAD; 4 byte-identical to pre-purge content via UUID auto-commit `9cdf1fb` (all live/imported — §3.2) | **CONTRADICTION** (letter of law; no dead code results) |
| C-4 | P1 report: `bun run lint` → "0 errors, 37 tolerated warnings — unchanged count" | 0 errors, **41** warnings today (new dead vars in `auth.ts`, `obs.ts`, `reservation-lifecycle.ts` + 1 test file) | Drift (post-P1 additions; not a false claim at its date) |
| C-5 | P1 report §3 route line counts (dashboard 28, reservations 75, installments 52, installments/[id] 38, payments 41, offer-lifecycle 1036) | `wc -l` reproduces **all six exactly** | **VERIFIED — no contradiction** |
| C-6 | P1 report §10 F2: installments `1e12` cap asymmetry "flagged for the Principal" | Still present at both sites (§3.3) | Consistent carry-forward (open debt, honestly declared) |
| C-7 | P2 closeout: 772/772 tests | Not re-run by this agent (forbidden by mission rules); Principal re-verified at entry assessment §5.1 on same HEAD | **NOT INDEPENDENTLY RE-RUN** (accepted on Principal's fresh evidence) |

---

## 8. Evidence appendix (commands run + key outputs)

All commands executed read-only at `main @ 6201496`. Probe artifacts: `tmp-scripts/p4-a1-{tsc,lint}.log`, `p4-a1-cycles.ts`, `p4-a1-ever-deleted.txt`, `p4-a1-in-head.txt`, `p4-a1-const-exports.txt`.

```
git rev-parse HEAD            → 62014966b4693d40c343b4e18af2dd332fbb3445 (main)
git status --porcelain src/   → (empty)

bunx tsc --noEmit             → (no output) exit code 0
bun run lint                  → ✖ 41 problems (0 errors, 41 warnings)
  [28 no-unused-vars · 10 react-hooks/exhaustive-deps · 3 prefer-const]

Route census:
  rg --files src/app/api | rg 'route\.ts$' | wc -l          → 87
  export function GET=45 POST=45 PATCH=13 PUT=1 DELETE=8    → 112 handlers
  routes without requireUser: auth/login, auth/session, health, [...path]

Module census:
  src/lib/server = 40 modules · src/lib/services = 4 · src/lib/client = 10
  src/lib/i18n/domains = 21 (fr/en/ar verified in search.ts:8-73)
  src/components = 161 .tsx (views 49 · pipeline 17 · visits 12 · …)
  wc -l src/app/page.tsx → 15 (shell confirmed)
  models: rg -c "^model " prisma/schema.prisma → 35
  migrations on disk: 25

Size hotspots (wc -l, top of src/): i18n/domains/leads 1468 · client/types 1207 ·
  server/offer-lifecycle 1036 · i18n/domains/pipeline 1020 · pipeline-view 926 ·
  visits/visit-dialogs 903 · create-opportunity-dialog 845 · create-lead-dialog 814 ·
  constants 799 · leads-view 796 · journey.ts 769
Largest routes: visits/[id] 628 · opportunities/[id] 548 · notifications 500 ·
  leads 489 · leads/[id] 464 · leads/import 397 · copilot 390
P1-verified thin adapters: dashboard 28 · reservations 75 · installments 52 ·
  installments/[id] 38 · payments 41 · offer-lifecycle 1036 (all match P1 §3)

Cycles/boundaries (tmp-scripts/p4-a1-cycles.ts, Tarjan SCC + alias/relative
resolution over all src/**/*.{ts,tsx}):
  CYCLES (SCCs >1)            → NONE FOUND
  lib/server → lib/client     → NONE FOUND
  src/components → lib/server|services → NONE FOUND
  app/api → lib/client        → NONE FOUND

Query keys:  queryKey: occurrences in components = 217; non-qk = 0 (PCRE2)
             useQuery/useInfiniteQuery = 178
ApiError:    293 uses across route files; fail() in 85/87 routes
Server actions ("use server") → 0 ; direct req.json() in routes → 0
Test files:  44 (not executed — Principal's 772/772 stands per entry §5.1)

Zombie sweep (D-040/D-041):
  ever-deleted ∧ in-HEAD = 22; content-hash proof: 18 recreated (differ),
  4 byte-identical (finance-attention, installment-detail-dialog, sav-attention,
  sav-table — introduced by UUID-message commit 9cdf1fb 2026-10-30; all have
  live importers: finance-view.tsx / sav-view.tsx)

Import map (all lib/server + lib/services modules): min reference count = 1
  (reservation-economics, zip) — zero orphan modules; every low-count module's
  importers listed (e.g. ai-provider → copilot + documents/analyze routes;
  route-pattern → src/proxy.ts + obs test)

Dead exports in constants.ts: 16 with zero refs outside the file
  (ApartmentPaymentPlan, ApartmentStatus, ContactType, FieldPendingStatus,
   InstallmentKind, InstallmentStatus, ORIENTATIONS, OutcomeBearingType,
   PROJECT_STATUSES, PaymentMethod, ReservationStatus, SavCategory, SavStatus,
   TouchChannel, TouchDirection, VisitInterestLevel)

Duplicate predicates: ["ACTIVE","CLOSURE_REQUESTED"] ×5 sites;
  assignedProjects inline ×2 (notifications:426, dashboard:389);
  OWN+POOL inline outside visibility.ts: 0

Dependencies: all 32 runtime deps imported ≥1× in src (lowest: @dnd-kit/utilities
  → pipeline/kanban-card.tsx; clsx → lib/utils.ts; cmdk → search-command.tsx;
  z-ai-web-dev-sdk → 3 server-only files — client boundary clean)

Debt markers: console.log in src = 3 (logger fallback + 2 sweeper notices);
  TODO/FIXME/HACK = 0 real markers
```

---

*No application source, schema, migration, or configuration was modified by this audit. The only files written are this report and `tmp-scripts/p4-a1-*` probes.*
