# ASAS CRM — Phase 4 DevOps, CI/CD, Performance & Production Operations Acceptance

**Task ID:** P4-6 / Agent 6 (DevOps, CI/CD, Performance and Production Operations Auditor)
**Date:** 2026-11-06 (fresh measurements 17:18–17:27 UTC)
**Scope:** CI/CD local proof matrix · fresh performance measurement · notification query-cost verification · hosting compatibility (Vercel) · multi-instance/session/restart analysis · operational readiness (health/observability/backups/runbooks).
**Environment audited:** HEAD `6201496` on `main`, NO remote repository (`git remote -v` empty), dev server live at `http://127.0.0.1:3000` (restarted 17:01:27Z — see §3 ambient conditions), 2 vCPU shared sandbox.

---

## 1. Executive Summary & Verdict

# VERDICT: DEVOPS/PERFORMANCE ACCEPTED — WITH FINDINGS

**0 CRITICAL · 1 MAJOR (CI gate, trivially fixable) · 5 MINOR · several INFO.** Score: **73 / 100** (§8).

The performance story is genuinely strong and now independently re-proven with fresh measurements: every P2 dev-gate budget holds (all 7 endpoints p95 ≤ 108 ms against budgets of 60–150 ms), the notification cache claim is verified **exactly** (warm hit = 2 SQL queries, cold miss = ~31–34), DB query p95 is sub-millisecond with max 28 ms, and the real (non-injected) 5xx rate over the last hour is **0 of 1,305+ requests**. The observability build-out (structured JSON logging with requestId correlation and deep redaction, ADMIN-gated per-route p50/p95 metrics, executable backup with integrity-on-snapshot + a passed restore drill) is production-shaped and honest about its single-instance law.

The gaps are concentrated where the environment structurally blocks proof: **no remote repository exists** (R-C1 — remote CI execution is NOT VERIFIABLE, carried forward), **`bun run build` is forbidden** (R-C3 — production bundle and NODE_ENV=production are NOT VERIFIABLE, carried forward), backups are **manual-only** (no scheduler exists → unbounded RPO by process), and — the one new MAJOR finding — the committed CI workflow's seed.sql validator **fails locally with exit 1 today** (handoff-tooling drift nobody noticed because the pipeline has never actually run). The hosting posture is honestly documented by the app's own ADR: SQLite is the source of truth (BP-ADR-02), which means the current architecture **cannot deploy to Vercel as-is** and is instead a match for a single persistent host; the Vercel path exists in documentation but requires the dormant, currently-drifting PostgreSQL migration plus a storage adapter.

Nothing found here REJECTS production readiness; the findings are (a) one broken CI gate with a 30-minute fix, (b) structural verification debt already registered (R-C1/R-C3/R-C4), and (c) operational hardening recommendations (backup scheduling, error-category fix, metrics-vs-log consistency).

---

## 2. CI/CD Acceptance

### 2.1 Repository & release posture (VERIFIED facts)

| Fact | Evidence |
|---|---|
| HEAD `6201496` on `main`, working tree: `worklog.md` modified + `05_ENGINEERING_DOCUMENTATION/12_P4_PRODUCTION_ACCEPTANCE/` untracked (Phase 4 deliverables pending Principal commit) | `git log`/`git status` |
| **NO remote repository exists** — `git remote -v` prints nothing (exit 0) | live command |
| History-purge gate R-C1 stands: `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` must be executed BEFORE any remote is added; `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/GITHUB_IMPORT.md` §7 codifies the clean-snapshot import alternative | docs read |
| `bun run build` FORBIDDEN in sandbox (R-C3); `NODE_ENV=production` not exercisable (R-C4) | standing constraints, AGENTS.md |
| `.github/workflows/ci.yml` is the only workflow file — 3 jobs (static-gates, database-gates, test-gates), Bun 1.3.14, `ubuntu-latest`, push/PR on main | file read |

### 2.2 CI local-proof matrix (each CI command executed locally, this session)

| CI job / step (as written in ci.yml) | Local verdict | Fresh evidence |
|---|---|---|
| static-gates → `bun install --frozen-lockfile` | **VERIFIED** (dry-run: lockfile resolves clean, no drift; node_modules healthy: 385 pkgs, 28 bins) | `bun install --dry-run --frozen-lockfile` → done, no errors |
| static-gates → `bunx prisma generate` | **VERIFIED** | exit 0 (Prisma 6.19.2); server health unchanged after regeneration (`uptimeSec` continuous, `dbLatencyMs` 2 ms) |
| static-gates → `bun run lint` | **VERIFIED** | exit 0 — **0 errors, 41 warnings** (30.7 s) |
| static-gates → `bun run typecheck` (`tsc --noEmit`) | **VERIFIED** | exit 0 — 0 errors (4.5 s) |
| static-gates → `bun run build` | **BLOCKED — forbidden in sandbox (R-C3)** | NOT VERIFIABLE |
| database-gates → `bunx prisma migrate deploy` (isolated DB) | **VERIFIED** | exit 0 — **all 25 migrations applied** to a fresh isolated SQLite file |
| database-gates → `bunx prisma migrate status` | **VERIFIED** | "25 migrations found … Database schema is up to date!" |
| database-gates → `bun run db:seed` (isolated DB) | **VERIFIED** | exit 0, 3.4 s — full roster seeded (users 8, leads 43, opportunities 21, …) |
| database-gates → `python3 scripts/validate-seed.py supabase/seed.sql` | **FAILS — exit 1** | `VALIDATION: FAIL` — canonical count drift (see F-1) |
| test-gates → `bun run test` (full suite) | **Principal-verified 772/772** — not re-run per audit mandate | carried forward |
| test-gates → dev-server boot + health jq assertion | NOT re-runnable this session (requires restarting the **shared** dev server — forbidden); locally proven historically in `05_ENGINEERING_DOCUMENTATION/09_P0_FOUNDATION_HARDENING/ASAS_CRM_P0_7_CI_VITEST_REPORT.md` | NOT VERIFIED (this session) |
| test-gates → demo-mode-OFF negative probes (403 quick-login, empty demoUsers) | same as above | NOT VERIFIED (this session) |

### 2.3 Findings (CI dimension)

- **F-1 · MAJOR (CI gate; production impact: none) — the committed database-gates job is RED as-written.** `python3 scripts/validate-seed.py supabase/seed.sql` exits 1: seed.sql contains 24 `Visit` / 184 `Activity` rows vs the validator's hardcoded `EXPECTED_COUNTS` of 23 / 183 (all FK/order/parse checks pass). The current `prisma/seed.ts` actually produces **24 Visits / 187 Activities** on a fresh isolated DB (measured this session), so *both* the canonical counts in the validator *and* the `supabase/seed.sql` mirror have drifted. Root cause: no remote CI has ever executed this step, so the drift went undetected — a concrete demonstration of the R-C1 limitation's real cost. Fix is mechanical (regenerate seed.sql from a fresh seeded DB via `scripts/generate-seed-sql.ts`, update `EXPECTED_COUNTS`), but until then the honest claim is "the CI pipeline would fail on its first real run."
- **F-2 · MINOR — CI relative `DATABASE_URL` lands in `prisma/db/`, which is NOT git-ignored.** Prisma resolves `file:./db/ci-check.db` against the schema directory, creating `prisma/db/ci-check.db` (verified live). `.gitignore` covers `/db/` (root-anchored) only, so running the CI commands locally risks committing a PII-bearing SQLite file. Harmless on ephemeral CI runners; recommend `prisma/db/` in `.gitignore` or absolute URLs in CI.
- **NOT VERIFIABLE (carried forward):** remote GitHub Actions execution of ANY job (no remote exists — R-C1 requires owner authorization + history purge first); production build (R-C3); `NODE_ENV=production` boot behavior incl. the fail-fast gate (R-C4); the `bun run start` standalone path (`output: "standalone"` is configured but has never been booted anywhere).

---

## 3. Fresh Performance Measurements (core evidence)

### 3.1 Measurement environment (honest ambient conditions)

- **Dev-mode Next.js 16.1.3 (Turbopack), single process**, restarted 17:01:27Z (clean "✓ Ready in 3.2s"; no OOM/kill trace in dev.log at the restart point — cause not evident from the log, most likely a deliberate restart per the documented recovery protocol; uptime at measurement start ≈ 1,000 s).
- 2 vCPU sandbox; loadavg 0.51–1.14 during all measurement runs.
- **Concurrent foreign load (other Phase 4 agents):** an agent-browser screenshot process (~40% CPU at observation), a browser tab polling `GET /api/notifications` every 60 s and `GET /api/opportunities/:id/gates` every ~28 s. All timing tables below were taken inside this shared noise floor; outliers are flagged where they occurred.
- Server RSS 2.0–2.2 GB throughout (dev-server posture on this class of host — see §7.6).
- **All numbers are dev-mode numbers** (Turbopack, per-route dev overhead, no production bundling) — they are DEV-GATE evidence, not production latency guarantees; production profiling requires `next build` (R-C3, forbidden).

### 3.2 `bun run perf:baseline` — fresh run vs both P2 baselines (sarah/MANAGER, N=30 warm, sequential)

Fresh JSON: `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/perf-baseline-2026-11-06T17-21-57-303Z.json` (written by the harness).

| Endpoint | **FRESH p50** | **FRESH p95** | fresh min/max | fresh cold | P2 baseline 03:35Z p50/p95 | P2 baseline 03:29Z p50/p95 | P2 dev-gate budget | Budget verdict |
|---|---|---|---|---|---|---|---|---|
| GET /api/dashboard | **54 ms** | **108 ms** | 46 / 169 | 104 ms | 39 / 51 | 36 / 78 | ≤ 150 ms | **PASS** |
| GET /api/analytics?days=30 | **35 ms** | **43 ms** | 32 / 57 | 39 ms | 24 / 50 | 24 / 36 | ≤ 150 ms | **PASS** |
| GET /api/leads (p50) | **19 ms** | **31 ms** | 17 / 38 | 21 ms | 15 / 24 | 15 / 47 | ≤ 100 ms | **PASS** |
| GET /api/pipeline/stages | **13 ms** | **21 ms** | 12 / 30 | 71 ms | 11 / 11 | 11 / 14 | ≤ 60 ms | **PASS** |
| GET /api/search?q=cher | **21 ms** | **27 ms** | 18 / 48 | 98 ms | 17 / 29 | 17 / 23 | ≤ 100 ms | **PASS** |
| GET /api/notifications | **12 ms** | **16 ms** | 10 / 39 | 14 ms | 10 / 28 | 10 / 11 | ≤ 100 ms | **PASS** |
| GET /api/journey/stats | **20 ms** | **23 ms** | 17 / 43 | 104 ms | 14 / 15 | 16 / 65 | ≤ 80 ms | **PASS** |

**7/7 endpoints inside every P2 dev-gate budget.** p50s run ~1.15–1.5× the P2 baselines — consistent with the shared-sandbox noise floor (concurrent browser-agent traffic) rather than any regression: the *server-side* view of the same traffic (dev.log `durationMs`, §3.4) shows p50s matching P2 almost exactly. Harness observation (INFO, F-5): the JSON's `serverMetrics` field is `null` because the harness authenticates as sarah (MANAGER) while `/api/metrics` is ADMIN-gated — the cross-evidence step silently degrades; run the harness with an ADMIN persona to populate it.

### 3.3 Independent curl timing loops (karim/ADMIN, 1 warmup + 25 measured samples each, sequential)

| Endpoint | p50 | p95 | min | max | Notes |
|---|---|---|---|---|---|
| GET /api/health | **8 ms** | **9 ms** | 7 | 23 | unauthenticated probe incl. `SELECT 1` + migration count |
| GET /api/leads?page=1&pageSize=50 | **19 ms** | **24 ms** (rerun) | 15 | 86 | first pass showed p95 104 / max 166 — single ambient outlier; immediate rerun p95 **24 ms**, server-side last-60 p95 33 ms; both within budget |
| GET /api/opportunities | **15 ms** | **20 ms** | 13 | 24 | |
| GET /api/notifications | **10 ms** | **12 ms** | 9 | 25 | cache-warm path |
| GET /api/dashboard | **45 ms** | **80 ms** | 39 | 96 | |
| GET /api/search?q=cher | **18 ms** | **22 ms** | 16 | 32 | |
| GET /api/leads/{id} (detail) | **24 ms** | **54 ms** | 17 | 87 | |

All within the P2 dev-gate budgets. Script: `tmp-scripts/p4-a6-curl-loops.sh`.

### 3.4 Server-side cross-evidence (dev.log `http_request` durations + live /api/metrics)

- `GET /api/leads` last 60 requests (server-side, excludes curl overhead): **p50 13 ms, p95 33 ms, max 104 ms.**
- Live `/api/metrics` snapshot (ADMIN, 17:26Z): uptime 1,462 s · totalRequests 734 · totalErrors 47 · **52 routes tracked with per-route count/errors/avg/p50/p95/max** · `dbQueries`: ring p50 **0 ms**, p95 **0 ms**, max **27 ms** (sub-millisecond SQLite point/range queries, as in P2) · `notificationCache`: **hits 87 / misses 9 (90.6%)**, entries 1, TTL 30,000 ms · memory rss 2,109 MB · `errorsByCategory`: AUTH 20, AUTHZ 10, NOT_FOUND 6, VALIDATION 2, INTERNAL 5, CONFLICT 4 — see F-3 for the INTERNAL label.
- `/api/metrics` gate verified live: no cookie → **401**; MANAGER cookie (harness) → non-ok (the `serverMetrics: null` above). ADMIN cookie → full snapshot.

### 3.5 Runtime error rate (last hour, dev.log)

- `http_request` events since 16:26Z: **1,305 — 1,183×200 + 122×201, ZERO 5xx.**
- `api_error` events (the authoritative error stream — 5xx never emit `http_request` lines, see F-4): **592 total**, of which **117 = `FAULT_INJECTED` 500s** — the deliberate fault-injection test suite run by another audit agent at 16:49–16:51Z; the remaining ~475 are expected 4xx negative-probe traffic (INVALID_TOKEN, NO_SESSION, FORBIDDEN_ROLE, INVALID_CREDENTIALS, NOT_FOUND family, RATE_LIMITED…). **Non-injected 5xx: 0. Zero hydration errors. Zero unhandled stack traces.**
- Budgets: API error rate (5xx) < 1% — **PASS (0%)**; notification cache hit rate > 60% — **PASS (90.6%)**; DB single query max ≤ 100 ms — **PASS (28 ms)**.

### 3.6 Initial JS bundle — NOT MEASURABLE (production), dev-mode context only

Production Initial JS cannot be measured: `next build` is forbidden (R-C3) — the P2 report already registered this honestly as a future gate (`next build` → bundle analysis → budget). Dev-mode observation for context only: the initial document (`curl /` → 33.3 KB HTML) references **43 unminified Turbopack JS chunks ≈ 11.06 MB + 271 KB CSS** (largest: `src_components_crm` 1.39 MB, react-dom 1.05 MB, zod 0.94 MB, devtools 0.82 MB). These figures include dev tooling and per-module chunking and are **not representative** of a minified/code-split production bundle; they are recorded to document that the measurement environment was exercised, not to claim a production number.

---

## 4. Notification Query-Cost Verification (the P2 claim, re-proven)

**Claim under test (P2/W3):** warm-cache poll = **2 queries** (auth only) vs cold miss ≈ 36 for the org scope.

**Method:** bounded dev.log windows around single authenticated requests (`tmp-scripts/p4-a6-query-count.sh`) — mark line → one `GET` → count `prisma:query` lines until the request's own `http_request` completion line; foreign interleaving is detectable (and was detected + excluded) via extra `http_request` lines and bare `SELECT 1` probes inside the window.

| Measurement (fresh, this session) | prisma:query count | Server durationMs | Verdict |
|---|---|---|---|
| **My cold request** (org-scope TTL expired, 17:25:36Z) | **33 raw** — incl. 2 foreign `SELECT 1` health probes → **~31 own** | 46 ms | MISS: full recompute (1 OrgSetting + parallel aggregates over Lead×6, Reservation×4, Visit×3+4 counts, Task×2+1, Project×3, Opportunity, Apartment, LeadDuplicateDismissal, User×2, RevokedSession) — consistent with P2's "35–40 manager / conditional branches vary" |
| **My warm request** (0.9 s later, 17:25:37Z) | **exactly 2** — `User` (auth lookup) + `RevokedSession` (revocation watermark) | 12 ms | **HIT — the P2 claim is verified exactly** |
| Independently observed foreign MISS (17:24:47Z) | 34 | 40 ms | second cold-path confirmation |
| Live cache stats after measurements | hits 87 / misses 13 (87.0%) | — | > 60% budget **PASS** |
| `GET /api/leads?page=1&pageSize=50` (per request, no cache) | **7** — User×2, Lead page + COUNT, Tag, LeadTag, RevokedSession | 18 ms | clean single-request window, 0 foreign lines |

The composition matches the P2 documentation (settings read + parallel aggregates + conditional counts, auth piggybacked); the TTL cache is doing exactly what was claimed, and the externally observable signal (`generatedAt` replay) is what the contract tests lock.

---

## 5. Hosting Compatibility Assessment (mandatory analysis; no deployment performed)

### 5.1 The app's ACTUAL persistence requirements (VERIFIED from code)

| Requirement | Where | Persistence class |
|---|---|---|
| SQLite database `db/custom.db` | `.env` `DATABASE_URL=file:/home/z/my-project/db/custom.db`; journal_mode=delete + busy_timeout 5000 (WAL deliberately blocked, P0-2 Prisma engine bug range) | **durable local filesystem** |
| Uploaded document binaries | `DOCS_DIR = path.join(process.cwd(), "db", "docs")` (`src/lib/server/documents.ts:19`, path-containment-guarded) | **durable local filesystem** |
| Secrets | `.env`: `ASAS_SESSION_SECRET` (boot-gate enforced in production), `ASAS_DEMO_MODE` | env/config plane |
| Sessions | HMAC-signed cookie (`session.ts:47–73`) — **stateless**; revocation via DB (`RevokedSession` exact-pair + `sessionsRevokedAt` watermark, `session.ts:109–136`) | DB-backed — portable |
| Login lockout | `LoginFailure` table, migration #24 (`src/lib/server/auth.ts`) — deliberately DB-backed so it survives restarts | DB-backed — portable |
| API metrics store | in-process ring buffers, globalThis-anchored (`obs.ts`) | **process-local** |
| Notification TTL cache | in-process, ≤64 entries (`notification-cache.ts`) | **process-local** |
| Rate limiters: public lead-capture (token+IP), copilot, document-analyze | in-memory `Map`s (`lead-capture.ts:227–228,302`; `copilot/route.ts:33`; `analyze/route.ts:44`) — documented trade-off, F-06/F-11 family | **process-local** |
| Expiry sweeper | in-process scheduler started at boot via `instrumentation.ts` (ENG-07) | process-local trigger, DB effect |

### 5.2 Vercel verdict (knowledge-based assessment of documented platform behavior; the app side is verified)

**The current architecture CANNOT deploy to Vercel as-is.** Vercel's serverless/Fluid compute functions run on Lambda-like **ephemeral filesystems**: (1) the SQLite file is not part of the build artifact, and even if bundled, writes would be lost on instance recycle and multiple warm instances would silently diverge — the database itself is the non-starter; (2) `db/docs/` uploads are equally ephemeral (the app's own `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md` §4 says exactly this: "uploaded files will disappear … treat document upload as demo/evaluation-only on Vercel" until a Supabase Storage adapter is adopted — **not implemented**); (3) serverless instantiates the app **concurrently in multiple isolated instances**, which breaks every process-local feature (§6.1). The application code itself is otherwise Vercel-compatible (Next.js App Router, `output: "standalone"` ignored by Vercel harmlessly, env-var matrix documented, no `NEXT_PUBLIC_*`), and `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md` is an honest, current-knowledge-shaped runbook for the path that DOES work — but that path **requires the PostgreSQL migration first** (`DATABASE_URL` = Supabase Session Pooler, `prisma/schema.postgres.prisma` swap, `bunx prisma generate && next build` build command) — i.e., option (c) below, an architectural change, not a deploy of what exists.

### 5.3 The honest options

| Option | Fit with what exists today | Assessment |
|---|---|---|
| **(a) Single persistent host (VPS/dedicated) + SQLite** | **1:1 match.** BP-ADR-02 (`05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/BP-ADR-02_SQLITE_SOURCE_OF_TRUTH.md`, ACCEPTED) declares SQLite the authoritative runtime DB for a workload shaped as "single agency, low concurrency, one app server"; the standalone self-hosted path exists (`output: "standalone"`, `bun run start` → `node .next/standalone/server.js`); every in-process feature is correct on one instance; busy_timeout=5000 is tuned for exactly this. | **Recommended posture for the current architecture.** Unverified residue: the standalone boot has never been exercised (R-C3/R-C4). |
| **(b) Managed PostgreSQL migration (Supabase)** | The dormant parallel architecture exists (`prisma/schema.postgres.prisma`, `supabase/` migrations/seed/RLS) — but BP-ADR-02 gates activation behind an owner-approved 5-condition migration project, and **this audit found the dormant path already rotting**: the seed.sql mirror and the validator's canonical counts have drifted from the live SQLite seed (F-1). Out of audit scope to execute; in scope to report that it needs regeneration + revalidation before ANY activation. | Viable future path; currently NOT production-ready and explicitly dormant by decision. |
| **(c) Vercel + external DB** | Documented as the intended handoff deployment (VERCEL_SETUP.md + HANDOFF_CHECKLIST.md steps C–D), but it **is** option (b) plus a Supabase Storage adapter for documents plus AI-provider loss (`.z-ai-config` absent off-platform → copilot/analyze return 503 — documented as expected). | Architectural change, honestly documented, **not done**. |

**Bottom line:** as-is, deploy to a single persistent host; Vercel only after the owner-approved PG migration + storage adapter; and the app's own docs already say both of these things — the assessment confirms the docs are accurate.

---

## 6. Multi-Instance, Session & Restart Analysis

### 6.1 What breaks or degrades with >1 instance (or on serverless)

| Feature | Behavior at N>1 | Severity |
|---|---|---|
| Notification TTL cache | Per-instance buckets → hit rate collapses toward 0 on cold starts; **correctness unaffected** (payload recomputed); multi-tab dedup lost. | degradation only |
| API metrics (`/api/metrics`) | Each instance reports only its own traffic — **misleading operational data** (a fleet looks like a fraction of one instance's numbers). Code documents this ("Single-instance law", `metrics/route.ts:8–10`). | ops signal loss |
| Lead-capture public rate limiter | Per-instance maps → effective abuse budget ×N on a **public unauthenticated** endpoint (capture-token brute force / form spam). | **security-relevant** |
| Copilot / document-analyze limiters | Same ×N weakening of the cost-protection 429s (AI-call cost guards). | cost-protection weakening |
| Login lockout | **SAFE** — DB-backed (`LoginFailure`, migration #24), the deliberate P2 decision ("no Redis by design", documented in `auth.ts:11–18`). | no degradation |
| Sessions + revocation | **SAFE** — stateless HMAC cookie + DB-backed revocation watermark (below). | no degradation |
| Reservation double-booking | **SAFE** — enforced inside the interactive transaction (D-008), not by process state. | no degradation |

### 6.2 Session persistence across restarts (VERIFIED from code)

- **Stateless verification:** `verifySessionCookie` (`session.ts:56–73`) is pure HMAC-SHA256 with `timingSafeEqual` and a 7-day absolute expiry — no server-side session state. The signing secret is read once from `ASAS_SESSION_SECRET` (`session.ts:32–39`); with a stable secret in `.env`, all cookies remain valid across restarts. (Sandbox caveat: R13 environment resets can revert `.env`, which regenerates the secret and resets sessions — recovery protocol in AGENTS.md; production boots *crash* without a strong secret via `src/instrumentation.ts` → `boot.ts`, so the failure mode is loud, not silent.)
- **Revocation survives restarts:** `getCurrentUser` (`session.ts:109–136`) piggybacks three DB-backed checks on the session's own user query — `passwordChangedAt` (F-05), the `sessionsRevokedAt` revoke-all watermark, and the `RevokedSession` exact-`(userId, issuedAtMs)` pair on its unique index. All are table state, not memory. ✓ VERIFIED by code read (live restart-crossing behavior was P0-verified; carried forward as consistent).
- The login lockout likewise survives restarts (`LoginFailure` table — the module's own docblock states the in-memory Map was replaced for exactly this reason).

---

## 7. Operational Readiness

### 7.1 Health / readiness probe (`/api/health`, code + live)

Adequate for a load-balancer probe: unauthenticated by design, `Cache-Control: no-store`, zero data exposure (booleans + coarse posture), and — the important part — **fails fast and loudly when the DB is down**: `SELECT 1` failure flips `status:"degraded"` + **HTTP 503** (`health/route.ts:48–70`). It additionally carries deploy-gate assertions (`demoMode == false`, `sessionSecretConfigured == true` — the P0-3 executable deploy contract), `dbLatencyMs`, `uptimeSec`, `rssMb`, and a migration-count drift signal (`migrations: 25` = full chain). Live: `{"status":"ok","dbOk":true,"dbLatencyMs":0–2,"migrations":25,...}`, p50 8 ms. One nuance: with SQLite `busy_timeout=5000`, a lock-saturated DB can hold the probe's `SELECT 1` up to ~5 s — an LB probe timeout should sit meaningfully below that if fast failure is wanted.

### 7.2 Observability (live-verified)

- **Structured logging** (`logger.ts`): one JSON object per line with `ts/level/event/requestId`; deep, pattern-based redaction (password/secret/token/cookie/apiKey…, depth/size-bounded, error stacks truncated server-side). Production posture: `ASAS_LOG_LEVEL` defaults to **info** (success `http_request` debug lines go silent; warnings/errors + `api_error` remain) and Prisma logs **`['error']` only** in production — `dbQueries` on `/api/metrics` then honestly reports zeros rather than fabricated numbers (`db.ts:93–119`). Verified live in dev: request lines carry `requestId` + route + status + `durationMs`; error lines carry category + code + bounded diagnostics.
- **`/api/metrics`** (ADMIN+ gated — verified: 401 without cookie, non-ok for MANAGER): per-route `count/errors/avgMs/p50Ms/p95Ms/maxMs` over 256-sample rings (52 routes live), `errorsByCategory`, `dbQueries` histogram, `notificationCache` hit/miss, memory. Single-instance law documented in the route itself.
- **F-3 · MINOR — 422 responses are categorized `INTERNAL` in metrics.** `categorizeError` (`session.ts:245–267`) maps 400/401/403/404/409/412/429 but not **422** — live snapshot's `INTERNAL: 5` were all domain 422 rejections (VALIDATION_ERROR, CORRECTION_REASON_REQUIRED, VISIT_REPORT_REQUIRED, EXCEEDS_REMAINING, OPPORTUNITY_NOT_DELETABLE). An operator triaging "INTERNAL" would chase phantom 500s. One-line fix (map 422 → VALIDATION or a DOMAIN category).
- **F-4 · MINOR — `http_request` lines undercount 5xx.** Only `ok()` emits `http_request`; `fail()` emits `api_error` — so log-based error-rate sampling must use `api_error` as the authoritative stream (this audit did). Observed live: 117 fault-injected 500s produced zero 5xx `http_request` lines. Also note `/api/health` bypasses both (raw `NextResponse.json`) — fine, but log analytics should know.

### 7.3 Backups — tooling excellent, scheduling absent (the real ops gap)

- **Tooling (VERIFIED):** `bun run db:backup` → `VACUUM INTO` snapshot (read-only source) + `PRAGMA integrity_check` **on the snapshot** + census + sha256 manifest + `db/docs/` tarball; retention keeps newest **14** (`ASAS_BACKUP_KEEP`) and never deletes anything younger than 1 h; any failed step exits non-zero. `bun run db:restore:drill` verified **PASS** by Agent 2 this session (backup `backup-20261106T170836Z`, manifest `integrity:"ok"`, census 8 users/45 leads/23 opps/46 apartments — mid-audit state, mechanics proven; see `05_ENGINEERING_DOCUMENTATION/12_P4_PRODUCTION_ACCEPTANCE/ASAS_CRM_PHASE4_DATABASE_AND_RECOVERY_ACCEPTANCE.md`, verdict ACCEPTED—WITH FINDINGS, 94/100).
- **F-6 · MINOR→MAJOR-for-ops — no backup schedule exists.** No cron/systemd timer schedules `db:backup` anywhere the app controls; `crontab` isn't even installed in this sandbox, and the platform-mandated 15-min `webDevReview` cron (job 507900) is a QA/development loop, **not** a backup scheduler (per AGENTS.md + the HEAD commit message "cron watchdog 507900 armed"). The last backup on disk (17:08Z) was an audit drill, not an operational event. **RPO is therefore operator-dependent and currently unbounded by process** (realistically: whatever interval a human chooses); RTO is minutes (restore + `ASAS_SESSION_SECRET` re-append + restart — the documented R13 recovery sequence). On a production host this needs a systemd timer/cron + an offbox copy; the tooling is already good enough that this is a one-config-file fix.

### 7.4 Runbooks

Content is strong but **dispersed**: AGENTS.md (environment recovery incl. R13 DB-wipe + secret re-append, stale-client/Turbopack recoveries, resurrection sweep D-040/D-041, sandbox OOM/reaping law) + `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/RECOVERY_GOVERNANCE_PROTOCOL.md` + `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/` (ENVIRONMENT_VARIABLES.md — inventory/provider matrix/precedence; VERCEL_SETUP.md) + `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/` (GITHUB_IMPORT.md with the R-C1 purge-first law; HANDOFF_CHECKLIST.md owner validation incl. known limitations). For a production operator this is adequate-to-good, but there is no single `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/RUNBOOK.md` index, and the sandbox-specific material (zombie-file resurrection sweeps) is noise for them. **F-7 · MINOR (ops):** the watchdog tooling AGENTS.md references (`tmp-scripts/dev-watchdog.ts`) is absent from the current tree (`tmp-scripts/` is git-ignored and environment-reset) — on a real host the equivalent must be systemd supervision with a memory ceiling (see below).

### 7.5 Capacity/incident posture (observed)

- Dev server RSS **2.0–2.2 GB** on a 2-vCPU/4 GB-class host during this audit; the AGENTS.md incident class (background bun processes reaped/OOM-killed; heap-capped relaunch) is documented operational history (dev.log shows a clean restart today, no OOM trace in the current window — precise patterns `heap out of memory|SIGKILL|Killed` = 0 matches in the current log; earlier sessions' incidents are recorded in the P2 incident register).
- A production single-host deployment should pin: 1 Node process (single-instance law), ≥2 GB headroom, systemd `MemoryMax`, `Restart=on-failure`, and the health endpoint as the readiness probe.

---

## 8. Score & Methodology

Suggested weighting retained (CI 20 / Perf 25 / Hosting 25 / Ops 30 = 100); deductions are justified against fresh evidence above.

| Dimension | Weight | Score | Deductions (evidence) |
|---|---|---|---|
| CI/CD | 20 | **12** | −5 F-1: committed database-gates job RED as-written (validator exit 1, undetected because remote CI never ran); −2 build step unverifiable (R-C3, structural); −2 remote execution of ANY job unverifiable (R-C1, structural); −1 F-2 (`prisma/db/` ignore gap). Credit: install/generate/lint/typecheck/migrate/status/seed all freshly locally-proven; test suite Principal-verified 772/772. |
| Performance | 25 | **20** | −4 production performance structurally unmeasurable (R-C3 — dev-mode evidence only, however consistent: 7/7 budgets PASS, fresh vs P2 within noise; notification claim verified exactly; db p95 0 ms/max 28 ms); −1 shared-sandbox ambient noise forced outlier re-measurement (leads first-pass p95 104 → rerun 24; documented). |
| Hosting | 25 | **19** | −3 dormant PG path provably drifting (F-1: seed.sql mirror ≠ live seed) — the documented Vercel path is not currently activatable; −2 production boot/standalone never exercised (R-C3/R-C4); −1 documents storage adapter for the Vercel path not implemented (documented honestly). Credit: BP-ADR-02 coherent single-host posture; VERCEL_SETUP.md accurate + honest; requirements inventory fully verified from code. |
| Ops | 30 | **22** | −4 F-6 backup scheduling absent (manual-only, RPO unbounded by process); −2 F-7 runbook dispersion + watchdog tooling absent from tree; −1 F-3 422→INTERNAL metric mislabel; −1 F-4 http_request 5xx undercount. Credit: health probe (503 fail-fast + deploy assertions) excellent; metrics endpoint live + gated; redaction-first logging; backup tooling + verified drill. |
| **Total** | 100 | **73** | Verdict: **ACCEPTED — WITH FINDINGS** (nothing REJECTED: no critical defect in anything verifiable; the MAJOR is a CI tooling fix with zero production impact). |

---

## 9. Evidence Appendix (commands → outputs, fresh this session)

1. **Health:** `curl http://127.0.0.1:3000/api/health` → `{"status":"ok","dbOk":true,"dbLatencyMs":1,"migrations":25,"demoMode":true,"sessionSecretConfigured":true,"uptimeSec":1008,"nodeEnv":"development","rssMb":2023,...}` (17:18Z); final snapshot 17:26Z: `dbLatencyMs 0, uptimeSec 1704, rssMb 2191`.
2. **Git:** `git remote -v` → empty (exit 0); HEAD `6201496`; status: `M worklog.md`, `?? 05_ENGINEERING_DOCUMENTATION/12_P4_PRODUCTION_ACCEPTANCE/`.
3. **CI local proof:** `bun install --dry-run --frozen-lockfile` → clean; `bunx prisma generate` → exit 0 (+ health re-check unchanged); `bunx tsc --noEmit` → exit 0 (4.5 s); `bun run lint` → exit 0, **0 errors / 41 warnings** (30.7 s); `DATABASE_URL=file:./db/ci-p4a6-check.db bunx prisma migrate deploy` → "All migrations have been successfully applied" (25); `... migrate status` → "Database schema is up to date!"; `... bun run db:seed` → exit 0 (3.4 s, full roster); `python3 scripts/validate-seed.py supabase/seed.sql` → **exit 1**: `rows: 610 across 26 tables · parse failures: 0 | FK violations: 0 | order violations: 0 · canonical counts: {'Visit': (24, 23), 'Activity': (184, 183)} · VALIDATION: FAIL`. Isolated-DB residue removed (`rm -rf prisma/db`). Fresh isolated-DB census: Visit 24 / Activity 187 / Lead 43 / Opportunity 21.
4. **perf:baseline:** `bun run perf:baseline` → table in §3.2; JSON at `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/perf-baseline-2026-11-06T17-21-57-303Z.json` (`serverMetrics: null` — MANAGER cannot read ADMIN-gated metrics).
5. **curl loops:** `bash tmp-scripts/p4-a6-curl-loops.sh` (karim cookie, 1 warmup + 25 measured per endpoint) → §3.3 table; leads rerun p95 23.9 ms; server-side `GET /api/leads` last-60: p50 13 / p95 33 / max 104 ms.
6. **Query counting:** `bash tmp-scripts/p4-a6-query-count.sh /api/notifications` (cold, after TTL wait) → 33 prisma:query lines (2 foreign `SELECT 1`); warm → **exactly 2** (`User`, `RevokedSession`); foreign MISS window (17:24:47Z) → 34; `GET /api/leads` → 7. Log windows: [24460,24494], [24495,24498], [24499,24507], [24279,24315].
7. **Metrics:** `GET /api/metrics` (karim) → §3.4 snapshot; no-cookie → 401.
8. **Error rate:** `rg '"event":"http_request"' dev.log | jq 'select(.ts >= "2026-11-06T16:26:00") | .status'` → 1183×200 + 122×201, 0×5xx; `api_error` since 16:26 = 592 (117 FAULT_INJECTED 500s at 16:49–16:51Z — deliberate test traffic; 0 non-injected 5xx); hydration matches = 0.
9. **Bundle (dev-only):** `curl /` → 33,286 B HTML; 43 JS chunks summed = 11,328,391 B; CSS 271,094 B.
10. **Hosting inventory (code cites):** `.env` (DATABASE_URL absolute; ASAS_DEMO_MODE=1 sandbox posture); `documents.ts:19` DOCS_DIR; `obs.ts` globalThis rings; `notification-cache.ts` ScopedTtlCache; `lead-capture.ts:227–228,302` Maps; `copilot/route.ts:33`, `analyze/route.ts:44` Maps; `auth.ts` LoginFailure; `session.ts:47–73,109–136`; BP-ADR-02; VERCEL_SETUP.md §2–§5; HANDOFF_CHECKLIST.md; GITHUB_IMPORT.md §7.
11. **Backups:** `db/backups/backup-20261106T170836Z/manifest.json` → `integrity:"ok", census {users 8, leads 45, opportunities 23, reservations 9, apartments 46, documents 0}, keep 14`; restore drill output `db/restore-drills/20261106T170840Z/`; Agent 2 deliverable (94/100) cross-cited.
12. **Logger/boot code:** `logger.ts` (level control: prod default info; redaction laws), `db.ts:93–119` (prod `log:['error']`), `instrumentation.ts` (P0-3 boot gate + expiry-scheduler at boot).

### Findings register (summary)

| ID | Severity | Finding | Fix direction |
|---|---|---|---|
| F-1 | MAJOR (CI gate; no production impact) | Committed CI database-gates validator fails locally (seed.sql + EXPECTED_COUNTS drift: Visit 24/23, Activity 184/183 vs live seed 24/187) — CI would be RED on first real run; dormant PG mirror is rotting | Regenerate `supabase/seed.sql` via `scripts/generate-seed-sql.ts`, update `EXPECTED_COUNTS`, re-run validator to PASS |
| F-2 | MINOR | CI relative DATABASE_URL creates `prisma/db/` — not git-ignored (commit-hazard if run locally) | Add `prisma/db/` to `.gitignore` (or absolute URLs in CI) |
| F-3 | MINOR | 422s categorized `INTERNAL` in `/api/metrics` (observed: INTERNAL:5 all 422 domain rejections) | Map 422 in `categorizeError` |
| F-4 | MINOR | 5xx never emit `http_request` lines (only `api_error`) — log-based error-rate sampling undercounts | Document/emit http_request from `fail()` too |
| F-5 | INFO | perf-baseline harness `serverMetrics: null` (MANAGER persona vs ADMIN-gated metrics) | Run harness with ADMIN persona |
| F-6 | MINOR→MAJOR-for-ops | No backup scheduling (manual-only; platform cron 507900 is a QA loop, not backups); RPO operator-dependent | systemd timer/cron for `db:backup` + offbox copy on the production host |
| F-7 | MINOR | Runbooks dispersed; `tmp-scripts/dev-watchdog.ts` absent from tree (git-ignored) — production supervision must be re-created (systemd + MemoryMax) | Single `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/RUNBOOK.md` index + host-level unit files at deploy time |
| — | NOT VERIFIABLE (carried) | Remote CI execution (R-C1), production build/bundle (R-C3), NODE_ENV=production boot gate (R-C4), standalone `bun run start` path | Owner decision: authorize history purge → remote → first real CI run |

*No source, schema, CI, or config files were modified by this audit; the only writes are this deliverable, `tmp-scripts/p4-a6-*` helpers, the harness's own baseline JSON, the worklog/agent-ctx entries, and the removed isolated CI database residue.*
