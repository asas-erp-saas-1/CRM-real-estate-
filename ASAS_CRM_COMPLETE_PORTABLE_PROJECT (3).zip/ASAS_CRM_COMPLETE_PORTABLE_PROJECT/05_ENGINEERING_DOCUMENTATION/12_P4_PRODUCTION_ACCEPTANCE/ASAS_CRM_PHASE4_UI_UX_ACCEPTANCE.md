# ASAS CRM — Phase 4 Independent Production Readiness Audit
## P4-5 · UI/UX, Responsive Design & Accessibility Acceptance (WCAG 2.2 reference)

- **Auditor**: Agent 5 (P4-5), independent sub-agent
- **Date**: 2026-11-06/07
- **Target**: RUNNING app at http://127.0.0.1:3000 (dev server health `ok`, dbOk, 25 migrations, demoMode ON)
- **Method**: live browser inspection via `agent-browser` CLI (Chromium headless), DOM-computed-style measurements, axe-core 4.12.1 scans (dark+light, 4 surfaces), VLM re-inspection of captured screenshots, full keyboard-only passes
- **Users exercised**: sarah (MANAGER), karim (ADMIN), amine (SALES_AGENT — for the 403 lock screen), login form flow
- **Evidence**: 55 screenshots in `05_ENGINEERING_DOCUMENTATION/12_P4_PRODUCTION_ACCEPTANCE/screenshots/` (all named `ui-*`), axe JSON dumps `/tmp/axe-{light,dark,leads-dark,login}.json`
- **Scope law**: AGENTS.md invariants #7–8 + `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/DESIGN_SYSTEM.md` (P41 "Prune & Sable" aubergine identity rev2)

---

## 1. Executive summary + verdict

### VERDICT: **UI/UX ACCEPTED — WITH FINDINGS** (score **83/100**)

The application presents a genuinely coherent, disciplined design system — the strongest of any view surface I have audited on this project. The single-route hash architecture is invisible to the user (back/forward, deep links `#/leads/:id` all work), every one of the 12 registry views is complete and interactive, the palette law (no blue/indigo; aubergine brand + emerald/teal/amber/rose/violet semantics) is respected with zero violations verified by computed-color extraction, and the trilingual FR/AR/EN + dark/light matrix works with genuine Arabic (not machine-styled), correct RTL mirroring, and localized currency (دج). Responsive behavior is exemplary: **zero horizontal overflow at 360, 375, 768, 1280, 1440 and 1920 px on every view tested**, with real mobile patterns (nav drawer, table→card fallback, vertical pipeline stacking) rather than squeezed desktops.

The findings that keep this from a clean accept are concentrated in **accessibility contrast** (a quantified axe-core cluster: sidebar micro-labels at 2.9:1 in BOTH themes, login subtitle 3.04:1, dark-mode muted text at 4.44:1 — a hair under the 4.5:1 AA threshold, 22+ nodes), **25 unnamed `role=progressbar` score bars** on Leads, one **critical `aria-controls` dangling-id** flag on inactive Radix tab triggers, a **dashboard heading-order skip (H1→H3)**, and a systemic minor visual defect: **KPI/stat-card titles ellipsize mid-word** on the dashboard at 1280px (mitigated by `title` attributes and `line-clamp-2` descriptions, but titles themselves violate the design system's "labels wrap, values truncate" law). None of these are launch blockers for an internal CRM, but the contrast cluster + progressbar naming should be fixed before production (est. < 1 day of work).

Business-data safety: the pipeline stage-move test was executed on a synthetic opportunity created via the UI ("TEST P4-5 audit opportunité"), advanced NOUVEAU→QUALIFIÉE through the gate dialog, reverted QUALIFIÉE→NOUVEAU through the manager correction flow (reason logged), and then **deleted via API (200 OK, verified absent)**. No seeded records were modified or deleted. Immutable audit/activity logs retain the honest trail of this test (by design).

---

## 2. Full view inventory + per-view status

All 12 views from `src/lib/client/view-registry.ts` audited at 1280×800 (FR/light unless noted). "Notes" list only findings; everything else on the checklist (typography scale, Lucide-only icons, spacing rhythm, button hierarchy, badges, table density, dialogs, toasts, loading/empty/error states) **passed** per view.

| # | View (hash) | Status | Key evidence | Notes / defects |
|---|---|---|---|---|
| 1 | Dashboard `#/dashboard` | ✅ PASS w/ findings | `ui-dashboard-1280.png`, `-full-`, axe dark+light | KPI/stat titles mid-word ellipsis (18 trunc. nodes, all w/ `title`); H1→H3 heading skip; aria-controls dangling (tab trigger `30d`); contrast cluster (§5); 7 attention cards + 8 stat tiles + 2-col agenda — dense but rhythmic |
| 2 | Parcours client `#/journey` | ✅ PASS | `ui-customer-journey-1280.png`, side panel shot | Funnel chips w/ counts, Priorités/Performance radios, referent filter; customer side panel = Radix Sheet (role=dialog, focus inside, Esc closes) |
| 3 | Prospects `#/leads` | ✅ PASS w/ findings | `ui-leads-1280.png`, table checks | Full toolbar (search/filters/saved searches/sort/density/duplicates/import/export); 12-col table, sticky thead, 25+18 pagination verified; **25 unnamed progressbars (score col)**; avatar-initial contrast 4.44:1 (dark); no sticky first col when table scrolls at 768 |
| 4 | Lead detail `#/leads/:id` | ✅ PASS | `ui-lead-detail-1280.png`, inline edit shot | Clean H1→H2→H3; tabs Aperçu/Historique/Tâches/Visites/Opportunités/Documents; inline edit (click-to-edit name); notes, tags, activity feed, score explainer; hash back/forward verified |
| 5 | Pipeline `#/pipeline` | ✅ PASS | `ui-pipeline-1280.png`, gate + opp-dialog shots | 10 stage columns w/ counts/values/weighted totals; gate dialog "Recommandé avant d'avancer" + override — excellent governance UX; manager correction flow w/ mandatory reason; board scrolls internally w/ `crm-scroll-fade`; empty column has drag hint; card container is `div[role=button]` containing real buttons (nested interactive roles — minor SR hazard) |
| 6 | Visites `#/visits` | ✅ PASS | `ui-visits-1280.png`, `-calendar-` | List/Calendar tabs (month grid renders); time tabs; agent/status comboboxes; quick filters; grouped rows w/ per-visit actions (Fiche/Terminer/Replanifier/Réinitialiser) |
| 7 | Tâches `#/tasks` | ✅ PASS | `ui-tasks-1280.png` | Grouped En retard/Aujourd'hui/À venir; per-user badge count (7 for sarah, 4 for amine) |
| 8 | Inventaire `#/properties` | ✅ PASS | `ui-inventory-1280.png`, `-table-`, unit detail | Project rail w/ availability bars; grid⇄table toggle; 8 status filters; type/parking/price filters; unit detail dialog w/ pending-demand panel, status combobox, price edit |
| 9 | Finance `#/finance` | ✅ PASS | `ui-finance-1280.png`, `ui-finance-403-lock-1280.png` | Recovery KPIs (20.9M DA overdue); radio filters; payments table; 403 lock screen as SALES_AGENT verified ("Restricted access — Access reserved for managers and administrators.") + nav items hidden below role floor |
| 10 | SAV `#/sav` | ✅ PASS | `ui-sav-1280.png` | 7-row cases table |
| 11 | Analytique `#/analytics` | ✅ PASS w/ findings | `ui-analytics-1280.png` | 6 chart sections (Recharts SVG); no blue/indigo; "Valeur gagnée" KPI label truncated w/o clamp/title (1 node); chart axis tspans flagged by axe for contrast |
| 12 | Audit `#/audit` | ✅ PASS w/ findings | `ui-audit-1280.png` | 25-row log; console warns 3 unmapped audit i18n actions (`OPPORTUNITY_CREATED`, `LOGIN_FAILED`, `SESSIONS_REVOKED`) → titleCase fallback shown |
| 13 | Paramètres `#/settings` | ✅ PASS | `ui-settings-*.png` (sarah + karim) | Matching weights (sum 100/100 enforced), thresholds, reservations, **Sécurité des sessions card (P2) present** w/ "Révoquer toutes mes sessions"; Équipe & accès table w/ role comboboxes, RBAC-disabled own row, ADMIN-only "Ajouter un membre" + Objectifs section |
| 14 | Login (pre-auth) | ✅ PASS w/ findings | `ui-login-1280.png`, axe login | FR/EN/ع switcher on the login card; 8 demo quick-login buttons; subtitle contrast 3.04:1; 13 nodes outside landmarks (region rule) |

**Cross-cutting confirmed-good**: Lucide icons only (no mixed icon fonts observed); semantic type scale live (`text-crm-page` 15px h1 verified by computed style); button hierarchy (primary aubergine solid / secondary outline / ghost) consistent; Sonner toasts (role=status, focusable, close button, e.g. "Opportunité créée"); skeletons in `crm-app.tsx` (7 view-level) + `crm/states.tsx` EmptyState/ErrorState; empty states human-written ("Aucune offre — lancez la négociation…", "Glissez une carte ici…"); density toggle actually changes row height (40→36px measured).

---

## 3. Screenshot inventory (55 files → `05_ENGINEERING_DOCUMENTATION/12_P4_PRODUCTION_ACCEPTANCE/screenshots/`)

| File | View | Viewport | Notes |
|---|---|---|---|
| ui-login-1280.png | Login | 1280×800 | FR, light, quick-login list |
| ui-dashboard-1280.png / -full-1280.png | Dashboard | 1280×800 | FR light; full-page variant |
| ui-leads-1280.png | Leads list | 1280×800 | FR light, 25 rows |
| ui-lead-detail-1280.png | Lead detail | 1280×800 | Réda Mokrani fiche |
| ui-lead-edit-dialog-1280.png | Inline name edit | 1280×800 | click-to-edit pattern |
| ui-new-lead-dialog-1280.png | New lead dialog | 1280×800 | Radix dialog, combobox prospect |
| ui-customer-journey-1280.png | Journey funnel | 1280×800 | stage chips + list |
| ui-customer-sidepanel-1280.png | Customer side panel | 1280×800 | Sheet, focus inside |
| ui-pipeline-1280.png | Pipeline board | 1280×800 | 10 columns, weighted totals |
| ui-opportunity-detail-dialog-1280.png | Opp detail dialog | 1280×800 | quick edit, offers, docs |
| ui-pipeline-stage-gate-dialog-1280.png | Stage gate dialog | 1280×800 | "Recommandé avant d'avancer" |
| ui-visits-1280.png / -calendar-1280.png | Visits list / calendar | 1280×800 | month grid November 2026 |
| ui-tasks-1280.png | Tasks | 1280×800 | grouped overdue/today/upcoming |
| ui-inventory-1280.png / -table-1280.png | Inventory grid / table | 1280×800 | project rail + units |
| ui-unit-detail-1280.png | Unit detail dialog | 1280×800 | Lot A-01, pending demand |
| ui-finance-1280.png | Finance | 1280×800 | recovery KPIs + table |
| ui-finance-403-lock-1280.png | 403 lock (amine) | 1280×800 | "Restricted access…" |
| ui-sav-1280.png | SAV | 1280×800 | 7 cases |
| ui-analytics-1280.png | Analytics | 1280×800 | 6 charts, no blue |
| ui-audit-1280.png | Audit log | 1280×800 | 25 rows |
| ui-settings-1280/-scroll/-full/-sessions-1280.png | Settings (sarah) | 1280×800 | incl. Sécurité des sessions card |
| ui-settings-karim-1280.png / -targets-karim-1280.png | Settings (karim) | 1280×800 | ADMIN extras: add member, targets |
| ui-global-search-1280.png | ⌘K palette | 1280×800 | recent + actions; "nesrine" filter verified |
| ui-notifications-1280.png / -open-1280.png | Bell popover | 1280×800 | 8 unread, mark-all-read |
| ui-density-menu-1280.png | Density toggle | 1280×800 | 40→36px rows verified |
| ui-dashboard-375.png / -360.png | Dashboard mobile | 375/360 | no overflow |
| ui-mobile-nav-drawer-375.png | Mobile nav drawer | 375×812 | role=dialog, 19 items, focus in |
| ui-leads-375.png / -360.png | Leads mobile | 375/360 | card list fallback |
| ui-pipeline-375.png | Pipeline mobile | 375×812 | vertical stacked stages + move combobox |
| ui-journey-375.png / ui-properties-375.png / ui-settings-375.png | mobile spot | 375×812 | 0 overflow each |
| ui-dashboard-768.png / ui-leads-768.png / ui-pipeline-768.png | tablet | 768×1024 | sidebar 224px kept; table scrolls internally |
| ui-dashboard-1440.png | desktop | 1440×900 | main 1216px |
| ui-dashboard-1920.png / ui-leads-1920.png | large | 1920×1080 | full-bleed grids (no max-width cap) |
| ui-dashboard-ar-1280.png / ui-leads-ar-1280.png | Arabic RTL | 1280×800 | dir=rtl, Noto Sans Arabic, دج |
| ui-leads-en-1280.png | English | 1280×800 | lang=en |
| ui-dashboard-en-dark-1280.png / ui-leads-en-dark-1280.png | EN dark | 1280×800 | html.dark |
| ui-dashboard-fr-dark-1280.png / ui-leads-fr-dark-1280.png | FR dark | 1280×800 | combo coverage |

All screenshots were re-inspected after capture (VLM pass on dashboard/leads/pipeline/analytics/AR/dark/mobile/focus-ring) — findings below distinguish VLM-claimed vs DOM-verified (two VLM claims — "sidebar profile overflow" and "floating avatar overlap" — were **disproven** by DOM measurement and discarded).

---

## 4. Responsive findings per breakpoint

| Breakpoint | Views checked | Page h-overflow | Findings |
|---|---|---|---|
| **360×800** (worst case) | dashboard, leads | **0px / 0px** | none |
| **375×812** | dashboard, leads, pipeline, journey, properties, settings | **0px on all 6** | nav collapses to hamburger drawer (verified open/close, role=dialog, Esc); leads table → card list (table `display:none` measured); pipeline → vertical stacked stage sections with per-card "Déplacer vers une étape" combobox (smart DnD replacement); **25 interactive elements < 24px tall** on leads (tel: links 14px tall × 94px wide — WCAG 2.5.8 concern); 61 elements 24–44px (AA-OK) |
| **768×1024** | dashboard, leads, pipeline | **0px on all 3** | sidebar remains expanded (224px) — deliberate; leads table scrolls horizontally inside `overflow-auto` wrapper (1465px content in 494px) — **no sticky first column** (name scrolls away; minor); board scrolls internally |
| **1280×800** | all 12 views | **0px everywhere** | board + tabs scroll internally with `crm-scroll-fade` affordance (scrollbar hidden in headless screenshots — DOM `overflow-x:auto` + fade class verified) |
| **1440×900** | dashboard | **0px** | main content 1216px; grids reflow |
| **1920×1080** | dashboard, leads | **0px** | content expands full-bleed (1696px main, 8-col stat strip, table fits) — **no max-width cap**; acceptable for a density-first CRM, noted as a design choice |

---

## 5. Accessibility findings (WCAG 2.2, axe-core 4.12.1 + manual)

### Passed (verified by test, not inspection)
- **Skip link** is the first focusable element on every view ("Aller au contenu principal").
- **Focus visible**: keyboard Tab produces a 2px aubergine ring on nav buttons (VLM-verified on screenshot; `:focus-visible` matches programmatically). Dialog triggers restore focus after Esc (verified twice).
- **Dialog semantics**: role=dialog + aria-labelledby + aria-describedby; **focus trap verified (14 consecutive Tabs, focus never leaves)**; Esc closes; X button labeled ("Fermer"). Minor: `aria-modal` attribute absent (valid ARIA, but announce-modality hint missing — Radix).
- **Icon-only buttons: 41/41 have aria-label** on Leads (checked every visible icon button).
- **Keyboard journey** login → dashboard → dialog completed keyboard-only.
- **Language/direction**: `html[lang]` + `dir` switch correctly for fr/en/ar; phone numbers render LTR-correct inside RTL (VLM-verified digit-group order `0771 12 35 23`).
- **Tables**: `thead th` on all tables (12 cols on leads); row selection checkboxes labeled; pagination buttons with aria-labels and correct disabled state.
- **Reduced motion**: `prefers-reduced-motion` matched by browser test; design system gates its scroll-driven animations on it (documented + `motion-safe:` classes present).

### Violations (axe, quantified)
| Rule | Severity | Where | Detail |
|---|---|---|---|
| color-contrast | serious (6 nodes light / 22+ dark) | sidebar, login, dark cards, charts | **2.9:1** `#67635c` on `#1d1a15` 10px sidebar section labels (BOTH themes — sidebar is theme-invariant dark); **3.04:1** login subtitle `#93908b` on `#fbfaf8` 11px; **3.23:1** white on aubergine logo tile; **4.44:1** `#8c8984` on `#262421` 11–12px dark-mode muted text (tab triggers, list metadata, avatar initials — 0.06 under AA 4.5:1); Recharts axis `tspan`s flagged both modes |
| aria-progressbar-name | serious (25 nodes) | Leads score column | `role=progressbar` (score bars) without accessible name |
| aria-valid-attr-value | **critical** (1 node) | Dashboard date-range tabs | `aria-controls="radix-…-content-30d"` references an id absent from DOM (Radix unmounts inactive panels) — appears on both themes |
| heading-order | moderate (1 node) | Dashboard | H1 → H3 card headers (H2 skipped); detail pages are clean H1→H2→H3 |
| region | moderate (13 nodes) | Login page | form content outside landmarks |
| aria-prohibited-attr | incomplete (2 nodes) | Dashboard | `aria-label` on non-interactive spans (`+983%` delta, `.bg-attn-1`) |

### Manual WCAG 2.2 notes
- **2.5.8 Target Size (Minimum, AA)**: primary buttons 36px tall ✓ (≥24px); but 25 mobile elements < 24px (tel: action links 14px tall) — recommend padding bump or 24px min-height on action links in card lists.
- **1.4.3 Contrast**: as quantified above — the sidebar-label and login-subtitle failures are the only clear sub-4:1 body-text cases; dark-mode muted token is a borderline 4.44.
- **4.1.2**: aria-controls dangling id (critical flag).
- Tables lack `scope="col"` (best practice; axe passes th-in-thead — advisory only).

---

## 6. Visual defects (ranked)

1. **[Medium] Sidebar section micro-labels 2.9:1 contrast** — "COMMERCIAL/OPÉRATIONS/ADMINISTRATION" labels are nearly invisible to low-vision users in BOTH themes (sidebar stays dark). Same family: login subtitle 3.04:1, logo-tile 3.23:1. One-token fix (`--sidebar-accent` lightening).
2. **[Medium] Dark-mode muted text 4.44:1** (22 nodes) — `--muted-foreground` in dark is one shade too dim for 11–12px text (tabs, list metadata, avatar initials). Trivial token bump.
3. **[Low-Medium] KPI/stat-card title mid-word ellipsis** — dashboard attention cards + stat strip titles single-line `text-overflow:ellipsis` ("Uncontac…", "Hot oppor…", "Today's ta…"); descriptions correctly use `line-clamp-2`; every truncated node carries a `title` attr (mitigation), but titles violate the DESIGN_SYSTEM "labels wrap" law at 1280px. Also 1 un-clamped/un-titled instance on Analytics ("Valeur gagnée").
4. **[Low] Chart axis-label contrast (Recharts defaults)** — flagged in both modes by axe (needs manual review; likely below 4.5:1 at 11px).
5. **[Low] Priority column mixed treatment** (Leads) — "Normale/Basse" plain text vs "Urgente" colored+dot in the same column.
6. **[Low] No sticky first column** on the horizontally-scrolling leads table at tablet widths.
7. **[Low] 1920 full-bleed** — no content max-width cap; dashboard stat strip and tables stretch to 1696px (design choice; note for polish).
8. **[Info] No blue/indigo found** — computed-color audit of primary button, Contacté badge, nav accents confirms aubergine `lab(35.7 26.7 −30.4)` (hue ≈ 310°) and violet ≈ 307° family. Palette law: **PASS**.

## 7. UX / interaction defects (ranked)

1. **[Medium] 25 unnamed score progressbars** (Leads) — screen readers announce "progressbar" with no value context; add `aria-label="Score {n}"` or convert to text+bar.
2. **[Low] Pipeline card = `div[role=button]` containing real buttons** — nested interactive roles (advance / open-lead / open-details inside the card-level role=button). Works with mouse/keyboard, but SR users get a compound button; consider making the card body a non-button with an explicit "Ouvrir les détails" affordance (already present).
3. **[Low] 3 unmapped audit i18n actions** (`OPPORTUNITY_CREATED`, `LOGIN_FAILED`, `SESSIONS_REVOKED`) — console warns; audit view shows titleCase fallback (violates AGENTS.md invariant #6 "not acceptable for shipped features"; AR users would see the same fallback).
4. **[Low] Dialogs lack `aria-modal`** (Radix content) — modality not announced; behavior (trap/Esc) is correct.
5. **[Low] Dangling `aria-controls`** on inactive date-range tabs (critical axe flag; Radix unmount artifact) — cosmetic but the only "critical" ARIA flag in the app.
6. **[Info] All core interactions verified working**: hash back/forward (leads↔detail↔leads), dialog open/Esc/X/focus-restore, inline edit, combobox search+select, sort (alphabetical verified), pagination (25→18 rows, prev/next disabled states), density toggle (40→36px rows), global search (⌘K, "nesrine" → 3 hits), notifications popover (8 unread, mark-all), stage advance with governance gate + manager correction revert, user switching (role-scoped nav + 403 lock), language + theme persistence across reloads.

## 8. Languages & themes findings

- **Arabic (RTL)**: `dir=rtl` + `lang=ar` + Noto Sans Arabic font swap verified; sidebar correctly mirrored (x=1056–1280); genuine Arabic strings (nav: "لوحة القيادة، رحلة العميل، العملاء المحتملون، مسار البيع"); currency localized to **دج**; VLM confirms proper shaping, no tofu, mirrored card internals, LTR-correct phone digits. Minor: one delta card truncated in AR ("…61.7~"), "+983%" sign placement is a bidi nuance (acceptable).
- **English (LTR)**: full translation (nav, h1 "Leads", buttons, 403 copy) ✓.
- **French**: default, complete ✓.
- **Dark mode**: `html.dark`, warm charcoal surfaces, alpha borders, distinct elevation (VLM: "8/10 — true dark, layers read clearly"); marginal muted-text contrast (4.44:1) is the one systemic dark defect; no glow/gradient violations.
- **Light mode**: clean; login subtitle + sidebar labels are the contrast outliers.
- **Persistence**: language + theme + density persist across reloads (zustand/next-themes) ✓.
- **Combos captured**: FR-light, FR-dark, EN-light, EN-dark, AR-light on Dashboard + Leads (6 dashboard + 5 leads files).

## 9. Score (0–100)

| Dimension | Weight | Score | Rationale |
|---|---|---|---|
| Visual consistency | 20 | **16** | Palette law 100% (computed-color verified); type scale + Lucide + radii + button hierarchy uniform; docked for KPI-title truncation cluster, priority-column inconsistency, chart-axis contrast |
| Interaction consistency | 20 | **18** | Every audited flow works incl. the governance gate + correction + revert; hash nav flawless; docked for progressbar naming + nested role=button cards |
| Responsive design | 20 | **18** | 0 overflow across 6 breakpoints; real mobile patterns; docked for no sticky first col (tablet), sub-24px mobile targets, no 1920 cap |
| Accessibility (WCAG 2.2) | 20 | **13** | Excellent foundations (skip link, traps, labels, focus rings, i18n semantics) but quantified AA contrast cluster + 25 unnamed progressbars + critical aria-controls flag + heading skip |
| Languages & themes | 20→**10** | **9** | Genuine AR RTL + localized currency; full EN; dark/light clean; docked for 3 unmapped audit i18n keys |
| States & feedback | 10 | **9** | Skeletons, empty states, 403 lock, Sonner toasts all present and well-written; docked for fallback audit labels |
| **TOTAL** | 100 | **83** | **ACCEPTED WITH FINDINGS** |

## 10. Evidence appendix

- DOM measurements (selected):
  - `hscroll` = `document.scrollWidth − clientWidth` = 0 at 360/375/768/1280/1440/1920 on all tested views.
  - Primary button bg `lab(35.72 26.70 −30.37)` (aubergine, hue ≈ 310° — NOT blue/indigo); "Contacté" badge `lab(35.28 67.99 −88.79)` (violet ≈ 307°); "Nouveau" badge `oklab(0.42 −0.085 0.031)` (muted teal).
  - Nav button classes: `focus-visible:ring-2 focus-visible:ring-sidebar-ring`; `--tw-ring-shadow: 0 0 0 2px #a77fc5` when focused (ring visible in screenshot, VLM-confirmed).
  - Leads table: 12 `th`, 0 `scope`, sticky `thead` (`position: sticky`), 25 rows page 1 / 18 page 2; sort asc verified (Abdelhak→Bilal); density 40→36px rows.
  - Truncation: 18 dashboard nodes `scrollWidth > clientWidth`, all with `title` attr; KPI titles `text-overflow: ellipsis` + `line-clamp: none`; descriptions `line-clamp: 2`.
  - Touch targets (mobile leads): 86 interactive, 25 < 24px (tel: links h=14px), 61 in 24–44px.
  - Focus trap: 14 Tabs → `focusInsideDialog: true`; Esc → dialog closed, focus on "Nouveau prospect" trigger.
  - Dialog attrs: `role=dialog`, `aria-labelledby=radix-_r_2sj_`, `aria-describedby=radix-_r_2sk_`, `aria-modal` absent.
  - Icon-only buttons on Leads: 41/41 aria-labeled.
- axe-core scans: `/tmp/axe-light.json` (dashboard FR light), `/tmp/axe-dark.json` (dashboard EN dark), `/tmp/axe-leads-dark.json`, `/tmp/axe-login.json`. Counts: login 2 violations; dashboard dark 2+3 incomplete; dashboard light 2+3; leads dark 3+2 (44 passes).
- Stage-move protocol (safety): created "TEST P4-5 audit opportunité" (Réda Mokrani, 1.5M DA, NOUVEAU) via UI dialog → advanced via gate dialog "Avancer quand-même" → board count NOUVEAU 0→1 / QUALIFIÉE 3→4 → reverted via "Nouveau CORRECTIONS (MANAGER)" + reason "Test audit P4-5 : retour à l'étape d'origine (Nouveau)" → board back to NOUVEAU 1 / QUALIFIÉE 3 → `DELETE /api/opportunities/cmw58u8ue004zqy536s3shoub` → 200, re-GET confirms absent. Audit/activity trails of the test remain (immutable, by design).
- Console: no page errors; 3 i18n warnings (unmapped audit actions). Network: all API calls 200/201 during flows.
- VLM re-inspections: dashboard (1280 light), leads (1280), pipeline, analytics, dashboard-AR, dashboard-dark, dashboard-375, focus-ring check. Two VLM claims disproven by DOM and discarded: "sidebar user-chip overflow" (rect right 212 < sidebar right 224) and "floating avatar overlapping card" (no fixed/absolute floating elements found).

### Recommended next actions (priority order)
1. Fix the contrast cluster: sidebar section labels, login subtitle, dark `--muted-foreground` (→ ≥ 4.5:1), logo tile, chart axis text. (a11y, ~half-day)
2. Add accessible names to the 25 Leads score progressbars. (a11y, 1 line/component)
3. Fix dangling `aria-controls` on Radix tab triggers (render panels or drop the attr). (a11y, small)
4. Add `audit.action.{OPPORTUNITY_CREATED,LOGIN_FAILED,SESSIONS_REVOKED}` keys fr/en/ar. (i18n, small)
5. Wrap dashboard KPI/stat titles with `line-clamp-2` (or widen the label area) per DESIGN_SYSTEM truncation law. (visual, small)
6. Optional polish: sticky first column at tablet; 24px min-height on mobile action links; `aria-modal` on dialogs; insert H2 on dashboard cards.
