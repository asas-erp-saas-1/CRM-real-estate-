# ASAS CRM — Phase 4 Remaining Defects Register

**Compiled by:** Principal Acceptance Auditor (consolidating six independent agent audits + Principal cross-review)
**Date:** 2026-11-06 · **HEAD:** `6201496` · Supersedes-for-Phase-4: the 2026-11-02 register (which predates P0/P1/P2 remediation and is stale)

Status: OPEN · BLOCKED (external gate) · OWNER (business decision) · LEGAL (counsel required) · INFO (accepted-by-design)

Severity: CRITICAL (blocks release) · MAJOR (blocks a stated readiness dimension) · MINOR (quality debt) · INFO

---

## 1. Release blockers (must close before PRODUCTION — none block staging)

| ID | Sev | Item | Evidence | Owner/path |
|---|---|---|---|---|
| RB-1 | MAJOR | **Hosting architecture decision + execution**: SQLite + db/docs/ + process-local state (metrics/cache/rate-limiters) cannot run on Vercel-as-is (ephemeral FS); multi-instance collapses caches and fragments metrics. VPS/single-persistent-host is the 1:1 match (BP-ADR-02); PG migration or Vercel+external-DB are larger changes. | P4-6 hosting assessment; app's own VERCEL_SETUP.md documents the gap | Owner decision → deployment |
| RB-2 | MAJOR | **Production runtime profile unverified**: `next build` forbidden in sandbox (bundle/standalone start unverified); NODE_ENV=production boot gates + demo-off + TLS termination never exercised end-to-end. | E-1/E-3 entry-assessment ledger | Target-host staging run |
| RB-3 | MAJOR | **CI not green as-written + no remote**: `scripts/validate-seed.py` FAILS (supabase/seed.sql drift: Visit 24/23, Activity 184/183 — Principal reproduced: "VALIDATION: FAIL"); git history purge (dead secret blob `66b7c13` + demo DB in ~10 commits) is a pre-remote authorization gate. | P4-6 F-1 + GIT_HISTORY_PURGE.md | Fix seed.sql → purge w/ owner authorization → add remote → CI green |
| RB-4 | MAJOR | **Backup scheduling absent** (tooling verified PASS): manual-only backups → RPO operator-dependent; retention policy unenforced by scheduler. | P4-6 F-6; P4-2 drill PASS | Owner decision (cron/systemd on target host) |
| RB-5 | MAJOR | **TLS/HSTS/CSP not active** — deferred to edge, edge doesn't exist yet. | P4-3 F-A3-1 | Target-host ingress |
| RB-6 | LEGAL | **Algeria Law 18-07 privacy program**: DPA with AI provider (lead names/notes transit), retention/DSR tooling, consent basis for comms — requires qualified counsel; technical controls ≠ legal compliance. | P4-3 §privacy | Legal counsel |
| RB-7 | BLOCKED | Email/SMS integration stays absent pending approved provider credentials (mission rule: no unapproved integrations). Evaluation + unblock checklist done (P2/W5). | P2 carry-forward | Owner + provider selection |

## 2. Open engineering defects (fix before/with production; none block staging)

| ID | Sev | Item | Evidence | Found by |
|---|---|---|---|---|
| ED-1 | MINOR | **Attribution test suite leaves permanent residue**: no afterAll — writes 3 LeadTouch rows to a seed lead (Zineddine Hamlaoui) on EVERY full-suite run; pollutes attribution analytics + demo narrative. (Principal cleaned this session's 3 rows; the generator remains.) | `tests/security/attribution.test.ts` — no teardown; touches created 16:56:50-51 during suite window | **Principal cross-review (NEW)** |
| ED-2 | MINOR | **A11y contrast cluster**: sidebar micro-labels 2.9:1, login subtitle 3.04:1, dark muted 4.44:1 (22+ nodes, both themes) — WCAG AA sub-threshold. | P4-5 axe + computed styles | P4-5 |
| ED-3 | MINOR | **25 unnamed `role=progressbar`** score bars on Leads (aria-progressbar-name) + 1 dangling aria-controls on inactive date-range triggers. | P4-5 DOM audit | P4-5 |
| ED-4 | MINOR | **3 unmapped audit i18n actions** (`OPPORTUNITY_CREATED`, `LOGIN_FAILED`, `SESSIONS_REVOKED`) → titleCase fallback + console warns. | P4-5 audit view | P4-5 |
| ED-5 | MINOR | **Zombie-file law violated in letter**: 22 ever-deleted ∧ in-HEAD files; 4 byte-identical to pre-purge (finance-attention, installment-detail-dialog, sav-attention, sav-table) reintroduced by UUID commit `9cdf1fb`; all live & functioning → needs explicit ratification (accept as operative) or re-delete + sweep re-run per D-041. | Principal git-hash reproduction | P4-1 + Principal |
| ED-6 | MINOR | **F2 (P1 carry-forward)**: money-cap asymmetry — `1e12` cap enforced on one installments route, not both. | P4-1 confirmed open | P1 |
| ED-7 | MINOR | **F3 (P1 carry-forward)**: direct-booking audit `after.value` semantics. | P2 register | P1 |
| ED-8 | MINOR | **F5 (P1 carry-forward)**: 12 dialogs not yet migrated to RHF/Zod (functional, pattern debt). | P2 register | P1 |
| ED-9 | MINOR | **Seed fidelity**: 7 won reservations bypass two-step closure stamps (convertedBy/convertedAt + SALE_VALIDATED audits absent; trail otherwise complete). | P4-2 F-0 | P4-2 |
| ED-10 | MINOR | **No service-level cap on échéancier totals** (sum(installments) ≤ agreed) — per-line guards only; live data clean. | P4-2 F-1 | P4-2 |
| ED-11 | MINOR | **Legacy `db:snapshot` file-copy path can orphan db/docs/ on restore** (latent; manifest system handles both). | P4-2 F-3 | P4-2 |
| ED-12 | MINOR | **Observability gaps**: 5xx responses never emit `http_request` lines; 422 mislabeled INTERNAL in the metrics store. | P4-6 F-3/F-4 | P4-6 |
| ED-13 | MINOR | **`prisma/db/` not git-ignored** (CI-run residue hazard). | P4-6 F-2 | P4-6 |
| ED-14 | MINOR | **Mobile touch targets**: 25 sub-24px targets at 375px (tel: links 14px); no sticky first column on 768px table scroll. | P4-5 responsive | P4-5 |
| ED-15 | INFO | **Test-suite fragility under interruption**: killed mid-suite runs leave residue that deterministically blocks the permission-matrix suite until manual marker-scoped cleanup (observed + remediated this session; moot on ephemeral-DB CI). | Principal incident AUDIT-E1 | Principal |
| ED-16 | INFO | **WIP limits advisory-only** (D-UX-043 — accepted by design; production should consciously accept). | P4-4 | P4-4 |
| ED-17 | INFO | **Échéancier deliberately partial** (H-31: 24.36M of 58M scheduled — heavy finance is ERP territory per operating model; flag for ERP handoff). | P4-4 | P4-4 |
| ED-18 | INFO | **Lint warnings 41** (was 37 at P1 — post-P1 additions; 0 errors). Dead vars in auth.ts:34-36, obs.ts:68, reservation-lifecycle.ts:418. | P4-1 | P4-1 |
| ED-19 | INFO | **Enum single-sourcing residue** (5 inline re-declarations + 1 inline z.enum + 16 dead exports). | P4-1 | P4-1 |
| ED-20 | INFO | **Stale architecture doc**: 05_ENGINEERING_DOCUMENTATION/01_SYSTEM_ARCHITECTURE/ARCHITECTURE.md census 28 routes/19 modules/9 models/12 migrations behind reality (87 route files/112 handlers/40+4 modules/35 models/25 migrations). | P4-1 C-1 | P4-1 |
| ED-21 | INFO | **Bundle size unmeasured** (build forbidden — dev-mode numbers only, documented with caveat). | E-1 | P4-6 |
| ED-22 | INFO | **Attribution fallback for the 7 seeded won deals** (predate touches) — counted and surfaced, never hidden. | P2 register | P2 |

## 3. Environment-class facts (not defects — binding evidence limits)

| ID | Fact |
|---|---|
| EN-1 | No git remote → remote CI execution NOT VERIFIABLE (local proof complete except ED/RB-3). |
| EN-2 | `bun run build` forbidden in sandbox → production bundle NOT VERIFIABLE. |
| EN-3 | NODE_ENV=production not exercisable → boot gates IMPLEMENTED-NOT-RUNTIME-VERIFIED. |
| EN-4 | WAL BLOCKED by Prisma engine SQLite 3.46.0 bug range — delete-journal + busy_timeout 5000ms verified safe (P0-2 decision upheld). |
| EN-5 | Single-org live seed → cross-org live probe NOT RUNNABLE this session (compensated: 135-test permission matrix incl. 20 org-fence rows, green). |
| EN-6 | Platform watchdog cron (job 507900) runs a 15-min webDevReview loop — an environmental fact recorded per mission §12 (no new jobs created by Phase 4). |
| EN-7 | A small pre-existing non-blocking DB delta observed at session start (unattributed — likely watchdog-period suite interruption); current state verified EXACTLY at seed baseline by the Principal (final census: 8 users/1 org/43 leads/21 opps/46 apts/8 res/3 offers/8 pay/14 inst; 7 won = 236,200,000 DZD; 0 stale holds; integrity ok). |

---

**Register totals:** 7 release blockers (3 MAJOR-engineering, 2 MAJOR-infra/ops, 1 LEGAL, 1 BLOCKED-external) · 22 open engineering defects (0 CRITICAL, 0 new-MAJOR, 14 MINOR, 8 INFO) · 7 environment facts. Every item carries evidence and an owner/path. Nothing was silently dropped; nothing was converted from NOT-VERIFIED to PASS.
