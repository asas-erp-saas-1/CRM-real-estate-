# ASAS CRM — Phase 4 Independent Production Readiness Audit
## P4-2 · Database, Data Integrity & Disaster Recovery Acceptance

| | |
|---|---|
| **Task ID** | P4-2 (Agent 2 — Database / Data Integrity / DR Auditor) |
| **Date** | 2026-11-06, 16:45–17:15 UTC (all live probes timestamped in evidence appendix) |
| **Scope** | `prisma/schema.prisma` + live `db/custom.db` (SQLite via Prisma 6.11), 25-migration chain, data-integrity probes, concurrency guard chain, SQLite runtime, backup/restore runbook incl. live drill |
| **Method** | READ-ONLY live probes (SELECT/PRAGMA only, scripts under `tmp-scripts/p4-a2-*`) + code reading + one isolated restore drill. `db/custom.db` was NEVER written by this audit (see §6 for the read-only VACUUM INTO reasoning). |
| **git HEAD** | `62014966b4693d40c343b4e18af2dd332fbb3445` |
| **Dev server** | `http://127.0.0.1:3000` — `/api/health` → HTTP 200 at audit time (never restarted) |

---

## 1. Executive Summary & Verdict

**VERDICT: DATABASE ACCEPTED — WITH FINDINGS** *(all findings MINOR or INFO; zero CRITICAL, zero MAJOR; none block production readiness).*

The database layer of ASAS CRM is in an exceptionally verifiable state. Every claim made in prior reports was re-established with fresh evidence: the schema (35 models — see note F-0) matches the live database **column-for-column (0 mismatches across 35 tables)**; the migration chain is **25/25 applied, canonical, chronological, 0 NULL `finished_at`, 0 rollbacks**, and `bunx prisma migrate status` reports *"Database schema is up to date!"*; `PRAGMA integrity_check` = ok, `PRAGMA foreign_key_check` = 0 rows, and **32 explicit orphan/referential probes all returned 0**. The D12 live-hold partial unique indexes (4/4) exist live with the exact documented WHERE clauses, and the double-booking guard is **inside the interactive transaction** in code (house invariant #5), with the partial indexes as the absolute DB backstop. Money consistency is clean: all 7 won deals have `value == agreed price == unit price`, no over-collection, no negative money, `PAID` stamps consistent. The backup/restore runbook was exercised **live**: the restore drill ran end-to-end (sha256 byte-identity → integrity_check on the restored copy → census match → PASS) while demonstrably never touching `db/custom.db`.

Four findings (all MINOR) and several INFO items are documented in §4/§7; the most notable are a **seed-fidelity gap** (all 7 seeded CONVERTED reservations lack the `convertedById`/`convertedAt` two-step-closure stamps — the runtime path stamps them, the seed does not), and a **missing service-level cap on échéancier totals** (`createInstallment` cannot over-collect per line, but nothing caps `sum(installments) ≤ reservation.amount`).

**Score: 94 / 100** (methodology in §8).

---

## 2. Actual Schema Status (verified live)

### 2.1 Model inventory — 35 models (not 34)

`prisma/schema.prisma` declares **35 models** (the briefing said 34; live parse of the file + live table inventory both say 35 — F-0, INFO). The live DB has exactly these 35 tables + `_prisma_migrations` (36 tables total excluding `sqlite_%` internals). **0 models missing from the live DB; 0 extra tables.**

Tenancy: `orgId` present on every tenant-owned model (Organization relation on all 30 tenant tables; `LoginFailure` is the documented pre-auth exception — keyed by email/ip only). Multi-tenant design holds.

### 2.2 Column-level fidelity: 0 mismatches

Probe `tmp-scripts/p4-a2-db-probe.ts` §2 parses every `model {}` block of `schema.prisma`, extracts scalar fields, and compares with `PRAGMA table_info("<table>")` for all 35 tables:

```
column mismatches across all models: 0
```

### 2.3 Index fidelity: exact match (79 + 19 + 4)

- Live explicit indexes (sql NOT NULL): **102**
- `schema.prisma` declares **79 `@@index`** → live non-unique explicit indexes = **102 − 23 unique = 79** ✔ exact
- Live **unique** indexes = **23** = **19 schema-declared** (all 19 verified present, incl. `Lead_orgId_phone_key`, `Installment_reservationId_seq_key`, `SavCase_orgId_seq_key`, `Document_storedName_key`, `LeadCaptureToken_tokenHash_key`, `RevokedSession_userId_issuedAtMs_key`, …) **+ 4 raw partial unique live-hold backstops** (Prisma-inexpressible, migration-borne) ✔ exact

### 2.4 The four D12 live-hold partial unique indexes (live SQL, verbatim)

```
Reservation_apartment_live_hold_uq  ON Reservation(apartmentId)   WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')
Reservation_opportunity_live_hold_uq ON Reservation(opportunityId) WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')
Offer_apartment_live_hold_uq        ON Offer(apartmentId)         WHERE status IN ('ACTIVE','CONFIRMED') AND apartmentId IS NOT NULL
Offer_opportunity_live_hold_uq      ON Offer(opportunityId)       WHERE status IN ('ACTIVE','CONFIRMED')
```

All four match `prisma/migrations/20261102000000_phase2_d12_live_hold_unique/migration.sql:30-36` and `prisma/migrations/20261105180000_p1_offer_option/migration.sql:58-64`, and are mirrored idempotently in `prisma/live-hold-indexes.sql:17-39` (the db:push companion — DB-04 fix). Data-level duplicate checks under the same predicates: **0 violations on all four**.

### 2.5 onDelete behaviors (schema → live)

Cascade (structural children, verified in live DDL): `PipelineStage→Pipeline`, `LeadTag→Lead/Tag`, `Building→Project`, `Apartment→Building`, `PropertyMatch→Requirement/Apartment`, `VisitApartment→Visit/Apartment`, `ProjectAssignment→Project/User`, `LeadDuplicateDismissal→LeadA/LeadB`. Everything else: RESTRICT on required FKs (org/user/lead/opportunity/apartment/installment parents — history never silently orphaned) and SET NULL on optional refs (ownerId/agentId/contactId/activity refs). Verified live in `0_init` + additive migrations (`ON DELETE RESTRICT ON UPDATE CASCADE` house style). The Finance family is RESTRICT: payments/installments never die with a silent cascade — deletion paths are explicit (`RESERVATION_HAS_DEPENDENTS` guard, §5).

### 2.6 Key domain shapes verified live

- **Reservation** — 36 columns incl. the full §37/§38 economics family (`commissionBasis/Status/EarnedAmount/ReceivedAmount/ReceivedAt`, `incentiveBasis/Status/DecidedById/DecidedAt/PaidAt`) and the two-step closure family (`closureRequestedById/At`, `closureEvidence`, `convertedById/At`). Indexes incl. the sweeper scan `[status, expiresAt]` and `[orgId, incentiveStatus]` (W1.8 DB-4). Matches schema.prisma:692-765.
- **Offer** — nullable `apartmentId` (unit-less negotiation is legal), `convertedReservationId` (no relation — house pattern), status vocabulary DRAFT/ACTIVE/CONFIRMED/CANCELLED/EXPIRED/CONVERTED. Matches schema.prisma:796-835.
- **Installment/Payment** — `@@unique([reservationId, seq])`; Payment ≤ remaining is service-enforced (§5); statuses PLANNED/CALLED/PAID/CANCELLED with derived overdue/partial (never stored).
- **Activity/AuditLog** — Activity carries 7 nullable entity refs (lead/opp/contact/visit/reservation/task/savCase) + actor; **0 rows with all refs NULL** (probe). AuditLog entity taxonomy live: USER/APARTMENT/INSTALLMENT/OPPORTUNITY/RESERVATION/VISIT/SAV_CASE/LEAD/OFFER/TASK/ORG — all UPPERCASE (invariant #6 holds).
- **Lead→Opportunity→Customer chain** — `Lead.@@unique([orgId, phone])` (phone = documented duplicate key, duplicate probe = 0 groups), `Contact.leadId @unique` (1:1), `Lead.convertedContactId @unique` + `convertedAt` (Phase 2.1 W2-10). Chain integrity: §4.4.

---

## 3. Migration Acceptance

### 3.1 Chain status (exact command output)

```
$ bunx prisma migrate status
25 migrations found in prisma/migrations
Database schema is up to date!
```

(Read-only CLI command — the only Prisma CLI command run by this audit. Full stdout incl. datasource line in appendix A-1.)

### 3.2 Ordering & canonicity

- 25 directories: `0_init` (baseline) + 24 timestamped, **strictly chronological** (`ls prisma/migrations/ | sort` — appendix A-2), 2026-10-03 → 2026-11-06, no gaps in the sequence semantics (Prisma applies by directory name order; every migration present in `_prisma_migrations`).
- `migration_lock.toml` = `provider = "sqlite"` — consistent with the datasource.
- `_prisma_migrations`: **25 rows, names == directory names (set equality verified programmatically)**, applied in exact chronological order by `finished_at`, **0 NULL finished_at, 0 rolled_back_at** (probe appendix A-3).
- Clean-reconstruction capability: the chain was fully replayed to rebuild the dev DB on 2026-11-04 (AGENTS.md:83, DB push-drift incident) and `migrate status` confirms zero drift today. The chain is self-healing evidence, not just bookkeeping.

### 3.3 Content audit of the 5 critical migrations (read in full)

| Migration | Verified content vs schema.prisma |
|---|---|
| `0_init` | Baseline: 20 tables + full index set incl. `Lead_orgId_phone_key`, `Lead.score` (historical NOT NULL DEFAULT 0 — documented in p1_lead_score header). All FKs RESTRICT/SET-NULL/CASCADE exactly as schema declares. |
| `20261102000000_phase2_d12_live_hold_unique` | Exactly the 2 Reservation partial unique indexes (raw SQL, deploy-only law). Header documents pre-check "0 violations on both invariants" and the ADR-004 deadlock lesson (partial, NOT global unique). Matches live DDL byte-for-byte. |
| `20261105180000_p1_offer_option` | `Offer` table + 4 read-path indexes + the 2 Offer partial uniques (`ACTIVE','CONFIRMED'` + `apartmentId IS NOT NULL` guard — the null-unit DRAFT case stays legal). Matches schema Offer model exactly (36→36 columns incl. all status stamps). |
| `20261106030000_p2_session_governance` | Additive: `User.sessionsRevokedAt`, `RevokedSession` (`@@unique([userId, issuedAtMs])` — point-lookup revocation), `LoginFailure` (`[email, at]` window scan + `[at]` retention sweep). All three verified live. |
| `20261106040000_p2_lead_touch` | `LeadTouch` table + `(orgId, leadId, occurredAt)` + `(orgId, channel)` indexes; `Lead.source` immutability is schema/API-side (PATCH never accepted it). Matches live. |

Also read in full: p4_composite_indexes, p8_9, p11, p13, p14, p16, p18, p20, p29, p30, p54, phase_c_visit_report, pd_finance_sav_targets, master_w18_incentive_index, arabic_aliases, phase21_lead_converted_at, g5_hot_query_indexes, g5_loss_reason_code, p1_lead_score, p1_capture_token — **all 25/25 read**; every SQL statement reconciles with the live DDL and schema.prisma (the 0-mismatch column/index comparison of §2 is the mechanical proof). Notable history preserved correctly: P13 created finance tables → P16 removed SAV → P18 removed finance/targets → Phase D (2026-10-31) re-introduced Installment/Payment/SavCase/SalesTarget — each removal cleanly deleted domain timeline/audit rows first (no orphan vocabulary).

---

## 4. Data-Integrity Probe Results (live, read-only)

Probe scripts: `tmp-scripts/p4-a2-db-probe.ts`, `p4-a2-anomaly-probe.ts`, `p4-a2-timeline-probe.ts` (full outputs saved to `tmp-scripts/p4-a2-*-output.txt`).

### 4.1 Engine-level

- `PRAGMA integrity_check` → **ok**; `PRAGMA foreign_key_check` → **0 rows**; `PRAGMA foreign_keys` → **1** (engine-enforced).

### 4.2 Orphan / referential probes — 32 checks, ALL ZERO

leads without org 0 · dangling ownerId 0 · opportunities without lead/org 0 · dangling contactId 0 · contacts without lead 0 · payments without installment 0 · payments→installment→reservation chain 0 · installments without reservation 0 · reservations without opportunity/apartment 0 · offers without opportunity 0 · dangling offer apartmentId 0 · CONVERTED offers with dangling/NULL convertedReservationId 0/0 · activities with no entity ref 0 · dangling activity leadId/reservationId 0 · dangling audit actorId 0 · dangling SAV reservationId 0 · installment seq≤0 / amount≤0 / payment amount≤0 0/0/0 · duplicate (reservationId,seq) 0 · documents with empty entityId 0 · document entityType outside vocabulary 0 · dangling task leadId 0 · visits without lead 0 · leadTouches without lead 0 · revokedSessions with dangling userId 0 · user orgId pointing nowhere 0.

**Orphan total: 0. Duplicate phone-key groups: 0** (and 0 same-phone-across-orgs; 0 non-E.164-shaped phones).

### 4.3 Money consistency (census at probe time: 8 payments, 14 installments, 8-9 reservations — see F-3)

- Over-collected installments (payments > amount + 0.01 DZD): **0**
- `status=PAID` but under-collected: **0** · fully-covered but status≠PAID: **0** · PAID with NULL paidAt: **0**
- Negative money anywhere (amount/deposit/commission/incentive): **0**
- **Won deals (7 CLOSED_WON): `opp.value == reservation.amount == apartment.price` on all 7 (±0.01)**; every reservation CONVERTED; every apartment SOLD; `CONVERTED reservations whose apartment is not SOLD: 0`; `apartments SOLD without CONVERTED reservation: 0`; `apartments RESERVED without live hold: 0`; `OPTIONED without live offer: 0`; `live holds on non-RESERVED apartments: 0`.
- Won-deal money map (full table in appendix A-4): 3 deals carry full 3-line échéanciers matching the agreed price to the cent (e.g. Farid B. 17.5M = 17.5M scheduled = 17.5M collected across 3 payments); 4 deals are échéancier-free (cash-style closes — legal).
- Audit trail for won deals: every one of the 7 has `OPPORTUNITY_STAGE_CHANGED → CLOSED_WON` (1 each) + `APARTMENT_STATUS_CHANGED → SOLD` (1-2 each) + commission/incentive audits (`COMMISSION_SET` ×7, `INCENTIVE_DECIDED` ×5, `INCENTIVE_PAID` ×2 live vocabulary). **Finding F-1:** `SALE_VALIDATED` audit rows = 0 for all 7 and `convertedById/convertedAt` = NULL on all 7 — see §7.

### 4.4 Conversion chain (Lead → Opportunity → Contact)

CONVERTED leads without convertedContactId **0** · whose contact row is missing **0** · contacts whose lead.convertedContactId points elsewhere **0** · CONVERTED leads without convertedAt **0** · opportunities on CONVERTED leads without contactId **0** · opportunities whose contactId ≠ lead.convertedContactId **0**. The chain is airtight in the live data.

### 4.5 Duplicate-management / capture-token surfaces

`LeadDuplicateDismissal` unique `[orgId, leadAId, leadBId]` live ✔ (unordered-pair law). `LeadCaptureToken.tokenHash` unique live ✔ (hash-only storage law — plaintext never persisted; verified in migration + `lead-capture.ts` contract per schema comments).

### 4.6 Census (cross-check vs briefing)

Live at probe ~17:01Z: users 8, leads 44, contacts 20, opps 21, reservations 8, offers 3, installments 14, payments 8, savCases 7, activities 190, auditLogs 364, documents 0, leadTouches 3, apartments 46, salesTargets 3. The briefing's "10 reservations, 5 offers" matched **no** observed state; payments (8) and installments (14) matched. See F-3 for why counts drift.

---

## 5. Concurrency Findings — the full guard chain

### 5.1 The double-booking law is INSIDE the interactive transaction (house invariant #5 — VERIFIED in code)

`src/lib/services/reservations.ts:412-624` (`bookUnitInTx`) runs inside `db.$transaction` (opened at `createReservation`, reservations.ts:669; the same core is ridden by offer conversion — one law, two entry points). Guard sequence, all **inside the tx**:

1. **Apartment re-read in-tx** (`tx.apartment.findFirst`, :421) → 404 `APARTMENT_NOT_FOUND`. *Availability is decided here, not before.*
2. **W1-A1 cross-guard (direct path)**: a live Offer (ACTIVE/CONFIRMED) on the unit → 409 `UNIT_OPTIONED` (:430-441).
3. **Source-status guard**: direct requires AVAILABLE; offer-convert requires OPTIONED → 409 `APARTMENT_NOT_AVAILABLE` (:444-450).
4. **offer-convert only**: live Reservation behind the unit → 409 `ALREADY_RESERVED`, fired BEFORE the offer claim (:452-467).
5. **Claim** (offer-convert): status-preconditioned CONVERTED claim — concurrent convert/cancel flips 0 rows → precise 409.
6. **Revive guards**: latest row live (ACTIVE/CLOSURE_REQUESTED — a pending closure is still a hold, W2.2/DOM-D2) → 409 `ALREADY_RESERVED`; dependency guard (installments/payments/SAV > 0) → 409 `RESERVATION_HAS_DEPENDENTS`; one-live-hold-per-deal → 409 `OPPORTUNITY_ALREADY_BOOKED` (:476-524).
7. Create/revive row (W2.1 full economics+closure reset — :526-547), **apartment flip to RESERVED in the same commit** (:549), offer link, deal stage advance to RESERVATION + STAGE_CHANGE activity + audit (:561-614).
8. §41 fault-injection site after every shared mutation (:621) — a forced failure rolls back hold + flip + stage + trail together (F-06).
9. **P2002 backstop catch** maps any unique-index violation (the interleaved-writer race the guards can't see) to 409 `ALREADY_RESERVED` (:738-741).

**The DB-level backstop**: even if two requests interleave before either commits (both passing the read guards), SQLite serializes writes and the **partial unique indexes** (`Reservation_apartment_live_hold_uq` / `Reservation_opportunity_live_hold_uq` / the two Offer twins — all 4 verified live, §2.4) make the second live-hold commit **physically impossible** (P2002 → 409). Data-level duplicate probes under the same predicates: 0. This is exactly the D12 race closure: route guards give precise error codes first; indexes are the absolute guarantee.

### 5.2 Financial integrity — transaction usage (verified in code + unit tests)

- **Payments** (`src/lib/services/payments.ts:121-226`): one `$transaction` = payment create + installment PAID stamp + `PAYMENT_RECORDED` audit + PAYMENT activity. The balance decision re-reads committed payments **inside the tx** (TOCTOU closure, W1-4: `tx.payment.findMany` :142-146); `amount ≤ remaining` with 0.01 DZD epsilon (W1-2) → 422 `EXCEEDS_REMAINING`; PAID is stamped only here, never by hand (PATCH closes that door — `planInstallmentUpdate` status vocabulary is `{CALLED, CANCELLED}` only).
- **Installments** (`installments.ts:178-252` create, `:353-418` update): seq claim + create + audit in one tx (P2002 on `[reservationId, seq]` → 409 `SEQ_CONFLICT`); PATCH guards: settled lines immutable (`INSTALLMENT_SETTLED`), amount regression below paid → 422 `AMOUNT_BELOW_PAID`.
- **Reservation economics** (`src/lib/server/reservation-economics.ts:127-223`): MANAGER+ gate, shadow-validate/rebase escalation, write + both §37/§38 audits + §39 activity in ONE `$transaction` (G5-P3-5/F-06).
- **Two-step closure** (`reservation-lifecycle.ts:255-261`): the CONVERTED claim is a status-preconditioned `updateMany` (`where status=CLOSURE_REQUESTED`) — concurrent validation/rejection flips 0 rows → 409 `RESERVATION_ALREADY_CLOSED`; then apartment SOLD + opportunity CLOSED_WON + probability 100 + `alignWonDealValue` + 4 audit rows + timeline entry all in the same tx.
- **Expiry**: lazy sweeper at GET /api/reservations (`expireDueReservations()` — route.ts:28), idempotent + audited (RESERVATION_EXPIRED / OFFER_EXPIRED actions exist in live vocabulary).
- **Unit tests (pure, DB never opened — vitest alias `@/lib/db` → throwing stub)**: services-reservations 10/10, services-payments 11/11, services-installments 20/20 — all pass (appendix A-6).
- Security suites `tests/security/offer-concurrency.test.ts` + `financial-atomicity.test.ts` + `fault-injection.test.ts` exist and cover the race/atomicity surfaces (not re-run by this audit to avoid live mutations; the fault-injection channel itself is header-gated and dead in production — faults.ts contract).

### 5.3 SQLite runtime (verified live on a fresh Prisma engine connection)

| Fact | Value | Note |
|---|---|---|
| `sqlite_version()` | **3.46.0** | Prisma engine-bundled — matches the documented WAL-blocked range (< 3.51.3 fix) |
| `journal_mode` | **delete** | WAL deliberately BLOCKED (P0-2 decision — re-confirmed: engine is the runtime, no upgrade path in Prisma 6) |
| `busy_timeout` (read back) | **5000 ms** | Engine-managed on every physical connection (applied by the Prisma query engine, not app code — observed, not configurable from src) |
| `foreign_keys` | **1** | FK enforcement ON |
| `page_size` / `page_count` / `freelist` | 4096 / 291 / 2 | db size from pages = 1,191,936 B == file size ✔ |
| `auto_vacuum` | 0 (none) | — |
| `encoding` / `cache_size` | UTF-8 / −2000 (2 MB) | engine defaults |
| `wal_autocheckpoint` | 1000 | **irrelevant** — journal is delete, no WAL exists |

---

## 6. Backup & Restore Verification (live drill)

### 6.1 The system (code-verified)

- **`scripts/backup.sh` → `scripts/lib/backup-run.mjs`**: `db/backups/backup-<ts>/` containing `db-<ts>.sqlite` (via **`VACUUM INTO`** — never a live file-copy of a journal-active DB; source connection opened **READ-ONLY** with busy_timeout 30000, backup-engine.mjs:93-97), `docs-<ts>.tar.gz` (the **`db/docs/` upload tree**), and `manifest.json` (runId, ts, `integrity:"ok"` = the verdict of integrity_check run ON THE SNAPSHOT, 6-table census, sha256+size of both artifacts, keep). Retention: newest N (env `ASAS_BACKUP_KEEP`, default 14), never deletes anything < 1 h old, never manages non-`backup-*` entries.
- **`scripts/restore.sh` → `scripts/lib/restore-run.mjs`**: hard safety interlock (backup-logic.mts:412-469, strict parsing — a misspelled confirmation flag is an unknown flag → refused). `--drill` writes **only** under `db/restore-drills/<ts>/`. Live restore requires BOTH `--confirm-restore` AND the typed `--i-understand-this-overwrites-the-live-db`, takes a VACUUM-INTO safety snapshot first, replaces the DB by atomic rename, replaces `db/docs/` from the tarball, re-verifies integrity+census on the live file.
- **Manifest integrity logic**: `scripts/lib/backup-logic.mts` (pure, no imports) + `tests/unit/backup-manifest.test.ts` — **67 tests, all passing** (run live by this audit): retention laws (keep-N, sub-1h guard, unknown-age-is-keep), census exact-compare (drift/missing/extra keys all fail), manifest contract (integrity exactly "ok", 6 canonical census keys, exactly 2 stamped artifacts bound to manifest.ts, 64-hex sha256, bare names only — path separators rejected), artifact verification naming both digests on mismatch, and the interlock (misspelled-confirmation bypass refused, drill+confirm contradiction refused, duplicated flags refused).

### 6.2 Pre-existing inventory (`ls -la db/backups/`)

Before this audit: **one legacy `db:snapshot` file-copy only** (`custom-20261106-165228.db`, 1,179,648 B) — **zero manifest-based backups existed**, so `bun run db:restore:drill` initially **REFUSED (exit 2)**:

```
[restore] INTERLOCK REFUSED:
[restore]   · missing <backupDir> positional argument
```

(The `$(ls -td db/backups/backup-* | head -1)` substitution found nothing — the interlock refused the malformed invocation exactly as designed. Evidence the refusal path works live.)

### 6.3 Backup run (live, 17:08:36Z) — output verbatim

```
$ bun run db:backup
[backup] sqlite3 CLI not found — using Node built-in node:sqlite (Node ≥ 22.5, no new deps)
[backup] runId=84ec6c3a1d3c4675a0d8c3919f8e646a ts=20261106T170836Z keep=14 (env ASAS_BACKUP_KEEP, default 14)
[backup] engine=node:sqlite (Node built-in)
[backup] snapshotting db/custom.db → db/backups/backup-20261106T170836Z/db-20261106T170836Z.sqlite (VACUUM INTO, read-only source connection)
[backup] archiving db/docs/ → db/backups/backup-20261106T170836Z/docs-20261106T170836Z.tar.gz
[backup] snapshot  … — 1191936 bytes, sha256 c84e063bef49df8d…
[backup] docs      … — 109 bytes, sha256 3443382c72e22b9a…
[backup] integrity ok — PRAGMA integrity_check run ON THE SNAPSHOT
[backup] census    users=8 leads=45 opportunities=23 reservations=9 apartments=46 documents=0
[backup] manifest  … (runId 84ec6c3a1d3c4675a0d8c3919f8e646a, keep=14)
[backup] retention kept=1 deleted=0 (guard: nothing younger than 1 h is ever deleted)
[backup] BACKUP OK → db/backups/backup-20261106T170836Z
```

Safety note: `VACUUM INTO` opens the source **read-only** (`new DatabaseSync(dbFile, { readOnly: true })`, backup-engine.mjs:94) — `db/custom.db` is never written by the backup (the live file's subsequent size/mtime changes during the audit window come from the parallel live agents, §F-3).

### 6.4 Restore drill (live, 17:08:40Z) — output verbatim, **PASS**

```
$ bun run db:restore:drill
[restore:drill] engine=node:sqlite (Node built-in)
[restore:drill] source db/backups/backup-20261106T170836Z (runId 84ec6c3a1d3c4675a0d8c3919f8e646a, ts 20261106T170836Z, keep=14)
[restore:drill] artifacts verified — sha256 + size match the manifest (db-20261106T170836Z.sqlite, docs-20261106T170836Z.tar.gz)
[restore:drill] restored db/restore-drills/20261106T170840Z/custom.db (byte-identical to the snapshot, sha256 c84e063bef49df8d…)
[restore:drill] docs     db/restore-drills/20261106T170840Z/docs/ (0 entries)
[restore:drill] integrity ok — PRAGMA integrity_check on the RESTORED copy
[restore:drill] census   users=8 leads=45 opportunities=23 reservations=9 apartments=46 documents=0 — MATCHES MANIFEST (…)
[restore:drill] original db/custom.db — NOT TOUCHED (drill mode writes only under db/restore-drills/)
[restore:drill] PASS — drill restore verified end-to-end; live DB untouched
```

Exit code 0. The drill restored into `db/restore-drills/20261106T170840Z/` only; `db/custom.db` untouched (drill-mode path restore-run.mjs:88-130 — code-verified before running, per the audit's safety boundary).

### 6.5 Restore-orphan analysis (documents)

Uploads live in **`db/docs/{storedName}`** (`src/lib/server/documents.ts:19` — `DOCS_DIR = path.join(process.cwd(), "db", "docs")`, with realpath containment security). Schema comment confirms (schema.prisma:974). Therefore:

- **The manifest backup system does NOT orphan documents**: every backup tars `db/docs/` (backup-run.mjs:80) and the live restore REPLACES `db/docs/` contents from the verified tarball (restore-run.mjs:158-164). DB + binaries restore as a pair.
- **The legacy `db:snapshot` path CAN orphan**: `cp db/custom.db db/backups/custom-*.db` copies only the DB. Restoring `custom.db` alone (e.g. the R13 recovery flow) leaves `db/docs/` from a different instant → restored `Document` rows may reference files that no longer exist (download 404s), or newer files may exist with no metadata. **Currently zero impact** (documents=0, `db/docs/` empty) — latent risk only, flagged as F-4. AGENTS.md should steer pre-risky-DB-work snapshots toward `bun run db:backup` once documents are in real use.

---

## 7. Remaining Risks & Findings Register

| ID | Severity | Finding | Evidence | Recommendation |
|---|---|---|---|---|
| **F-0** | INFO | Schema has **35** models, not 34 as briefed. | `tmp-scripts/p4-a2-db-probe.ts` §2 (parse + live tables) | Correct the briefing figure; no action. |
| **F-1** | MINOR | **Seed-fidelity gap**: all 7 seeded CONVERTED reservations have `convertedById=NULL, convertedAt=NULL` and **0 `SALE_VALIDATED` audits** — the seed writes won-deal history directly (seed.ts:1553-1588) instead of riding the two-step closure that stamps them (reservation-lifecycle.ts:257). Audit trail is nonetheless complete per deal (STAGE_CHANGED→WON + APARTMENT_SOLD + COMMISSION/INCENTIVE audits). | `p4-a2-anomaly-probe.ts` output | One-line seed fix (stamp `convertedBy: manager.id, convertedAt` + a `SALE_VALIDATED` audit row per won deal) so demo data exercises the full closure contract. |
| **F-2** | MINOR | **No service-level cap on échéancier totals**: `createInstallment` (installments.ts:178-252) doesn't guard `sum(installments) ≤ reservation.amount`; a MANAGER could over-schedule beyond the agreed price. Per-line over-collection IS guarded (payments). Live data clean (1 partial schedule 24.36M ≤ 58M agreed; 3 exact matches). | probe §6 + code | Add a 422 `SCHEDULE_EXCEEDS_AGREED` guard in `createInstallment`/`planInstallmentUpdate`. |
| **F-3** | MINOR | **Live shared-DB drift during the audit**: census moved 44/21/8 (17:01) → 45/23/9 (17:08) leads/opps/reservations; EXPORT_BUNDLE at 16:56 saw 45/24/9. Cause verified: a parallel "P4-AUDIT" agent mutating through the running dev server (LEAD_CREATED "P4-AUDIT- Test Lead" 17:04:07 → convert → visit → offer activate 17:06:37). Integrity invariants held at every instant probed. | `p4-a2-timeline-probe.ts` | None (expected on a live parallel audit); all census claims are instant-stamped. Briefing's "10 reservations / 5 offers" matched no observed state. |
| **F-4** | MINOR | **Legacy `db:snapshot` orphans documents if used for restore once documents exist** (§6.5). Latent (documents=0 today). | package.json:23 vs backup-run.mjs | Prefer `db:backup` for pre-risk snapshots; note in AGENTS.md. |
| **F-5** | INFO | 2 AuditLog rows with NULL entityId (`EXPORT_BUNDLE` entity=ORG, `LEADS_EXPORTED` entity=LEAD) — org-wide aggregate actions; `entityId` is nullable by schema design. | `p4-a2-anomaly-probe.ts` | Acceptable; optionally stamp `entityId: orgId` for uniform resolution. |
| **F-6** | INFO | WAL remains BLOCKED (engine SQLite 3.46.0 in the WAL-reset bug range) — delete-journal + busy_timeout 5000 verified live. Read-heavy scale-out would benefit from WAL once the engine SQLite ≥ 3.51.3. | probe §1 | Documented P0-2 decision; revisit only on Prisma engine upgrade. |
| **F-7** | INFO | Dormant PostgreSQL/Supabase variant confirmed INERT: `prisma/schema.postgres.prisma` (generated variant) exists; **zero** postgres driver imports in src/scripts; `.env` DATABASE_URL = SQLite file; the only src mention is a port comment (visibility.ts:192). | greps §appendix | Keep dormant; regeneration procedure documented in 05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md. |
| **F-8** | INFO | Backup census covers 6 tables (User/Lead/Opportunity/Reservation/Apartment/Document); full-artifact integrity is carried by the sha256 byte-identity check, so this is a representativeness trade-off, not a hole. | backup-logic.mts:53-60 | Optional: extend census keys in a coordinated manifest-version bump. |
| **F-9** | INFO | Backups are manual (`bun run db:backup`) — long-term scheduled automation is TERMINALLY ENDED by user mandate (AGENTS.md:21), so no cron exists. The drill is equally manual. | AGENTS.md | Operational runbook should name the human cadence (e.g. before each risky DB session — already the house habit). |

**BLOCKED items: none.** (WAL enablement remains blocked BY DESIGN, not by this audit — F-6.)

---

## 8. Score & Methodology

**Score: 94 / 100 — DATABASE ACCEPTED — WITH FINDINGS.**

| Dimension | Weight | Result | Rationale |
|---|---|---|---|
| Schema fidelity & live-DB match | 25 | **25/25** | 35/35 models, 0 column mismatches, 79+19+4 index surface exact, FK/integrity clean (live probes). |
| Migration chain acceptance | 20 | **20/20** | 25/25 applied, chronological, canonical lock, `migrate status` clean, all 25 SQL files read and reconciled, clean-rebuild capability demonstrated (2026-11-04 full replay + zero drift today). |
| Data integrity (probes) | 25 | **22/25** | 32/32 orphan probes = 0; money consistent on all axes; live-hold invariants hold. −1.5 F-1 seed stamps, −1.0 F-2 échéancier cap, −0.5 F-5 NULL entityId. |
| Concurrency architecture | 15 | **15/15** | In-tx guard chain code-verified end-to-end; 4/4 partial unique backstops live; P2002 mapping; TOCTOU-closed payments; 41 relevant unit tests pass. |
| Backup/restore/DR | 15 | **12/15** | Full VACUUM-INTO + docs + manifest system; interlock; drill run LIVE → PASS with live DB untouched; 67 manifest tests pass. −1.0 manual-only cadence (F-9), −0.5 6-table census (F-8), −1.0 legacy-snapshot orphan hazard (F-4). |

Deductions are hardening/demo-fidelity items — no integrity violation was found anywhere in the live data.

---

## 9. Evidence Appendix

### A-1 Read-only Prisma CLI
```
$ bunx prisma migrate status
warn The configuration property `package.json#prisma` is deprecated …
Environment variables loaded from .env
Prisma schema loaded from prisma/schema.prisma
Datasource "db": SQLite database "custom.db" at "file:/home/z/my-project/db/custom.db"
25 migrations found in prisma/migrations
Database schema is up to date!
```

### A-2 Migration directory order (`ls prisma/migrations/ | sort`, 25 + lock)
`0_init · 20261003020538_p4_composite_indexes · 20261007120000_p8_9_schema_catchup_stage_changed_at · 20261007234744_p11_stage_wip_limit · 20261008022052_p13_finance_installments · 20261008154438_p14_sav_cases · 20261008231000_p16_remove_sav · 20261009050000_p18_crm_premium_operating_model · 20261009080000_p20_visit_decision_lifecycle · 20261011090000_p29_commercial_trust · 20261011150302_p30_duplicate_management · 20261019174640_p54_two_step_closure · 20261027140445_phase_c_visit_report · 20261031101714_pd_finance_sav_targets · 20261101184000_master_w18_incentive_index · 20261101224756_arabic_aliases · 20261102000000_phase2_d12_live_hold_unique · 20261102150000_phase21_lead_converted_at · 20261104010000_g5_hot_query_indexes · 20261104020000_g5_loss_reason_code · 20261105180000_p1_offer_option · 20261105190000_p1_lead_score · 20261105200000_p1_capture_token · 20261106030000_p2_session_governance · 20261106040000_p2_lead_touch` (+ `migration_lock.toml`, provider=sqlite)

### A-3 `_prisma_migrations` bookkeeping (probe `p4-a2-migration-chain-probe.ts`)
`migration dirs count: 25 | _prisma_migrations rows: 25` · `DIRS == DB ROWS (names, sorted): true` · applied order by finished_at == chronological order above · NULL finished_at: 0 · rolled_back_at set: 0.

### A-4 Won-deal money map (probe, 17:01Z instant)
| Deal | value | agreed | unit price | apt | installments | payments |
|---|---|---|---|---|---|---|
| Bachir A. — Villa Sidi Yahia | 125,000,000 | 125,000,000 | 125,000,000 | SOLD | 0 lines | 0 |
| Zineb H. — F2 Kouba | 9,400,000 | 9,400,000 | 9,400,000 | SOLD | 0 | 0 |
| Sabrina A. — F2 Hydra | 14,200,000 | 14,200,000 | 14,200,000 | SOLD | 0 | 0 |
| Hocine B. — F4 Kouba | 18,800,000 | 18,800,000 | 18,800,000 | SOLD | 0 | 0 |
| Djamila R. — F4 Hydra | 39,500,000 | 39,500,000 | 39,500,000 | SOLD | 3 = 39,500,000 | 2 = 11,950,000 |
| Mustapha K. — F2 Cheraga | 11,800,000 | 11,800,000 | 11,800,000 | SOLD | 3 = 11,800,000 | 1 = 1,180,000 |
| Farid B. — F3 Cheraga | 17,500,000 | 17,500,000 | 17,500,000 | SOLD | 3 = 17,500,000 | 3 = 17,500,000 |

Plus the ACTIVE hold (not won): agreed 58,000,000, échéancier 5 lines = 24,360,000 (partial — F-2 context), payments 8,700,000 ≤ schedule, deposit 5,800,000 consistent.

### A-5 SQLite runtime (probe §1, fresh Prisma connection)
`sqlite_version 3.46.0 · journal_mode delete · busy_timeout 5000 · foreign_keys 1 · page_size 4096 · page_count 291 · freelist 2 · auto_vacuum 0 · encoding UTF-8 · cache_size -2000 · wal_autocheckpoint 1000 (inert under delete-journal) · integrity_check ok · foreign_key_check 0 rows · size-from-pages 1,191,936 == file size`

### A-6 Unit tests (pure — `@/lib/db` aliased to a throwing stub, DB never opened)
```
✓ tests/unit/backup-manifest.test.ts (67 tests)
✓ tests/unit/services-installments.test.ts (20 tests)
✓ tests/unit/services-reservations.test.ts (10 tests)
✓ tests/unit/services-payments.test.ts (11 tests)
Test Files 4 passed (4) · Tests 108 passed (108)
```

### A-7 Key code citations
- Booking guard chain: `src/lib/services/reservations.ts:412-624` (bookUnitInTx), `:669` ($transaction), `:738-741` (P2002→409)
- Offer conversion convergence: `reservations.ts:8-15` header; `src/lib/server/offer-lifecycle.ts:971` (OFFER_CONVERTED trail)
- Two-step closure stamps + claim: `src/lib/server/reservation-lifecycle.ts:255-261`, `:321-349` (SALE_VALIDATED/APARTMENT/OPP audits)
- Payments TOCTOU/epsilon: `src/lib/services/payments.ts:139-151` (in-tx re-read), `:86-102` (planPaymentSettlement, MONEY_EPSILON 0.01)
- Installments guards: `src/lib/services/installments.ts:307-326` (SETTLED/AMOUNT_BELOW_PAID), `:178-252` (create — F-2 gap)
- Economics one-tx law: `src/lib/server/reservation-economics.ts:127-223`
- Backup/restore: `scripts/backup.sh`, `scripts/restore.sh`, `scripts/lib/backup-run.mjs:57-108`, `scripts/lib/backup-engine.mjs:49-135` (engines, read-only, busy_timeout 30000), `scripts/lib/restore-run.mjs:88-130` (drill), `:132-176` (live interlock path), `scripts/lib/backup-logic.mts:263-357` (manifest contract), `:412-469` (interlock parsing)
- Documents upload dir: `src/lib/server/documents.ts:19` (`DOCS_DIR = db/docs`), schema.prisma:973-1000
- Migration SQL: the five critical files quoted in §3.3; live-hold raw SQL: `prisma/live-hold-indexes.sql:17-39`

### A-8 Probe artifacts (this audit, all git-ignored)
`tmp-scripts/p4-a2-db-probe.ts` (+ `p4-a2-probe-output.txt`) · `tmp-scripts/p4-a2-anomaly-probe.ts` (+ output) · `tmp-scripts/p4-a2-timeline-probe.ts` (+ output) · `tmp-scripts/p4-a2-migration-chain-probe.ts` (+ output). Backup/drill artifacts: `db/backups/backup-20261106T170836Z/` (retention-managed), `db/restore-drills/20261106T170840Z/` (drill namespace).

### A-9 Safety-boundary compliance statement
No write to `db/custom.db` was performed by this audit (all probes SELECT/PRAGMA; backup used the read-only VACUUM INTO engine; the drill wrote only under `db/restore-drills/`). No migrations executed, no db:push/reset/db:deploy. No app source, schema, or test files modified. Dev server never restarted (`/api/health` 200 throughout). The only Prisma CLI command run was `migrate status`.

---

*P4-2 · Agent 2 — Database, Data Integrity & Disaster Recovery Auditor · 2026-11-06*
