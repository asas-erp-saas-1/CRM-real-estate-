# ASAS CRM — Phase 4 Independent Production Readiness Audit
## P4-4 · CRM Domain, Financial Integrity & Business Workflow Acceptance

**Agent:** 4 of the Phase-4 independent audit cell (CRM Domain, Financial Integrity, Business Workflow Auditor)
**Date:** 2026-11-06 (session window 17:02–17:11 UTC)
**Scope:** full CRM business lifecycle verified end-to-end against the LIVE API at `http://127.0.0.1:3000` (dev server untouched), with synthetic `P4-AUDIT-` records created and fully cleaned up. Read-only code citations + read-only DB probes + live curl workflow.
**Evidence scripts:** `tmp-scripts/p4-a4-census.ts` (read-only probe), `tmp-scripts/p4-a4-cleanup.ts` (marker-scoped teardown). Raw console capture: `/tmp/p4-a4-census-out.txt`.
**Baseline snapshot reference:** `db/backups/custom-20261106-165228.db` (untouched, never restored — live DB verified as ground truth).

---

## 1. Executive summary + verdict

**VERDICT: CRM DOMAIN ACCEPTED** — with 0 CRITICAL, 0 MAJOR, 2 MINOR, 6 INFO findings.

The complete commercial lifecycle (lead → qualification → assignment → conversion → pipeline stages → visit → offer/option → reservation → two-step closure → installments → payments) was executed live, end-to-end, in ~7 minutes of wall-clock API traffic, and every domain invariant held:

- **Every state machine refused what it should refuse** — illegal opp transitions (422), PATCH entry into CLOSED_WON without a qualifying completed visit with structured report (422 `VISIT_REPORT_REQUIRED`), SALES_AGENT visit confirmation (403, the operating-model law), double-booking (409), payment before appel de fonds (409), over-collection (422), duplicate phone (409, non-forceable), duplicate payment on a settled line (409).
- **Every money write was transactionally sound** — the two-step closure performed reservation CONVERTED + apartment SOLD + opportunity CLOSED_WON + **value alignment (28,000,000 → 18,900,000 DZD)** in ONE transaction with a dedicated `OPPORTUNITY_VALUE_CHANGED` audit row; payments+audits+activities committed 2:2:2 atomically.
- **The 7 seeded won deals are 100 % money-coherent** (value == agreed price == unit price on all 7; total 236,200,000 DZD; zero over-collection anywhere in the DB).
- **Cleanup certified zero residue**: every business table returned EXACTLY to the pre-audit census; apartment A-02 restored AVAILABLE; marker scans all 0.

The two MINOR findings are documentation-level observations (advisory WIP limits by design; the CRM échéancier deliberately models partial schedules — heavy finance is ERP territory per the operating model), not defects.

---

## 2. Live census (ground truth, read-only probe `tmp-scripts/p4-a4-census.ts`)

| Entity | Live count | Mission expectation | Note |
|---|---|---|---|
| Users | 8 (1 org) | 8 | nadia OWNER, karim ADMIN, sarah MANAGER, amine/lina/yacine SALES_AGENT, mounia/riadh FIELD_REP |
| Leads | 43 | ~43 | ✓ |
| Opportunities | 21 | ~21 | ✓ |
| Apartments | 46 (35 AVAILABLE, 7 SOLD, 1 RESERVED, 1 OPTIONED, 1 BLOCKED, 1 OFF_MARKET) | 46+1 | live = 46 (the +1 was transient during the Principal's verification) |
| Reservations | 8 (7 CONVERTED, 1 ACTIVE) | 10 | live = 8 — live is ground truth |
| Offers | 3 (1 DRAFT, 1 ACTIVE, 1 CONVERTED) | 3 | ✓ |
| Payments | 8 (39,330,000 DZD) | 8 | ✓ |
| Installments | 14 (93,160,000 DZD scheduled) | 14 | ✓ |
| Activities / AuditLogs | 187 / 355 | — | baseline before my workflow |
| Tasks / Visits / Contacts / SAV / Targets | 18 / 24 / 20 / 7 / 3 | — | ✓ |

FIELD_REP assignments (visit-confirmation authority): Mounia → Les Oliviers + Hydra Heights; Riadh → Cité Bougainvilliers.
Audit entity taxonomy: `SELECT DISTINCT entity FROM AuditLog WHERE entity != UPPER(entity)` → **empty** (UPPERCASE law holds).

---

## 3. The 15-step CRM golden path — test matrix (all live, as sarah MANAGER unless noted)

| # | Step | Result | Evidence (request → response) |
|---|---|---|---|
| 1 | Create Lead | **PASS** | `POST /api/leads` `{fullName:"P4-AUDIT-… Test Lead", phone:"+213500000000", source:"WALK_IN", notes:"P4-AUDIT…"}` → **201** `{lead:{id:cmw5851ga…, status:"NEW", score:0, source:"WALK_IN", owner:null}}`; lead-creation Activity+Audit committed in-tx (code: `leads/route.ts:406-456`). |
| 2 | Qualify Lead | **PASS** | `PATCH /api/leads/:id` `{status:"QUALIFIED", budgetMin:12M, budgetMax:28M, propertyType:"F3", desiredLocation:"Hydra"}` → **200** `status:"QUALIFIED"`. First attempt with `propertyType:"APARTMENT"` → **422 VALIDATION_ERROR** (zod enum discipline — correct strictness). NEW→QUALIFIED is a legal forward edge (`LEAD_TRANSITIONS`, constants.ts:158). |
| 3 | Assign to amine | **PASS** | `PATCH {ownerId:amine}` → **200** `ownerId:cmw56j2x4…` + ASSIGNMENT Activity ("Lead assigné à Amine Cherif") + `LEAD_ASSIGNED` audit. Managerial-gated law (route lines 301-303). |
| 4 | Extended customer info | **PASS** | `PATCH {email, notes, nextFollowUpAt}` → **200** all three fields persisted. |
| 5 | Create Opportunity from lead | **PASS** | `POST /api/leads/:id/convert` `{}` → **201** `{contact:{id:cmw5865ex…}, opportunity:{id:cmw5865f3…, stage:"QUALIFIED", value:28000000 (=budgetMax), probability:15 (canonical table), nextAction:"Appeler le prospect", stageChangedAt stamped, ownerId:amine}}`; lead flipped CONVERTED + `convertedAt` + `convertedContactId` (one transaction, convert/route.ts:44-111). |
| 6 | Pipeline moves + invalid rejection | **PASS** | QUALIFIED→VISIT_SCHEDULED → **200** (stageChangedAt 17:05:09.574Z); VISIT_SCHEDULED→VISIT_COMPLETED → **200** (stageChangedAt **updated** to 17:05:09.655Z). INVALID backward VISIT_COMPLETED→QUALIFIED → **422 CORRECTION_REASON_REQUIRED** (matrix guard, opportunities/[id]/route.ts:142-158). Bonus: PATCH→CLOSED_WON with reason but no visit → **422 VISIT_REPORT_REQUIRED** `{missing:["completed_visit_with_report"], visit:{linked:false}}` — the closure gate (visit-gate.ts:138) blocks even the manager correction path. |
| 7 | Record interaction | **PASS** | `POST /api/leads/:id/activities` `{type:"CALL", title:"P4-AUDIT appel de qualification", outcome:"INTERESTED"}` → **201** Activity linked to lead + converted contact. |
| 8 | Schedule follow-up task | **PASS** | `POST /api/tasks` `{title:"P4-AUDIT relance offre F3 Hydra", type:"FOLLOW_UP", dueAt:+5d, priority:"HIGH", leadId, opportunityId}` → **201** `{status:"OPEN", dueAt:2026-11-11}` + TASK activity on the lead timeline. |
| 9 | Schedule visit + complete | **PASS** | `POST /api/visits` `{leadId, projectId:Les Oliviers, scheduledAt:+1d, agentId:amine, apartmentIds:[A-02]}` → **201** SCHEDULED (visit auto-linked to the lead's single live opportunity — the E2E-FINAL auto-link, visits/route.ts:250-257). **Operating-model probe:** amine (SALES_AGENT, the visit's own agent) tries CONFIRM → **403 VISIT_CONFIRM_FORBIDDEN** ("Seul le représentant terrain assigné au projet…"). sarah (MANAGER) confirms → **200** `confirmedById/confirmedAt` stamped. Complete with structured report `{status:"COMPLETED", outcome, interestLevel:"VERY_INTERESTED", reportNotes(≥20 chars)}` → **200** `attended:true, reportedById/reportedAt SERVER-STAMPED`. |
| 10 | Offer on AVAILABLE apartment | **PASS** | `POST /api/offers` `{opportunityId, apartmentId:A-02, amount:18,900,000, paymentPlan:"INSTALLMENT", activate:true, expiresAt:+7d}` → **201** `{status:"ACTIVE", expiresAt}`; **apartment A-02 → OPTIONED in the same transaction** (offer-lifecycle.ts:372-391, audited `APARTMENT_STATUS_CHANGED`). |
| 11 | Reservation + double-booking guard | **PASS** | Offer confirm → **CONFIRMED**; `POST /api/offers/:id/convert` → **200**: reservation `cmw588q54…` ACTIVE, amount 18.9M, **apartment → RESERVED**, offer → CONVERTED + `convertedReservationId` link, **opportunity auto-advanced to RESERVATION** (booking-coupled stage advance, OPP_PRE_BOOKING_STAGES). Second booking attempt on the SAME apartment (fresh rival P4-AUDIT lead+opp) → **409 APARTMENT_NOT_AVAILABLE** `{details:{apartmentId, status:"RESERVED"}}` (bookUnitInTx in-tx apartment re-read, reservations.ts:421-450 + D12 partial-unique backstop). |
| 12 | Two-step closure | **PASS** | `PATCH /api/reservations/:id` `{action:"request_closure", evidence:"P4-AUDIT: contrat signé…"}` → **200** CLOSURE_REQUESTED + stamps. `{action:"validate_closure"}` → **200**: reservation **CONVERTED** (`convertedById/At`), apartment A-02 **SOLD**, opportunity **CLOSED_WON** (probability 100, closedAt+stageChangedAt stamped). **Value alignment verified live: opportunity.value 28,000,000 → 18,900,000 (the agreed price) in the SAME transaction, audited `OPPORTUNITY_VALUE_CHANGED` `{before:{value:28000000}, after:{value:18900000, reason:"Validation de la vente…", agreedAmount:18900000, reservationId}}`** (reservation-lifecycle.ts:241-362 + financial-semantics.ts:153-201). |
| 13 | Installments + payment | **PASS** | `POST /api/finance/installments` ×2 → **201** lines PLANNED, seq 1/2 (3,780,000 BOOKING + 7,560,000 INSTALLMENT). `PATCH {status:"CALLED"}` → **200** `calledAt` stamped. Payment guards: before call → **409 INSTALLMENT_NOT_CALLED**; 4M > 3.78M line → **422 EXCEEDS_REMAINING** `{remaining:3780000}`. Valid payments: partial 2M CASH → line stays CALLED; final 1.78M TRANSFER → line **PAID + paidAt** (stamped only by the payment writer). **Atomicity verified: payments=2 = PAYMENT_RECORDED audits=2 = PAYMENT activities=2; paySum=3,780,000 == line amount exactly.** |
| 14 | Customer timeline | **PASS** | `GET /api/leads/:id` / `GET /api/activities?leadId=…` → 20 rows in a perfectly accurate chronological narrative: LEAD_CREATED → STATUS_CHANGE → ASSIGNMENT → CONVERSION → 2×STAGE_CHANGE → CALL → TASK → VISIT (planifiée/confirmée/effectuée) → OFFER (activée/confirmée/convertie) → STAGE_CHANGE→RESERVATION → RESERVATION (booked/clôture demandée/vente conclue) → 2×PAYMENT. Audit trail mirrors every business op with UPPERCASE entities (LEAD/OPPORTUNITY/RESERVATION/APARTMENT/OFFER/INSTALLMENT/VISIT/TASK) incl. `SALE_VALIDATED`, `OPPORTUNITY_VALUE_CHANGED`, `APARTMENT_RESERVED`, `APARTMENT_STATUS_CHANGED`, `PAYMENT_RECORDED`, `INSTALLMENT_CALLED`. |
| 15 | Reporting reflects records | **PASS** | Dashboard (30d) BEFORE → AFTER: `newLeads 36→38 (+2)`, `uncontacted 11→12`, `clients 20→22`, `wonInRange 101,800,000→120,700,000 (+18,900,000 = exactly the synthetic won deal)`, `conversionRate 13.3→17.6`. Analytics `bySource`: WALK_IN `won:2, wonValue:30,700,000` (seeded 11.8M + my 18.9M). After cleanup all KPIs returned to baseline exactly (§6). |

**15/15 PASS. 0 FAIL. 0 BLOCKED.**

---

## 4. Financial consistency verification

### 4.1 The 7 seeded won deals (read-only probe, exact numbers)

| Won deal (opportunity) | Opp value | Reservation amount (agreed) | Apartment | Unit price | value==agreed==price | Installments | Payments | Coherent |
|---|---|---|---|---|---|---|---|---|
| Bachir A. — Villa Sidi Yahia | 125,000,000 | 125,000,000 (CONVERTED) | V-02 SOLD | 125,000,000 | ✓ | 0 | 0 | ✓ (cash sale, no échéancier) |
| Djamila R. — F4 Hydra | 39,500,000 | 39,500,000 (CONVERTED) | H-02 SOLD | 39,500,000 | ✓ | 3 lines = 39,500,000 | 11,950,000 (partial) | ✓ |
| Hocine B. — F4 Kouba | 18,800,000 | 18,800,000 (CONVERTED) | N-31 SOLD | 18,800,000 | ✓ | 0 | 0 | ✓ |
| Sabrina A. — F2 Hydra | 14,200,000 | 14,200,000 (CONVERTED) | H-42 SOLD | 14,200,000 | ✓ | 0 | 0 | ✓ |
| Farid B. — F3 Cheraga | 17,500,000 | 17,500,000 (CONVERTED) | A-01 SOLD | 17,500,000 | ✓ | 3 lines = 17,500,000 | 17,500,000 (fully paid) | ✓ |
| Mustapha K. — F2 Cheraga | 11,800,000 | 11,800,000 (CONVERTED) | B-01 SOLD | 11,800,000 | ✓ | 3 lines = 11,800,000 | 1,180,000 (10 % partial) | ✓ |
| Zineb H. — F2 Kouba | 9,400,000 | 9,400,000 (CONVERTED) | S-02 SOLD | 9,400,000 | ✓ | 0 | 0 | ✓ |
| **TOTAL** | **236,200,000 DZD** | | | | **7/7 aligned** | | | **7/7 coherent** |

- **7/7 won deals: opportunity.value == reservation.amount == apartment.price** — the DOM-03 alignment convention holds across the whole seed; no stale estimates on won cards.
- **Installment sums == agreed price** on every won deal that carries an échéancier (3/3).
- **Payments ≤ installments everywhere** (no over-collection anywhere in the DB — checked across ALL 8 reservations); partial collection (Djamila 11.95M/39.5M, Mustapha 1.18M/11.8M) is legitimate in-progress collection, not inconsistency.
- Global: 8 payments = 39,330,000 DZD; 14 installments = 93,160,000 DZD scheduled; every reservation's agreed amount == its unit's price.

### 4.2 The synthetic deal (created and destroyed by this audit)

- Pipeline estimate at conversion: 28,000,000 (lead budgetMax) — deliberately different from the agreed price while open (per the DOM-03 concept table: estimate ≠ contract is commercial reality).
- Offer → reservation agreed price: 18,900,000 (A-02 price).
- Two-step closure aligned opportunity.value → **18,900,000 in the closure transaction, audited** (`OPPORTUNITY_VALUE_CHANGED` row cited in §3 step 12) — mirroring `tests/security/closure-value-consistency.test.ts` TEST 1, verified LIVE.
- Échéancier: 2 lines = 11,340,000 scheduled (3.78M BOOKING + 7.56M); payments 3,780,000 == line 1 amount exactly (fully covered → PAID); line 2 PLANNED, untouched. **No over-collection; PAID stamped only by the payment writer.**

### 4.3 Money-path atomicity (code + live evidence)

- Every money-adjacent writer wraps mutation + Activity + AuditLog in ONE `$transaction` with a fault-injection hook proving joint rollback: lead create (`leads/route.ts:406`), lead PATCH (`:361`), convert (`convert/route.ts:44`), offers (`offer-lifecycle.ts:347`, create/activate/confirm/convert/cancel), booking core (`services/reservations.ts:412` — guard sequence enumerated at :392-411), two-step closure (`reservation-lifecycle.ts:243`, stage `reservations-validate`), installments create/patch (`services/installments.ts:194/:383`), payments (`services/payments.ts:139`, stage `payments-post` — money writes BEFORE trail, fault BETWEEN them).
- Live proof: payments=audits=activities=2:2:2 on the synthetic line; the closure wrote 4 audit rows (SALE_VALIDATED + APARTMENT_STATUS_CHANGED + OPPORTUNITY_STAGE_CHANGED + OPPORTUNITY_VALUE_CHANGED) + 1 timeline row in one commit.

---

## 5. Lifecycle / guard verification findings (code citations)

1. **Lead status ≠ opportunity stage — separate enums.** `LEAD_STATUSES = [NEW, CONTACTED, QUALIFIED, CONVERTED, CLOSED_LOST, REACTIVATED]` (constants.ts:13) vs `OPPORTUNITY_STAGES = [NEW, QUALIFIED, VISIT_SCHEDULED, VISIT_COMPLETED, NEGOTIATION, OPTION, RESERVATION, CONTRACT, CLOSED_WON, CLOSED_LOST]` (constants.ts:16-27). Same-named members (NEW, QUALIFIED, CLOSED_LOST) are distinct positions in distinct machines.
2. **Lead state machine** (`LEAD_TRANSITIONS`, constants.ts:157-164 + `canTransitionLead` :169): forward edges ungated (skip-forward legal), backward = MANAGER+ + `correctionReason` + `LEAD_STATUS_CORRECTED` audit (leads/[id]/route.ts:261-284); CONVERTED terminal (PATCH entry refused :244-246, exit refused :247-253, `ALREADY_CONVERTED` 409 in the dedicated flow, convert/route.ts:25-27); conversion stamps `convertedAt`/`convertedContactId` (migration `20261102150000_phase21_lead_converted_at` + convert route :79-83, backfilled from Contact.createdAt).
3. **Opportunity gates** (`OPPORTUNITY_TRANSITIONS`, constants.ts:192-203, enforced opportunities/[id]/route.ts:142-158): routine forward moves (any later stage, skips allowed); CLOSED_LOST reachable from every working stage but requires `lostReasonCode`/`lostReason` (:100-107) and is blocked while a live hold exists (422 `ACTIVE_RESERVATION_EXISTS`, in-tx :273-286); PATCH entry into CLOSED_WON is always correction-class AND runs the same visit/report gate as validate_closure (in-tx :215-239) + value alignment (:225-238); reopening a sale-backed CLOSED_WON → 422 `OPPORTUNITY_BACKED_BY_SALE` (in-tx :254-265); HARD stage gates for RESERVATION/CONTRACT entry (422 `GATE_RESERVATION_REQUIRED`/`GATE_DEPOSIT_REQUIRED`, in-tx :304-332 — predicates single-sourced in `opportunity-gates.ts`, mirrored by tests/unit/opportunity-gates.test.ts:72-93); birth-at-CLOSED_WON refused outright (`refuseBirthClosed`, visit-gate.ts:245).
4. **stageChangedAt history**: stamped on every stage move (route :183-187; migration `p8_9_schema_catchup_stage_changed_at` backfilled from updatedAt), rebased by the coupled closure advance (reservation-lifecycle.ts:278-287, DOM-D7) — verified live twice (17:05:09.574Z → .655Z) and at closure (17:07:36.791Z).
5. **Loss reason codes** (g5_loss_reason_code migration; `LOST_REASONS` 9-code taxonomy constants.ts:88): live-verified on the rival deal — PATCH to CLOSED_LOST with `lostReasonCode:"OTHER"` stored the code, forced probability 0, stamped `closedAt` (constants-coupled zod).
6. **WIP limits (p11)**: `PipelineStage.wipLimit` (migration `20261007234744_p11_stage_wip_limit`) is an **advisory kanban-column capacity signal** — over-limit moves produce a warning toast, never a block, suppressed while board filters are on ("board-level-signal law", use-pipeline-moves.ts:107-120; pipeline/stages/[id]/route.ts:21,47 audited edits). **MINOR-1 (by-design observation):** no server-side WIP enforcement exists; production owners should confirm the advisory choice is intended (it is documented as D-UX-043/P11 intent).
7. **Offer/Option domain (P1/W1-A1)**: statuses `OFFER_STATUSES` (constants.ts:747); DRAFT→ACTIVE takes the provisional hold (apartment → OPTIONED same-tx, only from AVAILABLE/OPTIONED else 409 `UNIT_NOT_HOLDABLE`), ACTIVE requires live future expiry; CONFIRMED records client commitment; CONVERTED only via the explicit MANAGER+ convert action (one transaction: offer CONVERTED + link + booking core + stage advance); CANCELLED requires reason, releases the hold; EXPIRED sweeper-only. Cross-guards: apartment under live reservation → 409 `ALREADY_RESERVED`; under another live offer → 409 `UNIT_ALREADY_OPTIONED` (partial-unique backstops `Offer_apartment_live_hold_uq`/`Offer_opportunity_live_hold_uq` map P2002 to the same vocabulary); one live offer per deal. Lazy expiry sweeper `expireDueOffers` (expiry.ts:128-218) awaited at GET /api/offers — idempotent, status-preconditioned, releases only mirroring holds, F-06 trail.
8. **Reservation booking core** (`bookUnitInTx`, services/reservations.ts:412-480+): apartment re-read INSIDE the transaction (availability decided in-tx); direct-booking live-offer cross-guard 409 `UNIT_OPTIONED`; source-status guard 409 `APARTMENT_NOT_AVAILABLE`; revive law (one row per apartment, dependency guard 409 `RESERVATION_HAS_DEPENDENTS`, one-live-hold-per-deal 409 `OPPORTUNITY_ALREADY_BOOKED`); W2.1 economics reset on revive (explicit nulls for the whole §37/§38 family, :235-301); booking advances pre-booking stages; D12 partial-unique index backstop.
9. **Two-step closure (p54 migration `20261019174640_p54_two_step_closure`)**: `request_closure` (responsible agent or MANAGER+, evidence REQUIRED) → `validate_closure` (MANAGER+) = ONE transactional money-state event: reservation CONVERTED + apartment SOLD + opportunity CLOSED_WON + value alignment + 4 audit rows + timeline row; status-preconditioned claim makes concurrent/repeated validation a safe 409 `RESERVATION_ALREADY_CLOSED` (idempotent, no double SOLD); `reject_closure`/`cancel` manager corrections; EXPIRED sweeper-only. The closure visit/report gate (`visit-gate.ts:138-236`) runs INSIDE the transaction BEFORE the claim on all three won-paths.
10. **Visit lifecycle (P20/D-026/D-027)**: consolidated `VISIT_TRANSITIONS` matrix (constants.ts:121-129) → 422 `VISIT_ILLEGAL_TRANSITION` on off-matrix edges; COMPLETED/CANCELLED/REJECTED terminal; `SCHEDULED→CONFIRMED` authority = assigned FIELD_REP of the visit's project or MANAGER+ (403 `VISIT_CONFIRM_FORBIDDEN` — **live-probed as amine**); executive reset CONFIRMED→SCHEDULED MANAGER+ only (403 `VISIT_RESET_FORBIDDEN`); stale-guard 409 `VISIT_STALE`; structured report contract (interestLevel enum + reportNotes ≥ 20 chars + SERVER-stamped reportedById/reportedAt, immutable once submitted); visit↔opportunity same-lead consistency law (422 `VISIT_LEAD_MISMATCH`).
11. **Payments/installments (D-022)**: money moves only on CALLED lines (409 `INSTALLMENT_NOT_CALLED`/`INSTALLMENT_ALREADY_PAID`/`INSTALLMENT_CANCELLED`); amount ≤ remaining decided in-tx on a fresh re-read with money-scale epsilon (422 `EXCEEDS_REMAINING`); PAID stamped only by full coverage inside the payment transaction; PATCH cannot hand-assign PAID (zod closes status to {CALLED, CANCELLED}); amount never below collected (422 `AMOUNT_BELOW_PAID`); PAID lines immutable history (409 `INSTALLMENT_SETTLED`); seq uniqueness in-tx (409 `SEQ_CONFLICT`); OVERDUE derived, never stored.
12. **Customer timeline**: `Activity` model captures type/title/body/outcome/meta + actor/lead/opportunity/contact/visit/reservation/task links; 25 system-generated types (constants.ts:416-456) — timeline rows exist for every business event in this audit (20 rows, §3 step 14); audit rows match business operations 1:1 with UPPERCASE entity taxonomy (probe: 0 violations).

---

## 6. Cleanup certification — residue = 0 (proof)

**Records created by this audit (all deleted):**

| Record | Id | Deleted via |
|---|---|---|
| Lead 1 "P4-AUDIT- Test Lead" | cmw5851ga000dqy53jjs2amxz | cleanup script (`leads: 2`) |
| Lead 2 "P4-AUDIT-Rival Test Lead" | cmw5899120033qy53jzcue0c0 | cleanup script |
| Opportunity 1 (won) | cmw5865f3000vqy53cwvpt0qh | cleanup script (`opportunities: 1`) |
| Opportunity 2 (rival, closed-lost) | cmw58993c003bqy53lq5hx9vn | **API** PATCH→CLOSED_LOST then `DELETE /api/opportunities/:id` → 200 (deletion guard first live-probed: 422 `OPPORTUNITY_NOT_DELETABLE` while QUALIFIED) |
| Contact ×2 | cmw5865ex… + rival | cleanup script (`contacts: 2`) |
| Offer (CONVERTED) | cmw5888si002bqy53nm8i3fkt | cleanup script (`offer: 1`) |
| Reservation (CONVERTED) | cmw588q54002pqy53pgwz8usl | cleanup script (`reservation: 1`, after its installments/payments) |
| Installments ×2 | cmw589yx8…, cmw589yxy… | cleanup script (`installments: 2`) |
| Payments ×2 | cmw58acvg…, cmw58acwd… | cleanup script (`payments: 2`) |
| Task | cmw586rl5001tqy53aflwwkb0 | **API** `DELETE /api/tasks/:id` → 200 `{deleted:true}` |
| Visit (COMPLETED) | cmw587058001zqy53tgq7d1kn | **API** `DELETE /api/visits/:id` → 200 `{deleted:true}` (VisitApartment cascade) |
| Apartment A-02 | cmw56j30v001uqyzlhj6mr7n5 | status SOLD → **AVAILABLE restored** (captured status) |
| Activities ×23, business AuditLogs ×32 | — | cleanup script (marker/id-scoped, FK-safe order) |

**Zero-residue verification (from `tmp-scripts/p4-a4-cleanup.ts` output):**

```
RESIDUE {"leads":0,"leadsByName":0,"opps":0,"oppsByTitle":0,"contacts":0,"offer":0,
"reservation":0,"installments":0,"payments":0,"activities":0,"auditBiz":0,
"auditMarker":0,"tasks":0,"visits":0,"leadTouches":0,"visitApartments":0}
APT_AFTER {"code":"A-02","status":"AVAILABLE"}
```

- Marker scans across every business table (by id AND by `P4-AUDIT` string in names/titles/labels/references/notes/audit payloads): **0 rows**.
- `GET /api/leads?query=P4-AUDIT` → `total: 0`.
- **Business census restored EXACTLY to baseline:** leads 43, opportunities 21, apartments 46, reservations 8, offers 3, payments 8, installments 14, activities 187, tasks 18, visits 24, contacts 20, users 8 — identical to the pre-audit probe.
- Dashboard KPIs restored exactly: newLeads 36, uncontacted 11, clients 20, wonInRange 101,800,000, conversionRate 13.3 (identical to the pre-audit snapshot).
- **AuditLogs 355 → 367 (+12)**: the delta is exclusively LOGIN/LOGIN_FAILED/SESSIONS_REVOKED session-telemetry rows created during the audit window by the LIVE parallel Phase-4 multi-agent session (sarah/amine/karim/lina/mounia logins incl. other agents' failed-login probes — e.g. lina/mounia rows at 17:05). My business audit rows were all deleted (`auditBiz` 32→0, `auditMarker` 0); zero non-USER audit rows from my session window remain (verified: all 33 non-USER rows after 16:30Z predate my first request at 17:02 and belong to the Principal's earlier test-suite runs). Deleting the shared login telemetry of parallel agents would destroy their evidence — deliberately left, documented here. **INFO-1.**

Teardown followed the `tests/security/offer-concurrency.test.ts` afterAll pattern (capture → id/marker-scoped deleteMany in dependency order → apartment status restore → verification). No seeded business record was ever PATCHed or DELETEd; no source file modified; no migration; no server restart; no test suite run; no build.

---

## 7. Duplicate / resilience findings (Phase C)

| Probe | Result | Evidence |
|---|---|---|
| Duplicate lead, same phone, no force | **PASS** | `POST /api/leads` phone `+213500000000` → **409 DUPLICATE** `{duplicates:[{id, fullName, phone…}]}` — contract-shaped response surfacing the existing lead inside the caller's scope (scope-aware: foreign duplicates answer existence-only). No row created. |
| Duplicate phone WITH `force:true` | **PASS** | → **409 DUPLICATE** "le téléphone identifie une personne unique et ne peut pas être forcé" — the `@@unique([orgId, phone])` P2002 backstop; DB count for that phone stayed **1** (no twin). Email duplicates remain force-able (deliberate asymmetry). |
| Duplicate scanner (P30) | **PASS** | `GET /api/leads/duplicates` returns the seeded explainable pair (Mohamed Larbaoui ×2, reasons `["EMAIL","NAME"]`, strong:true) — the DUPLICATE_RULES engine (duplicates.ts: EMAIL exact / PHONE_CROSS / NAME-normal-form) runs on real data; NAME-only pairs surface as suggestions, never auto-actions. |
| Duplicate payment submission | **PASS** | Retry of the full-coverage payment on the PAID line → **409 INSTALLMENT_ALREADY_PAID**; no second payment row (payments=2). In-tx balance re-read (payments.ts:139-151) closes the TOCTOU double-submit class. |
| Repeat/concurrent closure | Code-verified | status-preconditioned `updateMany` claim (reservation-lifecycle.ts:255-261) → safe 409 `RESERVATION_ALREADY_CLOSED`, zero rows flipped, no double SOLD. |
| Twin-activity guard | Code-verified | 5-second dedup window on identical timeline writes (leads/[id]/activities/route.ts:70-92) — double-click echoes re-answer 200 with the existing row. |

---

## 8. Findings register

| Id | Severity | Finding | Disposition |
|---|---|---|---|
| MINOR-1 | MINOR | WIP limits (p11) are advisory only — over-limit stage moves warn, never block; no server-side WIP enforcement. | Documented design (D-UX-043 "board-level-signal law"); production owners should consciously accept an advisory capacity signal. No action required for acceptance. |
| MINOR-2 | MINOR | The CRM échéancier deliberately models partial schedules: the seeded ACTIVE hold H-31 (58M agreed) schedules only 24.36M of lines (booking 5.8M + 3×5.8M + notary 1.16M) + 5.8M depositPaid; nothing requires Σinstallments == agreed price. | Consistent with the operating model (heavy finance = future ERP; "deal economics are the only money"). Flagged so the ERP handoff knows the CRM schedule is not a full amortization plan. |
| INFO-1 | INFO | AuditLog census cannot return to a fixed baseline in a live multi-agent session: +12 LOGIN-family rows (shared telemetry across parallel P4 agents). My business residue is exactly 0. | No action; noted for census comparability across agents. |
| INFO-2 | INFO | `GET /api/metrics` is ADMIN+ (sarah 403 `FORBIDDEN_ROLE`) — reporting verification for MANAGER used `/api/dashboard` + `/api/analytics` (sufficient). | By-design RBAC. |
| INFO-3 | INFO | Closure does not auto-generate an échéancier — installments are manager-created lines (`POST /api/finance/installments`, MANAGER+). | By design (§D-022 law 2: money recording is management work). |
| INFO-4 | INFO | Seed contains exactly one intentional duplicate-email pair (m.larbaoui@gmail.com ×2) powering the P30 duplicates feature; zero duplicate phones. | Seed feature, verified live. |
| INFO-5 | INFO | Payments on won deals are partial by narrative (Djamila 30 %, Mustapha 10 %, Farid 100 %) — payments ≤ installments everywhere; no over-collection possible by construction. | Healthy. |
| INFO-6 | INFO | zod rejects unknown enum values with precise 422 (live-probed: `propertyType:"APARTMENT"` → VALIDATION_ERROR listing the 8 valid UNIT_TYPES). | Healthy strictness. |

**No CRITICAL or MAJOR findings in the CRM domain.**

---

## 9. Score: **97 / 100**

Methodology (evidence-weighted, deductions only for findings attributed to the product):

| Component | Weight | Awarded | Rationale |
|---|---|---|---|
| A. Code & data verification (Phase A: 6 items, all cited) | 20 | 20 | Every invariant located in code with file:line and confirmed against live data. |
| B. Live 15-step golden path | 45 (3/step) | 45 | 15/15 PASS with status codes + field-level evidence; 0 BLOCKED. |
| C. Financial integrity (7 won deals + synthetic deal + atomicity) | 20 | 20 | 7/7 coherence; live value-alignment proof; 2:2:2 payment/audit/activity atomicity. |
| D. Guards & resilience (Phase C duplicates/idempotency) | 10 | 10 | All probes PASS (phone dup non-forceable, payment idempotency, closure claim idempotency). |
| E. Cleanup discipline | 5 | 5 | Zero residue proven; exact census + KPI restoration; API-delete paths used where the API allows. |
| Deductions | −3 | | −1 MINOR-1 (advisory WIP), −1 MINOR-2 (partial-échéancier semantics need ERP-handoff awareness), −1 INFO-1 (session-telemetry census noise — observability attribution limit). |

---

## 10. Evidence appendix (abridged request/response log)

```
# Session: sarah@asas.dz (MANAGER), cookie /tmp/p4-a4-sarah.txt; amine probe /tmp/p4-a4-amine.txt
17:02  POST /api/auth/login {sarah}                       → 200 {role:"MANAGER"}
17:03  [probe] tmp-scripts/p4-a4-census.ts                 → CENSUS {users:8, leads:43, opps:21, apts:46,
                                                                res:8, offers:3, payments:8, inst:14, act:187, audit:355}
       [probe] 7 won deals                                 → valueEqualsAgreed true ×7; TOTAL 236,200,000 DZD
17:04  POST /api/leads (P4-AUDIT lead, WALK_IN)            → 201 {status:"NEW", score:0}
       PATCH  /api/leads/:id {propertyType:"APARTMENT"}    → 422 VALIDATION_ERROR (enum)
       PATCH  /api/leads/:id {status:QUALIFIED, F3, 12-28M}→ 200 {status:"QUALIFIED"}
       PATCH  /api/leads/:id {ownerId:amine}               → 200 {ownerId:amine} + LEAD_ASSIGNED audit
       PATCH  /api/leads/:id {email,notes,nextFollowUpAt}  → 200
       POST   /api/leads/:id/convert                       → 201 {opp QUALIFIED, value 28M, prob 15,
                                                                nextAction, stageChangedAt}
17:05  PATCH /api/opportunities/:id →VISIT_SCHEDULED       → 200 {stageChangedAt 17:05:09.574Z}
       PATCH /api/opportunities/:id →VISIT_COMPLETED       → 200 {stageChangedAt 17:05:09.655Z}
       PATCH /api/opportunities/:id →QUALIFIED (backwards) → 422 CORRECTION_REASON_REQUIRED
       PATCH /api/opportunities/:id →CLOSED_WON (+reason)  → 422 VISIT_REPORT_REQUIRED {linked:false}
       POST /api/leads/:id/activities {CALL/INTERESTED}    → 201
       POST /api/tasks {FOLLOW_UP +5d HIGH}                → 201 {OPEN}
       POST /api/visits {Les Oliviers, A-02, agent amine}  → 201 SCHEDULED (opp auto-linked)
       [amine] PATCH /api/visits/:id {CONFIRMED}           → 403 VISIT_CONFIRM_FORBIDDEN   ← operating model
       [sarah] PATCH /api/visits/:id {CONFIRMED}           → 200 {confirmedById/At}
       PATCH /api/visits/:id {COMPLETED + report}          → 200 {attended, interestLevel, reportedBy server-stamped}
17:06  POST /api/offers {A-02, 18.9M, activate}            → 201 ACTIVE; A-02 → OPTIONED (same tx)
       POST /api/offers/:id/confirm                        → 200 CONFIRMED
       POST /api/offers/:id/convert                        → 200 {reservation ACTIVE 18.9M; A-02 → RESERVED;
                                                                offer CONVERTED + link; opp → RESERVATION}
       [rival] POST /api/leads + convert                   → 201/201 (rival opp QUALIFIED)
       POST /api/reservations {rival on A-02}              → 409 APARTMENT_NOT_AVAILABLE {status:"RESERVED"}
17:07  PATCH /api/reservations/:id {request_closure}       → 200 CLOSURE_REQUESTED {evidence}
       PATCH /api/reservations/:id {validate_closure}      → 200 {res CONVERTED, apt SOLD, opp CLOSED_WON,
                                                                value 28M→18.9M aligned; 4 audit rows}
       POST /api/finance/installments ×2                   → 201 {PLANNED seq 1,2}
17:08  POST /api/finance/payments (before call)            → 409 INSTALLMENT_NOT_CALLED
       PATCH /api/finance/installments/:id {CALLED}        → 200 {calledAt}
       POST /api/finance/payments {4M > 3.78M}             → 422 EXCEEDS_REMAINING {remaining:3780000}
       POST /api/finance/payments {2M CASH}                → 201 {line stays CALLED}
       POST /api/finance/payments {1.78M TRANSFER}         → 201 {line PAID + paidAt}
       POST /api/finance/payments (repeat)                 → 409 INSTALLMENT_ALREADY_PAID
       [probe] payments=2, PAYMENT_RECORDED audits=2, PAYMENT activities=2, Σ=3,780,000
       GET /api/activities?leadId                          → 20-row accurate timeline (see §3 step 14)
17:08  GET /api/dashboard                                   → KPIs moved (+2 leads, +18.9M won)
       GET /api/analytics                                  → bySource WALK_IN won 2 / 30.7M (incl. synthetic)
17:09  [Phase C] POST /api/leads {dup phone}               → 409 DUPLICATE {duplicates:[…]}
       [Phase C] POST /api/leads {dup phone, force}        → 409 DUPLICATE (unique-index backstop; count stays 1)
       GET /api/leads/duplicates                           → seeded EMAIL+NAME pair, strong
17:10  DELETE /api/tasks/:id                               → 200 {deleted:true}
       DELETE /api/visits/:id                              → 200 {deleted:true}
       DELETE /api/opportunities/:rival (QUALIFIED)        → 422 OPPORTUNITY_NOT_DELETABLE (guard)
       PATCH /api/opportunities/:rival {CLOSED_LOST+code}  → 200 {prob 0, closedAt, lostReasonCode OTHER}
       DELETE /api/opportunities/:rival                    → 200 {deleted:true}
17:11  [cleanup] tmp-scripts/p4-a4-cleanup.ts              → CLEANED [payments:2, installments:2, activities:23,
                                                                auditBiz:32, reservation:1, offer:1, opportunities:1,
                                                                contacts:2, leads:2, A-02→AVAILABLE]
       RESIDUE all-zero; FINAL_CENSUS business tables == baseline
       GET /api/dashboard                                   → KPIs == pre-audit snapshot exactly
       GET /api/leads?query=P4-AUDIT                        → total 0
```

**Deliverable completeness:** Phase A (code citations §5, money probe §4), Phase B (15-step matrix §3), Phase C (§7), cleanup certification (§6), findings (§8), score (§9), evidence (§10). Scripts: `tmp-scripts/p4-a4-census.ts`, `tmp-scripts/p4-a4-cleanup.ts` (this audit's only filesystem writes besides this document).
