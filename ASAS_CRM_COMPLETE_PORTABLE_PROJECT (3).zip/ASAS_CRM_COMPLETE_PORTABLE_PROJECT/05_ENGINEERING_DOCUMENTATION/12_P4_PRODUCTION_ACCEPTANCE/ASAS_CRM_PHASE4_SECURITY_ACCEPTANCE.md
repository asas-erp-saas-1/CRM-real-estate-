# ASAS CRM — Phase 4 Independent Production Readiness Audit
## P4-3 · Security, Authentication, Authorization & Privacy Acceptance

| | |
|---|---|
| **Task ID** | P4-3 (Agent 3 — Security/Auth/Authz/Privacy Auditor) |
| **Date** | 2026-11-06, 17:00–17:15 UTC |
| **Git HEAD** | `6201496` (clean tree; only `05_ENGINEERING_DOCUMENTATION/12_P4_PRODUCTION_ACCEPTANCE/` + `tmp-scripts/p4-a3-*` untracked) |
| **Mode** | READ-ONLY code audit + non-destructive live probes vs `http://127.0.0.1:3000` |
| **Verdict** | **SECURITY ACCEPTED — WITH FINDINGS** (conditional; see §1.3) |
| **Score** | **87 / 100** (methodology §7) |

---

## 1. Executive summary

### 1.1 What was audited

Full read-through of the security-bearing code (`src/lib/server/session.ts`, `boot.ts`, `instrumentation.ts`, `visibility.ts`, `auth.ts`, `lead-capture.ts`, `documents.ts`, `file-verification.ts`, `logger.ts`, `faults.ts`, `proxy.ts`, `next.config.ts`, all `src/app/api/auth/**` routes, plus leads/tasks/opportunities/reservations/finance/documents/users/metrics/audit/export routes) combined with a 30-step live curl probe battery against the running dev server, read-only Prisma/SQLite probes (`tmp-scripts/p4-a3-*.ts`), git-history secret checks, and log-redaction sampling.

### 1.2 Headline results

- **Authentication is production-shape**: HMAC-SHA256-signed session cookies (`asas_user = userId.issuedAtMs.hmac`), constant-time verification, 7-day absolute expiry, `passwordChangedAt` + `sessionsRevokedAt` + exact-pair `RevokedSession` invalidation, scrypt (N=16384) password hashing, DB-backed login lockout (5 fails / 15 min, restart-survivable), timing-oracle dummy-hash defense. **Every one of these was verified live in this session.**
- **Authorization is uniformly enforced server-side**: `requireUser(role?)` on every route (grep sweep of `src/app/api`), D-021 visibility fragments composed into every data query (29+ composition sites verified), scoped `findFirst` producing **byte-identical 404 ghosts** (live-proven in two domains with sha256 equality), role gates live-verified (403 envelopes), admin-surface fencing live-verified.
- **No CRITICAL and no code-level MAJOR vulnerability found.** The MAJOR items are *deployment-configuration conditions* (edge TLS/HSTS/CSP absent from the live Caddyfile; privacy legal review outstanding) — not application defects.
- Cross-tenant (org-B) isolation could not be exercised live this session because the current DB holds **one organization only** (the second org seen in the 16:52 snapshot was a parallel agent's permission-matrix test fixture, torn down before this audit). Isolation is instead evidenced three ways: code (every query composes `orgId`), the automated cross-org matrix (`tests/security/permission-matrix.test.ts`, 20 bidirectional org-fence rows, run earlier today — its fixture org is present in the `db/backups/custom-20261106-165228.db` snapshot and absent from the live DB, proving both the run and the teardown), and the live record-level 404-ghost analogue (§5, probes P-08/09/10 — the same scoped-`findFirst` mechanism that implements the org fence).

### 1.3 Conditions attached to the verdict (must close before public deployment)

1. **C-1 (MAJOR, deployment)** — Terminate TLS at the edge and add HSTS + CSP + frame policy: the live `Caddyfile` (`:81`, plain HTTP, no added headers) currently provides none; `next.config.ts` deliberately defers CSP/HSTS/XFO to the edge (V-05) but the edge config doesn't do it yet. The session cookie's `secure` flag only activates under `NODE_ENV=production`, which requires TLS to function.
2. **C-2 (MAJOR, legal)** — Algerian Law 18-07 review by counsel (§4.3): AI-provider transfer of lead names/notes without a documented DPA; no retention schedule; no data-subject-rights (access/rectification/erasure) tooling; IP + email retention in security tables.
3. **C-3 (MINOR, ops)** — Single-instance assumptions: in-memory rate limiters (public capture, copilot) reset on restart and don't span instances; documented trade-off, acceptable only while the single-instance deployment law holds.

### 1.4 Environment incidents observed (transparency)

- The dev server was **down** at session start (reaped; `dev.log` last write 17:00:06, no `bun run dev` process, port 3000 refused, gateway :81 → 502). It was brought up once via the documented AGENTS.md procedure (`(setsid nohup bun run dev … &)`) — environment recovery of a dead server, not a restart of a live one. `/api/health` verified `ok` immediately after.
- A parallel P4 agent's activity was live in the DB during this audit (a "P4-AUDIT- Test Lead" created/converted ~16:52–17:00; permission-matrix test fixtures). None of it is this agent's residue; this agent created **zero** records (all its mutation probes were rejected pre-parse: 403 CSRF, 400 INVALID_JSON, 404 ghosts).

---

## 2. Threat model — STRIDE

| Threat | Primary attack path considered | Control that blocks it (evidence) | Residual risk |
|---|---|---|---|
| **Spoofing** (user identity) | Forged `asas_user` cookie: raw userId, tampered payload, garbage HMAC | HMAC-SHA256 over `userId.issuedAtMs` with `ASAS_SESSION_SECRET`; `timingSafeEqual` on hex; strict format regex (`session.ts:56-73`). Live: garbage + well-shaped-forgery cookies → 401 NO_SESSION (P-04/05), never 500 | **Low**. Password spraying across *many* accounts is bounded per-email (5/15 min) but not per-IP across emails — no per-IP login throttle. No MFA (single-factor by design) |
| **Spoofing** (cross-tenant) | Org-B member forges a session / quick-login as org-A user | Session resolves only real `active` users; quick-login constrained to the first-created (designated demo) org (`demo-org.ts`, login route `orgId: demoOrgId` filter); foreign userId → ghost 404 (P-24 analogue + matrix test rows 238/240-244) | **Low** (code+test verified; live cross-org run impossible this session — single-org DB) |
| **Tampering** (request forgery / CSRF) | Cross-site POST with stolen cookie; forged Origin on login | `assertSameOrigin()` inside `requireUser()` AND `readJson()` (login-CSRF closed); sameSite=lax primary; `Sec-Fetch-Site: same-origin/none` browser-vouched (JS-forbidden header). Live: forged-Origin POST /api/leads → 403 CROSS_ORIGIN_BLOCKED (P-16); forged-Origin login → 403 (P-18) | **Low**. Non-browser clients omitting Origin are deliberately allowed (curl/server-to-server) — sameSite+lax scopes the browser case |
| **Tampering** (data) | Privilege-escalating writes: create OWNER as ADMIN, assign leads as agent, mass-assignment on public capture | ROLE_CEILING (ADMIN cannot mint/reset OWNER — `users/route.ts:65`, `reset-password/route.ts:31`); assignment is MANAGER+ (`leads/route.ts:338`); `.strict()` zod whitelist on public capture (`lead-capture.ts:280-292`). Live: agent POST /api/users → 403 (P-13) | **Very low** |
| **Repudiation** | "I never did that" — unlogged mutations, invisible reattribution | AuditLog rows on every mutation incl. LOGIN/LOGIN_FAILED/LOGIN_LOCKED/LOGOUT/SESSIONS_REVOKED/DOC_DOWNLOADED/EXPORT_BUNDLE; transactional audit writes (F-06). Live: this session's failed logins + revoke-all are in the audit trail with IP (§8.4) | **Very low**. AuditLog itself is MANAGER+-gated and org-scoped (`audit/route.ts:18,25`) |
| **Information disclosure** (existence oracles) | Distinguish foreign vs nonexistent records (403 vs 404, body diff) | Scoped `findFirst` → byte-identical 404. Live: sha256-equal bodies for out-of-scope vs ghost ids in leads **and** tasks domains (P-08/09/10/22/23); duplicate-check path reports foreign duplicates with empty list (no name/owner leak) | **Very low** |
| **Information disclosure** (account enumeration) | Login timing + response diff for unknown vs existing email | DUMMY_HASH scrypt equalization + identical INVALID_CREDENTIALS body. Live: 50–55 ms vs 54–56 ms (indistinguishable, P-19); identical bodies (P-20) | **Low** |
| **Information disclosure** (error leakage) | Stack traces / Prisma internals in client responses | `fail()` returns generic `{"error":"Erreur interne — réessayez.","code":"INTERNAL"}` for non-ApiError 500s; full detail stays server-side (`session.ts:287-318`). Live: malformed JSON → clean 400 INVALID_JSON envelope (P-17) | **Very low**. A deterministic live 500 trigger wasn't attempted (all inputs zod-gated — itself hardening evidence); generic-500 path is code-verified |
| **Information disclosure** (secrets) | Secret in git, client bundle, logs, health endpoint | Live: `/api/health` exposes booleans only (`sessionSecretConfigured: true` — presence, never value, P-01); secret value: 0 matches in tracked files and 0 in the worktree outside `.env` (§8.5); 0 imports of session/signing code in `src/components`/`src/lib/client`; historical `.env` (initial commit) contained only a local SQLite path | **Very low**. Dev fallback secret (unset env) is dev/test-only, production-crashed at boot |
| **DoS** (auth) | Brute-force lockout bypass via restart | DB-backed `LoginFailure` (migration #24) — lockout survives restarts. Live: 2 failed logins → rows persisted with IP; success cleared them (P-20) | **Low** |
| **DoS** (public surface) | Anonymous flood on `/api/public/lead-capture` | IP budget (30/min) is gate #1 **before** token resolution/DB work; token budget 10/min post-verification; honeypot + phone-interval swallow cost zero DB. Live: 6 invalid-token requests → uniform 401, no pollution (bad tokens never reach the token budget; direct probes carry no vouched IP) | **Medium-low**: windows are process-local (restart resets, C-3); `clientIp()` null (direct dev access) skips the IP budget by design — behind the Caddy gateway the XFF is vouched |
| **DoS** (uploads) | Oversized/malicious uploads | Pre-`formData()` Content-Length rejection (> 8 MB + 64 KB slack) + authoritative `file.size` gate; magic-byte sniffing vs whitelist (PDF/PNG/JPEG/WEBP); no executable type can be stored or served inline | **Low** |
| **Elevation of privilege** | Agent reaches admin surface; route forgets a gate | `requireUser("ADMIN"/"MANAGER")` on all sensitive surfaces (grep sweep §8.2: metrics, users, audit, finance, export, targets, pipeline, analytics, duplicates, import); UI hiding is never authorization. Live: agent → metrics/users/audit/finance/payments/export all 403 (P-12/13/14/15/25) | **Very low** |

---

## 3. RBAC & org isolation findings

### 3.1 Role model — verified

Rank order OWNER > ADMIN > MANAGER > SALES_AGENT > FIELD_REP (`src/lib/constants.ts`), enforced by `atLeastRole` inside `requireUser(minimumRole?)` — a single choke point that also runs `assertSameOrigin` **before** session resolution (order verified: `session.ts:321-331`).

**Role-gated surfaces (grep-verified, 30 sites)**: `/api/metrics` (ADMIN), `/api/users` POST/PATCH + reset-password (ADMIN), `/api/targets` + copy (ADMIN), `/api/pipeline/stages/[id]` (ADMIN), `/api/audit`, `/api/settings`, `/api/finance/**` (overview/installments/payments — MANAGER), `/api/analytics` + attribution, `/api/journey/stats`, `/api/leads/export`, `/api/export/bundle`, `/api/leads/import` + undo, duplicates merge/dismiss, `/api/lead-capture-tokens` + revoke, project assignments, apartments mutations (MANAGER). All live-checked where non-destructive: 403 FORBIDDEN_ROLE envelopes (P-12/13/14/15/25).

### 3.2 Record-level visibility (D-021) — verified on 8 domains

`src/lib/server/visibility.ts` exports the single authorization-boundary primitive; every data route composes it:

| Domain | List composition | Detail/mutation scoped findFirst | Evidence |
|---|---|---|---|
| Leads | `leads/route.ts:40` | `leads/[id]/route.ts:34` (+ touches/copilot) | code + live counts (44/15/12) + 404 ghost |
| Opportunities | `opportunities/route.ts:43` | `[id]/route.ts:86,478`, gates:27 | code + matrix test |
| Tasks | `tasks/route.ts:29` | `[id]/route.ts:46,144` | code + live 404 ghost (P-22/23) |
| Visits | `visits/route.ts:40` | matrix + canConfirmVisit guard | code |
| Activities | `activities/route.ts:24` | `[id]/route.ts:24` | code |
| Reservations | matrix + `[id]/route.ts:91` | `[id]/route.ts:90-91` | code + matrix test |
| SAV | `sav/route.ts:106,139,198` | `[id]/route.ts:67,112` | code |
| Documents | `documents/route.ts:52` (async documentScope) | `[id]/file/route.ts:47` | code (binary itself scope-gated) |

- **Composition law holds**: a repo-wide multiline search for the forbidden pattern (scope spread adjacent to an explicit `OR:` key in one literal) found **0 violations**; `search/route.ts` documents and applies the AND-composition explicitly.
- **Live visibility census** (same query, three roles): MANAGER 44 leads, SALES_AGENT (amine) 15 (OWN+POOL), FIELD_REP (mounia) 12 (project-derived: assigned to "Résidence Les Oliviers" + "Hydra Heights" — a lead visited on Hydra Heights is *correctly* visible to her; a lead with no visit on her projects → byte-identical 404, P-23).
- **User management invariants** (code): org-scoped load → ROLE_CEILING (ADMIN cannot create/patch/reset OWNER) → SELF_* guards → LAST_OWNER; temp passwords via CSPRNG (`randomInt`, unambiguous alphabet), returned once, scrypt-hashed.
- **Data minimization** (live-visible): `/api/users` GET strips emails below MANAGER (`users/route.ts:39-41`).

### 3.3 Cross-org isolation

- **Code**: every query in every route composes `orgId: user.orgId` (the D-021 base condition); quick-login is fenced to the designated demo org; admin revoke-all resolves targets `findFirst({ id, orgId })` with ghost-404 for foreign-org ids.
- **Automated test**: `tests/security/permission-matrix.test.ts` carries 20 dedicated org-fence rows (leads/opps/offers/reservations/tasks/visits/sav/documents/matching/users/quick-login, bidirectional incl. a foreign-org MANAGER with real credentials) — run earlier today by a parallel agent (fixture org "QA4 Probe Org" present in the 16:52 DB snapshot, absent from the live DB → run + teardown proven).
- **Live analogue this session**: the same scoped-`findFirst` mechanism was live-proven at record level (two domains, sha256-identical ghosts). Classified: **CODE-VERIFIED + TEST-VERIFIED + ANALOGUE-LIVE**; a fresh live cross-org run was impossible without DB writes (single-org DB, write ban).

---

## 4. Privacy assessment

### 4.1 Personal-data inventory (per Prisma schema + route reads)

| Class | Fields | Where | Exposure surface |
|---|---|---|---|
| Identity | `fullName`, `fullNameAr` (Arabic names) | Lead, Contact | All org-visible surfaces per D-021; exports (MANAGER+) |
| Contact | E.164 `phone` (+213), `phoneRaw`, `whatsapp`, `email`, `address` | Lead, Contact, User | D-021-scoped; roster emails stripped below MANAGER |
| Financial | budgets, deal values, installments, payments, commissions, `agentIncentive`, `notary`, `contractRef` | Opportunity/Reservation/Installment/Payment | MANAGER+ gates on finance routes; commission economics travel in export bundle |
| Documents | uploaded binaries (PDF/images), filenames (Arabic/French) | db/docs | scope-gated download + DOC_DOWNLOADED audit; magic-byte whitelist |
| Lead provenance | source, campaign, UTM params, lead-capture submissions (name/phone/email/message) | Lead | public capture (token-gated, generic responses) |
| Agent ownership | ownerId/agentId/assigneeId across domains | all | visibility model itself |
| Exports | full CSV/ZIP snapshots (≤5 000 rows/entity) | /api/leads/export, /api/export/bundle | MANAGER+; LEAD_EXPORTED / EXPORT_BUNDLE audits; CSV formula-injection defanged |
| Audit/security | emails + IPs (LOGIN_FAILED, LoginFailure), actor names, before/after diffs | AuditLog, LoginFailure | MANAGER+ (audit API); server console |
| AI processing | lead name, notes (≤500 chars), budgets, timeline titles → external LLM | copilot/analyze routes | server-side only; **no phone/email sent** (`hasEmail` boolean — good minimization) |

### 4.2 Controls found (positive)

Data minimization below MANAGER (emails), generic no-oracle public capture, hash-only capture-token storage, scope-gated document egress with audit, bounded log redaction (emails/IPs logged only as security trail), honeypot+rate limits on the public intake.

### 4.3 Law 18-07 (Algeria) — items requiring legal counsel review (NOT a compliance claim)

1. **Lawful basis & purpose limitation** for CRM processing of prospect data (consent vs. legitimate interest) — especially data captured via public landing-page forms and WhatsApp-origin leads.
2. **Third-party processor (AI provider)**: lead names + free-text notes are transmitted to the LLM service (z-ai-web-dev-sdk) with no documented Data Processing Agreement, no cross-border-transfer assessment — the biggest 18-07 gap.
3. **Retention schedule**: no documented retention/deletion policy for leads (incl. archived/lost), LoginFailure rows (swept at 1 h — good), AuditLog (unbounded), RevokedSession (swept at 8 d — good), documents, backups (`db/backups/` retention kept=4-5).
4. **Data-subject rights**: no tooling for access/rectification/erasure/portability requests (a manual process may suffice legally — counsel to define).
5. **Security-notification obligations**: 18-07 requires breach notification to ANPDP; no incident-response runbook references it.
6. **IP address + email storage** in LoginFailure/AuditLog (security logs) — likely permissible as security processing, but should be covered by the register of processing.
7. **Register of processing / DPO appointment** applicability for an Algiers real-estate agency — counsel to determine.

---

## 5. Live security test results (probe battery)

All probes against `http://127.0.0.1:3000`, cookie jars in `/tmp/p4a3_*.jar`, 2026-11-06 17:01–17:10 UTC. `VERIFIED-LIVE` = observed this session.

| # | Probe | Expected | Result | Status |
|---|---|---|---|---|
| P-01 | `GET /api/health` unauth | booleans only, no secrets | `{"status":"ok","dbOk":true,…,"demoMode":true,"sessionSecretConfigured":true,"nodeEnv":"development","rssMb":1843}` — presence flags only | ✅ VERIFIED-LIVE |
| P-02 | `GET /api/leads` unauth | 401 envelope | `401 {"error":"No active session. Reload the page.","code":"NO_SESSION","details":null}` | ✅ VERIFIED-LIVE |
| P-03 | `GET /api/opportunities`, `/api/notifications`, `/api/users`, `/api/metrics` unauth | 401 | identical 401 NO_SESSION ×4 | ✅ VERIFIED-LIVE |
| P-04 | Forged cookie (garbage) on /api/leads | 401, never 500 | 401 NO_SESSION | ✅ VERIFIED-LIVE |
| P-05 | Forged cookie (well-shaped, wrong HMAC) | 401 | 401 NO_SESSION | ✅ VERIFIED-LIVE |
| P-06 | Login sarah (MANAGER) → `GET /api/auth/session` | 200 user info | 200: user/org/session with `issuedAt` 17:02:06 → `expiresAt` 2026-11-13 (7-day span) | ✅ VERIFIED-LIVE |
| P-06b | Cookie flags on login | httpOnly, lax, path=/ | `#HttpOnly_… asas_user` in jar; secure=FALSE in dev (prod-gated, `login/route.ts:40`) | ✅ VERIFIED-LIVE |
| P-07 | Login as FIELD_REP mounia; lead-visibility census | D-021 scoping | mounia 12 / amine 15 / sarah 44 / karim 44 leads (same endpoint) | ✅ VERIFIED-LIVE |
| P-08 | amine → lead owned by lina (out of OWN+POOL scope) | 404 ghost | `404 {"error":"Lead introuvable","code":"LEAD_NOT_FOUND","details":null}` | ✅ VERIFIED-LIVE |
| P-09 | amine → nonexistent lead id | identical 404 | **sha256-identical** body (`ec752609…` both) | ✅ VERIFIED-LIVE |
| P-10 | amine → own lead (control) | 200 | 200 | ✅ VERIFIED-LIVE |
| P-11 | Cross-org (org-B record) | — | **NOT RUNNABLE** (single-org DB; no DB writes allowed). Substituted by code+matrix-test evidence + P-08/09/22/23 analogues | ⚠️ NOT VERIFIED-LIVE (see §3.3) |
| P-12 | `/api/metrics` as amine (SALES_AGENT) | 403 | `403 {"error":"Requires role ADMIN or higher.","code":"FORBIDDEN_ROLE"}` | ✅ VERIFIED-LIVE |
| P-13 | `POST /api/users` (attempt ADMIN creation) as amine | 403 | 403 FORBIDDEN_ROLE — role gate fires before parse/create | ✅ VERIFIED-LIVE |
| P-14 | `POST /api/finance/payments` as amine | 403 (gate before write) | 403 FORBIDDEN_ROLE (`requireUser("MANAGER")` precedes `parseBody`/`recordPayment` — no write possible) | ✅ VERIFIED-LIVE |
| P-15 | `/api/leads/export` as amine | 403 | 403 | ✅ VERIFIED-LIVE |
| P-16 | CSRF: `POST /api/leads` valid cookie + `Origin: http://evil.example` + `Sec-Fetch-Site: cross-site` | rejection | `403 {"error":"Requête inter-origines refusée.","code":"CROSS_ORIGIN_BLOCKED"}` — no record created (dev.log shows only 403/400 POSTs from this session) | ✅ VERIFIED-LIVE |
| P-17 | Malformed JSON `POST /api/leads` (valid session) | no stack/internal leak | `400 {"error":"Corps de requête JSON invalide","code":"INVALID_JSON","details":null}` | ✅ VERIFIED-LIVE |
| P-18 | Login-CSRF: `POST /api/auth/login` forged Origin | rejection | 403 CROSS_ORIGIN_BLOCKED (readJson choke point) | ✅ VERIFIED-LIVE |
| P-19 | Timing oracle: unknown-email vs wrong-password logins | equal latency | unknown 55.5/49.8 ms vs real 53.9/56.4 ms — indistinguishable (DUMMY_HASH equalization) | ✅ VERIFIED-LIVE |
| P-20 | Lockout: 2 failed logins (lina) then success | rows recorded, window cleared | 2× 401 INVALID_CREDENTIALS (byte-identical); LoginFailure rows with IP persisted in DB; successful login → 0 rows (clearFailures). **Held to the ≤2 safety limit; 429 not triggered** (covered by `session-governance.test.ts` "5 failures → 429 ACCOUNT_LOCKED", run earlier today by a parallel agent) | ✅ VERIFIED-LIVE (mechanics) / ⚠️ 429 NOT re-triggered (safety) |
| P-21 | Session revocation: amine ×2 jars, revoke-all via jar1 | jar2 dead | revoke-all `{}` → 200 `{"ok":true,"revokedAt":"…","self":true}`; jar1+jar2 → 401 NO_SESSION on protected route; amine re-logged-in (state restored). SESSIONS_REVOKED audit row written | ✅ VERIFIED-LIVE |
| P-22 | amine → PATCH lina's task (out of scope) | 404 ghost | 404 TASK_NOT_FOUND (before any transaction — no write) | ✅ VERIFIED-LIVE |
| P-23 | amine → PATCH ghost task id; FIELD_REP → out-of-project lead | identical 404 | both byte-identical to P-22 body; mounia → "Bachir Amrani" lead = 404 = ghost | ✅ VERIFIED-LIVE |
| P-24 | Quick-login with nonexistent userId | ghost 404 | `404 {"error":"Utilisateur introuvable ou inactif","code":"USER_NOT_FOUND"}` | ✅ VERIFIED-LIVE |
| P-25 | `/api/audit` as amine | 403 | 403 FORBIDDEN_ROLE (MANAGER+ gate) | ✅ VERIFIED-LIVE |
| P-26 | `/api/metrics` as sarah (MANAGER) / karim (ADMIN) | 403 / 200 | 403 FORBIDDEN_ROLE; 200 with route-pattern metrics only — **no customer data, no user identifiers** (keys: routes/errorsByCategory/dbQueries/memory/notificationCache) | ✅ VERIFIED-LIVE |
| P-27 | `POST /api/public/lead-capture` invalid token ×6 | generic 401, no oracle | 6× `401 {"error":"Jeton de capture invalide ou expiré","code":"INVALID_TOKEN"}`; zero rate-limit pollution (IP budget needs vouched XFF; token budget needs a valid row — code-verified order: IP gate #1 → honeypot → token resolve → token budget) | ✅ VERIFIED-LIVE (429 math code-verified only: 30/min/IP, 10/min/token, 60 s sliding window — deliberately NOT saturated to protect parallel agents) |
| P-28 | `/api/notifications` as sarah | 200 | 200 | ✅ VERIFIED-LIVE |
| P-29 | `GET /` root | 200 | 200 (server up after documented recovery) | ✅ VERIFIED-LIVE |

**Boot gates (P0-3)**: `boot.ts` + `instrumentation.ts` fail-fast (SESSION_SECRET missing/weak/placeholder; DEMO_MODE=production) — **IMPLEMENTED-NOT-RUNTIME-VERIFIED** (NODE_ENV=production cannot be exercised in this sandbox); unit coverage `tests/unit/boot-env.test.ts` (10 assertions incl. placeholder + multi-violation + never-gates-dev).

---

## 6. Critical vulnerabilities & findings register

**CRITICAL: none found.**

**MAJOR (deployment/config conditions, not code defects):**

- **F-A3-1 — Production edge has no TLS/HSTS/CSP/frame policy.** `next.config.ts` sets only `X-Content-Type-Options: nosniff` + `Referrer-Policy` and explicitly defers CSP/HSTS/XFO to the edge (V-05); the live `Caddyfile` (`:81`, plain HTTP) adds none. `secure` cookie flag is NODE_ENV-gated. *Evidence: next.config.ts:3-21; Caddyfile:1-23; live headers P-02 (`nosniff`, `strict-origin-when-cross-origin` present).* Fix: terminate TLS at the edge, add HSTS + CSP + frame-ancestors before any public deployment.
- **F-A3-2 — Law 18-07 privacy program absent** (§4.3): AI-provider transfer without DPA, no retention schedule, no DSR process, no ANPDP breach-notification runbook. Fix: legal counsel engagement (pre-deployment condition).

**MINOR:**

- **F-A3-3 — Login lockout is per-email only** (`auth.ts:104-117`): password *spraying* (many emails, few tries each) is bounded per account but not per source IP; `clientIp()` is recorded, not enforced. Fix candidate: a per-IP failure budget alongside the per-email window.
- **F-A3-4 — Process-local rate limiters** (public capture, copilot, analyze): reset on restart, single-instance only — documented trade-off under the no-Redis architecture law (C-3).
- **F-A3-5 — Unknown-route JSON 404 catch-all exists** (`api/[...path]/route.ts`) — good; but unknown `/api` subpaths under authed routes return 405/404 envelopes consistently (verified: finance/payments GET → 405 pre-auth). No issue; noted for completeness.
- **F-A3-6 — Demo mode ON in sandbox exposes the unauthenticated persona roster + passwordless quick-login** — correct by design here (boot gate crashes production+demo; `isDemoModeMisconfigured` runtime re-check; P-24 ghost behavior). Production checklist must assert `/api/health .demoMode == false` (the deploy-gate contract documented in the route).

**INFO (positive findings worth recording):** timing-equalized login (P-19); DUMMY_HASH; transactional audit writes (F-06); CSV formula-injection defanging (CWE-1236, `csvEscape`); document realpath containment + re-sniffed Content-Type + `nosniff` + `private, no-store` on egress; `x-test-inject` fault injection is double-gated (NODE_ENV + exact stage header) and production-inert; deep pattern redaction in logs (verified live: `login_failed_unknown_email`, `api_error` lines — bounded stacks, no secrets); client-side boundary clean (0 imports of session/signing in `src/components`/`src/lib/client`); `/api/auth/session` exposes no cross-user data; historical `.env` (initial commit) contained only a local SQLite path — no credential ever committed; `git grep` for the live secret value: 0 hits.

---

## 7. Score — 87/100

| Dimension | Weight | Score | Rationale (evidence anchor) |
|---|---|---|---|
| Authentication | 20% | 93 | HMAC+expiry+revocation+lockout+scrypt+timing-equalization all live-verified; deductions: no per-IP login throttle (F-A3-3), no MFA |
| Authorization / RBAC / org isolation | 25% | 94 | uniform requireUser + D-021 on 8 domains + byte-identical ghosts (2 domains live) + matrix test; cross-org live run impossible this session (single-org DB) |
| CSRF / request forgery | 10% | 90 | layered sameSite + assertSameOrigin at both choke points, live-verified incl. login-CSRF; no token layer (acceptable for JSON API) |
| Input validation | 10% | 92 | zod everywhere; strict() mass-assignment fence on public capture; money caps; honeypot |
| Rate limiting / DoS resistance | 5% | 72 | login DB-backed (strong); others process-local; IP budget skipped without vouched XFF |
| Secret hygiene | 10% | 92 | boot gates (unit-tested), 0 secret matches in git/worktree, clean client boundary, redaction verified live |
| Error handling / info disclosure | 5% | 90 | consistent envelopes, generic 500s (code), no oracles (live ×2 domains) |
| Production config / boot / edge | 10% | 68 | boot gates strong but NOT runtime-verified; edge TLS/CSP/HSTS missing (F-A3-1); demo-mode gating correct |
| Privacy | 5% | 62 | minimization present; 18-07 program absent (F-A3-2) |
| **Weighted total** | | **87.5 → 87** | |

Deduction integrity: no PASS was awarded without evidence; every ✅ row in §5 carries a command+response in §8; NOT-VERIFIED items are explicitly labeled (cross-org live, 429 saturation, production boot runtime).

---

## 8. Evidence appendix

### 8.1 Authentication code anchors

- `src/lib/server/session.ts:47-73` — signSession/verifySessionCookie (HMAC-SHA256, `timingSafeEqual`, format regex, 7-day absolute expiry `SESSION_MAX_AGE_MS`).
- `src/lib/server/session.ts:103-137` — getCurrentUser: user lookup piggybacks `passwordChangedAt` (F-05), `sessionsRevokedAt` watermark, exact-pair `revokedSessions` (filtered select on the composite unique index).
- `src/lib/server/session.ts:321-331` — requireUser: assertSameOrigin **before** session resolution; role minimum via atLeastRole.
- `src/lib/server/session.ts:344-347` — clientIp parses XFF **rightmost only**.
- `src/lib/server/auth.ts:57-77` — scrypt (N=16384, r=8, p=1, keylen 32, 16-byte salt), constant-time verify; `:84-135` — DB-backed sliding window (5/15 min), opportunistic sweep, clear-on-success.
- `src/app/api/auth/login/route.ts:36-54` — cookie opts (httpOnly, lax, path=/, secure prod-gated, maxAge 7 d) + DUMMY_HASH; `:60-129` — quick-login: demo gate, demo-org fence, lockout-respecting; `:131-204` — credentials flow with lockout, audits, IP capture.
- `src/app/api/auth/change-password/route.ts:39-46` — passwordChangedAt bump invalidates all prior sessions; audit carries userId only.
- `src/app/api/auth/sessions/revoke-all/route.ts:29-77` — SELF/ADMIN modes, org-fenced target resolution (ghost 404), watermark write, audit.
- `src/app/api/auth/logout/route.ts:26-63` — exact-pair revocation row + idempotent cookie clear + 8-day sweep.
- `tests/security/session-governance.test.ts` — replay/revocation/lockout/window-reset/audit-trail coverage (black-box; run earlier today — LoginFailure residue timestamps 16:50-16:56 observed read-only).

### 8.2 Authorization grep sweeps

- `rg 'requireUser\("ADMIN"\)|requireUser\("MANAGER"\)|requireUser\("OWNER"\)' src/app/api` → 30 sites (metrics, users×3, targets×2, audit, settings, export/bundle, leads/export, finance×4, analytics×2, journey, duplicates×3, import×2, capture-tokens×3, assignments×2, apartments, pipeline, merge).
- `rg '\.\.\.(lead|opp|visit|task|contact|activity|reservation|installment|sav)Scope\(' src/app/api` → 29 composition sites across 10 route files.
- Multiline PCRE2 search for spread-adjacent-to-OR composition violations → **0 matches**.
- `rg 'passwordHash' src/app/api` → only login/change-password/users-create/reset-password (hash generation/verification; login strips hash before response `login/route.ts:191-193`).

### 8.3 Document/download hardening (SEC-06, W3-A5)

- `src/lib/server/documents.ts:32-55` — filename sanitization + lexical containment; `:75-100` — realpath read-path containment (symlinks followed, escapes flattened to the 404-ghost).
- `src/lib/server/file-verification.ts:53-105` — magic-byte sniffing (PNG/JPEG/PDF/WEBP/zip-family), whitelist acceptance independent of declared type.
- `src/app/api/documents/[id]/file/route.ts:38-102` — scoped findFirst (orgId + documentScope), re-sniffed Content-Type, DOC_DOWNLOADED audit, RFC 5987 filename encoding, `nosniff` + `private, no-store`.
- `src/app/api/documents/route.ts:99-125` — pre-parse Content-Length rejection + authoritative `file.size` gate (DOC_MAX_SIZE_BYTES = 8 MB, `constants.ts:482`).

### 8.4 Audit-trail live evidence (read-only Prisma probe `tmp-scripts/p4-a3-audit-failures.ts`)

```
2026-11-06T17:05:23.529Z LOGIN_FAILED  ip=::ffff:127.0.0.1 {"email":"mounia@asas.dz","ip":"::ffff:127.0.0.1"}
2026-11-06T17:05:03.724Z LOGIN_FAILED  ip=::ffff:127.0.0.1 {"email":"lina@asas.dz","ip":"::ffff:127.0.0.1"}
2026-11-06T17:04:01.241Z SESSIONS_REVOKED {"email":"amine@asas.dz","mode":"SELF","watermark":"2026-11-06T17:04:01.236Z"}
```
Plus ~40 LOGIN rows with email+role+IP in the 30-minute window (parallel agents included).

### 8.5 Secret hygiene

- Live secret length 48 chars (value never printed); `git grep -l <value>` → 0 tracked matches; worktree ripgrep (excluding `.env`, `db/`, `node_modules/`, `tool-results/`) → 0 matches.
- `.gitignore`: `.env*` (with `!.env.example`), `/db/`, `/db/backups/`, `/db/restore-drills/`, `/tool-results/`, `*.pid`.
- `git log --all --diff-filter=A -- .env` → 1 hit (initial commit `adf78e6`); contents: `DATABASE_URL` only — a local `file:*` SQLite path (36 chars, no credential); no ASAS_SESSION_SECRET key existed then.
- Client boundary: `rg 'lib/server/session|signSession|SESSION_SECRET|createHmac' src/components src/lib/client src/app/page.tsx` → 0 matches.
- Log redaction (dev.log live samples): `login_failed_unknown_email` / `api_error` lines are single JSON objects; `errorStack` bounded to 5 frames/400 chars; no password/cookie/secret values present; redaction is pattern-based (`SENSITIVE_KEY_PATTERN` in `logger.ts:36-38`).
- `/api/health` (live): presence-only `sessionSecretConfigured:true`, no values.

### 8.6 Public capture route law (code)

`src/lib/server/lead-capture.ts` — order of gates: `checkCaptureIpRate` (line 331, FIRST — bounds all later work) → honeypot (335) → `verifyCaptureToken` (340; generic 401 for unknown/expired/revoked, timing-safe compare, 128-char length sanity) → `checkCaptureTokenRate` (341) → E.164 +213 phone discipline → 60 s per-phone interval → durable duplicate fence → atomic create (lead + score + activity + audit + useCount in ONE tx; P2002 race backstop degrades to duplicate handling). Constants: `CAPTURE_RATE_MAX_PER_IP=30`, `CAPTURE_RATE_MAX_PER_TOKEN=10`, window 60 s. Hash-only token storage (sha-256; plaintext returned once at mint; never in audits).

### 8.7 Probe scripts left behind (read-only, reproducible)

`tmp-scripts/p4-a3-orgb-probe.ts`, `p4-a3-org-check.ts`, `p4-a3-amine-scope-probe.ts`, `p4-a3-fieldrep-scope-probe.ts`, `p4-a3-task-scope-probe.ts`, `p4-a3-lockout-state.ts`, `p4-a3-audit-trail.ts`, `p4-a3-audit-failures.ts` — all Prisma/`bun:sqlite` read-only (`readonly: true` / selects only).

### 8.8 State restoration confirmation

- lina: 2 failed logins → successful login (window cleared, 0 rows).
- mounia: 2 failed logins → successful login (window cleared).
- amine: revoke-all → re-logged-in (P-21).
- No records created/modified by this agent (dev.log: this session's POST /api/leads = 403 + 400 only; the "P4-AUDIT- Test Lead" belongs to a parallel agent's earlier run).
- Residual (by design, auto-expiring): 2 LoginFailure rows for a nonexistent probe email (swept after 1 h); audit rows listed in §8.4; valid sessions for sarah/amine/karim/lina/mounia (7-day dev cookies, jars in /tmp only).

---

*End of P4-3 Security Acceptance. Agent 3, 2026-11-06.*
