# MIGRATIONS AND SCHEMA

This document states the migration law of ASAS CRM — which file is the
authoritative schema, how the two migration chains relate to it, how the
PostgreSQL variant and chain are regenerated, the settled type decisions,
how migrations are tested, and how to recover from failures. It extends
`05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md` (the schema's decision history) and
is the reference quoted by `README.md` and `CONTRIBUTING.md`.

## 1. The single-source-of-truth law

**`prisma/schema.prisma` (SQLite provider) is the AUTHORITATIVE model
definition.** It has exactly two renderings:

| Chain | Path | Provider | Role |
|---|---|---|---|
| SQLite chain | `prisma/migrations/` (13 migrations) | `sqlite` | Local development + CI + test batteries |
| PostgreSQL chain | `supabase/migrations/` (3 migrations) | `postgresql` | **Canonical for production / Supabase** |

Schema changes therefore follow this fixed sequence:

1. Edit `prisma/schema.prisma` (the SQLite model).
2. `bun run db:migrate` — creates + applies a new dated SQLite migration
   (`prisma/migrations/<timestamp>_<name>/`), then **restart the dev server**
   (a stale Prisma client produces 500s).
3. Regenerate the PostgreSQL variant `prisma/schema.postgres.prisma` from
   the edited SQLite schema (procedure in §3).
4. If the change is structural, extend the `supabase/migrations/` chain with
   a NEW numbered migration. **Never edit an applied migration** (§6).

## 2. The two chains

**SQLite (`prisma/migrations/`, applied by `bun run db:deploy` /
`prisma migrate dev`):**

`0_init` (full baseline) → `p4_composite_indexes` → `p8_9_schema_catchup_stage_changed_at`
→ `p11_stage_wip_limit` → `p13_finance_installments` (superseded) →
`p14_sav_cases` (superseded) → `p16_remove_sav` → `p18_crm_premium_operating_model`
→ `p20_visit_decision_lifecycle` → `p29_commercial_trust` →
`p30_duplicate_management` → `p54_two_step_closure` → `phase_c_visit_report`

**PostgreSQL (`supabase/migrations/`, applied in filename order — see
`05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md`):**

| File | Content |
|---|---|
| `20261030000001_init.sql` | Full schema baseline for all 26 tables — generated with `prisma migrate diff --from-empty --to-schema-datamodel prisma/schema.postgres.prisma --script` (Prisma 6 engine-validated DDL), curated header |
| `20261030000002_business_constraints.sql` | Closed-vocabulary CHECK constraints generated from `src/lib/constants.ts` + the reservation partial unique index |
| `20261030000003_rls_policies.sql` | RLS enable + org-scoped default-deny policies on every table |

The PostgreSQL chain is a **baseline-style rendering** of the final schema,
not a replay of the SQLite history: SQLite's incremental history includes
superseded intermediate shapes (finance installments added then removed,
SAV cases added then removed) that a fresh PostgreSQL database must never
see. Evolution AFTER the handoff baseline is always additive
(new `20261030XXXXXX_…​.sql` files — timestamped per the Supabase CLI convention).

## 3. Regeneration procedure (SQLite change → both chains)

Run after every `prisma/schema.prisma` edit + SQLite migration:

1. **Copy the schema**: `cp prisma/schema.prisma prisma/schema.postgres.prisma`
   (work from the fresh SQLite source).
2. **Switch the datasource** in `prisma/schema.postgres.prisma`:
   `provider = "postgresql"` (keep `url = env("DATABASE_URL")`).
3. **Annotate every `DateTime` field** with `@db.Timestamptz(3)` — including
   `@default(now())` / `@updatedAt` columns (Supabase best practice; the
   Prisma client reads/writes JS `Date` identically either way).
4. **Change nothing else.** Enums stay `String` (no Prisma-native enums —
   ADR-001), money stays `Float` (→ `DOUBLE PRECISION`), JSON payload columns
   stay `String` (→ `TEXT`). Keep the variant header comment intact.
5. **Generate the DDL for the structural delta** — diff the PREVIOUS variant
   (before your edit) against the new one:
   `bunx prisma migrate diff --from-schema-datamodel <old prisma/schema.postgres.prisma> --to-schema-datamodel prisma/schema.postgres.prisma --script` —
   or, for a fresh baseline, `--from-empty`. Curate the output into a NEW
   numbered `supabase/migrations/000N_*.sql` file with a provenance header
   (see `0001`/`0002` headers for the house style).
6. If a closed vocabulary in `src/lib/constants.ts` changed, add the matching
   CHECK-constraint migration (new `ALTER TABLE … ADD CONSTRAINT` /
   `DROP CONSTRAINT` statements) — never edit `0002` in place.
7. `bunx prisma generate` + `bun run lint` + `bun run typecheck`.

Conventions carried by every generated migration (see `20261030000001_init.sql`
header): PascalCase quoted identifiers everywhere; TEXT cuid ids (no
sequences); `TIMESTAMPTZ(3)` timestamps; `DOUBLE PRECISION` money; TEXT
enum-like columns with CHECKs in `0002`; JSON payloads as TEXT.

## 4. Type-decision records (settled — owner decisions required to change)

| Decision | Choice | Rationale |
|---|---|---|
| **Money** | `Float` → `DOUBLE PRECISION` | A semantics-preserving port of the owner-approved financial models (commission/incentive calculations). A `NUMERIC(14,2)` upgrade is a documented FUTURE owner decision — changing decimal semantics changes financial calculations. Recorded in `CONTRIBUTING.md` ground rule 7 and `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md`. |
| **Timestamps** | `TIMESTAMPTZ(3)` in the PostgreSQL chain | Supabase best practice; the client round-trips JS `Date` unchanged. |
| **JSON payloads** (`Activity.meta`, `AuditLog.before/after`, `Document.analysis`, `SavedSearch.filters`, `OrgSetting.value`, `PropertyMatch.reasons`) | Stay `TEXT` | Exact client-contract parity — the app `JSON.parse`/`stringify` round-trips these strings; a JSONB column would return parsed objects and break the client contract. JSONB is a documented future decision, not taken. |
| **Enums** | `TEXT` + CHECK constraints (`0002`) | ADR-001, the Enum-as-String law: the shared closed vocabularies in `src/lib/constants.ts` feed the UI selects, the zod validation, the seed AND the DB CHECKs — one source, never re-declared. No Prisma-native enums ⇒ client types unchanged across providers. |
| **Reservation apartment exclusivity** | Partial unique index: `CREATE UNIQUE INDEX "Reservation_apartmentId_active_key" ON "Reservation"("apartmentId") WHERE "status" IN ('ACTIVE','CLOSURE_REQUESTED')` | The documented PostgreSQL backstop (SQLite/Prisma could not express it). The interactive transactional guard in `src/lib/server/reservation-lifecycle.ts` stays the OPERATIVE enforcement (D-008); the index only blocks ACTIVE/CLOSURE_REQUESTED double-booking — EXPIRED/CANCELLED/CONVERTED rows never block re-booking. |

## 5. How migrations are tested

| Chain | Coverage | Honest limits |
|---|---|---|
| SQLite | CI (`.github/workflows/ci.yml`): `prisma migrate deploy` on a fresh DB + `bun run db:seed` + `python3 scripts/validate-seed.py supabase/seed.sql`. Replay from empty is exercised on every PR. | The full HTTP probe batteries run in the engineering environment, not CI (`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/TEST_STRATEGY.md`). |
| PostgreSQL | `0001` is Prisma-engine-generated DDL (engine-validated syntax); `supabase/seed.sql` passes the structural validator (parse + FK closure + row-level emission order + canonical counts). | **Runtime execution on a live PostgreSQL was NOT possible in the packaging environment** (no Docker/PostgreSQL). The chain's first live run happens on the owner's Supabase project (`05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` §9). |

## 6. Recreating the database from scratch

**SQLite (local dev):**

```bash
cp .env.example .env          # DATABASE_URL=file:./db/custom.db
bun install
bunx prisma generate
bun run db:deploy             # applies the 13-migration chain
bun run db:seed               # synthetic roster (idempotent)
# or the one-shot equivalent:
bun run db:reset              # drop + migrate + seed
```

**PostgreSQL (Supabase):** create a fresh project, apply
`supabase/migrations/0001 → 0002 → 0003` in order, run `supabase/seed.sql`
(or switch the provider first and `bun run db:seed`). Full walkthrough with
verification queries: `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md`.

## 7. Migration failure recovery

- **Never edit an applied migration** — applied files are immutable history;
  editing one creates drift between every database that already ran it.
- **Additive-only policy**: fixes and changes ship as NEW migrations
  (`ALTER … ADD`, new tables/indexes/constraints). Destructive statements
  require an explicit owner decision (precedent: `p16_remove_sav`, which
  combined data + DDL in one migration by recorded decision D-024).
- **Rollback = a new forward migration** that reverses the effect. There is
  no down-migration concept in either chain.
- A SQLite migration that failed mid-apply: the journal tracks the failed
  entry; fix the cause, then `bunx prisma migrate resolve --rolled-back
  <name>` before re-running `bun run db:migrate`.
- A PostgreSQL chain step that failed mid-paste (SQL editor): the Supabase
  SQL editor runs each paste as a single transaction — a failed paste leaves
  no partial state; fix the cause and re-run the whole file. If you used the
  CLI, `supabase migration repair` can mark a failed entry.
- The sandbox escape hatch `bunx prisma db push --accept-data-loss` (SQLite
  only) is destructive and creates migration drift — it exists for
  fast-iteration emergencies and requires re-baselining afterwards; it is
  not an npm script on purpose.
