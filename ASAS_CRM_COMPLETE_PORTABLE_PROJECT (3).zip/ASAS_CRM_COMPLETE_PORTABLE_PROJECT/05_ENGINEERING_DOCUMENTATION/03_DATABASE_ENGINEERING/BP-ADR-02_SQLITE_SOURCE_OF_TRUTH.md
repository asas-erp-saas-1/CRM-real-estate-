# BP-ADR-02 — SQLite Is the Authoritative Runtime Database

**Status:** ACCEPTED (formalized 2026-11-03, P0-6 — codifying the standing architecture decision)
**Scope:** database architecture, migration governance, deployment contracts.

## Decision

**SQLite is the single authoritative runtime database** for ASAS CRM until an
explicit, owner-approved migration trigger fires. The active database is
`db/custom.db`, created and evolved exclusively through the canonical Prisma
migration chain (`prisma migrate deploy`), seeded by `prisma/seed.ts`.

Supabase/PostgreSQL is a **dormant, unvalidated parallel architecture**:
zero active Supabase imports in `src/`, a dormant PostgreSQL schema rendering
(`prisma/schema.postgres.prisma`), and a dormant SQL migration/seed mirror
(`supabase/`). No runtime integration exists or is claimed.

## Rationale

- The application's entire invariant chain (org scoping, transactional audit
  folds, partial live-hold indexes, busy-timeout behavior — see the P0 reports)
  is verified against SQLite.
- The workload shape (single agency, low concurrency, one app server) fits
  SQLite with the engine-managed `busy_timeout=5000` (P0-2).
- A dual-database architecture with unverified parity is a correctness hazard:
  partial indexes, transaction semantics, and JSON handling differ across
  engines.

## Migration application law

| Command | Role |
|---|---|
| `bun run db:migrate:deploy` | the ONLY way migrations are applied (testing/staging/production AND the sandbox) |
| `bun run db:migrate:status` | bookkeeping verification — must read "up to date" (18 applied today) |
| `bun run db:seed` | synthetic demo roster (idempotent — only seeds when no users) |
| `bun run db:generate` | Prisma client generation |
| `bunx prisma migrate dev` | migration AUTHORING only — against a **scratch database**, never the shared/active one; produces reviewable SQL committed to the chain |
| `bun run db:push` | schema prototyping convenience only — NEVER a deployment mechanism; never a substitute for the chain |
| `bun run db:reset` | destructive local scratch reset — forbidden against the shared/active database |

There is deliberately **no generic `db:migrate` script** (removed by P0-6): it
aliased `migrate dev`, and an alias that can demand a reset or mutate history
must not be one keystroke away from the shared database. Applied migration
history is never edited.

## Future migration trigger (PostgreSQL transition)

The dormant PostgreSQL architecture may be activated ONLY when the owner
explicitly approves a migration project that includes, at minimum:

1. A stated production driver (concurrent-writer scale, managed-backup
   requirements, multi-instance deployment) that SQLite demonstrably cannot meet.
2. A complete, reviewed `supabase/migrations` chain proven equivalent to the
   SQLite chain (including the partial live-hold indexes and their semantics).
3. A data-migration plan with verified referential integrity and a rollback path.
4. Re-verification of every P0-class invariant (transactional audit atomicity,
   org isolation, concurrency behavior) against the new engine.
5. A Prisma version whose bundled/adapter SQLite (if any interim) satisfies the
   P0-2 safety findings — the WAL decision must be re-evaluated against the
   runtime actually in use.

Until all five exist and are approved, SQLite remains the source of truth and
the dormant files stay untouched (not activated, not deleted).
