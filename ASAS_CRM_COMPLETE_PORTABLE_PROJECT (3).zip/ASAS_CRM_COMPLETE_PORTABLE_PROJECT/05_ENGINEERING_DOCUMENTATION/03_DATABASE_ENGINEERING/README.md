# 03_DATABASE_ENGINEERING

**Purpose (EN):** Database architecture, migrations, Supabase setup, data dictionary.
**الغرض:** هندسة قاعدة البيانات والترحيل والقاموس.
**Documents:** 5 · **Renamed from:** `database`

| # | File | Title | Bytes |
|---:|---|---|---:|
| 1 | `BP-ADR-02_SQLITE_SOURCE_OF_TRUTH.md` | BP-ADR-02 — SQLite Is the Authoritative Runtime Database | 3,482 |
| 2 | `DATABASE_ARCHITECTURE.md` | DATABASE ARCHITECTURE | 7,125 |
| 3 | `DATA_MIGRATION_GUIDE.md` | DATA MIGRATION GUIDE (real business data) | 9,459 |
| 4 | `MIGRATIONS_AND_SCHEMA.md` | MIGRATIONS AND SCHEMA | 9,835 |
| 5 | `SUPABASE_SETUP.md` | SUPABASE SETUP | 11,923 |

--- Part of `ASAS_CRM_COMPLETE_PORTABLE_PROJECT/05_ENGINEERING_DOCUMENTATION` — see root `README.md` for the master index.
