# DATABASE ARCHITECTURE

Evidence: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/DATABASE_DOMAIN_AUDIT.md` (25-model audit, integrity queries, index matrix).

## Posture
SQLite single-file (`db/custom.db`, WAL) + Prisma 6. Single-writer; single-instance rate limiters acceptable at this scale (D-002). Schema source of truth: `prisma/schema.prisma`; **migrations baseline adopted (Phase 1 Task 2, D-014)** — `prisma/migrations/0_init/migration.sql` reproduces the full schema from empty (replay-validated: empty → deploy → exact schema + exact live-DB equivalence; zero drift live-vs-schema pre-baseline).

### Migration system (authoritative)
- **Fresh install**: `cp .env.example .env` (set DATABASE_URL) → `bun run db:deploy` → `bun run db:seed` (or `bun run db:reset` = drop + migrate + seed).
- **Schema evolution**: edit `prisma/schema.prisma` → `bun run db:migrate` (creates + applies a dated migration) → **restart dev server** (stale client = 500s, R10-4) → commit the migration with the schema.
- **Sandbox escape hatch**: `bunx prisma db push --accept-data-loss` (NOT in npm scripts anymore) — destructive fast-iteration only; creates migration drift, re-baseline required after use.
- **Status check**: `bunx prisma migrate status` → "Database schema is up to date!"
- `_prisma_migrations` marks `0_init` as applied on the live DB (resolve, not executed — live schema already matched exactly).

### Seed system (Phase 1 Task 4 — consolidated)
- **Single entry point**: `prisma/seed.ts` (wired via `package.json prisma.seed` → `bun run db:seed` / `prisma migrate reset`). No other seed scripts exist — `tmp-scripts/r10-seed-won.ts` was **folded in and deleted** (single source of truth).
- **Deterministic & idempotent**: full-seed guard (`db.user.findFirst()` exists → skip) + standalone won-deal guard (CLOSED_WON count > 0 → skip). Re-running against a seeded DB writes nothing (live-DB verified: all counts identical before/after).
- **Development seed = demo workspace data**: 7 users (shared demo password, D-007), org, pipeline, 4 projects / 46 apartments, 35 base leads + 7 won-deal leads with full coherent history (leads → contacts → opps CLOSED_WON → visits → CONVERTED reservations → SOLD apartments → activities + audits, backdated), targets, tags, matches. Dashboard ranges populate on a fresh install: 7d 29.3M / 30d 101.8M / 90d+all 236.2M DZD.
- **No production secrets**: only the public demo password (intentional, D-007); session secret never seeded.
- **Test fixtures**: none separate — automated tests are a Phase 4/5 roadmap item (TEST_STRATEGY.md); when they arrive they seed throwaway DBs, not this file.

## Integrity state (verified 2026-10-02)
- 0 duplicate phones/emails (org+phone unique holds in practice) · 0 orphaned activities/documents/audits · 0 reservation↔apartment contradictions · R10-2 won-deal coherence 7/7.
- Repaired this phase: AuditLog entity taxonomy ("User"→"USER", 51 rows + call-sites); N-21 ACTIVE-with-null-expiresAt → createdAt+30d; stale tmp-script tsc error.
- Open data decisions (NOT auto-fixed — business call): 7 seed-legacy apartments RESERVED/OPTIONED with no reservation row (A-21, B-11, H-12, N-11, V-03, A-31, H-21); possible duplicate lead "Mohamed Larbaoui" ×2 (different phones +213661234501 Sep-26 / +213550123456 Oct-02).

## Key decisions affecting the schema (Phase 2)
- **Reservation.apartmentId unique index REMOVED** (P2-R2): it deadlocked re-booking after EXPIRED/CANCELLED (Prisma/SQLite cannot express partial unique indexes). Double-booking is enforced transactionally (in-tx apartment-status re-read → 409 APARTMENT_NOT_AVAILABLE / ALREADY_RESERVED — both re-verified live). Migrate to a partial unique index when moving to PostgreSQL.
- **User.passwordChangedAt DateTime?** (P2-R1): stateless session invalidation — cookies carry issuedAt; `getCurrentUser` rejects cookies older than the stamp.
- **Reservation @@index([status, expiresAt])** added — powers the lazy expiry sweeper where-clause.
- Enum-as-String (ADR-001): constants.ts + zod keep values closed. Verified zero drift across all hot enums except the (now-fixed) AuditLog entity. ~~Remaining free strings~~ **P4/D-016 RESOLVED for write-side**: Requirement.payment/purpose/timeframe now zod-enum'd against shared constants (canonical set incl. BANK_LOAN/RENTAL_INVESTMENT/…); Task.priority guarded since P2-R2. Contact.type / Apartment.paymentPlan / orientation have NO write surface yet (constants reserved for when one is added — display-only today).

## Index strategy
Good coverage at current scale (R6 10k-row benchmark). **P4 composites APPLIED** (migration `20261003020538_p4_composite_indexes`): Task(orgId,status,dueAt) · Visit(orgId,status,scheduledAt) · Reservation(orgId,status,expiresAt) · Opportunity(orgId,stage,closedAt) · AuditLog(orgId,action) — the three orgId+X single-column indexes they prefix-cover were dropped. Audit undo-scan (LEADS_IMPORT_UNDONE take 500, app-side parse) is O(org audit rows)/page-load — fine today, watch at 10×. **P13 finance** (migration `20261008022052_p13_finance_installments`): Installment @@unique([reservationId, seq]) + [orgId,status,dueAt] (bucket scans) + [orgId,dueAt] (dashboard overdue/dueSoon windows); Payment [orgId,paidAt] (ledger/monthly collections) + [installmentId]. Derived-overdue means no sweeper and no stored state — the collections windows read live rows only (D-022 law 1).

## Migration history (Phase 1 — settled)
~~Current `db:push --accept-data-loss` can silently drop columns/tables~~ **RESOLVED**: baseline `0_init` committed and replay-validated (D-014); `db:push` npm script no longer carries `--accept-data-loss`; the flag survives only as a documented manual escape hatch. R10-4 stale-Prisma-client 500s remain a restart-discipline lesson (unchanged). Won-deal seeding folded into `prisma/seed.ts` (Phase 1 Task 4).

**Phase 4 additions**: `20261003020538_p4_composite_indexes` (CREATE/DROP INDEX only). Operational note: the environment-restored DB had lost its `_prisma_migrations` bookkeeping — `migrate resolve --applied 0_init` (bookkeeping only) precedes any `migrate dev` on a restored DB. Enum closure D-016: seed canonical (FAMILY→PRIMARY_RESIDENCE etc.); no data migration needed (fresh-seed path).

**Later migrations**: `p8_9_schema_catchup` · `p11_stage_wip_limit` · `p13_finance_installments` (**superseded**) · `p14_sav_cases` (**superseded**) · `p16_remove_sav` (**D-024**: SAV removal — data+DDL in one migration) · `p18_crm_premium_operating_model` (**2026-10-09, D-025**: DELETEs PAYMENT activities + INSTALLMENT/SALES_TARGET audits, reassigns removed-role users (MARKETING→FIELD_REP), DROPs `Installment`/`Payment`/`SalesTarget`, CREATEs `ProjectAssignment` (unique [projectId,userId] + cascades), adds `Visit.confirmedAt/confirmedById` (Visit table-rebuild) + `Reservation.commissionAmount/commissionFrom/agentIncentive` + the `[orgId,agentId]` incentive index — the p16 authoring pattern: `migrate diff --script` engine DDL + manually prepended data statements).
