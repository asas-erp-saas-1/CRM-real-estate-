# DATA MIGRATION GUIDE (real business data)

This document defines the controlled pipeline for migrating the owner's REAL
business data into an ASAS CRM deployment — the operation the handoff was
asked to perform and could not (see status below). It specifies the required
18 steps, the non-negotiable data-integrity rules, and the reconciliation
census. The seed-generation tooling shipped in `scripts/` is the working
pattern for the import mechanics: same shape, different (real) source.

## Status: BLOCKED

The authoritative business-data source **does not exist in the packaging
environment**: `db/custom.db` is empty (0 rows across 26 tables) and carries
no `_prisma_migrations` bookkeeping (the full 13-migration chain reports
unapplied); no other verified authoritative source is present. Real-data
migration therefore CANNOT start. Full report and the required unblocking
action: `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/DATA_EXPORT_BLOCKED.md`.

What IS provided instead: the synthetic seed (511 rows, `supabase/seed.sql`
/ `prisma/seed.ts`), the import tooling pattern
(`scripts/generate-seed-sql.ts` + `scripts/validate-seed.py`), and this
pipeline specification.

## Rules (non-negotiable)

1. **Never skip records silently.** Every source row is either imported,
   explicitly excluded with a recorded reason, or the migration stops.
2. **Never invent values.** Empty source fields stay empty (`NULL`), or the
   exclusion rule fires. No fabricated names, phones, amounts or dates.
3. **Never fabricate visit reports or attribution.** If the source has no
   qualifying visit-report data, opportunities stay in their true stage —
   the server-side closure gate (`src/lib/server/visit-gate.ts`) must remain
   satisfiable only by real data. Actor stamps (`reportedById`,
   `confirmedById`, `agentId`, `actorId`) must reference real imported users.
4. Money values pass through **unchanged** — no rounding, no currency
   conversion (the source must already be DZD amounts; DOUBLE PRECISION
   port, see `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md` §4).
5. Closed vocabularies (statuses, stages, roles, sources…) must map onto the
   exact values in `src/lib/constants.ts` — unmappable values stop the
   migration (extend the mapping decision, never coerce silently).
6. The pipeline runs against a **dedicated test target first**; production
   import happens only after every check passes there.

## The 18-step controlled pipeline

| # | Step | Output / gate |
|---|---|---|
| 1 | Owner identifies + authorizes the authoritative source (production backup or pre-wipe database) and grants READ-ONLY access | written authorization, source snapshot reference |
| 2 | Safety snapshot of the source (file copy + checksum) before anything else | checksum recorded; source verified untouched |
| 3 | Read-only source inspection: schema, table list, column types, row samples — no mutating command, ever | source schema inventory |
| 4 | Table inventory: map every source table → target model (`prisma/schema.prisma`) or explicit "not migrated + reason" | field-mapping draft |
| 5 | Row counts + null-rate census per table on BOTH source and target | the count baseline for reconciliation |
| 6 | Field mapping specification: every target column's source expression, transformation, default; review + owner sign-off | signed mapping document |
| 7 | Vocabulary reconciliation: source enum values → `src/lib/constants.ts` values (exact matches; unmapped ⇒ stop) | mapping table, zero unmapped |
| 8 | ID preservation decision: keep original ids where collision-free (the seed pattern keeps cuids), else a recorded id map | id-mapping table (if any) |
| 9 | Transformation script: read source → emit PostgreSQL INSERTs with SQL-literal escaping, in FK-safe order (pattern: `scripts/generate-seed-sql.ts`) | generated import SQL |
| 10 | Dependency-aware import order: parents before children (the ORDER table in `generate-seed-sql.ts` — note `Reservation` precedes `Activity` because seeded activities reference reservations) | ordered import file(s) |
| 11 | Structural validation WITHOUT a runtime: parse every INSERT, FK closure over the row set, row-level emission order, counts vs the §5 census (pattern: `scripts/validate-seed.py`) | validator exit 0 |
| 12 | Reconciliation counts: import census vs source census, table by table; every delta explained | reconciliation sheet, zero unexplained deltas |
| 13 | Business-rule validation: FK orphans, duplicate phones/emails, reservation↔apartment status coherence, won-deal economics coherence, ACTIVE-reservation apartment exclusivity (the partial unique index will enforce this at import time) | integrity query results |
| 14 | Dry-run: apply the import SQL to a THROWAWAY database (fresh `supabase/migrations` chain), run the full census + integrity queries | dry-run report |
| 15 | Execution on the dedicated TEST target (separate Supabase project — never production) + post-import checks: census, integrity queries, app-level smoke (login, list reads, a scoped detail 404 probe) | test-target sign-off |
| 16 | Owner review of the test target against real business expectations (spot-check known deals, agents, buildings) | recorded approval |
| 17 | Production execution: identical artifacts, maintenance window, fresh-chain target, census + integrity re-run | production census report |
| 18 | Rollback strategy + sign-off: pre-import backup of the production target, documented restore procedure, post-go monitoring window | closed migration record |

## The tooling pattern (shipped, working)

- `scripts/generate-seed-sql.ts` — reads a seeded SQLite database and emits
  `supabase/seed.sql`: PostgreSQL INSERT statements with original ids (every
  FK relation survives), SQL-literal escaping, FK-safe table order, and
  safe-to-ship scrypt hashes of the documented demo password. For a REAL
  migration, clone this script against the authorized source and re-derive
  the order/mapping — never point it at a production database for
  "regeneration".
- `scripts/validate-seed.py` — the structural validator (no PostgreSQL
  needed): INSERT parsing (column count == value count), FK closure, strict
  row-level emission order, canonical counts. Exit code 0 = pass. It is
  wired into CI (`.github/workflows/ci.yml`) for the synthetic seed.

## Reconciliation census queries (PostgreSQL target)

```sql
SELECT
  (SELECT count(*) FROM "Organization")   AS orgs,           -- synthetic reference: 1
  (SELECT count(*) FROM "User")           AS users,          -- 8
  (SELECT count(*) FROM "Pipeline")       AS pipelines,      -- 1
  (SELECT count(*) FROM "PipelineStage")  AS stages,         -- 10
  (SELECT count(*) FROM "Tag")            AS tags,           -- 7
  (SELECT count(*) FROM "Developer")      AS developers,     -- 3
  (SELECT count(*) FROM "Project")        AS projects,       -- 4
  (SELECT count(*) FROM "Building")       AS buildings,      -- 6
  (SELECT count(*) FROM "Apartment")      AS apartments,     -- 46
  (SELECT count(*) FROM "Lead")           AS leads,          -- 43
  (SELECT count(*) FROM "LeadTag")        AS lead_tags,      -- 26
  (SELECT count(*) FROM "Contact")        AS contacts,       -- 20
  (SELECT count(*) FROM "Requirement")    AS requirements,   -- 14
  (SELECT count(*) FROM "Opportunity")    AS opportunities,  -- 21
  (SELECT count(*) FROM "PropertyMatch")  AS matches,        -- 3
  (SELECT count(*) FROM "Visit")          AS visits,         -- 23
  (SELECT count(*) FROM "VisitApartment") AS visit_units,    -- 41
  (SELECT count(*) FROM "Task")           AS tasks,          -- 18
  (SELECT count(*) FROM "Reservation")    AS reservations,   -- 8
  (SELECT count(*) FROM "Activity")       AS activities,     -- 161
  (SELECT count(*) FROM "ProjectAssignment") AS assignments; -- 3
SELECT (SELECT count(*) FROM "AuditLog")   AS audit_logs;    -- 44
```

(The right-hand numbers are the SYNTHETIC seed reference values — 511 rows
total, asserted by `scripts/validate-seed.py`. For a real migration, replace
them with the source census from step 5 and reconcile every table.)

Integrity spot checks (adapted from the engineering audit batteries):

```sql
-- orphaned activities must be 0
SELECT count(*) FROM "Activity" a
WHERE (a."leadId"     IS NOT NULL AND NOT EXISTS (SELECT 1 FROM "Lead" l WHERE l."id" = a."leadId"))
   OR (a."taskId"     IS NOT NULL AND NOT EXISTS (SELECT 1 FROM "Task" t WHERE t."id" = a."taskId"));

-- apartment/reservation contradictions must be 0
SELECT count(*) FROM "Apartment" ap
WHERE ap."status" = 'RESERVED'
  AND NOT EXISTS (SELECT 1 FROM "Reservation" r
                  WHERE r."apartmentId" = ap."id" AND r."status" IN ('ACTIVE','CLOSURE_REQUESTED'));

-- every org-owned row carries the org id
SELECT count(*) FROM "Lead" WHERE "orgId" IS NULL;
```

## Related documents

- `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/DATA_EXPORT_BLOCKED.md` — why this pipeline is blocked today
- `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` — fresh-chain + seed application
- `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md` — schema law and type decisions
- `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md` — schema decision history + the
  known open data decisions in the synthetic seed (documented, not auto-fixed)
