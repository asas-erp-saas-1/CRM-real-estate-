# SUPABASE SETUP

This document walks the repository owner through creating a Supabase
PostgreSQL project for ASAS CRM, applying the canonical PostgreSQL migration
chain (`supabase/migrations/`), loading the synthetic demo seed, and pointing
the application at the database. Follow it top to bottom. Where a step could
not be runtime-validated in the packaging environment, it says so explicitly
(see §9) — the SQL itself is engine-generated and structurally validated, but
its execution against a live Supabase project is the owner's first-run
responsibility.

## 1. Prerequisites

| Requirement | Notes |
|---|---|
| Supabase account + project | https://supabase.com — any paid tier or the free tier |
| Database password | Set at project creation; used in `DATABASE_URL` |
| Supabase CLI (optional) | Only for Option A (`supabase db push`) — https://supabase.com/docs/guides/cli |
| Docker (optional) | Only for Option C (local `supabase start` dev stack) |
| Bun ≥ 1.1 (or Node 20+) | For the Prisma-based seed path and local dev |

## 2. Create the Supabase project

1. Create a **new project** in the Supabase dashboard (choose a region close
   to your users; note the generated project ref, e.g. `abcdefghijklm`).
2. Set a strong **database password** and store it in your password manager —
   it is the password in `DATABASE_URL` below.
3. Wait for the project to finish provisioning (the dashboard shows
   "Health status: awaiting database" until ready).

Nothing else is configured in the dashboard at this point — Supabase Auth,
Storage and Edge Functions are **not used by the application today**
(auth is the app's own HMAC session layer; see
`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md`).

## 3. Apply the migration chain (in order)

Apply the three files from `supabase/migrations/` **in this exact order**:

| # | File | What it does |
|---|---|---|
| 1 | `20261030000001_init.sql` | Full schema baseline (26 tables, FKs, indexes) — Prisma-engine-generated DDL |
| 2 | `20261030000002_business_constraints.sql` | Closed-vocabulary CHECK constraints + the reservation double-booking partial unique index |
| 3 | `20261030000003_rls_policies.sql` | Row Level Security: enable + org-scoped default-deny policies on every table |

### Option A — Supabase CLI (recommended)

```bash
supabase login
supabase link --project-ref <your-project-ref>
supabase db push --dry-run   # print what would run — verify the chain first
supabase db push             # applies supabase/migrations/*.sql in filename order
```

`supabase db push` picks up the files under `supabase/migrations/`, records
them in the `supabase_migrations.schema_migrations` table, and re-running it
later is a no-op for already-applied files. Note (honest caveat): the
official docs show timestamp-prefixed filenames; this chain uses sequence
prefixes (`0001_…`, `0002_…`, `0003_…`). Filename-order application is the
documented behavior, but the prefix shape could not be runtime-verified in
the packaging environment — the `--dry-run` step above is the check. If the
CLI ever rejects the prefixes, rename to timestamped prefixes in one commit
(never edit the file contents). Never edit the remote schema by hand after
using `db push` — it breaks the sync bookkeeping.

### Option B — SQL editor paste (no CLI)

In the Supabase dashboard open **SQL Editor → New query**, paste the FULL
content of `supabase/migrations/20261030000001_init.sql`, run it, confirm success, then
repeat for `20261030000002_business_constraints.sql` and finally `20261030000003_rls_policies.sql`.
Do not run them out of order and do not skip the RLS migration — it is part
of the canonical chain, not an optional hardening step.

### Option C — local development stack (Docker)

```bash
supabase start             # boots Postgres + local services per supabase/config.toml
supabase db reset          # fresh database + applies migrations + runs seed.sql
```

The local stack applies `supabase/migrations/` **and** `supabase/seed.sql`
automatically. The app then connects with
`DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:54322/postgres`.
NOTE: `supabase/config.toml` was authored for the handoff package and was
**not runtime-validated in the packaging environment** (no Docker there);
validate with `supabase start` on a Docker-capable machine before relying on
the local stack.

## 4. Verify the schema

Run these in the SQL editor after applying the chain:

```sql
-- 26 tables expected
SELECT count(*) FROM pg_tables WHERE schemaname = 'public';

-- RLS enabled on every table (expect 26 rows, all true)
SELECT relname, relrowsecurity FROM pg_class
WHERE relnamespace = 'public'::regnamespace AND relkind = 'r';

-- the reservation partial unique index exists
SELECT indexdef FROM pg_indexes
WHERE indexname = 'Reservation_apartmentId_active_key';

-- CHECK constraints from 0002 exist (spot check)
SELECT conname FROM pg_constraint WHERE conname = 'User_role_domain';
```

All tables are empty at this point (`SELECT count(*) FROM "User"` → 0).

## 5. Load the seed

Two interchangeable paths produce the same data (the synthetic demo roster —
fictional personas, fake `+213` phones, `@asas.dz` users, scrypt hashes of
the documented demo password `asas1234`; 511 rows total).

### Path 1 — run `supabase/seed.sql` (SQL editor or psql)

Paste/run the full content of `supabase/seed.sql` (a single transaction,
FK-safe order, original cuid ids preserved). Then verify with the census:

```sql
SELECT
  (SELECT count(*) FROM "Organization")  AS org,          -- 1
  (SELECT count(*) FROM "User")          AS users,        -- 8
  (SELECT count(*) FROM "Project")       AS projects,     -- 4
  (SELECT count(*) FROM "Apartment")     AS apartments,   -- 46
  (SELECT count(*) FROM "Lead")          AS leads,        -- 43
  (SELECT count(*) FROM "Opportunity")   AS opportunities,-- 21
  (SELECT count(*) FROM "Visit")         AS visits,       -- 23
  (SELECT count(*) FROM "Reservation")   AS reservations, -- 8
  (SELECT count(*) FROM "Activity")      AS activities;   -- 161
```

Full expected counts are asserted by `scripts/validate-seed.py`
(`EXPECTED_COUNTS`) — the same census is listed in
`05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATA_MIGRATION_GUIDE.md`.

### Path 2 — Prisma seeding (requires §6 first)

After switching the provider (§6) and setting `DATABASE_URL` (§7):

```bash
bun install
bun run db:seed        # prisma/seed.ts — idempotent (skips if users exist)
```

## 6. Switch the Prisma provider to PostgreSQL

`prisma/schema.prisma` ships with the SQLite provider (local-dev default).
For Supabase deployments, replace it with the maintained PostgreSQL variant:

```bash
cp prisma/schema.postgres.prisma prisma/schema.prisma
```

`prisma/schema.postgres.prisma` is the same 26-model definition rendered for
PostgreSQL (provider `postgresql`, every `DateTime` annotated
`@db.Timestamptz(3)`). Do NOT hand-edit a mixed copy — the variant is
regenerated from the SQLite source by a documented procedure
(`05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md` § "Regeneration procedure").

## 7. Set `DATABASE_URL`

Get the connection string from **Project Settings → Database → Connection
string → URI**. For serverless hosts (Vercel) use the **Session Pooler**:

```
postgresql://postgres.<project-ref>:<password>@aws-0-<region>.pooler.supabase.com:5432/postgres
```

Guidance:

| Deployment shape | Connection | Why |
|---|---|---|
| Serverless / Vercel | **Session Pooler** (pooler hostname, port `5432`) | Serverless functions churn connections; the pooler absorbs that. This is the format shown in `.env.example`. |
| Long-lived server (self-hosted `node .next/standalone/server.js`) | Direct connection `db.<project-ref>.supabase.co:5432` (requires IPv6 support) or the pooler | Direct connections resolve to IPv6, which many hosts lack — prefer the pooler unless you know otherwise. |
| Local CLI stack (Option C) | `postgresql://postgres:postgres@127.0.0.1:54322/postgres` | `supabase start` default |

The pooler/service connection used by the app **bypasses RLS** (table owner
semantics; `20261030000003_rls_policies.sql` deliberately does not `FORCE` RLS) — the
application layer is the operative enforcement boundary. See
`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md`.

Pooling-mode note: this guide follows `.env.example` and recommends the
**Session Pooler** (port `5432`) — IPv4-friendly and prepared-statement
compatible. Prisma's own Supabase guide instead recommends the transaction
pooler (`:6543` + `?pgbouncer=true`) for serverless runtimes; both patterns
are legitimate and the choice is recorded (with sources) in
`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/PLATFORM_HANDOFF_RESEARCH.md` §2. If you hit
prepared-statement errors under heavy serverless load, switch
`DATABASE_URL` to the transaction-mode pooler URL.

## 8. Generate the Prisma client

```bash
bunx prisma generate
```

No database is required for this step. Then start the app
(`bun run dev` locally, or deploy per `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md`)
and log in with a seeded account (e.g. `sarah@asas.dz` / `asas1234` — the
documented demo password; rotate it before real use).

## 9. Runtime validation status (honest note)

The PostgreSQL migration chain was **structurally validated only**:
`20261030000001_init.sql` is Prisma-engine-generated DDL
(`prisma migrate diff --from-empty --to-schema-datamodel
prisma/schema.postgres.prisma --script`), and `supabase/seed.sql` passed the
`scripts/validate-seed.py` validator (parse + FK closure + emission order +
canonical counts). **Runtime execution against a live PostgreSQL was NOT
possible in the packaging environment** (no Docker, no PostgreSQL). First
application of the chain on a real Supabase project is the owner's
validation gate — if any statement fails, capture the exact error and see §10.

## 10. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `relation "Organization" does not exist` | `20261030000001_init.sql` not applied, or applied to the wrong database/schema. Re-run §3 in order. |
| Seed fails with a foreign-key violation | `supabase/seed.sql` was split/pasted partially, or run before `0001`/`0002`. Run it whole, after the chain. |
| `CHECK constraint violated` on seed or app writes | A vocabulary evolved — the app's `src/lib/constants.ts` and the CHECK lists in `0002` must stay in sync; extend with a NEW migration (never edit `0002`). |
| Login fails with `P1001` (can't reach database) | Wrong `DATABASE_URL`, wrong port (pooler vs direct), or the project is paused. |
| `too many connections` | You are using the direct connection from serverless functions — switch `DATABASE_URL` to the Session Pooler (§7). |
| Queries return 0 rows although data exists | You are connected as a non-owner role subject to RLS without an `org_id` claim. The app must connect via the pooler/service connection (which bypasses RLS). |
| Prisma client errors after provider switch | Re-run `bunx prisma generate` and restart the dev server (stale client = 500s). |
| `supabase db push` wants to "revert" or reports drift | The remote database has objects outside the chain (e.g. leftovers from an aborted paste). Inspect with `supabase db diff`, or recreate the project cleanly. |

## 11. Next steps

- Application hosting: `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md`
- Environment variables: `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md`
- Production security checklist (demo mode, secrets, password rotation):
  `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md` § "Demo mode" and
  `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_HARDENING.md` § "Production checklist".
