# ASAS CRM — Phase 6 Final Readiness Gate

**Gate authority:** Principal Engineering Lead, Phase 6 · **Date:** 2026-11-07
**Evidence basis:** six-agent execution (P6-T1…T6) + Principal integration, independent reproduction
of every critical result, full regression 884/884, and live production-mode runtime evidence from
the in-sandbox staging twin — all recorded under `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/` this session.
**Decision rule:** verdict from evidence; a gate that requires an external resource that does not
exist is BLOCKED, never PASSED; a fixed defect is a fixed defect only with a regression guard and a
green full suite.

---

## 1. Gates A–G (mission §7)

| Gate | Outcome | Key evidence |
|---|---|---|
| **A — Production Build** | **PASS (in-sandbox twin)** — first-ever production build executed: exit 0, ~73 s, standalone 99 MB incl. Prisma engine; standalone boot in production mode; health gate jq PASS; no critical startup errors; actual build + runtime logs captured. Docker-image-build leg = BLOCKED (no daemon — external). | a1-deploy/02–03, 08; a4-ci/05 |
| **B — Hosting & Persistence** | **PASS (single-node model, file-level)** — persistent DB + document storage verified byte-stable across process replacement (≥5 restarts, sha256-identical); memory/disk measured (runtime 129–150 MB vs 4g limit); no serverless assumptions. Container/volume replacement leg = BLOCKED (no Docker — external); compose parity table validated against measured reality. | a2-db/04; a1-deploy/10–11 |
| **C — Production Security Posture** | **PASS** — demo mode OFF (quick-login 403 DEMO_MODE_DISABLED); stable secret configured (never printed); Secure/HttpOnly/SameSite cookies; production seed blocked (exit 1, zero writes); role privacy server-side (OWN+POOL, 404-ghosts); live cross-org isolation; forged/expired/revoked sessions 401; zero secret leakage in logs. | a3-security/01–09; a1-deploy/05–07 |
| **D — Database & Recovery** | **PASS** — migrations 25/25 on 3 fresh DBs; integrity quick_check ok; FK check clean; backup created (VACUUM INTO + manifest + sha256); restore drill byte-identical + census-exact, original untouched; persistence across replacement proven. | a2-db/01–05 |
| **E — CI/CD** | **PASS locally / BLOCKED remotely (external)** — full gate chain executed in a clean room (install→generate→lint→typecheck→**884/884**→production build exit 0); failure-gate proven; no secrets committed. No Git remote exists → remote execution BLOCKED with the exact owner package. | a4-ci/01–08 |
| **F — Monitoring & Operations** | **PASS locally-activated / BLOCKED externally** — health-watch LIVE: 9 alert keys with real dispatch receipts, restart detection, backup age/success, memory/disk, DB + HTTP errors; scheduler re-arms at boot. External uptime vantage + alert channel + timer activation = BLOCKED (owner checklists delivered). | a6-ops/01–08 |
| **G — CRM Functional Acceptance** | **PASS** — journeys A–I all green (lead→opp→visit→offer→reservation→payment); payment idempotency HARD GATE (replay 409, concurrent race exactly-one-wins, census arithmetic exact); role privacy; AR RTL; mobile 390; FR/EN/AR × light/dark matrix; 0 console errors; no horizontal overflow (after the P6-D1b fix, measured 0 clipped leaves). | a5-e2e/*, principal/02–05 |

**Gate summary: 5 PASS (in-sandbox) · 2 PASS-local/BLOCKED-external (E, F) · container/volume legs
of A/B BLOCKED (no Docker daemon, no staging host — external by rule, never fabricated).**

## 2. Defects found by the deployment verification itself (the phase's core yield)

| ID | Class | Severity | Impact if Phase 6 had not run | Disposition |
|---|---|---|---|---|
| P6-D1 | Build-breaking route export | CRITICAL | The Phase 5 "staging package" would have failed `docker compose build` on the real host at first attempt — invisible to tsc/lint/suite | FIXED + 2-test regression guard (route-export contract scan, all 87 routes) |
| P6-F5 | Swallowed fail-fast gate | HIGH | Misconfigured staging container would serve 500s silently; restart policy never fires | FIXED + 3-test regression guard + live exit-1 probes |
| F-CI-1 | Inert vitest memory law | HIGH (CI) | Uncapped worker storms would OOM small CI runners' dev servers nondeterministically | FIXED (top-level maxWorkers) + verified by 884/884 |
| P6-D1b | Mobile dialog clipping | MEDIUM | Silent financial-content clipping on 390 px (Gate G violation) | FIXED (CSS-only, desktop regression-checked) + measured re-verification |
| LOW residuals | — | LOW | — | Recorded, not fixed (see §5) |

## 3. Final regression (mission §8) — vs Phase 5 baseline

| Check | Phase 5 | Phase 6 | Reconciliation |
|---|---|---|---|
| Full suite | 879/879 (51 files) | **884/884 (53 files), exit 0** | +5 = the two new regression guards (+2 +3); 0 removed, 0 skipped-of-record |
| TypeScript | 0 errors | **0 errors** | — |
| Lint | 0 errors / 41 warnings | **0 errors / 42 warnings** | +1 benign warning from the P6-D1 fix, reconciled 1:1 |
| Production build | never executed | **exit 0** (clean room + twin, 5 successful builds) | gate closed |
| Migrations | 25/25 | 25/25 (3 fresh DBs) | — |
| Original DB census | seed-exact | **seed-exact (31/31 models, verified after the final run)** | F-CI-4 incident disclosed + surgically repaired (evidence a4-ci/04) |
| Browser E2E | 0 console errors (3 langs) | **0 console errors (FR/EN/AR × light/dark × desktop/mobile)** | re-verified on the production-mode twin |

## 4. FINAL VERDICT

# C — STAGING PACKAGE VERIFIED, EXTERNAL ACCESS BLOCKED

**Rationale.** Phase 6's mission was to convert "prepared but never executed" into executed
evidence. That conversion happened everywhere the environment permits: the first-ever production
build ran and passed (twice — twin and clean room); the application booted as a genuine
production-mode standalone process and passed the health/auth/persistence/security/monitoring/E2E
acceptance on a controlled twin; the full lifecycle — deploy, provision, operate, back up, restore,
restart, recover, monitor — was exercised with byte-level evidence; and the verification itself
caught and fixed one CRITICAL build-breaking defect, one HIGH swallowed-fail-fast defect, one HIGH
CI-law defect, and one MEDIUM Gate-G violation, each with a regression guard and a green 884/884
suite. What remains is exactly the external dependency set verified absent at session start and
unchanged since: **no Docker daemon, no staging host, no Git remote, no monitoring credentials,
no offsite destination** — with exact, file-accurate owner actions prepared for every one of them
(deploy §C1 procedure; CI owner package; monitoring activation checklist; systemd/offsite
checklists). Per the decision rule, gates requiring those resources are BLOCKED, not PASSED —
therefore C, not B/A: the application is verified in production mode in a controlled local
environment, but it is not "running on staging infrastructure" because none exists to run on.

**Why not the other verdicts:**
- *A:* requires all gates closed on actual staging infrastructure with a real staging URL — no host
  exists; claiming it would be fabrication.
- *B:* requires the application running in staging with only integrations incomplete — the
  sandbox twin is not owner-provisioned staging infrastructure and is not reachable at a staging
  URL by the owner; calling it "deployed in staging" would overstate reality.
- *D:* would require a critical defect remaining — none remains; every defect found this phase is
  fixed with a regression guard, and the residual register contains no CRITICAL/HIGH item.

**Percentage context (non-overriding):** engineering-side gates A–G as executable in-sandbox:
~95% complete with runtime evidence; external-host/CI/monitoring legs: 0% executable here (100%
prepared as owner actions).

## 5. Residual register (honest, carried forward)

**Environment-blocked (owner actions, exact procedures delivered):** Docker image build/run ·
staging-host deployment · container/volume replacement test on-host · remote CI execution ·
external uptime monitor + alert channel · systemd backup-timer activation · offsite backups ·
load/stress at concurrency (unchanged from Phase 4/5: sequential probes only).

**Documented LOW residuals (not fixed this phase, none staging-blocking):** `GET /api/settings`
doc-vs-code drift (SALES_AGENT read; mutation correctly 403) · route-pattern CUID_RE metrics-label
edge · 11-char API temp passwords · attribution test virgin-DB dependency (F-CI-2) · lint-warning
ratchet (42) · dialog grid-item/min-w-0 pattern audit across other dialogs (recommended sweep) ·
WAL enablement (engine bug range — carried) · email/SMS (no credentials — carried).

**Incidents (all disclosed, recovered, verified):** 1× dev-server OOM during a concurrent rebuild ·
1× F-4 seed misdirection into the main dev DB (census surgically restored to exact seed, verified
twice) · sandbox boundary-reaping of manually-started dev pipelines (documented workaround).

## 6. Authorization boundary held

No production deployment occurred (none exists). No production data was accessed or used. No
infrastructure was purchased or provisioned. No domains/DNS touched. No unknown remotes pushed.
No duplicate scheduled jobs created (registry verified empty; the mandated 15-minute webDevReview
job is armed once, by the Principal, at phase close). No secrets appear in any deliverable.

**Next phase precondition:** the owner provisions the staging host (≥8 GB) and executes
`deploy/README-STAGING.md` §C1 — at which point Phase 7 opens with the Docker legs of Gates A/B
and the host-side F/E activations.
