# ASAS CRM — Phase 6 Operational Runbook Validation

**Principal deliverable** · **Date:** 2026-11-07
**Method (per mission §9):** a runbook step is accepted only when its commands correspond to actual
files, scripts, and configuration — and, wherever safe, were EXECUTED this phase. Every procedure
below was executed against the production-mode staging twin (or the main project where the
procedure targets it), with evidence links. Destructive steps were executed only against synthetic/
disposable data. Production was never touched (none exists).

## 1. Procedure-by-procedure validation

| Runbook procedure (source doc) | Verdict | What was executed | Evidence |
|---|---|---|---|
| **Staging deployment** (deploy/README-STAGING.md §C1: build → up → health jq gate) | **EXECUTED (twin-equivalent)** | Production build (×5, final exit 0/73 s); standalone assembly per the Dockerfile runtime-stage contract; boot on :3100; health gate `dbOk==true and demoMode==false` jq assertion exit 0 | a1-deploy/02–03, 08; STAGING_DEPLOYMENT_REPORT §2 |
| **First-boot migrations** (§C4: `bun run db:deploy`) | **EXECUTED** | `prisma migrate deploy` on a fresh DB: 25/25 applied; zero users proven; `migrate status` up-to-date | a1-deploy/04 |
| **Initial OWNER provisioning** (`bun run db:owner`) | **EXECUTED** | Synthetic OWNER provisioned (random ≥12-char password, never printed); idempotent re-run → exit 1 refusal; demo password → exit 1 refusal | a1-deploy/06 |
| **Startup procedure** (twin.sh start / `node server.js`) | **EXECUTED (repeatedly)** | Boot → health ok in seconds; RSS 129–150 MB idle | a1-deploy/08 |
| **Restart procedure** (twin.sh restart / kill -TERM + restart) | **EXECUTED (≥5×)** | TERM → down → restart → healthy ~6 s; DB sha256 byte-identical; sessions survive (stateless HMAC) | a1-deploy/10, a2-db/04, principal/05 |
| **Backup procedure** (`bun run db:backup` → scripts/backup.sh) | **EXECUTED (production-mode twin)** | VACUUM INTO snapshot + manifest + sha256; source hash unchanged; manifest independently re-verified | a2-db/03 |
| **Restore procedure** (`scripts/restore.sh --drill <backup>`) | **EXECUTED** | Drill into a disposable copy: byte-identical to snapshot, integrity ok, census-exact; original provably untouched; interlock negative test → exit 2 REFUSED | a2-db/05 |
| **Monitoring procedure** (deploy/monitoring/asas-health-watch.sh + README) | **EXECUTED (live-activated)** | Healthy polling (quiet by design); 9 alert keys live-fired with real dispatch receipts (file + webhook); restart detection; stale-backup; memory/disk thresholds; DB + HTTP-error probes — all via invocation-scoped env, zero repo edits | a6-ops/01–05 |
| **Incident response** (runbook §: kill-recovery test procedure) | **EXECUTED** | Kill → restart → recovery verified; alert dispatch on downtime observed (availability CRITICAL) | a6-ops/04 |
| **Database recovery** (restore drill + census reconciliation) | **EXECUTED** | See restore row; PLUS the main-DB census restoration this phase (31/31 models == virgin seed, verified twice) | a2-db/05, a4-ci/04 |
| **Rollback procedure** | **PARTIAL (file-level verified)** | Git-based rollback = commits 91d91c3 → Phase 6 (additive only; no history rewrite); the twin's re-deploy-from-previous-build flow was exercised implicitly across 5 builds. A full staging-host rollback (compose down → previous image tag) requires the host — BLOCKED (external), commands present in README-STAGING/compose. | STAGING_DEPLOYMENT_REPORT §6 |
| **Secret rotation** | **VERIFIED (semantics) + BLOCKED (host execution)** | Session secret semantics live-verified: stateless HMAC cookies survive restarts while the secret is unchanged; logout revocation is DB-backed exact-pair; password change kills pre-change sessions (replayed cookie → 401). Rotation on the host = regenerate `ASAS_SESSION_SECRET` + restart (invalidates all sessions — the measured behavior), documented in .env.staging.example guidance. | a3-security/02 |
| **Scheduled backup activation** (deploy/systemd/asas-backup.{service,timer}) | **STATIC VERIFIED + BLOCKED (activation)** | `systemd-analyze verify` exit 0; timer/service contract consistent with the runner code; exact activation commands delivered | a2-db/06 |
| **Offsite backup** | **BLOCKED (external)** | Procedure references real files/commands; no credentials/destination exist — none invented | a2-db/06 |

## 2. Runbook corrections made necessary by Phase 6 findings

1. **Fail-fast semantics corrected in code, not just docs (P6-F5):** the runbook's "missing secret →
   the server refuses to start" now HOLDS in the real standalone runtime (exit 1) after the
   instrumentation fix. Pre-fix, a misconfigured container would have sat alive-but-unhealthy with
   `restart: unless-stopped` never firing — the exact failure mode the runbook claimed could not
   happen.
2. **Build memory guidance now measurement-anchored:** Turbopack build >2 GB RSS / webpack ~1.5 GB /
   runtime 129–150 MB steady — the ≥8 GB host recommendation and the 4g compose limit are grounded
   in twin measurements (a1-deploy/02, 08).
3. **Operational rule (from the disclosed OOM incident):** never run production builds concurrently
   with the runtime workload on memory-constrained hosts — the Dockerfile's isolated builder stage
   is the sanctioned pattern; sandbox/twin parity runs must stop companion servers first.
4. **Sandbox-side DB ops must inline `DATABASE_URL`** (F-4 hazard) — recorded in the runbook margin
   by evidence (a1-deploy F-4 note; a4-ci/04 F-CI-4 incident).
5. **Watchdog claim corrected:** the Phase 5 "Z.ai watchdog job 510835 armed" claim is void (live
   registry empty; no repo file references it). The monitoring acceptance report records the honest
   state and the recommendation: arm the health-watch on the staging host via systemd, not as a
   session-scoped Z.ai job.

## 3. Verdict

The runbooks are **operationally usable**: every procedure that can be executed without the external
staging host was executed this phase with evidence, and the two latent defects that would have made
the documented behavior FALSE at first real use (P6-D1 build-breaker, P6-F5 swallowed fail-fast)
were found and fixed. Host-dependent procedures (Docker up, systemd activation, offsite, rollback
of image tags) carry exact, file-accurate commands and are marked BLOCKED pending the owner's
staging host — none were fabricated as done.
