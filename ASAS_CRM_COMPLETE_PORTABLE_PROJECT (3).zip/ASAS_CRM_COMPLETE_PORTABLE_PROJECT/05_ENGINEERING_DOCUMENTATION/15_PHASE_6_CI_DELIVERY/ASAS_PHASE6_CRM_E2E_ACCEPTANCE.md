# ASAS Phase 6 — CRM End-to-End Acceptance (P6-T4)

**Status: DRAFT — Principal integration pending**
**Task ID: P6-T4 · Agent 5 (E2E acceptance) · Evidence dir: `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a5-e2e/`**
**Staging twin: `http://127.0.0.1:3100` — production mode, demo OFF, 25/25 migrations, dbOk:true**

> **Two sessions, honestly noted.** Session 1 executed Journeys A–F with 32 screenshots
> (00–31) plus the payment-idempotency transcript, then hit its turn limit. Session 2
> (this document's author) executed Journeys G/H/I, the cross-cutting matrix, the
> recovery check, and the objective DB census. Everything attributed to session 1 below
> was **independently re-confirmed by session 2 via the DB census** (entity counts +
> payment arithmetic), not merely trusted from screenshots. All console captures in both
> sessions are **0 bytes — zero console messages, zero page errors** at every stage.

**Actors (synthetic roster, `logs/a3-synthetic-roster.txt`):** owner.staging (OWNER),
manager.p6 (MANAGER — main session), agent-a.p6 / agent-b.p6 (SALES_AGENT — J-F).
Passwords never echoed; login inputs masked; session cookie httpOnly and never printed.

---

## 1. Journey verdicts

| # | Journey | Verdict | Evidence |
|---|---------|---------|----------|
| J-A | Lead create → assign agent-a → priority HIGH → activity timeline | **PASS** | Executed by first session; screenshots `01–06`, login `00`; independently confirmed by this session via DB census (lead `cmw6pdvw7…` CONVERTED/HIGH/owner=agent-a, LEAD_CREATED + ASSIGNMENT activities present). |
| J-B | Lead → convert → opportunity → pipeline kanban → stage gate NEW→QUALIFIED→RESERVATION → probability edit → persist-after-reload | **PASS** | Executed by first session; screenshots `07–13`; confirmed by census: 2 opportunities (`cmw6pglc0…` QUALIFIED p=15; `cmw6pi3pv…` RESERVATION p=40, value 12.5M) + STAGE_CHANGE trail. |
| J-C | Visit schedule → confirm-on-site → complete → journey view | **PASS** | Executed by first session; screenshots `14–18`; confirmed by census: visit `cmw6pjwhu…` COMPLETED + 3 VISIT activities. |
| J-D | Inventory (developer/project/building/2 apartments) → offer → confirm → convert → reservation → availability flip | **PASS** | Executed by first session; screenshots `19–23`; confirmed by census: A-101 RESERVED 12.5M, A-102 AVAILABLE 18.5M, offer CONVERTED, reservation ACTIVE. |
| J-E | Payments + idempotency HARD GATE (replay 409, concurrent race, census arithmetic) | **PASS (HARD GATE)** | Executed by first session; screenshots `24–28` + `payment-idempotency-transcript.txt`; re-confirmed by this session's census: exactly 3 payments, 2.5M+1.5M=4.0M. See §3. |
| J-F | Role privacy: agent-a sees no agent-b leads, deeplink /leads/<id> opens own lead only, agent-b sees no agent-a leads | **PASS** | Executed by first session; screenshots `29–31`. Server-side corroboration: Agent 3, `evidence/a3-security/03-role-permissions.txt`. See §4. |
| J-G | Arabic RTL desktop 1440: dashboard / leads / lead drawer / installments / pipeline, dir=rtl, DZD in Arabic | **PASS** | This session: screenshots `32–36`, console `console-AR-*.txt` (0 B), `vlm-jG-ar-visual-qa.txt`. `document.dir=rtl, lang=ar`; amounts render `2.500.000 دج`…`13 مليون دج`; paid 4.0 مليون دج correct. |
| J-H | Mobile 390x844 (MANAGER): leads cards → drawer → create lead via dialog → toast + list update → finance → overflow + touch targets | **PASS with defects** | This session: screenshots `37–44`, console `console-jH-*.txt` (0 B), `jH-touch-targets.txt`. New lead `P6-T4 SYNTHETIC Mobile Lead` +213555000077 created (census id `cmw6q1spl…`). Overflow defect D-1 found — see §5. |
| J-I | Recovery: `twin.sh restart` with live manager session → reload → still authenticated, data intact | **PASS** | This session: screenshots `50–52`, console `console-jI-post-restart.txt` (0 B). See §6. |

---

## 2. Cross-cutting matrix (6 combos)

Console-error total across all combos: **0 messages / 0 page errors** (all `console-*.txt` are 0 B).
Overflow method: `document.documentElement.scrollWidth` vs `window.innerWidth` **plus** a
per-element `getBoundingClientRect()` leaf scan (right edge > viewport, excluding leaves inside
`overflow-x:auto/scroll` containers) — the DOM-level scan was added after D-1 showed that
`body{overflow-x:hidden}` hides clipped content from the naive scrollWidth check.

| Combo | Screenshots | Console errors | Page-level overflow | Leaf-level overflow (non-scrollable) | Verdict |
|-------|-------------|----------------|---------------------|--------------------------------------|---------|
| FR · light · desktop 1440 | J-A…J-F (`00–31`) + J-I (`50–52`) | 0 | none | none (leads table scrolls internally by design) | PASS |
| EN · light · desktop 1440 | `46–47` | 0 | none (1440=1440) | none outside scrollable table (scrollW 1327>1150 in-table = by design) | PASS |
| AR (RTL) · light · desktop 1440 | `32–36` | 0 | none (1440=1440) | none | PASS (2 cosmetic notes, §5 D-3/D-4) |
| FR · light · mobile 390 | `37–44` | 0 | none (390=390) | **D-1: installment-detail dialog, 9 clipped leaves** (§5) | PASS with defect |
| AR (RTL) · light · mobile 390 | `45` | 0 | none (390=390, dir=rtl) | none | PASS |
| FR · dark · desktop 1440 | `48–49` | 0 | none (1440=1440) | none | PASS (D-5/D-6 cosmetic notes, §5) |

Matrix conclusion: **5/6 clean; 1/6 (FR light mobile) carries D-1.** Language switcher
(FR/EN/ع) works everywhere incl. login page; dark-mode toggle verified
(`html.dark`, color-scheme dark); RTL mirroring verified via `dir` attribute and VLM review.

---

## 3. Payment idempotency (J-E) — HARD GATE PASS

Source: `payment-idempotency-transcript.txt` (first session, re-confirmed by census):

- **Mechanism (read from source):** no custom key header — the idempotency key is the
  P4-L02 business fingerprint (same actor + installment + amount + method + reference +
  notes within 60 000 ms), enforced **inside the write transaction** (TOCTOU-safe).
  Pre-write lifecycle gate: money lands only on CALLED lines; PAID → `409 INSTALLMENT_ALREADY_PAID`.
- **Replay of a full payment** (2.5M TRANSFER on PAID line): `409 INSTALLMENT_ALREADY_PAID`, no write.
- **Replay of a partial payment** (identical fingerprint 6 s later): `409 DUPLICATE_PAYMENT`
  with `details.existingPaymentId` — no row created.
- **Concurrent race** (same body fired twice in parallel): exactly-one-wins —
  `201` (winner `cmw6ptgxn…`) + `409 DUPLICATE_PAYMENT` pointing at the winner's id;
  SQLite write-lock serialization.
- **Census arithmetic (re-run by session 2, `logs/a5-e2e-corpus.txt`):** payments = 3 rows
  (2 500 000 TRANSFER `VIR-P6T4-E2E-001`; 1 000 000 CHEQUE `CHQ-P6T4-E2E-002`; 500 000 CASH),
  sum = **4 000 000** = installment#1 paid 2 500 000 + installment#2 paid 1 500 000.
  Finance KPIs after all retries: Échéancier 13M · Appelé 13M · Encaissé **4.0M** ·
  Reste 8.5M — retries moved nothing (screenshot `28`, re-seen in `43`/`52`).

**Verdict: exactly-once payment semantics hold under replay and race.**

---

## 4. Role privacy (J-F)

- agent-a's Leads list contains **no agent-b-owned lead** (`29`); agent-b's list contains
  **no agent-a-owned lead** (`31`); agent-b deep-linking to **his own** lead id opens it (`30`).
- Server-side corroboration (Agent 3, independent session): `evidence/a3-security/03-role-permissions.txt`
  — SALES_AGENT scoping enforced in API layer, not just UI filtering.
- Census note: agent-a owns `P6-T3 A3 Lead AgentA` + `P6-T4 SYNTHETIC E2E Lead`
  (managerially assigned), agent-b owns `P6-T3 A3 Lead AgentB` — assignment boundaries intact.

---

## 5. Defects found

| ID | Severity | Where (file:line, determinable) | Description |
|----|----------|----------------------------------|-------------|
| **D-1** | **MEDIUM** | `src/components/crm/views/finance/installment-detail-dialog.tsx:51–64` (3-stat flex row), `:81–95` (payment row `shrink-0` right span), `:38–47` (title/description) | **Installment-detail dialog overflows at 390 px.** Dialog is 358 px wide (x=16..374) but its grid content column sizes to ~491 px: 9 leaf elements render out of bounds (right edges 405–532) — header `#2 · Échéance` (collides with ✕), subtitle `P6-T4 SYNTHETIC E2E Lead · A-101 · P6 Résidence E2E`, `Reste à encaisser`, `8 500 000 DA`, `ACTIVE · 12 500 000 DA`, `Échéancier`, `Règlements enregistrés`, 2× `Saisi par P6-T3 manager.p6`. Root cause: unbreakable DZD strings (NNBSP) in the 3-stat flex row + `shrink-0` `recordedBy` span; visually clipped by `body{overflow-x:hidden}` — **the page-level scrollWidth check passes while content is cut**. VLM screenshot review independently flagged the same strings ("Sais…", "ACTI", "8…"). Evidence: `44`, `vlm-jG-ar-visual-qa.txt` (method note), DOM rects in session log. Fix: `min-w-0` + responsive stacking (`flex-wrap` / `grid-cols-1 sm:grid-cols-3`), truncate title/description, hide/wrap `recordedBy` below `sm`. |
| **D-2** | LOW (AA fail on one control) | `installment-detail-dialog.tsx` close button (shadcn DialogContent ✕) | Dialog close **✕ hit area = 16×16 px** — fails WCAG 2.2 SC 2.5.8 AA (24 px minimum). Other small targets: card chips Qualifier/Assigner 97×28, WhatsApp 36×36, toolbar icons 36–42×36 — pass 24 px AA, miss the 44 px HIG recommendation. Full table: `jH-touch-targets.txt`, screenshot `39`. |
| **D-3** | LOW (cosmetic) | leads table AR, Latin-script names in RTL cells | Ellipsis truncation of Latin-script lead names renders on the leading (right) side in RTL — readable, mildly confusing. VLM-noted (`vlm-jG-ar-visual-qa.txt`, Image2). |
| **D-4** | LOW (cosmetic) | pipeline AR empty-stage totals | Zero amounts render `دج 0` (prefix order) while non-zero render `13 مليون دج` (suffix order) — formatting inconsistency between the compact/empty formatters. VLM Image5. |
| **D-5** | LOW (cosmetic) | `src/components/crm/views/dashboard/attention-strip.tsx:397`, `phased-attention.tsx:78` | Dashboard attention-card hints use `line-clamp-2` with `text-overflow:clip` — some descriptions cut mid-word without an ellipsis affordance (VLM: "visites à confirmer — projet m…", "incentives awaiting approval…"). Intended clamping, missing "…". |
| **D-6** | LOW (cosmetic) | Finance desktop table | DZD amounts ("2 500 000 DA") wrap to two lines in narrow MONTANT column; the rightmost ACTIONS column needs a 28 px in-table scroll with no visible affordance until hover (table container `overflow-x:auto`, scrollW 1178 > clientW 1150). No data hidden (scroll reaches it). VLM Image5 + DOM check. |

No HIGH/CRITICAL defects. Nothing blocked a journey step.

---

## 6. J-I — Restart recovery (session 2)

1. Live manager.p6 session open on `#/dashboard` (httpOnly cookie — JS `document.cookie` empty, as designed).
2. `twin.sh restart` → stopped pid 7450, started pid 17785, ~6 s.
3. Health after 8 s: `{"status":"ok","dbOk":true,"dbLatencyMs":4,"migrations":25,"demoMode":false,"sessionSecretConfigured":true,"nodeEnv":"production"}`.
4. Browser `reload` → **still authenticated**: dashboard renders ("Tableau de bord"), **no login form**, user chip "P6-T3 manager.p6". Stateless HMAC cookie survived the restart, as predicted.
5. Data intact: Leads list = 7 rows incl. `P6-T4 SYNTHETIC E2E Lead` and `P6-T4 SYNTHETIC Mobile Lead`; Finance KPIs 13M/4.0M/8.5M with both installments (`Acompte…SOLDÉE`, `Solde…APPELÉE`). Screenshots `50–52`; console 0 B.

Corroborating evidence that the DB itself is restart-stable (earlier tasks):
`evidence/a1-deploy/10-restart-recovery.txt` (Agent 1: restart cycle, health + data OK) and
`evidence/a2-db/04-replacement-persistence.txt` (Agent 2: DB file byte-stability across replacement).

---

## 7. Objective census (session 2) — `logs/a5-e2e-corpus.txt`

Method: `bun scripts/a5-census.ts` with **inline** `DATABASE_URL=file:/home/z/asas-twin/app/db/custom.db`
(twin SQLite only; dev DB untouched). Full table (35 models):

| model | n | model | n | model | n |
|---|---|---|---|---|---|
| organization | 2 | lead | 8 | activity | 26 |
| user | 8 | leadCaptureToken | 1 | auditLog | 65 |
| pipeline / pipelineStage | 0 / 0 | leadDuplicateDismissal | 0 | revokedSession | 1 |
| tag / leadTag | 0 / 0 | contact | 1 | loginFailure | 5 |
| opportunity | 2 | requirement | 0 | leadTouch | 0 |
| developer | 1 | propertyMatch | 0 | savedSearch | 0 |
| project | 1 | visit / visitApartment | 1 / 0 | document | 1 |
| building | 1 | task | 2 | orgSetting | 0 |
| apartment | 2 | reservation | 1 | installment | 2 |
| offer | 1 | payment | 3 | savCase / salesTarget | 0 / 0 |

**P6-T4 census deltas (both sessions, org1, all synthetic):**
+2 leads (`cmw6pdvw7…` E2E Lead CONVERTED/HIGH→agent-a; `cmw6q1spl…` Mobile Lead NEW/unassigned — session 2),
+2 opportunities (`cmw6pglc0…`, `cmw6pi3pv…`), +1 developer (`cmw6po0kp…`), +1 project (`cmw6po0ks…`),
+1 building (`cmw6po0kt…`), +2 apartments (A-101 RESERVED `cmw6po0ku…`, A-102 AVAILABLE `cmw6po0kw…`),
+1 offer (`cmw6pp81i…` CONVERTED), +1 reservation (`cmw6pq7xm…` ACTIVE 12.5M),
+2 installments (`cmw6prj2n…` 2.5M PAID, `cmw6psypv…` 10M CALLED), +3 payments (4.0M total),
+1 visit (`cmw6pjwhu…` COMPLETED), +1 task (`cmw6plvxh…`), +17 activities on P6-T4 leads,
+1 contact (created at lead conversion). Baseline for the delta: the A3-exit census in
`logs/a3-synthetic-roster.txt` (organizations=2, users=8, leads=6, documents=1, tasks=1).

---

## 8. Honest NOT-VERIFIED / caveats

1. **Touch targets** were measured via `getBoundingClientRect()` (layout boxes), not by
   pointer-hit-testing padded hit areas — a button with invisible padding could test larger
   than its box. The 16×16 ✕ is a box measurement (worst case is its box).
2. **J-A…J-F UI flows themselves were not re-executed** by session 2 — they are attested by
   session 1's screenshots and re-confirmed at the DB level only (census). The first
   session's console capture exists only for login (clean); per-stage console captures for
   J-A…J-F are not available (0-console-error behavior was re-established for every stage
   session 2 touched: J-G/H/I + all matrix combos).
3. **VLM (glm-5.3-flash) screenshot review** is a secondary signal — it produced one false
   "dialog wider than viewport" reading (refuted by DOM rects) and one correct clipping
   finding (D-1, confirmed by rects). Where VLM and DOM disagree, DOM wins; both recorded.
4. **Visual layout QA** beyond the DOM scans relied on the VLM pass (`vlm-jG-ar-visual-qa.txt`
   + the matrix pass) — no human eye reviewed the screenshots.
5. **A11y axe audit / keyboard navigation / screen-reader** flows were NOT in P6-T4 scope and
   were not run (a11y command exists in agent-browser if the Principal wants a follow-up).
6. **AR mobile drawer** bottom action bar was below the fold — verified scrollable-by-design
   (stepper sits in `overflow-x:auto`, scrollW 706 > clientW 365), not a defect, but touch-scroll
   discoverability on that stepper was not user-tested.
7. **J-I restart** was exercised once (light) — no chaos/repeat-loop, no cookie-rotation
   (revokedSession table not re-tested here; Agent 3's `02-session-cookie-security.txt` covers cookie posture).

---

## 9. Environment left behind

- Twin **RUNNING** pid 17785, port 3100, health ok, dbOk, 25/25 migrations, demo OFF.
- Twin DB contains only synthetic P6-* data (corpus above); dev project DB/dev server untouched (PID 1172, port 3000).
- Census script kept at `/home/z/asas-twin/app/scripts/a5-census.ts` (inline-DATABASE_URL pattern).
- Evidence: 53 screenshots (00–52), 30 console captures (all 0 B), `payment-idempotency-transcript.txt`,
  `vlm-jG-ar-visual-qa.txt`, `jH-touch-targets.txt`, corpus `logs/a5-e2e-corpus.txt`.

**Overall verdict: ACCEPTANCE PASS** — 9/9 journeys pass (J-H with a MEDIUM mobile-layout
defect D-1 and five LOW-severity cosmetic/a11y notes, none blocking). Payment idempotency
hard gate and restart recovery both hold. Ready for Principal integration.
