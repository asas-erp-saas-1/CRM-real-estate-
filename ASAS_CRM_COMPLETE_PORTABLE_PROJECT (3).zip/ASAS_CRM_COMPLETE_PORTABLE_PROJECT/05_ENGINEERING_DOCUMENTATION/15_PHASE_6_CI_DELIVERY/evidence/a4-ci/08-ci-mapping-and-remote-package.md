# P6-T6 — C8: ci.yml ↔ local parity mapping + remote-CI owner package

## Part 1 — Step-by-step mapping (every ci.yml step ↔ locally executed command ↔ exit code)

### Job `static-gates` (lint + typecheck + build)
| CI step | CI command | Local parity command | Where | Exit | Evidence |
|---|---|---|---|---|---|
| Checkout | actions/checkout@v4 | rsync copy (excl. .git/docs/node_modules/.next/db/.env) | → /home/z/asas-ci | 0 | a4-ci/01 |
| Install Bun | oven-sh/setup-bun@v2 (1.3.14) | sandbox bun 1.3.14 (matches) | — | — | 01 |
| Install dependencies (lockfile) | `bun install --frozen-lockfile` | `bun install --frozen-lockfile` (clean room) | /home/z/asas-ci | 0 | 01 |
| Generate Prisma client | `bunx prisma generate` | `bunx prisma generate` | /home/z/asas-ci | 0 | 01 |
| Lint | `bun run lint` | `bunx eslint .` (same script) | /home/z/asas-ci | 0 (0 errors / 42 warnings) | 03 |
| Typecheck | `bun run typecheck` | `bunx tsc --noEmit` | /home/z/asas-ci | 0 (0 errors) | 02 |
| Production build | `bun run build` | `NODE_ENV=production NODE_OPTIONS=--max-old-space-size=2048 bunx next build --webpack` | /home/z/asas-ci | **0** (~73 s, standalone 99 MB) | 05 |

Deviation (documented, not hidden): CI runs plain `next build` (Turbopack default) on a
7 GB-class runner; the sandbox parity run uses `--webpack` because Turbopack measured
>2 GB peak RSS vs ~1.5 GB webpack in this 4 GB sandbox (evidence a1-deploy/02-build-run.txt).
The standalone artifact contract (server.js + traced node_modules) is identical — the twin
deployment (a1-deploy) booted the same-shaped artifact and passed the health gate.

### Job `database-gates` (migrations + seed + seed.sql validator)
| CI step | Local parity | Exit | Evidence |
|---|---|---|---|
| `bunx prisma migrate deploy` (DATABASE_URL=file:./db/ci-check.db) | executed against fresh isolated DBs during P6-T1 (twin provisioning: 25/25 applied, zero users) and P6-T6 (ci-test.db) | 0 | a1-deploy/04, a4-ci/04 |
| `bunx prisma migrate status` | 25/25 up to date (a1-deploy/04) | 0 | a1-deploy/04 |
| `bun run db:seed` (isolated DB) | executed on twin DB (P6-T1: 8 users) and ci-test.db (P6-T6) | 0 | a1-deploy/06, a4-ci/04 |
| `python3 scripts/validate-seed.py supabase/seed.sql` | NOT re-run this phase (P0-7/P5-proven; unchanged file at HEAD — git status clean for scripts/) | — (carried) | p0/ASAS_CRM_P0_7 report |

### Job `test-gates` (Vitest full suite, live server, isolated DB)
| CI step | Local parity | Exit | Evidence |
|---|---|---|---|
| migrate + seed ci-test.db | fresh ci-test.db migrate+seed | 0 | a4-ci/04 |
| Boot dev server (demo ON, throwaway secret) + health jq gate | clean-room server on :3000, `dbOk==true` observed | ✓ | a4-ci/04 |
| `bun run test` (full suite) | **`bunx vitest run --maxWorkers=1` → 53/53 files, 884/884 tests, 0 skipped-of-record, exit 0** (definitive run 20:01:45Z, main project + live warm server — Phase 5 methodology) | **0** | a4-ci/04-vitest-final.txt |
| Demo-mode-OFF negative probes | equivalent probes live-verified in P6-T3 P9 (quick-login → 403 DEMO_MODE_DISABLED; session demoUsers []; health demoMode:false on the production-mode twin) + P6-T1 posture evidence | ✓ | a3-security/09, a1-deploy/07-08 |
| Teardown pkill next dev | done (both servers restored + verified 200 afterward) | ✓ | a4-ci/05 |

### Findings surfaced by the local parity attempt (all genuine, all documented)
1. **F-CI-1 (fixed in-phase):** `vitest.config.ts` `poolOptions.forks.maxWorkers` is INERT under
   vitest 5.1.0 (options moved top-level) — the documented MEMORY LAW was silently unenforced;
   parallel worker storms OOM-killed the companion dev server mid-suite. Fixed by the Principal
   (top-level `maxWorkers/minWorkers`) + verified by the 884/884 sequential run. Remote CI on a
   7 GB runner masked the symptom; the law is now active everywhere.
2. **F-CI-2 (operational note, not a code defect):** `tests/security/attribution.test.ts` uses
   "first lead in the agent's list" and creates persistent touches with no cleanup — green only
   on a virgin-DB first run; re-runs against a used DB fail on firstTouchChannel. CI is unaffected
   (fresh runner + fresh ci-test.db every run). Local re-runs need the documented touch-cleanup
   (executed twice this session — evidence 04).
3. **F-CI-3 (environment note):** the sandbox reaps manually-started `next dev` pipelines at
   tool-session boundaries; the CI-parity server must be booted and exercised within a single
   shell session. A GitHub runner boots everything within one job step-set (unaffected).
4. **F-CI-4 (incident, disclosed + repaired):** during Agent 4's window a `db:seed` ran without
   an inline DATABASE_URL (the F-4 shell-export hazard) and seeded the main dev DB at
   2026-11-07T19:17:28Z (its idempotency guard found zero users). The Principal surgically
   restored the EXACT seed census (31/31 models byte-count verified vs a fresh virgin seed —
   evidence 04) before the definitive regression run. Post-suite residue (101 audits, 11
   login-failures, 2 revoked-sessions, 3 touches — the suite's normal footprint, same class as
   Phase 5's disclosed incidents) was cleaned again; final census == seed.

## Part 2 — Remote-CI owner package (BLOCKED: no git remote exists)

Status: **BLOCKED (external)** — `git remote -v` is empty. Nothing was pushed, no repository
created, no URL invented. Exact owner steps when ready (aligned with 05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/GITHUB_IMPORT.md):

1. Review `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` BEFORE the first push (history contains no
   secrets — `.env*` is gitignored since the Phase 1 purge, verified: `git ls-files | grep ^\.env`
   → only `.env.example` + `.env.staging.example`, both placeholder-only — but the doc's
   review checklist is the sanctioned gate).
2. Create a PRIVATE GitHub repository (owner action; do not use a public repo for staging code).
3. `git remote add origin git@github.com:<owner>/asas-crm.git`
4. `git push -u origin main` (main = 91d91c3 + Phase 6 commit; NEVER force-push, never rewrite
   history — the Phase 6 change-set is additive).
5. Required repo secrets/actions config: **none** — ci.yml defines no `secrets.*` usage
   (test-gates uses throwaway inline env: `ASAS_SESSION_SECRET=ci-throwaway-…`,
   `ASAS_DEMO_MODE=1`, `DATABASE_URL=file:./db/ci-test.db`). Verified by reading the workflow.
6. On push, GitHub Actions will execute: static-gates (install→generate→lint→typecheck→
   `bun run build`) · database-gates (migrate→status→seed→seed.sql validator) · test-gates
   (migrate+seed→boot demo server→full suite→demo-off probes). Runner sizing note: the suite's
   memory law caps workers at 12 (~1.8 GB) + dev server ~2.4 GB ⇒ ubuntu-latest (7 GB) fits;
   Turbopack `next build` needs the runner's full headroom (~2.5 GB+) — fine on 7 GB.
7. First-run watch items (from the local parity findings): attribution test needs the fresh
   runner DB (automatic); the vitest top-level maxWorkers fix is already committed.

No secrets, tokens, or credentials appear in this file.
