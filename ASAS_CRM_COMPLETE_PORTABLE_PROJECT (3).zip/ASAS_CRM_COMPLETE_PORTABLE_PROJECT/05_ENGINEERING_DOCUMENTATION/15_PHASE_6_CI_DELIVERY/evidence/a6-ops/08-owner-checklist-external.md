# ASAS Phase 6 / P6-T5 — Evidence 08: OWNER CHECKLIST for external integrations (M4)

2026-11-07 · Agent 6 (monitoring). Everything below is BLOCKED in this sandbox by
design (no staging host, no external accounts, no credentials — none invented).
Every file path, env var and command below is REAL — taken from
`deploy/monitoring/asas-health-watch.sh`, `deploy/monitoring/README.md`,
`deploy/systemd/asas-backup.{service,timer}` and
`05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_OPERATIONS_RUNBOOK.md` §2–4. The dispatch mechanism each
step relies on was LIVE-verified this session (evidence 02–05); only the external
asset is missing.

---

## 1. External uptime monitoring (the vantage point the in-host loop cannot have)

**What to monitor (exact):** `https://<staging-host>/api/health`
**Expected contract:** HTTP **200** with body `{"status":"ok","dbOk":true,…}` —
alert when `status != "ok"` OR `dbOk != true` OR HTTP ≠ 200, after **3
consecutive failures** at a **30–60 s** cadence (README §5 / runbook §2.5).
The endpoint is unauthenticated BY DESIGN and safe to expose: booleans + coarse
process numbers only, no data, no counters (detailed metrics stay behind ADMIN
auth on `/api/metrics`).

Sanity check the owner can run once before wiring any service:
```bash
curl -fsS https://<staging-host>/api/health | jq -e '.status=="ok" and .dbOk==true'
```

Options (README §5, trade-offs verbatim):
- **Self-hosted Uptime Kuma on a second host/VPS** (recommended end-state):
  HTTP + TLS + latency history + alert channels, you own the data; cost = a
  second machine to run and patch. Satisfies the "two vantage points" rule.
- **Commercial free tier** (UptimeRobot / Better Uptime / healthchecks.io class):
  zero ops effort; trade-offs: the health URL + schedule leave your
  infrastructure, free tiers poll slowly (≥60 s…5 min), vendor lock-in on the
  alert channel. Acceptable for staging — the URL carries no secrets.
- **Cron on another machine you already run** (`curl -fsS` + existing mail):
  zero new services, weakest alerting — honest minimum.

## 2. Alert channel wiring (the script's real destination mechanism)

The loop dispatches alerts via the **`ASAS_ALERT_CMD`** env var (a bash snippet;
message arrives BOTH as `$1` AND on stdin — live-verified this session, evidence
03: the Phase-5 empty-message defect is fixed in the repo at
`asas-health-watch.sh` lines 85–86). README §3 examples, all now functional:

```bash
# email via the staging host's installed MTA (if any):
export ASAS_ALERT_CMD='mail -s "ASAS alert" ops@example.dz'

# YOUR chat webhook (fill the placeholder with your own endpoint):
export ASAS_ALERT_CMD='curl -fsS -m 10 -H "content-type: application/json" \
  -d @- https://YOUR-WEBHOOK.example/ <<<"{\"text\": \"$1\"}"'

# append to the ops channel file (zero-dependency default):
export ASAS_ALERT_CMD='tee -a /var/log/asas-alerts.log'
```
Rules: per-alert-key cooldown `ASAS_HW_COOLDOWN` (default 900 s) prevents storms;
never put credentials in repo files; paging/escalation out of scope until the
channel is chosen (README §3). Recommended for staging start: the **file
channel** + a daily human glance, upgraded to webhook/mail when the account
exists.

## 3. Periodic health-watch execution on the staging host (systemd — recommended)

The script is a DAEMON-STYLE LOOP (never exits; `set -u`, no `-e`): run it as a
systemd **service** with `Restart=always` (README §4 option a; script header
lines 24–36 install notes). Unit file adapted from the repo's own
`deploy/systemd/asas-backup.service` hardening pattern:

```ini
# /etc/systemd/system/asas-health-watch.service  (adapted from deploy/systemd/ pattern)
[Unit]
Description=ASAS CRM — health watchdog loop (curl /api/health, alert on deviation)
Documentation=file:/opt/asas/deploy/monitoring/README.md
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=asas
Group=asas
# installed per the script header: sudo install -m 0755 \
#   deploy/monitoring/asas-health-watch.sh /usr/local/bin/
ExecStart=/usr/local/bin/asas-health-watch.sh
Restart=always
RestartSec=10
# ── the loop's real env contract (defaults in parentheses) ──
Environment=ASAS_HW_URL=http://127.0.0.1:3000/api/health
Environment=ASAS_HW_DB_DIR=/opt/asas/db
Environment=ASAS_HW_BACKUP_DIR=/opt/asas/db/backups
Environment=ASAS_HW_STATE_DIR=/var/lib/asas-health-watch
Environment=ASAS_HW_LOG=/var/log/asas-health-watch.log
# pick ONE channel (README §3); example = the zero-dependency file default:
Environment=ASAS_ALERT_CMD=tee -a /var/log/asas-alerts.log
# Threshold envelope for the Docker deployment (runbook §2.3 / compose mem_limit 4g):
Environment=ASAS_HW_RSS_WARN=3500
Environment=ASAS_HW_RSS_CRIT=4000
# (bare-metal 4 GB host with a neighbour: keep script defaults 2200/2600)
StandardOutput=journal
StandardError=journal
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=/var/lib/asas-health-watch /var/log
ProtectHome=true

[Install]
WantedBy=multi-user.target
```

Install + verify (mirrors the backup timer's header steps):
```bash
sudo install -m 0755 deploy/monitoring/asas-health-watch.sh /usr/local/bin/
sudo cp deploy/systemd/asas-backup.service /etc/systemd/system/        # see §5 below
sudo cp deploy/systemd/asas-backup.timer  /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now asas-health-watch.service asas-backup.timer
systemctl status asas-health-watch.service            # one-glance state
tail -f /var/log/asas-health-watch.log                # health_ok/backup_ok lines
journalctl -u asas-backup.service -n 50               # each backup's receipt
```
`/api/metrics`-based checks (ADMIN session) and the docker sidecar variant
(`URL=http://asas-app:3000/api/health`, db/ mounted read-only) are documented
alternatives — README §4 compares them; compose healthcheck (already embedded
by Agent 1) auto-RESTARTS but alerts NOBODY, so it complements, never replaces,
this unit.

## 4. Error-rate check wiring (README §6 — the one monitoring recipe NOT in the loop)

Wire the 5xx recipe as a 15-minute cron on the staging host (README §6 verbatim
command, `$LOG` = wherever the service redirects app stdout):

```bash
# /usr/local/bin/asas-error-rate-check.sh  (content: README §6 recipe)
#!/bin/bash
LOG=/opt/asas/dev.log     # app stdout redirect on the staging host
SINCE=$(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M)
n=$(grep '"event":"api_error"' "$LOG" | grep '"status":5' \
  | while IFS= read -r line; do
      ts=$(printf '%s' "$line" | cut -d'"' -f4)
      [ "${ts:0:16}" \> "$SINCE" ] && printf '%s\n' "$line"
    done | wc -l)
[ "$n" -gt 50 ] && level=CRITICAL || { [ "$n" -gt 10 ] && level=WARNING || exit 0; }
echo "$(date -u +%FT%TZ) 5xx count ${n}/15min (${level})" \
  | tee -a /var/log/asas-alerts.log      # or reuse ASAS_ALERT_CMD-style channel
```
```cron
*/15 * * * * asas /usr/local/bin/asas-error-rate-check.sh
```
(The recipe itself was LIVE-verified against the twin's log this session —
evidence 05: 5/5 injected errors detected, 0 false 5xx. Steady state is 0;
>10 = WARNING, >50 = CRITICAL per README §2.)

## 5. Pairs-with: the backup timer (Agent 2's templates — the watch checks its output)

The watch's `backup_missing` / `backup_stale` (≥26 h) / `backup_integrity`
alerts key off `db/backups/backup-*/manifest.json`, which only stays fresh if
`asas-backup.timer` (daily 02:30, `Persistent=true`) is enabled — install steps
in §3 above and in both unit headers. The watchdog's stale-backup alert
explicitly tells the operator to run `systemctl list-timers asas-backup.timer`
(live-fired receipt: evidence 03 §4). Quarterly restore drills remain a HUMAN
calendar item (README §7): `bash scripts/restore.sh --drill db/backups/backup-<newest>`.

## 6. The Z.ai-cron watchdog question (Principal decision — nothing created)

One-line recommendation (also report §9): **do NOT register a standing Z.ai
cron watchdog for the sandbox twin — arm the health-watch on the real staging
host's systemd per §3 above; a Z.ai job would poll a session-scoped twin that
does not exist between Phase-6 sessions, producing false DOWN alerts.**
If an in-session convenience watchdog is still wanted for the REMAINING
Phase-6 window, the Principal can arm it at phase end with exactly:
`ASAS_HW_URL=http://127.0.0.1:3100/api/health ASAS_HW_INTERVAL=30
ASAS_HW_DB_DIR=/home/z/asas-twin/app/db
ASAS_ALERT_CMD='tee -a /home/z/asas-twin/logs/alerts.log'
bash /home/z/my-project/deploy/monitoring/asas-health-watch.sh` (plus
ASAS_HW_STATE_DIR/ASAS_HW_LOG under /home/z/asas-twin/) — a decision to make
explicitly, never a default.
