# ASAS CRM — Phase 6 Monitoring, Alerting & Operational Readiness Acceptance (DRAFT)

**Task ID:** P6-T5 · **Agent:** 6 (monitoring, alerting & operational readiness) ·
**Date:** 2026-11-07 · **Status:** DRAFT — Principal integration pending.
**Scope:** activate and verify the operational monitoring floor against the LIVE
production-mode staging twin (`http://127.0.0.1:3100`, standalone Next.js,
`nodeEnv:"production"`), with REAL alert-dispatch evidence; inventory the signal
floor; verify the cron-registry claim; hand the owner the exact external
activation checklist.

**Verdict: PASS (in-sandbox activation complete and live-evidenced).** The
Phase-5 monitoring package (`deploy/monitoring/asas-health-watch.sh` + README)
was executed against the live twin without modification: healthy state is quiet
by design; **9 of its alert keys were live-fired with real dispatched receipts**
(file channel + a local webhook listener standing in for the absent external
channel); the Phase-5 alert-dispatch defect fix is **live-proven**; two real
twin restarts were detected; every override was invocation-scoped env — zero
repo edits. External delivery and automated scheduling remain honestly BLOCKED
(no credentials, no staging host, empty cron registry) with the exact owner
checklist prepared (evidence 08).

---

## 1. What is LIVE-ACTIVATED vs PREPARED vs BLOCKED

| Layer | State | Evidence |
|---|---|---|
| Health-watch loop, healthy polling | **LIVE-ACTIVATED** (this session) | 5 invocations, 20 polls over ~2.5 min, zero alerts, alert file never created — 02 |
| Alert dispatch, file channel (`tee`) | **LIVE-ACTIVATED** | receipts for 9 keys — 03 |
| Alert dispatch, webhook channel (local listener :3102) | **LIVE-ACTIVATED** (local stand-in) | full-message JSON receipts — 03 §1-2 |
| Restart detection + per-day counter | **LIVE-ACTIVATED** | 2 real `twin.sh restart`s — 04 |
| Error-rate recipe (README §6) | **LIVE-VERIFIED, not wired** (no cron exists) | 5/5 injected errors counted — 05 |
| P5 dispatch-defect fix ($0→$1+stdin) | **LIVE-PROVEN** | webhook receipts carry the full message — 03 §1-2 |
| External alert channel (email/chat/pager) | **BLOCKED (external)** — zero credentials in sandbox; checklist ready | 08 §2 |
| External uptime monitor (second vantage) | **BLOCKED (external)** — no account/host; exact URL + JSON contract ready | 08 §1 |
| Automated execution (systemd/cron) | **BLOCKED (external)** — no staging host; Z.ai registry EMPTY; exact unit file ready | 07, 08 §3 |
| Backup scheduler (systemd timer) | **PREPARED** (templates) — Agent 2's units; watchdog's backup alerts key off its output | 08 §5 |

## 2. Live dispatch evidence (M1) — sub-check verdicts

| # | Mission sub-check | Verdict | Receipt |
|---|---|---|---|
| 1 | Healthy polling — quiet, no alerts | **PASS** | 20 polls `health_ok`+`backup_ok`, 0 alert lines, destination file never created — 02 |
| 2 | Memory threshold live-fire (WARN + CRIT) | **PASS** | `rss_warning` + `rss_critical` dispatched; **webhook received the FULL message** (`{"text":"rss_critical: rssMb=144 ≥ 100 …"}`) → P5 fix verified; cooldown suppression visible — 03 §1-2 |
| 3 | Stale-backup live-fire | **PASS** | `backup_stale` CRITICAL dispatched with triage hint; healthy `backup_ok` path continuously observed — 03 §4 + 02 |
| 4 | DOWN probe (wrong port :3199) | **PASS** | `availability` CRITICAL dispatched (curl rc=7); real twin untouched — 03 §3 |
| 5 | Restart detection | **PASS** | `app_restarted` WARNING dispatched (uptimeSec 985→3, restart #1 today, per-day state written) + observed-outage path dispatched `availability` during the 2nd real restart — 04 |
| 6 | HTTP error + DB probes | **PASS** | §6 recipe: 5/5 generated API errors counted in-window, 0 false 5xx, category breakdown; DB: dbOk=true on 60+ polls, db_latency live-fired — 05 |
| — | Bonus live-fires | **PASS** | `backup_integrity` (tampered scratch manifest), `disk_warning` (37% ≥ 30), `db_latency` — 03 §5-7 |

Dispatched alert keys (9): `availability` · `rss_warning` · `rss_critical` ·
`backup_stale` · `backup_integrity` · `disk_warning` · `db_latency` ·
`app_restarted` (+ `availability` again during the observed real restart).
Not live-fired, documented with reasons: `http_status`, `health_degraded`,
`restart_flapping`, `backup_missing` (03 §8; `restart_flapping` shares the
live-proven counter code path; only 2 intentional restarts were performed).

## 3. Signal inventory summary (M2) — 8 VERIFIED-LIVE · 4 PARTIAL · 3 BLOCKED(external)

- **VERIFIED-LIVE (8):** application availability · database availability ·
  memory usage · disk capacity (37% live, check live-fired) · process restarts
  (stand-in for container restarts) · backup success (integrity) · backup age ·
  alert delivery (local).
- **PARTIAL (4):** restore-drill status (real drill PASS this session by Agent 2;
  cadence is a human calendar item by design) · HTTP error rate (recipe
  live-verified; not wired to a scheduler) · critical application errors
  (structured log seam live-verified; no shipping/alerting wired) · scheduler
  behavior (re-arms at every server start via `instrumentation.ts:32`, 60 s
  interval — but SILENT by design when nothing is due: read-only DB query shows
  0 due items, 0 `[sweeper]` lines, 0 sweep failures across both restarts; no
  positive heartbeat signal EXISTS).
- **BLOCKED (external) (3):** host/network-death vantage (external uptime) ·
  external alert channel · automated watchdog execution host.
Full table with one-line evidence per signal: **evidence 06**.

## 4. Cron registry verification (M3) — the Phase-5 "510835" claim does NOT hold

The **Z.ai cron registry is EMPTY — 0 jobs** (verified by the Principal this
session; tool output recorded in the Principal's session). The Phase-5 final
report's claim of an armed watchdog job "510835" appears in **no repo file**
(`rg '510835'` across all of /home/z → 0 matches) and is **contradicted by
Phase 5's own written record** ("no cron job, timer or background automation
was created or enabled in this session" — `ASAS_PHASE5_DATABASE_BACKUP_RECOVERY.md:190,302`;
"No timer/cron is enabled in the dev sandbox" — runbook:355). The three layers
are distinct: (a) Z.ai scheduled jobs — registry EMPTY; (b) staging-host systemd
timers — templates only, activation BLOCKED (no staging host); (c) the
health-watch script — manual/executable, live-proven this session, scheduled by
nothing. **No cron job was created by this agent** (Principal's decision).
Details: **evidence 07**.

## 5. Script defects found (rule: document, never fix)

**None that would fail on the real staging host.** Verified clean: the P5
dispatch fix (line 85-86) works live; cooldown, per-day restart rollover, JSON
fallback chain, backup glob and df/stat guards all behaved. Four documented
non-defect observations (design notes, flagged for the Principal — no source
change recommended):
1. The loop has **no error-rate check** — README §6 is an explicit recipe with
   "wire as a cron or extend the script"; owner wiring (evidence 08 §4).
2. **`curl -f` precision** (P5-known): a 503-degraded health route surfaces as
   `availability` (rc=22) rather than `health_degraded` — same CRITICAL
   severity, less precise message.
3. **Restart counter vs observed outage** (script line 129): a poll that CATCHES
   the downtime clears `prev_uptime`, so that restart does not increment the
   day counter — the `availability` CRITICAL is the signal in that path; the
   counter fires when downtime falls between polls (both paths live-proven in
   evidence 04 — with the default 30 s interval vs ~1–2 s twin restart, the
   counter path is the one that fires on a real host).
4. **The expiry scheduler has no positive heartbeat** (silent no-op by design,
   `expiry-scheduler.ts:41-45`) — "is it ticking" is unobservable without due
   work items; if the owner wants heartbeat evidence, an occasional log line
   would be a deliberate code change, not a fix.

## 6. Environment notes (honest)

- The sandbox tool harness reaps backgrounded jobs between calls (nohup and even
  setsid did not survive) — all canonical runs were foreground-bounded
  (`timeout -s TERM`), and the webhook listener ran within a single call window
  (started, received both receipts, killed; port 3102 unreachable afterwards —
  evidence 02 note + 07 §4).
- Threshold overrides were ALL invocation-scoped `ASAS_HW_*` env vars; a
  post-live-fire invocation with pure defaults returned to the quiet healthy
  baseline (03 §7). `git diff -- deploy/monitoring/` is EMPTY;
  `git status --porcelain -- deploy/` = 0 entries. The dev preview (port 3000)
  and the main DB were never touched. No builds were run.

## 7. Twin end state (rule: keep it RUNNING)

**RUNNING and healthy** — pid 23975 (two sanctioned `twin.sh restart`s during
restart-detection testing, both recovered: `status:"ok"`, `dbOk:true`,
`migrations:25`, `rssMb:138`, `uptimeSec:335` at 18:58:37Z). Twin DB intact
(25/25 migrations, 1 OWNER); Agent 2's backup untouched (integrity "ok", age
~1.5 h). No stray monitoring processes; local webhook listener killed.

## 8. Evidence index — `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a6-ops/`

01-healthwatch-config.txt (contract + destination configuration) ·
02-healthy-polling.txt (5 invocations, 20 polls, zero alerts) ·
03-alert-dispatch-livefire.txt (9 dispatched receipts, P5-fix proof, cooldown) ·
04-restart-detection.txt (two real restarts, both detection paths) ·
05-http-errors-and-db.txt (error recipe + DB probes) · 06-signal-inventory.txt
(M2 table) · 07-cron-registry-verification.txt (M3, empty registry, "510835"
void) · 08-owner-checklist-external.md (M4: uptime URL/contract, ASAS_ALERT_CMD
examples, systemd unit file, error-rate cron, backup timer, Z.ai decision).

## 9. Recommendation on the Z.ai watchdog question (one line)

**Do not register a standing Z.ai cron watchdog for the sandbox twin — arm the
health-watch loop on the real staging host's systemd per evidence 08 §3 (exact
unit file included); a Z.ai job would poll a session-scoped twin that does not
exist between Phase-6 sessions and would generate false DOWN alerts.**

---
*Prepared by Agent 6 (P6-T5). DRAFT: awaiting Principal integration into the
Phase-6 final report. All claims above are backed by the evidence files in
§8; everything not executable in this sandbox is explicitly declared BLOCKED
with its exact external requirement — nothing external was invented.*
