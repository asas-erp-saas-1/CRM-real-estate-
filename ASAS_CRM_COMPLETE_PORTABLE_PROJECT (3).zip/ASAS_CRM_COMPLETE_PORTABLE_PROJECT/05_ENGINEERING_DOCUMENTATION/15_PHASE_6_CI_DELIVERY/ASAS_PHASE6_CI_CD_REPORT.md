# ASAS CRM — Phase 6 CI/CD Report

**Task ID:** P6-T6 · **Status:** COMPLETE (local CI parity EXECUTED; remote execution BLOCKED — external) · **Date:** 2026-11-07
**Executors:** Agent 4 (C1–C3, C6, C7 — clean room, install, typecheck, lint, failure-gate proof, secrets audit) + Principal (C4 definitive regression, C5 production build, forensic recovery, integration) — Agent 4 hit its context deadline mid-C4; the Principal completed the remaining steps and independently reproduced the earlier ones' key results.
**Baseline to beat (Phase 5):** 879/879 tests · tsc 0 · lint 0/41 warnings · production build NEVER executed anywhere.

---

## 1. Local CI parity — the full gate chain, executed

| Gate | Result | Evidence |
|---|---|---|
| Install (`bun install --frozen-lockfile`, clean room) | **PASS** — exit 0 | `evidence/a4-ci/01` |
| Prisma generate | **PASS** — exit 0 | `evidence/a4-ci/01` |
| Typecheck (`tsc --noEmit`) | **PASS** — 0 errors (19 s) | `evidence/a4-ci/02` |
| Lint (`eslint .`) | **PASS** — 0 errors, **42 warnings** (41 baseline + 1 new benign warning from the P6-D1 route-export fix, reconciled 1:1 — no pre-existing warning removed or modified) | `evidence/a4-ci/03` |
| **Full Vitest suite (FINAL REGRESSION)** | **PASS — 53/53 files, 884/884 tests, exit 0** (+5 vs Phase 5: `route-export-contract` ×2, `instrumentation-boot-gate` ×3 — both added by the Principal this phase; 0 tests removed) | `evidence/a4-ci/04-vitest-final.txt` |
| **Production build (CI acceptance step)** | **PASS — exit 0, ~73 s, standalone output 99 MB (server.js + traced node_modules incl. Prisma engine)** — executed in full runner isolation (no servers running), matching the CI static-gates environment | `evidence/a4-ci/05` |
| Failure-gate proof (a failing test ⇒ non-zero exit) | **PASS** — throwaway scratch run, exit 1, cleaned up, repo untouched | `evidence/a4-ci/06` |
| Secrets audit | **PASS** — only `.env.example`/`.env.staging.example` tracked (placeholder-only); `.env` gitignored; no untracked secret files | `evidence/a4-ci/07` |
| ci.yml step mapping | 8/8 static+test gate steps mapped to executed commands (1 carried: seed.sql validator, unchanged since P5 proof) | `evidence/a4-ci/08` |

**Method note (honest):** the definitive 884/884 run used the Phase 5 methodology — the full
suite against the live warm dev server with the shared demo DB, executed sequentially
(`--maxWorkers=1`) because parallel worker storms on the non-WAL SQLite triggered lock-contention
failures (documented takes 1–3 in evidence 04). The suite's own concurrency law was also found
inert (see finding F-CI-1) and is now fixed in `vitest.config.ts`.

## 2. Defects found & fixed this phase (CI-relevant)

| ID | Severity | Finding | Disposition |
|---|---|---|---|
| **F-CI-1** | HIGH (CI correctness) | `vitest.config.ts` `poolOptions.forks.maxWorkers: 12` — the documented memory law — was **silently ignored by vitest 5.1.0** (options moved top-level; deprecation warning only). The suite ran UNCAPPED; 53 per-file isolate workers raced the dev server for memory and the kernel OOM-killer reaped it mid-suite. | **FIXED (Principal):** migrated to top-level `maxWorkers: 12 / minWorkers: 1` with the full history in the config comment. Verified by the 884/884 run. Affects remote CI identically — the fix makes the law active there too. |
| F-CI-2 | LOW (test hygiene) | `attribution.test.ts` probes "first lead in the agent's list" and leaves 3 touches with no cleanup — green only on a virgin DB; re-runs fail on `firstTouchChannel`. CI unaffected (fresh runner DB per run). | Documented; local re-run cleanup procedure recorded (evidence 04). Not fixed in-phase (test-only change, not deployment-blocking). |
| F-CI-4 | Incident (disclosed, repaired) | A `db:seed` without an inline `DATABASE_URL` (the F-4 sandbox shell-export hazard) seeded the main dev DB at 19:17:28Z during Agent 4's window (guard found zero users). | Principal surgically restored the EXACT seed census (31/31 models match a fresh virgin seed) before the definitive regression; post-suite residue cleaned again; final census == seed. Full timeline in evidence 04. |

## 3. Remote CI execution — BLOCKED (external dependency)

`git remote -v` is empty; no GitHub repository exists; nothing was pushed, invented, or fabricated.
**The complete owner activation package** (remote creation, push commands, secrets policy —
none needed, runner sizing, first-run watch items) is in `evidence/a4-ci/08` Part 2, aligned
with `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/GITHUB_IMPORT.md` and the `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` review gate.

## 4. What changed vs Phase 5 (regression reconciliation)

| Metric | Phase 5 | Phase 6 | Delta |
|---|---|---|---|
| Tests | 879/879 (51 files) | **884/884 (53 files)** | +5 (2 route-export-contract, 3 instrumentation-boot-gate — both regression guards for Phase 6 fixes); 0 removed |
| tsc | 0 errors | 0 errors | — |
| Lint | 0 errors / 41 warnings | 0 errors / **42 warnings** | +1 benign (P6-D1 fix's intentional unused-symbol note), reconciled |
| Production build | never executed | **executed, exit 0** (clean room + twin, 5 successful builds total) | gate closed |
| Migrations | 25/25 | 25/25 (re-verified on 3 fresh DBs) | — |

## 5. Honest NOT-VERIFIED list

1. Remote GitHub Actions execution (no remote — owner package delivered).
2. `scripts/validate-seed.py supabase/seed.sql` not re-run (file unchanged since its P0/P5 proof).
3. Turbopack production build in-sandbox (memory-bound; webpack parity run + Dockerfile's
   builder stage remains the sanctioned Turbopack site on an adequately-sized host).
4. CI's exact `bun run test` invocation (no maxWorkers flag) against a fresh runner DB —
   locally proven equivalent via the sequential run; the flag difference is documented.

*No secrets, tokens, or credentials appear in this report.*
