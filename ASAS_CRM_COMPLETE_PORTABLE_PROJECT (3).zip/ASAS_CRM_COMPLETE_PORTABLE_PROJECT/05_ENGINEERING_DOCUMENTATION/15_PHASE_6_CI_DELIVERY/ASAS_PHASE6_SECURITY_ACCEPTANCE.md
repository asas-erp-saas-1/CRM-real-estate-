# ASAS CRM — Phase 6 Security Acceptance (P6-T3, Agent 3: Security / Production Posture / Access Control)

**Status: DRAFT — Principal integration pending.**
**Task ID:** P6-T3 · **Agent:** 3 (A3-SECURITY) · **Date:** 2026-11-07 · **Target:** live production-mode staging twin `http://127.0.0.1:3100` (NODE_ENV=production, ASAS_DEMO_MODE=0, 25/25 migrations).
**Method:** read-first (constants.ts / session.ts / auth.ts / visibility.ts / proxy.ts / route sources), then SAFE SYNTHETIC non-destructive HTTP + Prisma probes. All transcripts cookie/password-redacted. No source files modified. Main dev DB/server untouched (inline `DATABASE_URL="file:/home/z/asas-twin/app/db/custom.db"` on every Prisma command — F-4 respected).

---

## 1. Verdicts (P1–P9)

| Probe | Verdict | One line |
|---|---|---|
| P1 Role inventory + synthetic users | **PASS** | Real role set is `OWNER, ADMIN, MANAGER, SALES_AGENT, FIELD_REP` (NO "DIRECTOR"); 6 synthetic users created through the REAL API (`POST /api/users`, OWNER session) across every non-OWNER role + org2 owner via Prisma; all logins verified live. [ev 01] |
| P2 Session & cookie security | **PASS** | HttpOnly+Secure+SameSite=lax+Max-Age=604800+Path=/; forged/tampered/garbage/unsigned cookies → 401 NO_SESSION; absolute 7-day expiry LIVE-proven by validly re-signing a −8d cookie with the twin's secret (value never printed); logout → exact-pair server-side revocation (replayed stolen cookie → 401); password change kills pre-change sessions (replay → 401); 0 secret/password occurrences in server.log. [ev 02] |
| P3 Role permissions (server-side) | **PASS** | OWN+POOL for SALES_AGENT (peer-assigned lead absent from list AND 404-ghost on direct ID), ORG for MANAGER/ADMIN/OWNER, project-scope-empty for FIELD_REP; user creation 403 below ADMIN; ADMIN→OWNER ceiling 403 ROLE_CEILING; roster emails stripped below MANAGER; denied probes log clean structured AUTH/AUTHZ lines, no crash. [ev 03] |
| P4 Organization isolation | **PASS** | org2 owner sees ONLY org2's lead (total 1); cross-org direct-ID probes 404 LEAD_NOT_FOUND in BOTH directions; org1 roster has zero org2 users. [ev 04] |
| P5 Public capture token | **PASS** | Valid token → 200 `{ok:true}` + exactly one pool lead (source=PUBLIC_CAPTURE); flipped token → 401 INVALID_TOKEN (census unchanged); no token → 422; honeypot silently swallowed; mass-assignment fenced (`.strict()` 422 on unknown `ownerId`). [ev 05] |
| P6 Document authorization | **PASS** | agent-a upload→download 200 (byte-identical, nosniff, no-store, attachment disposition); agent-b → 404 DOC_NOT_FOUND (list + direct); anonymous → 401; cross-org owner2 → 404; MANAGER → 200; file verified on disk under `app/db/docs/`. [ev 06] |
| P7 CSRF / cross-origin | **PASS** | Server-side origin enforcement EXISTS (not SameSite-only): login with `Origin: https://evil.example` → 403 CROSS_ORIGIN_BLOCKED (pre-auth choke-point `readJson`); authed POST with valid cookie + evil origin → 403 and NO record created; `Origin: null` → allowed by design (opaque origin; SameSite=lax withholds cookie for its mutations); no-Origin API clients allowed by design. [ev 07] |
| P8 Login rate limits | **PASS** (with briefing correction) | 5 failed logins/15 min per EMAIL → 429 ACCOUNT_LOCKED (6th attempt); correct OWNER login still works while another email is locked; **the lockout is DB-BACKED (LoginFailure table) and SURVIVES `twin.sh restart`** — attempt 7 post-restart still 429. The briefing's "restart clears in-memory rate limiters" applies only to the in-memory family (public-capture token/IP windows, copilot/analyze). [ev 08] |
| P9 Production posture | **PASS** | Demo quick-login `{userId}` → 403 DEMO_MODE_DISABLED (F-01 vector closed, probed with the real OWNER id); unauthenticated `GET /api/auth/session` → `demoUsers: []`; health: `demoMode:false, sessionSecretConfigured:true, nodeEnv:production, migrations:25`; production seed refusal cited from a1-deploy/05 (not re-run). [ev 09] |

**No CRITICAL or HIGH findings. No genuine authorization hole found.** Cross-agent, cross-org, forged-session, token-forgery and CSRF probes were all correctly refused server-side.

---

## 2. Live-verified role / visibility matrix (vs 05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/ROLE_DATA_VISIBILITY_MATRIX.md)

Corpus at probe time: org1 = 5 leads (2 P6-A2 pool + AgentA-assigned + AgentB-assigned + 1 PUBLIC_CAPTURE pool), org2 = 1 lead.

| Cell | Documented | LIVE result | Match |
|---|---|---|---|
| Leads · SALES_AGENT | OWN+POOL | agent-a/agent-b each see 4/5 (own + 3 pool); peer's assigned lead ABSENT | ✅ |
| Leads · MANAGER / ADMIN / OWNER | ORG | 5/5 org1, org2 lead invisible | ✅ |
| Leads · FIELD_REP | assigned-project-derived, NO pool | 0 (no ProjectAssignment rows in twin — negative case only) | ✅ (partial: positive path code-verified) |
| Direct-ID foreign lead | 404 byte-identical ghost | 404 LEAD_NOT_FOUND, byte-identical to random id (list + detail, cross-agent AND cross-org) | ✅ |
| User creation | ADMIN+ only; OWNER ceiling | OWNER 201 ×5; ADMIN 201 (non-OWNER); MANAGER/SALES_AGENT/FIELD_REP 403 FORBIDDEN_ROLE; ADMIN→OWNER 403 ROLE_CEILING | ✅ |
| Roster (`GET /api/users`) | names+roles below MANAGER; emails at MANAGER+ | agent-a: 6 rows, zero email keys; manager: emails present | ✅ |
| Management surfaces | analytics/audit/export 403 below MANAGER | SALES_AGENT 403 (FORBIDDEN_ROLE / EXPORT_FORBIDDEN); MANAGER 200 | ✅ |
| `/api/settings` | "403" for SALES_AGENT (§3) | **GET 200 for SALES_AGENT** (org-scoped non-PII config); PUT (mutation) 403 FORBIDDEN_ROLE | ⚠️ doc-vs-code drift (LOW, see §6) |
| Documents | own uploads ∨ inventory ∨ docs on in-scope entities | uploader 200; peer agent 404 (list+direct); anonymous 401; MANAGER 200; cross-org 404 | ✅ |
| Sessions | HMAC cookie + 7d absolute expiry + revocation | all live-proven (see P2) | ✅ |

---

## 3. Session & auth security detail (live-proven)

- Cookie `asas_user` = `userId.issuedAtMs.HMAC-SHA256(userId.issuedAtMs, ASAS_SESSION_SECRET)`; attributes `HttpOnly; Secure; SameSite=lax; Path=/; Max-Age=604800` (7d == server-side `SESSION_MAX_AGE_MS`).
- Tamper: any HMAC flip/append/garbage/unsigned raw userId → 401 NO_SESSION (constant-time compare, session.ts:56-73).
- Absolute expiry: LIVE-proven — cookie validly re-signed with the twin's real secret (secret read in-process, never printed) at `issuedAtMs = now−8d` → 401; `now` control → 200.
- Revocation (NOT purely stateless): logout writes exact `(userId, issuedAtMs)` RevokedSession row → replayed stolen cookie 401; password change bumps `passwordChangedAt` → pre-change cookie 401, new password login 200. `sessionsRevokedAt` revoke-all watermark code-verified only.
- Sessions survive `twin.sh restart` (stateless signature; revocation checks ride the user query) — verified live post-restart.
- Login hardening observed: timing-oracle-neutral dummy-hash arm, byte-identical INVALID_CREDENTIALS, unknown-email failures logged structurally with peer IP (127.0.0.1 recorded via the node server's XFF synthesis), lockout audited when the email maps to a real account.
- CSRF: `assertSameOrigin` at BOTH choke-points (`requireUser` for authed routes, `readJson` for pre-auth login) — evil-origin login 403, evil-origin authed mutation 403 with zero side effects. Public capture route is deliberately CORS-open (no session to forge) and relies on token + honeypot + rate windows.

## 4. Synthetic corpus (for Agents 5/6)

Full roster with IDs: `/home/z/asas-twin/logs/a3-synthetic-roster.txt`. Summary: **2 orgs · 8 users** (org1: owner + admin.p6 + manager.p6 + manager2.p6 + agent-a.p6 + agent-b.p6 + fieldrep.p6; org2: owner2.p6) **· 6 leads** (org1: 2 P6-A2 + AgentA + AgentB + Capture-Public; org2: 1) **· 1 document** (1×1 PNG on agent-a's lead) **· 1 capture token** (secret one-time, not persisted). Passwords: `/home/z/asas-twin/secrets/*.txt` (600). `nonexistent@example.invalid` is login-locked ~15 min from 17:48Z (DB-backed).

## 5. Twin state at exit

RUNNING pid=7450 port=3100, health `ok` (dbOk, 25/25 migrations, demoMode:false, sessionSecretConfigured:true, nodeEnv:production). Twin restarted once during P8 (by design, to prove lockout persistence). Dev preview untouched (pid 1172, port 3000).

## 6. Defects / observations (no source fixes made — Principal's call)

1. **LOW — doc-vs-code drift, `GET /api/settings`:** ROLE_DATA_VISIBILITY_MATRIX.md §3 lists "`/api/settings` | 403" for SALES_AGENT; live behavior: GET is open to ANY authenticated role (returns matching weights + notification thresholds — org-scoped, non-PII) while the mutation PUT is correctly MANAGER-gated (403 FORBIDDEN_ROLE live-verified). Files: `src/app/api/settings/route.ts:15-23` (GET has no role gate) vs `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/ROLE_DATA_VISIBILITY_MATRIX.md` §3 row. Decide: tighten the route or refresh the matrix cell.
2. **LOW — route-pattern normalization gap (metrics labels only):** `CUID_RE = /^c[a-z0-9]{20,}$/i` (`src/lib/server/route-pattern.ts:10`) did not match the 18-char probe id `cmw6nonexistent99`, which therefore appeared RAW in the `x-asas-route` log/metrics label (observed in server.log). Real Prisma cuids (25 chars) normalize; risk = identifier-bearing/unbounded metric keys for non-cuid id shapes. No authorization impact.
3. **INFO — API temp-password entropy:** `generateTempPassword()` = `Asas-` + 6 CSPRNG chars (`src/lib/server/auth.ts:47-54`, ~34.6 bits) — below the 12-char/`provision-owner` CLI bar (`scripts/provision-owner.ts:36`). One-time display, CSPRNG-based (F-13 fixed), but short for an unrotated credential; consider lengthening or forcing change on first login.
4. **INFO — briefing correction (not a defect):** the login limiter is DB-backed per-email (P2/W2, `LoginFailure` table) and survives restarts; only the capture/copilot/analyze limiters are in-memory (`src/lib/server/lead-capture.ts:215-269`).

## 7. Honest NOT-VERIFIED list (code-verified only, not live-proven this round)

- Exact 7-day expiry boundary (probed −8d vs now; the −7d+ε edge is code logic `session.ts:71`).
- `POST /api/auth/sessions/revoke-all` watermark (session.ts:127-128) — not executed.
- Production boot-gate crash (missing secret / demo=1 in production) — code (`src/instrumentation.ts`, `src/lib/server/boot.ts`); live twin only shows the healthy configuration (health flags).
- Production demo-seed refusal — cited from P6-T1 evidence `evidence/a1-deploy/05-seed-refusal.txt`, not re-run (task rule).
- FIELD_REP positive path (leads visible through assigned projects) and visit-confirmation entitlement (`canConfirmVisit`) — twin has no ProjectAssignment rows; negative case live-proven, positive path code-verified (`visibility.ts:62-94, 221-232`).
- Reservation financial-field minimization (FIN-MIN-Q10, `reservation-dto.ts`) — code-verified only this round.
- Gateway path of `assertSameOrigin` (Caddy Host/XFH rewriting, D-019/D-020 acceptance rules incl. Sec-Fetch-Site browser-vouched allowance) — twin is direct-to-node :3100, no Caddy in front; trust model documented in `session.ts:339-425`.
- Document `analyze`/`thumb` route authz — same scope law as the probed `file` route (code-verified).
- ADMIN-role cell of the §1 matrix for tasks/opps/visits/documents — code-verified (identical scope builders); leads row live-probed.

## 8. Evidence index

`/home/z/my-project/05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a3-security/`: `01-role-inventory-users.txt`, `02-session-cookie-security.txt`, `03-role-permissions.txt`, `04-org-isolation.txt`, `05-public-capture-token.txt`, `06-document-authz.txt`, `07-csrf-cross-origin.txt`, `08-rate-limits.txt`, `09-production-posture.txt` — all transcripts with cookies/passwords redacted; secrets live only in `/home/z/asas-twin/secrets/` (mode 600).
