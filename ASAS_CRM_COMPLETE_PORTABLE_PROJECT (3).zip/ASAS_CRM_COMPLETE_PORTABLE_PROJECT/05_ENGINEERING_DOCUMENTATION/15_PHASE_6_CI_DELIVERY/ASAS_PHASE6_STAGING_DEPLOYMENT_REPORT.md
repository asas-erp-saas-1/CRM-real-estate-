# ASAS CRM — Phase 6 Staging Deployment Report (In-Sandbox Staging Twin)

**Task IDs:** P6-T1 (Agent 1) + Principal integration · **Date:** 2026-11-07
**Environment verdict up front:** no Docker daemon, no external staging host, no SSH, no domain, no
Git remote exist in this sandbox (all verified live — see §1). The sanctioned Phase 6 approach was
therefore the **in-sandbox staging twin**: an isolated hardlink-copy of the repository at
`/home/z/asas-twin` in which the **first-ever production build was executed** and the
**production-mode standalone application was deployed, provisioned, exercised, restarted, backed up,
restored, monitored, and E2E-verified**. The main project's dev preview (port 3000) was never
stopped for twin operations and its `.next`/DB were never touched by twin work (one OOM collateral
incident + one F-4 seed incident occurred and were fully recovered + disclosed — §5).

---

## 1. Deployment authorization boundary — verified facts

| Dependency | Live status (verified this session) | Consequence |
|---|---|---|
| Docker daemon | **NOT INSTALLED** (`docker: command not found`) | Container image build/run = BLOCKED (external) |
| External staging host / SSH | none exists | Real-host deployment = BLOCKED (external) |
| Git remote | `git remote -v` empty | Remote CI = BLOCKED (external) — owner package delivered |
| External monitoring credentials | none | External uptime/alerting = BLOCKED (external) |
| Offsite backup destination | none | Offsite copies = BLOCKED (external) |
| Host resources (sandbox) | 4.0 GiB RAM / 2 CPU / 9.9 G disk | Twin build memory-tripwired; webpack bundler measured |

**The documented decision (Principal):** the sandbox rule forbids `bun run build` in the live
project to protect the preview dev server. The twin honors that intent by construction: separate
directory (hardlinked node_modules — near-zero cost), separate `.next`, separate DB, separate port
(3100), memory tripwire (kill the build tree before the kernel OOM killer can act), and the main
project untouched. The twin is treated as a verification mini-service per the sandbox's
mini-services convention.

## 2. What was deployed and verified (the twin lifecycle)

1. **Production build — EXECUTED (5 successful builds):** first-ever `next build` of this codebase.
   Initial attempts surfaced the two latent defects below; the final build: exit 0, ~73 s,
   standalone output 99 MB (server.js + traced node_modules incl.
   `libquery_engine-debian-openssl-3.0.x.so.node`), 52/52 static pages. Turbopack measured >2 GB
   RSS (tripwire tripped at 101 MB MemAvailable) — webpack used instead (~1.5 GB peak; min
   MemAvailable 525 MB). The repo's Dockerfile (Turbopack, ≥8 GB host) is unaffected — measured
   numbers now anchor the host sizing guidance.
2. **Runtime assembly per the Dockerfile's runtime-stage contract:** standalone tree + `.next/static`
   + `public/` at the twin app root with `db/` on the twin's persistent path (the Dockerfile's
   `/app/.next/standalone/db → /app/db` symlink bridge is replaced by the equivalent cwd-relative
   `db/` — parity table in evidence 11).
3. **Production-mode boot:** `node server.js` (NOT next dev) on 127.0.0.1:3100 with
   NODE_ENV=production, ASAS_DEMO_MODE=0, 64-hex synthetic session secret (never printed; mode 600).
   Health gate (README-STAGING §C1 jq assertion): `{"status":"ok","dbOk":true,"dbLatencyMs":1-4,
   "migrations":25,"demoMode":false,"sessionSecretConfigured":true,"nodeEnv":"production"}` ✓
4. **Database lifecycle (deployment runbook §C1/C4 verbatim):** fresh DB → `prisma migrate deploy`
   (25/25) → **zero users proven** → production demo-seed REFUSAL (exit 1, zero writes) →
   `db:owner` provisioning of a synthetic OWNER (random ≥12-char password; idempotent second-run
   refusal; demo-password refusal) → login smoke 200 with secure cookie
   (`asas_user; Secure; HttpOnly; SameSite=lax; Path=/; Max-Age=604800`).
5. **Posture fail-fast gates — LIVE:** demo-mode boot → exit 1 `DEMO_MODE_PRODUCTION`; missing
   secret → exit 1 `SESSION_SECRET_MISSING` (after the F-5 fix these now genuinely TERMINATE the
   process — port refused afterwards; pre-fix behavior was alive-but-500s, see §4).
6. **Restart/recovery (Journey I):** TERM → down → `twin.sh restart` → healthy in ~6 s; DB sha256
   byte-identical across restart; sessions (stateless HMAC) survive restart while the secret is
   unchanged; OWNER re-login works.
7. **Runtime footprint:** standalone RSS **129–150 MB idle** (3–4% of the compose `mem_limit: 4g`;
   ~12× leaner than the dev server) — the compose memory ceiling is now validated with headroom by
   measurement, replacing dev-class estimates.

## 3. The twin as a verification platform for the rest of Phase 6

- **Database/backup/restore (P6-T2):** full lifecycle on the twin — synthetic corpus via the real
  API → backup (VACUUM INTO + manifest + sha256) → process-replacement persistence (byte-stable) →
  restore drill into a disposable copy (byte-identical, census-exact, original untouched) →
  systemd timer/offsite = templates verified, activation BLOCKED (external).
- **Security (P6-T3):** 9/9 PASS — roles (OWNER/ADMIN/MANAGER/SALES_AGENT/FIELD_REP — the REAL
  hierarchy; no DIRECTOR exists), agent privacy (OWN+POOL, 404-ghost), live cross-org isolation
  (second synthetic org), forged/expired/revoked sessions, public-capture token fencing, document
  authz, server-side origin enforcement, DB-backed login lockout. Zero CRITICAL/HIGH findings.
- **E2E CRM (P6-T4):** journeys A–I PASS (lead → opportunity → visit → offer → reservation →
  payment-with-idempotency [replay 409 + concurrent race exactly-one-wins + census arithmetic
  exact] → role privacy → AR RTL → mobile 390 → restart recovery), 6-combo UI matrix, 0 console
  errors, payment hard gate PASS.
- **Monitoring (P6-T5):** health-watch LIVE-ACTIVATED with 9 alert keys dispatched to real local
  destinations (file + webhook receipts), restart detection, backup-age/staleness, memory/disk
  thresholds, DB + HTTP error probes; external vantage = BLOCKED (owner checklist delivered).

## 4. Deployment-verification defects found & fixed (the mission's core value)

| ID | Severity | Defect (found BY the deployment attempt) | Fix (smallest safe correction, Principal-applied) | Regression guard |
|---|---|---|---|---|
| **P6-D1** | **CRITICAL (build-breaking)** | `src/app/api/documents/[id]/analyze/route.ts:49` exported `KNOWN_FIELD_KEYS` — invalid Next 16 route export ⇒ `next build` exit 1. **The Phase 5 "staging package" was never buildable at HEAD 91d91c3** — invisible to tsc (0 errors), only to the never-executed build. | Removed the `export` keyword (zero importers, grep-verified). | `tests/unit/route-export-contract.test.ts` (scans all 87 route files for invalid exports — catches the whole class) |
| **P6-F5** | HIGH (operational) | Next 16.1.3 standalone **swallows instrumentation rejections** — misconfigured boots stayed alive serving 500s; `restart: unless-stopped` never fired; contradicted the documented fail-fast contract (P5's C3 evidence was module-level only). | `process.exit(1)` in the catch path of `src/instrumentation.ts` register(). | `tests/unit/instrumentation-boot-gate.test.ts` + live probes (exit 1 ×2, port refused) |
| P6-D1b | MEDIUM (UI/G* gate) | Installment-detail dialog content silently clipped at 390 px (9 leaves 405–532 px vs dialog edge 374) — the amount row's unbreakable NBSP-DZD trio + a `shrink-0` span, and the true root cause: the dialog's grid-item column lacked `min-w-0` so a nowrap subline blew the track. | Responsive stacking below `sm` + `min-w-0` on the column/row/span (CSS-only; `sm:` desktop layout regression-checked: row layout 154/136/136 px). | Browser rect-scan verification (9→0 clipped leaves); method documented for QA reuse |
| F-CI-1 | HIGH (CI) | vitest 5.1 silently ignores the suite's memory law (`poolOptions` deprecated form) — uncapped workers OOM-killed the companion server mid-suite (would hit remote CI's dev server the same way on small runners). | Top-level `maxWorkers/minWorkers` in `vitest.config.ts`. | The 884/884 definitive run |

## 5. Incidents (disclosed, recovered, verified)

1. **Dev-server OOM (1×):** during a twin rebuild with dev+twin+build concurrently resident, the
   kernel OOM-killer terminated the preview dev server. Recovered (restart, port 3000 → 200).
   Operational rule recorded: builds never share memory with the runtime workload (matches the
   Dockerfile's isolated builder stage).
2. **F-4 seed misdirection (1×):** a `db:seed` without inline `DATABASE_URL` seeded the main dev DB
   during Agent 4's window (guard found zero users). Principal restored the EXACT seed census
   (31/31 models verified vs a fresh virgin seed) — full timeline in evidence a4-ci/04. The main DB
   ends Phase 6 at exact seed census, re-verified after the final regression.
3. **Sandbox process reaping:** manually-started `next dev` pipelines die at tool-session
   boundaries (observed repeatedly); all CI-parity server+suite work was therefore executed within
   single shell sessions. The platform preview server is restarted and verified healthy at phase end.

## 6. What remains BLOCKED (external — exact owner actions)

1. **Real Docker image build/run + staging-host deployment** — commands prepared and
   statically re-validated against the twin's measured reality (parity table, evidence a1-deploy/11);
   execute `deploy/README-STAGING.md` §C1 on the host (≥8 GB recommended; the compose 4g runtime
   limit is now measurement-anchored).
2. **Remote CI** — owner package in evidence a4-ci/08 (remote creation, push, no-secrets-needed
   confirmation, runner sizing, first-run watch items).
3. **External uptime monitoring + alert channel + offsite backups + systemd timer activation** —
   owner checklists in evidence a6-ops/08 and a2-db/06.
4. **Z.ai cron watchdog:** registry verified EMPTY — the Phase 5 "job 510835 armed" claim does not
   hold against the live registry and appears in no repository file (honest correction recorded in
   the monitoring acceptance report). Recommendation (P6-T5): arm the health-watch on the real
   staging host via systemd, not as a Z.ai job polling a session-scoped twin.

**This report contains no secrets.** Twin credentials live only in `/home/z/asas-twin/secrets/` (mode 600).
