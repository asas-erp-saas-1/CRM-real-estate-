# ASAS CRM — Phase 6 Database & Persistence Report (Staging Twin)

**DRAFT — Principal integration pending**
**Task ID: P6-T2 (Agent 2 — Database, Storage & Disaster Recovery)**
**Date: 2026-11-07 (UTC) · Target: the staging twin at `http://127.0.0.1:3100` (Next 16.1.3 standalone, `NODE_ENV=production`, `ASAS_DEMO_MODE=0`, PID 5828)**
**Evidence directory: `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a2-db/` (6 files)**
**Companion report: `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_BACKUP_RESTORE_REPORT.md` (L3/L5/L6 — backup, restore drill, scheduling, offsite)**

---

## 0. Verdict in one line

**L1 (baseline census & integrity): PASS. L4 (process-replacement persistence): PASS.** The twin's SQLite database lives in durable storage outside the server process (`/home/z/asas-twin/app/db/custom.db`), is fully intact (`quick_check`/`integrity_check`/`foreign_key_check` all clean), and survives a full process replacement (SIGTERM kill → cold boot of a **new** PID) **byte-for-byte** with the synthetic corpus still served by the new process through the real API. The one scope limit is stated honestly: **Docker container replacement + named-volume semantics are environment-BLOCKED** (no Docker daemon in the sandbox); process replacement is the strongest in-sandbox stand-in available.

| Phase | Verdict | One-line result |
|---|---|---|
| L1 baseline census & integrity | **PASS** | health `dbOk:true, migrations:25, demoMode:false`; `quick_check`=ok · `foreign_key_check`=0 rows · census `User=1, Organization=1, AuditLog=2`, all business tables 0 |
| L1 journal mode | **PASS (documented deviation from the brief)** | `journal_mode=delete`, no WAL sidecars — the **documented stack decision** (P0: WAL BLOCKED with Prisma-bundled SQLite 3.46.0), not a defect; the brief's "expect wal" is superseded by the repo's own P0 finding |
| L2 synthetic corpus via real API | **PASS** | 2 leads (`P6-A2 SYNTHETIC Un/Deux`, +213555000011/0012) + 1 task created, all 201, census deltas exactly as expected |
| L4 process replacement | **PASS** | PID 5065 → 5828 (≈4 s downtime); sha256 **identical** pre-stop/while-down/post-start; census identical on all 15 models; both leads + task served by the new process with the **pre-restart session cookie** |
| Docker volume layer | **BLOCKED (environment)** | No Docker daemon in the sandbox; image rebuild / container recreate / named-volume retention cannot be exercised here — see §5 |

---

## 1. Where the data actually lives (L1)

| Item | Value (evidence 01) |
|---|---|
| Database file | `/home/z/asas-twin/app/db/custom.db` (SQLite, 774,144 B baseline, 189 pages × 4096 B) |
| Document storage | `/home/z/asas-twin/app/db/docs/` (empty at L1 — created by the deploy layout) |
| Backup storage (created in L3) | `/home/z/asas-twin/app/db/backups/backup-<stamp>/` |
| Restore drill area (L5) | `/home/z/asas-twin/app/db/restore-drills/<stamp>/` |
| Server boot binding | `twin.sh start` → `DATABASE_URL="file:/home/z/asas-twin/app/db/custom.db"`, `NODE_ENV=production`, `ASAS_DEMO_MODE=0`, session secret from `/home/z/asas-twin/secrets/session-secret.txt` (mode-protected, never printed) |

All of it sits **outside the process tree** — the standalone server (`app/server.js`) is stateless apart from the DB volume: kill it, replace it, the data stays. The twin health endpoint reports the runtime binding live: `{"status":"ok","dbOk":true,"dbLatencyMs":1,"migrations":25,"demoMode":false,"sessionSecretConfigured":true,"nodeEnv":"production"}`.

### 1.1 Baseline census (L1, before any agent writes)

```
organization=1  user=1  lead=0  opportunity=0  project=0  apartment=0  offer=0
reservation=0  payment=0  installment=0  visit=0  task=0  document=0  activity=0  auditLog=2
```

The two AuditLog rows are the **owner-provisioning trail** written by P6-T1's `scripts/provision-owner.ts` (1 OWNER `owner.staging@asas-twin.local` + 1 organization — the documented twin bootstrap state). Everything else is 0: a pristine staging DB, exactly as briefed. "Property" is not a Prisma model in this schema — the inventory domain is `Developer → Project → Building → Apartment`; the census counts `Project` + `Apartment` (both 0).

### 1.2 Integrity (L1)

- `PRAGMA quick_check` → `ok` · `PRAGMA integrity_check` → `ok` (run on a **read-only** `node:sqlite` connection — the same engine class the backup tooling uses)
- `PRAGMA foreign_key_check` → **0 violation rows**
- `PRAGMA journal_mode` → **`delete`** — see §2

### 1.3 Baseline hash (the custody anchor)

```
L1 baseline sha256  011b2b3a6517d8cdbbe99ff0992f0bd12936de5dca9aff2575716c6d2b17bf7e  (774144 B)
```

Every later hash in this mission is explained against this anchor (see §4's chain and the L3 report's chain).

## 2. Journal mode: the honest finding (L1)

The mission brief said "journal mode (expect wal)". **The actual, measured, and documented state is `journal_mode=delete`** — no `-wal`/`-shm` sidecars exist at any point (observed before/during/after every phase, including while the server is running and while it is down). This is not a drift introduced by Phase 6:

- `05_ENGINEERING_DOCUMENTATION/09_P0_FOUNDATION_HARDENING/ASAS_CRM_P0_2_SQLITE_RELIABILITY_REPORT.md` — WAL enablement is **BLOCKED by design**: the Prisma engine bundles SQLite 3.46.0, below the 3.51.3 WAL-reset fix range; no v6 upgrade exists. The runtime mitigation is `busy_timeout=5000` on every connection.
- The backup tooling is **built for exactly this state** (`scripts/lib/backup-run.mjs` consistency notes: "the live DB runs in delete-journal mode … a byte-copy can capture a torn page image; VACUUM INTO instead asks SQLite itself…"). The sidecar story across the L4 stop/start is therefore trivially clean: a transient `-journal` file exists only during a write transaction — none was observed at any checkpoint.

Reported as measured; the brief's expectation is superseded by the repo's own P0 decision.

## 3. L2 — the synthetic corpus (write path under production mode)

Created through the **real REST API** as the owner (login 200, cookie `asas_user` Secure/HttpOnly/SameSite=lax/Max-Age 604800; password read from the secrets file into a shell var, never printed):

| Entity | Marker / payload | Result |
|---|---|---|
| Lead 1 | `P6-A2 SYNTHETIC Lead Un`, `+213555000011`, source WEBSITE | **201**, id `cmw6ojwb70003pwwp0nkb2egl`, score cache born fresh in-tx |
| Lead 2 | `P6-A2 SYNTHETIC Lead Deux`, `+213555000012`, source WEBSITE | **201**, id `cmw6ojwbv0009pwwp9z8zucrc` |
| Task | `P6-A2 SYNTHETIC Task — persistence probe` (FOLLOW_UP, on Lead Un) | **201**, id `cmw6ok4z8000fpwwpiujmmr4j`, owner = Staging Owner |

Census deltas (L1 → L2): `lead +2`, `task +1`, `activity +3` (LEAD_CREATED×2 + TASK_CREATED), `auditLog 2→6` (+1 USER_LOGIN, +2 LEAD_CREATED, +1 TASK_CREATED — the login route audits too). No offers/payments/reservations were created (Agent 5's E2E owns those journeys). Retrieval verified: `GET /api/leads?query=P6-A2` → `total: 2`.

This corpus is the **restorability probe** for the backup/restore lifecycle: if a restored copy contains exactly these rows with these ids, the drill proved real recoverability, not just byte copying.

## 4. L4 — process replacement persistence

The in-sandbox stand-in for container replacement. Sequence (evidence 04):

1. **Pre-stop** state pinned: sha256 `42f06feb…` (the post-L2 hash; see the L3 report for the full chain), census `lead=2 task=1 activity=3 auditLog=6`, no sidecars.
2. **`twin.sh stop`** — SIGTERM (escalation path available, not needed); curl → `connection refused` (exit 7); PID file removed; status `STOPPED`.
3. **While down**: DB file present, byte-identical (`42f06feb…`), **no journal sidecars** (clean delete-mode shutdown leaves nothing behind).
4. **`twin.sh start`** — cold boot of a **new process**: PID 5065 → **5828**, ~1 s to start, total downtime ≈ 4 s (well inside the ≤60 s mission rule).
5. **Post-start, before any authenticated write**: sha256 **still `42f06feb…`**, census **identical on all 15 models**, health `ok / dbOk:true / migrations:25 / demoMode:false`.
6. **The new process serves the old world**: `GET /api/leads?query=P6-A2` with the **pre-restart cookie** → `total: 2` (both synthetic leads, same ids, same `createdAt`); `GET /api/tasks?leadId=…` → the persistence-probe task, `OPEN`.

Point 6 doubles as a session-secret persistence proof: `asas_user` is an HMAC-signed stateless cookie (`src/lib/server/session.ts`, F-02) keyed by `ASAS_SESSION_SECRET`, which the boot reads from the stable secrets file — so cookie continuity across a process replacement is exactly the volume-like behavior the secret file is supposed to have.

**What this proves:** the twin's durability boundary is the filesystem, not the process. A full process replacement (the strongest disruption available in this sandbox) preserves the DB byte-for-byte, the document tree, the backup area, and even session validity.

## 5. What L4 does NOT prove — the honest Docker boundary

**BLOCKED (environment):** Docker container replacement and named-volume semantics. The sandbox has no Docker daemon (P6-T1 documented the same constraint). Specifically NOT exercised here:

- image rebuild / `docker compose up` recreate with a named volume mounted at the DB path (`docker-compose.staging.yml` wiring);
- volume retention across container recreation/deletion (the "does `docker volume rm` eat my data" class);
- container-level crash/restart policy interplay with SQLite file locks.

What the twin *does* model faithfully: the standalone runtime layout (`app/server.js` + traced `node_modules` + `db/` on plain durable storage) is byte-equivalent in shape to the Dockerfile runtime stage (P6-T1's S4 parity table), and a process replacement is the in-process analogue of a container restart without volume loss. The **remaining** untested layer is purely the volume/mount indirection — an owner-run verification item on the real staging host.

## 6. Findings & notes for the Principal

| ID | Severity | Finding |
|---|---|---|
| — | info | **Journal mode is `delete`, not WAL** (measured, and the documented P0 decision with the busy_timeout=5000 mitigation). The Phase 6 brief's "expect wal" should be updated in any downstream mission text. No action needed on the twin. |
| — | info | **Login writes an audit row** (`USER_LOGIN`): any authenticated session adds +1 AuditLog. Census expectations for later agents should account for it (L2: auditLog +4 = login + 2 leads + 1 task). |
| — | info | Session continuity across restarts is *stateless-HMAC* (secret-file persistence), not DB-backed sessions; `RevokedSession` is the governance table, not the session store. Correct per design (F-02). |
| — | none | No defects found in this mission's scope. The one invocation correction (run twin scripts from `app/`, not `build/`) is documented in the companion report §1 — it is a path-derivation fact, not a script defect. |

## 7. Twin state at end of mission

`RUNNING pid=5828 port=3100`, health `ok / dbOk:true / migrations:25 / demoMode:false`, live DB sha256 `42f06feb…` (unchanged since L2 — no phase after L2 wrote to it), census `organization=1 user=1 lead=2 task=1 activity=3 auditLog=6` + zeros elsewhere, backup + drill artifacts on disk. Left healthy for Agents 3–6.

## 8. Evidence index

| File | Content |
|---|---|
| `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a2-db/01-baseline-census-integrity.txt` | L1: health JSON, sidecar listings, sha256, PRAGMAs, full census |
| `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a2-db/02-synthetic-data-api.txt` | L2: login + create transcripts (cookies redacted), retrieval proof, census deltas |
| `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a2-db/04-replacement-persistence.txt` | L4: stop/down/start transcript, hash+census before/after, leads served by the new process |
| (03, 05, 06 are indexed in the companion backup/restore report) | |
