# ASAS CRM — Phase 6 Backup, Restore & DR Scheduling Report (Staging Twin)

**DRAFT — Principal integration pending**
**Task ID: P6-T2 (Agent 2 — Database, Storage & Disaster Recovery)**
**Date: 2026-11-07 (UTC) · Target: the staging twin DB `/home/z/asas-twin/app/db/custom.db` (production-mode server on :3100)**
**Evidence directory: `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a2-db/` (6 files)**
**Companion report: `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_DATABASE_PERSISTENCE_REPORT.md` (L1/L2/L4 — location, integrity, replacement persistence)**

---

## 0. Verdict in one line

**L3 (backup + manifest verification): PASS. L5 (restore drill on a disposable copy): PASS. L6 (scheduling + offsite): PASS on static verification, BLOCKED on activation/execution (environment).** The full Phase 5 backup lifecycle re-verified end-to-end against the **production-mode twin**: VACUUM INTO snapshot with verified integrity and manifest, byte-identical restore drill into the disposable drills area with census match, live DB provably untouched at every step, and the scheduling/offsite artifacts statically verified with the exact owner activation checklist.

| Phase | Verdict | One-line result |
|---|---|---|
| L3 backup run | **PASS** | `bash /home/z/asas-twin/app/scripts/backup.sh` → exit 0, `BACKUP OK`, first-ever twin backup `backup-20261107T173230Z` |
| L3 manifest verification | **PASS** | both artifact sha256+size recomputed independently == manifest; snapshot `quick_check`=ok, `foreign_key_check`=0 rows; snapshot census == pre-backup census (all 15 models) |
| L3 source-unchanged | **PASS** | live DB sha256 `42f06feb…` **identical** pre/post backup (VACUUM INTO never writes the source; mtime unchanged) |
| L5 restore drill | **PASS** | `--drill` → exit 0 + `PASS` line; restored copy **byte-identical** to the snapshot (`81ed5a1c…`); integrity ok ON THE RESTORED COPY; census matches manifest; both synthetic leads + task present with identical row ids |
| L5 original untouched | **PASS** | live DB sha256/census/health/leads identical pre/post drill |
| L5 safety interlock | **PASS** | no-flags invocation → `INTERLOCK REFUSED`, exit 2 (the live-overwrite path stays double-flagged; not exercised, by rule) |
| L6 scheduling | **PASS (static) / BLOCKED (activation)** | timer/service contract consistent with the runner code; `systemd-analyze verify` exit 0; no systemd PID 1 / no staging host to activate on |
| L6 offsite | **BLOCKED (execution)** | §7 procedure references real files/commands; no offsite host, no credentials exist (by design); owner checklist extracted verbatim |

---

## 1. Invocation correction (documented, not a defect)

The runners derive **all** paths from their own file location — `scripts/lib/backup-run.mjs:36` and `restore-run.mjs:41`: `root = <script>/../..` — **not** from cwd and **not** from `DATABASE_URL` (the engine layer, `backup-engine.mjs`, works on bare file paths). Consequences on the twin:

- `build/scripts/backup.sh` → root `/home/z/asas-twin/build` → would target the **nonexistent** `build/db/custom.db`;
- `app/scripts/backup.sh` → root `/home/z/asas-twin/app` → targets **the twin DB** and lands backups in `/home/z/asas-twin/app/db/backups/` ✓.

The correct twin invocation is therefore `bash /home/z/asas-twin/app/scripts/backup.sh` (and `…/restore.sh --drill db/backups/backup-<ts>` with the positional resolved against the same root). The three script copies (main repo, twin `app/`, twin `build/`) are **byte-identical** (`diff -r` verified twice), so this is purely a path-derivation fact of where the script lives — on a real staging host installed at `/opt/asas` per the service header, the layout is exactly `app/`'s. Not a script defect; no source was modified.

`DATABASE_URL` is **irrelevant to both runners by construction** — which also makes the F-4 hazard (sandbox-exported `DATABASE_URL` pointing at the main dev DB) structurally impossible for the backup/restore path. It was still inline-overridden on every `bun`/prisma command actually using it (all censuses), per the hazard rule.

## 2. L3 — the backup and its manifest

Run (full transcript in evidence 03): `bash /home/z/asas-twin/app/scripts/backup.sh` → engine `node:sqlite (Node built-in)` (no sqlite3 CLI in the sandbox — the choice is logged, never silent), runId `e964af1f19bf4f3684eea84cb17e4007`, keep=14, exit 0.

**Artifacts** — `/home/z/asas-twin/app/db/backups/backup-20261107T173230Z/`:

| File | Bytes | sha256 |
|---|---|---|
| `db-20261107T173230Z.sqlite` (VACUUM INTO snapshot) | 765,952 | `81ed5a1c666cf84d3e04f9daaba1f5c4470dc16b48efa9aec3387c87197c0156` |
| `docs-20261107T173230Z.tar.gz` | 108 | `0861d2f373a1c13ff73b095d45f0ffa3966e953da0d033a153af5ac4a8790a42` |
| `manifest.json` | 593 | census `{users:1, leads:2, opportunities:0, reservations:0, apartments:0, documents:0}`, `integrity:"ok"`, both file entries |

**Verification (independent of the script's own code):** both sha256s recomputed with coreutils == manifest entries; sizes match; snapshot opened read-only (`node:sqlite`) → `quick_check`=ok, `foreign_key_check`=0 rows; **full 15-model census of the snapshot == the pre-backup census** (`lead=2 task=1 activity=3 auditLog=6`), taken with a disposable PrismaClient pointed at the snapshot via inline `DATABASE_URL`, with the artifact hashed **before and after** the reads to prove the census itself mutated nothing.

**The consistency law held:** the source live DB hash `42f06feb…` is **identical** before and after the backup (mtime untouched at 17:31:32) — VACUUM INTO writes a brand-new file through a read-only connection; the live file is never opened for writing.

### 2.1 The sha256 chain (every change explained)

```
L1 baseline         011b2b3a6517d8cdbbe99ff0992f0bd12936de5dca9aff2575716c6d2b17bf7e   (fresh staging DB)
  → L2 API writes   42f06febbb77dabacd1cef30740b4314f5e12f772106f01c865fe92b1c687042   (2 leads + 1 task + 3 activities + 4 audit rows — the ONLY writes; census-proven)
  → L3 post-backup  42f06feb…                                                          IDENTICAL (VACUUM INTO never writes the source)
  → L4 post-replacement 42f06feb…                                                      IDENTICAL (process replacement, byte-stable)
  → L5 post-drill   42f06feb…                                                          IDENTICAL (drill writes only under restore-drills/)
snapshot            81ed5a1c666cf84d3e04f9daaba1f5c4470dc16b48efa9aec3387c87197c0156   (765,952 B — VACUUM INTO produces a fresh, compacted,
                                                                                       page-consistent file: byte-different from the live file BY DESIGN;
                                                                                       equality is logical — identical census, integrity ok)
drill restore       81ed5a1c…                                                          IDENTICAL to the snapshot (pure byte-copy, restore-run.mjs:100)
```

The live-file hash changed exactly **once** (L1→L2) and for exactly the L2 API writes; from there it is invariant through backup, process replacement, and the drill — the whole mission.

## 3. L5 — the restore drill (disposable copy)

Semantics were verified by **reading** `restore-run.mjs` before running: `--drill` restores only into `<root>/db/restore-drills/<ts>/`; the live DB is opened only in live mode behind the double interlock (`--confirm-restore` + `--i-understand-this-overwrites-the-live-db`, strict-parsed so a typo is an unknown flag, not a silent bypass). The live-restore path was **not** exercised — the twin DB must never be overwritten in a drill (absolute rule).

Run: `bash /home/z/asas-twin/app/scripts/restore.sh --drill db/backups/backup-20261107T173230Z` → exit 0 with the script's own receipts (manifest artifacts verified → restored copy byte-identical → integrity_check ok ON THE RESTORED COPY → census MATCHES MANIFEST → `original db/custom.db — NOT TOUCHED` → `PASS`).

**Independent verification (evidence 05):**

- restored copy `/home/z/asas-twin/app/db/restore-drills/20261107T173428Z/custom.db` — sha256 == snapshot sha256 (`81ed5a1c…`): the drill is a **pure byte-copy**, not a re-VACUUM (copyFile semantics, `restore-run.mjs:100`);
- read-only open: `quick_check`=ok, `foreign_key_check`=0 rows, `journal_mode=delete`;
- **the actual rows**: `SELECT … FROM Lead` → both `P6-A2 SYNTHETIC` leads with **identical ids/phones/status**; `SELECT … FROM Task` → the persistence-probe task, `OPEN`. The corpus is restorable, not just countable;
- full 15-model census == L2/L3 census exactly; docs tarball extracted (`0 entries` — `db/docs/` is empty);
- **original untouched**: live DB sha256 `42f06feb…` unchanged pre/post drill (mtime untouched), census unchanged, `/api/health` ok, `GET /api/leads?query=P6-A2` still `total: 2`;
- **interlock negative test**: `restore.sh` with no flags → `INTERLOCK REFUSED` + usage, **exit 2** (matches the documented exit-code contract: 0 success / 1 verification failure / 2 interlock refusal).

## 4. L6 — scheduled backup service (static verification; activation BLOCKED)

`deploy/systemd/asas-backup.timer` + `asas-backup.service` (templates; byte-identical copies in the twin's `build/deploy/systemd/`):

| Contract item | Value | Consistency check |
|---|---|---|
| Schedule | `OnCalendar=*-*-* 02:30:00` daily, `Persistent=true` (boot catch-up), `AccuracySec=1min`, no jitter | matches the monitoring assumption "daily 02:30 + slack" (below) |
| Command | `ExecStart=/bin/bash -lc 'bash scripts/backup.sh'` with `WorkingDirectory=/opt/asas` | relative script → `/opt/asas/scripts/backup.sh` → runner root `/opt/asas` → liveDb `/opt/asas/db/custom.db` — **consistent with the runner's script-location derivation** (the §1 correction is the same law) |
| `DATABASE_URL` | **not set by the unit** | **correct by construction**: the runner uses file paths only; the F-4 class hazard cannot reach the scheduled unit |
| Env | `ASAS_BACKUP_KEEP=14`; `ASAS_SQLITE3_BIN` optional (auto-detect, engine logged every run) | matches `backup-logic.mts` `KEEP_ENV_VAR` parsing (strict int ≥ 1, default 14) |
| Safety | `Type=oneshot`; conditions refuse mis-install (`ConditionPathExists=/opt/asas/db/custom.db` etc.); `ProtectSystem=strict` + `ReadWritePaths=/opt/asas/db` (only the DB tree is writable); `NoNewPrivileges`, `PrivateTmp`, `ProtectHome`, `TimeoutStartSec=10min` | least-privilege shape matches "reads the live DB, writes only db/backups + db/docs" |
| Retention | runs **inside** the backup (keep-N + 1 h age guard) — no separate unit | matches `backup-run.mjs` step (e) |

**Static verification (this sandbox has `systemd-analyze` 257):** `systemd-analyze verify` on both units → **exit 0**; the only output is two cosmetic "marked executable" chmod advisories on the repo template files. **Activation is BLOCKED — environment:** no systemd PID 1 in the sandbox and no staging host. The exact owner commands (verbatim from the unit headers):

```bash
sudo cp deploy/systemd/asas-backup.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now asas-backup.timer
systemctl list-timers asas-backup.timer          # confirm NEXT → tomorrow 02:30
journalctl -u asas-backup.service --since today  # each run must end "BACKUP OK →"
```

## 5. L6 — offsite (procedure verified; execution BLOCKED)

Source: `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_DATABASE_BACKUP_RECOVERY.md` §7 (real file, read in full). Design: rsync-over-SSH push of **only complete verified `backup-*/` dirs** (`--include='backup-*/***' --exclude='*'`; the manifest is written last, so a half-written dir is never restorable), offsite rotation 14 daily + 8 weekly + 6 monthly with the same age-guard law (never touch anything younger than 24 h offsite), verification by `integrity_check` + sha256 vs manifest **on the offsite host**, quarterly restore drill, and a >36 h freshness alert. The rsync source path `/opt/asas/db/backups/` is consistent with the service's WorkingDirectory-derived backup root. SSH auth is a restricted forced-command key, operator-provisioned; **no credentials exist in any repo file** (verified claim of §7, consistent with what this mission found).

**BLOCKED — execution:** the destination is a documented placeholder host; there is no offsite host and no staging host in this environment (the rsync binary exists locally, but there is nothing real to push to). Owner checklist (§7, verbatim steps 1–5) is reproduced in evidence 06 §5.

## 6. Retention & backup-age signal (for Agent 6)

- The twin backup dir `/home/z/asas-twin/app/db/backups/` now holds **1 verified backup** (`backup-20261107T173230Z`, manifest `integrity:"ok"`, `keep=14`), age ≈ 0 h at mission end.
- Backup-age monitoring exists as a deployment template: `deploy/monitoring/asas-health-watch.sh` — `BACKUP_DIR` is env-able (`ASAS_HW_BACKUP_DIR`/`ASAS_HW_DB_DIR`); the alarm law: no `backup-*/manifest.json` → `backup_missing` (critical); newest manifest without `"integrity": "ok"` → `backup_integrity` (treated as NO backup); newest backup ≥ `ASAS_HW_BACKUP_MAX_AGE_H` (default **26 h** = daily 02:30 timer + 90 min slack) → `backup_stale` with a remediation hint (`systemctl list-timers`, `journalctl -u asas-backup.service`). On the twin, the monitored path is `/home/z/asas-twin/app/db/backups`. The watchdog itself is a template — not activated in the sandbox.
- Operator-facing retention CLI exists separately (`scripts/retention.ts`: `retention:dry` safe report / `retention:apply --confirm-purge` guarded, fresh-backup gate inside `retentionApply()`) — not part of this mission's drill, not run.

## 7. Defects found

**None.** No script defects surfaced in L3/L5/L6 (both runners exit-0 with receipts matching their documented contracts; interlock refusal exit-code contract verified). The single deviation from the mission text is the §1 invocation correction (path derivation by script location), which is documented and requires **no source change** — the systemd unit already encodes the correct layout.

## 8. Evidence index

| File | Content |
|---|---|
| `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a2-db/03-backup-run.txt` | L3: invocation analysis, pre-backup pinning, full backup output, manifest, independent sha256 table, snapshot integrity + census, hash-chain summary |
| `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a2-db/05-restore-drill.txt` | L5: drill semantics analysis, full drill output, restored-copy independent verification (hash/pragmas/rows/census), original-untouched proof, interlock negative test |
| `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a2-db/06-backup-scheduling-offsite.txt` | L6: timer/service contract analysis, `systemd-analyze verify` output, owner activation commands, offsite procedure verification + BLOCKED checklist, backup-age signal for Agent 6 |
| (01, 02, 04 are indexed in the companion persistence report) | |
