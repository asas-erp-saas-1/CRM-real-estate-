# ASAS CRM — Phase 6 Production Build & Staging-Twin Deployment Report

**DRAFT — Principal integration pending**
**Task ID: P6-T1 (Agent 1 — Staging Host & Container Deployment; session 1 + resumption)**
**Date: 2026-11-07 (UTC) · Repo HEAD under test: `91d91c3` + Principal's D1 fix (src/app/api/documents/[id]/analyze/route.ts; tests/unit/route-export-contract.test.ts)**
**Evidence directory: `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a1-deploy/` (13 files)**

---

## 0. Verdict in one line

**GATE A (C1: first-ever production build + standalone boot + `/api/health`): PASS.** The first-ever production build succeeded (webpack, memory-tripwired, ~73 s), the standalone runtime boots on the twin, the C1 jq health assertion passes (dbOk:true, demoMode:false, migrations:25), the full §3 DB lifecycle had already passed, and login/restart/security-headers/secure-cookie contracts are all verified live. One new process-level finding (F-5) and the standing sandbox constraints remain.

| Leg | Verdict | One-line result |
|---|---|---|
| S1 twin workspace | **PASS** | Isolated copy + hardlinked node_modules; main project bit-identical; dev preview untouched throughout both sessions |
| S2 production build | **PASS (attempt 3)** | Turbopack tripwired (memory); pre-fix webpack failed on D1; post-fix webpack: **success ~73 s**, peak tree RSS 1480 MB, min MemAvailable 525 MB, no trip |
| S3 fresh DB lifecycle | **PASS 4/4** (session 1) | 25/25 migrations · 0 users post-migrate · demo seed refuses · owner provisioned + idempotent + demo-pw refusal |
| S4 runtime assembly | **PASS** | Standalone tree assembled per Dockerfile runtime stage (parity table); Prisma engine IS traced into standalone; DB preserved (sha256 unchanged) |
| S5 posture fail-fast | **PASS with FINDING F-5** | Both gate markers fire and every request 500s — but the process does NOT self-exit in the standalone runtime |
| S6 boot + health gate | **PASS** | Health 200/ok, dbOk:true, migrations:25, demoMode:false; jq assertion exit 0; headers per next.config.ts; idle RSS 141–155 MB |
| S7 login smoke | **PASS** | 200 + OWNER session; cookie: HttpOnly, SameSite=lax, Secure, Max-Age 604800, Path=/ — all five Phase 5 claims verified; 401 without cookie on data routes |
| S8 restart/recovery | **PASS** | TERM-kill → down; twin.sh restart → healthy ~6 s; DB sha256 unchanged by the restart; old cookie still 200 (stateless HMAC sessions); twin LEFT RUNNING |
| S9 docker cross-check | **PASS** | Full parity table vs Dockerfile/compose; findings F-2/F-4/F-5 + two documented divergences |

---

## 1. Decision note — the in-sandbox staging twin (sanctioned approach)

The standing sandbox rule forbids `bun run build` inside `/home/z/my-project` because the live dev
preview server (`next dev -p 3000`, PID 1172, RSS ~1.6 GB) must keep running on a 3.9 GB no-swap
host where the OOM killer historically fired at 2.31/2.55 GB. Phase 6's sanctioned substitute is
the **isolated staging twin** at `/home/z/asas-twin`: a `.dockerignore`-equivalent source copy
with `node_modules` **hardlinked** (`cp -al` — near-zero disk; because the twin never runs
`bun install`/`prisma generate`, nothing ever wrote through the shared inodes), a private secrets
vault (mode 700/600), and its own SQLite home (`app/db/`). The twin executes the project's
first-ever `next build` under a **memory tripwire** (`build/tripwire.sh`, 2 s sampling;
MemAvailable < 350 MB or build-tree RSS > 2000 MB → clean kill of the build tree only). The
tripwire fired once (attempt 1) and did its job exactly: my processes died, the dev server did
not. The dev preview stayed HTTP-200 at every checkpoint of both sessions; `git status` shows
only the `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/` additions (the D1 fix in `src/` and the new regression test are the
Principal's own, pre-existing to this session).

## 2. Environment measurements

| Quantity | Value |
|---|---|
| Host RAM | 4041 MB total, 0 swap, 2 CPUs |
| MemAvailable before builds | ~2.1 GB (dev server ~1.6–2.2 GB resident) |
| Toolchain | Node v24.22.2, bun 1.3.14, Next.js 16.1.3, Prisma 6.19.2 |
| Twin source / node_modules | 9.6 MB / 1.1 GB logical (~0 physical, hardlinks) |
| Standalone build output | 99 MB (+ .next/static 4.2 MB, public 1.8 MB); assembled runtime 106 MB |
| Dev preview during mission | alive at every checkpoint; port 3000 `/api/health` HTTP 200; final RSS ~1.6 GB |

## 3. Build evidence (S2) — three attempts, one success

All from `/home/z/asas-twin/build`, `NODE_ENV=production NODE_OPTIONS=--max-old-space-size=1792`,
double-fork detached, tripwired:

1. **Turbopack (pre-fix): TRIPWIRED (memory), ~26 s.** Compile ✓ 26.4 s, then the TypeScript
   phase spiked to **1993 MB tree RSS / 101 MB MemAvailable** → tripwire killed the tree.
2. **webpack (pre-fix): exit 1 (code), ~55 s.** Tripwire quiet (562 MB / 1517 MB). Compile ✓,
   then the D1 failure: `"KNOWN_FIELD_KEYS" is not a valid Route export field`
   (`src/app/api/documents/[id]/analyze/route.ts:49`). tsc proved it was the codebase's only
   type error. **Fixed by the Principal** (un-export the const; regression test
   `tests/unit/route-export-contract.test.ts` 2/2).
3. **webpack (post-fix): SUCCESS ~73 s.** `✓ Compiled successfully in 34.8 s` → 52/52 static
   pages (868 ms) → traces → full route table. Tripwire: **min MemAvailable 537768 KB (525 MB),
   peak build-tree RSS 1514904 KB (1480 MB), tripped=0**. Standalone `server.js` + traced
   node_modules (incl. `libquery_engine-debian-openssl-3.0.x.so.node` + `schema.prisma`)
   produced. Non-fatal warnings: `module.createRequire failed parsing argument` for
   `src/lib/db.ts` import traces (Prisma-under-webpack, F-2).

**Bundler decision (authorized divergence, documented):** the twin build ran `--webpack`
(Principal-authorized sandbox adaptation — Turbopack does not fit this 4 GB host beside the dev
server). The repo Dockerfile is untouched and keeps the Turbopack default, valid for the ≥8 GB
target host; the measured ~2 GB Turbopack build floor now underwrites that recommendation.
Both bundlers compile this codebase.

## 4. Database lifecycle evidence (S3 — session 1, not repeated)

Fresh twin DB with explicit inline `DATABASE_URL` (F-4 defense): **25/25 migrations applied**
(= 25 dirs on disk = Phase 5's claim); zero users post-migrate; demo seed refuses under
production (exit 1, zero writes); owner provisioned via the sanctioned C4 path (exit 0, password
never echoed; second run → exit 1 CONFLICT; `--password asas1234` → exit 1 REFUSED). Final
census: 1 OWNER (`owner.staging@asas-twin.local`) + 1 org. **This DB survived the build, the
assembly, the boots and the restart of this session byte-for-byte when no application write
occurred** (sha256 in evidence 10).

## 5. Runtime assembly (S4) — Dockerfile parity

Flat-layout mirror of the runtime stage into `/home/z/asas-twin/app` (full parity table in
evidence 11): standalone tree → `app/`, `.next/static` → `app/.next/static`, `public/` →
`app/public`, `scripts` + `package.json`/`bun.lock`/`prisma` copied for parity (the ops
node_modules role is served by `twin/build/node_modules`, from which all S3 ops ran). The
container's `/app/db` symlink bridge is layout-equivalent to the twin's real `app/db` dir
(`server.js` chdirs to its own directory in both models). **The S6 risk item is closed: the
Prisma query engine is traced into standalone by Next itself — `dbOk:true` on first boot; the
Dockerfile needs no special engine handling.** Two documented divergences: `.env` rides along in
the twin's standalone output (dockerignored in-image; values identical to the inline env) and
port 3100 instead of the dev-preview's 3000.

## 6. Posture fail-fast (S5) — PASS with finding F-5

On the REAL standalone runtime (port 3101, process-env only — `app/.env` stashed during tests):
- `ASAS_DEMO_MODE=1` → boot gate marker `[DEMO_MODE_PRODUCTION]` fires verbatim.
- `ASAS_SESSION_SECRET` unset → `[SESSION_SECRET_MISSING]` fires verbatim.
- In both cases **every HTTP request answers 500 "Internal Server Error"** — the misconfigured
  server never serves app state; the demo quick-login chain is NOT reachable (probed).
- **F-5 (real finding):** the process does **not** exit on its own — Next 16.1.3's standalone
  `start-server` swallows the instrumentation rejection (log: `Failed to prepare server` +
  `⨯ unhandledRejection`); the process stayed alive ≥20 s and required an external kill. This
  contradicts `src/instrumentation.ts:5-7`, `deploy/README-STAGING.md:90-92` ("the process
  crashes on purpose") and `:290` (§9 "Container exits immediately"). Docker impact: with
  `restart: unless-stopped` (exit-triggered only), a misconfigured container would sit
  **alive-but-unhealthy** forever (healthcheck 500s → probe fails) instead of crash-looping.
  Security impact contained (nothing serves), but the runbook's troubleshooting row and the
  restart-policy assumption need a Principal decision (see §12).

## 7. Clean boot + health gate (S6) — C1 boot/health legs PASS

Boot (all env inline, double-fork detached): `PORT=3100 HOSTNAME=127.0.0.1 NODE_ENV=production
ASAS_DEMO_MODE=0 ASAS_SESSION_SECRET=… DATABASE_URL=file:/home/z/asas-twin/app/db/custom.db
node server.js`. First health response ~9 s after launch:

```json
{"status":"ok","dbOk":true,"dbLatencyMs":3,"migrations":25,"demoMode":false,
 "demoModeMisconfigured":false,"sessionSecretConfigured":true,"uptimeSec":5,
 "nodeEnv":"production","rssMb":144,"checkedAt":"2026-11-07T17:14:27.595Z"}
```

- README-STAGING §2d/§3 assertions: `jq -e '.dbOk == true and .demoMode == false'` → PASS; with
  `.migrations == 25` → PASS. **C1 is satisfied end-to-end: build exits clean, standalone boots,
  health gate green.**
- Process proof: launched by this agent as `node server.js`; `/proc/<pid>/exe` = `/usr/bin/node`;
  production-only response headers (`x-nextjs-prerender`, `s-maxage=31536000`) — `next dev` never
  emits them. (Next overwrites the process title to `next-server (v16.1.3)`; twin.sh's ownership
  check was hardened accordingly — F-6.)
- Security headers on `/`: `X-Content-Type-Options: nosniff`, `Referrer-Policy:
  strict-origin-when-cross-origin` — exactly the next.config.ts W1.3 set (CSP/XFO deliberately
  deferred to the Caddy edge; `X-Powered-By: Next.js` present at default — observation).
- Startup log: 5 lines (`✓ Ready in 117ms`) — standalone boots are quiet. dbLatencyMs 1–3 ms.

## 8. Login smoke (S7) — all five secure-cookie claims verified live

`POST /api/auth/login {email,password}` → **HTTP 200** with the OWNER session; Set-Cookie:

```
asas_user=***REDACTED***; Path=/; Expires=Sat, 14 Nov 2026 17:15:23 GMT; Max-Age=604800; Secure; HttpOnly; SameSite=lax
```

| Claim (Phase 5 / login/route.ts:33-42) | Measured |
|---|---|
| httpOnly | ✓ |
| sameSite=lax | ✓ |
| path=/ | ✓ |
| secure (production) | ✓ (correct HTTPS-only posture; plain-HTTP curl inspection only) |
| maxAge 7 d aligned with SESSION_MAX_AGE_MS | ✓ (604800 s; Expires = login + 7 d) |

Auth gates: WITH cookie → `/api/auth/session` 200 (user+org+session windows), `/api/leads` 200;
WITHOUT cookie → `/api/leads` 401 `NO_SESSION`, `/api/metrics` 401 (`/api/auth/session`
returning 200 `{user:null}` is the app's anonymous-safe bootstrap convention — recorded
honestly, not a gate violation). `GET /` → 200 HTML, French UI, 10 535 bytes. No password or
cookie value appears in any artifact (secret-scan: 0 hits).

## 9. Restart / recovery (S8) — Journey I core verified

- sha256(custom.db): `bd5b86db…` BEFORE (live) = POST-shutdown = AFTER restart (before any new
  login) — **the restart itself mutates nothing**. (Post-new-login hash differs only by the
  audited LOGIN row — expected application write.) No `-wal`/`-shm` sidecars at any checkpoint.
- `kill -TERM` → process gone in ≤3 s, port dead; `/home/z/asas-twin/twin.sh restart` →
  **healthy again ~6 s** (status RUNNING, health ok/dbOk/migrations:25).
- **Old-cookie replay: HTTP 200** (actual behavior) — sessions are **stateless HMAC-signed
  cookies** (`${userId}.${issuedAtMs}.${sig}`), neither process-memory nor DB-backed: they
  survive restarts while the secret is unchanged. Positive for user continuity; invalidation
  happens only via secret rotation or the 7-day absolute window (`.env.staging.example:39-42`
  documents this correctly).
- Census constant: users=1, orgs=1. RSS post-restart: 155 MB. **Twin left RUNNING on 3100.**

## 10. Memory analysis vs compose `mem_limit: 4g`

- **Runtime (first-ever production reading):** boot 141 MB → idle 129–146 MB → post-restart
  152 MB. That is ~3–4 % of the 4 g limit, and ~12× leaner than the dev-server class
  (2.0–2.5 GB). The README's re-sizing rule (≈1.5–2× steady-state after load-bearing
  measurement) still stands — this is an idle-only reading on a traffic-less twin; caches grow
  under load. On today's evidence 4 g is a generous ceiling, not a risk.
- **Build time (host memory, outside the container limit):** webpack peak tree RSS **1480 MB**
  (min MemAvailable 525 MB); Turbopack peak **1993 MB** (101 MB floor with the dev co-tenant).
  The ≥8 GB host recommendation is now backed by a measured build floor of ~2 GB transient.

## 11. Docker parity summary (full table: evidence 11)

Verified green by execution: builder-stage flow (modulo hardlink/bundler divergences below),
runtime-stage copy contract, Prisma-engine presence in standalone, healthcheck contract vs the
real endpoint, volume layout equivalence, restart policy equivalence (TERM-kill recovery),
env contract (.env.staging.example keys = exactly what the runtime requires). Findings:
- **F-5** (§6) — process-level fail-fast does not hold in the standalone runtime; compose
  restart never fires for misconfigured boots; runbook §2c/§9 rows are inaccurate for this
  Next version.
- **F-2** — webpack build warnings (`module.createRequire failed parsing argument`,
  src/lib/db.ts traces): cosmetic, Prisma-under-webpack pattern.
- **F-4** — sandbox shell exports a main-project `DATABASE_URL`; Prisma env-precedence
  misdirects bare prisma commands (first-session attempt was read-only; main DB untouched —
  mtime predated the session). Defense: inline `DATABASE_URL` everywhere (container immune via
  env_file). Suggested one-line runbook hardening for any sandbox-side DB operation.
- **F-6** — twin.sh pid-ownership check hardened for the Next process-title overwrite (twin-only
  script; no repo files involved).
- Documented divergences (no action): twin `--webpack` vs Dockerfile Turbopack (authorized,
  memory-driven); `.env` present in twin standalone output vs dockerignored in-image; port
  3100 vs 3000; ops node_modules via hardlink vs in-image prod install.

## 12. Honest BLOCKED list & decisions for the Principal

Blocked by sandbox reality (not by code):
1. **Real `docker build`/`docker run`** of the Phase 5 image (no docker daemon) — the twin
   verified every leg the image would execute except the image assembly itself.
2. **External staging host** — none exists; C1's "on the staging host" form happens on the real
   host when provisioned.
3. **Load-bearing runtime RSS** (idle-only reading recorded) and the document-upload volume
   round-trip drill (fresh DB has no documents; out of P6-T1 scope).

Decisions requested:
1. **F-5 disposition** — accept "alive-but-unhealthy + external C1 gate" as the failure mode
   and correct `deploy/README-STAGING.md:90-92,:290` + `src/instrumentation.ts:5-7` comments,
   or harden the gate to force process exit (e.g. `process.exit(1)` in the catch path — an app
   change I did not make per contract). Also consider a compose healthcheck addition
   (`disable: false` is default; an explicit `autoheal`-style supervisor is out of scope).
2. Optional runbook line for sandbox-side DB ops (always inline `DATABASE_URL`) per F-4.
3. Whether to note the webpack-warnings (F-2) anywhere if the team ever pins `--webpack`.

## 13. Twin status & handoff

- **RUNNING**: production standalone server on `127.0.0.1:3100` (launched via `twin.sh`;
  health ok, dbOk, migrations 25, demoMode false). Control:
  `/home/z/asas-twin/twin.sh {status|start|stop|restart|logs}` — idempotent, pid-ownership
  verified (title-overwrite aware), all env inline (immune to the shell's main-DB export).
- Twin DB ready for later agents: 25/25 migrations, 1 OWNER (`owner.staging@asas-twin.local`;
  password at `/home/z/asas-twin/secrets/owner-password.txt`, mode 600), 1 org.
- Dev preview: untouched across both sessions (PID 1172, port 3000, HTTP 200; final RSS ~1.6 GB).

*No secret values appear in this report or any evidence file. All artifacts (report + 13 evidence
files) were secret-scanned for the session secret and owner password: 0 occurrences.*
