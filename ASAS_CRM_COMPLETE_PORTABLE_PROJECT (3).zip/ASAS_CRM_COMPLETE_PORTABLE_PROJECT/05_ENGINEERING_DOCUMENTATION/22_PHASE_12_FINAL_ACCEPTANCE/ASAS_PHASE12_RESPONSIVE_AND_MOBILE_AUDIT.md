# ASAS Phase 12 — Responsive & Mobile Audit

Targets: 390 / 768 / 1024 / 1440. Policy: operational lists transform to card twins; reference tables scroll; field view is mobile-first.

## Verified strong
Leads/inbox/sav/finance mobile card twins; lead drawer mobile tab bar + 4-verb bottom action bar (safe-area); field agenda + execution sheet (one-handed, ≥44px, Maps one-tap); kanban stacked ladder + per-card move-select at h-11; shell mobile Sheet nav; .crm-hit 24/44px touch floors; mobile lang switch h-11.

## Defects corrected this phase
- Unit table min-w-[52rem] at 390px ≈ 5 screens sideways (T56: force grid/cards on mobile).
- Login language cells 28×36px below 44px floor (T68).
- Kanban mini-map hidden <md where ladder is longest (accepted — stacked ladder is the mobile surface).
- Visits toolbar ~10 controls at 390px (accepted wrap; grouping deferred).
- Field agenda ±30d window (accepted scope).
