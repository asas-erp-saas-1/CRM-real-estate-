# ASAS Phase 12 — Page-by-Page Design Decisions (approved)

- **All views:** forest-green brand tokens; status chips on attn/state tokens; single primary-hover idiom; text-crm-control on forms; panel headers text-crm-section.
- **Shell:** CTA permission-gated; nav generic aria-label; notifications complete the isolate contract.
- **Dashboard:** overdue group in hero; composite follow-up cell; stalled + inventory + pending-offers cells; management KPI drill-downs; conversion label split.
- **Leads:** toolbar de-duplicated (one create CTA); reset-all via existing saved-search reset idiom; numeric alignment right.
- **Inbox:** truthful DB counts; urgency ordering; agent claim documented deferred.
- **Pipeline:** workspace-store persistence; summary pending-offers chip; opportunity cockpit promoted to 2xl Sheet drawer with sticky tabs.
- **Visits:** lifecycle dialogs consolidated (deferred — 9 dialogs stay, decision vocabulary already consistent); FIELD_REP hidden from nav.
- **Tasks:** quick-add linking deferred (documented); overdue group remains the sort.
- **Properties:** unit table mobile grid force; apartment detail widened to 2xl; wizard validation surfaced + dirty guard.
- **Finance:** PAID attn-3; byProject table; agent scoped mode; MoneyField; count disclosure.
- **SAV:** truncation banner; single ErrorState; bucket state persisted.
- **Analytics:** honest cycle metric; distinct conversion labels; empty-state-before-zero-wall; range grammar unified where touched.
- **Audit:** zebra added; entity resolver scope documented.
- **Settings:** role options filtered by actor; sections unchanged (read-only below MANAGER preserved).
- **Field:** REJECT outcome; default landing.
- **Login:** lang cells 44px; hover = border shift; glows token-based.
