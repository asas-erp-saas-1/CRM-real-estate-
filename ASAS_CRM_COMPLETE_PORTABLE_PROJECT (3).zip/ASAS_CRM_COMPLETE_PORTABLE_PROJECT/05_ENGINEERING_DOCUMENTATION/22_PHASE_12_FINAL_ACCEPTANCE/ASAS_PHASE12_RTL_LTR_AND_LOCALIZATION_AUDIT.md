# ASAS Phase 12 — RTL/LTR & Localization Audit (from A6)

Grades: RTL A · i18n A. 

## RTL (near-exemplary — keep)
Logical utilities convention (43+ sites); CSS glyph mirroring of 14 directional lucide glyphs under [dir=rtl]; double-flip guard comments; pre-paint dir script kills Arabic LTR-FOUC; Sheet side + Toaster position flip. Fixes this phase: ml-1→ms-1 bidi offender (T66); diagonal attribution arrows accepted (cosmetic).

## Localization
24 domains ~2,779 keys, 0 fr/en/ar mismatches (load-time parity guard + tests); zero hardcoded strings in 158 files; ar-DZ conventions (Latin digits, DA/دج, h23 clock, Algerian months, 6-form plurals). Fixes this phase: domains/customers.ts wired into index (T62 — 48 dead keys, guard blind); journey urgency enum keys (T69); retargeting-hydra slug accepted neutral.
