# ASAS Phase 12 — Information Architecture

## Current structure
NAV_SECTIONS: Commercial(field, dashboard, journey, leads, inbox, pipeline, visits, tasks = 8) · Opérations(properties, finance, sav, analytics = 4) · Administration(audit, settings = 2). Per-role top-level: OWNER/ADMIN/MANAGER 13 · SALES_AGENT 10 · FIELD_REP 8.

## Approved target (T20)
- **Commercial** (lifecycle order): dashboard, inbox, leads, journey, pipeline, visits, tasks — intake→book→worklist→deals→day-work.
- **Opérations**: properties, finance, sav.
- **Pilotage**: analytics, audit, settings — measurement + governance cluster.
- `visits` gains `hideFor: [FIELD_REP]` (single visit console for field reps); `field` stays FIELD_REP-exclusive; role labels preserved.

## Rules adopted
1. One primary navigation per module; related functions grouped (campaigns stay in Settings as registry; attribution analytics in Pilotage).
2. Nav never shows inaccessible destinations (permission floor + showFor/hideFor mirror server gates — verified lockstep).
3. Record context is preserved through overlays (drawer/focus tokens), not page navigation.
4. Section titles: ≤8 items per section (7±2 law).
5. Global chrome carries exactly one global CTA (permission-gated) + search + notifications + lang/theme/profile.

## Deferred IA decisions (owner product call needed)
- journey/leads/inbox merge (three lenses over one record set — reordering ships now, merge needs product decision).
- Full hash addressability for opportunities/visits/apartments (architecture change).
- Reservations worklist + pending-approvals worklist (new surfaces).
