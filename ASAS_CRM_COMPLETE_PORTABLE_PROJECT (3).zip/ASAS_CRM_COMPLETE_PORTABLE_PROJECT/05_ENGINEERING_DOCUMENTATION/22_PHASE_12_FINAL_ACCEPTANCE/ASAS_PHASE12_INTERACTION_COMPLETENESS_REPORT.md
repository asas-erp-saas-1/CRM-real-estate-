# ASAS Phase 12 — Interaction Completeness (no dead buttons)

Every visible action audited across 14 views + ~45 overlays. Findings:

## Reliably-failing controls (fixed this phase)
- Global "Nouveau prospect" CTA + palette create render for FIELD_REP without leads.create → 403 every time (T25: permission-gated).
- OWNER-role select option offered to ADMIN → guaranteed 403 ROLE_CEILING post-submit (T33: filtered by actor rank).

## Dead-end metrics (fixed this phase)
- MANAGEMENT_KPIS row display-only (T36 drill-downs); myPendingReservations (T46); analytics dead-ends get definitions instead of fake affordances (T30/T31); LEADS_UNASSIGNED notification → unfiltered landing (T23).

## Dead code (removed this phase)
view-placeholder.tsx, pipeline/lost-reason-dialog.tsx, pipeline/correction-reason-dialog.tsx (zero importers).

## Verified honest (no action)
No fake-success paths; every mutation toasts real server outcomes; silent failures none (clipboard exception documented); display-only KPIs are deliberate honest-surface law (no fake affordance); destructive confirms thorough; 403 lock screens honest.

## Paper-only backend capabilities (documented, deferred T39)
sessions.revoke_others (no enforcing route), metrics.view (no UI consumer) — owner visibility recorded in final report.
