# ASAS Phase 12 — Accessibility Report (WCAG 2.2 AA target)

## Verified strong
Skip-link + main#main; 62/62 named icon buttons; focus-visible rings (256 sites); keyboard kanban (role=button + Enter/Space + KeyboardSensor DnD); aria-sort table headers; text-labeled status badges (never color alone); one-h1 law; sr-only dialog titles; radiogroups done right in 2 of 3 sites.

## Defects corrected this phase
- T60: ~30 text sites at 1.9–3.8:1 via text-muted-foreground/40–80 (both themes, mostly 10–11px) → full token.
- T63: dark primary-on-tint chips 3.6:1 → lighter dark primary (0.72 emerald).
- T61: 32 unassociated Labels → htmlFor/id.
- T64: "—" button name → aria-label.
- T65: assign-dialog radios → radiogroup wrapper + label.
- T67: sr-only table captions on main tables.
- T68: login lang cells → ≥44px.
- T3: 9.5px print text → 10px floor.

## Remaining accepted risks (documented)
Queue-chips tablist lacks roving arrow keys (individual tabs focusable); dark muted-on-card 4.83:1 headroom rule (no future tone overlays without re-check); h-7 text buttons pass 2.5.8 AA but sit below internal 44px design floor (design-system §10).
