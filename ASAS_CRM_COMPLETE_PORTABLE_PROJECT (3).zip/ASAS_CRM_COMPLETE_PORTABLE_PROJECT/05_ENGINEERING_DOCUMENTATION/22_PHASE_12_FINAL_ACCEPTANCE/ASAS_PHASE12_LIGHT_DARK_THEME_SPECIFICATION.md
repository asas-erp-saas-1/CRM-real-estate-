# ASAS Phase 12 — Light/Dark Theme Specification

Both themes share ONE component architecture (next-themes, class strategy, light default, no system preference).

## Light theme
Warm off-white background (oklch 0.985 0.003 85), clear white cards/popovers, deep forest green primary actions, restrained champagne/gold accents, hairline borders, whisper shadows, clearly visible status washes (attn tiers).

## Dark theme
Warm charcoal background (oklch 0.17 0.005 80), elevated charcoal surfaces, light emerald primary (oklch 0.72 0.13 160 — text-safe ≥4.5:1 on tinted chips, fixes the 3.6:1 dark primary-on-tint defect T63), no pure-black surfaces, alpha borders, controlled emerald accents, muted-foreground kept ≥4.83:1 on card with headroom rule (text never at opacity <100%).

## Laws
1. Token parity is complete — every themeable token defined in both :root and .dark (verified diff: only theme-invariant --radius/--font-arabic-stack differ).
2. No component ships light-only/dark-only classes; print documents are the sanctioned exception (paper pinned light, hue-law aligned).
3. Theme switch preserves preference (next-themes localStorage).
4. Charts use --chart-1..6 in both themes (chart-1 re-tasked to forest green family).
5. Sidebar is theme-invariant charcoal with emerald active accent in both themes.
