# ASAS Phase 12 — Browser Evidence

All evidence captured this session against the **real running Preview**
(agent-browser, dev server healthy, 30 migrations, seeded demo workspace).
Earlier-session Wave 1–3 evidence (before/after pairs, wave1 brand shots)
lives alongside in `evidence/phase12/`. This file records the **Wave 4 final
acceptance set**: `evidence/phase12/wave4/`.

## Console / page health
- `agent-browser errors` → empty; console error count → **0** across the
  matrix pass.

## OWNER (nadia@asas.dz — credential login verified, HTTP 200)
| Evidence | Conditions |
|---|---|
| `owner-dashboard-fr-light-desktop.png` | desktop 1440, FR, light |
| `owner-notifications-open.png` | bell open — groups, mark-all-read, deep-links |
| `owner-leads-filtered-fr-light.png` | attention-cell drill-down → `#/leads` + active filter chip |
| `owner-lead-drawer-fr-light.png` | lead workspace drawer — 14 actions, journey rail, tabs |
| `owner-search-palette.png` | global search combobox + create action |
| `owner-pipeline-fr-light.png` | kanban — real stages/counts |
| `owner-kanban-stage-advance.png` / `owner-kanban-after-advance.png` | stage advance: recommendations dialog → confirm → toast |
| `owner-pipeline-ar-rtl-light.png` | **AR RTL** (`dir="rtl"` verified) |
| `owner-pipeline-ar-rtl-dark.png` | AR RTL + **dark** (`class="dark"` verified) |
| `owner-dashboard-ar-rtl-dark-mobile390.png` | **mobile 390** + AR + dark |
| `owner-mobile-nav-drawer-ar.png` | mobile hamburger nav drawer |
| `owner-visit-scheduled.png` | visit scheduling flow result (`Planifiée`) |
| `owner-finance-fr-light.png` / `owner-finance-payment-recorded.png` | finance + payment recorded (**DB 8→9 verified**) |
| `owner-settings-saved.png` | settings save (toast + clean state) |
| `owner-settings-en-ltr-light.png` / `owner-dashboard-en-ltr-light.png` | **EN LTR** full translation |

## MANAGER (sarah@asas.dz)
| `manager-dashboard-fr-light-desktop.png` | team view, Journée de l'équipe, Objectifs nov. 2026 |

## ADMIN (karim@asas.dz)
| `admin-dashboard-fr-light-desktop.png` | admin scope, Patrimoine |

## SALES_AGENT (amine@asas.dz)
| `sales-dashboard-fr-light-desktop.png` | agent cockpit: Commissions, scoped nav (Ma journée / Mes prospects / Mon pipeline) |
| `sales-dashboard-fr-light-mobile390.png` | mobile 390 |

## FIELD_REP (mounia@asas.dz — the mobile-first experience)
| `field-landing-fr-light-mobile390.png` | **T22 boot default: Espace terrain** (cleared-hash reload) |
| `field-visit-sheet-fr-mobile.png` | visit execution: checklist, no-show/cancel/reschedule, report + photos |

## Interaction outcomes (V3 — each verified with real persistence)
1. Credential login 200 + persona quick-login ×6 (all 5 roles exercised).
2. Nav switching across Commercial/Opérations/Pilotage.
3. Lead drawer open/close with full action set.
4. Kanban stage advance (dialog → toast; card stage changes).
5. Visit scheduling (prospect/project/date form → 201 → `Planifiée` in list).
6. Finance payment record (dialog → DB payment count 8→9, amount exact).
7. Settings save (Enregistrer enables on change → toast `Politiques enregistrées` → disabled again).
8. Search palette (combobox typing, create action present).
9. Notifications (bell → groups → attention cell → filtered leads view).

## Matrix honesty
The exhaustive 5×2×3×2 (60-cell) matrix was covered **on key pages** per the
backlog V2 wording; the cells above span every role, both viewports, all
three languages, and both themes. Native deployment remains a separate,
unresolved owner-side issue (see Deployment Blocker Status).
