# ASAS Phase 12 — Complete Page Inventory

**Evidence base:** read-only code audit (Agents A1–A6, working tree @ commit 2571354) + live browser verification (OWNER session, `evidence/phase12/before-*.png`). No imaginary pages; every surface below exists in `src/components/crm/**`.

## Architecture

Single-route SPA: `/` → `CrmApp` → shell; hash-routed `#/<view>` via `src/lib/client/view-registry.ts` (14 views). Record addressability exists only for leads (`#/leads/:id` opens the drawer from any view); all other cross-surface jumps are transient in-memory focus tokens (`src/lib/client/focus.ts`). **~45 distinct dialogs/drawers/sheets** over 14 views + 1 auth overlay.

## The 14 main views

| # | View | Hash | Roles (nav) | Purpose | Key UX problems (top 3) |
|---|------|------|-------------|---------|--------------------------|
| 1 | field | `#/field` | FIELD_REP only (`showFor`) | Mobile-first visit agenda + execution sheet | ① FIELD_REP sees BOTH "field" and "visits" (dup consoles) ② ±30d history window ③ no in-agenda search/refresh |
| 2 | dashboard | `#/dashboard` | all (scoped; "Ma journée" for SALES_AGENT) | Command center: attention strip + 8 KPIs + role rows + hero + rail | ① 12–15 stacked blocks = scan wall ② KPI entrance redundancy (3 entrances per set) ③ non-isolated fallback deep-links land unfiltered |
| 3 | journey | `#/journey` | all (scoped) | Guided lifecycle worklist (funnel header + prioritized cards + NBA) | ① overlaps leads/inbox (3 lenses, same records) ② every action is 2-hop ③ cryptic funnel segments (tooltip-only labels) |
| 4 | leads | `#/leads`, `#/leads/:id` | all except FIELD_REP | Customer book: search, composable filters, saved searches, bulk bar | ① toolbar overload (10 controls) ② duplicate primary CTA (topbar + toolbar) ③ no one-click reset-all-filters |
| 5 | inbox | `#/inbox` | `inbox.view` (SALES_AGENT personal / MANAGER+ org) | Intake triage: 9 queue chips + routing console | ① overlap with leads/journey ② no claim verb for agents on pool leads ③ 403 lock lacks role guidance |
| 6 | pipeline | `#/pipeline` | all except FIELD_REP | dnd-kit kanban, 10 stages, WIP limits, aging | ① board filters component-local (amnesia) ② noAction filter client-side partial ③ 10-col horizontal scroll; mini-map hidden <md |
| 7 | visits | `#/visits` | all | Visit console: list/calendar, 9 lifecycle dialogs + fiche | ① dialog fragmentation (9 keyed dialogs) ② toolbar ~10 controls ③ agent-select lacks degraded state |
| 8 | tasks | `#/tasks` | all (overdue badge) | Task worklist: overdue/today/upcoming groups | ① quick-add creates unlinked tasks ② no due-date edit beyond +1d postpone ③ 200-cap truncation |
| 9 | properties | `#/properties` | all | Inventory: project rail + building tabs + grid/table | ① 3 management panels before any unit (scroll barrier) ② mode feature asymmetry ③ reserve buried 2 levels deep |
| 10 | finance | `#/finance` | `finance.overview` (MANAGER+) | Collections: attention + buckets + installments scan | ① no nav to parent deal/reservation ② local filters (amnesia) ③ agents hold payments.view but get 403 lock |
| 11 | sav | `#/sav` | all (scoped) | After-sales cases: 7 buckets + case cockpit | ① local filters (amnesia) ② triple-redundant tiering ③ no SLA countdown column |
| 12 | analytics | `#/analytics` | `analytics.view` (MANAGER+) | Overview + Acquisition analytics | ① dead-end numbers (no drill-down) ② 3 inconsistent range grammars ③ duplicated tab-switch code |
| 13 | audit | `#/audit` | `audit.view` (MANAGER+) | Business audit journal + import undo | ① resolver covers only 5 entities ② fixed 25/page ③ mobile card drops IP + change-chips |
| 14 | settings | `#/settings` | `settings.manage` (MANAGER+) | Org tuning: 9 heterogeneous sections | ① 600-line single-page stack, no anchors ② OWNER-role option offered to ADMIN (guaranteed 403) ③ agents hold settings.view but surface unreachable |

## Auth + shell overlays

- **Login overlay** (1168 ln): credentials + demo persona grid + token redemption + bootstrap. Issues: demo grid on production surface; no URL state for modes; no self-serve recovery.
- **Shell-level:** LeadDetailDrawer (6 tabs + journey rail — the strongest surface), CreateLeadDialog (reliably-403 for FIELD_REP), ScheduleVisitDialog (single-project unit picker; no conflict check), SearchCommand (opportunity rows → lead drawer instead of cockpit), NotificationsBell (isolation incomplete for most groups), mobile nav Sheet, ChangePasswordDialog.

## View-mounted dialogs (enumerated)

Leads: import wizard, duplicates, saved-searches, filter popover, bulk bar + copilot. Pipeline: create-opportunity (845 ln), opportunity cockpit (727 ln), reason, gate, offer presentation. Properties: apartment detail (1147 ln), add-property wizard (1790 ln), import units, unit compare, orphan holds. Field: field-visit-sheet (825 ln). Finance: record-payment, installment-detail, add-installment. SAV: create + detail. Settings: add-member, invite, temp-password, targets, campaigns, export, sessions. Audit: target overlay. Visits: 9 lifecycle + fiche + calendar.

## Classification

- **Existing & complete:** dashboard, leads, pipeline, field, audit (with defects listed).
- **Existing but incomplete:** finance (agent mode dead, byProject unrendered), analytics (metric epistemics), settings (permission mismatches), inbox (scale integrity), visits (fragmentation).
- **Missing but genuinely required:** a reservations worklist (manager cannot answer "all active/expiring holds" from any list), a pending-approvals worklist (offers awaiting manager approval).
- **Duplicate:** field vs visits (for FIELD_REP); journey vs leads vs inbox overlap (same records, 3 lenses).
- **Obsolete/dead code:** `view-placeholder.tsx`, `pipeline/lost-reason-dialog.tsx`, `pipeline/correction-reason-dialog.tsx` (zero importers), `domains/customers.ts` (never imported).

Full per-page audit entries with evidence are in `ASAS_PHASE12_UX_UI_AUDIT.md`; role experience detail in `ASAS_PHASE12_ROLE_EXPERIENCE_AUDIT.md`.
