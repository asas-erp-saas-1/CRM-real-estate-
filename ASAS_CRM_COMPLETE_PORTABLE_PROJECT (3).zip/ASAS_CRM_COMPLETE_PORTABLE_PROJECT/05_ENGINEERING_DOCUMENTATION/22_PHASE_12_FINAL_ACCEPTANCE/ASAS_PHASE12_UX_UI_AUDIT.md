# ASAS Phase 12 — UX/UI Audit (consolidated, evidence-based)

Sources: Agent A1 (IA), A2 (visual), A3 (management), A4 (sales/field), A5 (tables/forms/dialogs), A6 (a11y/i18n). Full agent transcripts distilled; file:line evidence preserved. Severity: P0 structural · P1 major · P2 polish.

## P0 — structural

1. **Brand identity contradicts owner direction.** Primary/ring/sidebar/chart-1 = aubergine `oklch(0.46 0.11 310)`; owner mandates deep forest green/emerald + champagne/gold restrained accent (no gold token exists; `--highlight` unmapped/unused). — globals.css:185,199,244; layout.tsx:32. **Fix: coordinated token re-brand (Backlog T1).**
2. **Three overlapping worklists + overloaded nav.** journey/leads/inbox = 3 lenses over the same lead records; "Commercial" section carries 8 items (13 top-level for MANAGER+); ordering contradicts intake lifecycle. — view-registry.ts:298-302. **Fix: T20 nav restructure.**
3. **Addressability only for leads.** `parseHash` handles only `#/<view>` + leadId; opportunities/visits/apartments/SAV cases have no routes; the deal cockpit (727 ln primary surface) is unreachable by URL. — store.ts:48-53, focus.ts. **Fix (scoped): palette/search rows open cockpit directly (T24); full hash grammar deferred with rationale.**

## P1 — major experience defects

**Design system (A2):** status chips bypass attn tokens (~500 raw palette lines; 9 central + 5 private maps drift) (T2); visit fiche renders same statuses in different hues (T3); sky/blue contamination ×10 (T4); finance PAID uses brand hue as success (T5); two primary-hover idioms (T1); typography fragmentation — text-xs ×374 off-scale, panel headers split 43 vs 10, half-pixel print sizes incl. 9.5px (T6); gradient pills + raw rgba glows + hover-lift violations (T7); hand-rolled destructive buttons (T7).

**Management (A3):** "Conversion rate" = one label over 3 different formulas, no disclosure (T30); "Cycle moyen" is an invented aggregate (sum of per-stage avg ages of open opps) (T31); SALES_AGENT `payments.view` dead — 403 lock for a right they hold (T32); OWNER role option offered to ADMIN → guaranteed 403 ROLE_CEILING (T33); dashboard missing inventory block (T34) and stalled-opportunities aggregate (T35); MANAGEMENT_KPIS row display-only — leadsAwaitingAssignment could deep-link to inbox unassigned (T36); byProject finance table computed but never rendered (T37); `sessions.revoke_others` + `metrics.view` are paper-only capabilities (documented, deferred T39).

**Sales/field (A4):** "Ma journée" hero omits overdue work (dueAt window excludes past-due) (T40); "Overdue follow-ups" cell counts only tasks while inbox queue counts lead.nextFollowUpAt (T41); field sheet lacks REJECT decision (T42); inbox counts/rows computed in-memory over newest 500 (SLA-overdue vanish; cap 500) (T43); per-queue ordering shows least-urgent first (T44); no pending-offers signal for agents (T45); pipeline board filters amnesia (T21); myPendingReservations dead end (T46); FIELD_REP default lands on dashboard not field (T22).

**Tables/forms/dialogs (A5):** no unsaved-change protection anywhere except create-lead — property wizard (5 steps), both import wizards, schedule-visit, opportunity create lose drafts on stray Escape (T50); deal cockpit + unit cockpit are full workflows trapped in sm:max-w-lg/md modals with 2–3 stacked layers (T51); SAV truncates at 200 silently / finance has no pagination contract (T52); filter amnesia on sav/finance/audit/journey (T21); MoneyField not adopted on finance money-critical fields (T53); numeric alignment split-brain (leads budget/score + unit-table left vs finance right) (T54); property wizard validates by silently disabling Continue (T55); unit table `min-w-[52rem]` no mobile adaptation (T56); SAV renders ErrorState twice (T57); 403 lock JSX copy-pasted ×5 (T58).

**A11y/i18n (A6):** ~30 text sites at 1.9–3.8:1 via `text-muted-foreground/40–80` (T60); 32 unassociated form Labels (T61); `domains/customers.ts` never imported — 48 dead keys, parity guard blind (T62); dark primary-on-tint chips 3.6–3.7:1 (T63 — solved by lighter dark primary token); "—" meaningless button name (T64); assign-dialog radios lack radiogroup wrapper (T65); `ml-1` bidi offender (T66); no table captions (T67); login lang cells 28×36px below 44px floor (T68); journey urgency chips fall back to raw enums (T69).

**IA/shell (A1):** notification waypoint isolation incomplete — LEADS_UNASSIGNED → unfiltered leads; RESERVATIONS_EXPIRING → unfiltered properties; task/visit groups lack facet resets (T23); global create-lead CTA renders for FIELD_REP without `leads.create` → reliably-403 (T25); FIELD_REP sees both field + visits consoles (T26); duplicate create CTAs (topbar + leads toolbar) (T27); dead modules view-placeholder/lost-reason/correction-reason (T28); nav aria-label mislabels whole nav as "Commercial" (T29); palette opportunity rows open lead drawer not cockpit; tasks/visits not searchable (T24).

## Verified-clean (no action)

RTL architecture (logical utilities, CSS glyph mirroring, pre-paint dir script); i18n discipline (0 hardcoded strings in 158 files, 24-domain parity, ar-DZ conventions); skip-link; 62/62 named icon buttons; keyboard kanban + KeyboardSensor; aria-sort tables; text-labeled badges; one-h1 law; server-side sort/filter/pagination on the 3 largest lists; truncation honesty (tasks/visits/pipeline/properties); mutation feedback (no fake-success paths); destructive confirms; focus trapping/restore incl. stacked-layer fallback; aggregate→isolate attention contract (dashboard tier-1); j/k row navigation; per-user density; empty states with CTAs; honest 403 lock screens; lead drawer as single-customer workspace; field execution sheet (Maps, checklist, photos, structured report).

## Responsive & mobile summary

Operational lists (leads/inbox/sav/finance) have transformed mobile card twins; reference tables (analytics/workload/team/campaigns/dashboard) scroll-only (policy-consistent); **unit table min-w-[52rem] is the outlier** (T56). Field view is genuinely mobile-first. Viewports to verify: 390/768/1024/1440.

## Interaction completeness

Every button audited: the reliably-403 set (FIELD_REP create CTA T25, ADMIN→OWNER option T33), dead-end KPIs (T36, T46), display-only analytics (documented as honest-surface law — labels get definitions instead of fake affordances T30/T31), and dead code (T28). No fake-success or non-persisting "success" paths found.
