# ASAS Phase 12 — Design System Specification (approved target)

**Principal Architect decision (MODE A → MODE B gate):** The Phase 12 owner brief explicitly mandates the *Premium Real Estate Intelligence Platform* direction — **deep forest green/emerald primary, charcoal/graphite dark, warm off-white light, restrained champagne/gold accent**. This supersedes the historical ADR-007 rev2 "Prune & Sable" aubergine identity. The re-brand is executed at the token layer only (the token indirection makes it a coordinated change, not a find-replace).

## 1. Color tokens (globals.css — the authoritative system)

| Token | Light | Dark | Role |
|---|---|---|---|
| `--primary` | `oklch(0.44 0.10 158)` deep forest green | `oklch(0.72 0.13 160)` light emerald (text-safe on dark) | brand fills, primary actions, focus ring |
| `--primary-hover` | `oklch(0.38 0.10 158)` | `oklch(0.78 0.12 160)` | hover state (mapped via `@theme inline` → `bg-primary-hover`) |
| `--primary-foreground` | near-white | deep forest | text on brand fills |
| `--ring` | primary family | primary family | focus indication (≥3:1) |
| `--gold` | `oklch(0.78 0.07 90)` champagne | `oklch(0.82 0.06 95)` | restrained premium accent (KPI deltas, wordmark tile, owner surfaces) — NEVER fills, never the warning amber |
| `--background` | warm off-white `oklch(0.985 0.003 85)` | warm charcoal `oklch(0.17 0.005 80)` | app background |
| `--card` / `--popover` | clear white | elevated charcoal | content surfaces |
| `--border` | hairline warm | alpha | subtle borders |
| Attention tiers | `--attn-1..3` (rose/amber/emerald) × 5 grades | same, dark-adapted | semantic status washes (the ONLY status vocabulary) |
| Neutral ladder | `--tone-3/4/5` | same | history/neutral chips |
| Charts | `--chart-1..6` (chart-1 → forest green family) | same | data viz |
| Sidebar | charcoal invariant + emerald active accent | same | app rail |

**Laws:**
1. One brand fill per view (the primary action); everything else outline/ghost.
2. Gold is an accent only — borders/deltas/wordmark; amber (attn-2) remains the decision-pending semantic.
3. Status chips must use `bg-attn-N / text-attn-N-fg / border-attn-N-line` (or `--tone-*` for neutral) — raw Tailwind palette classes for business status are forbidden.
4. `hover:bg-primary-hover` (token) replaces both `hover:bg-primary/90` and `hover:bg-[var(--primary-hover)]`.
5. No blue/sky anywhere; windowed/future statuses use violet; "recent" indicators use stone.
6. Success semantics: emerald attn-3 (light washes) — visually distinct from deep forest brand fills.

## 2. Typography (semantic scale — unchanged sizes, one addition)

`text-crm-page` 15/600 · `text-crm-section` 13/600 · `text-crm-body` 13/400 · `text-crm-caption` 11 muted · `text-crm-micro` 10 uppercase · `text-crm-nano` 10 · `text-crm-tag` 11 · `text-crm-num` 15 tabular · `text-crm-num-xl` 28 tabular · **NEW `text-crm-control` 12/1.4** (form-control size; `text-xs` call sites migrate here). Print documents snap to the 10/11/13 scale (no 9.5px — a11y floor 10px). Panel headers standardize on `text-crm-section`.

## 3. Spacing & geometry

Page gutters `px-4 sm:px-6`; section gaps `gap-4/gap-6`; card padding `p-4` (compact `p-3`); radius scale 6/8/full (`rounded-sm/md/lg` only); control heights: input `h-9`, icon button `size-9`, touch floor 44px (`crm-hit`); table density 40/36 (compact 36/32). Dialog widths: `sm` confirm · `md` form · `lg/2xl` cockpit · `2xl+` wizard. **Detail cockpits (opportunity, apartment) adopt the Sheet drawer grammar (`sm:max-w-2xl`, sticky tab band)** — the lead drawer is the canonical anatomy.

## 4. Interaction states

Default/hover/focus-visible(ring)/active/disabled(opacity+cursor)/loading(spinner in-button or row shimmer)/selected(`bg-primary/5` + accent bar)/error(attn-1 inline). Hover = border/background shift, never movement. Focus ring on every interactive element. Destructive actions → `variant="destructive"` + AlertDialog consent.

## 5. Status semantic vocabulary (single source: constants.ts tone maps → attn tokens)

- **Danger/blocked/overdue/lost/no-show** → attn-1 rose.
- **Decision-pending/warning/awaiting** → attn-2 amber.
- **Positive/completed/won/paid/qualified** → attn-3 emerald.
- **Advancing/scheduled-windowed** → violet state ramp.
- **In-progress/advancing** → teal state ramp.
- **Neutral/draft/history/archived** → tone ladder.

Every badge carries a text label (never color alone). Same business state = same hue on every surface (app + print documents pinned light but hue-law aligned).

## 6. Theme system

next-themes class strategy, light default. Both themes use identical component architecture — no component may ship light-only or dark-only classes. Dark theme: deep charcoal surfaces, emerald accents, no pure black, muted-foreground ≥4.5:1 on card (verified: 4.83:1 → keep headroom; text never rendered at opacity <100%).

## 7. Component inventory (unified)

Button (variants: default/outline/ghost/destructive/secondary), icon-button (aria-label mandatory), Input/Select/Combobox/Textarea (text-crm-control), MoneyField (the ONE DZD primitive — every money field), Checkbox/Radio (radiogroup wrapper mandatory), Tabs, Badge/StatusBadge (attn tokens), Tooltip, Popover, DropdownMenu, Dialog (focus restore — existing), Sheet (drawer grammar), Card, crm-th/td tables (+ NEW `crm-td-num` right-aligned tabular), Pagination, Breadcrumb (future), Alert, Toast, Skeleton, EmptyState (what/why/next), ErrorState (+ retry), LockScreen (NEW shared 403 surface), states ladder.

## 8. Defect corrections mandated by this spec

See `ASAS_PHASE12_IMPLEMENTATION_BACKLOG.md` tasks T1–T10 (design-system stream).
