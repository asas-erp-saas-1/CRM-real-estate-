# ASAS Phase 12 — Regression Report

## Method
House law honored: integration suites are **black-box against the live dev
server**; the full suite is run **sequentially** (`--maxWorkers=1`) per the
documented OOM/sequential-execution law (uncapped parallel workers +
`next-server` race for the 4 GB sandbox's memory → the kernel reaper kills
the server mid-run → cascading false failures).

## Environment incidents during regression (root-caused, not product bugs)
1. **Dev-server OOM kills ×2** this session (lint/typecheck/seed concurrency,
   then 59 vitest workers). Recovery each time: `.zscripts/dev-restart.sh`
   (double-fork → PID 1). The restart script's header documents this exact
   class (verified 2026-11-10, S-CLOSE-2).
2. **R13 DB wipe** at session open: all 22 core tables 0 rows. Restored with
   the sanctioned demo seed. This is the documented sandbox lifecycle, not a
   product defect.
3. **First full-suite run failed 23 files at collection** — the dev server
   was down at that moment (preflight law: a down server FAILS, never skips).
   Re-run with server healthy.

## Results
- **Unit suite**: `bun run test:unit` → **36 files, 605/605 PASS** —
  identical to the Phase 11 exit record. **Zero unit regressions.**
- **Full suite, sequential, single pass** (server healthy): **964 tests
  total** — matching the Phase 11 claim; 4 failures, all root-caused as
  **test-maintenance debt** (details below), all fixed this session.

## The 4 failures — root causes (none are Phase 12 product regressions)
| Test | Failure | Root cause | Fix applied |
|---|---|---|---|
| `contract/api.test.ts` (health bookkeeping) | `expect([29, null]).toContain(30)` | Phase 11 added migration **#30** (`20261110150000_p11_lead_acquisition`) but did not advance these two pins; Phase 11's exit evidence only cites the unit suite, so this debt was never observed | Pin advanced to `[30, null]` with dated comment |
| `contract/observability.test.ts` (same probe) | same | same | same |
| `contract/services-contract.test.ts` (dashboard snapshot) | pinned key-set mismatch | Phase 12 W3 intentionally added `myOverdueTasks` (T40), `overdueFollowUps` (T41), `pendingOffers` (T45), `stalledOpportunities` (T35) — browser-verified live BEFORE the pin was advanced | All 4 keys added to the exhaustive pin (additive contract law, documented in-test since Phase 9 STEP 8) |
| `security/attribution.test.ts` (first-touch) | firstTouchChannel OUEDKNISS ≠ WHATSAPP | Fixture-order latent defect: the test borrowed "the first lead in Amine's list" as its probe subject; on a fresh seed that lead can carry prior INBOUND touches, so the posted touch is not first. Unstable across seed regenerations | Test now creates a DEDICATED marker lead (POST /api/leads, 201) — self-contained; assertions equally strict (source PHONE preserved, first-touch WHATSAPP, non-fallback) |

## Post-fix verification
- The 4 fixed suites re-run together: **40/40 PASS**.
- **Re-run interference (documented, expected)**: `phase8-identity.test.ts`
  (17 tests) passes on a fresh in-memory redeem-window but 429s when the
  suite is re-run inside the 5-minute limiter window — the redeem-token
  limiter is **in-memory per-IP** (5 failures / 5 min, `auth-tokens.ts`), and
  all local traffic shares `127.0.0.1`; the suite itself records exactly ≤5
  failures per pass, so a single pass on a fresh window passes (observed
  twice) while stacked re-runs exhaust the window. This is test-environment
  accumulation, not a product defect. The **final single-pass** run below is
  the honest gate.

## Final gate (single sequential pass, fresh redeem window, server healthy)
Recorded in `05_ENGINEERING_DOCUMENTATION/22_PHASE_12_FINAL_ACCEPTANCE/ASAS_PHASE12_FINAL_ACCEPTANCE_GATE.md`.

## Preservation laws honored
- No tests removed; no assertions weakened (pins advanced to the CURRENT
  truthful contract; one test made MORE robust).
- No backend/src changes required — all four fixes are test-file maintenance,
  matching the Phase 12 rule (backend only for real UX-functional defects).
- React Strict Mode, security gates, RBAC/permission suites untouched and
  passing (permission-matrix 140/140 in group runs; the full matrix is part
  of the 964).
