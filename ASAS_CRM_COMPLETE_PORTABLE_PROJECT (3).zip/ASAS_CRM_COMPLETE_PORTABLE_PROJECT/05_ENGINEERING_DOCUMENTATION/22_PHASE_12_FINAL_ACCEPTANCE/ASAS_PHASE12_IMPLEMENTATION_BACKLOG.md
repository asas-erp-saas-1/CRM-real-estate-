# ASAS Phase 12 — Implementation Backlog (the TODO gate)

Approved by Principal Integrator after six-agent discovery + cross-review. Each task: ID · priority · files · acceptance. Waves are sequenced to avoid file conflicts. **Preservation laws apply to all: no permission weakening, no financial semantic changes, no removed required fields, every action keeps a real outcome.**

## WAVE 1 — Design token foundation (Principal, sequential)

| ID | Pri | Task | Files | Acceptance |
|---|---|---|---|---|
| T1 | P0 | Re-brand tokens: `--primary` family → deep forest green (light 0.44/0.10/158, dark 0.72/0.13/160 text-safe), `--ring`, `--chart-1`, `--sidebar-primary`, themeColor; add `--gold` champagne ramp mapped via `@theme inline`; map `--color-primary-hover` → `hover:bg-primary-hover` utility; add `text-crm-control` 12px utility | globals.css, layout.tsx | brand hue is forest green everywhere; gold exists as accent only; single hover idiom; no visual regressions in either theme |

## WAVE 2 — Parallel (disjoint file sets)

| ID | Pri | Task | Files | Acceptance |
|---|---|---|---|---|
| T2 | P1 | Migrate 9 central tone maps + badges to attn/state token classes; delete private maps (notifications-bell L75-102, lead-tab-activities L110-118); add violet/teal state ramps for lifecycle hues | constants.ts, badges.tsx, notifications-bell.tsx, lead-tab-activities.tsx | zero raw rose-/amber-/emerald-500-style status classes in tone maps; identical hues app-wide per status |
| T3 | P1 | Print documents (visit fiche, offer presentation) align to app hue law + snap sizes to 10/11/13 scale (kill 9.5px) | visit-fiche-dialog.tsx, offer-presentation-dialog.tsx | same visit status = same hue in app and print; no sub-10px text |
| T4 | P1 | Purge 10 sky/blue sites → violet/stone | badges.tsx, constants.ts, matching-tab, unit-compare, availability-panel, history-tab, inventory-dashboard, fiche, offer-presentation | zero `sky-` classes remain |
| T5 | P1 | Finance PAID → attn-3; brand-as-success ban | finance-table.tsx | PAID chip emerald semantic |
| T6 | P2 | Panel headers → `text-crm-section` on main surfaces; text-xs → text-crm-control sweep on form controls (top offenders) | dashboard/panel-title.tsx + top files | headers unified; controls on 12px role |
| T7 | P2 | Decorative violations: gradient pills → flat attn washes; login hover-lift → border shift; raw rgba glows → token-based; hand-rolled destructive buttons → variant | notifications-bell.tsx, login-overlay.tsx, import-leads-dialog.tsx, finance-view.tsx, sav-detail-dialog.tsx, lead-copilot-card.tsx, journey-view.tsx, lead-journey-rail.tsx | no gradients/movement-hovers/raw rgba |
| T60 | P1 | Contrast: replace `text-muted-foreground/NN` text sites (~30) with full token; add CI-style grep note | 15+ files listed by A6 | no text below 4.5:1 |
| T61 | P1 | Associate 32 unassociated Labels (htmlFor/id) or adopt Field primitive | lead-tab-overview, leads/filters, lead-tab-tasks, settings-view, campaigns/sessions/attribution/upload/qualification/routing | zero orphan labels |
| T62 | P1 | Import `domains/customers.ts` into i18n index + parity guard | i18n/index.ts | domain wired; tests see it |
| T64–T69 | P2 | A11y micro-batch: "—" aria-label; assign-dialog radiogroup; ml-1→ms-1; sr-only table captions (main tables); login lang cells ≥44px; journey urgency enum keys | per-file | all pass |
| T50 | P1 | Extract `useDirtyGuard` from create-lead; wire into add-property wizard, import-leads, import-units, schedule-visit, create-opportunity, sav-create, add-installment/record-payment | hooks + 8 dialogs | stray Escape never silently discards a typed draft |
| T53 | P2 | MoneyField on finance money fields + lead budget fields | add-installment-dialog, record-payment-dialog, create-lead-dialog | DA suffix + grouping on money-critical path |
| T54 | P2 | `crm-td-num` right-aligned tabular on leads budget/score + unit-table price/surface/floor | leads/table.tsx, properties/unit-table.tsx | numeric anchor unified with finance/analytics |
| T55 | P2 | Property wizard: surface criticalMissing inline alert + aria-invalid | add-property-dialog.tsx | user always knows which field blocks Continue |
| T57 | P3 | Remove SAV double ErrorState | sav-view.tsx | single error alert |
| T58 | P2 | Extract shared `LockScreen` component; replace 5 copies | states.tsx + 5 views | one source |
| T28 | P2 | Delete dead modules (view-placeholder, lost-reason, correction-reason dialogs) | deletions | zero importers confirmed |

## WAVE 3 — Parallel (after Wave 2 merges)

| ID | Pri | Task | Files | Acceptance |
|---|---|---|---|---|
| T20 | P0 | Nav restructure: lifecycle order (dashboard, inbox, leads, journey, pipeline, visits, tasks); section regroup: Commercial(dashboard,inbox,leads,journey,pipeline,visits,tasks) / Opérations(properties,finance,sav) / Pilotage(analytics,audit,settings) | view-registry.ts | lifecycle-ordered nav; sections ≤8/≤3/≤3 |
| T21 | P1 | Workspace-store slices for pipeline/sav/finance/audit/journey filters | workspace-store.ts + 5 views | no filter amnesia on any view |
| T22 | P2 | FIELD_REP default view → field at boot | store.ts | field reps land in their agenda |
| T23 | P1 | Notification isolation completion: LEADS_UNASSIGNED → inbox unassigned queue; RESERVATIONS_EXPIRING → properties + pending-holds focus; task/visit groups patch facets | notifications-bell.tsx + api/notifications | every group lands on its exact set |
| T24 | P2 | Palette opportunity rows → open cockpit (exact-id fetch, audit-overlay idiom) | search-command.tsx | deal match is 1 hop |
| T25 | P1 | Gate global create CTA + palette create on `leads.create` | shell.tsx, search-command.tsx | FIELD_REP never sees a 403 button |
| T26 | P1 | `hideFor: ["FIELD_REP"]` on visits nav | view-registry.ts | one visit console for field reps |
| T27 | P2 | Drop duplicate leads-toolbar create CTA (keep global) | leads-view.tsx | one primary CTA |
| T29 | P2 | Generic nav aria-label | sidebar-nav.tsx | nav named "ASAS" not "Commercial" |
| T40 | P1 | TodayPanel: overdue OPEN tasks as leading rose group + tab badge | today-panel.tsx, dashboard service | overdue visible in hero |
| T41 | P1 | Composite overdue follow-ups cell (tasks OR lead.nextFollowUpAt) aligned with inbox predicate | dashboard service + attention-strip | one predicate everywhere |
| T42 | P1 | Field sheet REJECT outcome (reuse RejectVisitDialog payload) | field-visit-sheet.tsx | refuse possible without leaving field |
| T43 | P1 | Inbox scale: per-queue grouped DB counts + server-side queue predicates + real pagination | api/leads/inbox/route.ts | counts truthful beyond 500; SLA-overdue never vanish |
| T44 | P2 | Per-queue ordering (overdue_contact asc; overdue_followups by nextFollowUpAt) | api/leads/inbox/route.ts | most-urgent first |
| T45 | P2 | Pending-offers signal: dashboard attention cell (agent+manager) deep-linking to board | dashboard service + attention-strip | offers awaiting decision visible |
| T46 | P2 | myPendingReservations KPI → pipeline RESERVATION stage isolation | kpi-card.tsx | KPI is 1 hop from its set |
| T30 | P1 | Conversion-rate relabeling: 3 distinct labels + definition tooltips | analytics-view, analytics-tables, dashboard, i18n | no ambiguous label |
| T31 | P1 | Replace "Cycle moyen" with CLOSED_WON cycle | analytics-view.tsx | metric definition honest |
| T32 | P1 | Agent scoped finance mode: when overview 403s but payments.view exists → list-only "Mes échéances" (no management tier) | finance-view.tsx | agent's authorized data visible |
| T33 | P2 | ROLE_OPTIONS filtered by actor rank + ceiling caption | role-options.ts, add-member-dialog, team-table | ADMIN never offered OWNER |
| T34 | P2 | Dashboard inventory rail card (MANAGER+) reusing /api/inventory/dashboard | dashboard-view + rail | portfolio health on command center |
| T35 | P2 | Stalled opportunities aggregate + attention cell | dashboard service | "N deals rotting" visible |
| T36 | P2 | Management KPI drill-downs (assignment→inbox unassigned; missed/completed visits→armed list; lost→pipeline) | kpi-card.tsx, dashboard-view | no dead management KPIs |
| T37 | P2 | Finance "Par projet" table (byProject already computed) | finance-view.tsx | per-project money visible |
| T51 | P1 | Promote opportunity cockpit Dialog→Sheet sm:max-w-2xl + sticky tab band; widen apartment detail to 2xl | opportunity-detail-dialog→drawer, apartment-detail-dialog | deal workspace gets drawer grammar |
| T52 | P2 | SAV truncation banner + finance count disclosure | sav-view.tsx, finance-view.tsx | scale honesty |
| T56 | P2 | Unit table mobile: force grid mode / card twin at <md | properties-view.tsx / unit-table.tsx | no 52rem scroll on phone |

## WAVE 4 — Verification (Principal)

| ID | Pri | Task | Acceptance |
|---|---|---|---|
| V1 | P0 | `bun run lint` clean | no new errors |
| V2 | P0 | Browser acceptance matrix: 5 roles × (desktop 1440, mobile 390) × (ar RTL, fr, en) × (light, dark) on key pages; screenshots in evidence/phase12/ | matrix filled with real screenshots |
| V3 | P0 | Interactivity checks: login, nav switch, lead drawer, kanban drag (desktop) / move-select (mobile), visit schedule, finance record, settings save, search palette, notifications navigation | each flow works end-to-end |
| V4 | P1 | Regression: existing test suite relevant subsets, tsc via lint | no regressions |
| V5 | P0 | Final docs: implementation report, browser evidence, regression report, deployment blocker status (UNRESOLVED — native Publish unverified by owner), final acceptance gate | complete honest record |

## Deferred (documented, not scheduled)

- Full hash addressability `#/<view>/<id>` for all entities (T-P0-A1) — architecture risk in this phase; palette direct-open (T24) delivers the UX value.
- `sessions.revoke_others` enforcing route + `metrics.view` ops surface (T39) — new backend features, not UX corrections; owner visibility documented.
- Reservations worklist view (new surface) — significant new IA; the notification focus fix (T23) mitigates the worst path.
- Journey/leads/inbox merge (deeper than reordering) — needs owner product decision; T20 ordering fix is the safe step.
