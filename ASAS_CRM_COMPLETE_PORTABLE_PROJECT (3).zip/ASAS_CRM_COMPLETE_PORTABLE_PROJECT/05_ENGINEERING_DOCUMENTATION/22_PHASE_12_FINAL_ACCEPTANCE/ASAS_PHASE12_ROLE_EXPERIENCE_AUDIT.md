# ASAS Phase 12 — Role Experience Audit

## OWNER (nadia@asas.dz — verified live)

Dashboard delivers: new leads (+trend, drill-down), qualified (funnel), active/hot opps, won value, lost (role row), overdue tasks/unstaffed visits/pending incentives/duplicates attention cells (all isolating), targets, commissions, finance card, movement funnel. **Missing: inventory block (active projects, available/reserved units — T34), stalled opportunities (T35), management KPI drill-downs (T36).** Nav = 13 top-level (overloaded — T20). Campaigns live in Settings; attribution in Analytics (split mental model). OWNER role option correctly offered (ceiling only breaks for ADMIN — T33).

## ADMIN (karim@asas.dz)

ADMIN_TEMPLATE = all permissions → identical 14-view nav as OWNER; no nav item 403s (verified per-view floors match server gates). Defects: OWNER-role option offered → guaranteed 403 ROLE_CEILING after full form effort (T33); `metrics.view` (ADMIN+) has no UI consumer; `sessions.revoke_others` has no enforcing route (paper-only — documented, deferred T39).

## MANAGER (sarah@asas.dz)

Genuine operational depth: inbox routing console + workload table; agent leaderboard; per-agent targets/velocity/stalled; acquisition contact-delay compliance; unstaffed/reconfirm/field-decision attention cells with isolating deep-links. Soft spots: management KPI row display-only (T36); manager-specific surfaces scattered across 6 views (accepted IA); conversion-rate label ambiguity across surfaces (T30).

## SALES_AGENT (amine@asas.dz)

"Ma journée" hero answers today's tasks/visits; attention cells isolate exact sets; drawer = single-customer workspace (requirements, qualification, matching, timeline, opportunities, documents); inbox personal slice (own+pool); pipeline kanban best-in-class cards; visits agenda. **Defects: overdue work hidden from hero (T40); follow-up semantics diverge from inbox (T41); no pending-offers signal (T45); payments.view dead capability → 403 lock (T32); myPendingReservations dead end (T46); no claim verb on pool leads (documented).**

## FIELD_REP (mounia@asas.dz)

Field view = genuine mobile-first agenda: TODAY/next/history, one-tap Maps itinerary, context-aware single primary, ≥44px targets, execution sheet with checklist/outcomes/report/photos, read-only terminal states. **Defects: no REJECT decision in sheet (T42); default landing is dashboard not field (T22); sees BOTH field + visits consoles (T26); global create-lead CTA reliably-403 (T25).**

Verdict per role: architecturally strong (null-gated data contract, no client role checks); residual defects concentrate in metric epistemics, dead/hidden capability surfaces, and executive blind spots. Full evidence: A3/A4 agent audits → UX_UI_AUDIT.md.
