# ASAS Phase 12 — Forms, Tables & Dialogs Audit (distilled from A5)

## Tables
In-house crm-th/td grammar (density vars, zebra, sticky header, crm-hit floors) on 20+ tables; server-sort on leads (3 cols) + unit-table (7 cols); server pagination on leads/inbox/audit; load-more + honest truncation on tasks/visits/properties/pipeline. Defects: SAV silent 200-cap (T52); finance no pagination contract (T52); audit lacks zebra + sort; numeric alignment split-brain (T54); unit-table min-w-52rem no mobile twin (T56); team-table lone shadcn-Table holdout (accepted).

## Search & filtering
One search grammar (shared SearchField); server-side filtering everywhere it matters; active-filter chips + KPI disarm on leads (best-in-class); hidden-filter disclosure exemplary. Defect: filter amnesia on sav/finance/audit/journey/pipeline (T21); properties mode-dependent semantics (server flat vs client project-mode) — disclosed via truncation banner only.

## Forms
RHF+Zod with per-field messages; required markers inconsistent (create-lead has *, property wizard has "· requis", schedule-visit/sav/finance none); create-lead implements error-jump-to-step + the app's ONLY dirty guard. Defects: dirty guard missing on 8 multi-step/money forms (T50); property wizard silent-disabled Continue (T55); MoneyField not on finance money fields (T53); create-opportunity giant single-form in 448px (widened with cockpit promotion T51).

## Dialogs & drawers
~55 Dialogs + 20 AlertDialogs + 3 Sheets; focus capture/restore engineered beyond stock shadcn (opener restore + stacked-layer fallback); destructive confirms thorough; widths disciplined. Defects: opportunity cockpit + apartment detail trapped in small modals with 2–3 stacked layers (T51 — promoted to Sheet drawer grammar); Escape discards drafts (T50); 403 lock JSX duplicated ×5 (T58).

## Detail-page pattern
Lead drawer = canonical anatomy (title/status/actions/overview/related/timeline + sticky tabs + mobile action bar). Opportunity/apartment cockpits adopt the same grammar (T51). No shared DetailShell abstraction (deferred — the two promotions deliver the UX value).
