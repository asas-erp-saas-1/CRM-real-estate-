# ASAS CRM — P0-1 Database Reconstruction Report

**Task:** Reconstruct the database from the canonical Prisma migration chain.
**Status:** IMPLEMENTED · INTEGRATED · TESTED · VERIFIED
**Executed:** 2026-11-03, Principal Agent (Agent 1 role).

## Step A — Original database verified & preserved

The original `db/custom.db` (db push artifact) was re-verified before any change:
30 tables, **0 rows in every table**, no `_prisma_migrations`, `journal_mode=delete`,
zero partial indexes — the blueprint's findings were accurate.

Preservation artifacts (both git-ignored under `/db/`):

| Artifact | Size (B) | SHA-256 (prefix) | Integrity |
|---|---|---|---|
| `db/backups/custom-pre-p0-2026-11-03T22-54-31.db` (consistent `VACUUM INTO` snapshot) | 626,688 | `53ab69984290…` | `PRAGMA integrity_check` = ok |
| `db/backups/custom-original-pre-swap.db` (original file, preserved at swap) | 626,688 | identical content | n/a |

## Step B — Migration chain inspected

`prisma/migrations/` contains **18 migration directories** + `migration_lock.toml`.
The chain covers: core CRM tables (`0_init`), composite indexes (P4), stage bookkeeping
(P8/9, P11), finance installments (P13), SAV lifecycle (P14→P16), operating model (P18),
visit lifecycle (P20), commercial trust (P29), duplicate management (P30), two-step
closure (P54), visit report (Phase C), finance/SAV targets (PD), incentive index (W18),
Arabic aliases, **live-hold partial unique indexes (D12)**, and `lead.convertedAt` (Phase 2.1).

### Migration-count discrepancy — reconciled

The previous report expected 19 `_prisma_migrations` records; the repository contains
**18 legitimate migration directories**. `prisma migrate deploy` created exactly
**18 records, all `finished_at` stamped**. The "19" expectation is corrected: it was a
miscount in the prior investigation (most plausibly counting the `migration_lock.toml`
entry, or simply an off-by-one). No migration was invented to force a different count —
per the mission's explicit prohibition.

## Step C — Clean candidate database reconstructed

```
DATABASE_URL="file:/home/z/my-project/db/candidate.db" bunx prisma migrate deploy
→ All migrations have been successfully applied.
```

`db push` was **not** used; no existing migration file was altered; the original
database was untouched during reconstruction.

## Step D — Prisma Client generated

`bunx prisma generate` — client regenerated against the unchanged schema (30 models).

## Step E — Reconstructed schema verified

| Check | Result |
|---|---|
| Tables | 31 = 30 models + `_prisma_migrations` |
| Migration records | 18, 0 unfinished |
| **Partial live-hold indexes** | `Reservation_apartment_live_hold_uq` (apartmentId, WHERE status IN ACTIVE/CLOSURE_REQUESTED) and `Reservation_opportunity_live_hold_uq` — both present in `sqlite_master` SQL text |
| Reservation FK count | 3 (opportunity, apartment, organization) |
| `PRAGMA foreign_key_check` | 0 violations |

The critical D12 invariant (one live hold per apartment / per opportunity) is now
**database-enforced on the active database** — it was absent in the db-push-built original.

## Step F — Seed executed & validated

`DATABASE_URL=file:…candidate.db bun run db:seed` (the project's real mechanism,
`prisma/seed.ts` — synthetic demo roster only, documented demo password, no real data).

DB-level validation (bun:sqlite, read-only):

| Entity | Rows | Entity | Rows |
|---|---|---|---|
| Organization | 1 | Activity | 183 |
| User | 8 | Task | 18 |
| Pipeline / Stage | 1 / 10 | Visit | 23 |
| Lead | 43 | Reservation | 8 |
| Contact | 20 | Installment | 14 |
| Opportunity | 21 | Payment | 8 |
| Project / Apartment | 4 / 46 | | |

- Referential integrity: **0 orphan FKs** across 11 checked relations, 0 cross-org rows.
- Live-hold duplicate check on seeded reservations: **PASS** (0 duplicate live holds).
- Documented validator: `python3 scripts/validate-seed.py supabase/seed.sql` →
  **606 rows / 26 tables, parse failures 0, FK violations 0, order violations 0,
  canonical counts MATCH, VALIDATION: PASS.**
- Reproducibility: the seed SQL generator run against the reconstructed+seeded
  candidate emits an equivalent roster (606 rows; ids/timestamps/scrypt salts differ
  by design per seed run). The committed `supabase/seed.sql` remains the canonical artifact.

## Step G — Candidate promoted (only after all checks passed)

Dev server stopped → original moved to `db/backups/custom-original-pre-swap.db` →
candidate moved to `db/custom.db` → server restarted.

Post-swap live evidence:
- `GET /api/health` → `{"status":"ok","dbOk":true,"migrations":18,"demoMode":true,…}`
  (previously `migrations:null` — the db-push artifact had no migration book).
- `POST /api/auth/login` (seeded manager) → `200` with session user (previously 401
  against the empty database — the operational baseline is restored).
- Full suite: **163/163 tests pass** (`bun run test`, live server, 2026-11-03 22:58).

## Acceptance criteria

1. Original database preserved — ✅ (2 artifacts, hashed, git-ignored)
2. Clean candidate database created — ✅ (`db/candidate.db`, isolated)
3. Full canonical migrations applied — ✅ (migrate deploy, no db push)
4. Migration count reconciled — ✅ (18 dirs = 18 records; "19" corrected)
5. `_prisma_migrations` matches the actual chain — ✅ (18/18 finished)
6. All 30 models exist — ✅ (31 tables incl. bookkeeping table)
7. Partial live-hold indexes in `sqlite_master` — ✅ (both D12 indexes)
8. Prisma Client generated — ✅
9. Seed execution succeeds — ✅
10. `validate-seed.py` passes — ✅ (VALIDATION: PASS)
11. Referential integrity passes — ✅ (0 violations, 0 orphans)
12. Recovered database reproducible from the repository — ✅ (migrate deploy + seed
    re-runs deterministically; documented in CI `database-gates`)

No database URLs or credentials are included in this report.
