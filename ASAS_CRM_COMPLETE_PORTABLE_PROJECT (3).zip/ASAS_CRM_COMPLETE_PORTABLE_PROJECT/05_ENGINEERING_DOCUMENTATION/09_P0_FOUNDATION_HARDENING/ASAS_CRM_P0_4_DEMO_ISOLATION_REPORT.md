# ASAS CRM — P0-4 Demo Isolation Report

**Task:** Demo user organization isolation & F-01 security remediation.
**Status:** IMPLEMENTED · INTEGRATED · TESTED · VERIFIED
**Executed:** 2026-11-03, Agent A (Task ID 4) — implementation; Principal Agent — diff review + independent full-suite verification.

## Step A — Investigation (complete F-01 chain)

Inspected: `POST /api/auth/login` (both flows), `GET /api/auth/session`, session
resolution (`getCurrentUser`), demo-mode gates, org selection, role assignment,
error handling. The chain had two unscoped halves:
1. **Disclosure half** — unauthenticated `demoUsers` listing with `where: { active: true }` (no org filter).
2. **Takeover half** — quick-login `{userId}` resolving any active user in ANY org.

## Step B — Organization filtering enforced

New module `src/lib/server/demo-org.ts` — `getDemoWorkspaceOrgId()`: the
**designated demo workspace organization** (first by `createdAt` ascending — the
seed's org), resolved server-side. Clients can never select or influence the org.

| Surface | Enforcement |
|---|---|
| `GET /api/auth/session` demoUsers | `where: { active: true, orgId: demoOrgId }`; no orgs → empty roster (never an unscoped fallback) |
| `POST /api/auth/login` quick-login | `where: { id, active: true, orgId: demoOrgId }`; no orgs → ghost 404 |

A foreign-org userId fails with the **byte-identical** 404 `USER_NOT_FOUND` as a
nonexistent id (status, code, message, full envelope JSON-equality — verified in
test): no org-membership oracle, no new error code, no timing divergence (both
arms are one identically-shaped indexed `findFirst`; no scrypt burned on either).

## Step C — Production interaction

Demo surfaces remain gated by `isDemoMode()` — now **OFF by default** (P0-3) —
plus `isDemoModeMisconfigured()` refusal, plus the P0-3 boot crash for
production+demo. Demo disabled → 403 `DEMO_MODE_DISABLED` (quick-login) and
empty `demoUsers` — enforced server-side, never by UI visibility.

## Step D — Security regression tests

`tests/security/demo-isolation.test.ts` — 5 mandatory black-box tests with a
**real PrismaClient** (direct `@prisma/client` import): creates Organization B +
an active user in it, then proves:

1. Org A **cannot enumerate** Org B's demo users (foreign id absent from the roster; demo org's own roster still listed — by-design positive control).
2. Org A **cannot authenticate as** Org B's user — 404, no `Set-Cookie`.
3. **Ghost-identity:** foreign-id 404 ≡ nonexistent-id 404 (full JSON envelope equality).
4. Client-supplied identifiers cannot bypass (org resolved server-side; forged cookie → `user: null`).
5. Credentials login unaffected by scoping (sarah@asas.dz → 200).

Preflight **throws** at collection time when the server is unreachable (no
`describe.skipIf` — P0-7's no-silent-skip law applied from birth). Full teardown
verified: 0 org-B rows, 0 stray probe rows.

`tests/unit/demo-mode-gate.test.ts` — 7 pure-function tests of the env matrix:
unset → OFF (secure default), strict `"1"` only, `NODE_ENV=production`+`"1"` →
misconfigured.

## Verification evidence (Principal)

- Full suite re-run by the Principal: **191/191 tests pass** (13 files).
- `bun run lint` + `bun run typecheck` — clean.
- Diff review of both auth routes + demo-org.ts — conforms to house patterns.
- `dev.log` clean; the org-scoped demoUsers query observed live:
  `WHERE active = ? AND orgId = ?`.
- Demo-mode-off HTTP behavior is boot-enforced (P0-3 instrumentation crashes
  production+demo) and unit-tested here; live-off verification runs in CI
  (P0-7 wires a demo-off probe step).

## Acceptance criteria

- Organization filtering enforced — ✅ both demo surfaces scoped to the designated org
- Demo user lookup correctly scoped — ✅
- No cross-organization enumeration — ✅ (test 1)
- No privilege escalation — ✅ (foreign-org quick-login impossible; org never client-selectable)
- Demo-mode restrictions enforced — ✅ (default-off + boot crash + route gates)
- All negative security tests pass — ✅ (5/5)

## Limitations

- Response-latency side channel between foreign-id and ghost-id 404s asserted by
  full-envelope equality, not statistically instrumented (both arms are one
  identical indexed query).
- `getDemoWorkspaceOrgId()` adds one tiny query per demo-surface hit (uncached by
  design — resolution stays live).
- `take: 8` persona-grid cap retained (pre-existing seed-shaped behavior).
