# ASAS CRM — P0-7 CI & Vitest Report

**Task:** Vitest CI integration & non-skipping test enforcement.
**Status:** IMPLEMENTED · INTEGRATED · TESTED · VERIFIED (local execution proven; remote CI = NOT VERIFIED, honestly reported)
**Executed:** 2026-11-03, Principal Agent (Agent 6 role, second half).

## Step A — Test architecture inspected (actual inventory, recounted)

**13 files / 191 tests** (the earlier 163/181-era counts are superseded):

| Category | File | Tests |
|---|---|---|
| Unit (pure engine) | tests/unit/format.test.ts | 19 |
| | tests/unit/journey.test.ts | 30 |
| | tests/unit/constants-matrices.test.ts | 33 |
| | tests/unit/phone.test.ts | 17 |
| | tests/unit/matching.test.ts | 16 |
| | tests/unit/visibility.test.ts | 14 |
| | tests/unit/validation.test.ts | 14 |
| | tests/unit/i18n.test.ts | 10 |
| | tests/unit/boot-env.test.ts | 11 (P0-3) |
| | tests/unit/demo-mode-gate.test.ts | 7 (P0-4) |
| Contract (live HTTP) | tests/contract/api.test.ts | 10 |
| Security (live HTTP + real Prisma) | tests/security/demo-isolation.test.ts | 5 (P0-4) |
| | tests/security/financial-atomicity.test.ts | 5 (P0-5) |

Serverless subset (`bun run test:unit`): 10 files / 171 tests.

## Step B — Vitest integrated into CI

`.github/workflows/ci.yml` — the existing workflow was extended (no competing
pipeline). Also fixed a **pre-existing YAML corruption** found during audit:
`branches: ain]` → `branches: [main]` (both triggers — the workflow could not
have parsed correctly before).

Jobs (Bun version **explicit**: 1.3.14; frozen lockfile installs):

1. **static-gates** — install → prisma generate → lint → typecheck → **production
   build** (`bun run build`, newly enforced).
2. **database-gates** — `migrate deploy` to isolated `db/ci-check.db` → **migrate
   status** verification (new) → synthetic seed → `validate-seed.py`.
3. **test-gates** (NEW) — migrate deploy + seed to isolated `db/ci-test.db` →
   boot dev server (background, health-polled, demo-mode explicitly ON for the
   isolated test context) → **full Vitest suite** → demo-mode-OFF negative
   probes → teardown. Test processes touch ONLY the CI-isolated database.

## Step C — Silent skipping eliminated (mandatory)

- `tests/contract/api.test.ts`: all 7 `describe.skipIf(!serverUp)` wrappers
  removed; the unreachable-server preflight now **throws at collection time**
  with the exact remedy (and points to `test:unit` for the serverless suite).
- The new P0-4/P0-5 security files were born with the same throw-don't-skip law.
- **Live proof:** server stopped → `bun run test` → **collection errors fail the
  run** (contract + P0-4 messages shown verbatim in the execution log) → exit 1.
  No test silently skips anywhere in the suite now.
- **Focused tests:** `allowOnly: false` in `vitest.config.ts` — any
  `.only`/`describe.only` FAILS the run, deterministically (not CI-env-dependent).
- New script: `bun run test:unit` — the legitimate serverless path (171 tests),
  so "no server" is an explicit choice, never a silent fallback.

## Step D — Required test categories (coverage map)

| Category | Where |
|---|---|
| Authentication | contract (session gate, bogus login), unit (demo-mode gate, boot env) |
| Authorization | unit (visibility roles), contract (401 negatives) |
| Organization isolation | security/demo-isolation (5 tests, real second org) |
| Demo-mode security | unit (env matrix) + CI demo-off probes + security tests |
| Database migration correctness | CI database-gates (deploy + status) |
| Seed validation | CI database-gates (validate-seed.py) + P0-1 DB-level validation |
| Reservation integrity / partial unique indexes | CI migrate deploy applies the D12 partial indexes; P0-1 verified them in sqlite_master |
| Financial transaction atomicity | security/financial-atomicity (fault injection + rollback proof) |
| Payment audit consistency | same (audit row presence/absence with money writes) |
| API contracts | contract suite (10 probes) |
| Core CRM workflows | unit suites (journey, matching, matrices, validation) |

## Step E — CI verification (honest)

- **Remote GitHub Actions: NOT VERIFIED** — no verified Git remote exists for
  this repository; no CI credentials. The workflow is preserved for future
  remote execution (mission's explicit honesty rule).
- **Local execution of the exact commands: PROVEN** —
  - `bun run lint` ✅ clean · `bun run typecheck` ✅ clean
  - `bun run test:unit` ✅ 171/171
  - `bun run test` (full, live server) ✅ **191/191**
  - Migration chain + seed on an isolated DB: proven end-to-end during P0-1
    (the candidate database WAS this exact workflow: migrate deploy → generate →
    seed → validate).
  - Demo-off probes (CI step replicated locally, sequential boot as CI does):
    health `demoMode:false` ✅ · quick-login **403 DEMO_MODE_DISABLED** ✅ ·
    unauthenticated `demoUsers` **empty** ✅.
  - YAML validated programmatically (3 jobs, triggers `[main]`, correct steps).

## Acceptance criteria

- Vitest included in the actual CI workflow — ✅ (test-gates job, full suite)
- CI executes all mandatory test suites — ✅ (unit + contract + security)
- Required tests cannot silently skip — ✅ (collection-time throws, proven live)
- Focused tests are prevented — ✅ (`allowOnly: false`)
- Isolated database setup is reproducible — ✅ (migrate deploy + seed, proven in P0-1)
- Typecheck, lint, and build remain enforced — ✅ (static-gates, build newly added)
- Test failures fail CI — ✅ (vitest non-zero exit fails the step; probes assert codes)
- Actual local test execution results recorded — ✅ (this report + execution log)
- Remote CI execution — ⛔ NOT VERIFIED (no Git remote/credentials — documented, workflow preserved)
