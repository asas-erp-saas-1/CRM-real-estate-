# ASAS CRM — P0 Master Execution Plan

**Stage:** Foundational Engineering Remediation & Operational Baseline Restoration
**Status register:** live — see `ASAS_CRM_P0_EXECUTION_LOG.md` for the running log.

---

## 1. Verified baseline (Principal Agent audit, 2026-11-03)

Every blueprint claim was re-verified against the live repository before any change:

| # | Blueprint claim | Verified state | Verdict |
|---|---|---|---|
| 1 | SQLite active DB at `db/custom.db` | `db/custom.db` 626,688 B, mtime 2026-11-03 20:52 | ✅ |
| 2 | `.env` contains only `DATABASE_URL` | `.env` = 50 bytes, single key | ✅ |
| 3 | 30 Prisma models | `grep -c '^model' schema.prisma` = 30 | ✅ |
| 4 | 72 API route files | 72 `route.ts` under `src/app/api` | ✅ |
| 5 | 12 hash-routed views | dashboard…settings | ✅ |
| 6 | Zero rows across 30 tables | all 30 tables COUNT=0 | ✅ |
| 7 | No `_prisma_migrations` history | table absent (db push artifact) | ✅ |
| 8 | Partial live-hold indexes absent | `sqlite_master` has no partial indexes | ✅ |
| 9 | `journal_mode=delete` | `PRAGMA journal_mode` → delete | ✅ |
| 10 | 18 migration directories vs "19 expected" | 18 directories + `migration_lock.toml` in `prisma/migrations/` | ✅ reconciled → see P0-1 report |
| 11 | D12 migration carries the partial indexes | `20261102000000_phase2_d12_live_hold_unique/migration.sql` contains both `CREATE UNIQUE INDEX … WHERE` | ✅ |
| 12 | Financial atomicity risk | `POST /api/finance/payments` commits payment+installment in `$transaction` but `logAudit`/`logActivity` run AFTER, on the global client; `PATCH /api/finance/installments/[id]` has **no** transaction; `POST /api/finance/installments` audit outside tx; `reservation-economics.ts` writes+audits without tx | ✅ gap confirmed |
| 13 | Demo-user org disclosure | `GET /api/auth/session` lists `demoUsers` with no org filter; quick-login accepts any active userId | ✅ gap confirmed |
| 14 | Session secret ephemeral | `session.ts` falls back to `randomBytes(32)` per process | ✅ |
| 15 | Demo mode default-on | `isDemoMode()` = `!== "0"` | ✅ |
| 16 | Vitest not in CI; contract tests silently skip | `ci.yml` has no vitest step; `api.test.ts` uses `describe.skipIf(!serverUp)` | ✅ |
| 17 | CI workflow YAML corrupt | `branches: ain]` in `on.push` / `on.pull_request` | ✅ bug found |
| 18 | Tests currently red | `bun run test` → 2 FAIL (login 401: DB empty → no seeded users) | ✅ operational baseline broken — P0-1 restores it |

Additional facts established by the Principal:
- `scripts/validate-seed.py` (supabase/seed.sql structural validator) + `scripts/generate-seed-sql.ts` exist and are wired in the existing CI `database-gates` job.
- Fault-injection infrastructure exists (`src/lib/server/faults.ts`, `x-test-inject` header) and is already folded into reservations/leads/visits/tasks/opportunities routes — the pattern P0-5 extends to finance.
- `logAudit`/`logActivity` already accept an optional `Prisma.TransactionClient` (G5-P3-5) — P0-5 is a call-site fix, not new plumbing.
- Dev server on :3000 is up but useless (empty DB): health returns `migrations: null, demoMode: true`.

## 2. Execution order (mission §11 — dependency-controlled)

| Phase | Task | Owner | Files owned (exclusive) |
|---|---|---|---|
| 0 | Task register + plan | Principal | `05_ENGINEERING_DOCUMENTATION/09_P0_FOUNDATION_HARDENING/*` |
| 1 | P0-1 Database reconstruction | Principal | `db/*`, backups, reports |
| 2 | P0-2 SQLite reliability | Principal | `src/lib/db.ts`, probes |
| 3 | P0-3 Production security | Principal | `.env`, `src/lib/server/session.ts`, `src/instrumentation.ts`, `src/app/api/health/route.ts`, docs |
| 4 | P0-4 Demo isolation | Agent A | `src/app/api/auth/{session,login}/route.ts`, `src/lib/server/demo-org.ts`, `tests/security/demo-isolation.test.ts` |
| 5 | P0-5 Financial atomicity | Agent B | `src/app/api/finance/**`, `src/lib/server/reservation-economics.ts`, `tests/security/financial-atomicity.test.ts` |
| 6 | P0-6 Migration governance | Principal | `package.json`, `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/*` |
| 7 | P0-7 CI + Vitest | Principal | `.github/workflows/ci.yml`, `vitest.config.ts`, `tests/contract/api.test.ts`, `package.json` (test scripts) |
| 8 | Final acceptance | Principal | reports, commit |

Phases 4 and 5 are the only parallel pair (zero file overlap; both depend on 1–3 landing first: a seeded DB, WAL, stable sessions).

## 3. Non-negotiable protections

- Original `db/custom.db` preserved via consistent `VACUUM INTO` backup before anything else; backups live under `db/backups/` (git-ignored).
- Candidate database built at `db/candidate.db`; swap only after migration + index + seed + integrity checks pass.
- No Supabase/PostgreSQL activation. SQLite stays authoritative (BP-ADR-02).
- No secret values in any report or log.
- Dev server restarts are Principal-only operations (agents never restart it).

## 4. Definition of done

Per mission §16 — all seven tasks satisfy their acceptance criteria, each proven with recorded evidence in `05_ENGINEERING_DOCUMENTATION/09_P0_FOUNDATION_HARDENING/ASAS_CRM_P0_{1..7}_*.md`, plus `ASAS_CRM_P0_FINAL_ACCEPTANCE_REPORT.md`. Any externally-blocked item stays open as BLOCKED with precise evidence.
