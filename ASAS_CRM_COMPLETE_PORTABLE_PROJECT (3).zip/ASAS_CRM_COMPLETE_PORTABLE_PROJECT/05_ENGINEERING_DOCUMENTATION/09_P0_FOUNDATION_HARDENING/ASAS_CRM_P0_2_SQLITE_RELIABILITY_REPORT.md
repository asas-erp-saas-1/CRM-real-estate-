# ASAS CRM — P0-2 SQLite Reliability Report

**Task:** WAL, busy_timeout & concurrency hardening.
**Status:** busy_timeout + concurrency — IMPLEMENTED · INTEGRATED · TESTED · VERIFIED.
**WAL enablement — BLOCKED (verified runtime blocker, evidence below). Per the mission's own rule, a falsely-completed WAL task is not reported.**
**Executed:** 2026-11-03, Principal Agent (Agent 2 role).

## Step A — Actual runtime SQLite version (queried, not assumed)

Probe: `SELECT sqlite_version()` **through the Prisma connection itself** (the runtime
the application actually uses — not Bun's SQLite, not a system CLI):

| Runtime | SQLite version | Role |
|---|---|---|
| **Prisma query engine (project `@prisma/client` 6.19.2)** | **3.46.0** | ← the application runtime |
| Prisma query engine (latest stable 6.x = 6.19.3, probed in isolation) | 3.46.0 | upgrade ceiling within v6 |
| Bun 1.3.14 `bun:sqlite` | 3.53.0 | probe tooling only — not the app runtime |
| Prisma 7.10.1 | not probed to completion | different architecture (see below) |

## Step B — WAL compatibility decision (the verified blocker)

The mission's compatibility requirement: WAL requires SQLite ≥ 3.51.3
(WAL-reset bug documented for 3.7.0–3.51.2), unless a verified vendor backport exists.

1. The application's actual runtime is **3.46.0 — inside the affected range**.
2. **No in-scope upgrade exists within Prisma 6:** the latest stable 6.19.3 bundles the
   identical SQLite 3.46.0 (probed empirically in an isolated install).
3. **Prisma 7 is a different architecture** (schema URL removed → `prisma.config.ts`,
   driver adapters, new `prisma-client` generator, constructor-level adapter injection —
   verified directly during the probe). Migrating the application to Prisma 7 is a
   major-version project that would touch every Prisma touchpoint (client init,
   migrations config, seed, CI) — explicitly out of P0's surgical scope, and reckless
   to combine with the concurrent P0-4/P0-5 code changes.
4. No vendor statement exists that Prisma's bundled 3.46.0 carries a backport of the
   WAL-reset fix; none may be assumed.

**Decision (per the mission's explicit rule "do not blindly enable WAL"):** the active
database **stays in `journal_mode=delete`**. WAL enablement is BLOCKED with this
evidence; the documented future trigger is a dedicated Prisma 7 migration task (which
brings a driver-adapter SQLite runtime) — recommended for a later phase, executed as
its own verified change, never silently.

Filesystem note: the database lives on the container's local filesystem (single host,
not network storage) — WAL-compatible storage if/when the runtime is upgraded.
Checkpoint behavior: N/A while WAL is off (delete journal auto-truncates on commit).

## Step D — Busy timeout (verified on every connection)

The Prisma query engine itself applies **`busy_timeout = 5000 ms` on every physical
connection it opens** — verified by read-back (`PRAGMA busy_timeout` → 5000) across
**three fresh `PrismaClient` instances**, and behaviorally under live contention (Step E).
It additionally enforces `foreign_keys = 1` (ON) on every connection.

A hand-rolled `PRAGMA busy_timeout` at singleton init was evaluated and **rejected**:
it would cover a single pooled connection only, weakening — not strengthening — the
engine's per-connection guarantee. The verified mechanism is the engine's own, which
is exactly "the actual Prisma/SQLite connection mechanism" the mission requires.

## Step E — Concurrency validation (active DB, application stack, all writes rolled back)

Probe: `tmp-scripts/p0-concurrency-probe.ts` (Prisma 6.19.2, `db/custom.db`).

| Test | Scenario | Result |
|---|---|---|
| Conn facts ×3 | fresh clients | sqlite=3.46.0, busy_timeout=5000ms, foreign_keys=ON — every connection |
| T1 | writer holding the lock 600 ms (delayed rollback) + **10 concurrent readers** | all 10 reads succeeded; writer rolled back; zero mutations — `PASS` |
| T2 | **two competing writers** on the same row, interleaved | both completed via rollback in 833 ms total — the second writer **waited out the lock via busy_timeout** (no `SQLITE_BUSY` hard failure); `PASS` |
| T3 | financial-shaped `$transaction` (payment + installment + auditLog) with forced mid-transaction failure | payments 8→8, audit rows 88→88, installment status unchanged — **fully atomic rollback** `PASS` (this is the exact shape P0-5 enforces at the route layer) |
| T4 | journal_mode stability across client reopen | `delete → delete` — `PASS` |

No data corruption, no lost transaction, no mutation leakage observed. Reader/writer
concurrency under delete-journal + engine busy_timeout is sufficient for the current
single-process deployment shape (one Next.js server, one Prisma pool).

## Retry-safety note (mission Step E)

No application-level retry loop was added: retries are the ORM/engine's busy-wait
domain, and a naive retry around a financial mutation could duplicate it. The
P0-5 transactional boundary (single `$transaction` per money event) is the
idempotency-correct structure; T3 proves it.

## Acceptance criteria

- Exact runtime SQLite version verified — ✅ 3.46.0 (Prisma engine, queried through the connection)
- WAL safety established — ✅ **verdict: unsafe on this runtime → not enabled** (documented blocker + future trigger)
- WAL mode confirmed — ⛔ **BLOCKED** (by design, with evidence — not falsely claimed)
- Busy timeout applied to relevant connections — ✅ engine-managed 5000 ms, verified per-connection ×3 + under contention
- Reopen behavior verified — ✅ (journal mode stable; facts re-read on every fresh client)
- Concurrent reader/writer test — ✅ T1 (10 readers during held write lock)
- Expected write contention handled safely — ✅ T2 (competing writers absorbed by busy_timeout)
- No data corruption or lost transaction — ✅ T1/T2/T3 rollback integrity
