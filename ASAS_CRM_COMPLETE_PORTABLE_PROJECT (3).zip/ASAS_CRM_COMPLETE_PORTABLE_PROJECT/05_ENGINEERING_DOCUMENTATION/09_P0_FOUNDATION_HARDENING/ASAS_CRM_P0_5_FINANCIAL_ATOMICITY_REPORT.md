# ASAS CRM — P0-5 Financial Atomicity Report

**Task:** Financial transaction atomicity & audit trail integrity.
**Status:** IMPLEMENTED · INTEGRATED · TESTED · VERIFIED
**Executed:** 2026-11-03, Agent B (Task ID 5) — implementation; Principal Agent — diff review + independent full-suite verification.

## Step A — Financial write paths inspected

All money-relevant write sites audited: payments POST, installments POST,
installments PATCH, reservation economics (§37 commission / §38 incentive),
plus the already-correct references (reservations POST, reservation-lifecycle)
whose `$transaction` + folded-audit + fault-hook pattern is the house standard.

Confirmed gaps (the F-06 orphan class — committed money without its trail):

| Site | Mutation | Audit/Activity | Gap |
|---|---|---|---|
| `POST /api/finance/payments` | in `$transaction` | **after**, global client | ❌ |
| `POST /api/finance/installments` | in `$transaction` | **after**, global client | ❌ |
| `PATCH /api/finance/installments/[id]` | **no transaction** | separate write | ❌ |
| `src/lib/server/reservation-economics.ts` | separate writes | separate writes | ❌ |

## Step B — Single transactional boundary (all four sites)

Every site now commits **mutation + AuditLog + Activity in ONE `$transaction`**,
with the transaction client passed explicitly to `logAudit`/`logActivity` (the
G5-P3-5 helper signature). Audit payloads preserved byte-for-byte (documented
contracts). Deterministic fault hooks (`x-test-inject`) sit **after the money
writes, before the trail writes**:

| Site | Hook stage |
|---|---|
| payments POST | `payments-post` |
| installments POST | `installments-post` |
| installments PATCH | `installment-patch-post` |
| reservation economics | `reservations-economics` |

Economics detail: signature gained `req: NextRequest` (exact mirror of
`applyReservationLifecycle`); the in-tx updated row is `updatedRow` so the outer
pre-update `row` still feeds the `before:` snapshots and the `decided`/`paid`
comparisons — before/after semantics verified unchanged. The route adapter
change is one line (`applyReservationEconomics(user, reservation, body, req)`).

## Step C — External side effects

No notification/external delivery exists inside these paths; nothing was added.
No distributed event system introduced (mission constraint).

## Step D — Fault injection (automated evidence)

`tests/security/financial-atomicity.test.ts` — 5 mandatory tests, real Prisma
verification, marker-scoped, full teardown (0 residue verified):

| Injected stage | HTTP | DB verification |
|---|---|---|
| `payments-post` | 500 `FAULT_INJECTED` | **0** payment rows (marker); PAYMENT_RECORDED audit count unchanged; PAYMENT activity unchanged; installment status unchanged |
| `installment-patch-post` | 500 `FAULT_INJECTED` | label unchanged; INSTALLMENT_UPDATED audit count unchanged |
| `installments-post` | 500 `FAULT_INJECTED` | 0 installment rows (marker label); 0 INSTALLMENT_CREATED audits |
| `reservations-economics` | 500 `FAULT_INJECTED` (manual probe) | commission fields rolled back to seeded values; 0 COMMISSION_SET audits |

Success-path consistency: payment + PAYMENT_RECORDED audit (actorId = manager) +
PAYMENT activity all verified committed together (201 response).

## Step E — Financial correctness

- Amount validity: zod positive + ≤1e12 (pre-existing, untouched).
- Installment relationships: remaining-balance guard proven — over-collection
  attempt → 422 `EXCEEDS_REMAINING`, no row created.
- Duplicate/retry safety: no retry loops exist (P0-2 decision); the single
  `$transaction` per money event is the idempotency-correct structure, and the
  in-tx re-read of committed payments (TOCTOU closure) was preserved.
- Audit actor identification: verified (`auditLog.actorId` = the recording manager).

## Verification evidence (Principal)

- Full suite re-run by the Principal: **191/191 tests pass** (13 files).
- `bun run lint` + `bun run typecheck` — clean.
- Diff review of all four sites — conforms to the reservations-route house pattern
  (fault hook placement, tx-passed audits, payload preservation).
- Post-suite marker sweep: 0 P0-5 residue rows; probe installment fully restored
  (`CALLED`, payments 8, installments 14 — seed baseline).

## Acceptance criteria

- All relevant payment writes within the same transaction — ✅ (4 sites)
- Audit trail writes included in the transaction — ✅
- Injected audit failure rolls back financial changes — ✅ (automated + probe)
- Successful operations persist consistently — ✅ (success-path test)
- Existing financial workflow tests pass — ✅ (191/191)

## Limitations

- Economics fault hook is wired and manually probed, but not an automated suite
  case (the mandated test spec covered the three finance routes; economics tx
  fold — the mandatory part — is fully implemented and probe-verified).
- Installment `kind` vocabulary: mission-mentioned `INTERMEDIATE` is not in the
  zod enum (`BOOKING|INSTALLMENT|NOTARY|FINAL|OTHER`) — the test uses
  `INSTALLMENT` and documents it.
- `clientIp()` header read stays outside the tx (pre-existing house pattern in
  `audit.ts`, untouched per file ownership).
