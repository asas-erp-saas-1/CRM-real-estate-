# ASAS CRM — P0-3 Production Security Report

**Task:** Production security profile, stable sessions & fail-fast configuration.
**Status:** IMPLEMENTED · INTEGRATED · TESTED · VERIFIED
**Executed:** 2026-11-03, Principal Agent (Agent 3 role). No secret values appear in this report.

## Step A — Environment configuration architecture

Consumers inspected before any change (`rg ASAS_DEMO_MODE/ASAS_SESSION_SECRET`):
`src/lib/server/session.ts`, `src/app/api/auth/{login,session}/route.ts`,
`src/app/api/health/route.ts`, `src/components/crm/login-overlay.tsx` (comment only).
No configuration names were invented — both variables were already documented in
`.env.example` and consumed by existing code.

## Step B — Stable session secret

- `.env` (git-ignored) now carries a **stable development-only secret**
  (`openssl rand -hex 32`, 64 hex chars = 32 bytes) — generated server-side, value
  never printed, never committed.
- **Live proof of stability:** login → cookie issued → **two full dev-server restarts**
  → the same cookie still authenticates (`GET /api/auth/session` → 200 with user).
  Before this change the per-process ephemeral secret invalidated every session on
  each restart.
- Negative control: a forged cookie value still resolves to `user: null` (HMAC gate).
- Production: missing/weak/placeholder secret **crashes the boot** (Step E gate) —
  the ephemeral fallback is now production-impossible; it survives only for
  local/test boots with a loud console.warn.

## Step C — Explicit demo mode (secure default)

`isDemoMode()` flipped from `!== "0"` (default ON) to **`=== "1"` (default OFF)**.
An unset variable can never silently re-enable the F-01 passwordless chain on a
deployment that forgot the flag. The sandbox `.env` explicitly opts in with
`ASAS_DEMO_MODE=1` (isolated demo context — verified live: health reports
`demoMode: true` with the explicit flag).

`.env.example` rewritten to document the new contract (OFF by default; explicit
opt-in for isolated local/test only; production boot with it on is crashed).

## Step D — Secure cookies

Verified in `src/app/api/auth/login/route.ts` (`SESSION_OPTS`): `httpOnly: true`,
`sameSite: "lax"`, `path: "/"`, `secure: NODE_ENV === "production"`, `maxAge: 7d`
aligned with the server-side `SESSION_MAX_AGE_MS` (7 days). Local HTTP development
is unaffected (`secure` is production-scoped). Same-origin CSRF enforcement
(`assertSameOrigin`) remains the transport-independent layer.

## Step E — Fail-fast boot gate (crash, not warn)

New: `src/lib/server/boot.ts` (pure validator) + `src/instrumentation.ts`
(Next.js `register()` hook — runs once per server start).

Wiring proof (`tmp-scripts/p0-boot-gate-probe.ts`, actual `register()` invocation):

| Case | Environment | Result |
|---|---|---|
| 1 | production, no secret, demo on | **boot ABORTED** — `SESSION_SECRET_MISSING` + `DEMO_MODE_PRODUCTION` with exact remedies |
| 2 | production, strong secret, demo off | clean boot proceeds |
| 3 | development, demo on (sandbox shape) | untouched — no throw |

Unit tests: `tests/unit/boot-env.test.ts` — 11 cases covering the full matrix
(missing/weak/placeholder/absent demo/clean prod/multi-violation/dev never gated).

## Health deployment gate

`GET /api/health` now also reports `sessionSecretConfigured: true/false`
(presence only — never the value), alongside the existing `demoMode` /
`demoModeMisconfigured` / `migrations` / `dbOk`. Live sandbox response after the
change: `{"status":"ok","dbOk":true,"migrations":18,"demoMode":true,
"demoModeMisconfigured":false,"sessionSecretConfigured":true}`.
Production release checks: `health.demoMode === false` **and**
`health.sessionSecretConfigured === true`.

## Step F — Session-duration documentation consistency

Implementation is 7 days absolute (`SESSION_MAX_AGE_MS` + cookie `maxAge`).
The one live inconsistency — the login route docblock claiming "lax, 30 days" —
is corrected to "lax, 7 days". Historical audit records (`05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/SECURITY_AUDIT.md`
F-16, describing the pre-fix 30-day state) are preserved as history, per the
mission's evidence rules; every current-behavior document now states seven days.

## Verification summary

- `bun run typecheck` — clean. `bun run lint` — clean.
- Full suite: **174/174 tests pass** (163 pre-existing + 11 new boot-gate tests).
- Session stability across restarts: proven live (above).
- Fail-fast: proven by direct `register()` invocation in a production-shaped env.
- Secret values: never logged, never printed, never committed (`.env` git-ignored;
  backups of this report contain keys only).
