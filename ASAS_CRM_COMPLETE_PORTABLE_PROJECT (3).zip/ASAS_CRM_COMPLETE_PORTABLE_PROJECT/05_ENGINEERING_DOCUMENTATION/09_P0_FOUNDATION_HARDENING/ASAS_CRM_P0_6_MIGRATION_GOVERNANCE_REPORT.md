# ASAS CRM — P0-6 Migration Governance Report

**Task:** Prisma migration governance & SQLite source-of-truth decision.
**Status:** IMPLEMENTED · INTEGRATED · TESTED · VERIFIED
**Executed:** 2026-11-03, Principal Agent (Agent 6 role, first half).

## Step A — Existing scripts inspected

`package.json` (pre-P0-6): `db:push`, `db:generate`, **`db:migrate` → `prisma migrate dev`**
(the ambiguous alias), `db:deploy`, `db:seed`, `db:reset`, `db:snapshot`. Prisma config,
migration chain (18), `supabase/` mirror, docs, and CI references inspected.

## Step B — The misleading command removed

- **`db:migrate` (→ `prisma migrate dev`) — REMOVED.** An alias that can demand a
  destructive reset or mutate applied history must not be one keystroke away from
  the shared database.
- **`db:deploy` alias — REMOVED** (replaced by the explicit `db:migrate:deploy`;
  two names for one action is its own ambiguity).
- Explicit set now: **`db:migrate:deploy`** (the only application path),
  **`db:migrate:status`** (bookkeeping check), `db:seed`, `db:generate`,
  `db:snapshot` (backup), `db:push` (prototyping only — never deployment),
  `db:reset` (destructive, local scratch only — documented in the ADR).

## Step C — Migration policy enforced

- Deployment = `prisma migrate deploy` only (BP-ADR-02 law).
- Authoring = `migrate dev` against a **scratch database only** — now stated in
  every living doc that previously said "run `bun run db:migrate`".
- Applied history is never edited; `db push` is never a deployment substitute.

## Step D — BP-ADR-02 formalized

New: `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/BP-ADR-02_SQLITE_SOURCE_OF_TRUTH.md` — SQLite authoritative
(`db/custom.db`, canonical chain, engine-managed busy timeout per P0-2);
Supabase/PostgreSQL explicitly dormant and unvalidated; the five requirements
for any future approved transition (driver, equivalent chain, data-migration
plan, invariant re-verification, runtime safety re-evaluation). No dormant file
was activated or deleted.

## Step E — Validation

Repository searches + live runs:

| Check | Result |
|---|---|
| No package script contains `migrate dev` | ✅ (programmatic scan of every script) |
| No generic `db:migrate` alias | ✅ removed |
| No stale `db:deploy` references in living docs | ✅ CONTRIBUTING.md, ENVIRONMENT_VARIABLES.md, PRODUCTION_READINESS.md, MASTER_ENGINEERING_PLAN.md, RISK_REGISTER.md updated (historical decision logs preserved as history) |
| `bun run db:migrate:status` | ✅ "18 migrations found — Database schema is up to date!" |
| SQLite source-of-truth documented | ✅ BP-ADR-02 |
| PostgreSQL remains inactive | ✅ zero `src/` imports, files untouched |

## Acceptance criteria

- Ambiguous migration command removed — ✅
- Explicit safe migration commands exist — ✅ (`db:migrate:deploy`, `db:migrate:status`)
- Migration governance documented — ✅ (BP-ADR-02 + updated living docs)
- No `migrate dev` in package scripts — ✅ (verified programmatically)
- SQLite source of truth documented — ✅
- PostgreSQL remains inactive — ✅
- No unnecessary database-provider changes — ✅
