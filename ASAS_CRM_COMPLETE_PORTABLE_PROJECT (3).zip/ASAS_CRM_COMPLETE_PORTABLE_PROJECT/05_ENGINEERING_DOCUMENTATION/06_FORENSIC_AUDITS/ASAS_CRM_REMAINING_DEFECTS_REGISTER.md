# ASAS CRM — Remaining Defects Register

**Companion to:** `ASAS_CRM_INDEPENDENT_AUDIT_REPORT.md` (same audit session, 2026-11-02).
**Scope:** (1) all defects NEWLY discovered by this independent acceptance audit; (2) original roadmap defects verified as genuinely fixed (closed with evidence — for traceability); (3) original defects/claims that remain unresolved, refuted at current state, or blocked.
**Priorities:** P0 = delivery-blocking/critical · P1 = high · P2 = medium · P3 = low. **Environment (ENV)** = caused by the sandbox reset class, repairable by the documented runbook without code changes.

---

## Section 1 — NEW defects introduced at HEAD `753d115` (the undocumented UUID commit)

| ID | Pri | Defect | Root cause | Affected modules | Required remediation | Acceptance criteria |
|---|---|---|---|---|---|---|
| **ND-A1** | **P0** | **Build fails at HEAD**: 20 tsc errors (15 missing-module in template `ui/*` scaffold, 5 broken-symbol in journey orphans) → `next build` aborts; CI static gate red | Commit 753d115 added 18 template files referencing 16 uninstalled packages + 5 abandoned refactor files importing non-existent exports | `src/components/ui/*` (17 files), `src/lib/server/journey-{stats,worklist}.ts`, `src/components/crm/journey-stage-chip.tsx` | Execute the AGENTS.md D-040 resurrection sweep: content-hash purity proof → `git rm` the zombie set → real commit message → worklog entry | `bunx tsc --noEmit` exit 0; CI green; `git log` shows documented sweep commit |
| **ND-A2** | **P1** | **i18n zombie shadowing**: `src/lib/i18n.ts` (3,253 lines, ~1,013 keys/lang, strict subset) shadows `src/lib/i18n/` (1,877 keys) for `@/lib/i18n` (file-before-folder, empirically proven via traceResolution) — 864 keys (46%) lost, 849/2,055 render sites raw, all 12 views, 3 nav labels, 3 view titles, multiple aria-labels; modular i18n system orphaned | Same commit resurrected a file deleted twice in history (P26/P32 eras) | `src/lib/i18n.ts`, `src/lib/client/store.ts:10` + 4 more importers, all view text layers | Delete `src/lib/i18n.ts` (zero key loss — strict-subset property verified) | One-file deletion; `t()` resolution to modular domains; spot-check `nav.journey` renders Arabic/French/English |
| **ND-A3** | **P1** | **Dev-server global API poisoning**: one request to `/api/journey/export` (broken import `isJourneyStalled`) degrades EVERY subsequent API request to 500 HTML dev-error pages (incl. previously-compiled routes); leaks absolute paths/stack in dev HTML; server never recovers without restart | Broken orphan route committed; dev-mode module-resolution failure is sticky | `/api/journey/export`, `lib/server/journey-worklist.ts`, entire API surface in dev | ND-A1 sweep removes the route (or fixes the 4 missing exports if journey export is genuinely wanted) | Unauthenticated matrix returns 401 JSON consistently; dev.log free of journey-worklist errors |
| **ND-A4** | **P2** | **Dead parallel implementations committed**: 4 duplicate UI concepts (Sonner vs dead ui/toast+toaster+use-toast; live sidebar-nav vs dead ui/sidebar 726 lines; live states.tsx vs dead view-placeholder; live inline chips vs dead journey-stage-chip) + dead endpoints (`GET /api` junk — also unguarded; check-duplicates; unit-types) + dead `journey-facet.ts` (docblock claims it is "THE one server-side lifecycle filter" — wired to nothing) | Same commit | 10 files + 3 routes | Same sweep; disposition the 40 orphan screenshots | Zero-importer scan clean; `GET /api` returns 404 |
| **ND-A5** | **P2** | **Governance hole**: HEAD commit 753d115 (103 files, +8,164 lines) recorded NOWHERE in the append-only worklog; violates the binding D-040/D-041 law (AGENTS.md:17 "NOTHING ever-deleted ∧ in-HEAD is tolerable") | Environment debris committed without review | worklog.md, git history | Sweep commit + retrospective worklog entry documenting 753d115's provenance | worklog references the sweep commit and the 753d115 hash |

## Section 2 — NEW engineering defects discovered in otherwise-verified code

| ID | Pri | Defect | Root cause | Affected modules | Required remediation | Acceptance criteria |
|---|---|---|---|---|---|---|
| **ND-B1** | **P2** | `oppBefore` read AFTER the validate_closure transaction commits → the dedicated `OPPORTUNITY_STAGE_CHANGED` audit row is unreachable dead code (post-tx read always sees CLOSED_WON; `SALE_VALIDATED.after.opportunityStage` always post-state) | Read placed outside `reservation-lifecycle.ts:225-228` while the guard needs pre-state | Money-path audit trail | Move the read inside the tx or pass it out | A CLOSED_WON transition produces both the Activity row and the opportunity audit row (probe on seeded data) |
| **ND-B2** | **P2** | request_closure / reject_closure write Activity+Audit **outside** any `$transaction` (crash between = state change with no trail) — the exact class D8/W2.6 fixed for reactivate; validate_closure's audit/activity rows are also post-commit | House tx law (F-06) not applied to two lifecycle transitions | `reservation-lifecycle.ts:123-159, :279-315` | Wrap the triads in `db.$transaction` (pattern already proven in cancel :319-341) | All 4 reservation lifecycle transitions are single-tx mutation+trail |
| **ND-B3** | **P2** | PG chain missing the **per-opportunity** live-hold partial unique index while `schema.postgres.prisma:611-617` claims both deploy on PG | Supabase migration set never extended after D12 | `supabase/migrations/` (needs 0005), PG deployments | Add the index to the PG chain or correct the schema comment | Both live-hold indexes present in a PG deployment (or the comment matches reality) |
| **ND-B4** | **P3** | Apartment dialog blind to CLOSURE_REQUESTED holds: `GET /api/reservations?apartmentId=` force-filters `status:"ACTIVE"` when no status param → closure-pending hold invisible in the unit's reservation block (display-only; booking still 409s) | Default filter narrower than the live-hold vocabulary | `reservations/route.ts:107-111`, `apartment-detail-dialog.tsx:131-140` | Widen default to `["ACTIVE","CLOSURE_REQUESTED"]` for the apartment-scoped lookup | Dialog shows closure-pending holds; booking behavior unchanged |
| **ND-B5** | **P3** | `PRE_BOOKING_STAGES` hand-declared in the booking tx instead of derived from OPPORTUNITY_TRANSITIONS (reverse-index pattern used elsewhere) | One-off literal | `reservations/route.ts:340-347` | Derive from the matrix | Single source; adding a stage updates booking preconditions |
| **ND-B6** | **P3** | Revival keeps original `createdAt` → "latest row wins" (`createdAt desc`) can surface a newer CANCELLED row over an older revived ACTIVE hold | Display heuristic vs revival semantics | `reservations/route.ts:113-147` | Recency bump (e.g. `reactivatedAt`) or smarter ordering | Deal cockpit shows the ACTIVE hold after revival |
| **ND-B7** | **P3** | scrypt cost constants declared but never passed (`SCRYPT_N/R/P` dead) — actual params are Node defaults, correct-by-coincidence vs all comments/DUMMY_HASH | Constants not wired | `lib/server/auth.ts:21-23` | Pass `{N, r, p}` explicitly | Documented strength is contractual |
| **ND-B8** | **P3** | Client-side stage-constant survivors: `CLOSED` re-declared in `analytics-kpi.tsx:42` + `CLOSED_STAGES` in `pipeline-view.tsx:47` (the R15 dedup killed 8 server sites, missed 2 client sites) | Dedup scoped to server files | 2 components | Adopt `OPP_CLOSED_STAGES` import | Zero local re-declarations of the closed-stage set |
| **ND-B9** | **P3** | `X-Powered-By: Next.js` unsuppressed | config | next.config.ts | `poweredByHeader: false` | Header absent |
| **ND-B10** | **P3** | `opportunityInclude` still declared in 2 routes despite the T4 helper extraction | Partial dedup | `api/opportunities/route.ts:19`, `[id]/route.ts:33` | Move to the helper | Single declaration |
| **ND-B11** | **P3** | Stale handoff docs: `supabase/seed.sql` is 606 rows; HANDOFF_CHECKLIST.md:38 + DATA_EXPORT_BLOCKED.md:54 still claim 511 | H3-era figure never refreshed | 2 docs | Update figures | Docs match seed.sql |
| **ND-B12** | **P3** | `package.json:14` exposes `db:migrate` = `prisma migrate dev` while the D12 migration header + schema comments declare `migrate dev` forbidden on this DB (deploy-only law) | Script contradicts law | package.json | Remove/rename the alias | No dev-migrate alias |

## Section 3 — Original defects verified FIXED (closed with evidence — traceability)

All D1–D14 roadmap defects + wave tasks were located in code with file:line evidence by Auditor E and closed: D1 revival guard + complete field reset (`reservations/route.ts:248-259, 294-318` — reset list checked field-by-field vs schema); D2 (`apartments/[id]:63-79`); D3 (`opportunities/[id]:175-188`); D4 + one-live-hold (`reservations/route.ts:196-203, 268-283`); D5 reassign cascade (`leads/[id]:335-338`); D6 create-dialog CLOSED_WON removal; D7 stageChangedAt stamp (`reservation-lifecycle.ts:213` — with ND-B1 caveat); D8 single-tx reactivate (`reactivate/route.ts:39-69`); D9 sweeper (live in dev.log polling); D10 guarded release (`reservation-lifecycle.ts:333-336` + sweeper parity); D11 activity/requirement auto-advance in-tx; D12 twin guard (activities) + DB indexes (migration #17 verbatim); D13 metrics (`lib/metrics.ts` + adoption); D14 closedAt true-fact. SEC-V01 production fail-fast code-verified (`session.ts:115-117`); SEC-V03/V04/V05/W1.3/W1.4/W1.5 all verified (live headers + code); ARCH-T1 visit-facets single-sourcing verified; PERF-P1 bounded; DB-4 index live.

**Not reopened** — these are closed as genuinely fixed at the code level; their runtime re-verification is gated by Section 4 items.

## Section 4 — Environment-class blockers (repairable by the documented runbook; NOT code defects)

| ID | Pri | Blocker | Required remediation (AGENTS.md runbook) | Acceptance criteria |
|---|---|---|---|---|
| **R-E1** | **P0** | Live DB empty (0 rows; login impossible → all authenticated acceptance BLOCKED) | Fresh `db/custom.db` → `bunx prisma migrate deploy` (17/17) → `bun run db:seed` | Census 8/43/21/46/8/23/18/183/85; `user count ≠ 0` pre-QA law satisfied |
| **R-E2** | **P1** | `_prisma_migrations` absent; **D12 partial unique indexes MISSING from live DB** (db-push provenance) — the D12 "DB-enforced" invariant is not operative on the live file | Same runbook (migrate deploy creates both indexes) | Both index names present in `sqlite_master`; violation probe on a COPY fires |
| **R-E3** | **P1** | `ASAS_SESSION_SECRET` unset (ephemeral per-restart secret; sessions die on restart — the W1.1 fix regressed with the environment) | Re-append to `.env` per runbook | dev.log warning gone after reload; sessions survive restart |
| **R-E4** | **P2** | `db/backups/` wiped (all sha256-anchored snapshots gone) | Re-establish baseline after recovery | `db/backups/` exists with a fresh sha256-recorded snapshot |
| **R-E5** | **P2** | WAL claim currently false (`journal_mode=delete`) | Re-apply PRAGMA after recovery | `PRAGMA journal_mode` = wal |
| **R-E6** | **P2** | Cron register empty (documented 7th reap of the webDevReview job class — AGENTS.md P14 owner instruction vs. per-session mandate conflict) | Owner decision (see prior register R-06) — NOT recreated by this audit per the explicit no-development directive | Explicit owner decision recorded |

## Section 5 — Carried-forward unresolved/deferred items (verified still open, with prior register cross-reference)

| ID | Pri | Item | Status | Cross-ref |
|---|---|---|---|---|
| R-C1 | P2 | Git-history purge (1 dead secret blob at `66b7c13` + demo DB in ~10 commits) before ANY remote | BLOCKED [owner authorization D-013] — never pushed, no remote (verified) | prior R-16; GIT_HISTORY_PURGE.md pre-verified accurate |
| R-C2 | P2 | PG/Supabase RLS runtime verification (150 policy statements structural-only) | BLOCKED [owner's Supabase project required] | prior R-08 |
| R-C3 | P2 | Production build never executed anywhere (build-failure inference at HEAD is deterministic but not from a run) | BLOCKED [env forbids build] | prior R-09 |
| R-C4 | P2 | Demo-mode production fail-fast runtime check (NODE_ENV=production impossible here) | IMPLEMENTED, not runtime-verified | prior R-10 |
| R-C5 | P2 | No automated test runner (house law) — the systemic enabler of the silent HEAD regression | REJECTED WITH JUSTIFICATION (policy) — this audit flags the risk formally: every future resurrection-class regression will also be silent | prior R-12; new ND-A1 demonstrates the failure mode concretely |
| R-C6 | P3 | Trigram search (PG-only), Vitest suites, new-row-per-booking revival flow, TruncationNotice extraction, production checklist (DEMO_MODE=0/TLS/supervisor/monitoring) | DEFERRED by design / owner-gated (verified still documented as such) | prior R-13…R-15, R-19 |

---

## Register summary

**Newly discovered:** 5 commit-class defects (1× P0, 2× P1, 2× P2) + 12 engineering defects (2× P2, 10× P3) + first-hand reproductions of 2 phenomena (poisoning; console-error class).
**Original defects:** all 14 domain defects + the audited wave tasks verified FIXED in code (Section 3); 4 runtime re-verification classes BLOCKED by environment (Section 4); 6 carried-forward deferred/blocked items verified still open (Section 5).
**Total open actionable (non-owner-gated):** P0 ×2 (ND-A1 sweep + R-E1 reseed — both mechanical, ~1 session combined) · P1 ×5 · P2 ×10 · P3 ×12.

**The single highest-leverage repair:** the AGENTS.md-mandated session-entry protocol (sweep + runbook + re-verify) — it closes ND-A1/A2/A3/A4/A5 and R-E1/E2/E3 simultaneously and restores the repository to the verified `b34d5b8`-equivalent state.
