# PHASE 2.3 — App-wide UX Consistency Contract

- **Mission:** unify the user experience across ALL 12 views (dashboard, journey, leads, pipeline, visits, tasks, properties, finance, sav, analytics, audit, settings) — pages organized and consistent (user directive, 2026-11-03).
- **Method:** behavior-neutral presentational unification. No API, state, or data-flow changes. Every law below is derived from a measured baseline (see audit table).
- **Baseline date:** 2026-11-03, post `bf47ec7` (Phase 2.2 closed 26/26 PASS).

## Baseline audit — confirmed fragmentation

| ID | Axis | Measured split |
|---|---|---|
| F-01 | View-root vertical rhythm | `space-y-3` ×6 (leads, pipeline, tasks, properties, audit, settings) vs `space-y-4` ×6 (dashboard, journey, visits, finance, sav, analytics) |
| F-02 | Toolbar search grammar | 3 dialects: leads/audit/pipeline `h-9 ps-8 text-crm-body` + `min-w-52 flex-1 sm:max-w-xs`; finance/sav `ps-8` (no height/body) + `min-w-44 sm:max-w-72`; journey `ps-8` + **no aria-label** |
| F-03 | Segmented controls | analytics range Tabs `TabsList h-9` / trigger `h-7 px-3 text-xs`; dashboard range Tabs trigger `h-6 px-2.5 text-xs` — same semantic, different metrics |
| F-04 | ResultCount grammar | pipeline bare `tabular-nums`; journey `tabular-nums text-muted-foreground (N)`; finance/sav `ms-auto text-crm-caption text-muted-foreground` + i18n `{count}` |
| F-05 | a11y | journey search input missing `aria-label` |

## The six laws (L1–L6)

**L1 — Rhythm.** Every workspace view root is `space-y-4`. (Toolbar→content, card→card breathing identical everywhere.) **Exception:** settings is a "document" genre (narrow `max-w-3xl` centered form column) and keeps its own wider `space-y-6` rhythm — a genre distinction, not fragmentation.

**L2 — SearchField.** Every toolbar text search is the shared `SearchField` (`views/shared/search-field.tsx`): wrapper `relative min-w-44 flex-1 sm:max-w-72`, icon `start-2.5 size-4`, input `h-9 ps-8 text-crm-body`, `aria-label` defaults to `t("action.search")`. Composers (task quick-add) are not searches and keep their own grammar.

**L3 — Segmented controls.** Two semantic families, one grammar each:
- **Time-range** (dashboard, analytics): Tabs — `TabsList h-9`, trigger `h-7 px-3 text-xs`.
- **Entity-bucket / pane** (finance, sav, journey): pill ToggleGroup — `size="sm" h-7 rounded-full px-3 text-crm-caption`, `data-[state=on]:bg-primary/10 data-[state=on]:text-primary`.

**L4 — ResultCount.** Toolbar totals render through `views/shared/result-count.tsx`: `ms-auto whitespace-nowrap text-crm-caption text-muted-foreground` + domain i18n rows key (e.g. `finance.rows` / `sav.rows`). In-card section counts: `ms-1 tabular-nums text-muted-foreground`, no parentheses.

**L5 — a11y floor.** Every search/filter control carries an explicit accessible name; no exceptions.

**L6 — Skeletons.** List skeletons use the established row grammar (icon-sized `h-9` blobs + text `h-4` widths, `border-b last:border-b-0`, `px-4 py-2.5` rows) — new surfaces copy `views/visits-view` skeleton pattern.

## Out of scope (verified already consistent)

- Shell chrome: topbar h1/subtitle, sidebar, footer status bar (single source in `shell.tsx`).
- `EmptyState`/`ErrorState` adoption (universal across views).
- `TablePagination` (leads + audit — the only two paginated lists).
- KPI presentation (intentionally per-domain: attention strips vs KPI strips vs summary grids — product-tier decision, not fragmentation).

## Verification gates

1. `bun run lint` clean; `bunx tsc --noEmit` 0 errors; `bun test` 163/163.
2. Browser QA: all 12 views render at 360/375/390/430 (mobile), 768/1024 (tablet), 1280/1440/1920 (desktop) — zero horizontal overflow, toolbar wraps cleanly.
3. Screenshots + report in `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ux-consistency/`.
