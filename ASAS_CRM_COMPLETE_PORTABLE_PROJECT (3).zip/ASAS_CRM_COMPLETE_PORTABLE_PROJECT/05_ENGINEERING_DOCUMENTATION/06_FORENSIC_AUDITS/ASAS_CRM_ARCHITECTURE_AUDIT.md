# ASAS CRM — Architecture Audit (Agent A)

Scope: 65,519 LOC / 314 TS-TSX files / 68 API routes / 31 models · tsc+eslint pass verified.

## Architecture Map
```
src/app/api/** (68 routes) → lib/server/{session,validation,audit,visibility,leads,faults,
                                  visit-gate,reservation-*,matching,duplicates,expiry,...}
                              → lib/db (Prisma singleton) + lib/constants (enum/transition source)
src/components/crm/** (120)  → lib/client/{api,types,store,session,whatsapp} + lib/i18n + lib/{format,dates,journey,phone}
lib/client ✗ lib/server (boundary clean) · components ✗ lib/server · no reverse imports
```
- **Circular dependencies: NONE** (Tarjan SCC over all `@/` imports = 0 cycles).
- Shared-helper adoption: session **76** sites, audit **48**, validation **47**, visibility **41**, leads **20**.
- State mgmt: TanStack Query (63 useQuery / 44 useMutation), zustand for UI/nav only, RHF+zod forms. Consistent.
- Error handling: 68/68 routes use `try/catch → fail(e)`; uniform `{error, code, details}` envelope; 401/403/scoped-404 byte-consistent. Only deviation: 409 duplicate envelope (intentional contract shape).
- Types: zero `any` leaks, zero `@ts-ignore` (rg-verified). Naming 100% consistent.

## Duplication Report (evidence in file:line)
| ID | Pattern | Evidence | Should live in |
|---|---|---|---|
| D1 | `visitInclude` byte-identical | visits/route.ts:25-33 vs visits/[id]/route.ts:131-139 | new `lib/server/visits.ts` |
| D2 | `flattenApartments` ×5 sites | visits/route.ts:35-37; visits/[id]:124,555; leads/[id]:112 | same |
| D3 | `taskInclude` identical | tasks/route.ts:14-21 vs tasks/[id]:18-24 | new `lib/server/tasks.ts` |
| D4 | `OPEN_WORK` ×2 | sav/route.ts:51 vs sav/[id]:53 | `SAV_OPEN_STATUSES` const |
| D5 | SAV enum re-declared inline; canonical const dead | sav/route.ts:83 vs constants.ts:497 | import `SAV_STATUSES` (latent filter-drift bug) |
| D6 | KPI predicates mirrored dashboard↔visits | dashboard/route.ts:147-149,175,208-209 vs visits/route.ts:85-89,116-121,130-136 | new `lib/server/visit-facets.ts` |
| D7 | owner-or-manager gate ×9 | tasks/[id]:104, activities/[id]:35, visits/[id]:347,574, leads/[id]:224, documents/[id]:69,146, analyze:218, opportunities/[id]:237 | `requireOwnerOrManager()` |
| D8 | notes zod fragment ×9 | 9 route files | `notesField` in validation.ts |
| D9 | budget-range check ×3 | leads/route.ts:171-173, leads/[id]:204-208, requirements:46-48 | `assertBudgetRange()` |
| D10 | scoped opp lookup + 404 ×5 | tasks:101-105, visits:233-237, reservations:~156, opportunities/[id]:59,232 | `findOpportunity()` |
| D11 | conditions-composition idiom ×12 | 12 list routes | NOT worth abstracting (documented decision) |

## Top files (verdicts): leads.ts i18n 1118 ✅ data-only · types.ts 1068 ⚠ contract single-point · visit-dialogs 920 ⚠ cohesive family · journey.ts 733 ✅ pure machine · visits/[id]/route 610 ⚠ justified complexity. **No file is unjustifiably complex — splitting is NOT the priority; dedup is.**

## Dead exports (verified zero usages): `canWhatsApp` (client/whatsapp.ts:50), `LANGS` (store.ts:13), `PriorityChip` (badges.tsx:268), `NAVIGABLE_AUDIT_ENTITIES` (audit-destinations.ts:66), `ORIENTATIONS`/`APARTMENT_PAYMENT_PLANS`/`PROJECT_STATUSES`/`SAV_STATUSES` (constants.ts:219,222,350,497 — adopt or delete).

## Technical Debt Register
T1 **P1** dashboard/visits predicate mirroring → extract visit-facets.ts · T2 **P2** SAV enum drift → import const · T3 **P2** visits/tasks include dedup → lib/server/{visits,tasks}.ts · T4 **P2** findOpportunity · T5 **P2** API contract types client-side only · T6 **P3** requireOwnerOrManager · T7 **P3** notesField/assertBudgetRange · T8 **P3** dead exports · T9 **P3** parseIntParam silent clamp (documented exception) · T10 **P3** persisted Activity titles French-only (accepted trade-off) · T11 **P3** visits/[id] concentrates 6 flows (split only if touched again) · T12 **P3→P0-if-deployed** demo-mode defaults.

**Confirmed defect:** D5/T2 (live latent bug: a 6th SAV status would be silently rejected by the route filter). **Risks:** T1, T4, T5, T12. Rest = optimization.

## Adopted improvements (measurable only)
1. Extract `visit-facets.ts` — makes "KPI == list total" structural instead of comment-enforced.
2. `lib/server/visits.ts` + `tasks.ts` mirroring the leads.ts pattern (~40 LOC dedup, testable contract).
3. `findOpportunity` + `requireOwnerOrManager` + `notesField`/`assertBudgetRange` (~10 call-site swaps).
4. SAV enum import fix (one line, closes latent bug). 5. Delete 7 dead exports.
6. **Do NOT** split i18n dicts, journey.ts, constants.ts, or view monoliths; **do NOT** add a service layer — the route→lib/server layering already delivers it.
