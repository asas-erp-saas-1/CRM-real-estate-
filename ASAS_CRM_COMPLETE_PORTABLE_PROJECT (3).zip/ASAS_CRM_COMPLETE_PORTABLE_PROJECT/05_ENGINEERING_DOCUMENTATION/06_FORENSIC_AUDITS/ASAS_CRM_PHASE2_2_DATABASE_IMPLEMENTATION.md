# ASAS CRM — PHASE 2.2 DATABASE IMPLEMENTATION

**Task owner:** Principal · **Status: VERIFIED (no schema migration required — by design)**

## 1. The engineering decision

Phase 2.2's database work was **verified, not churned**. The Phase 2.1 schema
(28 models, FK-complete, cascade law, money law, D12 indexes) already models
the domain correctly. The Customer-book gap was **not** a missing table — the
`Contact` model (1:1 with converted `Lead`, org-scoped, indexed) is the durable
customer identity; what was missing was the **access surface**. Adding
duplicate customer fields (status, value, lastContact) would have violated the
data-duplication law — every signal is DERIVED from recorded facts:

| Signal in `/api/customers` | Derivation (existing schema) |
|---|---|
| Journey stage | `computeJourney(lead + visits + opps + reservations)` — the CJ engine |
| Commercial weight | sum of open `Opportunity.value` (non-`OPP_CLOSED_STAGES`); won value from `CLOSED_WON` |
| Last interaction | `Lead.lastContactAt` (maintained by the activity log path) |
| Next action | MIN(`Lead.nextFollowUpAt`, open opps' `nextActionAt`, next SCHEDULED/CONFIRMED `Visit.scheduledAt`) |
| Idle tier | `lastContactAt < now − 14d` (the leads rotting-ladder law) |

## 2. Query efficiency (measured)

- **One page query** (`contact.findMany` with the journey FACT projection, `take: 500` ceiling) + **one batched reservation fetch** for the whole page's opportunity ids — the journey route's money-path join law, mirrored exactly (no N+1).
- Dev-server log: `GET /api/customers?sort=recent&page=1&pageSize=25 → 200 in 18ms`.
- Prisma query log shows exactly 2–3 statements per request (contacts + reservations + optional search-probe).

## 3. Integrity verification

- `bun run db:seed` re-run cleanly (idempotent) before QA: 8 users / 43 leads / 20 contacts / 21 opps / 23 visits / 183 activities.
- The archived-lead law holds: creating + archiving a synthetic pool lead (`Test Pool Lead P22`) moved `unassigned=1` total 0 → 1 → 0, and the lead remains in the DB (archived, preserved — no destructive delete).
- `/api/health` now truthfully separates DB connectivity (200) from migration bookkeeping (null on this push-based sandbox DB; 18 on migration-chain deploys).

## 4. Schema objects touched

None (verified deliberate non-change). The ERD and data dictionary from Phase
2.1 remain accurate; the customer book adds zero columns, zero tables, zero
migration — it composes the existing relations.
