# ASAS CRM — UX/UI Audit (Agent D)

Live-audited at :3000 · 49 screenshots in `download/qa-master/` · axe-core + VLM assisted · DB was empty at start (seeded via project's own idempotent seed to audit the real product).

## Page inventory (all visited): login (FR/AR), dashboard (light/dark), journey, leads (+drawer, create dialog, empty/error states, EN), pipeline Kanban + opportunity dialog, visits (list/calendar/schedule dialog), tasks, inventory (grid/table), finance (+3 dialogs), SAV (+detail), analytics, audit, settings (6 sections), ⌘K, notifications, duplicates merge, density toggle, AR-RTL (dashboard/leads/pipeline), mobile 390×844 (4 views), agent role (6 views).

## Findings
### P1
1. **Nested interactive controls in every leads row** (axe `nested-interactive`, 25 nodes): row is a button containing checkbox + tel link + WhatsApp button. Fix: row = non-button container, name cell = row opener, separate action cells.
2. **Dark-mode WCAG failures (3 nodes)**: active FR lang chip (≈2.6:1), role badge "Directeur exécutif", sidebar footer "ASAS Immobilier" (white@50%). Fix: token adjustments in `.dark`.

### P2
3. "Trouver des biens" button: 200 OK but results render at drawer bottom — no scroll, no toast, no count → perceived dead button. 4. Mixed-language AR content (data-level: task titles/notes French in Arabic chrome) → bidi isolation (`dir="auto"`). 5. **EN a11y names in FR/AR dialogs** (react-day-picker defaults: "Show date picker", "Month Month") → pass locale/labels. 6. Dashboard decision cards clip client names + addresses (the decision datum) → 2-line clamp + tooltip. 7. Finance table: two columns both "ÉCHÉANCE" → rename first to "LIBELLÉ". 8. Currency drift: `102M DA` / `15M DA` / `1 750 000 DA` / `18 800 000 DZD` → single formatter, compact for KPIs, full for tables, DA everywhere. 9. Duplicate toast on persona switch.

### P3
10. Dashboard accent proliferation (purple+red+amber+green/teal) → 1 primary + 2 semantics. 11. FR pluralization ("1 vendus"). 12. Funnel vs pipeline vocabulary mismatch. 13. `document.title` static across 12 views. 14. Only 3/11 leads columns sortable. 15. Error copy conflates all failures as "API non encore disponible". 16. Kanban: 2668px internal scroll, no column-jump. 17. Mobile touch targets 24–40px < 44px. 18. AR dual grammar. 19. SAV-3 "—" client/bien (seed). 20. Density toggle nearly imperceptible (36↔40px).

## Component consistency: tables (leads/finance/SAV/audit) share header style + hover + sticky header ✅ EXCEPT leads row-as-button divergence; cards/dialogs/badges consistent; only date pickers break the language contract; mobile coverage gap: Finance/SAV/Audit mobile not verified (follow-up).

## Role-based UX (Sarah MANAGER vs Amine AGENT, verified live): **strong isolation** — agent nav 8 vs 12 items; "Ma journée/Mes incentives/Mes prospects"; own targets row only; ⌘K finance → no results; 14 vs 43 leads; no economics leaked. Persona quick-switcher = demo affordance (documented).

## RTL: `dir=rtl`+`lang=ar` verified; sidebar mirrored (measured); no overflow at 1440; login flips. Western numerals appropriate.

## Responsive 390×844: scrollWidth=390 (no overflow) on 4 views; sidebar→Menu sheet; leads→card list; pipeline→stacked columns w/ explicit "Déplacer" button. ⚠ touch targets.

## Verified-good: login UX (split panel, show/hide, code-aware errors, RTL pre-auth); form validation (red asterisks, inline errors, borders); designed empty/error states; ⌘K grouped+keyboard legend; notifications day-grouped; FR copy professional + domain-correct; AR covers enums/currency/dates; 4-view consistency "highly consistent" (VLM).

## Adopted remediation order: (1) a11y row nesting + contrast tokens NOW; (2) match feedback, currency unification, column rename, picker locale, toast dedupe, de-truncation; (3) accent rationalization, more sort columns, per-view titles, bidi isolation, 44px targets, mobile coverage of finance/SAV/audit, error copy split, Kanban column-jump.
