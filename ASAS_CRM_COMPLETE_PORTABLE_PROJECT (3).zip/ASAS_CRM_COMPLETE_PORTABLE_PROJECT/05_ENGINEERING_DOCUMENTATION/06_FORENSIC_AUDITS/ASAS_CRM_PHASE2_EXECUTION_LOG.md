# ASAS CRM — Phase 2 Execution Log

**Mission:** Controlled implementation of the validated Phase 1 findings (remediation, refactoring, features, hardening).
**Baseline:** git `de787ec` (main, clean) · **Delivered:** see the Phase 2 commit on `main` (this round).

Statuses used: NOT STARTED / IN PROGRESS / BLOCKED / IMPLEMENTED / TESTED / VERIFIED / DEFERRED.

---

## Wave 1 — Foundation & validation (Principal, serial)

| Task | Detail | Status |
|---|---|---|
| W1.1 Phase 1 deliverable review | All 9 audit docs + AGENTS.md + git history + worklog read; every P0/P1 finding independently re-verified against current code (see IMPLEMENTATION_PLAN §1 table). 4 recommendations REJECTED with documented reasons (Vitest suites — house law; production build — env-disallowed; new-row-per-booking revival — kept deferred, safe state; PG RLS — N/A on SQLite). | VERIFIED |
| W1.2 DB snapshot baseline | `db/backups/custom-20261101-233426-phase2-baseline.db` (sha256 `b0d926ac…`). | VERIFIED |
| W1.3 Environment gates | tsc 0 · eslint 0 · dev :3000 healthy · tree clean. | VERIFIED |
| W1.4 Implementation plan | `ASAS_CRM_PHASE2_IMPLEMENTATION_PLAN.md` (validated findings, rejected recommendations, waves, risks, acceptance). | VERIFIED |

## Wave 2 — Integrity hardening (Principal, serial — DB centrally coordinated)

| Task | Problem → Root cause | Files | Tests executed | Status |
|---|---|---|---|---|
| W2.1 **D12 race closure** | Two interleaved POST /api/reservations could theoretically both pass the in-tx guards before either commit (the FINAL round's documented theoretical residue). Root cause: invariant enforced only in application code. | `prisma/migrations/20261102000000_phase2_d12_live_hold_unique/migration.sql` (raw SQL — Prisma cannot express partial indexes) · schema.prisma + schema.postgres.prisma comments | Pre-check: 0 violations on both invariants (8 reservations, 1 ACTIVE). **Violation probes on a DB COPY** (never live): duplicate ACTIVE apartment hold → constraint fired ✓ · duplicate ACTIVE opportunity hold → fired ✓ · terminal row on same apartment still insertable (partial-index legality) ✓ · copy discarded. `migrate deploy` → 17 applied, indexes present in live DB, data intact (8 reservations). **Live booking round-trip** (synthetic lead → opp → book A-02 → 201 ACTIVE + apartment RESERVED + stage advance → cancel → CANCELLED + apartment AVAILABLE → FK-ordered cleanup, census restored 8/43). P2002→ALREADY_RESERVED mapping pre-existed in the route — zero code change needed. | VERIFIED |
| W2.2 **Production demo fail-fast** | SEC-V01's residual: production deployments forgetting `ASAS_DEMO_MODE=0` kept the F-01 takeover chain silently alive. Root cause: env law was documented but not code-enforced. | `lib/server/session.ts` (`isDemoModeMisconfigured()` + one-time boot warning) · `api/auth/login/route.ts` (500 `DEMO_MODE_PRODUCTION_MISCONFIG` on quick-login) · `api/auth/session/route.ts` (demoUsers suppressed in misconfigured production) | NODE_ENV-gated (production only) — sandbox demo untouched by construction; quick-login + session routes reviewed; dev.log warning path confirmed inert in development. | IMPLEMENTED (production-path code; cannot execute a production build in this environment — by design) |
| W2.3 SECURITY.md checklist | Document the fail-fast mechanism. | `SECURITY.md` | doc review. | VERIFIED |

## Wave 3 — Feature wave (parallel agents, disjoint file ownership)

| Task | Agent | Files | Tests executed | Status |
|---|---|---|---|---|
| W3.1 **Targets month-copy** | ENG-D (Task 3-a) | `api/targets/copy/route.ts` (NEW) · `settings/targets-section.tsx` · i18n `dashboard.ts` (+11 keys ×3) | Agent live-verified as OWNER (copy 2026-11→2026-12, 3 rows/75M byte-correct, toast + month jump, AR/RTL render, cleanup restored). Central re-verification this round: dialog contract (source summary + next-month default + overwrite note), copy executed live (3 rows byte-correct vs source), December restored to baseline (0 rows). Audit i18n labels `SALES_TARGET_COPIED` added centrally (§26 law — the agent flagged the gap). | VERIFIED |
| W3.2 **PDF first-page thumbnails** | ENG-E (Task 3-b) | `api/documents/[id]/thumb/route.ts` (NEW) · `documents/doc-thumb.tsx` · `lib/server/documents.ts` (renderPdfPages +optional dpi, backward compatible) | Contract matrix verified live: PDF → 200 PNG 612×792 64KB with `private,max-age=86400` + nosniff ✓ · nonexistent → 404 ✓ · unauthenticated → 401 ✓ · image → 307→file ✓. **Central integration fixed two gaps the ownership boundary produced** (see Wave 4). | VERIFIED |
| W3.3 **Polish batch** | ENG-F (Task 3-c) | 6 files: truncation-banner quartet (`pipeline-view`/`tasks-view`/`visits-view`/`inventory-filters`) `text-[12px]`→`text-crm-body` · copilot risk callouts + noTags hint → `text-crm-caption` | Survey verdicts: incentiveStatus chip = **already coherent** (the named candidate was deleted in WS-S round — git `-S` evidence; 0 chip surfaces today, extraction bar fails at 0 — no invented work). Type-scale: ~120 literal sites examined, 6 converted, deliberate-size list documented. | VERIFIED |

## Wave 4 — Central integration + robustness (Principal, serial)

| Task | Detail | Status |
|---|---|---|
| Integration review | Full git-diff review of all agent work; ownership boundaries held exactly. | VERIFIED |
| **Integration fix 1 — document-row gate** | Live QA surfaced: PDF rows never rendered DocThumb — `document-row.tsx:86` gated on `IMAGE_MIME` (agent 3-b was forbidden to touch that file — the boundary gap). Fixed: gate → `PREVIEWABLE_MIME` (images + PDFs both get the rounded thumbnail; onError fallback covers corrupt files); stale `PDF_MIME` comment updated; unused `IMAGE_MIME` import dropped. After fix: both thumbnails render live (image 8×8 redirect, PDF 612×792 raster). | VERIFIED |
| **Integration fix 2 — thumb retry** | Live QA surfaced a real robustness defect: a transient thumb failure (dev cold-compile / poppler first-load) permanently degraded the row to the icon (sticky onError). Fixed: ONE cache-busting retry before accepting the fallback (the durable signal). | VERIFIED |
| Demo dataset decision | The two QA-uploaded documents kept as natural demo data on Réda Mokrani's lead (renamed: « Contrat de vente — lot H-02 » PDF + « Pièce d'identité — Mokrani ») — the standing matrix asserts relative counts (its own scratch records with exact cleanup), so the baseline stays valid, and the feature is now demonstrable in the demo workspace. | VERIFIED |
| Bounded-loop note | `targets/copy` upserts in a loop inside ONE transaction — bounded by org users with a target (≤ ~20 realistically); the per-natural-key upsert is the correctness-critical part (deleteMany+createMany would lose upsert semantics for no measurable gain at this scale). Documented here per the N+1-audit disclosure discipline. | DOCUMENTED |

## Wave 5 — Regression + delivery (Principal, serial)

**Browser regression (agent-browser, evidence `download/qa-phase2/` 00–12):**
- Manager (Sarah) login → dashboard renders, zero console errors (01).
- Settings → targets section (OWNER Nadia): month nav + « Copier » affordance gated on non-empty month (02).
- Copy dialog: source summary « 3 objectif(s) · 75M DA », destination defaults to next month, amber overwrite note (03).
- Copy executed: toast « 3 objectif(s) copié(s) » + auto-jump to destination month (04); API cross-check byte-correct (Lina 30M / Amine 25M / Yacine 20M); December restored to 0 rows after verification.
- Documents surface: PDF + image thumbnails both render (05–08; the two integration fixes above landed between 05 and 08).
- AR RTL: `dir=rtl`, Arabic document.title, dashboard renders (09).
- Dark mode (AR combination) (10).
- Mobile 390 (AR dark): `scrollWidth` EXACTLY 390 — zero overflow (11).
- Role isolation (agent Amine, AR): nav = 8 items — no Finance / Analytique / Audit / Paramètres (12).
- Console: zero errors/warnings across the whole session. dev.log: zero errors.

**Final gates:** `tsc --noEmit` 0 · `eslint .` 0.

## Failure & recovery record

- Browser tab wedged twice during the documents-tab QA (the known sandbox class — heavy SPA + browser memory). Recovery: `agent-browser close --all` + fresh session + deep-link state restore; dev server itself never down (200 throughout). No code defect — but the first wedge triggered the live discovery of the thumb sticky-fallback defect (Wave 4 fix 2), so the incident produced a real fix.
- First attempt at the copy-dialog title `fill` timed out (browser wedge #2); re-approached via curl API verification instead — same acceptance evidence.
- `bunx tsx` cannot load `bun:sqlite` (tsx runs under Node) — probe script re-run with `bun` directly. No DB was touched by the failed attempt.

## Residual risks / honest limits

1. W2.2's production paths are code-verified but not runtime-verified (a production build is disallowed in this environment — same limit as every prior round).
2. The D12 index closes the double-hold race absolutely; the sequential-twin (double-click) guard from the FINAL round remains the first line for precise error codes.
3. `migrate dev` on this DB would now flag the partial indexes as drift (not schema-expressible) — the deploy-only law was already house policy; documented in the migration header + schema comments.
4. The copy loop inside the transaction is bounded by org-user count (see Wave 4 note).
5. Vitest suites remain rejected per house law (live-protocol verification is the strategy; the golden path + this round's booking round-trip are the regression suites).

---

## Addendum — R15 (Phase 2+ continuation round, 2026-11-02)

**Entry context:** the `/goal` directive re-stated the Phase 2 mission with four success indicators (Engineering / Database / Security / UI-UX). Phase 2's five waves were verified as delivered at HEAD `0d36f3e` (clean tree, tsc 0, lint 0, dev :3000 healthy); this round executed the four-indicator verification suite plus one engineered feature + dedup wave on top.

### Indicator verification (all green)

| Indicator | Evidence |
|---|---|
| **Database** | `PRAGMA foreign_key_check` = 0 violations · `integrity_check` ok · migrations 17/17 applied · D12 partial unique indexes present in live DB · zero orphan spot-checks (lead→org, activity→lead, reservation→apartment/opportunity) · census 8/43/21/46/8/23/18/185/132/2 |
| **Security** | 13-assertion live probe matrix: unauth 401 ×3 · agent→finance/analytics/audit 403 ×3 · ghost lead/document 404 ×2 · cross-origin POST forge 403 · tampered HMAC cookie 401 · agent roster carries NO emails (G5-P3-4 minimization, live response inspected) · agent targets = own row ONLY · ghost reservation PATCH 404. Three probe-expectation mismatches investigated and classified as BY-DESIGN (users GET = team directory with email stripping; targets GET = self-row for agents; reservations/[id] has no GET handler → 405 is the routing shape). |
| **Engineering** | Verified drift-class closure: `OPP_CLOSED_STAGES` + `ACTIVE_VISIT_STATUSES` added to constants.ts (satisfies-typed); 6 files adopted (dashboard, analytics, notifications ×2 sites, opportunities, visits, leads/[id]) — the local `CLOSED_STAGES`/inline-pair re-declarations (8 sites total) are gone. journey.ts's LIVE_VISIT_STATUSES deliberately NOT merged (different semantic — documented at the constant). |
| **UI/UX** | See the R15 feature below + the browser matrix. |

### R15 feature — dashboard KPI period-over-period trends

**Gap:** trend context existed ONLY on the Analytics view (MANAGER+); the dashboard — the first screen for every role — answered "what is happening" but never "are we better than the previous N days?" (agents had no trend surface at all).

**Implementation** (D-UX-040's analytics pattern brought to the daily surface, zero new visual vocabulary):
- API (`api/dashboard/route.ts`): when range ≠ all, 4 parallel previous-window queries ([rangeStart−N, rangeStart), same leadW/oppW scope fragments — D-021 rides: an agent's trend is THEIR trend) → `trends: { newLeads, wonInRange, conversionRate }` raw `{current, previous}` pairs; null on range=all (honest absence, never fake zeros).
- UI (`dashboard/kpi-card.tsx`): TrendChip on the three windowed KPIs — counts/money → ±% with analytics' exact pctDelta semantics (prev ≤ 0 → no chip; ±999% display cap); rate → percentage-POINTS delta ("−61.7 pts" — a % of a % is meaningless); attn-3/attn-1 tiers, size-only text (D-UX-008 chip law); title + aria-label (full signed value + period context).
- Backport: analytics-kpi.tsx's chip gained the same aria-label (title alone was hover-only — screen readers had no context there).

**Live QA found and fixed one real defect:** first render clipped the primary number ("102M DA" → "10…") because `truncate` on the number + `shrink-0` on the chip let the chip win the space race. Fix: `flex-wrap` baseline row — the number is NEVER truncated (primary datum law); the chip yields and drops to its own line on narrow (8-up) cards. VLM re-review confirmed: all numbers fully visible, placement intentional, vertical rhythm coherent.

### Browser regression (evidence `download/qa-r15/`, 9 screenshots)

Manager (Sarah) 30d: 3 chips render — +800% / +983% / −61.7 pts, each EXACTLY matching the API values (UI ≡ API probe) · range=all → chips vanish; back to 30d → return · AR RTL: chips render, Arabic tooltips + aria-labels · AR + dark: chips render, html.dark verified · mobile 390 (AR dark): `scrollWidth` EXACTLY 390 — zero overflow (the flex-wrap fix is what makes this hold) · agent (Amine) own-scope: exactly 1 chip "+25.0 pts" — matches API byte-for-byte (newLeads 13-vs-0 and won 11.8M-vs-0 correctly hide: prev=0 honest absence) · analytics view (AR): 3 chips with full Arabic aria-labels · FR light final: chips + French aria-labels · console: zero errors across the whole session; dev.log: 23 dashboard GETs, all 200.

**VLM styling-detail review — claims verified against code before acting (the no-invented-work law):** hover affordance on decision/task rows = already implemented (`crm-list-row:hover` + `group` + focus-visible rings); task-list time alignment = already tabular-nums with caption-tier metadata; range-tab active state = already present. Only the aria-label gap was real (fixed, above). The translate-lift and blue/purple-tab suggestions were REJECTED as house-law violations (hover = bg/border shift only; no blue).

**Environment note:** the cron register was found EMPTY again (6th documented reap) — the 15-min webDevReview job recreated as **494790** per the current session's explicit mandate (supersedes the P14 termination note's "absent an explicit user instruction to the contrary" — this session's system instruction IS that instruction).

**Gates at close:** `tsc --noEmit` 0 · `eslint .` 0 · tree committed as `feat: R15 — …` on main.
