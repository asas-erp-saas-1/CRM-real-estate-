# ASAS CRM — Lead Management UI Forensic Audit

**Task ID:** S1-A1 · **Agent:** UI Forensic Auditor · **Scope:** Lead-management UI ecosystem only
**Project root:** `/home/z/my-project` · **Mode:** READ-ONLY source audit (no code modified)
**Method:** full source read of every in-scope file; cross-reference of `src/components/ui/*`, `src/components/crm/badges.tsx`, `src/components/crm/states.tsx`, `src/app/globals.css`, `src/lib/i18n/*`; automated key-coverage diff (336 static `t()` keys vs 1,922 dictionary keys — **zero missing keys**).

---

## 1. Component Inventory (actual files, actual line counts)

| # | File | Lines | Role |
|---|------|-------|------|
| 1 | `src/components/crm/views/leads-view.tsx` | 804 | Composition root: search, KPI strip, table/cards, pagination, dialogs |
| 2 | `src/components/crm/views/leads/table.tsx` | 168 | Desktop table, sortable headers, restore column |
| 3 | `src/components/crm/views/leads/lead-row.tsx` | 546 | `LeadRow` (table) + `LeadCard` (mobile) + `LeadsTableSkeleton` |
| 4 | `src/components/crm/views/leads/filters.tsx` | 485 | Filter popover + removable chips + sort maps |
| 5 | `src/components/crm/views/leads/kpi-strip.tsx` | 215 | 5-chip intake KPI strip |
| 6 | `src/components/crm/views/leads/quick-actions.tsx` | 179 | Row qualify/assign actions (icon + text variants) |
| 7 | `src/components/crm/views/leads/bulk-bar.tsx` | 428 | Floating bulk toolbar (desktop + mobile) |
| 8 | `src/components/crm/views/leads/use-export.ts` | 83 | CSV export hook |
| 9 | `src/components/crm/create-lead-dialog.tsx` | 765 | 2-step lead capture wizard |
| 10 | `src/components/crm/lead-detail-drawer.tsx` | 373 | Drawer orchestrator (Sheet + tabs + mobile action bar) |
| 11 | `src/components/crm/lead-drawer-header.tsx` | 386 | Identity block, status/owner edit surfaces |
| 12 | `src/components/crm/lead-drawer-info.tsx` | 669 | 2-row next-action band, info grid, tags, notes |
| 13 | `src/components/crm/lead-tab-overview.tsx` | 566 | Activity preview, composer, copilot, requirements, matches |
| 14 | `src/components/crm/lead-tab-activities.tsx` | 708 | Timeline + `Composer` + outcome chips + dialogs |
| 15 | `src/components/crm/lead-tab-tasks.tsx` | 316 | Task add form + list |
| 16 | `src/components/crm/lead-tab-visits.tsx` | 210 | Visit list + schedule CTA + fiche |
| 17 | `src/components/crm/lead-tab-opportunities.tsx` | 159 | Deal list + convert CTA |
| 18 | `src/components/crm/lead-tab-documents.tsx` | 22 | Thin wrapper over `EntityDocuments` |
| 19 | `src/components/crm/import-leads-dialog.tsx` | 302 | 4-step CSV import wizard (+ `import/step-*.tsx` 585) |
| 20 | `src/components/crm/duplicates-dialog.tsx` | 479 | Duplicate list + merge inspector |
| 21 | `src/components/crm/lead-journey-rail.tsx` | 377 | 8-step journey stepper + NBA band |
| 22 | `src/components/crm/lead-copilot-card.tsx` | 551 | LLM assessment card |
| 23 | `src/components/crm/lead-activity-preview.tsx` | 85 | 2-entry activity preview |
| — | Shared: `badges.tsx` (275), `states.tsx` (71), `shared/table-pagination.tsx` | — | Cross-referenced |

**Total in-scope surface: ~9,138 lines** across 23 lead files (+585 import steps).

---

## 2. Visual Defect Register

Severity ladder: **P0** = broken core workflow · **P1** = visible incorrectness for a primary locale/workflow · **P2** = inconsistency / usability defect · **P3** = polish / minor.

### P1

**V-01 · RTL double-flip on the duplicates "back" arrow**
- `duplicates-dialog.tsx:275` — `<ArrowLeft className="size-3.5 rtl:rotate-180" />`
- `globals.css:356–370` already applies `[dir="rtl"] svg.lucide-arrow-left { transform: scaleX(-1) }` (global RTL mirror).
- Expected: mirror once → arrow points right (RTL "back"). Actual: `rotate: 180deg` + `scaleX(-1)` compose to a **vertical flip** — the arrow points left again in Arabic. The codebase's own comment (`lead-activity-preview.tsx:44–46`) documents the global rule; 6 other files re-add `rtl:rotate-180` on globally-mirrored glyphs (kanban-card.tsx:230, visits-calendar.tsx:241/250, journey-view.tsx:411, targets-section.tsx:306/320 — out of scope, flagged for the owning agents).

**V-02 · Mobile card shows the wrong-locale name**
- `lead-row.tsx:202` (table): `arabicDisplay(lang, lead.fullName, lead.fullNameAr)`.
- `lead-row.tsx:444` (mobile card): `{lead.fullName}` — no alias switch. Tooltip `:444` also uses the Latin name.
- Expected: AR locale shows the Arabic alias everywhere. Actual: mobile cards (<md) show Latin names while the desktop table shows Arabic — same lead, two identities, split by breakpoint.

**V-03 · CSV export silently drops the `idle` / `unassigned` facets**
- `use-export.ts:32–51` builds export params **without** `idle` / `unassigned`, while the list query sends them (`leads-view.tsx:288–289`).
- Expected ("export what you see" law, the file's own header comment): filtered list → filtered CSV. Actual: a manager who isolates the intake pool or cooling relationships exports a **superset** — hundreds of rows the screen doesn't show.

**V-04 · `propertyType` renders raw enum in 3 of 4 surfaces**
- `create-lead-dialog.tsx:648–651` (`{u}`), `lead-tab-overview.tsx:389–392` (`{u}`), `lead-drawer-info.tsx:531` (`{lead.propertyType}`) — all raw.
- `lead-tab-overview.tsx:118–120` (MatchCard) translates with a guarded `t("properties.unitType.…")` fallback.
- Keys **exist in all three languages** (`properties.ts:71–78/174–181/274–281`). Expected: "Villa / Land plot / فيلا". Actual: "VILLA"/"LAND" enums in EN & AR.

### P2

**V-05 · Two competing overdue/severity color systems**
- Token system: `text-attn-1-fg` / `text-attn-2-fg` — `lead-row.tsx:42,108,119,142`, `kpi-strip.tsx:47–51`, `badges.tsx:248–255`.
- Raw palette system: `text-rose-600 dark:text-rose-400` — `lead-drawer-info.tsx:240,355,405,485,496`; `lead-tab-tasks.tsx:252,266`; `lead-tab-activities.tsx:625`; `lead-journey-rail.tsx:230–240` (rose-* block).
- Expected: one attention tier per severity. Actual: the same "overdue" fact is rose-600 in the drawer and attn-1 in the list; if the attn tokens are ever re-themed, the drawer silently diverges.

**V-06 · Four different 0–100 meter implementations for the same concept**
- `lead-row.tsx:319` — `<Progress className="h-1.5 w-10">` primary fill (score).
- `lead-drawer-info.tsx:539–548` — `<Progress>` with emerald/amber/rose tier override (score).
- `lead-copilot-card.tsx:387–396` — hand-built `div` bar + attn tiers + `role="progressbar"` (score).
- `lead-tab-opportunities.tsx:106–118` — hand-built `span` bar, `start-0` (probability).
- Plus `lead-row.tsx:163–174` budget micro-meter. Five shapes, three tone systems, two a11y strategies.

**V-07 · Sub-scale & off-scale type in the journey rail**
- `lead-journey-rail.tsx:287` — `text-[9px]` (the project's own D-UX-004 law, cited in `lead-copilot-card.tsx:361`, forbids 9px).
- `:276` `text-[10.5px]`, `:327/:337` `text-[11.5px]` — literals between the 10px (crm-micro) and 11px (crm-caption) tokens.

**V-08 · Primary CTAs below the 44px touch floor (no `crm-hit`)**
- Journey-rail Next-Best-Action buttons `h-7` (28px) — `lead-journey-rail.tsx:327,337`.
- Mobile card quick actions `h-7` — `quick-actions.tsx:109,148` (always visible on touch; qualify/assign are the row's main actions).
- KpiStrip chip buttons `h-7` — `kpi-strip.tsx:96`.
- Tag remove `size-3.5` (14px) + tag add `size-6` — `lead-drawer-info.tsx:614,641`.
- Composer submit `size-8` — `lead-tab-activities.tsx:360`.
- Drawer header owner-switch / reactivate `h-6` — `lead-drawer-header.tsx:231,300`.
- Contrast with the codebase's own standard: mobile bulk bar uses `crm-hit h-11` (`bulk-bar.tsx:308,381`), create-lead footer `h-11 sm:h-9` (`create-lead-dialog.tsx:709,724`).

**V-09 · Inconsistent hit-area treatment for same-sized row icon buttons**
- Quick-action icon triggers: `crm-hit size-7` (`quick-actions.tsx:99,138`).
- Restore button: `size-7` **without** `crm-hit` (`lead-row.tsx:358`).
- Visits fiche printer: `crm-hit size-7` (`lead-tab-visits.tsx:157`); visits/tasks delete: `size-7` without `crm-hit` (`lead-tab-visits.tsx:170`, `lead-tab-tasks.tsx:279`).

**V-10 · Dialog sizing/scroll strategies disagree across the lead modal family**
- `create-lead-dialog.tsx:292–296` — width **changes mid-flight**: step 1 `sm:max-w-lg` → step 2 `sm:max-w-2xl` (visible resize jump).
- `import-leads-dialog.tsx:107` — `max-h-[92vh]` + inner body `max-h-[58vh]` (`:152`).
- `duplicates-dialog.tsx:217` — `max-h-[85vh]`, whole-content scroll.
- `lead-detail-drawer.tsx:68` — sheet `sm:max-w-2xl` (default sheet is `sm:max-w-sm`, `sheet.tsx:105`).
- Expected: one modal-size/scroll token set for the lead ecosystem. Actual: three different max-height caps and a resizing wizard.

**V-11 · Destructive confirm actions re-implemented with raw rose classes ×5**
- `lead-tab-activities.tsx:665`, `lead-tab-tasks.tsx:301`, `lead-tab-visits.tsx:192`, `import-leads-dialog.tsx:283`, `duplicates-dialog.tsx:443` — all `bg-rose-600 hover:bg-rose-700` on `AlertDialogAction`; meanwhile `create-lead-dialog.tsx:754` uses the `bg-destructive` token. One concept, two implementations.

**V-12 · Wizard step indicators: two visual languages for the same concept**
- Create-lead: quiet rounded pill chips + `·` separator (`create-lead-dialog.tsx:92–97, 316–333`).
- Import: numbered circles + connecting progress lines (`import-leads-dialog.tsx:119–149`).
- Same app, same "multi-step dialog" pattern, zero shared code.

**V-13 · Misleading accessible names on next-action cells**
- `lead-drawer-info.tsx:357` — the nearest-TASK button's `aria-label` is `t("leads.detail.tasks")` (the tab name); `:407` nearest-VISIT button labeled `t("leads.detail.visits")`; `:437` deal button `t("leads.detail.opportunities")`.
- Screen-reader users hear "Tâches" three times instead of the actual task/visit/deal content. `aria-label` should compose with `title={nextTask.title}` (which is already present but shadowed).

**V-14 · Hardcoded French floor convention `R+{n}`**
- `lead-tab-overview.tsx:144` — `` `R+${apt.floorNumber}` `` (also `properties/unit-table.tsx:139`, `apartment-detail-dialog.tsx:265`, `apartment-card.tsx:82` outside scope). `properties.floor.ground` is translated; the `R+` prefix is not — Arabic/English users see a French label.

**V-15 · Hardcoded FR placeholders bypassing i18n**
- `create-lead-dialog.tsx:413` — `placeholder="0555 12 34 56"`; `:491` — `placeholder="contact@exemple.dz"`. The i18n header (`i18n/index.ts:2`) says "NEVER hardcode user-facing strings".

**V-16 · Raw amber/emerald/teal palette chips vs the attn-tier tokens**
- `lead-copilot-card.tsx:62–99` (TEMP_META/WHEN_TONE), `duplicates-dialog.tsx:206–209` (ruleChip `border-amber-300`), `lead-journey-rail.tsx:366` (blocker chip), `create-lead-dialog.tsx:431–440` (dup pre-check note), `bulk-bar.tsx:205,214` (copilot trigger/cap badge), `lead-tab-overview.tsx:186` (presented badge).
- The attn-1/2/3 tokens exist and are used in `kpi-strip.tsx` / `badges.tsx`. Documented "P6-3 color-coupled exception" covers *size*, not the raw hue drift across ~10 distinct chip styles.

### P3

**V-17 · Desktop-shaped skeleton on mobile** — `LeadsTableSkeleton` (`lead-row.tsx:527–546`, mounted at `leads-view.tsx:696`) renders table rows; below md the real layout is cards (`leads-view.tsx:740`). Mobile loading state misrepresents the layout.

**V-18 · Mobile card omits priority, budget, score, email** — `LeadCard` (`lead-row.tsx:371–525`) shows status/source/owner/rot/next-action only, while the table shows all columns. Field-team (thumb-first) users lose the commercial scan signals.

**V-19 · Toolbar controls at `h-9` (36px) on mobile** — `leads-view.tsx:449–474` (search, archive toggle, create). The primary "Create" button is 36px tall on touch — under the codebase's own 44px floor (`create-lead-dialog.tsx:703` documents it).

**V-20 · Crowded drawer prelude** — Above the first tab content a user passes: header (identity + 3 chips + 2 actions) → journey rail (8-step stepper + NBA + evidence chips, `lead-journey-rail.tsx:214–375`) → info band row 1 → info band row 2 → info grid (`lead-drawer-info.tsx:229–510`) — five stacked sections before the tabs bar. The file's own comment (`lead-drawer-info.tsx:216–221`) removed one lifecycle strip for exactly this reason; the journey rail re-introduced a third lifecycle vocabulary (8 journey stages vs 6 lead statuses vs 4-chip band).

**V-21 · Reservation fact rendered three ways in one drawer** — rail BOOKING stage + evidence chip (`lead-journey-rail.tsx:253,351–357`), band-2 reservation cell (`lead-drawer-info.tsx:474–509`), opportunities tab rows (`lead-tab-opportunities.tsx:85–130`). Also `wonWeight` (`lead-drawer-info.tsx:566–590`) duplicates the sum the opportunities tab lists.

**V-22 · `bg-primary hover:bg-[var(--primary-hover)]` inline override ×4** — `leads-view.tsx:570`, `lead-tab-visits.tsx:102`, `import-leads-dialog.tsx:241,257`. A Button-variant escape hatch repeated instead of fixed once in `ui/button.tsx`.

**V-23 · `users` query without a loading branch in the drawer** — `lead-detail-drawer.tsx:56–62`; the header's owner-switch menu renders empty until the roster resolves (no skeleton, no disabled state).

**V-24 · Table min-width 1060–1120px** — `table.tsx:106`. At md (768px) the table mounts with `overflow-auto` — guaranteed horizontal pan on small laptops/tablets; acceptable for density but the mobile/tablet threshold leaves a 768–1024px dead zone of constant scrolling.

**V-25 · Duplicated WhatsApp affordance on mobile drawer** — header `WhatsAppPopoverButton` (`lead-drawer-header.tsx:318`) **and** mobile action bar (`lead-detail-drawer.tsx:343`) are simultaneously visible <md.

---

## 3. Duplication Findings

**DUP-01 · The 200-char "next-action cell" button class block — 9 verbatim copies in one file**
`lead-drawer-info.tsx:237, 354, 377, 404, 421, 436, 457, 466, 480` — the same `"-mx-1.5 -my-0.5 inline-flex max-w-full items-center gap-1.5 rounded-md px-1.5 py-0.5 … focus-visible:ring-2"` string. One `NextActionCell` extraction (the file already has `NextActionCell` in `lead-row.tsx` as precedent) removes ~150 lines and guarantees tone consistency.

**DUP-02 · Lost-reason dialog implemented twice**
`bulk-bar.tsx:391–416` vs `lead-drawer-header.tsx:333–362` — identical Dialog/Textarea/disabled-confirm flow (the comment admits "mirrors the single-lead drawer"). A `LostReasonDialog` primitive is the obvious share.

**DUP-03 · Roster dropdown item (initials avatar + name) ×3**
`quick-actions.tsx:162–173`, `bulk-bar.tsx:181–192` (desktop), `bulk-bar.tsx:319–330` (mobile). Also `lead-drawer-header.tsx:252–263` renders the same roster without avatars — 4 renderings of one list.

**DUP-04 · tel: / mailto identity anchor blocks ×3**
`lead-row.tsx:269–277` (table), `lead-row.tsx:450–458` (card), `lead-drawer-header.tsx:129–136` (drawer) — same classes, same stopPropagation law, copied three times.

**DUP-05 · Five meter/bar micro-implementations** (see V-06) — score, probability, budget, copilot score, match fit — no shared `<Meter>` primitive despite `Progress` existing in `ui/`.

**DUP-06 · Two wizard steppers** (see V-12).

**DUP-07 · Destructive AlertDialogAction styling ×5 + 1 token version** (see V-11).

**DUP-08 · Composer mounted in two tabs** — `lead-tab-overview.tsx:357` and `lead-tab-activities.tsx:498` (documented as safe because Radix unmounts inactive tabs; still two code references, and the overview's copy is *above* the activity preview that duplicates the timeline's first 2 rows — `lead-activity-preview.tsx` vs `lead-tab-activities.tsx`).

**DUP-09 · `t(key) !== key` guarded-translation hack ×2** — `lead-tab-overview.tsx:118,217`, `lead-journey-rail.tsx:368` — a runtime fallback idiom that exists only because some dynamic keys were once missing; keys now all exist (verified) — dead defensive code that hides real gaps if they regress.

---

## 4. i18n Gap Analysis

**Coverage: excellent.** All 336 static keys used across the 23 audited files exist in the dictionaries; all dynamic enum key families (`lead.status.*`, `outcome.*`, `journey.*`, `visit.status.*`, `task.type.*`, `stage.*`, `req.*`, `leads.dup.rule.*`, `match.reason.*`, `copilot.temp/when.*`) are present in fr/en/ar; module-load parity guard at `i18n/index.ts:74–102` enforces 3-language parity at build time.

**Gaps (bypasses, not missing keys):**

| ID | Location | Issue |
|----|----------|-------|
| I-01 | `create-lead-dialog.tsx:648–651`, `lead-tab-overview.tsx:389–392`, `lead-drawer-info.tsx:531` | `propertyType` raw enum despite existing `properties.unitType.*` keys (all 3 langs) — see V-04 |
| I-02 | `lead-tab-overview.tsx:144` (+3 property-side files) | `R+{n}` hardcoded French floor prefix — no key exists; needs `properties.floor.upper` |
| I-03 | `create-lead-dialog.tsx:413,491` | Hardcoded FR placeholders (`0555 12 34 56`, `contact@exemple.dz`) |
| I-04 | `lead-journey-rail.tsx:276,287,327,337` + ~24 `text-[10px]` literals | Off-scale font literals instead of `text-crm-micro`/`text-crm-caption` (partially justified by the documented P6-3 color-coupling exception, but 9px/10.5px/11.5px have no justification) |
| I-05 | `lead-tab-visits.tsx:131`, `lead-drawer-info.tsx:318,363,412,444,499` | Date/status `·` separators joined with literal `" · "` inside JSX — fine in LTR/RTL (neutral punctuation), listed for completeness only |

---

## 5. State Coverage Assessment (loading / empty / error / disabled)

Generally **strong** — a differentiator of this codebase:
- List: skeleton (`leads-view.tsx:696`), 3 distinct empty states (`:698–722`), `ErrorState` + retry (`:694`), `aria-busy` (`:441`).
- Drawer: skeleton (`lead-detail-drawer.tsx:85–100`), error + close (`:77–83`), sr-only title in every branch (`:73–76`).
- KPI strip: skeleton pills, never a fake 0 (`kpi-strip.tsx:66–68`).
- Tabs: `EmptyState` in activities/tasks/visits/opportunities/matches; "empty ≠ dead end" CTAs (`lead-drawer-info.tsx:374–382, 418–427`).
- Pending states: every mutation button carries `Loader2` + `disabled` (verified across all files; no "disabled-but-not-really" found; no dead buttons found — `W4.3` comment even documents fixing the match button's dead feel).

Exceptions: V-17 (mobile skeleton shape), V-23 (drawer users query), and the duplicates dialog loading is a bare spinner line (`duplicates-dialog.tsx:229–233`) rather than the house skeleton idiom.

---

## 6. Consistency Scorecard

| Dimension | Score | Notes |
|-----------|-------|-------|
| Spacing / layout | 82 | Consistent `space-y-*`+`p-3/p-4` rhythm; band `py-2.5` vs grid `p-4` slight drift |
| Typography | 70 | Token system solid; 9px/10.5px/11.5px + 24 raw 10px literals |
| Color tokens | 62 | attn-tokens vs raw rose/amber/emerald split across severity surfaces |
| Border radius / shadow | 88 | `rounded-lg/md`, `shadow-card` used uniformly |
| Iconography | 85 | One icon vocabulary (`TYPE_ICON`, `SOURCE_ICON`); RTL mirror mostly global |
| RTL/LTR logical props | 84 | `ms/me/ps/pe/start/end` used consistently; V-01 double-flip + V-02 are the lapses |
| Component reuse | 65 | Badges/states/pagination shared; meters, steppers, dialogs duplicated |
| States (load/empty/error) | 90 | Near-complete |
| Touch targets | 55 | Mobile CTAs at 24–32px throughout the drawer |
| i18n | 88 | Zero missing keys; 4 bypass clusters |

**Overall visual consistency: 74 / 100.** The lead ecosystem is engineered with unusual discipline (documented design laws, honest states, a11y care), but it has accumulated three parallel low-level systems (color tones, meters, steppers) and a touch-target regression concentrated in the drawer — the highest-value surface.

---

## 7. Recommended Next Actions (for the remediation agent — priority order)

1. **V-03** add `idle`/`unassigned` to `use-export.ts` params (data-correctness, 2 lines).
2. **V-01** remove `rtl:rotate-180` from `duplicates-dialog.tsx:275` (and queue the 6 sibling files to their owners).
3. **V-02** use `arabicDisplay` + `displayName` in `LeadCard` (`lead-row.tsx:444`).
4. **V-04/I-01** single `unitTypeLabel(u)` helper with the guarded `t()`; adopt in all 4 surfaces.
5. **V-05/V-06** extract `<Meter>` and standardize on attn-tier tokens; retire raw rose/amber in overdue contexts.
6. **V-08/V-09** touch-floor sweep: `crm-hit` + `h-11 sm:h-9` (or ≥40px) for journey NBA, card quick actions, KPI chips, tag controls, composer submit.
7. **DUP-01/02/03** extract `NextActionCell`, `LostReasonDialog`, `RosterMenu`.
8. **V-10** one modal sizing convention (`sm:max-w-lg` forms / `sm:max-w-2xl` inspectors, single `max-h-[92vh]` + inner scroll) — and stop the create-lead width jump (keep `sm:max-w-2xl` both steps).
9. **V-13** compose aria-labels from content (``${t("lead.detail.nextTask")}: ${nextTask.title}``).
10. **I-02** add `properties.floor.upper` key; replace `R+${n}` in 4 files.

*Audit complete — no code was modified.*
