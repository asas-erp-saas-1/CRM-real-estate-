# ASAS CRM — Lead Domain, Database, API & Business Logic Audit

**Task ID:** S1-A5 · **Agent:** 5 (Lead/Domain/DB/API) · **Mode:** READ-ONLY (no code modified)
**Date:** 2026-02-27 · **Project root:** `/home/z/my-project`
**Scope:** `prisma/schema.prisma` (Lead + related), `src/app/api/leads/**`, `src/app/api/{activities,tasks,visits,opportunities}`, `src/lib/phone.ts`, `src/lib/server/{session,auth,validation,visibility,leads,duplicates,audit}.ts`, frontend callers (`create-lead-dialog.tsx`, `views/leads/*`, `lead-detail-drawer` family).

---

## 1. Schema Verdict

The Lead domain is **mature, well-indexed and multi-tenant-ready**, with genuine engineering discipline (state-machine matrices, transactional audit trails, scope-based visibility, duplicate-pair machinery). The core funnel (NEW → CONTACTED → QUALIFIED → CONVERTED / CLOSED_LOST → REACTIVATED) is fully supported with timestamps (`convertedAt`, `lostAt`, `reactivatedAt`), reason-gating (`lostReason`), and a dedicated conversion flow. **Main structural weaknesses:** a duplicated requirement snapshot (Lead vs Requirement 1:1) with no sync, dead attribution columns (UTM/referrer) and dead Arabic alias (`fullNameAr`) with no API write path, money as `Float`, and a hard `(orgId, phone)` unique that encodes "phone = one person" with no escape hatch for shared family numbers.

### 1.1 Field map — `model Lead` (schema.prisma:150–225)

| Group | Fields | Assessment |
|---|---|---|
| Identity | `fullName`, `fullNameAr?`, `phone` (E.164, dup key), `phoneRaw?`, `secondaryPhone?`, `whatsapp?`, `email?` | ✅ strong; ⚠️ `fullNameAr` never writable via API (seed-only) |
| Attribution | `source`, `campaign?`, `utmSource?`, `utmMedium?`, `utmCampaign?`, `referrerName?` | ✅ modeled; ❌ UTM/referrer **not exposed** in create/patch schemas (seed-only) |
| Ownership & lifecycle | `ownerId?`→User, `status` (NEW/CONTACTED/QUALIFIED/CONVERTED/CLOSED_LOST/REACTIVATED), `priority`, `score` 0–100 | ✅ `convertedAt` is a first-class column (W2-10); assignment history only via Activity/AuditLog meta — no history table |
| Requirement snapshot | `budgetMin?`, `budgetMax?`, `propertyType?`, `desiredLocation?` (DZD, Float) | ⚠️ duplicates the structured `Requirement` model → drift risk (D-LD-07); negative values accepted (D-LD-04) |
| Commercial discipline | `lastContactAt?`, `nextFollowUpAt?`, `convertedContactId?` (@unique), `convertedAt?`, `lostReason?`, `lostAt?`, `reactivatedAt?`, `notes?`, `archived` | ✅ next follow-up supported; follow-up overdue auto-clear on contact (activities route) |
| Relations | `tags` (LeadTag), `activities`, `tasks`, `visits`, `opportunities`, `contact` (1:1), `requirements`, `duplicateDismissalsA/B`, `savCases` | ✅ complete |

**Indexes/uniques:** `@@unique([orgId, phone])` (hard identity), `@@index` on `[orgId,status]`, `[orgId,source]`, `[orgId,ownerId]`, `[orgId,createdAt]`, `[orgId,nextFollowUpAt]`, `[orgId,archived]`, `[email]`. All list facets (`status`, `source`, `ownerId`, `archived`, follow-up) are index-backed. ✅

**Competing status fields?** No stored `temperature` and no separate qualification flag — good. The lead carries `status` + `priority` + `score`; the funnel stage shown in the journey rail is **derived** (`src/lib/journey.ts` — never asserted), and the copilot's HOT/WARM/COLD **temperature is ephemeral** (only in the latest COPILOT Activity meta, not a Lead column). The one real duplication is Lead-snapshot vs `Requirement` (§ D-LD-07); `QUALIFIED` status vs journey-QUALIFIED was reconciled by auto-advance on requirement completion (E2E-FINAL D11).

### 1.2 ERD (lead domain)

```mermaid
erDiagram
    Organization ||--o{ Lead : owns
    Organization ||--o{ User : has
    Organization ||--o{ Tag : has
    User ||--o{ Lead : "owner (LeadOwner)"
    Lead ||--o{ LeadTag : ""
    Tag ||--o{ LeadTag : ""
    Lead ||--o{ Activity : timeline
    Lead ||--o{ Task : ""
    Lead ||--o{ Visit : ""
    Lead ||--o{ Opportunity : ""
    Lead ||--o| Contact : "convertedContactId (leadId unique)"
    Lead ||--o| Requirement : "leadId unique"
    Lead ||--o{ LeadDuplicateDismissal : "pair A / pair B"
    Lead ||--o{ SavCase : ""
    Requirement ||--o{ PropertyMatch : ""
    Opportunity ||--o{ Visit : ""
    Opportunity ||--o{ Reservation : ""
    Opportunity ||--o{ Task : ""
    Contact ||--o{ Opportunity : ""
    Activity }o--|| User : actor
    Activity }o--o| Task : ""
    Activity }o--o| Visit : ""
    Activity }o--o| Reservation : ""

    Lead {
        string id PK
        string orgId FK
        string fullName
        string fullNameAr "nullable, seed-only today"
        string phone "E.164 unique per org"
        string phoneRaw
        string secondaryPhone
        string whatsapp
        string email
        string source
        string campaign
        string utmSource "seed-only today"
        string utmMedium "seed-only today"
        string utmCampaign "seed-only today"
        string referrerName "seed-only today"
        string ownerId FK
        string status "NEW|CONTACTED|QUALIFIED|CONVERTED|CLOSED_LOST|REACTIVATED"
        string priority
        int score
        float budgetMin
        float budgetMax
        string propertyType
        string desiredLocation
        datetime lastContactAt
        datetime nextFollowUpAt
        string convertedContactId FK
        datetime convertedAt
        string lostReason
        datetime lostAt
        datetime reactivatedAt
        boolean archived
    }
    LeadDuplicateDismissal {
        string id PK
        string orgId FK
        string leadAId FK "normalized a<b"
        string leadBId FK
        string dismissedById FK
        string note
    }
    Requirement {
        string id PK
        string leadId FK "unique"
        float budgetMin
        float budgetMax
        string propertyType
        float surfaceMin
        float surfaceMax
        string district
        int floorMin
        int floorMax
        boolean parking
        int bedroomsMin
        string payment
        string purpose
        string timeframe
    }
```

---

## 2. Phone Handling (src/lib/phone.ts)

- **Canonical form:** E.164, `+213XXXXXXXXX` for DZ. Handled inputs: `0555123456` / spaced/dashed/dotted, `+213…`, `00213…`, landline `021xxxxxxx`, bare `213…` (country-coded, W5-bugfix), bare ≥8-digit national, other international `+CC…` preserved. 17 unit tests pass (`tests/unit/phone.test.ts`).
- **Server enforcement:** POST `/api/leads` normalizes before insert (`INVALID_PHONE` 422 on failure); import normalizes per row; `phoneRaw` preserves the user's entry for search.
- **Duplicate detection:** DB unique `(orgId, phone)` — the hard backstop (P2002 → shaped 409, never forceable). Pre-insert check also probes email (see D-LD-03). PHONE_CROSS (primary↔secondary) is only detected by the manager duplicates scan, not at create time.
- **False-positive risks:**
  - **Family/shared numbers:** the unique constraint *blocks* a second person with the same primary phone outright (`force` cannot bypass P2002 — by design, "phone = one person"). No supported path for "same household, second lead" except inventing a different primary number. Documented limitation (D-LD-16).
  - **Loose validity** (D-LD-06): any ≥8-digit bare string is accepted as DZ (`"12345678"` → `+21312345678`); no 05/06/07 mobile or 02x landline prefix check → garbage numbers enter the identity key.
- **PATCH hole** (D-LD-05): `secondaryPhone`/`whatsapp` updates are stored **raw** (no normalization) → breaks PHONE_CROSS matching and `wa.me` links.

---

## 3. API Inventory — Lead Domain

All routes: JSON envelope `{ error, code, details? }`, session via HMAC cookie (`asas_user`), `requireUser()` = auth + same-origin CSRF check; scope via `leadScope()` (MANAGER+ org-wide; SALES_AGENT own+pool; FIELD_REP project-derived). 404 for out-of-scope ids (no existence leak).

| Route | Method | Auth/Role | Validation (zod) | Returns / Notes |
|---|---|---|---|---|
| `/api/leads` | GET | any session | query params, multi-status CSV, 422 on garbage | `{data,total,page,pageSize}` — **true server-side pagination** (skip/take ≤100/page, count) + server-side filters: query (name/phone/phoneRaw/email/fullNameAr+Arabic fold), status[], source, ownerId, priority, tagId, min/maxBudget (range-intersect), location (snapshot ∪ requirement.district), uncontacted, unassigned (MANAGER+ only, 403 below), idle (14d), createdAfter, propertyType, archived; sort allowlist; `withStats=1` adds batched per-row opp/visit stats (2 queries, no N+1) |
| `/api/leads` | POST | any session; ownerId requires MANAGER+ | createSchema; phone normalized; budget range; owner in-org | 201 `{lead}`; 409 DUPLICATE (+duplicates list, scope-filtered; foreign dup → generic empty list); P2002 backstop → 409. `force:true` bypasses email dup only. LEAD_CREATED Activity + AuditLog (outside tx — D-LD-13) |
| `/api/leads/[id]` | GET | any session (scoped) | — | Full aggregate: lead + owner + tags + activities (**take 100**, D-LD-10) + tasks + visits (with apartments) + opportunities + requirement + contact + reservations (batched second query). **One query + 1 — no N+1** |
| `/api/leads/[id]` | PATCH | any session (scoped); owner change & illegal transitions MANAGER+; archive owner-or-MANAGER | patchSchema; CONVERTED entry refused; CONVERTED locked; CLOSED_LOST requires lostReason; LEAD_TRANSITIONS matrix (illegal → MANAGER+ + correctionReason); budget coherence | 200 `{lead}`; mutation + Activity + AuditLog in **one $transaction** (F-06, fault-injectable); reassignment cascades open opps/tasks/future visits (`reassignLeadCascade`) |
| `/api/leads/[id]/convert` | POST | any session (scoped) — **SALES_AGENT can convert** | — (409 ALREADY_CONVERTED) | Contact + Opportunity (stage QUALIFIED, value=budgetMax, probability 20) + lead flip (status/convertedContactId/convertedAt) + CONVERSION Activity + audit — all in one tx |
| `/api/leads/[id]/reactivate` | POST | any session (scoped) | 409 unless CLOSED_LOST | CLOSED_LOST → CONTACTED, clears lost fields, stamps reactivatedAt; tx'd trail |
| `/api/leads/[id]/activities` | POST | any session (scoped) | type/title/body/outcome; OUTCOME_TYPE_MISMATCH guard | Contact types refresh `lastContactAt`, auto-advance NEW→CONTACTED, clear overdue `nextFollowUpAt`; **5s twin-dedup idempotency** (double-click safe); tx'd. **No GET** (timeline rides the aggregate) |
| `/api/leads/[id]/tasks` | POST | any session (scoped) | title/type/dueAt/priority/notes | Task created (owner = lead owner ∪ caller), TASK Activity + audit (not tx'd — D-LD-13) |
| `/api/leads/[id]/tags` | POST | any session (scoped) | name | find-or-create tag, idempotent attach (P2002 → 200), trail |
| `/api/leads/[id]/tags/[tagId]` | DELETE | any session (scoped) | — | detach + trail |
| `/api/leads/[id]/requirements` | POST | any session (scoped) | full requirement schema, budget range | upsert (undefined=keep/null=clear); auto-advance NEW/CONTACTED→QUALIFIED; tx'd |
| `/api/leads/[id]/whatsapp` | POST | any session (scoped) | template/message/lang | WHATSAPP Activity + lastContactAt + audit in one tx |
| `/api/leads/[id]/copilot` | POST | any session (scoped) | lang | LLM assessment persisted as COPILOT Activity (meta), 20s/lead rate limit, 60s timeout. Temperature is **ephemeral meta** — no Lead column |
| `/api/leads/bulk` | POST | assign → MANAGER+; status/addTag/archive → any (scoped) | ids ≤200, action enum; CLOSED_LOST needs reason; CONVERTED refused | updateMany in-scope only; transition-matrix eligibility filter; **one $transaction** (15s) for writes + per-lead Activities + summary audit |
| `/api/leads/duplicates` | GET | **MANAGER+** | — | §12.2 shared predicate (EMAIL / PHONE_CROSS / NAME-weak), dismissed + both-archived excluded, strong-first; ≤5000 scan basis; per-lead relation stats. Pure read (no trail) |
| `/api/leads/duplicates/merge` | POST | **MANAGER+** | survivor/merged ids + expectedUpdatedAt stale guards + note | One 30s tx: re-points activities/tasks/visits/opps/documents/SAV cases, tag union, contact/requirement re-point or preserve-then-delete, fill-if-empty survivor fields, phone→secondary law, MERGE Activity with full snapshot meta; post-commit LEAD_MERGED audit; cache bust |
| `/api/leads/duplicates/dismiss` | POST | **MANAGER+** | pair ids + note | Idempotent unordered-pair dismissal row + audit |
| `/api/leads/export` | GET | **MANAGER+** | same filter surface *minus* multi-status (D-LD-01), tagId, idle, unassigned | CSV (semicolon, BOM, CRLF, formula-injection defang), ≤5000, LEADS_EXPORTED audit |
| `/api/leads/import` | POST | **MANAGER+** | preview/commit; ≤2000 rows, ≤600KB | preview: per-row validation + in-file + DB dup detection; commit: valid rows in one tx, dupes always skipped; LEADS_IMPORTED audit with `leadIds` (undo source) |
| `/api/leads/import/undo` | POST | **MANAGER+** | auditId | soft-archive of un-progressed leads; idempotence via LEADS_IMPORT_UNDONE scan |
| `/api/tasks` `[id]` | GET/POST/PATCH/DELETE | scoped (taskScope); reopen/delete owner-or-MANAGER | task schema, TASK_TRANSITIONS matrix | DONE emits Activity + audit |
| `/api/activities` `[id]` | GET / DELETE | scoped (activityScope) | type filter | paginated timeline feed; DELETE owner-or-MANAGER |
| `/api/visits` `[id]` | GET/POST/PATCH | scoped (visitScope); confirm/reject = assigned FIELD_REP or MANAGER+ | visit schema, VISIT_TRANSITIONS, report contract gate | POST writes VISIT Activity + audit in tx |
| `/api/opportunities` `[id]` | GET/POST/PATCH | scoped (oppScope) | stage matrix, terminal discipline | kanban aging `stageChangedAt` |

**Unused endpoint capability:** `tagId` list filter + `archived=all` + `sort=lastContactAt/convertedAt` have no UI caller today. **No endpoint is dead code.**

---

## 4. Duplicate Protection Assessment

- **Create-time:** phone (exact, DB-enforced) + email (substring — D-LD-03). Scope-aware: an agent sees only in-scope duplicates; foreign twins yield an anonymous 409. `force:true` overrides email dupes only; phone never.
- **Scan-time (manager):** shared single-writer predicate in `src/lib/server/duplicates.ts` (scan + KPI + bell all delegate); 60s TTL cache for high-frequency aggregates, busted on merge/dismiss. NAME rule is exact-normalized (weak, suggestion-only).
- **Merge:** reference-preserving, direction-explicit, stale-guarded, transactional, fully snapshotted into Activity meta + audit. **Idempotency:** dismiss is idempotent; merge double-submit → second call 404s (merged side deleted) — acceptable. Create has **no idempotency key** (D-LD-12).
- **Latent integrity bug** D-LD-02: converting a survivor that absorbed a converted lead's Contact → unhandled P2002 → 500.

## 5. Status Transitions

`LEAD_TRANSITIONS` (constants.ts:127–134) enforced server-side on PATCH ([id]/route.ts:185) and bulk (bulk/route.ts:127). Forward edges ungated; backward/sideways = MANAGER+ + mandatory `correctionReason` (audited as LEAD_STATUS_CORRECTED). CONVERTED terminal (no PATCH entry — dedicated /convert; no exit). CLOSED_LOST requires lostReason (single + bulk); leaving CLOSED_LOST clears lost fields. Reactivate is a dedicated CLOSED_LOST→CONTACTED flow (documented matrix bypass). **History is persisted**: STATUS_CHANGE Activity (before/after meta) + LEAD_STATUS_CHANGED AuditLog per transition, transactionally with the mutation. `convertedAt` set only in /convert; never cleared; merge does not transfer it (absorbed lead's conversion facts survive only in the merge snapshot).

## 6. Drawer Tab Linkage (N+1 check)

`GET /api/leads/[id]` is the **single source**: one scoped `findFirst` with nested includes (activities ≤100 desc, tasks asc, visits desc + apartments, opportunities desc, requirement, contact, owner, tags) + one batched reservations query. Tabs (`lead-tab-*`) receive slices as props — **no N+1**. Task completion/delete and activity delete call their own `/api/tasks/[id]`, `/api/activities/[id]` endpoints, which write Activity + AuditLog. Visit/task/contact creates all write timeline rows (visits/whatsapp/requirements tx'd; plain task & lead create trails are not — D-LD-13).

## 7. Permissions Summary (server-enforced)

| Action | OWNER/ADMIN/MANAGER | SALES_AGENT | FIELD_REP |
|---|---|---|---|
| List/create lead | ✅ org-wide | ✅ own+pool | ✅ project-derived |
| Assign / reassign / bulk-assign | ✅ | ❌ 403 | ❌ 403 |
| Qualify (status forward) | ✅ | ✅ (in-scope) | ✅ (in-scope) |
| Convert | ✅ | ✅ (in-scope) — note: not manager-gated | ✅ (in-scope) |
| Correct illegal transition | ✅ + reason | ❌ 422 | ❌ 422 |
| Archive/unarchive | ✅ | owner-of-record only | owner-of-record only |
| Duplicates scan/merge/dismiss, import, export, undo | ✅ | ❌ 403 | ❌ 403 |

Enforcement is genuinely server-side (`requireUser(role)`, scoped `findFirst`, matrix guards); UI hiding is never the gate. No RLS (SQLite; documented as PostgreSQL-port work).

---

## 8. Defect Register

| ID | Severity | Location (file:line) | Description |
|---|---|---|---|
| D-LD-01 | **HIGH** | `src/app/api/leads/export/route.ts:76` vs `views/leads/use-export.ts:34-39` | Export uses single-value `qpEnum(status)`; the UI sends comma-joined multi-status (`status=NEW,CONTACTED`) → **422 INVALID_FILTER whenever ≥2 status chips are armed**. The list route got the multi-status fix (leads/route.ts:66-75) but export never did. |
| D-LD-02 | **HIGH** | `duplicates/merge/route.ts:154-159` + `[id]/convert/route.ts:28-37` | Merge re-points the merged (converted) lead's Contact onto a non-converted survivor without setting `survivor.convertedContactId`/status. A later `/convert` on that survivor hits `Contact.leadId @unique` → unhandled P2002 → **500 INTERNAL** (no isPrismaKnownError handling in convert). |
| D-LD-03 | **HIGH** | `src/app/api/leads/route.ts:349` | Create-time email duplicate check uses `contains` (substring): creating `ali@gmail.com` flags existing `mali@gmail.com` as a duplicate — **false-positive 409s** with a wrong duplicate list. Should be exact (case-insensitive) equality. |
| D-LD-04 | MEDIUM | `leads/route.ts:295-296`, `[id]/route.ts:141-142` | Lead `budgetMin/budgetMax` use `optionalNumber` — **negative budgets accepted**, inconsistent with the W1-2 non-negative money law applied to opportunities/reservations (`optionalMoney`). |
| D-LD-05 | MEDIUM | `[id]/route.ts:127-129` | PATCH `email` has **no format validation** (create uses `optionalEmail`); `secondaryPhone`/`whatsapp` are stored **un-normalized** → breaks PHONE_CROSS duplicate rule and wa.me link generation. |
| D-LD-06 | MEDIUM | `src/lib/phone.ts:40-53` | `normalizePhone` accepts any ≥8-digit bare string as DZ (`"12345678"` → `+21312345678`); no 05/06/07 or 02x prefix validation → invalid numbers become identity keys. |
| D-LD-07 | MEDIUM | `schema.prisma:183-186` vs `Requirement` (414-438); `[id]/route.ts` PATCH vs `[id]/requirements/route.ts` | Lead snapshot (budget/propertyType/desiredLocation) and the 1:1 `Requirement` are **two unsynchronized truths**: PATCH updates the snapshot only; requirements POST updates the requirement only. Matching reads Requirement; list filters/export read the snapshot. |
| D-LD-08 | MEDIUM | `leads/route.ts:287-303`, `[id]/route.ts:125-146` | `utmSource/utmMedium/utmCampaign/referrerName` have **no API write path** (createSchema/patchSchema omit them) — attribution columns are seed-only dead weight; the "never lost through the funnel" promise is unreachable from the product. |
| D-LD-09 | MEDIUM | `leads/route.ts:52`, `search/route.ts:91` | `fullNameAr` is searched by list/global-search but **never writable via API** (seed-only) — Arabic-alias search works only for seeded rows. |
| D-LD-10 | MEDIUM | `[id]/route.ts:36-38` | Drawer timeline is `take: 100` activities with **no pagination route** (`[id]/activities` is POST-only) — older history silently disappears for high-touch leads. |
| D-LD-11 | MEDIUM | `views/leads/use-export.ts:32-51` vs `filters.tsx:43-47` | "Export what you see" violated for `idle` and `unassigned` facets: armed in the UI but **not forwarded** to the export URL → CSV is a superset of the filtered view. |
| D-LD-12 | LOW | `leads/route.ts:347-383` | Duplicate pre-check and insert are not in one transaction and there is **no idempotency key** — concurrent double-submits can double-create (email-dup pairs and `force:true`; phone is backstopped by the unique index). |
| D-LD-13 | LOW | `leads/route.ts:385-451`, `[id]/tasks/route.ts:33-64` | POST /api/leads and POST /api/leads/:id/tasks write their Activity/AuditLog **outside** the mutation transaction — violates the F-06 house law enforced on PATCH/bulk/convert/reactivate/whatsapp (crash between → untrailed mutation). |
| D-LD-14 | LOW | `leads/route.ts:348-349` | Create-time dedup ignores `secondaryPhone` cross-matches (PHONE_CROSS) — such duplicates surface only later in the manager scan. |
| D-LD-15 | LOW | `leads/route.ts:30,127` | `requireUser()` resolved twice for the `unassigned` facet (second auth+CSRF pass per request). |
| D-LD-16 | LOW (design) | `schema.prisma:217` | Hard `(orgId, phone)` unique with no escape hatch for **shared family numbers** — the second household member cannot be created without a different primary number (force cannot bypass P2002). Known business trade-off; should be product-documented. |
| D-LD-17 | LOW (DB-wide) | `schema.prisma:183-184`, `Opportunity.value` | DZD money as Prisma `Float` (SQLite REAL, IEEE-754) — rounding risk in aggregated analytics; flagged for the PostgreSQL/Decimal port. |

Observations (no defect ID): convert is open to any in-scope role (incl. SALES_AGENT) — confirm this matches the intended RBAC matrix; reactivate intentionally bypasses the CLOSED_LOST→CONTACTED matrix edge as a dedicated flow (documented).

## 9. UI Actions vs API Capabilities — Gaps

**Top missing capabilities:**
1. **Timeline pagination** — no `GET /api/leads/:id/activities?page=`; aggregate capped at 100 rows.
2. **Primary-phone correction flow** — `phone` is absent from patchSchema; a mistyped phone can only be fixed by DB edit or a merge workaround (no dedicated endpoint).
3. **Attribution & Arabic alias write surface** — UTM/referrer/`fullNameAr` columns exist but no route accepts them (D-LD-08/09).
4. **Persisted lead temperature / qualification metadata** — copilot HOT/WARM/COLD lives only in the latest COPILOT Activity meta; not queryable/filterable.
5. **Assignment history as data** — only Activity/AuditLog meta (not a queryable `LeadAssignment` history); also **no DELETE/purge endpoint** (archive-only — acceptable but undocumented as a data-retention stance).

Minor gaps: export parity (D-LD-01/11); no create-time PHONE_CROSS check; no `nextFollowUpAt` on quick-create (needs a later PATCH).

## 10. Verification Results (no fixes applied)

- `bun run typecheck` (`tsc --noEmit`): **PASS** — zero diagnostics.
- `bun run test` (`vitest run`): **8 files passed, 1 skipped; 153 tests passed, 10 skipped, 0 failed.** The 10 skips are the live API contract probes (`tests/contract/api.test.ts`) — the dev server on :3000 was not running during the audit; they are environment-conditional, not failures.

## 11. Recommended Next Actions (priority order)

1. Fix export multi-status (accept the comma vocabulary like the list route) — D-LD-01.
2. Handle P2002 in `/convert` (or make merge set survivor conversion facts) — D-LD-02.
3. Exact-match email dedup + PATCH email validation + phone normalization on PATCH — D-LD-03/05.
4. Add `optionalMoney` to lead budgets — D-LD-04.
5. Sync (or derive) the Lead requirement snapshot from `Requirement` — D-LD-07.
6. Expose UTM/referrer + `fullNameAr` in create/patch — D-LD-08/09.
7. Paginate the timeline (extend `[id]/activities` with GET) — D-LD-10.
8. Forward `idle`/`unassigned` in export params — D-LD-11.
9. Decide the family-shared-number policy (secondaryPhone assist at create time, or a manager force path) — D-LD-16.
