# ASAS CRM — Lead Management: Implementation Task Register (Phase 2.2 Execution Enforcement)

**Principal:** GLM-5.3 principal agent · **Session:** 2026-11-03 (Phase 2.2) · **Execution contract:** `ASAS_LEADS_MASTER_IMPLEMENTATION_ROADMAP.md`

**Method:** zero-trust re-verification of the LM mission's claimed VERIFIED state at HEAD (`4d1f71a`, src identical to LM commit `23fc602`), foundational defect correction, then browser-verified execution of every remaining verification task. **Status: COMPLETE — all tasks VERIFIED.**

**Status legend:** NOT STARTED → IN PROGRESS → CODED → INTEGRATED → TESTED → VERIFIED → BLOCKED / FAILED / DEFERRED

---

## Baseline findings (2026-11-03, measured)

1. Dev server boots: PASS (`✓ Ready`, `/` → 200).
2. Typecheck: initially **22 errors**, all from an untracked orphan file cluster (never committed, zero tracked imports). **Quarantined at `4d1f71a`** → `.quarantine/phase22-orphans/` (29 paths).
3. Tracked application code (the LM mission output) committed at `23fc602`, untouched since — verified `git diff 23fc602..HEAD --stat -- src/ prisma/` is empty.

---

## WAVE F — Foundational code correction (mission STEP 2)

| ID | Priority | Problem | Owner | Files | Acceptance | Status |
|---|---|---|---|---|---|---|
| F-01 | P0 | 22 TS errors from unused orphan cluster | Principal | quarantine → `.quarantine/phase22-orphans/` (commit `4d1f71a`) | typecheck errors = 0 | **VERIFIED** |
| F-02 | P0 | Typecheck 0 errors on tracked app | Principal | — | `bun run typecheck` exit 0 | **VERIFIED** (exit 0, measured) |
| F-03 | P0 | Lint clean | Principal | — | `bun run lint` 0/0 | **VERIFIED** (exit 0, measured) |
| F-04 | P0 | Test suite green | Principal | — | 163/163 pass | **VERIFIED** — required TWO fixes first: (a) X-02 contract-probe IPv6 defect; (b) X-03 empty-DB recovery (platform reset had wiped the seed). After fixes: **163/163 PASS incl. all 10 live contract probes** (previously silently skipped — the prior session's "163/163" claim had never actually exercised the contract file's live probes against a seeded DB in this environment) |
| F-05 | P0 | Dev server stable | Principal | — | `/` → 200, health dbOk | **VERIFIED** (`{"status":"ok","dbOk":true}`) |

## WAVE V — Zero-trust re-verification of LM mission claims (mission STEPS 4–7)

Each claim re-executed in the real browser with DB/API evidence. Owners: A6a = QA subagent (drawer cluster); A6b = Principal (list/responsive cluster); A5 = backend subagent (API cluster).

| ID | Priority | Claim under test | Owner | Verification method | Status |
|---|---|---|---|---|---|
| V-01 | P0 | B-01 inline name/contact editing persists (DB round-trip) | A6a | browser: edit name → API GET shows persisted value → revert → re-verify | **VERIFIED** (Karima Lounis → "QA P22 Vérif" → API persisted → reverted; phone validation also exercised by A5-P9) |
| V-02 | P0 | B-02 convert requires explicit confirm; cancel safe | A6a | browser: convert dialog renders BEFORE any action; Annuler → status unchanged, convertedAt null, oppCount 0 | **VERIFIED** |
| V-03 | P1 | B-03 desktop drawer action parity (Task/Visit verbs ≥768px) | A6a | screenshot at 1440 (verbs 36×36 visible); Task verb → Tâches tab; Visit verb → Planifier dialog; 375 bottom bar contrast | **VERIFIED** |
| V-04 | P1 | B-04/B-06 propertyType i18n + temperature tier chip | A6a | raw `VILLA` → displayed "Villa" (enum absent from DOM); score 41 → "Tiède"; create-select options localized (Studio…Terrain) | **VERIFIED** |
| V-05 | P0 | B-05 priority dropdown persists | A6a | menu 4 priorities w/ check; NORMAL→HIGH → API HIGH → reverted; toast | **VERIFIED** |
| V-06 | P0 | C-01..C-03 create dialog: stable width, i18n placeholders, source memory | Principal | 576px at step 1 AND step 2; placeholders "0555 12 34 56"/"Ex : Yacine Belkacem"; full create (PHONE source) → reopen → "Téléphone" preselected; phone normalized +213555443322; test lead archived, total back to 43 | **VERIFIED** |
| V-07 | P1 | D-01/D-02 zero horizontal overflow + mobile card locale | Principal | programmatic scrollWidth/clientWidth: 375/375, 768/768, 1024/1024, 1440/1440, 1920/1920; RTL 375+1440 zero; AR card shows رضا مقراني | **VERIFIED** |
| V-08 | P1 | E-01 mobile language switcher reachable | Principal | FR/EN/ع buttons in 375px top bar; ع → dir=rtl; switcher still reachable in RTL; back to FR → ltr | **VERIFIED** |
| V-09 | P1 | E-02 bell group click isolates (attention-cell law) | Principal | bell group "11 Non contactés" click → #/leads armed chip → 11 rows == API total 11 | **VERIFIED** |
| V-10 | P1 | A-01..A-06 API correctness (export facets, email dedup exact, money ≥0, merge-converted guard, phone normalization, session integrity) | A5 | direct probes P1–P10, all PASS, evidence `p22/A5_API_PROBES.md` | **VERIFIED** (10/10 PASS) |
| V-11 | P1 | Full lead list workflow: search, filter, sort, pagination, KPI strip | Principal | search "Mokrani" 1 row == API query total 1; Esc clears; KPI newLeads click arms createdAfter facet (36 rows; 38-vs-36 delta = documented archive-inclusive statistic + the 2 archived A5 probe leads — design-intentional, dashboard route comment); sort Score cycles (26→95→10); pagination page 2/2 = 18 rows (25+18=43); errors clean | **VERIFIED** |

## WAVE X — Discovered-defect register (mission STEP 8)

| ID | Priority | Defect | Root cause | Fix | Status |
|---|---|---|---|---|---|
| X-01 | P0 | 22 typecheck errors from orphan cluster | pollution files never committed, never referenced | F-01 quarantine (commit `4d1f71a`) | **RESOLVED** |
| X-02 | P1 | Contract tests silently skipped (10 probes) despite live server — suite claimed "163/163" while 10 were skipped | Node undici fetch resolves `localhost`→`::1` (IPv6) while `next dev` binds IPv4-only; curl falls back, fetch does not | Probe both candidates and pin BASE to whichever answers — `tests/contract/api.test.ts` | **RESOLVED** (163/163 incl. 10 live probes) |
| X-03 | P1 | DB empty at session start (0 users/0 orgs/0 leads) → login 401 → 2 contract FAILs | platform container reset wiped the seeded DB (file re-pushed schema-only at boot) | `db:push` + `db:seed` (8 users/35 leads); `.env` restored with ASAS_SESSION_SECRET + ASAS_DEMO_MODE=1 | **RESOLVED** (recovered; sanctioned recovery path per prior phase `dff2d6e`) |
| X-04 | P2 | Dev server does not survive Bash command boundaries in this sandbox (all spawned processes reaped per command) | container process-group cleanup (k8s sandbox) | All verification runs executed as self-contained boot→work→kill commands; documented as environmental constraint | **MITIGATED** (environmental, not an app defect) |
| X-05 | P3 | newLeads KPI (38) vs createdAfter facet (36) delta under archived-in-window leads | KPI is archive-inclusive creation STATISTIC by documented design (dashboard route comment); delta exactly = the 2 archived A5 probe leads | none needed — behavior-by-design; amplified only by test-created archived leads | **CLOSED** (documented; no production impact) |

## WAVE R — Deliverables (mission §11)

| ID | Deliverable | Status |
|---|---|---|
| R-1 | `ASAS_LEADS_IMPLEMENTATION_TASK_REGISTER.md` (this file) | **VERIFIED** |
| R-2 | `ASAS_LEADS_IMPLEMENTATION_EXECUTION_LOG.md` (Phase 2.2 continuation) | **VERIFIED** |
| R-3 | `ASAS_LEADS_IMPLEMENTATION_FINAL_REPORT.md` | **VERIFIED** |
| R-4 | `ASAS_LEADS_FINAL_QA_REPORT.md` | **VERIFIED** |
| R-5 | `ASAS_LEADS_REMAINING_DEFECTS.md` | **VERIFIED** |

---

## Roadmap-contract compliance notes

- Roadmap MUST items #1–#11, #26: implemented at LM; **all re-verified zero-trust this phase** (V-01..V-11).
- Roadmap SHOULD items #12–#18: implemented at LM; covered by V-01/V-04/V-06.
- Roadmap DEFER items #19–#24: **respected as deferred** (documented decisions — no user-facing defect; executing the contract means honoring its DEFER table).
- Roadmap REJECT item #25: no fake integrations introduced — verified in code review of diffs.
- Preservation guarantees (mission §2): verified intact — two-step create, duplicate pre-check, drawer journey rail/tabs, PATCH transactional audit law; all Phase 2.2 changes were additive (1 test-harness file + docs + quarantine move).
