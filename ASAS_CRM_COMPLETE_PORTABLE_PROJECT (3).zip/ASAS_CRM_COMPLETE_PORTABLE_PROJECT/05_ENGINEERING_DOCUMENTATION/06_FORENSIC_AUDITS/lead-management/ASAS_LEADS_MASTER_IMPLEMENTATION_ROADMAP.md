# ASAS CRM — Lead Management Experience: Master Implementation Roadmap

**Principal:** GLM-5.3 principal agent · **Stage:** 2 (product decision) · **Session:** 2026-11-03
**Inputs:** six STAGE-1 agent reports (UI forensic 74/100, UX workflow 72/100, market research, IA unification 78/100, domain/API audit, zero-trust browser QA 68/100) — all under `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/lead-management/`.

---

## 1. Principal verdict on the existing experience

The Lead Management ecosystem is **structurally strong** — one shell-level `openLead` drawer called from 21 surfaces, one badge/formatter/i18n system, server-side pagination and scope enforcement, transactional audit trails, a two-step progressive create form with duplicate pre-check and draft safety, and a p2.2 attention layer (KPI strip with click-isolation, qualify/assign quick actions, rotting ladder, idle + unassigned facets).

The decisive gaps are concentrated, not diffuse:

1. **The lead profile is not editable anywhere** although `PATCH /api/leads/:id` already accepts 15 fields (UX critical #1).
2. **Convert-to-customer is one unguarded irreversible click.**
3. **The desktop drawer hides the mobile action row** (`md:hidden`) — no schedule-visit verb on desktop.
4. **Locale/data honesty defects**: raw `propertyType` enum in 3 surfaces, mobile card shows the wrong-locale name, export drops armed facets, 16–680px horizontal overflow from the unscaled leads table.
5. **Cross-view parity breaks**: language switcher invisible on mobile, bell aggregate clicks don't isolate.

## 2. Decisions (MUST / SHOULD / OPTIONAL / DEFER / REJECT)

| # | Proposal (source) | Decision | Rationale |
|---|---|---|---|
| 1 | Inline editing of drawer profile fields (UX-A2 #1) | **MUST** | PATCH contract exists; zero server work; fixes "wrong phone is unfixable" |
| 2 | Convert confirmation dialog (UX-A2 #2) | **MUST** | Terminal + creates Contact+Opportunity; one accidental click today |
| 3 | Desktop drawer action-bar parity (UX-A2 #3) | **MUST** | Same 4 verbs both breakpoints; restores the `md:hidden` row |
| 4 | Export facet parity + multi-status CSV (UI-A1 P1, D-LD-01/11) | **MUST** | "Export what you see" is broken today |
| 5 | Email dedup `contains`→exact (D-LD-03) | **MUST** | False-positive 409s block legitimate creates |
| 6 | Budget ≥0 guards + PATCH email validation (D-LD-04/05) | **MUST** | Prerequisite for trustworthy inline editing |
| 7 | Tablet/desktop overflow-x container (QA P1/P2) | **MUST** | 680px unusable table at 768px |
| 8 | `propertyType` i18n (3 surfaces, UI-A1 P1) | **MUST** | Keys already exist in 3 languages |
| 9 | Mobile card locale fix `arabicDisplay` (UI-A1 P1) | **MUST** | Same lead, different identity per breakpoint |
| 10 | Mobile language switcher (QA P2) | **MUST** | AR users cannot switch on phones |
| 11 | Bell group click isolation (IA-A4) | **MUST** | Honors the attention-cell contract |
| 12 | Priority editable via badge menu (PATCH `priority`) | **SHOULD** | Contract exists; qualification speed |
| 13 | Score → hot/warm/cold tier label (research C10) | **SHOULD** | Display-only translation of numeric score |
| 14 | Stable create-dialog width (UI-A1 P2) | **SHOULD** | lg→2xl jump between steps is jarring |
| 15 | Placeholder i18n (phone/email) (UI-A1 P2) | **SHOULD** | Hardcoded FR strings |
| 16 | Overdue color token unification in drawer (UI-A1 P2) | **SHOULD** | attn-1-fg vs raw rose |
| 17 | Speed-to-lead age on never-contacted rows (research C2) | **SHOULD** | Creation-age replaces the dead "—" |
| 18 | Last-used source memory in quick-create (UX-A2 #3) | **SHOULD** | 4→2 clicks without corrupting attribution |
| 19 | `NextActionCell` extraction (UI-A1 dup #1) | **DEFER** | High-churn refactor of 9 live variants; behavior preserved today |
| 20 | Lost-reason/roster/stepper dedupe (UI-A1 dup #2-5) | **DEFER** | Cosmetic consolidation, no user-facing defect |
| 21 | Journey `journeyFocus` deep-links (IA-A4) | **DEFER** | Cross-view token system; next mission scope |
| 22 | TruncationNotice extraction (IA-A4) | **DEFER** | Pure refactor |
| 23 | Timeline pagination (D-LD-10) | **DEFER** | take:100 covers seeded reality |
| 24 | Saved-views upgrade / column customization (research O5) | **DEFER** | Existing saved-searches adequate |
| 25 | WhatsApp Business API, AI scoring, drip email, campaign attribution (research NOT-list) | **REJECT** | Honest-integration law; no fake integrations |
| 26 | Merge-converted guard (D-LD-02) | **MUST** | 500 → 422 with clear code |

**Wave order:** B (drawer deep engineering) → A (API correctness) → C (create form) → D (list/table) → E (cross-page) → verification.

## 3. Preservation guarantees (mission §2)

- The two-step create architecture, duplicate pre-check, draft-safety, phone preview, post-create drawer landing: **kept, only refined**.
- The drawer's next-action bands, journey rail, tabs, tags/notes flows: **kept**; additions are strictly additive (edit affordances, tier label, desktop verbs).
- All PATCH edits ride the existing mutation → existing audit/Activity transaction.

## 4. Acceptance gates (mission §16)

Typecheck + lint + tests pass · tablet 768px no horizontal overflow · drawer fields editable and persisted (verified via API) · convert requires explicit confirm · propertyType/locale/i18n defects closed · browser-verified at 375/768/1440 + RTL · execution log + final acceptance report with honest remaining-defect register.
