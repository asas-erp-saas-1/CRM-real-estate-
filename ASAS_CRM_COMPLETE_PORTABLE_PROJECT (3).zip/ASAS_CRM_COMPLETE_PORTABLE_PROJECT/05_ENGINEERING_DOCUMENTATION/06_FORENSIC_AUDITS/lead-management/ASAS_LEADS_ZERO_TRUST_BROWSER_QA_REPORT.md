# ASAS CRM — Leads Management: Zero-Trust Responsive Browser QA Report

**Task ID:** S1-A6-retry · **Agent:** 6 (Responsive Browser QA) · **Date:** 2026-11-03
**Target:** `/` (client-side views + sidebar nav) — Leads view, lead drawer, create-lead dialog, language switcher, filters/search
**Tooling:** `agent-browser` (headless Chrome 156) · **Login:** demo user "Sarah Hamdi" (Directeur exécutif / MANAGER)
**Screenshots:** `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/lead-management/before/` (files `01-…` through `14-…` in this audit)

---

## 1. Executive Summary

Core lead-management interactions **work end-to-end** on desktop and mobile: login, sidebar navigation, list load, search-by-name, drawer open/close, create-lead dialog open/close, language switch FR↔AR with full RTL rendering, deep-linking (`#/leads/<id>`), mobile nav Sheet with Escape-to-close. No console or page errors during normal flows.

However, **filtering is broken server-side** (status-filter API request hangs and kills the list), the **leads table overflows horizontally on tablet** (page-level scrollbar, ~680px of pan), **desktop 1440 has a 16px overflow**, the **language switcher is unreachable on mobile**, and **many mobile touch targets are under 44px**.

**Overall score: 68/100** (see §5).

---

## 2. Test Matrix & Evidence

| # | Screenshot | Surface | Viewport | H-overflow |
|---|------------|---------|----------|------------|
| a | `01-desktop-1440x900-login-overlay.png` | Login overlay + demo profiles | 1440×900 | none |
| b | `02-desktop-1440x900-leads-list.png` | Leads list (25 rows, 12 cols) | 1440×900 | **YES (1456/1440)** |
| c | `03-desktop-1440x900-lead-drawer.png` | Lead drawer (Réda Mokrani) | 1440×900 | none |
| d | `04-desktop-1440x900-create-lead-dialog.png` | Create-lead wizard step 1 (512×435 @464,232) | 1440×900 | none |
| e | `05-desktop-1440x900-leads-filter-applied.png` | "Qualifié" filter → **API error state** | 1440×900 | none |
| f | `06-mobile-375x812-leads-list.png` | Leads list | 375×812 | none |
| g | `07-mobile-375x812-nav-open.png` | Mobile nav Sheet (overlay 375×812 + 256px panel) | 375×812 | none |
| h | `08-mobile-375x812-lead-drawer.png` | Lead drawer, full-screen sheet | 375×812 | none |
| i | `09-mobile-375x812-create-lead-dialog.png` | Create-lead dialog (343×495 @16,158) | 375×812 | none |
| j | `10-tablet-768x1024-leads-view.png` | Leads list | 768×1024 | **YES (1448/768)** |
| k | `11-tablet-768x1024-lead-drawer.png` | Drawer (672×1024 centered) | 768×1024 | none |
| l | `12-mobile-375x812-arabic-leads-list.png` | Leads list, Arabic RTL | 375×812 | none |
| m | `13-mobile-375x812-arabic-lead-drawer.png` | Drawer AR (h2 «رضا مقراني») | 375×812 | none |
| n | `14-desktop-1920x1080-leads-view.png` | Leads list | 1920×1080 | none |

---

## 3. Defect List

### D1 — P1 · Status filter API request hangs; leads table unmounts with error
- **Screenshot:** `05-desktop-1440x900-leads-filter-applied.png`
- **Page/Viewport:** Leads view, 1440×900 (viewport-independent)
- **Expected:** Checking filter "Qualifié" refetches and shows qualified leads.
- **Actual:** `GET /api/leads?status=QUALIFIED&page=1&pageSize=25&withStats=1&sort=createdAt&dir=desc` is sent **twice and never responds** (no status code; both pending indefinitely). UI shows alert **«API non encore disponible (intégration en cours)»** with a "Réessayer" button, the entire table unmounts (0 rows, no tbody), and "Exporter CSV" becomes disabled. Unfiltered `GET /api/leads` and `?query=Mokrani` both return 200, isolating the fault to the `status` filter path (server-side).
- **Repro:** Login → Prospects → `Filtres` → check `Qualifié` → close popover (Esc). Recovery: `Effacer les filtres` restores the list.
- **Note:** The dev server process died ~1 min after this test and required restart; correlation unproven but worth investigating (possible server crash loop triggered by the hanging handler).

### D2 — P1 · Horizontal page overflow on tablet (768×1024)
- **Screenshot:** `10-tablet-768x1024-leads-view.png`
- **Page/Viewport:** Leads view, 768×1024
- **Expected:** All content within viewport or inside an internal scroll container.
- **Actual:** `document.scrollWidth = 1448` vs `innerWidth = 768` → **~680px page-level horizontal scrollbar**. Root cause: leads table `table.crm-zebra` has `min-width: 1120px` (`min-w-[1120px]`) and **no ancestor declares `overflow-x: auto|scroll`** (verified via computed styles on every ancestor up to body — all `visible`), so overflow propagates to the document. Score/Actions columns are off-screen.
- **Repro:** Set viewport 768×1024 → Prospects → observe bottom horizontal scrollbar / pan.

### D3 — P2 · Horizontal overflow on desktop 1440×900 (same root cause)
- **Screenshot:** `02-desktop-1440x900-leads-list.png`
- **Page/Viewport:** Leads view, 1440×900
- **Expected:** No document-level horizontal scrollbar at standard desktop width.
- **Actual:** `scrollWidth = 1456` vs `1440` (16px overflow). Table renders 1459px wide (L:257→R:1716) with sidebar ≈256px; the last columns ("Score", "Actions rapides") extend past the right edge.
- **Repro:** 1440×900 → Prospects → `document.documentElement.scrollWidth > window.innerWidth` → true. (Not present at 1920×1080.)

### D4 — P2 · Language switcher (FR/EN/ع) not visible on mobile
- **Screenshots:** `06-mobile-375x812-leads-list.png`, `12-mobile-375x812-arabic-leads-list.png` (AR only reachable by switching at ≥ tablet width first)
- **Page/Viewport:** Top bar, 375×812
- **Expected:** User can change language on mobile.
- **Actual:** Buttons exist in the DOM (`FR`, `EN`, `ع`) but all report `getBoundingClientRect().width = 0` at 375px — the "Changer de langue" group is hidden on small screens with no alternative entry point (not in nav Sheet, not in overflow menu). Language had to be switched at 1280px, then viewport resized, to capture RTL mobile screenshots.
- **Repro:** 375×812 → inspect top bar → language buttons invisible; no language control reachable.

### D5 — P2 · Sub-44px touch targets across mobile surfaces
- **Screenshots:** `06-…-leads-list.png`, `07-…-nav-open.png`, `09-…-create-lead-dialog.png`
- **Page/Viewport:** Mobile leads list / nav / create dialog, 375×812
- **Expected:** Interactive elements ≥ 44×44px (Apple HIG / WCAG 2.5.8).
- **Actual (measured):**
  - Create dialog: text inputs & Source combobox **36px tall**; close **X button 16×16px**.
  - Toolbar: "Archivés" 40×36, "Recherches sauvegardées" 42×36, "Doublons probables" 64×36, "Importer/Exporter CSV" 42×36.
  - Range tabs ("7/30/90 jours", "Tout") **24px tall**; KPI quick-filter pills 28px tall.
  - Task "Terminer" buttons **16×16px**; row action links ("Ouvrir la fiche prospect") 20px tall.
  - Skip-link renders at 1×1px.
- **Repro:** 375×812 → measure bounding boxes of buttons/inputs in toolbar, dialog, tabs.

### D6 — P3 · Dev server availability during QA (infrastructure note)
- Dev server (`next dev -p 3000`) died mid-session (~02:46, after ~25 min uptime, right after the D1 test) and did not auto-restart; required manual restart to continue. Filed as observation; if the hanging `status=` handler (D1) can crash the process, D6 escalates to P1.

**Not defects (verified non-issues):** mobile drawer & create dialog fit viewport with no overflow and remain closable; RTL mirroring correct (Arabic lead name «رضا مقراني», localized close label «إغلاق», `dir=rtl`); `Esc` closes mobile nav Sheet; deep-link `#/leads/<id>` restores drawer after reload; no console/page errors in normal flows.

---

## 4. Verified-Working Interactions (click-tested)

| # | Interaction | Result | Where verified |
|---|-------------|--------|----------------|
| 1 | Demo login (Sarah Hamdi quick-login) | ✓ enters app, session persists across reloads | 1440×900 |
| 2 | Sidebar nav → Prospects (Leads) | ✓ all viewports incl. Arabic | 1440/768/375, AR |
| 3 | Leads list load | ✓ 25 rows/page (37 leads total per KPI) | all viewports |
| 4 | Search lead by name ("Mokrani") | ✓ live-filtered 25→1 row; clears restore 25 | 1440×900 |
| 5 | Open lead drawer (row click) | ✓ desktop / tablet / mobile / AR | 03, 08, 11, 13 |
| 6 | Close drawer (X / "Fermer" / «إغلاق») | ✓ dialog removed from DOM | 1440, 375 AR |
| 7 | Open create-lead dialog ("Nouveau prospect") | ✓ 2-step wizard renders | 04, 09 |
| 8 | Close create dialog (X) | ✓ | 375×812 |
| 9 | Language switch FR→ع and ع→FR | ✓ `dir=rtl`, `lang=ar`, full translation; back to `fr/ltr` | ≥ tablet widths |
| 10 | Filter popover + status chip + "Effacer les filtres" | ✓ UI mechanics work (but see D1 for the API) | 1440×900 |
| 11 | Mobile "Menu" button → nav Sheet; Esc closes it | ✓ overlay 375×812 + 256px panel; `[data-state=open]` cleared after Esc | 07 |
| 12 | Deep-link `#/leads/<id>` reopens drawer on reload | ✓ | 1920×1080 |
| 13 | No page errors / console errors during flows | ✓ (`agent-browser errors` empty) | all |

---

## 5. Per-Viewport Verdict & Score

| Viewport | Verdict | Key issues |
|----------|---------|------------|
| Desktop 1440×900 | **PASS w/ defects** | 16px h-overflow (D3); filter API hang (D1) |
| Desktop 1920×1080 | **PASS** | clean, no overflow |
| Mobile 375×812 | **PASS w/ defects** | no overflow; language switcher hidden (D4); touch targets (D5) |
| Tablet 768×1024 | **FAIL** | ~680px page-level h-overflow (D2) |
| RTL Arabic (375) | **PASS w/ caveat** | rendering/mirroring correct; switch only possible at larger widths (D4) |

**Score: 68/100** — deducting: D1 filter feature broken (−15), D2 tablet layout fail (−10), D3 desktop overflow (−3), D4 mobile language gap (−3), D5 touch targets (−1). Strengths: rock-solid core interactions, full AR localization, no JS errors, dialogs/drawers fit all tested viewports.

## 6. Recommended Next Actions

1. **Fix `GET /api/leads?status=…` handler** (hang → likely never-resolving query/loop; add timeout + investigate link to server crash).
2. **Wrap leads table in `overflow-x-auto`** container (fixes D2 + D3 at once).
3. **Surface the language switcher on mobile** (move into nav Sheet or top-bar overflow menu).
4. **Raise mobile touch targets to ≥44px** (inputs 36→44, tabs, X buttons, "Terminer" 16×16 → icon-button size).

---

## AFTER-PASS — 2026-11-03 (post-implementation verification by the principal)

Baseline defects re-tested after the implementation waves:

| Baseline defect | Re-test result |
|---|---|
| P1 tablet h-overflow (1448 vs 768) | **FIXED** — root cause: sr-only absolute spans in table cells escaping the scroll container (containing block = viewport). `.crm-td { position: relative }` makes cells the containing block. Measured: 768=768. |
| P2 desktop 16px h-overflow (1456 vs 1440) | **FIXED** — same root cause. Measured: 1440=1440. |
| P2 language switcher invisible on mobile | **FIXED** — MobileLangSwitch in the top bar; verified by switching FR→ع at 375px (RTL applied, Arabic alias on cards). |
| P1 status filter API hang | **NOT REPRODUCIBLE** — every facet combination returns <25ms on direct probes (authenticated). Classified as dev-server load during concurrent browser testing; watch item. |
| P2 sub-44px touch targets | **IMPROVED** — tag-row remove/quick-add raised; drawer header buttons size-9; mobile verb bar h-11 (pre-existing). |

New-interaction verification (all executed AND DB-verified): name inline edit · priority menu · contact editor with normalization · convert confirmation (cancel-safe) · propertyType localization · tier chip · requirements snapshot sync · desktop Task/Visit verbs · source memory · bell isolation (12=12) · create-dialog stable width · discard guard. Evidence screenshots: `after/` folder.
