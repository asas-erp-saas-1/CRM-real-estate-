# P2.2-A5 — API Correctness Probes (WAVE V / V-10)

**Mission:** zero-trust verification of the Phase 2.2 API-fix claims (email dedup exact-match, money-law validation, export facet parity, merge-converted guard, PATCH validation) with live probes against the dev server.
**Agent:** A5 (CRM Backend, Database and Business Logic).
**Date:** 2026-11-03 (probe run timestamped in `tmp-scripts/a5-results.json`).
**Verdict: 11/11 probes PASS — every claim reproduced against the live server. No contract mismatch found.**

---

## Environment & Method

- **Server:** `next dev` on `http://127.0.0.1:3000` (IPv4 — Node's `localhost` resolves `::1` which the dev server does not bind), started/waithed/killed inside one self-contained Bash command per run (this sandbox reaps background processes between commands).
- **DB:** SQLite `db/custom.db` (Prisma). Pre-probe state: 8 active users, **43 leads** (1 CLOSED_LOST, 10 CONTACTED, 20 CONVERTED, 11 NEW, 1 REACTIVATED), **0 archived**, 0 unassigned-active, 4 idle-active, 21 NEW+CONTACTED-active (verified via direct Prisma read before any probe ran).
- **Personas:** `sarah@asas.dz` / `asas1234` (MANAGER — primary), `mounia@asas.dz` / `asas1234` (FIELD_REP — negative gate P8b). Both logins returned HTTP 200 with an HMAC-signed `asas_user` cookie.
- **Probe runner:** `tmp-scripts/a5-probes.ts` (read-only w.r.t. app source; manual cookie header handling; 30s per-request timeout for first-hit route compilation; own RFC-4180-ish CSV parser matching the app's house format: `;` delimiter, UTF-8 BOM, CRLF, `""` escapes).
- **Raw evidence:** `tmp-scripts/a5-results.json` (machine-readable full bodies/facts per probe).
- **No source files modified.** Only two leads created during the run, both archived at the end (see Cleanup).

### Contracts read before probing (design input)

`src/app/api/leads/route.ts`, `src/app/api/leads/[id]/route.ts`, `src/app/api/leads/export/route.ts`, `src/app/api/leads/[id]/convert/route.ts`, `src/app/api/leads/duplicates/merge/route.ts`, `src/lib/phone.ts`, `src/lib/server/validation.ts`, `src/lib/server/session.ts`, `src/lib/server/visibility.ts`, `src/lib/server/csv.ts`, `prisma/seed.ts`.

---

## Verdict Summary

| Probe | Claim | Verdict |
|---|---|---|
| P1 | Export multi-status CSV parity | **PASS** |
| P2 | Export `idle=1` facet parity | **PASS** |
| P3 | Export `unassigned=1` facet parity | **PASS** |
| P4 | Email dedup is EXACT, not substring | **PASS** |
| P5 | Money law (non-negative budgets) | **PASS** |
| P6 | PATCH email shape validation | **PASS** |
| P7 | Convert guard on CONVERTED lead | **PASS** |
| P8a | Export without cookie → 401 JSON | **PASS** |
| P8b | `unassigned` facet manager-gated → 403 for FIELD_REP | **PASS** |
| P9 | Phone normalization round-trip | **PASS** |
| P10 | Forged cookie → 401, no leak | **PASS** |

---

## P1 — Export multi-status CSV

**Request (manager):**
```
GET /api/leads/export?status=NEW,CONTACTED
GET /api/leads?status=NEW,CONTACTED&pageSize=1      (parity reference)
```

**Expected:** 200 `text/csv`; every data row's Status column ∈ {NEW, CONTACTED}; CSV data-row count == JSON `total`.

**Actual:**
- Export: **200**, `Content-Type: text/csv; charset=utf-8` (also `Content-Disposition: attachment; filename="asas-prospects-<date>.csv"`, `Cache-Control: no-store`).
- CSV: 20 header columns (`id;fullName;phone;phoneDisplay;email;source;campaign;status;priority;score;budgetMin;budgetMax;propertyType;desiredLocation;owner;tags;createdAt;lastContactAt;nextFollowUpAt;lostReason`) — note the status column is the lowercase `status` header (the claim's "Status column").
- **21 data rows**, distinct status values observed: `["NEW","CONTACTED"]` — no foreign status leaked in.
- JSON list: `total = 21` → **21 == 21**.

**Verdict: PASS.** The comma-vocabulary `status` filter is honored identically on both surfaces ("export what you see"), matching the D-LD-01 fix in the route code.

---

## P2 — Export idle facet

**Request (manager):**
```
GET /api/leads/export?idle=1
GET /api/leads?idle=1&pageSize=1
```

**Expected:** 200 CSV; row count == JSON total (idle = last contact strictly older than 14 days; never-contacted leads are NOT idle).

**Actual:**
- Export: **200** `text/csv`; **4 data rows**.
- JSON list: `total = 4` → **4 == 4**.
- Cross-check with direct DB read before the run: `idle(active) = 4` — the facet's predicate (lastContactAt < now−14d, archived=false) matches the seeded cooling set exactly.

**Verdict: PASS.** D-LD-11 law identical on list and export.

---

## P3 — Export unassigned facet

**Request (manager):**
```
GET /api/leads/export?unassigned=1
GET /api/leads?unassigned=1&pageSize=1
```

**Expected:** 200 CSV; row count == JSON total. (Pre-run DB had 0 unassigned-active leads, so the probe was sequenced AFTER P4 created an unassigned probe lead to make the parity check non-vacuous.)

**Actual:**
- Export: **200** `text/csv`; **1 data row** (the unassigned probe lead A).
- JSON list: `total = 1` → **1 == 1**.
- After archiving lead A: unassigned facet `total` returned to **0** (facet tracks the pool both entering and leaving — see P4 cleanup).

**Verdict: PASS.**

---

## P4 — Email dedup is EXACT, not substring

**Setup:** from `GET /api/leads?pageSize=50` (manager), first lead with an email: **Réda Mokrani** (`cmw0ly2yb007sqyk0x5dyop09`), `E = reda.mokrani@gmail.com`.

**Requests (manager):**
```
(a) POST /api/leads  { "fullName":"A5 Dedup Substring Probe", "phone":"0769000141",
                       "email":"zzreda.mokrani@gmail.com", "source":"WEBSITE", "priority":"LOW" }
(b) POST /api/leads  { "fullName":"A5 Dedup Exact Probe", "phone":"0769000142",
                       "email":"reda.mokrani@gmail.com", "source":"WEBSITE", "priority":"LOW" }
```

**Expected:** (a) **201** — a substring/suffix twin must NOT trigger the duplicate gate; (b) **409** `DUPLICATE` with a non-empty `duplicates[]` list.

**Actual:**
- (a) **201 Created**; response `lead.id = cmw0m73320007qy67s3vot69m`, `lead.phone = +213769000141` (normalized), `lead.email = zzreda.mokrani@gmail.com` — the substring twin sails through.
- (b) **409 Conflict**, body: `{"error":"Lead déjà existant (téléphone ou email en doublon)","code":"DUPLICATE","duplicates":[…1 entry…]}` — the duplicates list contains the existing Réda Mokrani record (caller is MANAGER → org-wide dedup scope).

**Verdict: PASS.** The dedup predicate is exact email equality (`{ orgId, email: body.email }`), not `contains` — the D-LD-03 fix is live. (Phone twins remain a separate OR-condition and the `@@unique([orgId, phone])` backstop; not contradicted by this probe.)

---

## P5 — Money law (non-negative budgets)

**Requests (manager):**
```
POST /api/leads { "fullName":"A5 Money Probe", "phone":"0769000151", "source":"WEBSITE", "budgetMin":-1 }
PATCH /api/leads/{LEAD_B} { "budgetMax":-5 }        (LEAD_B = P9's probe lead)
```

**Expected:** **422** on both; no side effects.

**Actual:**
- POST: **422**, `code = VALIDATION_ERROR`, `details = [{path:"budgetMin", message:"Le montant ne peut pas être négatif"}]`.
- PATCH: **422**, `code = VALIDATION_ERROR`, `details = [{path:"budgetMax", message:"Le montant ne peut pas être négatif"}]`.
- Side-effect check: `GET /api/leads/{LEAD_B}` afterwards → `budgetMax = null` (untouched); no lead created by the rejected POST (DB total stayed 43+2 — see Cleanup).

**Verdict: PASS.** The W1-2/A4#3 money domain law (`optionalMoney`: `min(0)`, `max(10_000_000_000)`) is enforced on both the create and PATCH paths of leads.

---

## P6 — PATCH email validation

**Request (manager):**
```
PATCH /api/leads/{LEAD_B} { "email":"not-an-email" }
```

**Expected:** **422**; garbage never persisted.

**Actual:**
- **422**, `code = VALIDATION_ERROR`, `details = [{path:"email", message:"Adresse email invalide"}]`.
- `GET /api/leads/{LEAD_B}` afterwards → `email = "a5.phone.probe@asas.dz"` (unchanged).

**Verdict: PASS.** The D-LD-05 PATCH-contact-validation claim is live (email shape enforced on PATCH, not just on create).

---

## P7 — Convert guard on a CONVERTED lead

**Requests (manager):**
```
GET  /api/leads?status=CONVERTED&pageSize=1     → total = 20, lead cmw0ly2yp008iqyk0dmvngiqf
POST /api/leads/cmw0ly2yp008iqyk0dmvngiqf/convert   (empty body)
```

**Expected:** **409** with a clear code (`ALREADY_CONVERTED` / `ALREADY_HAS_CLIENT_RECORD`); never a 500.

**Actual:** **409 Conflict**, body: `{"error":"Lead déjà converti","code":"ALREADY_CONVERTED","details":null}`.

**Verdict: PASS.** The convert route's own guard fires (convertedContactId/status check) before any transaction — no opaque P2002/500 path. The D-LD-02 `ALREADY_HAS_CLIENT_RECORD` branch (merge-inherited contact with unconverted status) was also code-verified in `convert/route.ts:29-36`; it is unreachable against the current seed because every CONVERTED-seeded lead carries its contact, so the first guard wins — reported as designed, not as a gap.

---

## P8a — Export without cookie

**Request:**
```
GET /api/leads/export          (no Cookie header at all)
```

**Expected:** **401** JSON envelope (never a CSV, never a redirect to data).

**Actual:** **401**, `Content-Type: application/json`, body: `{"error":"No active session. Reload the page.","code":"NO_SESSION", ...}`.

**Verdict: PASS.** `requireUser("MANAGER")` throws before any query; the export route's 403 remap does not swallow 401s (only `error.status === 403` is remapped to `EXPORT_FORBIDDEN`).

---

## P8b — `unassigned` facet as a non-manager (FIELD_REP)

**Code expectation (read before probing):** `leads/route.ts` gates the facet — below MANAGER the request is refused **403 `FORBIDDEN_ROLE`**; the export route additionally requires MANAGER+ for the whole surface (**403 `EXPORT_FORBIDDEN`** via its catch remap).

**Requests (mounia@asas.dz, FIELD_REP — login returned 200):**
```
GET /api/leads?unassigned=1
GET /api/leads/export?unassigned=1
```

**Expected:** list facet → **403 FORBIDDEN_ROLE** (the facet is manager-gated); export facet → **403** (route-level MANAGER+ gate).

**Actual:**
- List: **403**, `code = FORBIDDEN_ROLE`, `error = "Le filtre « non assignés » est réservé à la direction"`.
- Export: **403**, `code = EXPORT_FORBIDDEN`, `error = "L'export de prospects requiert le rôle Manager ou supérieur."`.

**Verdict: PASS.** Both gates behave exactly as the source declares; no data returned to the field-rep persona.

---

## P9 — Phone normalization round-trip

**Requests (manager):**
```
POST /api/leads { "fullName":"A5 Phone Probe", "phone":"0555 99 88 77",
                  "email":"a5.phone.probe@asas.dz", "source":"WEBSITE", "priority":"LOW" }
GET  /api/leads/{id}
```

**Expected:** **201**; stored phone is the canonical E.164 form **`+213555998877`** (per `src/lib/phone.ts`: DZ mobile `0X XX XX XX XX` → `+213` + subscriber digits); `phoneRaw` preserves the entered string.

**Actual:**
- POST: **201**, `lead.id = cmw0m73r5000fqy67j01sk9f2`, `lead.phone = +213555998877`.
- GET: `lead.phone = +213555998877`, `lead.phoneRaw = "0555 99 88 77"` (and `whatsapp` defaulted to the same canonical form).

**Verdict: PASS.** Round-trip confirmed: input formatting is stripped at the boundary and the canonical international form is what every later consumer (dedup probes, wa.me links, export `phoneDisplay`) sees.

---

## P10 — Session integrity sanity (forged cookie)

**Request:**
```
GET /api/leads      (Cookie: asas_user=forged)
```

**Expected:** **401** — never 500, never data.

**Actual:** **401**, `code = NO_SESSION`, `error = "No active session. Reload the page."`.

**Verdict: PASS.** The HMAC-signed cookie law (F-02) rejects a malformed/tampered value as "no session" — treated identically to an absent cookie, no stack trace, no record leak.

---

## Cleanup & Residue Evidence

**Created during the run (exactly 2 leads, both archived via `PATCH {archived:true}` — the documented mechanism):**

| Lead | id | Phone | Email | Archived |
|---|---|---|---|---|
| A5 Dedup Substring Probe | `cmw0m73320007qy67s3vot69m` | +213769000141 | zzreda.mokrani@gmail.com | ✅ (PATCH 200, GET archived=true) |
| A5 Phone Probe | `cmw0m73r5000fqy67j01sk9f2` | +213555998877 | a5.phone.probe@asas.dz | ✅ (PATCH 200, GET archived=true) |

**Post-run DB truth (direct Prisma read, server down):**
- `lead.count() = 45` (43 pre-existing + 2 probe leads — nothing else mutated).
- `archived = true` rows = exactly the 2 probe leads above; **0 active** leads matching any probe name/email/phone; **0 Contact rows** on the probe leads (no accidental conversion).
- In-app sweep during the run: `GET /api/leads?query="A5 "` → 0 active rows, 2 archived rows (`A5 Phone Probe`, `A5 Dedup Substring Probe`).
- The unassigned pool returned to `total = 0` after lead A's archival (P3's facet re-probed).

Side effects intentionally left in place (audit trail, per app design): `LEAD_CREATED` activity+audit rows for the 2 creates, `LEAD_ARCHIVED`-carrying status/audit trail for the 2 archives, `LEADS_EXPORTED` audit rows for the 6 manager exports. These are history rows, not live data.

## Contract Notes / Mismatches

**None found.** Every documented behavior matched the live server. Two clarifications (not mismatches):
1. The export CSV's status column header is lowercase `status` (not `Status`) — consistent with the 20-column header contract in `export/route.ts`.
2. P7's `ALREADY_HAS_CLIENT_RECORD` code path is currently shadowed by `ALREADY_CONVERTED` on all seeded CONVERTED leads (each carries its contact) — the guard exists and code-reads correct, but today's data cannot reach it via a plain status=CONVERTED probe; it targets the post-merge zombie state (unconverted status + inherited Contact) instead.

## Artifacts

- Probe runner: `tmp-scripts/a5-probes.ts` (reproducible; run inside the self-contained boot→probe→kill command).
- Pre-check: `tmp-scripts/a5-precheck.ts` (DB uniqueness of probe phones/emails before the run).
- Raw results: `tmp-scripts/a5-results.json` (full status/body facts for every probe, including the 409/422 bodies).
- This report: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/lead-management/p22/A5_API_PROBES.md`.
