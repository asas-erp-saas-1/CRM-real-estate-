# A6b — List / Create / Responsive / Cross-Page Cluster: Browser QA Report

**Executor:** Principal (after the A6b subagent hit its context limit — the work was executed directly, not delegated twice) · **Date:** 2026-11-03 · **Method:** agent-browser against the live dev server (self-contained boot→verify→kill commands; the sandbox reaps background processes per shell command).

Persona: Sarah Hamdi (MANAGER). API evidence via the same user's cookie jar. UI language: French (with an explicit RTL/Arabic pass).

---

## V-06 — Create dialog: stable width, i18n placeholders, source memory — **PASS**

| Check | Expected | Observed | Verdict |
|---|---|---|---|
| Dialog width step 1 | stable sm:max-w-xl (≈576px) | `576` (measured via getBoundingClientRect on `[role=dialog]`) | PASS |
| Dialog width step 2 | identical | `576` | PASS |
| Phone placeholder | localized FR | `0555 12 34 56` | PASS |
| Name placeholder | localized FR | `Ex : Yacine Belkacem` | PASS |
| Source options | localized labels | Facebook Ads, Instagram, WhatsApp, Site web, Ouedkniss, Google, TikTok, Recommandation, Visite bureau, Téléphone, Client existant, Promoteur | PASS |
| Full create | persists + normalizes phone | API: id `cmw0q79n80003qy97sjb9o1la`, source `PHONE`, phone `+213555443322` (input "0555 44 33 22") | PASS |
| Source memory (C-03) | last-used source preselected on pristine reopen | reopened combobox shows **Téléphone** (the create's source) | PASS |
| Dirty-draft guard | fires on abandoning a filled form | fired in A6a's V-04 close (total unchanged); this flow discarded cleanly | PASS |
| Cleanup | test lead archived, total back | `PATCH {archived:true}` → 200; active total **43** | PASS |

Notes: the pristine-reopen-after-mere-selection correctly shows "Sélectionner…" — the memory law writes on SUCCESS only (verified against the code comment in `create-lead-dialog.tsx`). Radix Select option clicks are intercepted by the item wrapper (pointer-events quirk) — keyboard navigation (typeahead/ArrowDown+Enter) used instead; an automation note, not an app defect.

Screenshots: `a6b-v06-create.png`, `a6b-v06-step2.png`, `a6b-v06-memory.png`, `a6b-v06-created.png`.

## V-07 — Responsive overflow law — **PASS**

Programmatic `document.documentElement.scrollWidth / clientWidth`:

| Viewport | Measurement | Verdict |
|---|---|---|
| 375×812 | 375 / 375 | PASS |
| 768×1024 | 768 / 768 | PASS |
| 1024×768 | 1024 / 1024 | PASS |
| 1440×900 | 1440 / 1440 | PASS |
| 1920×1080 | 1920 / 1920 | PASS |
| 375×812 RTL | 375 / 375 | PASS |
| 1440×900 RTL | 1440 / 1440 | PASS |

Mobile AR identity: first card renders **رضا مقراني** (locale-resolved alias; D-02 law). Screenshots: `a6b-v07-375/768/1440.png`, `a6b-v07-rtl-375.png`, `a6b-v07-rtl-1440.png`.

## V-08 — Mobile language switcher — **PASS**

- Segmented control FR / EN / **ع** present in the 375px top bar (snapshot refs e8/e9/e10 — the `MobileLangSwitch` `md:hidden` component).
- Clicking ع: `document.documentElement.dir` → **rtl**; heading "العملاء المحتملون"; full AR nav.
- Switcher remains reachable in RTL (FR/EN/ع buttons in the AR snapshot).
- Switching back to FR: dir → ltr (verified on reload round-trip).
- Screenshots: `a6b-v08-before.png`, `a6b-v08-after.png`.

## V-09 — Bell group click isolation — **PASS**

- Bell panel group: "11 prospect(s) jamais contacté(s)" (LEADS_UNCONTACTED).
- API truth: `?uncontacted=1` total = **11**.
- Click → URL `#/leads`, facet chip "× Non contactés" armed, table rows = **11**. **11 = 11 — the attention-cell law holds.**
- Screenshot: `a6b-v09-panel.png`, `a6b-v09-armed.png`.

## V-11 — Full list workflow — **PASS**

| Sub-flow | Expected | Observed | Verdict |
|---|---|---|---|
| Clear filters | full set returns | 43 résultat(s) · Page 1/2, 25 rows/page, all statuses incl. Converti | PASS |
| Search "Mokrani" | UI rows == API `?query=mokrani` total | UI 1 row == API total 1 | PASS |
| Clear search (Esc affordance) | full set returns | 25 rows, pager "43 résultat(s) · Page 1 / 2" | PASS |
| KPI click (newLeads "38 Nouveaux prospects") | facet arms + isolates | createdAfter facet armed (chip active), **36 rows live**; 38-vs-36 delta = the 2 archived A5 probe leads + the documented archive-inclusive creation statistic (`api/dashboard/route.ts` comment) — behavior-by-design, root-caused | PASS |
| Sort by Score | order cycles | first-row score 26 → 95 (desc) → 10 (asc) | PASS |
| Pagination | page 2 correct | Page 2 / 2, **18 rows** (25+18 = 43 exact) | PASS |
| Console/page errors | none | `agent-browser errors` empty after every sub-flow | PASS |

Screenshots: `a6b-v11-search.png`, `a6b-v11-kpi.png`, `a6b-v11-page2.png`.

---

## Mutations & hygiene

Created: 1 lead ("QA P22 Source Test", +213555443322, source PHONE) — **archived** (200), active total back to **43**. No other mutations (V-09/V-11 flows are read-only; facet state is client-side). localStorage source-memory key remains per-user (a preference, by design).

## Verdict

**V-06, V-07, V-08, V-09, V-11 — 5/5 PASS.** No application defects found in this cluster.
