# A6 — Independent Browser QA — Lead Drawer Feature Cluster (WAVE V)

- **Mission:** P2.2-A6a — ASAS CRM Phase 2.2, Agent 6 (Integration, Code Review & Independent QA)
- **Scope:** Zero-trust BROWSER verification of the lead-drawer feature cluster, verifications V-01 … V-05
- **Date:** 2026-11-03 (12:41–12:48 local)
- **Environment:** Next.js 16 dev server (`bun run dev`) at `http://127.0.0.1:3000`, agent-browser (headless Chromium, CDP), viewport 1440×900 (desktop) / 375×812 (mobile), session `a6a-qa`
- **Persona:** Sarah Hamdi (Directrice exécutive, MANAGER) — demo persona tile login
- **Evidence law applied:** per principal's verified AUDIT LAW, PATCHes of profile fields (fullName/priority/contact) write **no AuditLog rows** — all persistence evidence below is **API GET** (`curl -b /tmp/a6a-cookies.txt`), not audit-table queries.
- **Honesty note:** a prior QA attempt was killed mid-run; its `a6-v*.png` artifacts were treated as untrusted and have been **overwritten** by this run's own screenshots (all timestamps 12:41–12:46). No application source under `src/`, `prisma/` or `tests/` was modified. The only mutations performed (lead name, lead priority) were both reverted and API-verified (see §Mutations).

---

## V-01 — Inline name editing persists — **PASS**

**Target lead (picked via API):** `cmw0ly2y8007oqyk02d3p30o2` — Karima Lounis, status CONTACTED, priority NORMAL.

**Steps executed:**
1. `GET /api/leads?pageSize=50` (cookie jar from `POST /api/auth/login` sarah@asas.dz) → recorded original `fullName: "Karima Lounis"`.
2. UI login via the "Sarah Hamdi Directeur exécutif" persona tile on `http://127.0.0.1:3000/#/leads/{id}` → drawer opens directly for the hash-routed lead.
3. Screenshot of the opened drawer → `a6-v01-drawer.png`.
4. Clicked the name in the drawer header — the edit affordance is a `<button>` with `aria-label="Modifier le nom"` (pencil icon appears on hover/focus). The title swaps to an inline `<input>` (same aria-label).
5. `fill` → `QA P22 Vérif`, `press Enter` (Enter routes through blur → single submit). A green toast **"Enregistré"** appeared.
6. Screenshot → `a6-v01-edited.png`.
7. **API evidence (after edit):**
   `curl -s -b /tmp/a6a-cookies.txt http://127.0.0.1:3000/api/leads/cmw0ly2y8007oqyk02d3p30o2`
   ```json
   { "id": "cmw0ly2y8007oqyk02d3p30o2", "fullName": "QA P22 Vérif", "priority": "NORMAL", "status": "CONTACTED" }
   ```
   → `fullName` persisted exactly as typed (accented string intact).
8. **Revert:** clicked the name again, restored `Karima Lounis`, Enter, screenshot → `a6-v01-reverted.png`.
   **API evidence (after revert):**
   ```json
   { "fullName": "Karima Lounis", "priority": "NORMAL" }
   ```
9. `agent-browser errors` → empty (no page errors).

**Expected vs observed:** click-to-edit input appears; Enter persists; PATCH `fullName` visible on next API GET — **all observed**. VLM cross-check of `a6-v01-edited.png` independently read the header as "QA P22 Vérif" + "Enregistré" toast.

**Screenshots:** `a6-v01-drawer.png`, `a6-v01-edited.png`, `a6-v01-reverted.png`.

---

## V-05 — Priority dropdown persists — **PASS**

**Target lead:** same as V-01 (Karima Lounis, original priority NORMAL).

**Steps executed:**
1. Clicked the priority badge in the drawer header (button `aria-label="Priorité"`). Dropdown opened with a "Priorité" label and the 4 priorities. Screenshot → `a6-v05-menu.png`.
2. Programmatic check of the open menu (eval over `[role=menuitem]`, check icon = svg):
   ```
   "Basse [no-check]", "Normale [CHECK]", "Haute [no-check]", "Urgente [no-check]"
   ```
   → 4 priorities, check on the current one (**Normale**). Note: the app's FR vocabulary for the NORMAL tier is **"Normale"** (not "Moyenne" as phrased in the mission brief) — Basse / Normale / Haute / Urgente, matching `priority.LOW/NORMAL/HIGH/URGENT` in `src/lib/i18n/domains/enums.ts`.
3. Selected **Haute** → screenshot → `a6-v05-changed.png`.
   **API evidence (after change):**
   ```json
   { "fullName": "Karima Lounis", "priority": "HIGH" }
   ```
4. Reopened the menu (check had moved: `"Haute [CHECK]"`) and re-selected **Normale** → screenshot → `a6-v05-reverted.png`.
   **API evidence (after revert):**
   ```json
   { "fullName": "Karima Lounis", "priority": "NORMAL" }
   ```
5. `agent-browser errors` → empty.

**Expected vs observed:** dropdown with the 4 priorities, check tracks the current value, PATCH `{priority}` persists across reload-by-API — **all observed**. VLM cross-check of `a6-v05-menu.png` independently listed Basse/Normale/Haute/Urgente with the check on Normale.

**Screenshots:** `a6-v05-menu.png`, `a6-v05-changed.png`, `a6-v05-reverted.png`.

---

## V-02 — Convert requires explicit confirmation — **PASS**

**Target lead (picked via API, NOT converted):** `cmw0ly2yb007sqyk0x5dyop09` — Réda Mokrani, status **NEW**, 0 opportunities (pre-check via `GET /api/leads/{id}` → `status: "NEW"`, `oppCount: 0`), so the convert CTA is shown.

**Steps executed:**
1. Hash-navigated to `#/leads/{id}` → drawer opened for Réda Mokrani.
2. Switched to the **Opportunités** tab → dashed convert CTA band with the **"Convertir"** button.
3. Clicked **Convertir** — BEFORE any mutation, an **AlertDialog** appeared. Screenshot → `a6-v02-dialog.png`.
   Programmatic capture of the dialog (`[role=alertdialog]` innerText):
   ```
   Confirmer la conversion | Un contact et une opportunité seront créés dans le pipeline,
   puis le prospect sera verrouillé en « Converti ». Cette action est irréversible. |
   Annuler | Convertir définitivement
   ```
   → the dialog names all three consequences: contact creation, opportunity creation, irreversibility.
4. Clicked **Annuler** → dialog closed (`[role=alertdialog]` absent).
   **API evidence (after Annuler):**
   ```json
   { "fullName": "Réda Mokrani", "status": "NEW", "convertedAt": null, "oppCount": 0 }
   ```
   → status **UNCHANGED**, not locked, no opportunity created.
5. The conversion was **NOT** executed (no click on "Convertir définitivement").
6. `agent-browser errors` → empty.

**Expected vs observed:** no action on first click; explicit confirm dialog explaining consequences; Annuler leaves the lead untouched — **all observed**. VLM cross-check of `a6-v02-dialog.png` independently read the title, body text and both buttons.

**Screenshot:** `a6-v02-dialog.png`.

---

## V-03 — Desktop drawer action parity — **PASS**

**Target lead:** `cmw0ly2xs006sqyk0gjr3ay42` — Youcef Amrani (drawer opened via hash URL).

**Steps executed (desktop, viewport 1440×900):**
1. Screenshot of the drawer → `a6-v03-desktop.png`.
2. Programmatic visibility check of the header verb row (eval over `button[aria-label]`, computed style + bounding rect):
   ```
   "Tâche"   visible=true size=36x36 next-to=Appeler
   "Visite"  visible=true size=36x36 next-to=Tâche
   "Modifier les contacts" visible=true size=36x36 next-to=Visite
   ```
   → the Task (CheckSquare) and Visit (CalendarPlus) icon buttons render in the header next to the WhatsApp/call/pencil actions (the `hidden md:inline-flex` pattern resolves visible at ≥md).
3. Clicked the **Tâche** verb → drawer switched to the **Tâches** tab (eval over `[role=tab]` → `SELECTED:Tâches`). Screenshot → `a6-v03-task-tab.png`.
4. Clicked the **Visite** verb → the shell-level schedule-visit dialog opened ON TOP of the still-open drawer. Programmatic capture:
   ```
   "Planifier une visite | Planifiez et suivez les visites | Prospect | Youcef Amrani |
    Projet | Sélectionner… | Agent | Sélectionner… | Date | Heure | Notes |
    Annuler | Planifier une visite | Fermer"   (rect 448x438, visible)
   ```
   Screenshot → `a6-v03-visit-dialog.png`. Closed it via **Annuler** (verified closed by rect-based check).
5. **Mobile parity:** `set viewport 375 812` → the bottom action bar (`role=group`, `aria-label="Actions rapides client"`, `md:hidden`) is visible: `display: block`, rect `374×57 @ y=755`, containing the 4 verbs:
   ```
   ["WhatsApp", "Journaliser", "Tâche", "Visite"]
   ```
   Screenshot → `a6-v03-mobile.png`. Horizontal overflow check: `scrollWidth 375 vs client 375` (no overflow).
6. `agent-browser errors` → empty.

**Expected vs observed:** desktop header gains Task + Visit verbs (parity with the mobile 4-verb bar), Task verb → Tasks tab, Visit verb → schedule-visit dialog, mobile bar intact at 375×812 — **all observed**. VLM cross-checks of `a6-v03-visit-dialog.png` (dialog fields, Prospect=Youcef Amrani) and `a6-v03-mobile.png` (bar: WhatsApp icon, Journaliser, Tâche, Visite) corroborate.

**Screenshots:** `a6-v03-desktop.png`, `a6-v03-task-tab.png`, `a6-v03-visit-dialog.png`, `a6-v03-mobile.png`.

---

## V-04 — propertyType i18n + temperature tier chip — **PASS**

**Target lead (picked via API with propertyType set):** `cmw0ly2y8007oqyk02d3p30o2` — Karima Lounis, raw enum `propertyType: "VILLA"`, `score: 41`.

**Steps executed (drawer, 1440×900):**
1. Opened the lead's drawer. Programmatic extraction of the info band:
   - Property cell text: `"Type de bienVilla"` → displays **"Villa"** (localized), and a whole-page scan found **no raw `VILLA` token anywhere** (`/\bVILLA\b/` false, `/\bVilla\b/` true).
   - Temperature chip (located via its title): `<span title="Score: 41/100">Tiède</span>` → score 41 → **Tiède** tier, matching the rule Chaud ≥70 / Tiède ≥40 / Froid <40.
2. Screenshot → `a6-v04-info.png`.
3. **Create dialog:** hash-navigated to `#/leads` (drawer closed), clicked **"Nouveau prospect"**. Step 1 filled minimally (name "QA Vérif Test", phone 0550998877, source "Facebook Ads") → **Continuer** → step 2 shows the **"Type de bien"** select. Opened it — options (accessibility snapshot, `role=option`):
   ```
   Studio, F2, F3, F4, F5, Duplex, Villa, Terrain
   ```
   → localized labels, not the raw enums (raw would be STUDIO/DUPLEX/VILLA/LAND; F2–F5 are identical in both vocabularies). Screenshot → `a6-v04-create.png`.
4. **Closed WITHOUT saving:** Escape on the open select, Escape on the dialog → the dirty-draft guard fired: AlertDialog **"Abandonner la saisie ?"** ("Les informations saisies seront perdues.") with "Continuer la saisie" / "Abandonner". The dialog ended fully closed with the draft discarded.
   *Automation note (honest):* my scripted click on "Abandonner" raced the dialog teardown (agent-browser reported the button list of the main app instead); the verified END STATE is what matters and was confirmed: no `[role=dialog]` elements remain, form unmounted.
5. **API evidence (no mutation):** `GET /api/leads?pageSize=1&sort=createdAt&dir=desc` → `total: 43` (unchanged), newest lead is still the seed lead Réda Mokrani (`createdAt 2026-11-03T09:00:00.000Z`, i.e. seed data, not my draft).
6. `agent-browser errors` → empty.

**Expected vs observed:** localized property-type label in the drawer info band (raw vs displayed: `VILLA` → `Villa`), tier chip consistent with score (41 → Tiède), localized options in the create dialog — **all observed**. VLM cross-checks: `a6-v04-info.png` independently read "Type de bien: Villa", chip "Tiède", "41/100"; `a6-v04-create.png` independently listed the options Studio/F2/F3/F4/F5/Duplex/Villa/Terrain under "Type de bien".

**Screenshots:** `a6-v04-info.png`, `a6-v04-create.png`.
*Note:* `a6-v04-info.png` is byte-identical to `a6-v01-drawer.png` (same lead, same drawer state after all mutations were reverted, same viewport — the info band is fully visible without scrolling; `scrollIntoView` was a no-op, md5 `fbc30cdde33ba96488fc638ead09569d`). This is a legitimate re-capture of an identical state, disclosed here for transparency.

---

## Mutations made and confirmed reverted

| Mutation | Lead | Before | After (verified) | Reverted to (verified) |
|---|---|---|---|---|
| fullName (inline edit, V-01) | cmw0ly2y8007oqyk02d3p30o2 Karima Lounis | `Karima Lounis` | `QA P22 Vérif` (API GET) | `Karima Lounis` (API GET) |
| priority (dropdown, V-05) | cmw0ly2y8007oqyk02d3p30o2 Karima Lounis | `NORMAL` | `HIGH` (API GET) | `NORMAL` (API GET) |

**Final state audit (after all flows, server still up):**
- Karima Lounis: `fullName "Karima Lounis"`, `status CONTACTED`, `priority NORMAL`, `score 41`, `propertyType VILLA`, `oppCount 0` — **all original values restored**.
- Réda Mokrani (V-02 target): `status NEW`, `convertedAt null`, `oppCount 0` — untouched.
- Leads total: **43** (no lead created, none converted).

## Errors / console hygiene

- `agent-browser errors` was run after every flow (V-01 edit, V-01 revert, V-05 change, V-05 revert, V-02, V-03 dialog close, V-04, final audit) → **empty every time**.
- `agent-browser console` at the end → only React DevTools info banners, no warnings/errors.
- One eval-only JavaScript syntax/redeclare error occurred inside my own probe scripts (page-context `const` reuse) — an automation artifact, not an application error; corrected by re-running with IIFE-scoped evals.

## Screenshot index (05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/lead-management/p22/)

| File | Verification | Content |
|---|---|---|
| a6-v01-drawer.png | V-01 | Karima Lounis drawer, original name, 1440×900 |
| a6-v01-edited.png | V-01 | Header name "QA P22 Vérif" + "Enregistré" toast |
| a6-v01-reverted.png | V-01 | Name restored "Karima Lounis" |
| a6-v05-menu.png | V-05 | Priority dropdown: Basse/Normale/Haute/Urgente, check on Normale |
| a6-v05-changed.png | V-05 | Priority badge after selecting Haute |
| a6-v05-reverted.png | V-05 | Priority badge restored Normale |
| a6-v02-dialog.png | V-02 | "Confirmer la conversion" AlertDialog over Réda Mokrani drawer |
| a6-v03-desktop.png | V-03 | Youcef Amrani drawer 1440×900, header verb row (Tâche/Visite icons) |
| a6-v03-task-tab.png | V-03 | After Task verb click — Tâches tab selected |
| a6-v03-visit-dialog.png | V-03 | "Planifier une visite" dialog (Prospect Youcef Amrani) over open drawer |
| a6-v03-mobile.png | V-03 | 375×812 — mobile bottom action bar (WhatsApp/Journaliser/Tâche/Visite) |
| a6-v04-info.png | V-04 | Info band: "Type de bien: Villa", score 41/100 + chip "Tiède" |
| a6-v04-create.png | V-04 | Create dialog, "Type de bien" select open with localized options |

All 13 screenshots were captured by THIS run (timestamps 12:41–12:46) and overwrite the killed prior run's artifacts. Key screenshots were additionally cross-verified with an independent vision model (GLM) reading the exact French labels back — noted per verification above.

## Verdict table

| Verification | Verdict |
|---|---|
| V-01 Inline name editing persists | **PASS** |
| V-02 Convert requires explicit confirmation | **PASS** |
| V-03 Desktop drawer action parity | **PASS** |
| V-04 propertyType i18n + temperature tier chip | **PASS** |
| V-05 Priority dropdown persists | **PASS** |

**Cluster result: 5/5 PASS.** No defects found. No application source modified. All mutations reverted and API-verified.
