# ASAS CRM — Leads: Market Research & Product Intelligence Report

| | |
|---|---|
| **Task ID** | S1-A3 (Agent 3 — Real-Estate CRM Product Research & Technology Intelligence) |
| **Date** | 3 November 2026 |
| **Scope** | External research only: lead-management UX in modern real-estate/general CRMs (2024–2026), current interface patterns, follow-up-discipline features, and the Algerian lead-acquisition context. Actionable recommendations for **ASAS CRM** (Algerian real-estate agency CRM; FR/AR/EN trilingual; DZD; WhatsApp-first culture; Next.js + Prisma + SQLite; single `Lead` table). |
| **Companion docs** | Read together with the lead-management UX audit (S1-A1) and codebase findings (S1-A2). This document deliberately avoids deep code conclusions. |

---

## 0. Method & Source Integrity

- **Method:** every source below was **fetched and read in this session** via direct HTTP fetch (curl with browser UA) or headless-browser rendering (agent-browser). Verbatim quotes are taken from the loaded page text. No search-engine snippets are cited.
- **Blocked/inaccessible sources (transparency):**
  - `capterra.com/resources/crm-software-for-real-estate/` — Cloudflare hard block (curl + headless browser both rejected). *Not cited.*
  - `www.ouedkniss.com` — connection timeout from this environment (likely geo/IP filtering). Characterized via secondary sources instead (French Wikipedia; press references).
  - Search engines (Bing, DuckDuckGo, Google, Startpage) served degraded/bot-challenge responses from this datacenter IP — **no search-engine-derived claims are used**; all citations are from directly loaded pages.
  - nngroup.com — WAF-blocked during this session. Progressive-disclosure/form guidance is taken from HubSpot, Pipedrive, Atlassian and Salesforce primary sources instead. (A prior workspace research task `agent-ctx/2-d-1-external-research.md` did successfully load NN/g "Progressive Disclosure" and "Web Form Design" in an earlier session; its findings are consistent with what is cited here but are **not** re-cited as primary sources.)
- **Codebase anchors used only for fit-assessment vocabulary** (read-only glance, not an audit): `LEAD_STATUSES` (`src/lib/constants.ts`) = `NEW / CONTACTED / QUALIFIED / CONVERTED / CLOSED_LOST / REACTIVATED`; `Lead` table (`supabase/migrations/20261030000001_init.sql`) already carries `phone`, `phoneRaw`, `secondaryPhone`, `whatsapp`, `email`, `source`, `campaign`, `utmSource/utmMedium/utmCampaign`, `referrerName`, `ownerId`, `status`, `priority`, `score`, `budgetMin/budgetMax`, `propertyType`, `desiredLocation`, `lastContactAt`, `nextFollowUpAt`, `lostReason`, `lostAt`, `reactivatedAt`, `archived`, plus a `LeadTag` join table.
- **Effort scale:** S = ≤ ~1 day of focused work in this codebase; M = 2–5 days; L = > 5 days / architectural risk.

---

## 1. Lead Management UX in Leading CRMs (Research Task 1)

### 1.1 Follow Up Boss (followupboss.com) — the real-estate-native benchmark

**Sources:**
- Lead Distribution / Lead Routing — https://www.followupboss.com/features/lead-routing
- Smart Lists — https://www.followupboss.com/features/smart-list
- Team Inbox — https://www.followupboss.com/features/team-inbox
- Get Organized — https://www.followupboss.com/how-it-works/organize
- Daily Use for Agents — https://www.followupboss.com/daily-use
- Automations — https://www.followupboss.com/features/automations
- Deals — https://www.followupboss.com/features/deals
- Mobile Apps — https://www.followupboss.com/features/mobile-apps

**What FUB does (extracted patterns):**

1. **Lead routing with simple, explicit strategies.** "Set rules that automatically distribute leads to agents in the areas they serve and the price points they're suited to handle" — routing by *ZIP code or town*, *listing → listing agent*, *senior agents → high-priced leads*. Two distribution modes: **"First to claim"** ("Instantly alert your team about new leads at once, and give priority to agents who can help first") and **"Round robin"** ("distribute leads one by one, in a repeating cycle"). The page headline ties routing to the core metric: "Get every lead to the right person **and improve speed to lead**."
2. **Smart Lists = dynamic saved views with a work-through rhythm.** "No one has hours a day to manually sift through 1000s of leads in a CRM to figure out who to call next." Documented daily loop: *"Click on a smart list → Click on the first lead in the list → Make notes → Move on to the next lead in the list. Just hit the advance arrow to go to the next priority prospect."* Concrete recipe examples given by the vendor: a **"New Leads"** list (created < 7 days ago), a **"High Value"** list (budget band), **"sort by last communication date"**, "sort leads older than 3 months, and tag them to follow up with them less often", and *"Sort leads by 'calls fewer than three' to create a Smart List of leads that need a call."*
3. **Lead ponds (reactivation of inactive leads).** "Give agents the power to discover more deals by **assigning inactive leads to a lead pond**. Agents can prospect from pond leads freely; create multiple ponds for different leads."
4. **Team Inbox with an inbox-zero discipline for leads.** "Team Inbox is designed to help your team get to Inbox Zero. It gives you a clear overview of all open communication so you can immediately see which leads have been followed up with and which ones still need to be **delegated, deferred, done now or deleted**."
5. **Single timeline of every interaction.** "View calls, texts and emails on a single timeline." (Get Organized page.)
6. **Follow-up automations framed around the two failure modes.** Automations page: *"First, new leads come in and need immediate action. If nothing happens quickly, momentum disappears. Second, older leads sit in the database quietly until one of them suddenly shows signs of life again."* and — the sharpest articulation of the problem ASAS must solve — *"Follow-up depends too much on memory, manual checking, and luck."* Automations = trigger (new lead / re-activation signal) → next step (task, email, field update, notify teammate, reassign).
7. **Mobile-first agent reality.** "Because leads come in when your agents are out." — push notification the second a new lead arrives; @mention to re-assign follow-up; note-taking in spare minutes. A customer quote doubles as a product philosophy: *"It has just the right amount of features – no clutter."*
8. **Deal hygiene reporting.** Deals page: "Recognize if deals are getting stuck at a certain stage", "conversion rate by agent and lead source."

**Market data (from the same vendor's pricing, cross-checked in §1.3):** FUB Grow $58/user/month; Pro $416/user/month (10 users); Platform $833/user/month. FUB was acquired by Zillow in 2023 (per HubSpot's article, §1.3).

---

### 1.2 Zoho — Real Estate CRM edition + core Zoho CRM

**Sources:**
- Zoho Real Estate CRM (marketing page, fetched as the site's own `index.md`) — https://www.zoho.com/realestate/realestate-crm/
- Zoho CRM — Lead Management hub — https://www.zoho.com/crm/lead-management/
- Zoho CRM — Lead Capture — https://www.zoho.com/crm/lead-management/lead-generation.html

**Extracted patterns:**

1. **Lead centralization across channels with area-expert assignment.** "Centralize leads from listing services, social media, or webforms, and assign them to **area experts** so that every lead gets that personal touch."
2. **Hot/warm/cold segmentation as the primary follow-up axis.** "Segment your audience into hot, warm, and cold leads; automate follow-ups with tailored messages."
3. **Site-visit management is a first-class object** (matches ASAS's visit-centric model): "Organize site visits, assign agents, and gather **post-visit feedback**. Automate reminders."
4. **Inactive-deal surveillance + re-engagement.** "Spot inactive deals, **re-engage with them by sharing fresh property updates**, and move deals along faster."
5. **WhatsApp named explicitly in omnichannel.** "Centrally manage client communications via phone, email, or **WhatsApp**."
6. **Duplicate hygiene at entry.** "Prevent, remove, or merge duplicates when necessary… **Mark fields as unique and stop duplicate records as they enter the system**."
7. **Multi-source capture.** Webforms (shareable as links or **QR codes**), social-media capture, business-card scanner for field reps ("strike while the iron is hot"), email parser.
8. **Scoring exists but is optional/manual** ("Score leads manually or with AI") — in a lightweight tool the manual/hot-warm-cold tier is the applicable part.

---

### 1.3 HubSpot — real-estate CRM roundup + interface mechanics

**Sources:**
- "6 best CRMs for real estate businesses in 2026" — https://blog.hubspot.com/sales/real-estate-crm (HubSpot Staff; page shows "Updated: 08/04/26")
- HubSpot Knowledge Base — "Create and manage saved views" — https://knowledge.hubspot.com/records/create-and-manage-saved-views (Last updated October 19, 2026)
- HubSpot Knowledge Base — "Use progressive fields in forms (legacy)" — https://knowledge.hubspot.com/forms/use-progressive-fields-in-forms

**Extracted facts & patterns:**

1. **Speed-to-lead is the #1 listed real-estate use case.** "Portal leads create pressure for agents and teams to respond fast. **Leads contacted within five minutes are 21x more likely to convert.**"
2. **The long-cycle reality of real estate.** "Real estate sales cycles often require long-term follow-up across weeks or months. **A contact who inquires today may not be ready to transact for six to 18 months.** Realtors need to capture leads, log interactions, and nurture contacts until they are ready."
3. **Lead routing by geography/expertise is the named team feature.** "Real estate teams with multiple agents need lead routing that can route leads **by geography or expertise**."
4. **Source tracking is table stakes in real estate.** Generic vs real-estate CRM comparison: "Lead source tracking (Zillow, Realtor.com): Manual → **Automated**"; "Property interest and matching: Not available → **Built-in**."
5. **5 important features for a real-estate CRM (their list):** Mobile CRM with offline functionality; customizable deal pipelines per transaction type; deep MLS/portal integrations; automated email & SMS sequences; commission/transaction tracking. (For ASAS, only the first two are in-scope — see §7.)
6. **Viewing follow-ups.** "After a property showing, CRM sequences can automatically send thank-you messages, gather feedback, and schedule next-step calls."
7. **Saved views mechanics (KB):** "On an index page, you can view and filter records using **saved reusable views**… create custom ones with filters and **visibility settings for your view only or account-wide**." View types include **table and board** ("select a view type (e.g., board) in addition to table view"); column sets are editable per view (checkboxes, drag-to-reorder); sharing levels: Private / Team / Everyone / Custom.
8. **Progressive fields (progressive profiling).** "If the contact filling out your form **already has a value for a specific field**, you can use progressive fields to **set another field to appear in its place**" — i.e., never re-ask what you already know; surface the next unknown question instead. (Legacy feature in HubSpot, but the *pattern* is the transferable part.)
9. **Market snapshot from the same article** (useful for ASAS positioning): FUB Grow $58/user/mo; Property Matrix $150–550/mo; REsimpli $149–599/mo; monday.com CRM $9–19/user/mo; HubSpot free–$150/seat. "Only 21% of realtors use an AI-powered CRM" (NAR via HubSpot).

---

### 1.4 Pipedrive — the cleanest documented lead-detail UX

**Sources:**
- Pipeline Management — https://www.pipedrive.com/en/features/pipeline-management
- LeadBooster / lead generation — https://www.pipedrive.com/en/features/lead-generation-software
- **Leads Inbox (Knowledge Base, Jenny Takahara, last updated September 23, 2026)** — https://support.pipedrive.com/en/article/leads-inbox

**Extracted patterns (the KB article is the most precise public spec of a modern lead workspace):**

1. **Separation of unqualified leads from the deal pipeline.** "In the early stages of your lead generation process, it's common to have potential opportunities that aren't ready to move through your pipeline yet. Keeping these leads in your pipeline can create clutter… The **Leads Inbox** offers a dedicated space to store and organize your unqualified leads. When a lead is ready to move forward, you can convert it into a deal." (ASAS already mirrors this: `Lead` vs `Opportunity`.)
2. **The lead detail view is a side panel, not a page.** "Click on any lead to open a **panel** where you can view its details or update it." Left side = fields (lead details / person / organization); bottom-left = **Archive** and **Convert to deal** actions.
3. **A right-side "Composer" + Focus + History triptych.** "Composer – write notes, add activities, compose emails and upload files. **Focus – upcoming activities, pinned notes, email drafts**… **History – notes, completed activities, sent emails and uploaded files.**" (This is the cleanest industry articulation of *next-action visibility* + *timeline history* in one panel.)
4. **Minimal mandatory intake.** "A lead must always be linked to a person or organization in Pipedrive, but **all other fields are optional**."
5. **Hot/warm/cold labels + custom columns.** "Know where leads stand with 'hot', 'warm' and 'cold' labels" (LeadBooster page); KB: gear icon to customize visible columns; click any column header to sort.
6. **Custom filters + favorites = saved views.** "You can create custom filters… After creating a custom filter, **you can add it to your favorites by clicking on the star icon**… quickly access these filters by opening the favorites section." Bulk-editable fields enumerated (title, labels, value, owner, visibility, **source channel**, source channel ID).
7. **Conversion carries data over.** "Any person, organization, notes or files data from the lead **remain attached** when the lead is converted into a deal." Convert dialog asks pipeline/visibility/value once.
8. **Lifecycle safety nets.** Archive (out of active inbox, unarchive later); deleted leads restorable for **30 days**; **merge duplicates** from the detail panel (pick which record's unique data to keep, preview, confirm); @mentions in notes.
9. **Automatic assignment.** "Automatically assign new sales leads and prospects to a person or team… predefined rules that determine how your leads are distributed. **Save time, follow up faster and increase conversions.**" (LeadBooster page.)

---

### 1.5 Salesforce — enterprise reference points (applicable kernels only)

**Sources:**
- Trailhead, "Leads and Opportunities / Create and Convert Leads" unit — https://trailhead.salesforce.com/content/learn/modules/leads_opportunities_lightning_experience/create-and-convert-leads-lightning (loaded in headless browser)
- Salesforce product article "What Is Lead Management?" (Elyse Archer, August 1, 2025) — https://www.salesforce.com/products/sales-cloud/lead-management/
- *(Prior verified workspace research: `agent-ctx/2-d-1-external-research.md` — help.salesforce.com "Convert Qualified Leads" + Trailhead lead-qualification units, loaded in an earlier session.)*

**Extracted patterns:**

1. **Lead Intelligence View — the canonical "attention buckets."** Verbatim from Trailhead: aggregate metrics over the filtered lead list — **"Total leads… No activity: leads with no completed activities. Idle: leads with past activity, but no completed activities in the last 30 days. No upcoming: leads with recently completed activity but no future activities scheduled. Overdue: leads with activities that are overdue. Due today: leads with activities due today. Upcoming: leads with activities due in the next 30 days."** Plus: "click the **side panel icon** next to the record name" for individual detail — side-panel detail from the list, same as Pipedrive.
2. **Lead record anatomy.** Activity tab (log calls/emails/notes; create Tasks/Events), Details tab (review/quick-update), Chatter (team collaboration), Related (campaigns/files).
3. **Status vocabulary is qualification-progress.** Standard statuses: Open–Not Contacted / Working–Contacted / Closed–Converted / Closed–Not Converted. (ASAS `NEW → CONTACTED → QUALIFIED → CONVERTED / CLOSED_LOST (+ REACTIVATED)` is the same shape.)
4. **Assignment model.** "Some companies assign leads automatically, based on criteria like geographical location or sales territory. Other companies assign all new leads to a **queue**." (Trailhead.)
5. **Lead-management stage model** (product article): **capture → qualification → distribution → nurturing → tracking**; "the first five minutes of prospect contact are make-or-break" (HBR via Salesforce); "when people feel understood, the likelihood they'll make a purchase increases by 40%" (McKinsey via Salesforce).
6. **Intake channels incl. trade-show capture.** Hands-on scenario: rep meets a prospect at a trade show, adds her as a lead **from the mobile app** to follow up after. (Walk-in equivalent.)

---

## 2. Modern CRM Interface Patterns, 2024–2026 (Research Task 2)

### 2.1 Contextual side drawers (record panel over a page, not a page navigation)

- **Pipedrive:** lead detail opens **in a panel** from the Leads Inbox list ("Click on any lead to open a panel"), keeping list context.
- **Salesforce Trailhead:** Lead Intelligence View uses a "side panel icon next to the record name" to open detailed activity for individual records.
- **Atlassian Design System — Drawer component** (https://atlassian.design/components/drawer, loaded in headless browser): "A drawer is a panel that slides in from the left side of the screen." (Atlassian is deprecating their own Drawer in favor of Modal for their app's needs — but every CRM studied here uses the side-panel pattern; the pattern itself is standard for record-inspection-with-context.)
- **ASAS fit:** already implemented (`lead-detail-drawer.tsx`). Research verdict: pattern is correct and current; invest in *content* (Focus/next-action + History/timeline sections) rather than the container.

### 2.2 Customer-360 / record-page composition

- **Salesforce:** lead record = Activity / Details / Chatter / Related tabs; opportunity carries the richer deal data (expected revenue, stage, close date, probability) — lead stays thin (Trailhead; prior 2-d-1 research).
- **Pipedrive:** panel left = structured fields; right = Composer/Focus/History.
- **Attio** (https://attio.com/help/reference/managing-your-data/views + academy "Views" https://attio.com/help/academy/introduction/views): record pages, table + kanban views, notes/tasks/email in one workspace.
- **Transferable rule for ASAS:** a lead's 360 = identity (name/phones/whatsapp/email) + source & campaign + requirement (budget/type/location) + owner + status/priority + **next action** + **timeline** + linked visits/opportunities/documents (already mostly present as tabs in the drawer).

### 2.3 Timeline-based activity history

- **FUB:** "View calls, texts and emails on a **single timeline**."
- **Pipedrive:** "History – This section displays notes, completed activities, sent emails and uploaded files."
- **Salesforce:** Activity tab logs calls, emails, notes; tasks/events planned for the future.
- **ASAS fit:** `lead-tab-activities.tsx` exists; the pattern consensus is: **one merged chronological stream** (contacts + status changes + notes + visits), newest-first, with actor + relative time.

### 2.4 Next-action visibility (the "Focus" pattern)

- **Pipedrive Focus section:** "upcoming activities, pinned notes, email drafts… You can also schedule an activity directly from the focus section."
- **Salesforce Intelligence View buckets:** No upcoming / Overdue / Due today / Upcoming.
- **FUB Smart Lists workflow:** the saved list *is* the next-action queue ("who to call next").
- **ASAS fit:** the `nextFollowUpAt` column already exists on `Lead` — research strongly supports surfacing it as a **status chip per row** (à la Salesforce buckets) and a drawer Focus block.

### 2.5 Progressive / stepped lead forms

- **HubSpot progressive fields:** don't re-ask known values; replace with the next unknown field.
- **Pipedrive intake minimalism:** "A lead must always be linked to a person or organization… **all other fields are optional**."
- **Salesforce trade-show capture:** name + phone from mobile app, everything else later.
- **ASAS fit:** quick-create = name + phone + source (+ optional note). Budget/propertyType/desiredLocation are *deferred qualification fields*, asked in the drawer (inline) after first contact — exactly the progressive pattern.

### 2.6 Inline editing

- **Atlassian Design System — Inline edit** (https://atlassian.design/components/inline-edit, loaded in headless browser): "An inline edit displays a custom input component that **switches between reading and editing on the same page**… starts in a read-only view called readView and people can activate the field to edit it."
- **Pipedrive:** "The Details tab lets you review, find, and **quickly update** lead information" (Trailhead, Salesforce wording; Pipedrive equivalent is field-level edit in the panel).
- **ASAS fit:** drawer fields editable in place (click-to-edit), with optimistic update + toast — avoids modal-on-modal for small corrections.

### 2.7 Saved views / smart filters

- **FUB Smart Lists:** dynamic segment lists, one-click access, advance-arrow work-through.
- **HubSpot saved views:** reusable filtered views; private/team/everyone sharing; board or table types.
- **Pipedrive:** custom filters + star favorites; export filtered results.
- **Attio "Filter and sort views"** (https://attio.com/help/reference/managing-your-data/views/filter-and-sort-views): "Saving these settings per view allows you to quickly surface different segments"; **"filter by Current user"** for Owner/Assignee attributes — "This makes views reusable across your team, so each member sees records or entries relevant to them **without needing separate views**." Also: "If you find yourself applying the same filters regularly, consider keeping a dedicated view just for that subset."
- **ASAS fit:** persisted saved searches exist (`saved-searches.tsx`); the researched differentiators worth adopting: (a) **"My leads" current-user semantics**, (b) **relative-date conditions** (Attio ships relative date filtering — e.g. created < 7 days, no contact > 30 days), (c) a small set of **shared default views** defined once for the whole team (HubSpot's "default views" + FUB's pre-built lists).

### 2.8 Quick actions

- **FUB:** advance-arrow to the next lead in a smart list; one-click WhatsApp/text/call from row (mobile page: "Tap to call your best leads").
- **Pipedrive:** composer directly in the panel (note/activity/email/file in one place); bulk edit + group email from list.
- **Salesforce Lightning console "Work Queue"**: "view, prioritize, and manage your tasks, leads, opportunities, or other actionable items based on predefined cadences" (Trailhead).
- **ASAS fit:** row-level WhatsApp button already exists (R9-4); extend the set with tap-to-call (`tel:` link) and "log a quick note" popover — all zero-backend-cost quick actions.

### 2.9 Mobile-first CRM patterns

- **FUB mobile:** "Because leads come in when your agents are out" — push alert on new lead, @mention re-assignment, in-app note-taking; "just the right amount of features – no clutter."
- **HubSpot 5-feature list:** "Mobile CRM Access With Offline Functionality" is feature #1 for real estate.
- **Algeria context (§4):** 116% mobile penetration, median age 28.6 — mobile IS the primary device.
- **ASAS fit:** mobile = leads list (cards, not table) + drawer + quick actions; already partially built. Keep it lean (FUB's "no clutter" is the design law).

### 2.10 Kanban vs list for lead management

- **Pipedrive:** kanban-style pipeline ("visualize every stage of the buyer journey", drag between stages) for **deals**; leads live in a **list inbox** with labels.
- **HubSpot saved views:** "select a view type (e.g., board) in addition to table view" — both available per object.
- **Attio academy:** "Build table and kanban views to organize your data your way."
- **monday.com (via HubSpot roundup):** "kanban boards, timeline views, and color-coded statuses."
- **Consensus:** lists (with filters/sort/labels) are the working surface for lead qualification; kanban is the visualization for stage progression of deals. ASAS already has a pipeline kanban for opportunities — the researched position is: **do not duplicate a lead kanban** (leads ≠ stages of a deal); a *grouped list* (by status) covers the "board feel" if ever needed.

---

## 3. Speed-to-Lead, Lead Rotting & Follow-Up Discipline (Research Task 3)

**Primary sources:**
- Chili Piper — "What Is Lead Response Time and How It Wins You More Deals" (Kris Rivera, August 1, 2025) — https://www.chilipiper.com/article/speed-to-lead-statistics
- HubSpot real-estate roundup (§1.3) — the 21x claim in a real-estate context.
- Salesforce "What Is Lead Management?" (§1.5) — "the first five minutes of prospect contact are make-or-break" (HBR reference).
- Follow Up Boss Automations page (§1.1) — the two failure modes.
- Salesforce Trailhead Lead Intelligence View (§1.5) — Idle/Overdue/Due-today buckets.
- Zoho Real Estate CRM (§1.2) — inactive-deal re-engagement.
- FUB Lead Ponds (§1.1) — inactive lead reactivation structure.

### 3.1 The numbers (as stated by each source)

| Stat | Source wording | Citation |
|---|---|---|
| 21x qualify odds | "you are **21 times more likely to qualify your lead** with a quick lead response time than if you wait for more than 30 minutes" | Chili Piper, 2025 |
| 21x convert (real estate) | "Leads contacted within **five minutes are 21x more likely to convert**" | HubSpot blog (real-estate roundup) |
| 100x connect/convert | "businesses that respond to leads in **5 minutes or less are 100x more likely to connect and convert opportunities**" | Chili Piper, 2025 |
| 391% first-minute | "Following up with your lead in the **first minute** can lead to a **391% increase in conversions**" | Chili Piper, 2025 |
| The sad baseline | "On average, it takes B2B sales teams **42 hours** to respond to a new lead, and **38% of those leads never reply**" | Chili Piper, 2025 |
| Five-minute window | "the first five minutes of prospect contact are make-or-break for hooking leads" | Salesforce (citing HBR) |

*(These vendor-quoted figures trace to lead-response studies popularized in the late 2000s; the exact multipliers vary by source. The direction — faster is dramatically better — is unanimous across every source. For a design decision, the safe, well-supported operational targets are: **respond to every new lead the same working day; treat >24h as a failure; show the age of every uncontacted lead.**)*

### 3.2 Lead rotting / negative-lead indicators

- **Salesforce Intelligence View "Idle" bucket:** "leads with past activity, but no completed activities in the **last 30 days**" — a concrete, citable definition of a rotten/idle lead.
- **FUB:** "older leads sit in the database quietly until one of them suddenly shows signs of life again… **Follow-up depends too much on memory, manual checking, and luck**."
- **Zoho:** "Spot inactive deals, re-engage with them by sharing fresh property updates."
- **FUB Smart Lists recipe:** "Sort leads older than 3 months, and tag them to follow up with them less often" — i.e., aging changes cadence, not existence.
- **Design translation for a lightweight CRM:** a computed **days-since-last-contact** signal on every open lead (from `lastContactAt`), surfaced as a chip/badge and usable in filters ("no contact > 14/30 days"), plus a dashboard attention queue. No scoring engine required.

### 3.3 Follow-up reminders & reactivation

- **Pipedrive Focus:** upcoming activities pinned in the lead panel; **Salesforce buckets:** Overdue / Due today / Upcoming (30 days).
- **FUB lead ponds:** inactive leads pooled for agents to re-prospect voluntarily.
- **FUB automations:** re-engagement trigger when an old lead "shows signs of life."
- **ASAS anchor:** `nextFollowUpAt` + `lastContactAt` + `REACTIVATED` status + `reactivatedAt` already exist in the schema — the research validates completing the loop: overdue-next-follow-up queue + reactivation event surfacing.

---

## 4. Algerian Context (Research Task 4)

### 4.1 The platform reality (DataReportal — Digital 2025: Algeria)

**Source:** https://datareportal.com/reports/digital-2025-algeria (DataReportal/Meltwater/We Are Social, data for January 2025)

- Population 47.1M; **median age 28.6**; 76% urban.
- **54.8M cellular mobile connections = 116% of population**; 91.4% of connections on 3G/4G/5G. (Mobile-first is not a nice-to-have; it is the default.)
- 36.2M internet users (76.9%).
- 25.6M social-media identities (54.2% of population).
- **Facebook: 25.6M users in Algeria** — equal to the entire counted social-media population; Facebook is *the* platform (for comparison: YouTube 21.1M, TikTok 21.1M (18+), **Messenger 15.8M**, **Instagram 12.0M**, LinkedIn 4.8M).
- WhatsApp-specific reach figures are not published by Meta for Algeria in this report; combined with the task brief's field reality (WhatsApp-first communication culture) and Messenger's 15.8M reach (Meta messaging family), the practical conclusion stands: **the messaging plane (WhatsApp/Messenger) is where Algerian customers live; email is a secondary channel**.

### 4.2 Ouedkniss — the classifieds monolith

**Source:** https://fr.wikipedia.org/wiki/Ouedkniss (accessed this session; original reporting referenced: Le Soir d'Algérie, Wamda, Algerie Eco)

- "Ouedkniss est un site web de **petites annonces** basé en Algérie. **Fondé en 2006**… offrant un large éventail de produits et des services allant des voitures et des motos aux appareils électroniques et aux offres d'emploi. **C'est l'un des sites les plus visités en Algérie.**"
- Referenced press headline (Le Soir d'Algérie, via Wikipedia): "En Algérie, **Ouedkniss est plus visité que Facebook**."
- Founded by five high-schoolers after the closure of the rue Oued Kniss market in Algiers; Djezzy partnership in 2022 (Algerie Eco).
- `www.ouedkniss.com` itself was unreachable from this research environment (connection timeout — likely geo/IP filtering); no public API is known or documented. **Implication: Ouedkniss must be a first-class *source label* + paste-assisted manual capture, never an "integration".**

### 4.3 Phone numbers (Wikipedia — Telephone numbers in Algeria)

**Source:** https://en.wikipedia.org/wiki/Telephone_numbers_in_Algeria

- Country code **+213**; closed numbering plan.
- **Mobile: `0yxx xx xx xx` (9 digits after the trunk 0)** where y = operator: **5 Ooredoo, 6 Mobilis, 7 Djezzy**; international form **`+213 yxx xxx xxx`** (drop the leading 0).
- Landline: `0yy xx xx xx` (8 digits) with 2-digit area codes (21 = Algiers, 25 = Blida, 31 = Oran…).
- This confirms the canonical storage/display rule the codebase already implements (e.g., `0771 12 35 23` ⇄ `+213771123523`): **store E.164 (`+213…`), display local `0…` grouping, and the operator digit is a free signal for display (Djezzy/Mobilis/Ooredoo) and for input validation (mobile = 9 digits, starts 5/6/7; landline = 8 digits after 0 + valid area code).**

### 4.4 WhatsApp deep links — the officially supported lightweight integration

**Source:** WhatsApp Help Center — "How to use click to chat" — https://faq.whatsapp.com/5913398998672934/?locale=en_US (loaded in headless browser)

- "Use `https://wa.me/<number>` where the `<number>` is a **full phone number in international format**. Omit any zeroes, brackets, or dashes…"
- "Use `https://wa.me/whatsappphonenumber?text=urlencodedtext`… The pre-filled message will automatically appear in the text field of a chat."
- "Click to chat works on both your phone **and WhatsApp Web**."
- **ASAS fit:** the codebase already ships wa.me deep links with prefilled trilingual templates + activity logging (workspace R9-4). This is the correct, honest ceiling of "WhatsApp integration" for a local lightweight CRM: **no WhatsApp Business API, no automation claims** — just reliable deep links + logged follow-ups.

### 4.5 Source-tracking structure that fits Algerian acquisition

Combining §4.1–4.4 with the source-tracking patterns from §1 (FUB's 250+ source integrations; HubSpot's "Lead source tracking: Manual → Automated"; Pipedrive's `Source channel` bulk-editable field; Zoho's multi-source capture):

**Recommended source taxonomy (enum, DZ-real):**

| Source value | Meaning | Notes |
|---|---|---|
| `OUEDKNISS` | Classifieds listing/inquiry | The dominant property listing channel |
| `FACEBOOK` | FB page/Marketplace/DM | 25.6M users; DMs convert to phone/WhatsApp |
| `INSTAGRAM` | IG post/DM/reel inquiry | 12M users |
| `WHATSAPP` | Direct WhatsApp inbound | The default messaging plane |
| `PHONE` | Inbound call | Classic |
| `WALK_IN` | Agency walk-in | Field reality of Algerian agencies (cf. Salesforce trade-show capture) |
| `REFERRAL` | Word of mouth | Keep `referrerName` free-text alongside |
| `SIGNAGE` | Billboard/panel on a project site | Optional, if the agency uses boards |
| `OTHER` | Fallback | + free-text `campaign`/detail |

Plus a free-text **detail/campaign** field (listing reference, ad name, which Ouedkniss ad, etc.) — mirroring Pipedrive's "Source channel + Source channel ID" pairing without any UTM machinery (the `utm*` columns can stay unused for manual channels).

---

## 5. Cross-Cutting Findings — What the Best-in-Class Agree On

1. **A lead is a thin record that graduates.** Name + phone + source is enough at intake (Pipedrive, Salesforce); richer fields belong to qualification/deal stages. ASAS's Lead vs Opportunity split matches Salesforce/Pipedrive orthodoxy.
2. **Next-action visibility is the product.** Every vendor expresses it differently (Focus section / Intelligence buckets / Smart Lists) but all make "what do I do next, for whom, how late is it" the home-screen question.
3. **Speed-to-lead is measured, not assumed.** Age-of-lead and time-to-first-contact are surfaced; FUB literally headlines routing with "improve speed to lead."
4. **Rot is a first-class state.** Idle > N days, no upcoming activity, overdue — computed, visible, filterable.
5. **Saved views are the team's muscle memory.** Shared defaults + personal favorites + "current user" semantics (Attio) keep a small team fast without admin overhead.
6. **WhatsApp is a named channel in mainstream CRMs now** (Zoho) — but the honest lightweight implementation is deep links + logged activities, not API automation.
7. **Lightweight is a position, not a compromise.** FUB's own customer quote — "It has just the right amount of features – no clutter" — is the market's praise-language for exactly what ASAS should be.

---

## 6. ASAS Fit Assessment Summary (constraint reminder)

- **Stack:** Next.js + Prisma + SQLite, single `Lead` table + `LeadTag`, activities, opportunities, visits, tasks already exist as related models. All recommendations below assume **no new infrastructure**, no external services, computed signals from existing columns (`createdAt`, `lastContactAt`, `nextFollowUpAt`, `status`, `priority`, `source`, `ownerId`, `archived`).
- **Trilingual FR/AR/EN + RTL:** any new label/chip/queue must ship in the i18n domains from day one.
- **DZD + Algerian phone format:** §4.3 rules apply to all phone UX.
- **Hard constraints honored:** no WhatsApp API/telephony/AI-scoring recommendations; deep links only. No ERP, no campaign attribution, no drip email automation.

---

## 7. Recommendations Catalog

Legend — **Class:** CORE (build/complete) / OPTIONAL (nice, bounded) / NOT RECOMMENDED (explicitly out). Effort: S/M/L as defined in §0.

### 7.1 CORE

| # | Recommendation | Source(s) | What it is | Why it matters | Effort |
|---|---|---|---|---|---|
| C1 | **Source taxonomy enum (DZ channels) + free-text detail** — `OUEDKNISS / FACEBOOK / INSTAGRAM / WHATSAPP / PHONE / WALK_IN / REFERRAL / SIGNAGE / OTHER`, with `referrerName`/campaign detail preserved; rendered as colored source chips in FR/AR/EN | HubSpot (source tracking "Manual → Automated"); Pipedrive (Source channel field); DataReportal §4.1; Wikipedia Ouedkniss §4.2 | Fixed enum on `Lead.source` + optional detail text | Source-level conversion analytics (FUB: "conversion rate by agent and lead source") is only possible if sources are typed, not free-typed; DZ-specific values make reporting mirror reality | **S** |
| C2 | **New-lead speed-to-lead attention** — computed chip on every uncontacted lead (`status = NEW` and no contact activity): "Xh" age since `createdAt`; attention queue "Nouveaux non contactés > 4h" (threshold configurable); badge escalates color with age | Chili Piper (42h baseline, 21x/100x); HubSpot (5-min/21x real-estate); FUB routing page ("improve speed to lead"); Salesforce ("first five minutes… make-or-break") | List chip + dashboard queue from existing columns | The single highest-leverage discipline feature; requires zero new data | **S** |
| C3 | **Lead rotting / Idle indicator** — "days since last contact" chip for open leads (from `lastContactAt`); "Idle > 14 j / > 30 j" escalation; filterable; feed an "Idle leads" default view | Salesforce Trailhead (Idle definition: no completed activities in last 30 days); FUB Automations ("older leads sit in the database quietly"); Zoho (spot inactive deals) | Computed, filterable staleness signal | Converts "memory, manual checking and luck" (FUB) into a visible queue | **S** |
| C4 | **Next-action discipline (Focus pattern)** — surface `nextFollowUpAt` as a per-row chip with Salesforce-style buckets: **Overdue / Due today / Upcoming / No upcoming**; drawer "Prochaine action" block with one-click "planifier/modifier"; completing a contact activity prompts "planifier la prochaine relance ?" | Pipedrive KB (Focus section); Salesforce Intelligence View buckets; FUB Smart Lists ("who to call next") | Field exists; add surfacing + prompt loop | "No upcoming" is the quiet leak in every CRM; the post-contact prompt builds the habit | **S/M** |
| C5 | **Saved views upgrade** — (a) shared default views ("Nouveaux cette semaine", "À relancer aujourd'hui", "Idle > 30 j", "Mes leads"); (b) "Current user / Mes leads" dynamic owner filter (Attio pattern); (c) relative-date filter conditions; (d) star/favorite quick access | Attio (current-user filter, "same filters regularly → dedicated view"); HubSpot KB (saved reusable views, default + shared visibility); FUB Smart Lists; Pipedrive (filter favorites) | Extend existing saved-searches | The team's daily entry point; Attio's current-user trick gives per-agent personalization with ONE shared view | **M** |
| C6 | **WhatsApp-first quick actions (complete the set)** — keep wa.me prefilled trilingual templates; add templates that interpolate the lead's actual interest (property type/location/budget) from Lead fields; add `tel:` tap-to-call button beside it; ensure deep links on mobile cards | WhatsApp FAQ §4.4 (wa.me + ?text=, phone & Web); Zoho (WhatsApp named channel); FUB mobile ("tap to call") | Already 70% built (R9-4) | Matching the DZ communication reality with zero backend | **S** |
| C7 | **Algerian phone UX rules** — validate/normalize to E.164 `+213…`; display `0…` grouped (`05 51 23 45 67` style); operator hint (5 Ooredoo / 6 Mobilis / 7 Djezzy) on input; accept both `0…` and `+213…` paste; never require `+` | Wikipedia §4.3 | Input validation + display affordance | Wrong phone formats break wa.me links and duplicates detection; local display matches how agents read numbers | **S** |
| C8 | **Quick-capture progressive lead form** — create-lead dialog requires only **name + phone + source**; qualification fields (budget, propertyType, desiredLocation) deferred to inline drawer editing after first contact; optional one-line note at capture | Pipedrive KB ("all other fields are optional"); Salesforce trade-show mobile capture; HubSpot progressive fields (don't ask what you know; ask the next thing) | Reduce intake friction | Faster capture = more leads actually recorded from phone/WA/walk-in moments | **S** |
| C9 | **Timeline activity history (unified, chronological)** — one merged stream in the drawer: notes, WhatsApp logs, calls, visits, status changes, reactivations — newest first, actor + relative time; status-change entries auto-generated | FUB ("calls, texts and emails on a single timeline"); Pipedrive (History section); Salesforce (Activity tab) | Consolidate existing tabs' data into one stream | The 360-view pattern every vendor converges on; most data already exists | **M** |
| C10 | **Hot/warm/cold tier (manual, no scoring engine)** — replace/overlay numeric `score` with a 3-tier label (the market's vocabulary); priority field already exists — align it to HOT/WARM/COLD semantics; quick set from row & drawer | Zoho RE ("segment into hot, warm and cold leads"); Pipedrive (hot/warm/cold labels); FUB smart-list recipes ("High Value" list) | A 3-value enum, manually settable + bulk-settable | Deterministic, explainable, trilingual-friendly; no AI (per constraints) | **S** |
| C11 | **Attention-strip lead queues on dashboard** — an "inbox-zero for leads" panel: [Nouveaux à contacter] [Relances en retard] [Idle] with counts, click-through to the corresponding saved view; clear "done today" progress affordance | FUB Team Inbox ("Inbox Zero… delegated, deferred, done now or deleted"); FUB Smart Lists workflow; Salesforce Intelligence View aggregate stats | Dashboard widget over computed queues | Turns discipline features into a daily ritual with one obvious entry point | **M** |
| C12 | **Duplicate guard on phone** — on create/import, warn when an open lead with same normalized phone exists (link/merge); "merge duplicates" flow à la Pipedrive (pick survivor, preview, confirm, activities re-parented) | Zoho ("prevent, remove, or merge duplicates; mark fields as unique"); Pipedrive KB (Merge duplicates in panel) | Query + merge dialog | Phone is the de-facto identity in DZ lead flow; duplicates silently destroy follow-up history | **M** |

### 7.2 OPTIONAL (bounded, valuable, not urgent)

| # | Recommendation | Source(s) | What / Why | Effort |
|---|---|---|---|---|
| O1 | **Lead claim / round-robin-lite assignment** — auto-assign new leads to SALES_AGENTs round-robin (or leave unassigned + "claim" button); admin-configurable; keep it dumb-simple | FUB routing ("first to claim", "round robin"); Pipedrive ("automatic assignment… predefined rules"); Salesforce (assignment by geography or queue) | Only pays off with ≥3 follow-up reps; ASAS's small team may prefer manual + claim | **M** |
| O2 | **Lead pond / unassigned pool browsing** — a default view of unowned/archived-ish inactive leads that any agent can pick up and claim | FUB lead ponds ("agents prospect from pond leads freely") | Cheap reactivation structure once O1 exists | **S** |
| O3 | **Reactivation loop polish** — when an idle lead gets a new inbound contact (new activity after > 30 days), auto-flag `REACTIVATED` and drop it back into the attention queue with a "signs of life" toast | FUB Automations ("older leads… suddenly show signs of life"); Zoho (re-engage with fresh property updates); fields already exist (`REACTIVATED`, `reactivatedAt`) | Makes an existing status meaningful rather than decorative | **S** |
| O4 | **Archive + restore semantics for leads** — `archived` flag exists; give it a "Archivés" default view + unarchive (Pipedrive: archived leads out of active inbox, restorable; deleted restorable 30 days) | Pipedrive KB | Keeps the active list clean without data loss | **S** |
| O5 | **Bulk quick actions completion** — bulk status change, bulk owner reassign, bulk tier set, bulk WhatsApp-template send (manual deep link per lead, not automation) | Pipedrive KB (bulk edit fields enumerated) | Speed for morning-queue triage | **S/M** |
| O6 | **Column customization + sort persistence on the leads table** — gear-icon column picker, click-header sort, persisted per user | Pipedrive KB; HubSpot KB (edit columns, drag reorder) | Agents have different priorities (source vs tier vs next action) | **M** |
| O7 | **Relative-date filter conditions** — "created < 7 j", "last contact > 30 j", "next follow-up ≤ today" | Attio (relative date filtering); FUB recipes ("leads older than 3 months") | The vocabulary every researched recipe uses | **S/M** |
| O8 | **Post-visit feedback quick-log on the lead** — after a COMPLETED visit, prompt "feedback?" one-tap (interested / not / needs X) writing a note + optional next-follow-up | Zoho RE ("gather post-visit feedback"); HubSpot ("after a showing… gather feedback, schedule next-step calls") | Closes the loop where real-estate leads actually convert (visits) | **S** |
| O9 | **Mobile "new lead" bottom action** — persistent FAB on mobile leads view (name+phone+source only), since walk-in/phone capture happens standing up | Salesforce trade-show capture; FUB mobile philosophy | Capture where it happens | **S** |

### 7.3 NOT RECOMMENDED (explicitly out — with reasons)

| # | Anti-recommendation | Why not (grounded in research + constraints) |
|---|---|---|
| N1 | **WhatsApp Business API / messaging automation / chatbots** | Requires Meta business verification, per-conversation pricing, template approval and ongoing infra — wrong weight class for a local SQLite CRM, and the official lightweight mechanism (wa.me deep links, §4.4) already covers the real workflow. Zoho's "omnichannel WhatsApp" is an enterprise suite feature, not a pattern to copy.
| N2 | **AI lead scoring / negative scoring / predictive prioritization** | Constraint-excluded; also against market evidence for this segment — HubSpot notes only 21% of realtors use AI CRMs; the effective lightweight equivalents are manual hot/warm/cold (Zoho/Pipedrive) and rule-based queues (Salesforce buckets). Deterministic, explainable, trilingual.
| N3 | **Drip email automation / campaign attribution engine / marketing sequences** | Email is a secondary channel in Algeria (§4.1 — the messaging plane dominates); attribution belongs to enterprise stacks. The honest local version is: WhatsApp deep-link templates triggered manually by an agent (C6) + source chip (C1) for reporting.
| N4 | **MLS/portal integrations (Zillow/Realtor.com-style) or Ouedkniss API** | No Algerian MLS exists; Ouedkniss has no public API and is unreachable from datacenter IPs (§4.2). Capterra/HubSpot list MLS integration as a US-market feature. The DZ-correct move is source labels + paste-assisted capture.
| N5 | **Telephony/power dialer/call recording** | Infra-heavy (numbers, SIP, consent); FUB's calling suite is bundled with their $58+/user platform economics. `tel:` deep links + manual call logging (C6/C9) are the lightweight ceiling.
| N6 | **Lead-activity website pixel / behavioral tracking** | FUB Pixel needs your own website + script infra; ASAS leads arrive on third-party surfaces (Ouedkniss/FB/IG). No surface to instrument honestly.
| N7 | **A second kanban board for leads** | Research consensus (§2.10): lists for qualification, kanban for deal stages. ASAS already has the pipeline kanban for opportunities — duplicating one for leads adds clutter against FUB's praised "no clutter" law. A grouped-by-status list view (O6) gives the same glanceability if ever needed.
| N8 | **Lead↔opportunity field duplication (budget/stage on both)** | Salesforce's division of labor (Trailhead, prior 2-d-1): expected value/stage/close-date live on the *opportunity*; keep Lead thin (C8). Avoids drift between two records for one deal reality.

---

## 8. Suggested Sequencing (if product accepts the CORE set)

1. **Wave 1 (pure compute, no schema change):** C2 + C3 + C4 (chips/queues from existing columns) + C7 (phone UX) — the attention system comes alive.
2. **Wave 2 (small schema/enum alignment):** C1 (source enum) + C10 (tier) + C8 (progressive intake) + C6 completion.
3. **Wave 3 (UX depth):** C5 (saved views upgrade) + C9 (unified timeline) + C11 (dashboard queues) + C12 (dedupe/merge).
4. **Later/when team grows:** O1/O2 (routing/ponds), then the rest of OPTIONAL opportunistically.

Rationale: waves 1–2 deliver the market's #1 differentiators (speed-to-lead + rot + next-action) with near-zero risk; the heavier UI work follows once the semantics are stable.

---

## 9. Source Register (all URLs actually loaded & read this session)

| # | Source | URL | Loaded via | Key extractions |
|---|---|---|---|---|
| 1 | Zoho Real Estate CRM (page markdown) | https://www.zoho.com/realestate/realestate-crm/ (index.md) | curl | Area-expert assignment; hot/warm/cold; site visits + feedback; inactive deals; WhatsApp channel; docs |
| 2 | Zoho CRM Lead Management hub | https://www.zoho.com/crm/lead-management/ | curl (index.md) | Duplicate prevention/merge; cadences; omnichannel |
| 3 | Zoho CRM Lead Capture | https://www.zoho.com/crm/lead-management/lead-generation.html | curl | Webforms/QR, card scanner, email parser |
| 4 | HubSpot blog — 6 best CRMs for real estate (2026) | https://blog.hubspot.com/sales/real-estate-crm | curl | 21x/5-min; 6–18-month cycles; routing by geography; FUB profile/pricing; 5 features; saved-views roundup |
| 5 | Follow Up Boss — Lead Routing | https://www.followupboss.com/features/lead-routing | curl | First-to-claim/round-robin; ZIP/town routing; lead ponds |
| 6 | Follow Up Boss — Smart Lists | https://www.followupboss.com/features/smart-list | curl | Dynamic saved lists; work-through rhythm; recipes |
| 7 | Follow Up Boss — Team Inbox | https://www.followupboss.com/features/team-inbox | curl | Inbox zero; delegate/defer/do/delete |
| 8 | Follow Up Boss — Get Organized | https://www.followupboss.com/how-it-works/organize | curl | Single timeline; pixel (not recommended) |
| 9 | Follow Up Boss — Daily Use | https://www.followupboss.com/daily-use | curl | 4-step daily agent workflow |
| 10 | Follow Up Boss — Automations | https://www.followupboss.com/features/automations | curl | Two failure modes; "memory, manual checking, luck" |
| 11 | Follow Up Boss — Deals | https://www.followupboss.com/features/deals | curl | Stuck deals; conversion by source/agent |
| 12 | Follow Up Boss — Mobile Apps | https://www.followupboss.com/features/mobile-apps | curl | Push on new lead; "no clutter" |
| 13 | Pipedrive — Pipeline Management | https://www.pipedrive.com/en/features/pipeline-management | curl | Visual pipeline; next steps per stage |
| 14 | Pipedrive — LeadBooster/lead gen | https://www.pipedrive.com/en/features/lead-generation-software | curl | Leads Inbox; hot/warm/cold labels; automatic assignment |
| 15 | Pipedrive KB — Leads Inbox | https://support.pipedrive.com/en/article/leads-inbox | curl | Panel detail view; Composer/Focus/History; filters+favorites; merge; archive/restore; convert carry-over |
| 16 | Salesforce Trailhead — Create & Convert Leads | https://trailhead.salesforce.com/content/learn/modules/leads_opportunities_lightning_experience/create-and-convert-leads-lightning | headless browser | Intelligence View buckets (Idle/Overdue/Due today/No upcoming); record tabs; statuses; assignment; trade-show capture |
| 17 | Salesforce — What Is Lead Management? | https://www.salesforce.com/products/sales-cloud/lead-management/ | curl | Stages capture→qualification→distribution→nurturing→tracking; 5-minute/HBR; 40% McKinsey |
| 18 | HubSpot KB — Create and manage saved views | https://knowledge.hubspot.com/records/create-and-manage-saved-views | curl | Reusable views; sharing; board/table; column editing |
| 19 | HubSpot KB — Progressive fields in forms | https://knowledge.hubspot.com/forms/use-progressive-fields-in-forms | curl | Progressive profiling pattern |
| 20 | Attio — Views (Academy) | https://attio.com/help/academy/introduction/views | curl | Table/kanban; favorite views for team |
| 21 | Attio — Filter and sort views | https://attio.com/help/reference/managing-your-data/views/filter-and-sort-views | curl | Current-user filter; save-for-everyone vs ephemeral; filter groups |
| 22 | Atlassian Design — Inline edit | https://atlassian.design/components/inline-edit | headless browser | Read→edit on same page definition |
| 23 | Atlassian Design — Drawer | https://atlassian.design/components/drawer | headless browser | Drawer definition; deprecation note |
| 24 | Chili Piper — Lead response time stats | https://www.chilipiper.com/article/speed-to-lead-statistics | curl | 21x/100x/391%/42h/38%; benchmarks; best practices |
| 25 | DataReportal — Digital 2025: Algeria | https://datareportal.com/reports/digital-2025-algeria | curl | Mobile 116%; FB 25.6M; Messenger 15.8M; IG 12M; TikTok 21.1M; median age 28.6 |
| 26 | Wikipedia — Telephone numbers in Algeria | https://en.wikipedia.org/wiki/Telephone_numbers_in_Algeria | curl | +213; 0yxx format; operators 5/6/7 |
| 27 | Wikipédia (FR) — Ouedkniss | https://fr.wikipedia.org/wiki/Ouedkniss | curl | 2006 classifieds leader; "one of most visited sites in Algeria"; refs to Le Soir/Wamda/Algerie Eco |
| 28 | WhatsApp Help Center — How to use click to chat | https://faq.whatsapp.com/5913398998672934/?locale=en_US | headless browser | wa.me + ?text= spec; phone & WhatsApp Web |
| 29 | Close — Sales Pipeline Management guide | https://blog.close.com/sales-pipeline-management/ | curl | Pipeline stages; hygiene; follow-up stage |
| 30 | *(Internal, prior verified)* Salesforce Help/Trailhead lead-convert & qualification research | `agent-ctx/2-d-1-external-research.md` (workspace) | prior session | Convert semantics; MQL/SQL; NN/g progressive disclosure notes |

**Not accessible (documented for transparency):** capterra.com (Cloudflare block) · www.ouedkniss.com (timeout) · nngroup.com (WAF) · search engines (bot-degraded responses — no snippet citations used).

---

## 10. Bottom Line for the ASAS Product Team

The 2024–2026 market consensus for lead management is not more features — it is **sharper attention**: know which lead is new and uncontacted, which is rotting, which has no next step, and make the next action one tap away (WhatsApp/call in the DZ context). Every researched vendor implements this with **computed signals over existing fields + saved views + quick actions**, which is exactly the shape a Next.js + Prisma + SQLite single-table-lead CRM can own. The recommended CORE set (C1–C12) deliberately avoids every heavy pattern the enterprise suites sell (API messaging, scoring, attribution, telephony) and doubles down on the discipline loops that FUB, Pipedrive, Salesforce and Zoho all converge on — localized for Ouedkniss/Facebook/Instagram/WhatsApp/walk-in sourcing, +213 phone reality, and trilingual FR/AR/EN delivery.

— *End of report. Agent S1-A3.*
