# ASAS CRM — Lead Management: Remaining Defects Register (Phase 2.2 close)

**Date:** 2026-11-03 · **Scope:** Lead Management ecosystem at HEAD `4d1f71a` (src identical to LM `23fc602`)

**Verdict:** zero P0/P1 defects open. The register below is the complete honest list of what is NOT verified or NOT done — nothing else is known to be broken.

---

## P2 — environmental / verification limits

| ID | Item | Detail | Disposition |
|---|---|---|---|
| D-R-01 | Mobile browser desktop-site mode | The headless environment cannot toggle a mobile browser's "request desktop site" setting, so the dedicated desktop-site-mode pass (mission §7) cannot be executed here. | NOT VERIFIED — reported per the honesty law; recommend a manual pass on a physical device (360–430px widths listed in mission §7). |
| D-R-02 | Production build | `next build` is intentionally not run in this sandbox (single-port dev-server law). Typecheck (0 errors) + lint (0/0) + 163/163 tests stand as the code-quality gates. | Environmental constraint, not a defect. |
| D-R-03 | Dev-server persistence | The sandbox reaps background processes at shell-command boundaries (X-04); the server lifecycle belongs to the platform driver. All QA used self-contained boot→verify→kill commands. | Environmental; QA methodology adapted and documented. |

## P3 — known design behaviors (documented, not defects)

| ID | Item | Detail |
|---|---|---|
| D-R-04 | newLeads KPI is archive-inclusive | The dashboard's newLeads statistic deliberately counts created-then-archived leads (creation STATISTIC, not an action queue — code comment in `api/dashboard/route.ts`). The KPI-strip click isolates the live (archived-excluded) `createdAfter` facet, so the two numbers can differ when archived leads exist in the window. Reproduced this session as 38 vs 36 (= exactly the 2 archived probe leads). | Behavior-by-design; if product later wants exactness, align the KPI predicate with the facet (one-line change) — tracked here so the decision is revisitable. |
| D-R-05 | Profile-field PATCHes are not AuditLog-recorded | The PATCH transaction audits status changes and assignment (LEAD_STATUS_CHANGED / LEAD_STATUS_CORRECTED / LEAD_ASSIGNED) but not profile-field edits (name/contact/priority). Activities still timeline them per the app's rules. | Design of the audited contract; acceptable for demo scope; revisit if compliance requirements expand. |

## Deferred work (roadmap DEFER table #19–#24 — decisions, not defects)

| ID | Item | Why deferred |
|---|---|---|
| D-R-06 | NextActionCell extraction (9 live variants) | High-churn refactor, behavior preserved today; no user-facing defect |
| D-R-07 | Lost-reason dialog / roster / stepper dedupe | Cosmetic consolidation |
| D-R-08 | Journey `journeyFocus` deep-links | Cross-view token system — next-mission scope |
| D-R-09 | TruncationNotice extraction | Pure refactor |
| D-R-10 | Timeline pagination (take:100) | Covers seeded reality |
| D-R-11 | Saved-views upgrade / column customization | Existing saved-searches adequate |

## Watch items (observed once, never reproduced)

| ID | Item | Detail |
|---|---|---|
| D-R-12 | Transient "status filter API hang" | Observed once by the prior session under heavy parallel browser load; not reproducible via direct API probes (<25ms across all facet combinations, re-confirmed by A5 this session). | Watch only; no action. |

## Data notes

- Historical snapshot drift rows (D-LD-07 forward-only heal): reconcile on their next requirement save; no backfill needed for demo data.
- The 2 archived A5 probe leads and 1 archived V-06 test lead remain in the DB as archived rows (invisible in active lists; counted by the archive-inclusive creation statistic — see D-R-04). Purge is a one-liner if demo cleanliness is later required; deletion of records is out of QA scope per the safety law.

---

**Bottom line:** the mission's completion criteria (§10) are met — 26/26 verification checks PASS with evidence; every remaining item above is a documented environmental limit, a design decision, or an explicit deferral from the approved roadmap. Nothing known-broken is being reported as done.
