# ASAS CRM — Lead Management UX / Workflow Audit

**Task ID:** S1-A2 · **Agent:** UX Architect & Workflow Specialist
**Scope:** Complete lead-management user journeys (create / search / profile / contact / status / assignment / qualification / interactions / follow-ups / visits / opportunities / conversion / history)
**Method:** Static read-only analysis of the actual source (`src/components/crm/**`, `src/lib/client/**`, `/api/leads/**`). Every claim is anchored to a file:line. No code was modified.
**Out of scope:** pixel-level visual design (handled by the visual audit agent).

---

## 1. Executive summary

The lead module is one of the strongest parts of ASAS CRM. The quick-capture dialog (2-step progressive form with draft-safety, duplicate pre-check and post-create drawer landing), the overlay drawer contract (context never dies), the KPI-chip isolation law, `j/k` row navigation, the mobile bottom action bar and the bulk-archive undo are all above-average CRM UX.

It is nonetheless held back by **one critical capability hole and a handful of high-frequency frictions**:

1. **Captured data is not editable.** The PATCH contract supports `fullName`, `email`, `secondaryPhone`, `whatsapp`, `priority`, `score`, `budgetMin/Max`, `propertyType`, `desiredLocation` (`src/app/api/leads/[id]/route.ts:125-146`), but **no UI anywhere fires those patches** (verified by grep: `patchLead.mutate` is only ever called with `status`, `ownerId`, `nextFollowUpAt`, `notes`, `lostReason`, `correctionReason` — `lead-drawer-header.tsx:90-110`, `lead-drawer-info.tsx:199-210`). A typo in a phone number, a wrong budget or a missing priority entered at creation is **unfixable** without recreating the lead or a manager merge.
2. **"Convert to customer" is a single unguarded irreversible click** on a terminal status (CONVERTED is locked server-side; there is no un-convert flow).
3. **Two parallel follow-up systems** (`lead.nextFollowUpAt` vs FOLLOW_UP tasks) with different default times (09:00 vs 10:00) and different surfaces.
4. **The drawer front-loads ~3 screens of "next action" bands** before the tabs; on a 375 px screen the actual work surfaces (composer, requirements, tabs) are below the fold.
5. **Desktop/tablet asymmetries**: the schedule-visit verb exists in the mobile bottom bar but not in the desktop drawer header; quick actions are hover-revealed (invisible on touch); owner chip is a 24 px-tall target.

**Overall UX score: 72 / 100** (breakdown in §9).

---

## 2. Surface map & entry points

| Surface | File | Entry points | Role |
|---|---|---|---|
| Leads list (toolbar, KPI strip, filters, table/cards, bulk bar) | `views/leads-view.tsx` (+ `views/leads/*`) | Sidebar «Prospects», hash `#/leads` | All |
| Create dialog (2-step) | `create-lead-dialog.tsx` | Leads toolbar «Créer», topbar «+ Nouveau prospect», ⌘K palette action | All |
| Lead drawer (header / journey rail / info bands / 6 tabs) | `lead-detail-drawer.tsx`, `lead-drawer-header.tsx`, `lead-journey-rail.tsx`, `lead-drawer-info.tsx`, `lead-tab-*.tsx` | Row click, palette result, post-create landing, deep link `#/leads/:id` | All |
| ⌘K palette | `search-command.tsx` | ⌘K / Ctrl-K, topbar search button (md+), mobile search icon | All |
| Schedule visit dialog (global) | `visits/schedule-visit-dialog.tsx` | Drawer (mobile bar / info cell / visits tab / journey NBA), visits view, apartment dialog | All |
| Import / Duplicates | `import-leads-dialog.tsx`, `duplicates-dialog.tsx` | Leads toolbar (MANAGER+) | MANAGER+ |
| State | `lib/client/store.ts` (view/leadId/tokens), `lib/client/workspace-store.ts` (search/filters/sort/page — session-scoped, per-user) | — | — |

API contracts verified: `POST /api/leads` (dup 409 + `force`), `PATCH /api/leads/:id` (transitions, corrections, assignment cascade), `POST /api/leads/:id/activities|tasks|tags|whatsapp|requirements|convert|reactivate`, `POST /api/leads/bulk` (assign/status/addTag/archive).

---

## 3. Current-state journey maps

Clicks = discrete pointer interactions (typing/select-scroll not counted). "C" = click.

### J1 — Create lead, quick path (« I have a new lead on the phone »)

Entry points: topbar `+` (`shell.tsx:216-227`), leads toolbar «Créer» (`leads-view.tsx:568-574`), ⌘K → «Nouveau prospect» (`search-command.tsx:248-259`).

| # | Step | Clicks | Surface / API | Feedback |
|---|---|---|---|---|
| 1 | Open dialog | 1 | `create-lead-dialog.tsx:291` | Step chips «1 L'essentiel · 2 Enrichir» + hint |
| 2 | Type full name | 0 (+type) | `:384-400` | inline zod error if <2 chars |
| 3 | Type phone | 0 (+type) | `:402-450` | normalized preview; debounced dup pre-check (500 ms, `:229-246`) → quiet amber twin note + «voir la fiche» jump |
| 4 | Pick source (required) | **2** | `:452-475` Select | none |
| 5 | «Créer maintenant» | 1 | `:724-731` → `POST /api/leads` | spinner in button (isPending), toast «Prospect créé», **drawer auto-opens** (D6 landing: `leads-view.tsx:355-359`, `shell.tsx:254-260`) |

**Total: 4 clicks + 2 text entries** (≈ 10–15 s). With a default source it would be 2 clicks.
Error recovery: inline zod; server 409 DUPLICATE renders an in-dialog destructive alert listing twins + «Créer quand même» (`force:true`) (`:339-379`); **form data is preserved on every error path** (no reset on error); **double submission prevented** (`disabled={isPending}`); Esc/overlay/X on a dirty draft route through a discard confirm (`:248-264`, `:736-761`).
Next action after save: excellent — drawer opens on the Overview tab with the journey rail's NBA «Consigner un 1er contact».

### J2 — Create lead, detailed path

Same as J1 + «Continuer» (1 C, validates the trio, `:283-286`) → step 2 (email, whatsapp-same, priority, campaign*, owner* (MANAGER), budget min/max, propertyType, location w/ datalist, notes) → «Créer maintenant» (1 C).
Both steps submit through the same resolver; a validation error on a field owned by the *other* step auto-jumps to it (`:266-279`) — no dead submit.
Friction: budget fields are plain number inputs here while the opportunity dialog uses the dedicated `MoneyField` (DZD formatting) — inconsistent money-entry grammar (`create-lead-dialog.tsx:592-633` vs `pipeline/create-opportunity-dialog.tsx:34`).

### J3 — Search & filter

| # | Step | Clicks | Notes |
|---|---|---|---|
| 1 | Type in toolbar search | 0 (+type) | 300 ms debounce, page reset (`leads-view.tsx:149,240-243`) |
| 2 | Open filter popover | 1 | `filters.tsx:206-243` |
| 3 | Toggle facets | 1 per facet | **Live-apply — every toggle fires a request immediately** (`filters.tsx:222`); no Apply/queue |
| 4 | Remove a facet | 1 | removable chips row (`filters.tsx:392-485`) + «clear all» |
| — | KPI chip isolation | 1 | resets everything, arms one facet (`leads-view.tsx:636-687`) |
| — | ⌘K palette | 0 (keys) | ≥2 chars, 300 ms debounce, grouped results, Enter → drawer overlay; recents + quick actions when empty (`search-command.tsx:148-276`) |
| — | Saved searches | 2 | menu → entry (manager surface, `saved-searches.tsx`) |

Positive: workspace state survives view switches (session-scoped, per-owner reset — `workspace-store.ts:12-25`); `placeholderData` keeps rows stable during refetch.
Friction: see F-07 (live-apply request storm), F-22 (KPI chip resets user-composed facets).

### J4 — Open lead profile

Row click / Enter / Space (`lead-row.tsx:213-227`) or card tap (`lead-row.tsx:393-396`) → **1 C** → shell-level Sheet overlay (`store.ts:206-222` — context preserved from ANY view). Loading = honest skeleton (`lead-detail-drawer.tsx:85-100`); error = retry state. Recents feed the palette (`:128-133`). Deep-linkable only on the leads view.

### J5 — Contact lead (WhatsApp-first culture)

| Path | Clicks | Behavior |
|---|---|---|
| Row WhatsApp icon (table/card) | **1** | opens `wa.me` with the *follow-up* template pre-filled, logs `POST /api/leads/:id/whatsapp` + toast (`whatsapp.tsx:227-278`) |
| Drawer header / mobile bar WhatsApp | 1 + 1 (template) + 1 («Ouvrir») | popover with 3 templates + custom text (`whatsapp.tsx:65-223`) |
| Phone | 1 | `tel:` deep link in row, card and header (`lead-row.tsx:269-277`, `lead-drawer-header.tsx:129-136,319-327`) |

Note: the row button logs a contact attempt the moment `wa.me` opens — even if the agent never sends the message. The timeline row is honest («attempt»), but `lastContactAt`-derived signals (uncontacted KPI, rot ladder) reset on a possibly-abandoned chat (F-23).

### J6 — Update status

- **List**: only QUALIFY shortcut for NEW/CONTACTED rows — hover-revealed icon → dropdown → «Qualifier» = **2 C** (deliberate confirm-click, `quick-actions.tsx:90-129`). Any other single-row status change must go through the drawer or bulk.
- **Drawer**: click the status badge (it *is* the DropdownMenuTrigger, `lead-drawer-header.tsx:150-213`) → pick target = **2 C**. Legal edges only for agents; manager corrections in a separate menu group requiring an audited reason dialog; CLOSED_LOST requires a lost-reason dialog (`:106-110,332-362`). CONVERTED never offered (dedicated flow owns it).
- **Bulk**: selection → status dropdown; CLOSED_LOST asks for the reason (`bulk-bar.tsx:221-247,127-138`).
- Feedback: toast + full invalidation family (`["lead",id]`, `["leads"]`, `["dashboard"]`). **Not optimistic** — badge updates only after refetch.
- Affordance gap: the badge carries no caret/pencil; editability must be discovered by clicking (F-05).

### J7 — Assign owner (MANAGER+)

| Path | Clicks | Gating |
|---|---|---|
| Row quick-assign (**unassigned rows only**) | 2 | `quick-actions.tsx:87` (`ownerId == null`) |
| Drawer owner chip (any lead) | 2 + drawer open | `lead-drawer-header.tsx:225-294` — trigger is `h-6` (24 px) — small touch target |
| Bulk assign | 3+ | `bulk-bar.tsx:171-195` |
| Below MANAGER | — | no UI anywhere; server 403s (`/api/leads/[id]/route.ts:218-220`) — consistent |

The reassignment cascade (open opps / open tasks / future visits follow the client) is server-side and toast-reported. Consistent list↔drawer, *except* the row shortcut deliberately covers only the intake pool.

### J8 — Qualify (fully: status + criteria)

From the leads list to "fully qualified":
1. Open drawer — 1 C (Overview tab is default).
2. Status badge → QUALIFIED — 2 C (or row shortcut 2 C *before* opening).
3. Scroll past activity preview + composer + copilot card to the requirements form (`lead-tab-overview.tsx:362-489`).
4. Fill criteria (13 available fields; realistically budget ×2, type, district, timeframe ≈ 5 field interactions).
5. «Enregistrer» — 1 C (`:297-304`) or «Rechercher des correspondances» — 1 C (saves then matches, toast + auto-scroll to results, `:306-333`).

**≈ 9 clicks + 5 field entries.** The journey rail NBA «Compléter les critères» jumps to the Overview tab (`lead-journey-rail.tsx:136-141`) but does not scroll to the form.

### J9 — Record interaction

Composer lives at the top of BOTH the Overview tab (default) and the Historique tab (`lead-tab-activities.tsx:236-373`): pick mode chip (1 C, optional) → optional structured outcome Select (2 C) → type text → Enter/send (1 C). Mobile: bottom bar «Journal» (1 C) → same composer. Toast + timeline refresh + `["leads"]`/`["dashboard"]` invalidation. **Best-in-class flow of the module.**

### J10 — Schedule follow-up

Info band «Prochain rappel» cell (1 C) → popover: preset chip Demain / 3 j / 1 semaine (1 C) or calendar day → «Enregistrer» (1 C) = **3 C** (`lead-drawer-info.tsx:229-340`). Draft line + hour visible before save; clear button; fixed **09:00** hour (`:49-59`).
Cognitive duplication: a *separate* FOLLOW_UP **task** system exists in the Tâches tab (quick-add defaults **tomorrow 10:00**, `lead-tab-tasks.tsx:91-96`) with its own date/time. Two models, two defaults, two surfaces, no cross-linking (F-06).

### J11 — Schedule visit

- Mobile: drawer bottom bar «Visite» (1 C) → global dialog pre-filled with this lead (`lead-detail-drawer.tsx:361-368`, drawer stays open under the dialog).
- Desktop: **no header verb** — must find the muted «+» next-visit cell in the second info band (`lead-drawer-info.tsx:418-427`), or the Visits tab CTA, or the journey NBA at the MATCH_AND_VISIT stage.
- Dialog: lead (pre-filled), project select (2 C), optional units (n C), agent, date/time (default today+2 11:00, `schedule-visit-dialog.tsx:60-64`), notes → submit (1 C). Toast + visits invalidation.
**≈ 4–7 C.** Entry asymmetry is the main friction (F-03).

### J12 — Create opportunity

**Not reachable from the lead drawer.** The drawer's Opportunités tab only offers *Convert* (when zero opportunities exist, `lead-tab-opportunities.tsx:52-53`) or opens the deal cockpit for existing rows. Creating a *second* deal for the same customer means: switch to Pipeline view → «create opportunity» dialog → re-find the lead through a combobox (`pipeline/create-opportunity-dialog.tsx:77-80`) → fill 6 fields → submit. Context loss + re-find (F-10).

### J13 — Convert to customer

Drawer → Opportunités tab (1 C) → «Convertir» (1 C) → `POST /api/leads/:id/convert` (transactional contact + opportunity@QUALIFIED + status flip). **No confirmation dialog** (`lead-tab-opportunities.tsx:57-76`). CONVERTED is terminal: every later status PATCH is 422 (`/api/leads/[id]/route.ts:159-170`); there is no un-convert UI. One accidental click creates a contact, an opportunity and an irreversible status — the single worst destructive-action-safety hole in the module (F-02).

### J14 — Review history

Drawer → Historique tab (1 C; count badge on the tab). Day-group chips, actor emphasis, outcome chips, system-vs-human de-emphasis; timeline rows deep-navigate to the visit fiche / deal cockpit / highlighted task by *authoritative ids* (`lead-tab-activities.tsx:375-429`). Overview tab carries a 3-item preview with «voir l'historique». Strong.

---

## 4. Cross-cutting findings

### 4.1 Feedback, loading & error recovery
- **Toasts everywhere** (sonner), always with honest server messages (`errMessage`); no fake successes found.
- **Blocking, not optimistic**: every mutation disables its trigger with a spinner and waits for invalidation+refetch (only the match-card «présenter» flip is optimistic, `lead-tab-overview.tsx:76-89`). Perceived latency on status/owner changes.
- **Draft safety** in the create dialog (discard confirm) — exemplary.
- Drawer notes save **on blur only** with no dirty indicator; closing the drawer mid-edit risks silently dropping the draft (F-27).
- Empty ≠ dead-end is applied well (no-visit «+», no-task «Planifier», composer CTAs).

### 4.2 Destructive-action safety matrix

| Action | Confirm | Undo | Verdict |
|---|---|---|---|
| Bulk archive | AlertDialog | 8 s toast-undo (real server restore) | ✅ |
| Single archive | — (via bulk of 1) | unarchive in archive view | acceptable |
| Status → CLOSED_LOST | reason dialog (required) | reactivate button | ✅ |
| Manager correction | reason dialog + audit | — | ✅ (audited) |
| **Convert** | **none** | **none (terminal)** | ❌ F-02 |
| Unarchive row | none | re-archive | ✅ reversible |
| Merge duplicates | destructive AlertDialog + preview | — | ✅ |

### 4.3 Mobile (375 px) trace
- Table `hidden md:block` (`table.tsx:100`); cards <md with labeled quick actions, tel/WhatsApp, rot signal, next action (`lead-row.tsx:371-525`).
- Mobile selection requires entering a selection mode first (no long-press) (`leads-view.tsx:545-566`).
- Create dialog: `max-h-[92vh]` scroll body, pinned footer, `h-11` (44 px) buttons, stacked primary (`create-lead-dialog.tsx:702-732`).
- Drawer: `w-full` sheet, sticky tab bar (scroll-x), sticky bottom action bar with 4 verbs + safe-area inset (`lead-detail-drawer.tsx:66-68,257-284,336-370`).
- Filter popover `w-80` (320 px) fits; KPI chips wrap; toolbar collapses labels to icons.
- **Verdict: all 14 journeys are completable at 375 px.** Watch-outs: hover-revealed quick actions on md..lg touch devices (F-09), 24 px owner chip (F-11), icon-only adjacent toolbar buttons (import vs duplicates) at <sm.

### 4.4 List ↔ drawer consistency matrix

| Verb | List | Drawer | Bulk | Gap |
|---|---|---|---|---|
| Qualify | ✅ (NEW/CONTACTED) | ✅ status menu | ✅ status | none |
| Other status | ❌ (drawer only) | ✅ | ✅ | mild |
| Assign | ✅ unassigned only | ✅ (manager) | ✅ | mild (deliberate) |
| Follow-up | ❌ | ✅ popover | ❌ | — |
| Contact (WA/call) | ✅ | ✅ | ❌ | — |
| Log activity | ❌ | ✅ composer | — | — |
| Schedule visit | ❌ | ✅ (weak on desktop) | ❌ | F-03 |
| Archive | bulk only | **❌ no per-lead archive** | ✅ | F-12b |
| **Edit profile fields** | ❌ | **❌** | ❌ | **F-01 critical** |
| Priority | ❌ | ❌ (static badge; PATCH + toast branch exist, no UI) | ❌ | F-01 |

---

## 5. Friction register

| ID | Workflow | Friction | Severity | Root cause (file:line) |
|---|---|---|---|---|
| **F-01** | Open profile / all | **Lead profile fields (name, phone, email, whatsapp, priority, budget, type, location, score) are not editable anywhere.** PATCH supports them; UI never fires them. Fixing a typo = recreate lead or manager merge. | **Critical** | `lead-drawer-info.tsx:512-557` (read-only InfoItems), `lead-drawer-header.tsx:215` (static PriorityBadge); unused capability in `/api/leads/[id]/route.ts:125-146` |
| **F-02** | Convert | One click, no confirm, irreversible terminal status; creates contact + opportunity silently | **High** | `lead-tab-opportunities.tsx:63-74`; lock at `/api/leads/[id]/route.ts:159-170` |
| **F-03** | Schedule visit | No schedule-visit verb in the desktop drawer header (mobile-only bottom bar); desktop path is a muted «+» cell | Medium-High | `lead-detail-drawer.tsx:321-370` (`md:hidden`), `lead-drawer-info.tsx:418-427` |
| **F-04** | Create quick | Source is required with **no default** → 2 extra clicks on the highest-frequency write (~30+/agent/day) | Medium-High | `create-lead-dialog.tsx:117` (`.min(1)`), `:452-475` |
| **F-05** | Update status | Status badge is an invisible edit trigger (no caret/affordance); also priority badge is purely decorative | Medium | `lead-drawer-header.tsx:150-161` |
| **F-06** | Follow-up | Two parallel systems (lead.nextFollowUpAt vs FOLLOW_UP tasks), different defaults (09:00 vs 10:00), no linkage; fixed 09:00 hour can't record «call me at 14:00» | Medium-High | `lead-drawer-info.tsx:49-59,199-204` vs `lead-tab-tasks.tsx:87-96` |
| **F-07** | Filter | Live-apply per checkbox toggle — each toggle = immediate request; rapid multi-facet composition fires N requests and can flicker | Medium | `filters.tsx:222` (`patch` → `onApply`), `leads-view.tsx:235-238` |
| **F-08** | Open profile | Drawer front-loads journey rail + 2×3 next-action cells + 7-item grid + tags + notes before tabs; ~3 screens on mobile before the composer/requirements | Medium-High | `lead-detail-drawer.tsx:212-241`, `lead-journey-rail.tsx:213-375`, `lead-drawer-info.tsx:229-666` |
| **F-09** | Qualify/assign | Row quick actions `opacity-0` until `group-hover` — invisible on touch-capable md+ devices (tap ≠ hover) | Medium | `lead-row.tsx:339` |
| **F-10** | Create opportunity | Not reachable from the drawer; second deal requires pipeline round-trip + combobox re-find (context loss) | Medium | `lead-tab-opportunities.tsx:52-76`; `create-opportunity-dialog.tsx:77-80` |
| **F-11** | Assign | Owner chip trigger `h-6` (24 px) < 44 px touch target; no `crm-hit` | Medium | `lead-drawer-header.tsx:228-245` |
| **F-12** | Bulk (mobile) | Selection requires a mode toggle first; no long-press-to-select on cards | Low-Medium | `leads-view.tsx:545-566`, `lead-row.tsx:393-396` |
| **F-12b** | Archive | No single-lead archive in the drawer (must bulk-select 1) | Low-Medium | absence in `lead-drawer-header.tsx` (header verbs) |
| **F-13** | All mutations | No optimistic updates for status/owner/qualify; perceived latency under slow networks | Low-Medium | e.g. `leads-view.tsx:389-418`, `lead-detail-drawer.tsx:160-172` |
| **F-14** | Search | No keyboard shortcut focuses the in-view search box (only ⌘K global palette) | Low | `leads-view.tsx:444-456` |
| **F-15** | Create | Email duplicates only surface on submit (409); phone gets a live pre-check | Low | `create-lead-dialog.tsx:229-246` |
| **F-16** | Money entry | Budget fields are raw number inputs; opportunity dialog uses `MoneyField` — two money grammars | Low-Medium | `create-lead-dialog.tsx:592-633` vs `create-opportunity-dialog.tsx` |
| **F-17** | Qualify | NBA «Compléter les critères» switches tab but doesn't scroll to the requirements form (below preview/composer/copilot) | Low | `lead-journey-rail.tsx:136-141`, `lead-tab-overview.tsx:348-366` |
| **F-18** | Navigate | No next/previous lead navigation inside the drawer (j/k only works in the table) | Low | `lead-detail-drawer.tsx` (no prev/next) |
| **F-19** | Follow-up | Presets select but never auto-save; three interactions for «tomorrow» | Low | `lead-drawer-info.tsx:64-68,199-204` |
| **F-20** | Filter | KPI chip click **resets** user-composed facets (isolation law) — surprising if facets were in progress | Low | `leads-view.tsx:648-685` |
| **F-21** | List | Empty search results state has no inline «clear filters» CTA (clear-all lives only in the chips row/popover) | Low | `leads-view.tsx:716-722` |
| **F-22** | Contact | Row WhatsApp click logs a contact attempt & resets rot/uncontacted signals even if the chat is abandoned | Low-Medium | `whatsapp.tsx:259-264` |
| **F-23** | Notes | Notes save on blur only; no dirty state; drawer close mid-edit can drop the draft | Low-Medium | `lead-drawer-info.tsx:206-210,652-665` |
| **F-24** | Bulk | No undo for bulk status/assign (only archive has undo) | Low | `bulk-bar.tsx:103-120` |
| **F-25** | Mobile toolbar | Manager toolbar has 5 adjacent icon-only buttons (duplicates/import/export visually close) | Low | `leads-view.tsx:576-625` |

---

## 6. Improved journey proposals (concrete, minimal-step)

**P1 — Make the lead profile editable (kills F-01, the critical gap).**
Turn the drawer's info grid into inline-edit rows (click-to-edit pencil → Input/Select → Enter saves `PATCH /api/leads/:id`): name, phone (+ normalization preview), email, whatsapp, secondary phone, priority, budget (use `MoneyField`), propertyType, desiredLocation. Zero server work — the PATCH contract already validates every field. Add «Archiver» to the drawer header's overflow (fixes F-12b at the same time).

**P2 — Guard the convert action (kills F-02).**
Wrap «Convertir» in an AlertDialog stating exactly what will be created (client record + opportunity at QUALIFIED stage, irreversible). One extra click on a rare, irreversible action — the correct trade.

**P3 — Default the source field (kills F-04).**
Default to the org's most-frequent source (or last-used, persisted in the workspace store). Quick-create drops from 4 clicks to 2. Keep the dropdown for override.

**P4 — Unify follow-up semantics (kills F-06).**
Single model: «Prochain rappel» popover gains a time picker (default 09:00) *or* a «créer une tâche de rappel» toggle that writes the FOLLOW_UP task instead of the bare field; align both defaults (one hour, one default). Long-term: make the task the source of truth and render the field as a derived signal.

**P5 — Desktop drawer action row (kills F-03, softens F-08).**
Mirror the mobile bottom bar's four verbs (WhatsApp / Journal / Tâche / Visite) as an md+ action row in the drawer header — «schedule visit» becomes one click on every viewport.

**P6 — Reduce drawer front-load (mitigates F-08).**
Collapse the two next-action band rows into one compact row (follow-up · next task · next visit · deal action) with the journey rail as its header; move the commercial-weight block into the Opportunités tab. Goal: composer + requirements reachable within one viewport at 375 px.

**P7 — Visible edit affordance on the status badge (kills F-05).**
Add a subtle caret/chevron inside the badge trigger (or «Modifier» hint in the aria-label + a tooltip). Same treatment for the priority badge once editable (P1).

**P8 — Queue filter applications (kills F-07).**
Debounce the checkbox facets the way the text facets already are (350 ms), or add an explicit «Appliquer» for multi-change composition. Keep chips removable (already good).

**P9 — Create-opportunity from the drawer (kills F-10).**
Add «+ Nouvelle opportunité» in the Opportunités tab that opens `CreateOpportunityDialog` pre-filled with this lead (dialog already accepts a lead combobox — preselect instead).

**P10 — Touch-revealed quick actions (kills F-09).**
On coarse pointers, always render the row actions cell at reduced opacity instead of `opacity-0` (`@media (pointer: coarse)` variant), and enlarge the owner chip to a 44 px `crm-hit` target (F-11).

**P11 — Optimistic status/owner/qualify flips (softens F-13).**
Use react-query `onMutate` cache patches for `["leads"]`/`["lead",id]` on the three hot verbs; rollback on error. Toast cadence unchanged.

**P12 — Post-step-1 continuation nudge.**
After a quick create, when the drawer opens on a NEW lead with no contact yet, auto-focus the composer input (the NBA already points there — make it actionable without the scroll).

---

## 7. UX acceptance criteria

**AC-01 (Capture)** — From any view, a lead is created and its drawer visible in ≤ 3 pointer interactions + 2 text entries; the source field carries a sensible default; Enter submits step 1.
**AC-02 (Data integrity)** — Every field displayed in the drawer's info grid is editable in place, with validation mirroring the server contract; a failed patch leaves the draft intact and shows the server message.
**AC-03 (Irreversibility)** — No irreversible action (convert, merge, bulk archive) commits without an explicit confirmation naming the consequence.
**AC-04 (Consistency)** — Every verb available in the drawer is reachable from the list surface in ≤ 2 additional interactions, or deliberately hidden with a documented rationale (RBAC).
**AC-05 (Contact loop)** — Logging an interaction, scheduling the follow-up and scheduling a visit are each ≤ 3 interactions from the open drawer on BOTH desktop and 375 px viewports.
**AC-06 (Follow-up truth)** — There is exactly one user-facing follow-up concept; its default time is identical across surfaces; a follow-up with a non-default hour is representable.
**AC-07 (Feedback)** — All mutations show pending state on their trigger; the three hot verbs (status/owner/qualify) reflect optimistically and roll back on failure with an error toast.
**AC-08 (Draft safety)** — No dismiss path (Esc/overlay/X/navigation) silently discards a dirty draft anywhere in the module (create dialog ✅ today; drawer notes ❌).
**AC-09 (Mobile)** — All 14 journeys complete on a 375 px viewport with ≥ 44 px touch targets on every interactive control.
**AC-10 (Keyboard)** — `j/k` navigation, Enter-to-open, ⌘K palette, and a focus shortcut for the in-view search all function without a pointer.
**AC-11 (Empty states)** — Every empty/dead-end state offers the next action (create, clear filters, schedule visit) — extends the existing pattern to the no-results state.
**AC-12 (Localization)** — All new copy ships fr/ar/en; phone/email tokens stay LTR-isolated in RTL; money always renders DZD-formatted.

---

## 8. Click-count comparison (current → proposed)

| Workflow | Current | With proposals |
|---|---|---|
| New lead on phone → saved (drawer open) | 4 C + 2 fields | **2 C + 2 fields** (P3) |
| Fix a wrong phone number | **impossible** | 3 C inline (P1) |
| Change priority | **impossible** | 2 C (P1/P7) |
| List → fully qualified | ≈ 9 C + 5 fields | ≈ 8 C (P6/P12 scroll & focus) |
| Status → QUALIFIED | 2 C (row) / 2 C (drawer) | same (affordance clearer, P7) |
| Schedule follow-up «tomorrow» | 3 C | 2 C (P4 one-tap save on preset) |
| Schedule visit from drawer (desktop) | 2–4 C + discovery | **1 C** (P5) |
| Log call + outcome | 4 C | 4 C (auto-focused, P12) |
| Convert to customer | 2 C, unguarded | 3 C, guarded (P2) |
| Create 2nd opportunity for a lead | view switch + combobox ≈ 6 C | 3 C from drawer (P9) |
| Archive one lead | 3 C (bulk-of-one) | 2 C from drawer (P1) |

---

## 9. Scorecard

| Dimension | Score | Rationale |
|---|---|---|
| Lead capture (quick/detailed) | 8.5/10 | 2-step + draft safety + dup pre-check; source default & money-field gaps |
| Search & filter | 8/10 | debounce, chips, KPI isolation, saved searches; live-apply storms |
| Profile / drawer | 6.5/10 | strong tabs & timeline; front-load + non-editable fields |
| Contact & interaction logging | 8.5/10 | best loop in the app; WA attempt semantics |
| Status / assignment / qualification | 7/10 | good guardrails; affordance + optimism gaps |
| Follow-up & scheduling | 6.5/10 | dual system, desktop visit asymmetry |
| Opportunities & conversion | 5.5/10 | unguarded convert; no in-drawer creation |
| History & audit | 9/10 | id-based navigation, day grouping |
| Mobile 375 px | 8/10 | complete; touch-target & hover-reveal issues |
| Error handling & safety | 8/10 | exemplary dialogs; convert hole, notes draft |
| **Overall** | **72/100** | |

*Audit generated read-only; no source files were modified.*
