# ASAS CRM — Lead Management: Information Architecture & Cross-Page Unification Audit

- **Task ID:** S1-A4 · **Agent:** 4 (IA & Cross-Page Unification Architect)
- **Date:** 2026-11-03 · **Mode:** READ-ONLY investigation (no code modified)
- **Scope:** How lead/customer information is organized ACROSS the 12 client-side views of the single `/` route (zustand-routed), and how to unify them into ONE coherent experience. Single-view visual detail (Agent 1) and workflows (Agent 2) are out of scope.

---

## 1. Page Relationship Map — where lead data lives

The app is one route (`src/app/page.tsx` → `crm-app.tsx`) with 12 views routed via `useCrmStore.view` (hash `#/view`, deep-link `#/leads/:id`). The **lead detail drawer is a shell-level overlay** (`ShellLeadDrawer` in `shell.tsx`) — `openLead(id)` opens it from ANY view without leaving the working context (the "Phase D overlay contract"). This is the single strongest IA unification in the codebase.

| Surface | File(s) | Lead fields shown | Lead affordances |
|---|---|---|---|
| **Leads view (customer book)** | `views/leads-view.tsx` + `views/leads/{table,lead-row,filters,kpi-strip,bulk-bar,quick-actions,use-export}` | name (+Arabic alias), email, phone (tel:), source, status, priority, budget (min–max + micro-meter), owner (+pool marker), last contact (rot ladder 7d/14d), unified next action (follow-up/deal/visit), score (meter), created | row click → drawer; checkbox/bulk; qualify/assign quick actions; archive toggle; import/export/duplicates; KPI chip strip (5 facets) |
| **Dashboard** | `views/dashboard-view.tsx` + `views/dashboard/*` | KPI counts (newLeads, uncontacted, clients, overdueTasks, hotOpps, funnel); `TodayPanel` task/visit rows (lead name chip); `HotOpportunities` rows; `RecentLeadsTable` (name, phone, source, status, owner, createdAt, staleness tint) | attention cells → leads facets (`uncontacted`, duplicates token); newLeads KPI → `createdAfter` facet; recent-leads row → drawer; "view all" → leads facet; hotOpps → `pipelineFocus{hot}` |
| **Journey view (lifecycle worklist)** | `views/journey-view.tsx` + `views/journey/{journey-visuals,journey-performance}` | funnel stage counts (8 stages); per-customer card: urgency tier, name, phone, stage chip, money in play (reservation/opp/budget), next best action, next visit, stage age, lost reason, owner | card click → drawer; stage chips/funnel segments filter in-view only |
| **Pipeline view** | `views/pipeline-view.tsx` + `pipeline/*` | kanban card: opp title/value/probability/stage/owner/aging; `OpportunityDetailDialog`: lead name + tel: | card click → opp dialog; dialog lead chip → drawer; create-opportunity dialog (lead combobox) |
| **Visits view** | `views/visits-view.tsx` + `visits/*` | `VisitRow`: lead name (button), project, agent, time block, status, units chips, outcome | row lead name → drawer; unit chips → apartment dialog; `visits.leadId` facet; schedule dialog (global, prefills lead) |
| **Tasks view** | `views/tasks-view.tsx` | `TaskRow`: title, lead chip, opp chip, owner, priority, due | lead chip → drawer; `TaskOpportunityChip` → opp dialog |
| **Properties view** | `views/properties-view.tsx` + `properties/*` | demand panel matching leads; reservation context (client link) | demand row → drawer; apartment dialog client link → drawer; orphan holds |
| **Finance view** | `views/finance-view.tsx` + `finance/*` | installment rows: client/contract/unit | row client link → drawer; `financeFocus{query}` isolation |
| **SAV view** | `views/sav-view.tsx` + `sav/*` | case rows: client, property | row client link → drawer; `savFocusId` cockpit |
| **Audit view** | `views/audit-view.tsx` + `audit/*` | audit target overlay | target → drawer |
| **Search palette (⌘K)** | `search-command.tsx` | leads (name+phone, highlight), recents, opportunities (title+lead), contacts (name+phone) | lead/contact rows → drawer; opp row → **lead drawer (not opp dialog)**; projects/apartments/developers → properties focus; SAV → case cockpit; installments → finance isolation |
| **Notifications bell** | `notifications-bell.tsx` + `hooks/use-notifications.ts` | grouped counts + up-to-3 item labels (leadId) | item click → drawer; LEADS_DUPLICATES → duplicates token; **other group clicks → plain `setView` (no facet)** |
| **Lead detail drawer (shell overlay)** | `lead-detail-drawer.tsx` + `lead-drawer-{header,info}.tsx`, `lead-journey-rail.tsx`, `lead-tab-{overview,activities,tasks,visits,opportunities,documents}.tsx` | full 360: identity + contact links, status/priority/owner edit, journey rail (8-step + NBA), next-action band (follow-up/last-contact/next task/next visit/deal action/reservation/commercial weight), 6 tabs | in-drawer CTAs; schedule visit (global); journey rail CTAs → pipeline hot / finance query / sav; mobile bottom action bar |

**Query-cache sharing:** leads KPI strip reads the exact `["dashboard","30d"]` query the dashboard owns; the unassigned chip reads the bell's `["notifications"]` poll — one metric, one label (`dash.kpi.*`), one cache across surfaces. ✅

---

## 2. Cross-View Consistency Matrix

Legend: ✅ unified/shared · ⚠️ partially consistent or duplicated · ❌ divergent/missing.

| Pattern | Leads | Dashboard | Journey | Pipeline | Visits | Tasks | Palette/Bell | Verdict |
|---|---|---|---|---|---|---|---|---|
| **View header (h1/subtitle)** | shell `VIEW_META` | ✅ same | ✅ same | ✅ same | ✅ same | ✅ same | n/a | ✅ **one system** (shell topbar + `document.title`) |
| **Toolbar row** (`flex-wrap gap-2`, h-9 controls, `text-crm-body`) | ✅ | — (period tabs) | ✅ | ✅ | ✅ | ✅ | n/a | ✅ same grammar everywhere |
| **Primary action button** (`bg-primary` + Plus, one per view) | ✅ create | shell CTA (demoted to outline on tasks/visits) | ❌ **none** (worklist is read-act) | ✅ create | ✅ schedule | ✅ composer | shell new-lead | ⚠️ journey has no create/refresh primary (refresh is outline) |
| **KPI presentation** | `KpiChip` mini-strip (clickable facets) | `AttentionCell` + `KpiCard` + funnel | funnel bar + stage chips | 4 summary `Card`s | count line only | count line | bell badges | ⚠️ **4 KPI idioms** — deliberate tiering (attention/context/quiet), labels shared via `dash.kpi.*`, but component-level divergence |
| **KPI labels** | reuses `dash.kpi.*` | owner | `journey.*` | `pipeline.*` | `visits.*` | `tasks.count` | `notif.*` | ✅ one label per metric via i18n keys |
| **List presentation** | `<table>` crm-zebra + sticky | recent-leads `<table>` (plain) | `<ul>` cards | kanban columns / stacked cards | `crm-list-row` groups | `crm-list-row` groups | CommandItems | ⚠️ 3 list idioms (table/card/list-row) — consistent per domain |
| **Pagination** | `TablePagination` (shared) | none (8 rows) | ❌ **none (server take:500, no disclosure)** | ❌ none (cap 200 + disclosure) | ❌ none (cap + disclosure) | ❌ none (cap + disclosure) | n/a | ⚠️ `TablePagination` shared by leads+audit only; 4 views use cap+disclosure; journey uses neither |
| **Truncation disclosure** | n/a | n/a | ❌ absent | ⚠️ copy #3 | ⚠️ copy #2 | ⚠️ copy #1 | n/a | ❌ **identical banner duplicated 4×** (tasks:541, visits:370, pipeline:344, inventory-filters:164) |
| **Row → lead** | row click → drawer | row/chip → drawer | card → drawer | card/dialog → drawer | name → drawer | chip → drawer | row → drawer | ✅ **the overlay contract — 21 files call `openLead`** |
| **Phone rendering** (`displayPhone`, mono, `ltr-token`, tel:) | ✅ | ✅ | ✅ | ✅ (dialog) | — | — | ✅ | ✅ one pattern |
| **Name rendering** (`arabicDisplay`, weight 600 anchor) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ one law |
| **Dates** | `relativeTime`/`formatDZD` via `lib/format` | ✅ | ✅ | ✅ | `formatDayMonth/Time` | ✅ | ✅ | ✅ **single locale-bound formatter module** |
| **Status badges** | `LeadStatusBadge`, `SourceBadge`, `PriorityBadge` | same + `VisitStatusBadge` | ⚠️ hand-rolled stage chips + `URGENCY_TONE` | `StageBadge` ✅ + ⚠️ private `STAGE_CHIP` dup | `VisitStatusBadge` | `PriorityBadge` | `SavStatusBadge` (from sav-table) | ⚠️ one system for 7 badge types, **3 escape hatches** (journey chips, STAGE_CHIP dup, SavStatusBadge location) |
| **Empty state** | `EmptyState` (3 variants) | ✅ | ✅ | ✅ | ✅ | ✅ | bespoke calm state | ✅ shared `states.tsx` |
| **Error state** | `ErrorState` | ✅ | ✅ | ✅ | ✅ | ✅ | — | ✅ shared with retry |
| **Loading state** | `LeadsTableSkeleton` | `KpiSkeletons`/`ListSkeleton` | 6×`Skeleton` cards | `BoardSkeleton` | `VisitsSkeleton` | `TasksSkeleton` | spinner row | ⚠️ 7 bespoke skeletons, consistent visual language, no shared component |
| **Detail surface header** | drawer: avatar+name+links+badges+actions | — | — | opp dialog: title+`StageBadge`+lead | — | — | — | ⚠️ 2 families (Sheet drawer vs Dialog); both lead with identity + status badge ✅ |
| **Detail body sections** | journey rail + info band + 6 tabs | — | — | InfoRow list + inline edit + economics + docs | — | — | — | ⚠️ `InfoRow`(opp) vs `Row`(apartment) duplicated |
| **Forms** | `CreateLeadDialog`: RHF+zod+`Form/*`, 2-step, dirty-guard, dup pre-check | — | — | `CreateOpportunityDialog`: useState+`Label`, manual gates | `ScheduleVisitDialog`: prefills | quick-add composer | — | ❌ **two form idioms**, different validation display (FormMessage vs disabled-submit vs toast) |
| **Cross-view state** | `workspace-store.leads` | patches leads/tasks/visits | ❌ **component-local only** | component-local (deliberate) | `workspace-store.visits` | `workspace-store.tasks` | read-state store | ⚠️ journey excluded from the workspace law |
| **Deep-link tokens** | consumes duplicatesToken | produces all tokens | ❌ produces none | consumes pipelineFocus | consumes visits facets | consumes tasks reset | consumes none | ⚠️ 5 token types exist; journey absent |
| **i18n** | `useT` everywhere | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ zero hardcoded strings found in scope |

---

## 3. Duplication Findings (same functionality, different components)

1. **Truncation disclosure banner ×4** — byte-identical markup+classes in `tasks-view.tsx:541-554`, `visits-view.tsx:367-381`, `pipeline-view.tsx:341-355`, `properties/inventory-filters.tsx:163-173` (plus 3 more `TriangleAlert mt-0.5 size-3.5` notice bodies in visit-fiche, copilot card, targets-section).
2. **Journey `STAGE_ICON` ×2** — `lead-journey-rail.tsx:46-55` and `views/journey/journey-visuals.ts:21-30` define the identical 8-entry map; journey-visuals.ts exists *specifically* to be the single definition ("mirrors the drawer rail"), yet the rail keeps its own copy.
3. **Stage tone map ×2** — `STAGE_CHIP` (`opportunity-detail-dialog.tsx:59-79`) restates `STAGE_TONE` (`badges.tsx:205-229`) with the same hues in border-inclusive syntax.
4. **Label-value row ×2+** — `InfoRow` (`opportunity-detail-dialog.tsx:107-124`) vs `Row` (`apartment-detail-dialog.tsx:81-88`) vs similar rows in sav-detail/installment-detail/`lead-drawer-info` — same `text-crm-caption` label / `text-crm-body font-medium tabular-nums` value anatomy.
5. **Owner filter Select ×2** — `tasks-view.tsx:477-502` and `pipeline-view.tsx:372-398` are the same "Tous — Propriétaire" roster select incl. the D-UX-053 tooltip-disclosure workaround.
6. **Inline debounce ×3** — `journey-view.tsx:84-87`, `sav-view.tsx:56-59`, `finance-view.tsx:78-81` hand-roll `setTimeout(…,300)` while `hooks/use-debounced.ts` exists (used by leads/pipeline).
7. **Contact-staleness logic ×2** — `lead-row.tsx:80-128` (`contactAgeDays`/`LastContactCell`, 7/14-day ladder) vs `recent-leads-table.tsx:31-44` (`contactTone`/`CONTACT_TONE_CLASS`, same thresholds, row-tint variant).
8. **Task row family ×3** — `tasks-view.tsx TaskRow` (full), `today-panel.tsx TaskRow` (light twin, same icon chip + lead chip + overdue law), `lead-tab-tasks.tsx` row (drawer variant). `TASK_TYPE_ICON` is shared ✅; the row anatomy is re-implemented.
9. **Visit row family ×4** — `visits/visit-row.tsx`, `today-panel.tsx VisitRow`, `visits/calendar-day-agenda.tsx` agenda row, `lead-tab-visits.tsx` — all share `VisitStatusBadge` ✅ but re-implement the time-block/identity anatomy.
10. **`SavStatusBadge` lives in a view** — defined in `views/sav/sav-table.tsx:46-60` and imported cross-domain by `search-command.tsx`; every other badge lives in `crm/badges.tsx`.
11. **KPI cell components ×3** — `leads/kpi-strip.tsx KpiChip`, `dashboard/kpi-card.tsx KpiCard`, `analytics-kpi.tsx` chips — three renderings of "number + label + tone".
12. **Cross-view composer focus hack** — `search-command.tsx focusTasksComposer` retries `querySelector` 20× to focus the tasks composer after navigation; every other cross-view contract uses a store token.
13. **`pad()` date helper** — `tasks-view.tsx:54-56` duplicates what `lib/format`/`lib/dates` provide.

---

## 4. Shared-Component Opportunities (concrete extraction proposals)

| # | Extract | From | Into | Why |
|---|---|---|---|---|
| 1 | `TruncationNotice({loaded,total,kind})` | tasks-view, visits-view, pipeline-view, inventory-filters | `components/crm/states.tsx` (or `views/shared/`) | kills the 4× copy-paste; one place to evolve the "Wave-2A board law" |
| 2 | import-only fix: `STAGE_ICON` | lead-journey-rail.tsx | `views/journey/journey-visuals.ts` (already the declared single source) | zero-risk dedupe of the 8-glyph map |
| 3 | `StageChip` derived from `STAGE_TONE` | opportunity-detail-dialog `STAGE_CHIP` | `crm/badges.tsx` next to `StageBadge` | one stage hue law; dialog header chip and badge can never drift |
| 4 | `InfoRow` / `LabelValueRow` | opportunity-detail-dialog `InfoRow`, apartment-detail-dialog `Row`, sav/installment dialogs | new `components/crm/entity-dialog-primitives.tsx` | one detail-dialog section anatomy |
| 5 | `OwnerFilterSelect` | tasks-view + pipeline-view | `components/crm/shared/owner-filter-select.tsx` | shared roster query, tooltip-disclosure law, RBAC narrowing |
| 6 | `useDebouncedSearch(value, 300)` or direct `useDebounced` adoption | journey-view, sav-view, finance-view | existing `hooks/use-debounced.ts` | removes 3 inline setTimeout copies |
| 7 | `contactStaleness(lead)` helper + `LastContactCell` | lead-row.tsx + recent-leads-table.tsx | `components/crm/views/leads/lead-row.tsx` (export) or `lib/format`-adjacent | one 7/14-day rot ladder (today: cell vs row-tint variants disagree in implementation, not thresholds) |
| 8 | `LeadIdentityCell({avatar,name,email,phone})` | lead-row, recent-leads-table, palette lead row | `components/crm/lead-identity.tsx` | avatar+initials+600-weight-name+tel: link re-implemented 3× |
| 9 | `SavStatusBadge` relocation | views/sav/sav-table.tsx → `crm/badges.tsx` | badges.tsx | keeps search-command from importing a view; completes the badge registry |
| 10 | `JourneyWorkspace` slice + `journeyFocus` token | journey-view component state | `lib/client/workspace-store.ts` + `store.ts` | lets dashboard/analytics funnels and the bell deep-link INTO the journey worklist (see §5) |
| 11 | `goToNotification` isolation map | notifications-bell `goTo` | per-type facet patches (mirroring attention-strip `goToCell`) | restores aggregate→isolate parity for the bell |
| 12 | `TaskRowCore` / `VisitRowLite` | tasks-view + today-panel (+drawer tabs) | `components/crm/{tasks,visits}/row-core.tsx` | one row anatomy per entity, presentation variants on top |
| 13 | Standardize forms on RHF+zod+`Form/*` (or extract a `FieldError` text) | create-opportunity-dialog, schedule-visit-dialog, sav/finance dialogs | pattern of create-lead-dialog | one validation display language (FormMessage vs disabled gates vs toasts today) |
| 14 | Skeleton families | 7 bespoke skeletons | optional `views/shared/skeletons.tsx` (table/list/board variants) | lowest priority — visual language already consistent |

---

## 5. Missing Navigation Links (cross-view waypoints)

**Existing (for reference — strong):** `openLead` overlay from 21 surfaces; attention-cell → leads facets (uncontacted, duplicates token); newLeads KPI + recent-leads "view all" → `createdAfter` facet; `openPipelineFocus({hot})` (KPI, HotOpportunities, journey rail); `openPropertiesFocus` (palette ×3 kinds); `openFinanceFocus` (palette + journey rail); `openSavCase` (palette); `openScheduleVisit` prefill (toolbar, drawer, calendar day-click, apartment dialog, demand panel, deal-economics closure → visits `leadId` facet); `#/leads/:id` shareable hash.

**Missing / broken:**

1. **Nothing deep-links INTO the Journey view.** No `journey` slice in the workspace store, no `journeyFocus` token, no funnel step is clickable (dashboard `MovementPanel` steps and analytics charts are plain divs), the bell has no journey target, and the palette has no journey group. The lifecycle worklist — the view whose entire job is "who needs what next" — is reachable only via the sidebar. The dashboard funnel (leads→qualified→visits→reservations→won) is *numerically* the journey funnel, yet cannot hand off to it.
2. **Bell group clicks don't isolate.** `notifications-bell.tsx goTo()`: item click → `openLead` ✅, duplicates → `openDuplicates()` ✅, but every other group → bare `setView(n.view)` — e.g. LEADS_UNCONTACTED lands on an **unfiltered** leads view, breaking the aggregate→isolate contract the dashboard attention cell for the *same metric* honors (it arms `filters.uncontacted`). TASKS_OVERDUE also doesn't reset owner/type narrowing (the documented parity requirement in attention-strip).
3. **Search palette opportunity rows open the LEAD drawer, not the opportunity cockpit.** Inconsistent with SAV rows (open case cockpit), installment rows (open finance isolation), apartment rows (open unit dialog). The user loses the deal context they searched for; there is also no path from the palette to the pipeline board filtered to that opp.
4. **Lead drawer → visits view scoped to this lead is missing.** The `visits.leadId` workspace facet exists (D7-R4B) and `deal-economics-closure.tsx` already uses `patchVisits({leadId})` — but the drawer's Visits tab offers no "see all in the visits calendar/list" waypoint. Similarly there's no "show this lead in the customer book" affordance (the `#/leads/:id` hash contract exists but is only produced implicitly).
5. **Journey view has no truncation disclosure + its filters are session-lost.** Server caps at `take: 500` with no client disclosure (the Wave-2A law every other capped surface honors); stage/owner/search state is component-local, so a dashboard→journey→leads→journey round-trip resets the worklist scope — inconsistent with the leads/tasks/visits workspace law.

Secondary gaps: dashboard funnel steps non-clickable (would map to leads status facets or journey stages); analytics funnel/source tables not drillable; palette lead row has no "view in list" secondary action; notifications `view` enum lacks `journey`/`sav`/`finance` targets for RESERVATIONS_EXPIRING (goes to `pipeline`).

---

## 6. Verdict & Score

**Score: 78 / 100.**

**What holds the architecture together (and should be preserved as the unification spine):**
- the `openLead` shell-level overlay contract (one lead 360, reachable from everywhere);
- one badge system (`badges.tsx` + `constants.ts` tone maps), one formatter module (`lib/format`), one i18n law (`useT`);
- shared `ErrorState`/`EmptyState`;
- the workspace-store + transient-token deep-link discipline with its privacy/owner-key law;
- shared KPI *labels* and query caches across dashboard / leads strip / bell.

**What costs points:**
- journey view's exclusion from the deep-link and workspace systems (−8);
- bell isolation parity break (−4);
- 4× truncation banner + 2× stage maps + 2× InfoRow + 2× owner select + 3× debounce + 2× staleness logic + 3 KPI cell components + 3/4-row families (−6 combined);
- two form idioms with divergent validation display (−3);
- palette opportunity-row target inconsistency (−1).

**Recommended unification order (highest leverage first):**
1. Bell `goTo` facet isolation (small, restores a documented contract).
2. `TruncationNotice` extraction (mechanical, 4 files).
3. Journey integration: `journeyFocus` token + workspace slice + clickable dashboard funnel (makes the lifecycle worklist first-class).
4. Detail-dialog primitives (`InfoRow`, `StageChip`) + `SavStatusBadge` relocation (completes the badge/registry systems).
5. Palette opportunity rows → open the opportunity cockpit (parity with SAV/finance rows).
6. Form idiom convergence (RHF+zod) on the next form touch.
