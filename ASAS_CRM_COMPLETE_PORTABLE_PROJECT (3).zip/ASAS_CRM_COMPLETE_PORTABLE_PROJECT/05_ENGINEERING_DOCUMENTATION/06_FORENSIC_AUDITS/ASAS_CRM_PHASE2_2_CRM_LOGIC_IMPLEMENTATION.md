# ASAS CRM — PHASE 2.2 CRM LOGIC IMPLEMENTATION

**Task owner:** Agents 2-b/2-c/2-d + Principal · **Status: VERIFIED (browser-evidenced)**

## 1. The customer lifecycle is now closed end-to-end

```
Lead captured ──► Leads Center (qualify/assign/rotting signals)
              ──► Journey worklist (stage + next-best-action)
              ──► Pipeline (opportunity monitoring: position, aging, advance)
              ──► CONVERT ──► Customers book (relationship health)
                              └─► 360 drawer (journey rail, history, tasks,
                                  visits, opportunities, documents)
```

Every arrow is a real navigation path in the app; every box is a live,
visibility-scoped surface backed by the same CJ engine derivation.

## 2. Leads — the qualification/distribution/follow-up center (Agent 2-b)

- **Intake KPI strip**: 4 chips (new / uncontacted / overdue / unassigned) fed
  from the EXISTING `["dashboard","30d"]` + `["notifications"]` caches — same
  keys, same queryFns → **zero extra requests**.
- **Qualify quick action** (NEW/CONTACTED → QUALIFIED): uses the sanctioned
  `PATCH /api/leads/:id { status }` routine edge (server validates against
  `LEAD_TRANSITIONS`; activity + audit rows commit in the route's transaction).
- **Assign quick action** (MANAGER+, unassigned rows): `PATCH { ownerId }` —
  the W3-1/W3-2 reassignment cascade (open opps / OPEN tasks / future visits
  follow the client) runs server-side; cache invalidation fans out
  `["leads"] ["dashboard"] ["lead",id] ["notifications"]`.
- **Rotting ladder** on last-contact: amber >7d (`Clock`), rose >14d
  (`TriangleAlert`), never-contacted keeps "—" + muted dot — desktop table AND
  mobile card.
- **Server gap closed by Principal**: `unassigned=1` facet (see SECURITY doc).

## 3. Pipeline — the opportunity progress monitoring system (Agent 2-c)

- **Card stage-position**: `3/8` badge + 3px progress rail, computed against
  the ordered OPEN stages (filter-independent — stays truthful under
  hideClosed/hotOnly; RTL-safe inline flow).
- **Column monitoring line**: `⌀ 12 j` median days-in-stage (+ mean tooltip),
  client-side from `stageChangedAt ?? createdAt` — **no new API field**;
  column total value health-colored (emerald ≤14d median, amber >14d).
- **Quick advance**: chevron on open cards → the EXISTING `requestMove`
  pipeline (optimistic move + rollback, WIP-limit warning, invalidation
  fan-out). Last-stage→CLOSED_WON routes into the existing
  CorrectionReasonDialog (server 422 law); LOST into the LostReasonDialog.
- **Closed-lane compaction**: won/lost cards render compact + muted; drag
  reopen preserved (visual compaction only).
- **Next-action due ladder** on cards: rose overdue / amber today micro-chips.

## 4. Customers — the relationship management space (Principal, Task 2-a)

The user's acceptance line — "صفحة العملاء ليست مجرد جدول أسماء وأرقام؛ بل مساحة
لإدارة العلاقة التجارية" — is implemented as five per-row signals (WHO/WHERE/
WHAT-weight/WHEN-last/WHAT-next) + the full 360 drawer on click. The idle chip
is a one-click "who are we neglecting" isolation (verified: 20 → 3 rows).
Verified per-role: manager sees 20 (org), Amine sees 5 (own), Mounia sees 10
(project-derived).

## 5. Dashboard — the decision tool (Agent 2-d)

- Attention strip: all 7 cells verified to land genuinely filtered (uncontacted
  → leads `?uncontacted=1`; unstaffed → visits `?unstaffed=1`; duplicates →
  the armed-token dialog; incentives → same-page queue anchor…).
- KPI cards: navigable cards carry a persistent chevron affordance (brightens
  + nudges on hover, RTL-mirrored); pure metrics stay plain — no fake
  navigability.
- **Scope framing**: `scope==="own"` → "Votre journée" agent workspace chip;
  org → "Vue équipe" (driven by the API echo, verified for both roles in the
  browser).
- Dead-end fix: Hot opportunities "view all" now opens the hot-isolated board
  (was: unfiltered board).
- Recent-leads rows: last-contact tint (amber >7d / rose >14d) + click → drawer.

## 6. End-to-end scenario evidence (browser, this session)

Login (Sarah) → dashboard (scope chip "Vue équipe") → Leads (KPI strip + row
actions + rotting) → Pipeline (⌀ medians, 3/8 badges) → Customers (KPIs, idle
filter 20→3) → customer row click → 360 drawer (Walid Sadi: Aperçu/Historique 3/
Tâches/Visites/Opportunités/Documents) → user switch (Amine) → "Votre journée"
framing → Customers 5 own rows → Mounia (FIELD_REP) → 10 project-derived rows.
Persistence verified across reload (`#/customers` hash deep-link). RTL/AR pass:
`dir=rtl lang=ar`, Arabic names + labels, no horizontal scroll at 390/768/1440.
