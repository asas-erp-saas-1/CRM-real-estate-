# ASAS CRM — Phase 2R Git Forensic Report (Repository Integrity & Governance)

**Task ID:** 1-a (Agent 1 — Git forensics, repository integrity & governance)
**Mission:** ASAS CRM Phase 2R Recovery
**Investigator:** read-only forensic session, 2026-11-02 (~14:36–15:30 UTC)
**Subject:** `main` @ `693bff9f690f1d3f33c0785fc4539ee0c920c151` (working tree clean at session open)
**Method:** git log/show/ls-tree/rev-parse/diff only, plus read-only `bunx tsc --noEmit`, `stat`, and file reads. Zero mutating git operations; zero working-tree modifications (except this report file, the one artifact this agent is authorized to create).

**Evidence-grading convention:** every material fact is tagged **[VERIFIED]** (with the command that proves it), **[INFERENCE]** (reasoned from verified facts), or **[NOT VERIFIED]** (claimed by prior audits, not re-checkable by this agent).

---

## §1 Executive summary

1. **The ancestry chain is exactly as briefed.** `753d115` (parent `b34d5b8`) and `693bff9` (parent `753d115`) are the ONLY two commits after the verified reference `b34d5b8`; both are purely additive; no other branches, tags, stashes, or remotes exist. **[VERIFIED]** `git rev-list b34d5b8..HEAD` → exactly `693bff9`, `753d115`; `git branch -a` → `* main`; `git tag`/`git stash list`/`git remote -v` → empty; `git status` → clean.

2. **The D-040 content-hash purity proof returns 26/26 IDENTICAL, 0 different.** Every one of the 26 ever-deleted files re-added by `753d115` is blob-identical (same git blob hash) to its version at **every** documented deletion-parent — including deletion waves the mission brief did not list (`b6b70f4`/WS-B-EXEC Oct 27, `26d253e`/PD-EXEC Oct 31). The contamination carries **zero new engineering content**. **[VERIFIED]** (§4 table; `git rev-parse <commit>:<path>` pairs).

3. **All 103 files of `753d115` decompose cleanly into the mission categories** — 26 resurrected environment residue, 64 orphaned QA screenshots (obsolete artifacts), 5 broken abandoned working files (source regressions), 6 legitimate audit deliverables (4 .md + 2 PNG from the "phase-status-audit" session), 2 disposable session tooling scripts (uncertain/disposition), **0 legitimate engineering improvements, 0 required configuration**. **[VERIFIED]** (§3).

4. **No legitimate source-code change exists after `b34d5b8`** in either commit. `693bff9` adds only 11 audit deliverables (5 .md + 5 PNG + 1 HTML). `753d115` adds only debris + audit docs. `src/`, `prisma/`, config: untouched. **[VERIFIED]** `git diff --name-status b34d5b8..HEAD` → 114 `A` rows, zero `M`/`D`.

5. **Root cause (INFERENCE, strongly evidenced): the sandbox environment's session-boot re-provisioning mechanism** (the R13/D-040 class, root-caused at `e2eb6f7`: "sandbox environment lifecycle re-provisions UNTRACKED state at session boot") resurrected the deleted files into the working tree between 00:39 and ~07:07 Nov 2, after which **the platform's session-snapshot auto-commit** (the UUID-message mechanism — 21 such commits in history, incl. the initial scaffold `7a7e255`) committed the accumulated untracked debris together with a legitimate audit session's outputs at 07:26:23, and the independent audit's outputs at 12:25:26. The 15-min webDevReview cron is **NOT** the author (reaped before 07:07; not on a 15-min boundary; 60–70 s after each session's last file write; R13 root-cause already excluded cron as the environment-reset source). **[VERIFIED]** mtimes: audit docs 07:22–07:25 → commit 07:26:23; docs 12:12–12:24 → commit 12:25:26.

6. **The prior audits' statistics are internally inconsistent as briefed, and now reconciled:** true test inventory = **85 test IDs in 70 table rows** (actual verdicts **50 PASS / 14 FAIL / 2 PARTIAL / 18 BLOCKED / 1 N-A**), vs the claimed summary 42/11/3/17/1 (= 74). True task inventory = **60 rows** (actual **40 PASS / 16 PARTIAL / 1 FAIL / 3 N-A** at-time reading), vs the claimed "64-unit inventory" with 33/18/4/0/3 (= 58). **[VERIFIED]** (§8; full derivations).

7. **Recommended recovery: a single targeted corrective commit (residue removal per the D-040/D-041/D-042 protocol)** — `git rm` the 26 zombies + 5 broken journey orphans + 2 tooling scripts, disposition the 64 orphan PNGs, **preserve** the 6 phase-status-audit deliverables and all 11 `693bff9` deliverables, conventional commit + retrospective worklog entry. No history rewrite, no reset, no revert. **[INFERENCE → recommendation]** (§7).

---

## §2 Chain of custody (commits, authors, timeline)

### 2.1 Repository topology — all [VERIFIED]

| Fact | Command | Output |
|---|---|---|
| HEAD | `git rev-parse HEAD` | `693bff9f690f1d3f33c0785fc4539ee0c920c151` |
| Branches | `git branch -a` | `* main` (only) |
| Tags / stash / remotes | `git tag` / `git stash list` / `git remote -v` | (all empty) |
| Working tree at session open | `git status` | `On branch main, nothing to commit, working tree clean` |
| Total commits | `git log --oneline main \| wc -l` | `304` |
| Commits after reference | `git rev-list b34d5b8..HEAD` | `693bff9…`, `753d115…` (exactly 2) |
| Parentage | `git log --format='%H %P' -3` | `693bff9` → parent `753d115` → parent `b34d5b8` (direct chain, no intervening commits) |
| Authors | `git log --format='%an <%ae>' \| sort \| uniq -c` | `304 Z User <z@container>` (100% — platform identity from `/home/z/.gitconfig`: `user.name=Z User`, `user.email=z@container`) |

### 2.2 The two post-reference commits — all [VERIFIED] unless noted

| Commit | Date (author=committer, +0000) | Subject | Files | Lines | Parent |
|---|---|---|---|---|---|
| `b34d5b84c6fb…` | 2026-11-02 00:39:06 | `feat: R15 — Phase 2+ four-indicator round (dashboard KPI trends + stage-constant dedup + a11y backport)` | — | — | `0d36f3e` (PHASE 2) |
| `753d1157469d…` | 2026-11-02 07:26:23 | `ffa3a843-519c-4c27-943e-d767e5360004` (bare UUID) | **103 A** | **+8,164** | `b34d5b8` |
| `693bff9f690f…` | 2026-11-02 12:25:26 | `d8685017-22cf-4b16-8cc2-6f751a0ac1aa` (bare UUID) | **11 A** | **+631** | `753d115` |

- `git diff --name-status b34d5b8 753d115 | awk '{print $1}' | sort | uniq -c` → `103 A`; same for `753d115..693bff9` → `11 A`; `b34d5b8..HEAD` → `114 A`. **Zero modifications, zero deletions of any reference file.** Both commits have empty bodies; author = committer = `Z User <z@container>` (identical timestamps — no rebase/amend signature).
- Reflog (`git reflog -20`) shows plain `commit:` entries only — no merges, no resets, no rebase, no checkout: the two UUID commits were created as ordinary commits on `main`.

### 2.3 Reconstructed timeline (Nov 1–2) — commands cited; interpretations [INFERENCE] where marked

| When (UTC) | Event | Evidence |
|---|---|---|
| Nov 1 12:58 | `d5a5209` UX-L close (last commit before the undocumented window) | `git log --date=iso` |
| Nov 1 14:46–17:38 | **Undocumented afternoon working window**: orphan journey refactor drafts (`journey-{stats,facet,worklist}.ts`, `api/journey/export/route.ts`, `journey-stage-chip.tsx`), `tmp-scripts/census.ts` (14:50), `recent-audits.ts` (15:08), and QA screenshots `evidence/qa-continue/` (from 14:46), `evidence/qa-r13/` (from 17:10), `evidence/qa-unify/` — **never committed, never referenced by any worklog/commit** | `stat` mtimes; `git log --all -- <path>` shows no add; worklog has zero mentions (grep) |
| Nov 1 19:31 / 21:10 / 23:06 | `9e783bf` MASTER · `a3a2c27` FINAL (deps cleanup "15 removed, 19 dead files… stale r10-seed-won.ts deleted") · `de787ec` R14 (34-candidate sweep adjudication) | `git log` |
| Nov 2 00:12 / 00:39 | `0d36f3e` PHASE 2 · `b34d5b8` R15 — **verified reference state; tree clean at close** | `git log`; worklog R15 entry |
| 00:39 → ~07:07 | **Environment re-provision at session boot [INFERENCE from mtime/class evidence]**: 26 ever-deleted files resurrected into the working tree with PRESERVED historical mtimes (`src/app/api/route.ts` & 17 `ui/*` & `tailwind.config.ts` = **2026-05-12 10:06** (bootstrap era); `src/lib/i18n.ts` = **2026-10-04 02:48** (pre-P7-1); `r10-seed-won.ts` = 2026-10-02 16:28; `view-placeholder.tsx` = 2026-10-02 04:15); live DB replaced by an Oct-2-era file (7 users/44 leads, per first audit); `db/backups/` wiped; `.env` reverted; cron register reaped | `stat` mtimes **[VERIFIED]**; DB/env state per audit docs **[NOT re-verified — see §2.4]** |
| Nov 2 ~07:07–07:25 | **"phase-status-audit" agent session** (read-only audit): 2 screenshots (`evidence/phase-status-audit/`, mtimes 07:07:52 / 07:1x) + 4 audit docs (mtimes 07:22:28–07:25:21). Observed the contamination as "36 untracked paths / 0 modified tracked" and documented it | mtimes **[VERIFIED]**; doc contents **[VERIFIED]** |
| Nov 2 07:26:23 | **`753d115`** — platform session-end snapshot committing ALL untracked debris (99 files) + the audit session's 6 outputs = 103 files | commit metadata; mtime→commit gap = 62 s after last doc write |
| 07:26 → 12:24 | **"independent-audit" agent session** (6 auditors): 5 docs (mtimes 12:18:52–12:24:16) + 5 PNGs + 1 HTML (`evidence/independent-audit/`, 12:12–12:14). Found DB EMPTY (0 rows) — a second environment reset occurred between the two audits | mtimes **[VERIFIED]**; DB claim **[NOT re-verified]** |
| Nov 2 12:25:26 | **`693bff9`** — platform session-end snapshot committing the 11 audit deliverables | commit metadata; mtime→commit gap = 70 s |
| Nov 2 14:00 | **Third environment re-provision (this mission's session boot)**: `.env` mtime 14:00:06, `db/custom.db` mtime 14:00:23 — after both audit commits | `stat` **[VERIFIED]** |
| Nov 2 14:36+ | This forensic session (Agent 1). Note: a parallel mission agent wrote `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_PHASE2R_DATABASE_ENVIRONMENT_REPORT.md` (untracked `??`, mtime 14:42:59) — not touched by this agent | `git status --porcelain` |

### 2.4 Current environment state (outside git, observed only)

`db/custom.db` and `.env` mtimes = Nov 2 14:00 (post-audit re-provision). The audits' live-DB claims (Oct-2-era data → then empty; no `_prisma_migrations`; WAL off) were **[NOT re-verified]** by this agent (DB probing out of forensic scope; state has since changed again per mtimes).

---

## §3 The 103-file inventory of `753d115` — 7-category classification

Source of inventory: `git diff --name-status b34d5b8 753d115` (103 `A` rows) **[VERIFIED]**. Category rubric: (1) environment residue = files resurrected by the environment from git-deleted history; (2) obsolete generated artifacts = orphaned session outputs with zero references; (3) confirmed source-code regressions = files whose tracked presence breaks/degrades the build or runtime; (4) legitimate engineering improvements; (5) audit documentation; (6) required configuration; (7) uncertain/disposition required.

### 3.1 Category (1) — Confirmed environment residue (resurrected ever-deleted files): **26 files**

All blob-identical to every documented deletion-parent (§4) — the D-040 zombie class, fifth documented wave (P25/P31 → P32; 23c04c0 → b6b70f4; 9cdf1fb → 26d253e; now 753d115 un-remediated).

| # | Path | Deleted at (all events) | Size |
|---|---|---|---|
| 1 | `src/lib/i18n.ts` | 392a743 (P7-1) · de9a3d3 (P26) · ee04e81 (P32) · b6b70f4 · 26d253e | 3,253 lines |
| 2 | `src/app/api/route.ts` | 66b7c13 · 9d635d7 (P33) · b6b70f4 · 26d253e | 5 lines ("Hello, world!") |
| 3 | `tailwind.config.ts` | ae9357f (H2-EXEC) · 26d253e | 64 lines |
| 4 | `src/components/crm/view-placeholder.tsx` | bb13147 (P34) · b6b70f4 · 26d253e | 35 lines |
| 5 | `src/app/api/leads/check-duplicates/route.ts` | bb13147 (P34) · b6b70f4 · 26d253e | 47 lines |
| 6 | `src/app/api/properties/unit-types/route.ts` | bb13147 (P34) · b6b70f4 · 26d253e | 13 lines |
| 7 | `tmp-scripts/r10-seed-won.ts` | e33737c · 9d635d7 (P33) · b6b70f4 · a3a2c27 | 653 lines |
| 8–24 | `src/components/ui/{accordion,aspect-ratio,carousel,chart,collapsible,context-menu,drawer,hover-card,input-otp,menubar,navigation-menu,radio-group,resizable,sidebar,toast,toaster,tooltip}.tsx` (17 files) | a3a2c27 (FINAL deps cleanup: "19 dead files") | 11–726 lines each |
| 25 | `src/hooks/use-mobile.ts` | a3a2c27 | 19 lines |
| 26 | `src/hooks/use-toast.ts` | a3a2c27 | 194 lines |

**Regression impact of this class (why their PRESENCE is a regression even though their CONTENT is residue):** 20 tsc errors at HEAD — **[VERIFIED]** `bunx tsc --noEmit` → exactly 20 errors: 14× TS2307 missing modules + 1× TS2339 (`input-otp.tsx:47 slots`) in the scaffold set + 5 broken-symbol errors in the journey orphans; the i18n.ts zombie re-activates the P26/P32 raw-key defect class (file-before-folder resolution rebinding `@/lib/i18n` — 5 live importers incl. `src/lib/client/store.ts:10` **[VERIFIED]**); `GET /api` becomes a live unguarded "Hello, world!" endpoint (content **[VERIFIED]** by `git show 753d115:src/app/api/route.ts`).

### 3.2 Category (3) — Confirmed source-code regressions (abandoned broken working files): **5 files**

Never tracked before `753d115` (absent at `b34d5b8` — **[VERIFIED]** `git cat-file -e b34d5b8:<path>` → absent); created Nov 1 16:13–17:28 during the undocumented afternoon window; reference non-existent exports (tsc errors **[VERIFIED]**): `journey-stats.ts:21,124,134` (`JourneyStatEntry`/`facts`/`LoadedJourneyEntry`), `journey-worklist.ts:26` (`isJourneyStalled`), `journey-stage-chip.tsx:29` (`openJourneyFocus`).

| # | Path | Lines | Note |
|---|---|---|---|
| 27 | `src/app/api/journey/export/route.ts` | 120 | Abandoned CSV-export feature draft; imports the orphan `journey-worklist.ts`; its broken import chain is the documented dev-server API-poisoning trigger (ND-A3, per independent audit **[NOT re-verified]**). **The export capability does NOT ship at `b34d5b8`** (`git grep "journey/export\|journeyExport\|JOURNEY_EXPORTED" b34d5b8 -- src/` → empty; no `text/csv` under `src/app/api/journey/` at `b34d5b8`) — a partial contradiction of the briefing's "superseded" claim: the worklist/stats/facet logic ships embedded in the live routes (`src/app/api/journey/route.ts` 219 lines + `journey/stats/route.ts` 141 lines at `b34d5b8`, **[VERIFIED]**), and the stage-chip vocabulary ships in `views/journey/journey-visuals.ts` (**[VERIFIED]** present at `b34d5b8`, and the orphan chip imports FROM it), but the export route itself has no live counterpart. |
| 28 | `src/lib/server/journey-worklist.ts` | 269 | Worklist loader draft; logic embedded in live `journey/route.ts`. |
| 29 | `src/lib/server/journey-stats.ts` | 141 | Stats draft; logic embedded in live `journey/stats/route.ts`. |
| 30 | `src/lib/server/journey-facet.ts` | 144 | Facet draft; dead + unwired (zero importers **[VERIFIED]**: `git grep -l "journey-worklist" 753d115 -- src/` → only the orphan export route). |
| 31 | `src/components/crm/journey-stage-chip.tsx` | 82 | UNIFY-round chip draft; visual vocabulary lives in `journey-visuals.ts`; references missing store action. |

### 3.3 Category (7) — Uncertain / disposition required: **2 files**

| # | Path | Content | Assessment |
|---|---|---|---|
| 32 | `tmp-scripts/census.ts` (15 lines) | Read-only Prisma census probe (`db.user.count()` × 9 entities → JSON) | **[VERIFIED]** content read. Harmless disposable session tooling (Nov 1 14:50); zero references in any doc/commit; duplicates capability of tracked probe scripts. Recommend delete. |
| 33 | `tmp-scripts/recent-audits.ts` (5 lines) | Read-only auditLog peek (last 4 rows) | Same class (Nov 1 15:08). Recommend delete. |

### 3.4 Category (5) — Audit documentation (legitimate deliverables of the phase-status-audit session): **6 files**

`05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_EXECUTION_EVIDENCE_INDEX.md` (76) · `ASAS_CRM_PHASE_COMPLETION_STATUS.md` (218) · `ASAS_CRM_PROJECT_HEALTH_SNAPSHOT.md` (46) · `ASAS_CRM_REMAINING_WORK_REGISTER.md` (57) · `evidence/phase-status-audit/01-manager-dashboard-broken.png` · `02-leads-view.png`.
**[VERIFIED]** content read in full: a coherent, honest, read-only audit of `b34d5b8` + the then-untracked contamination; explicitly states "zero implementation writes… The only files created are this document set (4 audit documents) and 2 evidence screenshots". These docs are the FIRST documentation of the contamination itself (register items R-01…R-07 prefigure the Phase 2R mission). Their only defect is provenance: they were swept into the platform's UUID snapshot commit instead of a conventional commit. **Recommendation: preserve (keep tracked).**

### 3.5 Category (2) — Obsolete generated artifacts (orphaned QA evidence): **64 files**

`evidence/qa-continue/` 19 PNGs · `evidence/qa-r13/` 19 PNGs · `evidence/qa-unify/` 26 PNGs (counts **[VERIFIED]** `ls | wc -l`). Nov 1 14:46–17:28 captures of the abandoned afternoon sessions. Zero references from any tracked doc, commit, or worklog (**[VERIFIED]** grep of worklog/docs; corroborated by the independent audit's "never referenced by any doc"). Superseded by the committed evidence corpora (`download/qa-*`: 85 entries/1,299 PNGs; `evidence/`: 19 dirs/160 PNGs — **[VERIFIED]**). Disposition = delete (or Principal may elect to archive the `qa-r13` journey-export toast capture as feature-archaeology for a future export implementation).

### 3.6 Categories (4) and (6): **0 files each**

No legitimate engineering improvement and no required configuration exists in `753d115`. (`tailwind.config.ts` is NOT required configuration: deliberately retired as "vestigial" at `ae9357f` — **[VERIFIED]** commit message.)

### 3.7 `693bff9` (for completeness — outside the contamination): 11 files, all category (5)

5 audit .md (`ACCEPTANCE_TEST_RESULTS` 143, `FINAL_READINESS_ASSESSMENT` 110, `INDEPENDENT_AUDIT_REPORT` 157, `PHASE_ACCEPTANCE_MATRIX` 148, `REMAINING_DEFECTS_REGISTER` 72) + `evidence/independent-audit/` 5 PNGs + 1 HTML (`poisoned-api-response.html`). **LEGITIMATE — PRESERVE (mission directive; contents read and cross-checked in §8–§9).**

### 3.8 Reconciliation of the "36 untracked paths" claim

The phase-status-audit's `git status --porcelain` = "36 lines, all `??`" reconciles **exactly** with my inventory if counted at that session's open (before its own 6 deliverables existed): 26 resurrected files + 7 never-tracked orphans + 3 pre-existing evidence dirs (`qa-continue/`, `qa-r13/`, `qa-unify/`) = **36** directory-collapsed entries → expanding to 99 files + the session's own 6 = 103. **[VERIFIED arithmetic]** The same doc's *textual* decomposition ("18 template files… 5 resurrected… 6 source files… 3 evidence folders" = 32) is internally sloppy (misses `r10-seed-won.ts`, `census.ts`, `recent-audits.ts`; double-lists `tailwind.config.ts` in two classes; "18 `src/components/ui/*`" vs the actual 17; "qa-unify (9 png), qa-r13 (12 png)" vs actual 26/19 — the "40 evidence screenshots" figure propagated into the independent audit from this miscount; true orphan-PNG count = 64).

---

## §4 D-040 content-hash purity-proof results

Method (per D-040/D-041 law): `git rev-parse <deleting-commit>^:<path>` (blob hash just before each documented deletion) vs `git rev-parse 753d115:<path>`. All deletion events enumerated via `git log --all --diff-filter=D -- <path>`. **Result: 26/26 IDENTICAL (100%); 0 DIFFERENT.** The blob hash is the SAME at every deletion-parent and at `753d115` for every file — the resurrection mechanism restores byte-exact original content every time.

| Path | All deletion events (earliest→latest) | Blob @ every deleting-parent | Blob @ 753d115 | Identical? |
|---|---|---|---|---|
| `src/lib/i18n.ts` | 392a743 (P7-1, 10-05) · de9a3d3 (P26, 10-11) · ee04e81 (P32, 10-12) · b6b70f4 (10-27) · 26d253e (10-31) | `2a3d9f7f9622e3f4e60da0b18a11ba7c7b1d6071` | `2a3d9f7f…` | **YES ×5** |
| `src/app/api/route.ts` | 66b7c13 (10-02) · 9d635d7 (P33, 10-13) · b6b70f4 · 26d253e | `0277710b3e8ce8861be944e9d69f62481dc57471` | `0277710b…` | **YES ×4** |
| `tailwind.config.ts` | ae9357f (H2, 10-30) · 26d253e (10-31) | `fc48e48832707aaaff6bd9b8cbba76358adf2e83` | `fc48e488…` | **YES ×2** |
| `src/components/crm/view-placeholder.tsx` | bb13147 (P34) · b6b70f4 · 26d253e | `339fc607d317e1500e4e4b868712836d506d641e` | `339fc607…` | **YES ×3** |
| `src/app/api/leads/check-duplicates/route.ts` | bb13147 (P34) · b6b70f4 · 26d253e | `cdc57231dd53c53fd6f29f8150f6c135fc9073dc` | `cdc57231…` | **YES ×3** |
| `src/app/api/properties/unit-types/route.ts` | bb13147 (P34) · b6b70f4 · 26d253e | `8e22b4ddfd5d1536176df8c2e78ef037d141c467` | `8e22b4dd…` | **YES ×3** |
| `tmp-scripts/r10-seed-won.ts` | e33737c · 9d635d7 (P33) · b6b70f4 · a3a2c27 (11-01) | `ea8c68fb85745525477c742fa241a3ca31e685ac` | `ea8c68fb…` | **YES ×4** |
| `src/components/ui/accordion.tsx` | a3a2c27 | `4a8cca46b9c10394f5710a35892b36407ee70fc4` | same | **YES** |
| `src/components/ui/aspect-ratio.tsx` | a3a2c27 | `3df3fd02a6a30b60b6e1474664065b0d3437bf48` | same | **YES** |
| `src/components/ui/carousel.tsx` | a3a2c27 | `0e05a77ea155fde6af5d9a4848b1d3953df6ea5a` | same | **YES** |
| `src/components/ui/chart.tsx` | a3a2c27 | `97cc2807f6d74ca79a5dc61f76c7796d9de19930` | same | **YES** |
| `src/components/ui/collapsible.tsx` | a3a2c27 | `ae9fad04a3716b5d6f6c957b75841737eb8ed7a8` | same | **YES** |
| `src/components/ui/context-menu.tsx` | a3a2c27 | `97634c9d294dd8d3e1d29c5c2cac7cfae57da286` | same | **YES** |
| `src/components/ui/drawer.tsx` | a3a2c27 | `8aa69230a087be1fb8efe2067d1cf793de87acd4` | same | **YES** |
| `src/components/ui/hover-card.tsx` | a3a2c27 | `e7541864c7dee7bf024ad96e7b6d0234e0b49f8b` | same | **YES** |
| `src/components/ui/input-otp.tsx` | a3a2c27 | `614f70e383bf47886ddb3d71581ccd27c8b5739d` | same | **YES** |
| `src/components/ui/menubar.tsx` | a3a2c27 | `55de7f4dbb176eec10dfd6a0f6a5d0a10f80991b` | same | **YES** |
| `src/components/ui/navigation-menu.tsx` | a3a2c27 | `1199945c49485cc3fbf9f86c0372ac550fe01cce5` | same | **YES** |
| `src/components/ui/radio-group.tsx` | a3a2c27 | `5e6778cb48d88b52f09ef333e1dd5df7c30f72d2` | same | **YES** |
| `src/components/ui/resizable.tsx` | a3a2c27 | `12bbd0b8b04e6ec83bde5b9fa8a3e29a166581da` | same | **YES** |
| `src/components/ui/sidebar.tsx` | a3a2c27 | `1ee5a457ea2b67b750e93d6be8311c7645a5cc6f` | same | **YES** |
| `src/components/ui/toast.tsx` | a3a2c27 | `41b1ee7bf1af4ba374a9f5959345cd1a08c41e24` | same | **YES** |
| `src/components/ui/toaster.tsx` | a3a2c27 | `3f3c878962026b2912d1e3df67c3859fccaa6ad7` | same | **YES** |
| `src/components/ui/tooltip.tsx` | a3a2c27 | `4ee26b38a595862a5a082013d564d1ccf8452a7c` | same | **YES** |
| `src/hooks/use-mobile.ts` | a3a2c27 | `2b0fe1dfef1b17850bbac040665f514a8ffd0f15` | same | **YES** |
| `src/hooks/use-toast.ts` | a3a2c27 | `b559959226c5b17b8a719d29a2cafe1ff5f935ef` | same | **YES** |

**Mode-bit signature** (not a reliable tell per D-041, recorded for completeness): every file at `753d115` is mode `100644`; at their deleting-parents, `api/route.ts`, `sidebar.tsx`, `tailwind.config.ts`, `r10-seed-won.ts`, `view-placeholder.tsx`, `check-duplicates` were `100755` — the same "restore without exec bits" artifact P33 documented. **[VERIFIED]** `git ls-tree`.

**Standing D-040 sweep at HEAD (context for the recovery):** `git log --all --diff-filter=D --name-only --pretty=format: | sort -u` × `git ls-files` → **60 hits** = 26 from the `753d115` wave + **34 pre-existing at `b34d5b8`** (22 finance/sav/targets files + 12 tmp-scripts). The 34 pre-existing hits were adjudicated by the R14 session's worklog entry (finance/sav/targets = deliberate owner-sanctioned Phase D restorations, wired live — schema carries `Installment`/`Payment`/`SavCase`/`SalesTarget` models **[VERIFIED]** `git grep "^model" prisma/schema.prisma`; the 12 tmp-scripts = recorded-as-inert tooling kept by R14 verdict). Not contamination; do not re-litigate per that verdict, but note: R14's "inert tooling" carve-out is in tension with D-041's letter ("nothing ever-deleted ∧ in-HEAD is tolerable") — flagged for the Principal. **[VERIFIED]** sweep counts; R14 verdict quoted from worklog at `b34d5b8`.

---

## §5 Root-cause analysis of the contamination

### 5.1 Who authored the commits — evidence

1. **Identity:** every one of the 304 commits (including all "engineering" ones) is authored by `Z User <z@container>` — the platform's global git identity (`/home/z/.gitconfig`). Authorship alone cannot discriminate. **[VERIFIED]**
2. **The UUID-message signature is the platform's auto-commit mechanism, not a project session:** 21 bare-UUID commits exist across history, from the initial scaffold `7a7e255` (Oct 2 03:37, 172 files/+35,127 — the platform bootstrap) through `23c04c0` (Oct 27, 196 files), `9cdf1fb` (Oct 30, 41 files/+9,266 — a full resurrection wave), to `753d115` and `693bff9`. **[VERIFIED]** `git log --format=… | grep -E '<uuid-regex>'`.
3. **Timing signature = session-end snapshot, not cron:** `753d115` (07:26:23) lands 62 s after the phase-status-audit's last file write (07:25:21); `693bff9` (12:25:26) lands 70 s after the independent audit's last write (12:24:16). Neither time is on a 15-minute boundary (the webDevReview cadence). **[VERIFIED]** `stat` mtimes vs commit dates.
4. **Cron ruled out:** the webDevReview job lineage (443511 → 488884 → 489828 (§1i) → 492455 (§1j) → 494550 (§1k) → 494790 (R15)) was **reaped before 07:07** — both audit sessions queried the scheduler and found 0 jobs (register addenda §1i/§1j **[VERIFIED]** in git; audit docs' "cron register EMPTY" **[NOT re-verified]**). The R13 root-cause determination (`e2eb6f7`, Oct 20) already concluded: "the cron jobs system-disabled — not the source" of environment re-provisioning. AGENTS.md line 21 (P14 law): all scheduled automation "TERMINALLY ENDED" per the user's 2026-10-07/08 instruction — while R14/R15 worklog entries record recreating the job "per this session's explicit system mandate (documented supersession of the P14 note)" — a standing law conflict the audits register as owner-decision item R-06/R-E6. **[VERIFIED]** texts quoted.
5. **The resurrection source is an old snapshot, not fresh writes:** resurrected files carry preserved historical mtimes (May 12, 2026 for the bootstrap scaffold files — `api/route.ts`, `tailwind.config.ts`, all 17 `ui/*`; Oct 4 02:48 for `i18n.ts` = its pre-P7-1 last-modified time). No recent process wrote these bytes. **[VERIFIED]** `stat`.
6. **Mechanism (INFERENCE):** the sandbox re-provisions untracked state at session boot (R13 root cause, `e2eb6f7`: ".env template · schema-only DB · db/backups wiped — while git-tracked state always survives; zero app-side mechanism"). Between 00:39 and ~07:07 a session boot re-provisioned the tree, restoring the ever-deleted files (from a snapshot preserving mtimes and dropping exec bits) alongside the Nov-1 orphan working files already on disk. The phase-status-audit session then ran (finding "36 untracked / 0 modified"), and at its close the platform's snapshot auto-commit committed everything untracked as `753d115`. The independent audit session followed; its close produced `693bff9` (only its own 11 files remained untracked by then). This is the **fifth documented wave** of the class (P25/P31→P32; `23c04c0`→`b6b70f4`; `9cdf1fb`→`26d253e`; now `753d115` un-remediated) — the first to survive more than ~2 h without a re-deleting engineering session.
7. **Not the author:** both audit sessions explicitly honor read-only mandates and list their own created files ("The only files created are this document set (4 audit documents) and 2 evidence screenshots"; "the five audit deliverables + 5 screenshots + 1 captured HTTP response are the only files created"). File mtimes corroborate: the 97 debris files pre-date both sessions. **[VERIFIED]** mtime table.

### 5.2 Why the contamination went unnoticed

- No automated test runner exists (house law; the structural enabler — independent audit's ND-A1/R-C5 analysis): nothing executable failed when the debris landed.
- The two sessions that ran between R15 close and the commit were **audits explicitly forbidden from repairing** ("do not fix issues during this audit") — the phase-status-audit *documented* the zombie set (register R-02/R-03/R-04) and the platform committed its outputs together with the debris minutes later.
- The worklog (append-only, 4,770 lines) has **zero** references to `753d115`/`ffa3a843`/`693bff9`/`d8685017` — the governance hole (ND-A5). **[VERIFIED]** `grep -cE … worklog.md` → 0.

---

## §6 Governing laws (exact quotes)

**AGENTS.md (identical blob at `b34d5b8` and HEAD — [VERIFIED] `git rev-parse` both = `5ca20e6d…`):**

- **Line 17 (D-040/D-041 resurrection-sweep law + R13 recovery manual):** "RESURRECTION SWEEP (D-040/D-041, mandatory): after secret + DB recovery, run `git log --all --diff-filter=D --name-only --pretty=format: | sort -u` × `git ls-files` (ever-deleted ∧ in-HEAD) BEFORE any steady-state witness — the environment resurrects deleted files into the tree (P25 small wave; P31 committed a 21-file wave unnoticed). NOTHING ever-deleted ∧ in-HEAD is tolerable (the D-040 law-4 «inert remainder» carve-out is RETIRED, D-041): re-delete every zombie after the content-hash purity proof (`git rev-parse <deleting-commit>^:<path>` vs HEAD — mode bits are NOT a reliable tell: P32's wave was +x 100755, P33's was 100644). Route deletions additionally require the restart-with-cleared-`.next` protocol…" (same paragraph carries the R13 manual: verify `user` count ≠ 0 before QA; recover via `bun run db:seed` + fresh `ASAS_SESSION_SECRET` + restart; `migrate resolve --applied 0_init` bookkeeping note).
- **Line 19 (commit law):** "Commits: conventional, one logical change each (`security: …`, `db: …`, `app: …`, `docs: …`, `chore: …`) — never UUID/noise messages; never mix unrelated refactors into a change." → `753d115`/`693bff9` violate this by their UUID messages (platform-authored, not project-authored).
- **Line 21 (P14 law):** "Long-term scheduled automation TERMINALLY ENDED (user-confirmed 2026-10-07 + re-confirmed 2026-10-08, P14): all `webDevReview` cron cycles are dead… do NOT rely on, recreate, or re-enable ANY scheduled review automation absent an explicit user instruction to the contrary…"
- **Line 13:** "`bun run build` is FORBIDDEN (sandbox)." (Observed by this investigation; relevant to recovery validation.)

**05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md:**

- **D-040 (Phase 32) binding laws:** "(1) **Deleted means deleted** — a file removed by a closed decision stays removed; any reappearance is a regression to fix, not a conflict to merge (the git-archaeology sweep `ever-deleted ∧ in-HEAD` is now the standing audit for the whole class…). (2) **Content-hash purity before deletion** — a resurrected file may only be re-deleted after proving it carries NO newer legitimate work (blob-hash vs the deletion commit's parent…). (3) **The single-source i18n law is structural** … `@/lib/i18n` must resolve to the domains composition root — the shadow file's existence alone re-breaks it regardless of content. (5) **The interrupted-session recovery protocol gains a step**: after secret + DB recovery, run the resurrection sweep BEFORE any steady-state witness."
- **D-041 (Phase 33) binding laws:** "(1) The D-040 law-4 «inert remainder» carve-out is RETIRED — the sweep's output is now wholly actionable; nothing ever-deleted ∧ in-HEAD is tolerable steady-state. (2) Content-hash is the only reliable purity signal… (3) The full-repo tsc gate joins the session gates… (4) Route deletions require the dev-server restart with a cleared `.next`…"
- **D-042 (Phase 34) binding laws:** "(1) The dead-surface class extends D-041 from zombies to originals: not only must deleted things stay deleted — never-wired things must be either wired or deleted… (2) Redundancy with a live surface is the purity proof for route deletion…"

**P32/P33/P34 commit messages** (`ee04e81`, `9d635d7`, `bb13147` — read in full **[VERIFIED]**): document the zombie class history, the purity-proof protocol, the "matrix ran once at 190/193 and would have mis-baselined without [the sweep]" lesson, and the 401-then-404 route-deletion verification subtlety.

---

## §7 Recommended recovery strategy

### 7.1 Recommendation: **targeted corrective commit (residue removal) — the P32/P33/P34 protocol, executed once, completely**

Rationale: the contamination is purely additive and 100% purity-proven; the tracked tree is otherwise identical to `b34d5b8`; history rewrite is forbidden and unnecessary; the reference state is reachable by deleting exactly what `753d115` added, minus the legitimate audit deliverables worth preserving.

**Concrete sequence (for the recovery executor — this agent performed none of it):**
1. `git rm` the **26 resurrected files** (§3.1 list) — purity proofs complete (§4, 26/26 identical).
2. `git rm` the **5 broken journey orphans** (§3.2) + `tmp-scripts/census.ts` + `tmp-scripts/recent-audits.ts` (disposition: discard — the phase-status-audit's own R-03 disposition option (b), "discard with a documented decision").
3. Disposition the **64 orphan PNGs** (`evidence/qa-continue|qa-r13|qa-unify/`): default `git rm` (unreferenced debris); optionally preserve `evidence/qa-r13/12-journey-export-toast.png` if the journey-export feature is ever re-implemented.
4. **Preserve** the 6 phase-status-audit deliverables (4 .md + 2 PNG) and all 11 `693bff9` deliverables (they stay tracked; the corrective commit simply does not touch them).
5. Commit with a **conventional message** (AGENTS.md line 19), e.g. `app: P2R — the 753d115 resurrection wave re-deleted after 26/26 content-hash purity proofs (D-040/D-041/D-042) + orphan working-session debris cleared; audit deliverables preserved`.
6. Append the **retrospective worklog entry** documenting `753d115`/`693bff9` provenance (closes the ND-A5 governance hole; the independent audit's stated acceptance criterion: "worklog references the sweep commit and the 753d115 hash").
7. **Route deletions require the D-041 law-4 restart protocol** (affected: `api/route.ts`, `api/leads/check-duplicates/`, `api/properties/unit-types/`, `api/journey/export/`): kill stale next-server BY PID from `ss -tlnp`, `rm -rf .next`, single subshell-detach restart.
8. Validation gates: `bunx tsc --noEmit` → 0 (this agent measured exactly 20 errors at HEAD, all confined to the 33 swept files — **[VERIFIED]**); `bunx eslint .` → 0; `GET /api` → 404; unauthenticated matrix → 401 JSON; D-040 sweep re-run → back to the 34 pre-adjudicated hits (not 60). Then the R13 DB runbook + re-verification per the mission plan (outside this agent's scope). **No `bun run build`** (forbidden).

### 7.2 Alternatives considered and rejected

| Option | Verdict | Reason |
|---|---|---|
| `git revert 753d115` (controlled revert) | **Rejected** | A revert of an adds-only commit deletes **all 103** files — including the 6 legitimate phase-status-audit deliverables the Principal should keep — and forfeits selective disposition of the 64 PNGs. Blunter than the sweep with zero additional safety (the sweep is mechanically identical for the 97 debris files). |
| `git reset --hard b34d5b8` | **Forbidden** | History rewrite; would also discard `693bff9`'s legitimate audit deliverables and violate mission constraints. |
| `git checkout b34d5b8 -- .` (selective restoration) | **Rejected** | Pointless: no tracked file differs from `b34d5b8` (purely additive contamination — **[VERIFIED]**). It would only delete the audit docs from the tree while leaving history dirty. |
| Do nothing / leave HEAD as-is | **Rejected** | Leaves the D-040 law violated at HEAD (sweep = 60 hits), build broken (20 tsc errors), the i18n text layer shadowed, and an unguarded `GET /api` endpoint. |
| History rewrite / purge | **Forbidden** | D-013 gate (owner authorization; only relevant before a remote — none exists). |

---

## §8 Statistics reconciliation (mission §13)

### 8.1 Test-level inventory — `ASAS_CRM_ACCEPTANCE_TEST_RESULTS.md` (in `693bff9`)

**Actual inventory [VERIFIED by row-count]:** T-1: 6 · T-2: 15 · T-3: 3 · T-4: 4 · T-5: 8 · T-6: 3 · T-7: 12 · T-8: **17 IDs in 2 rows** ("T-8.1–T-8.16" collapsed into one table row + T-8.17) · T-9: 8 · T-10: 9 → **85 test IDs across 70 table rows.**

| Verdict | Claimed (doc's "Summary counts") | Actual by ID (table-literal) | Delta |
|---|---|---|---|
| PASS | 42 | **50** | −8 undercounted |
| FAIL | 11 | **14** | −3 undercounted (the doc's own "Notable" column lists **13** FAIL IDs — self-contradictory with its own count of 11) |
| PARTIAL | 3 | **2** (T-9.6, T-9.7; T-10.7 is labeled **PASS** in its table row but counted PARTIAL in the summary) | +1 overcounted vs table |
| BLOCKED | 17 | **18** (T-7.5 + T-8.1…T-8.17) | −1 undercounted (doc's own note says "T-7.5 + T-8.1–T-8.17" = 18) |
| N-A | 1 | **1** (T-1.4) | 0 |
| **Total** | **74** (42+11+3+17+1) | **85** IDs / 70 rows | Neither 74 nor any single counting rule (rows vs IDs) reproduces the claimed numbers |

**Context-briefing cross-check:** the briefing's "claims 62 items / 42 PASS / 11 FAIL / 17 BLOCKED — sums to 70": the 42/11/17 figures match the doc; the "62 items" figure is **not traceable to any audit document** (the doc's own categories sum to 74; the row count is 70; the ID count is 85). The briefing's "sums to 70" is the sum of its own three quoted categories, not an item count.

### 8.2 Task-level inventory — `ASAS_CRM_PHASE_ACCEPTANCE_MATRIX.md` (in `693bff9`)

**Actual inventory [VERIFIED by row-count]:** Wave 1: 8 · Wave 2: 9 · Wave 3: 8 · Wave 4: 12 · Wave 5: 1 · PHASE 2: 8 · R15: 4 · Deferred: 10 → **60 task rows.** The doc's claimed inventory "42 roadmap units + 12 PHASE2/R15 + 10 deferred = 64" overstates the roadmap units by 4 (actual roadmap rows = 38; 38+12+10 = 60).

| Verdict | Claimed ("§4 Verdict counts" and FINAL_READINESS §2, both repeated) | Actual (each row once, at-time/first-listed reading) | Actual (current-state/second reading where dual) |
|---|---|---|---|
| PASS | 33 | **40** | 35 |
| PARTIAL PASS | 18 | **16** | 17 |
| FAIL | 4 | **1** (WAL current-state) | 2 (WAL + deps-cleanup-at-HEAD) |
| NOT IMPLEMENTED | 0 | **0** | 0 |
| NOT VERIFIED | 0 standalone | 0 (one dual row: R15 indicator battery "PASS at time / NOT VERIFIED now") | 1 |
| BLOCKED | 1 ("counted within PARTIAL" — double-counted by the doc's own footnote) | 0 standalone (dual rows: W5 roadmap + PHASE2-W5 "PASS at time / BLOCKED now") | 2 |
| NOT APPLICABLE | 3 | **3** (W3.7, Vitest, trigram) | 3 |
| **Total** | 58 (+1 double-counted = 59) ≠ 64 claimed | **60** | **60** |

**Discrepancy explanation [VERIFIED against the doc's own text]:** (a) the claimed FAIL=4 includes the **phase-level** "Phase-2-as-deliverable at HEAD" verdict from §1 — not a task row; (b) the claimed PARTIAL=18 decomposition ("12 + 6") lists **7** items; (c) BLOCKED is double-counted inside PARTIAL per the doc's own footnote; (d) the 64-unit denominator itself is inflated by 4 vs the actual 60 rows. The doc's "at `b34d5b8` the equivalent tally would be 51 PASS / 9 PARTIAL / 0 FAIL / 3 N-A" (= 63) also fails to reconcile mechanically against the 60 rows.

### 8.3 Scorecard denominators — `ASAS_CRM_FINAL_READINESS_ASSESSMENT.md`

- 12 engineering areas scored 0–100; weighted overall **60/100 at HEAD, 78/100 at `b34d5b8`** (equal weights — arithmetic on the 12 published scores is consistent with the printed totals to rounding). Phase 1 completion 100% = "15/15 units (6/6 workstreams + 9/9 deliverables)" — a different denominator from PHASE_COMPLETION_STATUS's Phase-0 "11/11 items" (both internally documented; not contradictory, but noted as differing denominators).
- "Phase 2 completion (engineering executed) ~94%" is a **judgment blend, not a mechanical count** — no counting rule over the 60 rows (or the claimed 64) yields 94% (e.g., (33+18+4)/64 = 86%; 33/60 = 55%; 51/64 = 80%). **[VERIFIED non-mechanical]** — flag for anyone citing it as a statistic.

---

## §9 Audit-claims cross-check list (repo/git-state claims made by the three audit docs)

From `ASAS_CRM_INDEPENDENT_AUDIT_REPORT.md`, `ASAS_CRM_REMAINING_DEFECTS_REGISTER.md`, `ASAS_CRM_FINAL_READINESS_ASSESSMENT.md` (all in `693bff9`; plus the four phase-status-audit docs in `753d115`). Status: ✔ = verified by this agent this session; ▲ = consistent/plausible, not re-verified; ✖ = inaccurate as stated.

| # | Claim (source) | Status | Finding |
|---|---|---|---|
| 1 | HEAD at audit = `753d115…`, 303 commits, single branch, no remote, clean tree (INDEP §subject) | ✔ | 303 at `753d115`; 304 at `693bff9`; branch/remote/tag/stash verified empty |
| 2 | `b34d5b8` = R15, 2026-11-02 00:39:06 (all docs) | ✔ | exact |
| 3 | `753d115`: 103 files, +8,164 lines, zero modifications/deletions (INDEP §3.1) | ✔ | exact |
| 4 | Bare-UUID message; zero worklog references (`grep -c` = 0) (INDEP §3.1/ND-A5) | ✔ | `grep -cE "ffa3a843\|753d115\|d8685017\|693bff9" worklog.md` → 0; worklog = 4,770 lines (one doc says 4,771 — off by one) |
| 5 | Contents class "(1) 5 resurrected zombies… (2) 6 abandoned files + 40 evidence screenshots… (3) 18 template files (17 shadcn + 2 hooks)… (4) 4 docs + 2 screenshots" (INDEP §3.1) | ✖ | Actual: **26** ever-deleted resurrected files (they missed `r10-seed-won.ts` entirely and classified the also-resurrected `api/route.ts`, `tailwind.config.ts`, 17 `ui/*`, 2 hooks as mere "template scaffold"); **64** orphan screenshots (not 40 — the 40 came from the first audit's miscount 19+9+12 vs actual 19+26+19); "18 files (17+2)" arithmetic = 19 items. Directionally right, numerically wrong |
| 6 | "~30 ever-deleted∧in-HEAD files" violating D-040 (FINAL_READINESS §1) | ✖ | Actual: **60** sweep hits at HEAD (26 new + 34 pre-adjudicated at `b34d5b8`); "~30" matches neither |
| 7 | tsc = 20 errors at HEAD, all in `753d115` files; "tsc 0 was true at every documented round close; 753d115 alone broke HEAD" (INDEP §3.7/T-1.1) | ✔ | I measured exactly 20; all 17 error FILES absent at `b34d5b8` (`git cat-file -e`). Sub-decomposition slightly off (14× TS2307 + 1× TS2339 in scaffold, not "15× TS2307") |
| 8 | i18n zombie: ~1,013 keys/lang; modular 1,877 keys; strict subset; 864 missing (46%) (INDEP §3.2) vs "662 unique keys missing" (T-5.8) | ✔/▲ | 1,013 ✔ (counted); 1,877 ✔ (5,631 domain key-lines ÷ 3 langs); 864 = 1,877−1,013 ✔ arithmetic; the 849/2,055 render-sites and 662-unique figures are the audit's static analysis **not re-verified**; the 864-vs-662 difference (dictionary-diff vs render-site scan) is never reconciled inside the docs |
| 9 | 5 live importers of `@/lib/i18n`, incl. `store.ts:10` (INDEP §3.2) | ✔ | exactly 5 exact-string importers found |
| 10 | `26d253e` deleted "all 5 (3,412 lines)" (PHASE_COMPLETION §1; REMAINING_WORK R-02) | ✔ | `26d253e` deleted 6 files; the 5 zombie files = 3,253+64+35+47+13 = **3,412 lines exactly** |
| 11 | `a3a2c27` deps cleanup "15 removed, 19 files deleted" real (INDEP §3.7) | ✔ | commit body: "deps cleanup (15 removed, 19 dead files…)… stale r10-seed-won.ts deleted" |
| 12 | R13-class root cause "sandbox re-provisions untracked state at session boot — commit `e2ebf7f`" (INDEP §3.1/HEALTH §2) | ✔/✖ | The commit is **`e2eb6f7`** (Oct 20 23:19) — the audit's hash "e2ebf7f" is a typo; the quoted root-cause text is otherwise verbatim ✔ |
| 13 | `evidence/` = 18 dirs, 155 PNGs; `download/` = 85 entries, 1,299 PNGs (INDEP §2) | ✔ | at `753d115`: 19 dirs − independent-audit = 18 ✔; 160 tracked PNGs − 5 = 155 ✔; download 85/1,299 ✔ exact |
| 14 | Live DB: 0 rows, 30 tables, no `_prisma_migrations`, WAL off (INDEP §3.4; T-7.2–7.4) | ▲/✖-stale | **Not re-verified**; and the DB was re-provisioned again at 14:00 Nov 2 (mtime) — after the audit — so these claims describe a superseded state. The earlier phase-status-audit saw a *different* DB (Oct-2-era, 7 users/44 leads) — evidence of a reset *between* the two audits |
| 15 | Phase-status-audit's "36 untracked paths / 0 modified tracked" | ✔ | Reconciles exactly: 26 resurrected + 7 orphans + 3 evidence dirs = 36 at session open (§3.8) |
| 16 | Statistics summaries (42/11/3/17/1; 33/18/4/0/3; 64-unit inventory; ~94%) | ✖ | §8 reconciliation: true counts 50/14/2/18/1 over 85 IDs; 40/16/1/3 over 60 rows; 94% non-mechanical |
| 17 | "No legitimate source-code change after b34d5b8" (mission expectation, echoed by both audits' causal picture) | ✔ | §1.4 — purely additive diff; 26/26 purity-identical; 0 improvements |
| 18 | Recovery = "one session" (sweep + runbook + re-verify) closing ND-A1…A5 + R-E1…E3 (INDEP §7; DEFECTS §summary) | ✔ as plan | Consistent with my §7 recommendation; note their sweep list (5+6+18 files) is incomplete — the correct sweep list is 26+5(+2) files (this report §3/§4) |

**Claims about `b34d5b8`/`753d115`/D-040/R13 specifically:** items 1–4, 7–13, 15, 17 above. Summary: the audits' *causal* analysis is correct and matches my independent forensics; their *file-level inventories and summary statistics* are under-counted/sloppy (items 5, 6, 16) and one commit hash is mistyped (item 12).

---

## §10 Verdict

1. **Contamination confirmed, fully characterized, and 100% purity-proven.** `753d115` is the environment's fifth resurrection wave, committed by the platform's session-snapshot mechanism; **26/26 resurrected files are blob-identical to every documented deletion-parent**; the further 7 never-tracked files are abandoned working-session debris; the 64 orphan PNGs are unreferenced artifacts; the only legitimate content in either post-reference commit is **audit documentation** (6 files in `753d115`, 11 in `693bff9`). **No legitimate source-code change exists after `b34d5b8`** — the reference state is fully recoverable by a single forward corrective commit. **[VERIFIED]**

2. **Chain of custody is clean and simple:** `b34d5b8` → `753d115` → `693bff9`, no other refs, no rewrite signatures, no remote — the contamination is contained in exactly one commit's additions. **[VERIFIED]**

3. **Root cause is environmental, not human/engineering:** the sandbox's session-boot re-provisioning (R13 class, root-caused at `e2eb6f7`) + the platform's UUID auto-commit; the webDevReview cron is excluded as author (reaped; timing signature is session-end, not 15-min cadence). The standing cron-law conflict (P14 terminal-end vs per-session recreation "system mandate") remains an open owner decision (R-06/R-E6). **[INFERENCE, strongly evidenced; cron exclusion VERIFIED]**

4. **Recommended action:** targeted corrective commit per §7 (git rm 26+5+2 (+64 PNGs disposition), preserve the 17 audit deliverables, conventional commit + worklog entry, D-041 restart protocol for the 4 deleted routes, then the R13 runbook + re-verification). Alternatives rejected with reasons (§7.2). No history rewrite, no reset, no revert, no force push — none are needed.

5. **Prior-audit corrections for the record:** the true sweep list is 26 resurrected files (not 5+18), the orphan-PNG count is 64 (not 40), the sweep total at HEAD is 60 (not ~30), the test inventory is 85 IDs/70 rows with verdicts 50/14/2/18/1 (not 42/11/3/17/1 = 74), the task inventory is 60 rows with 40/16/1/3 at-time (not 64 units with 33/18/4/3), the R13 root-cause commit is `e2eb6f7` (not "e2ebf7f"), and the briefing's "62 test items" figure is untraceable. The 34 pre-existing sweep hits at `b34d5b8` (22 owner-sanctioned Phase D restorations + 12 R14-adjudicated inert tmp-scripts) are reference-state, not contamination — but the "inert tooling" carve-out contradicts D-041's letter and merits a Principal decision.

---

*Investigation boundary honored: read-only git forensics; zero mutating git operations; zero working-tree modifications (sole exception: this report file, explicitly authorized); no build; no DB seeding or probing; no secrets read (`.env` examined by mtime only); no evidence files created. All command outputs cited above are reproducible from the repository as of 2026-11-02.*
