# ASAS CRM — PHASE 2.1 — MASTER REMEDIATION ROADMAP

**Principal Architect / Engineering Director** · 2026-11-02
**Baseline**: `dff2d6e` (sixth resurrection wave swept 30/30 purity-proven; env re-recovered 17/17 migrations + D12 + seed; tsc=0/lint=0; server clean).
**Method**: six-agent parallel Wave-0 investigation (W0-A1…W0-A6, all read-only, evidence-verified) → this reconciled register → implementation waves → verification.

---

## 0. Reconciled baseline verdict (vs legacy audit scores)

The legacy audit scores (UI/UX 48, Data Integrity 55, Code Quality 65, Perf 62, Testing 15/20) were taken at a contaminated/weaker HEAD. The Wave-0 investigation of the **recovered** baseline finds:

- **UI/UX ≈ 80-85/100 already** (the P1/P2 remediation of the prior waves landed: 0 hex colors, logical-property discipline, RTL stack complete, 12/12 skeleton+empty states, 44px touch targets, zero console errors live). Remaining work is polish, not structure.
- **Security 82→~90 achievable** with 5 small fixes; authorization layer is genuinely strong (68/70 routes behind one chokepoint, byte-identical 404s for foreign records, no raw SQL, live-verified negatives).
- **Database structurally healthy** (17/17, zero FK violations, D12 enforced, disciplined FK-action three-tier policy) with narrow latent seams.
- **The two real structural debts**: (1) zero executable tests — quality rests on a manual 7-gate protocol; (2) perf ceilings of the one-bundle SPA + a handful of JS-side aggregations.

No P0 findings. 7 P1 · ~20 P2 · ~25 P3 (deduplicated across agents).

---

## 1. Remediation register

Statuses: NOT STARTED → IN PROGRESS → IMPLEMENTED → TESTED → VERIFIED | BLOCKED | DEFERRED.
"TA" = task agent (P = Principal, A1…A6 = lanes). Effort S/M/L.

### WAVE 1 — Critical data & security foundation

| ID | Pri | Defect (origin) | Root cause / evidence | Fix | TA | Effort | Status |
|---|---|---|---|---|---|---|---|
| W1-1 | P1 | SavCase orphaned on lead merge (A2#1) | `merge/route.ts:127-133` re-points 9 child tables but not `SavCase.leadId` (FK is SET NULL → silent detach) | add `savCase.updateMany` in merge tx | P | S | NOT STARTED |
| W1-2 | P1 | Money guard mis-scaled + negative money accepted (A2#2, A4#3) | `optionalNumber` has no min → reservation amount/deposit & opp value accept negatives; payments epsilon `1e-9` below DZD float noise → false 422 | shared `money` schema (min 0, max 1e10) on all amount fields; epsilon → 0.01; integer-DZD validation | P | S | NOT STARTED |
| W1-3 | P1 | AuditLog gaps on 9 mutating endpoints (A6#2) | convert / tags POST+DELETE / match / present / opps POST / tasks POST / lead-tasks POST / visits POST log activity-only or nothing | add `logAudit` (tags: at least Activity) | P | S | NOT STARTED |
| W1-4 | P2 | Payment TOCTOU race (A4#5) | remaining computed outside write tx (`finance/payments/route.ts:49-87`) | re-read installment + recompute inside tx | P | S | NOT STARTED |
| W1-5 | P2 | Immortal holds via nullable `expiresAt` (A4#2) | POST /api/reservations accepts null; sweeper only matches `< now` | server default from `reservations.defaultExpiryDays` org setting | P | S | NOT STARTED |
| W1-6 | P2 | Multipart buffers before size check (A3#4) | `req.formData()` reads all before 8MB cap | reject `Content-Length` > cap pre-parse | P | S | NOT STARTED |
| W1-7 | P3 | Create-time `ownerId` not MANAGER-gated (A3#6) | POST /api/leads accepts any ownerId while PATCH gates reassignment | align to D-GOV-5 law | P | S | NOT STARTED |
| W1-8 | P2 | Demo-mode hardening (A3#1, #5) | quick-login roster unauthenticated by flag default; deploy assertion absent | boot-time non-localhost bind fail-fast + deploy-check doc | P | S | NOT STARTED |

### WAVE 2 — Database & architecture

| ID | Pri | Defect | Evidence | Fix | TA | Effort | Status |
|---|---|---|---|---|---|---|---|
| W2-1 | P1 | Zero CHECK constraints on enum vocabularies (A2#3) | 1/31 tables has CHECK; ~25 loose TEXT enums | CHECKs for closed vocabularies — Postgres chain via ALTER; SQLite subset via rebuild migration (scoped to Law: Lead/Reservation/User/Opportunity/Apartment/Installment) | P | M | NOT STARTED |
| W2-2 | P2 | Document polymorphic link orphans on opp delete (A2#4) | no FK on (entityType,entityId); opp DELETE ignores docs | audited delete/reassign in guarded DELETE + orphan sweep probe | P | S | NOT STARTED |
| W2-3 | P2 | Dashboard JS-side aggregation + unbounded takes (A6#5, A2#7) | incentives/wonOpps full scans reduced in JS | `_sum`/`groupBy` + take caps | P | S | NOT STARTED |
| W2-4 | P2 | SAV list full-table scan (A6#4) | `sav/route.ts:131` no take, JS sort+slice | SQL ordering + pagination | P | M | NOT STARTED |
| W2-5 | P2 | Analytics monthlyTrend JS bucketing (A6#12) | full-window findMany | SQL groupBy | P | S | NOT STARTED |
| W2-6 | P2 | Client type mirror drift (A1#3, A6#6) | `SavListResponse` missing page/pageSize; Lead omits 7 wire fields | fix drift + derive key DTO types from serializers | P | S | NOT STARTED |
| W2-7 | P2 | Query log always on (A1#6, A2#8) | `db.ts:7-11` `log:['query']` unconditional | gate on NODE_ENV | P | S | NOT STARTED |
| W2-8 | P3 | Matching engine stale rows + N+1 (A2#10) | 20 sequential upserts; fallen rows never pruned | single-tx prune + batched upserts | P | S | NOT STARTED |
| W2-9 | P3 | No `server-only` guard (A1#11) | layering protected by convention only | import "server-only" in db.ts + session.ts | P | S | NOT STARTED |
| W2-10 | P3 | Lead lacks `convertedAt` (A2#15) | derivable only via Activity | add column + stamp in convert tx | P | S | NOT STARTED |
| W2-11 | P3 | Stale reservation-guard comment (A2#18) | says "no DB unique index" while D12 exists | comment fix | P | S | NOT STARTED |

### WAVE 3 — CRM business logic

| ID | Pri | Defect | Evidence | Fix | TA | Effort | Status |
|---|---|---|---|---|---|---|---|
| W3-1 | P2 | Bulk reassign doesn't cascade opportunities (A4#1) | single PATCH moves opps in-tx; `leads/bulk` moves only lead.ownerId | shared `reassignLeadCascade()` helper for both | P | S | NOT STARTED |
| W3-2 | P2 | Reassign orphans open tasks & visits (A4#6) | only opps cascade | cascade OPEN tasks (+ future visits) in same tx | P | M | NOT STARTED |
| W3-3 | P2 | `nextFollowUpAt` never auto-advances (A4#4) | contact activity stamps lastContactAt only; journey urgency +100 forever | clear/roll nextFollowUpAt on contact activity & task completion | P | M | NOT STARTED |
| W3-4 | P3 | Task status machine ungated (A4#7) | DONE→OPEN silently legal | `TASK_TRANSITIONS` matrix (DONE/CANCELLED terminal; reopen = owner) | P | S | NOT STARTED |
| W3-5 | P3 | Reservation money-trail not atomic (A4#8) | lifecycle logs written AFTER tx returns | move logActivity/logAudit inside tx | P | S | NOT STARTED |
| W3-6 | P3 | Duplicated stage literals (A4#9) | HOT_STAGES ×2, RESERVE_STAGES vs PRE_BOOKING_STAGES | hoist to constants.ts | P | S | NOT STARTED |
| W3-7 | P3 | Closure UI re-implements lifecycle law (A4#10) | `deal-economics-closure.tsx:79-81` literals | derive from RESERVATION_LIFECYCLE | P | S | NOT STARTED |
| W3-8 | P3 | Convert-created opps lack `stageChangedAt` (A4#11) | convert tx omits stamp | one line in create data | P | S | NOT STARTED |
| W3-9 | P3 | Visit completion doesn't advance lead (A4#12) | first-touch visit leaves NEW + lastContactAt null | stamp lastContactAt + NEW→CONTACTED in visit tx | P | S | NOT STARTED |

### WAVE 4 — UI/UX engineering (polish wave — foundations verified strong)

| ID | Pri | Defect | Evidence | Fix | TA | Effort | Status |
|---|---|---|---|---|---|---|---|
| W4-1 | P2 | Typography dual vocabulary (A5#1) | 423 arbitrary `text-[13px]` vs 340 token uses | codemod px→crm tokens + worst-file normalization | A5' | M | NOT STARTED |
| W4-2 | P2 | i18n parity unguarded (A5#2) | silent lang→fr→key fallback | dev-time missing-key guard ×3 langs | P | S | NOT STARTED |
| W4-3 | P2 | Control-height sprawl (A5#3) | h-7×41 / h-8×113 / h-9×100 / h-10×8 | height token law + normalize toolbar controls | A5' | M | NOT STARTED |
| W4-4 | P3 | Arabic money-unit leak `"DA"` (A5#4) | targets-section.tsx:444 | use moneyUnit() | A5' | S | NOT STARTED |
| W4-5 | P3 | Settings error state conflates lock/error (A5#5, A1#12) | hand-rolled panel for any isError | reuse ErrorState | A5' | S | NOT STARTED |
| W4-6 | P3 | Card padding drift (A5#6) | p-3×13 / p-4×7 / px-4×24 | normalize panel body padding | A5' | S | NOT STARTED |
| W4-7 | P3 | Pagination copy-paste (A1#5) | audit-view duplicates leads/pagination verbatim | shared TablePagination | A5' | S | NOT STARTED |
| W4-8 | P3 | pad()/date helpers ×3 (A1#8) | 3 local copies vs canonical lib/format | consolidate into lib/format.ts | P | S | NOT STARTED |
| W4-9 | P3 | Hooks exported from dialog files (A1#9) | useInvalidateVisits etc. | move to visits/hooks.ts | A5' | S | NOT STARTED |
| W4-10 | P3 | MoneyField caret jump (A5#7) | grouping-boundary edits | caret preservation fix | A5' | M | NOT STARTED |
| W4-11 | P3 | Dormant primitives physical props (A5#8) | ui/pagination.tsx, calendar.tsx | logical properties | A5' | S | NOT STARTED |

### WAVE 5 — Performance, testing & cleanup

| ID | Pri | Defect | Evidence | Fix | TA | Effort | Status |
|---|---|---|---|---|---|---|---|
| W5-1 | P1 | Zero automated tests (A1#1, A6#1) | no test files/framework/script; pure engines untested | vitest: unit (journey/constants/metrics/phone/csv/validation/matching) + visibility-scope + API contract (cookie fixtures) | A6' | M | NOT STARTED |
| W5-2 | P1 | All 12 views statically imported (A6#3) | crm-app.tsx:19-33 | React.lazy per view in switch | P | S | NOT STARTED |
| W5-3 | P2 | Unknown /api/* returns HTML 404 (A6#10) | Next default page | JSON-envelope not-found handler | P | S | NOT STARTED |
| W5-4 | P2 | Notifications duplicate re-scan per poll (A2#6) | 5k-lead scan per user-minute | 60s TTL cache for duplicate aggregate | P | S | NOT STARTED |
| W5-5 | P3 | Dead exports ~25 (A1#7) | zero-reference symbols | delete/un-export sweep (shadcn exempt) | P | S | NOT STARTED |
| W5-6 | P3 | Dashboard mega-handler (A1#2) | 632 lines, 12 sections | extract section builders + shared opp select | P | M | NOT STARTED |
| W5-7 | P3 | Visit PATCH inline state machine (A1#4) | 390-line route | extract guards to visit-gate.ts | P | M | NOT STARTED |
| W5-8 | P3 | Copilot limiter keyed per-lead not per-user (A3#3) | global throttle cross-agent | key by (user, lead) | P | S | NOT STARTED |

### Explicitly deferred (owner decision / out of scope)

- D-1: Journey-CSV export reintroduction (P2R C-3 — Option B spec preserved; product decision).
- D-2: User.email per-org uniqueness change (single-tenant now; documented login-key decision).
- D-3: FTS5 search, AuditLog retention policy, durable rate-limit store, session revocation epoch — production-scale items, documented.
- D-4: Full mutating E2E + multi-user concurrency suite (proper QA window; P2R C-4).
- D-5: `next build` production run (sandbox-forbidden — AGENTS.md:13).

---

## 2. Execution sequence & coordination

1. **Principal implements Waves 1-3 + backend items of 2/5** (src/app/api/**, src/lib/**, prisma/**) — sequential, personally reviewed diffs.
2. **Parallel agent tracks after backend lands** (no shared files): A5' = UI polish track (src/components/** only); A6' = vitest track (tests/** only, package.json script pre-added by Principal).
3. **W5-2 lazy loading** (crm-app.tsx) executed by Principal after A5' completes (same tree).
4. **Wave 6**: tsc + lint + full API battery + browser pass (agent-browser, 5 viewports, FR/AR/EN) + vitest run.
5. Acceptance gates per mission §7; statistics only from mechanical inventories.

## 3. Acceptance criteria (per gate)

- **Architecture**: no unresolved P1/P2 from register; duplication items closed or justified.
- **Database**: W1/W2 fixes verified by targeted probes; migration chain consistent (`migrate status` clean); no data loss (seeded dev only).
- **Security**: W1 fixes live-verified (negative probes); no new exposure.
- **CRM logic**: W3 fixes verified by API-level transition tests (vitest + live battery).
- **UI/UX**: W4 items browser-verified at 1440/1280/768/390/375; RTL unchanged-clean.
- **Code quality**: tsc 0, lint 0, vitest green, no new `any`/`@ts-ignore`.
- **QA**: regression battery re-run; console clean; screenshots captured.
