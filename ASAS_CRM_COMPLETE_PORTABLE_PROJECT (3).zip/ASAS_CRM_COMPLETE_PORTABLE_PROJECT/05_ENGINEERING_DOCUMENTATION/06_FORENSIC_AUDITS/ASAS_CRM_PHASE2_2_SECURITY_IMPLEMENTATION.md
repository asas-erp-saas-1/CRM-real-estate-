# ASAS CRM — PHASE 2.2 SECURITY IMPLEMENTATION

**Task owner:** Principal · **Status: VERIFIED (positive + negative evidence)**

## 1. The authorization model applied to the new surface

`GET /api/customers` composes the **existing D-021 visibility law** (no new
authorization logic — one law, every surface):

| Role | Customers visible | Enforcement |
|---|---|---|
| MANAGER+ | whole org | `leadScope() → undefined` (org fragment) |
| SALES_AGENT | own + unassigned pool | `leadScope() → OR[ownerId=me, ownerId=null]` through the contact's 1:1 lead |
| FIELD_REP | customers of visits on assigned projects | `leadScope() → visits.some(project.assignments.some(userId))` |

The list is read through `contact.lead` — the scope fragment lands on the LEAD
predicate, so a foreign contact is invisible, not merely unlisted. The 360
surface is the existing `GET /api/leads/:id` (scoped findFirst → 404
byte-identical to nonexistent, no existence leak).

## 2. New enforcement point

`GET /api/leads?unassigned=1` (the intake-pool facet) is **MANAGER+-gated**:
below MANAGER → `403 FORBIDDEN_ROLE` (the pool is half an agent's world, not a
filter on it — the visibility.ts comment law).

## 3. Negative test evidence (executed this session)

| Probe | Expected | Actual |
|---|---|---|
| `GET /api/customers` no cookie | 401 NO_SESSION | **401 NO_SESSION** ✓ |
| Agent Amine `GET /api/customers` | scope `own`, zero foreign rows | **scope "own", 5 rows — 5/5 owned by Amine** (cross-agent reads impossible) ✓ |
| FIELD_REP Mounia `GET /api/customers` | project-derived set | **10 rows, all visit-derived** ✓ |
| Agent `GET /api/leads?unassigned=1` | 403 | **403** ✓ |
| Manager `GET /api/leads?unassigned=1` | scoped pool only | isolated exactly the synthetic pool lead ✓ |

## 4. Contract regression cover (added to the suite)

`tests/contract/api.test.ts` now asserts: the customers 401 gate, gate-ordering
(validation never bypasses auth), the manager envelope (scope org, KPI
consistency `live ≤ total`, `idle ≤ total`), row contract (leadId + stage +
liveValue present), and idle-facet consistency (`idle=1` total ≤ KPI idle).

## 5. Frontend honesty

- The owner filter group renders only for MANAGER+ (server ignores the param
  below MANAGER anyway — UI hiding is presentation, never authorization).
- The scope caption comes from the **API's scope echo**, never a client role
  guess (the dashboard scope-row law).

## 6. Not changed (deliberate)

Session, cookie signing, login, RBAC matrix, RLS documentation, audit logging
paths — Phase 2R/2.1 states remain binding; no security regression surface
was introduced (the new route performs zero writes → zero audit events owed).
