# ASAS CRM — Acceptance Test Results

**Audit date:** 2026-11-02 · **Mode:** independent, read-only, evidence-recorded.
**Legend:** PASS = expected behavior observed · FAIL = deviation from expectation · BLOCKED = cannot execute in current environment · N-A = not applicable to this platform/scope.
**Environment during tests:** dev server `next dev` :3000 (turbopack), git HEAD `753d115`, live DB `db/custom.db` = 30 tables / **0 rows** / no `_prisma_migrations`, `.env` = DATABASE_URL only (no `ASAS_SESSION_SECRET`, no `ASAS_DEMO_MODE` → demo mode defaults ON in dev).

---

## T-1 — Test & build verification (Section 9 of the mandate)

| Test ID | Command / scenario | Expected (per delivery claims) | Actual | Verdict | Evidence |
|---|---|---|---|---|---|
| T-1.1 | `bunx tsc --noEmit` | 0 errors ("tsc 0" claimed at every round close) | **Exit 1 — 20 errors**: 15× TS2307 missing modules (`@radix-ui/react-accordion|aspect-ratio|collapsible|context-menu|hover-card|menubar|navigation-menu|radio-group|toast|tooltip`, `embla-carousel-react`, `vaul`, `input-otp`, `react-resizable-panels`) in template `src/components/ui/*`; 1× TS2339 `slots` in `input-otp.tsx:47`; 4× broken symbols in journey orphans (`journey-stats.ts:21,124,134` — `JourneyStatEntry`/`facts`/`LoadedJourneyEntry`; `journey-worklist.ts:26` — `isJourneyStalled`); 1× `journey-stage-chip.tsx:29` — `openJourneyFocus` missing from store | **FAIL at HEAD** (claim was TRUE at `b34d5b8`: all 20 files absent there — `git ls-tree b34d5b8` per file; introducer = `753d115` alone) | command output this session; Auditor F classification |
| T-1.2 | `bunx eslint .` | 0 errors | **Exit 0, zero output** — reproducible | **PASS** (caveat: config disables ~30 rules incl. `no-unused-vars`/`no-redeclare` → gate is blind to the zombie class; 0 in-code `eslint-disable` cheats) | command output ×2 runs |
| T-1.3 | `next build` (deterministic inference — build execution forbidden by house law) | buildable production artifact | **FAIL — build aborts**: no `ignoreBuildErrors` in next.config.ts (verified removed at H2 `ae9357f`), tsconfig includes `src` → 20 tsc errors fail the default build type-check. CI static gate (`bun run typecheck`) equally red | **FAIL at HEAD** | next.config.ts read; tsc output; ci.yml read |
| T-1.4 | Unit/integration/E2E suites | none exist (house law "no test code in this environment", documented with the live-protocol substitute) | **Confirmed**: no test script in package.json; no vitest/jest/playwright config or `*.test.ts`/`*.spec.ts` anywhere; `tests/` holds 3 manual shell scripts only | **N-A by documented policy** — flagged as the systemic enabler of the silent HEAD regression | package.json; repo-wide glob; TEST_STRATEGY.md:4 |
| T-1.5 | `scripts/validate-seed.py` (safe, read-only) | 0 parse / 0 FK / 0 order violations, counts MATCH | **PASS: rows 606 across 26 tables · parse 0 · FK 0 · order 0 · canonical counts MATCH** | **PASS** | executed this session |
| T-1.6 | Reproduce prior gate entries | per-round "tsc 0 · eslint 0" claims | All located & quoted: worklog :4492 (H2), :4709 (FINAL), :4718 (R14), :4744 (PHASE2), :4760/:4767 (R15); golden-path E2E entry :4706 with 32-PNG receipt corpus (`download/qa-final/`) | **PASS as historical records — not reproducible at HEAD** | worklog.md citations |

## T-2 — Unauthenticated API security matrix (live probes, healthy window)

All expected: **401 JSON `{"error":…,"code":"NO_SESSION"}`** with byte-identical body (fail-closed).

| Test ID | Endpoint | Actual (healthy window) | Verdict |
|---|---|---|---|
| T-2.1 | GET /api/dashboard | 401 NO_SESSION JSON | PASS |
| T-2.2 | GET /api/leads | 401 NO_SESSION JSON | PASS |
| T-2.3 | GET /api/reservations | 401 NO_SESSION JSON | PASS |
| T-2.4 | GET /api/users | 401 NO_SESSION JSON | PASS |
| T-2.5 | GET /api/sav | 401 NO_SESSION JSON | PASS |
| T-2.6 | GET /api/finance/installments | 401 NO_SESSION JSON | PASS |
| T-2.7 | GET /api/analytics | 401 NO_SESSION JSON | PASS |
| T-2.8 | GET /api/notifications | 401 NO_SESSION JSON | PASS |
| T-2.9 | GET /api/targets | 401 NO_SESSION JSON | PASS |
| T-2.10 | GET /api/audit | 401 NO_SESSION JSON | PASS |
| T-2.11 | GET /api/auth/session | 200 `{"user":null,"organization":null,"demoUsers":[]}` (by design, empty DB) | PASS |
| T-2.12 | POST /api/auth/login (empty body) | 422 VALIDATION_ERROR (zod; not 403 — origin checked separately) | PASS |
| T-2.13 | POST /api/reservations (unauth) | 401 (requireUser first statement) | PASS |
| T-2.14 | PATCH /api/opportunities/xyz (unauth) | 401 | PASS |
| T-2.15 | GET /api (junk endpoint from zombie commit) | **200 `{"message":"Hello, world!"}` unauthenticated** — exposes no data but is an unguarded scaffold route | **FAIL (P3)** — junk endpoint should not exist |

## T-3 — CSRF / origin enforcement (live)

| Test ID | Scenario | Expected | Actual | Verdict |
|---|---|---|---|---|
| T-3.1 | POST /api/auth/logout, `Origin: https://evil.example` | 403 | **403 `{"code":"CROSS_ORIGIN_BLOCKED"}`** | PASS |
| T-3.2 | POST /api/auth/logout, same-origin Origin | 200 | **200 `{"ok":true}`** | PASS |
| T-3.3 | POST /api/auth/login, same-origin, empty body | not origin-blocked (422 validation) | **422 VALIDATION_ERROR** | PASS |

## T-4 — Security headers (live)

| Test ID | Check | Expected (W1.3 claim) | Actual (`curl -sI /`) | Verdict |
|---|---|---|---|---|
| T-4.1 | X-Content-Type-Options | nosniff | **nosniff** | PASS |
| T-4.2 | Referrer-Policy | strict-origin-when-cross-origin | **strict-origin-when-cross-origin** | PASS |
| T-4.3 | CSP / X-Frame-Options | absent by documented trade-off (preview iframe) | absent — matches documented decision | PASS (documented) |
| T-4.4 | X-Powered-By | (not claimed) | **present: `X-Powered-By: Next.js`** | FAIL (P3, new finding) |

## T-5 — Runtime behavior at HEAD (first-hand browser session)

| Test ID | Scenario | Expected | Actual | Verdict |
|---|---|---|---|---|
| T-5.1 | Load `/` fresh session | app shell/login renders, zero console errors (claim) | **"Build Error" dialog on load: `Export isJourneyStalled doesn't exist in target module` — `./src/lib/server/journey-worklist.ts (23:1)`; console carries the same error** | **FAIL** — "zero console errors" claim refuted at HEAD (203 error occurrences in dev.log) |
| T-5.2 | Dismiss overlay → login surface | renders | **Renders fully translated (FR)**: "Connexion / Accédez à votre espace de travail / Adresse email / Mot de passe / Se connecter / Mot de passe oublié ?" + marketing panel + © line; persona grid cleanly unmounted (demoUsers=[]) | PASS |
| T-5.3 | Language switch FR → ع | Arabic dictionary + RTL | **Full AR: "تسجيل الدخول / ادخل إلى مساحة عملك / تغيير اللغة"; `document.documentElement.dir="rtl"`, `lang="ar"`, title intact** | PASS (auth.* keys are in the zombie dictionary) |
| T-5.4 | Language switch AR → EN | LTR English | **`dir="ltr"`, form re-renders** | PASS |
| T-5.5 | Failed credentials login (test@asas.dz / wrongpass) | graceful error feedback, no crash | **Toast appeared with Close affordance (auto-dismissed per Sonner default); form intact, values retained; no crash** | PASS |
| T-5.6 | Mobile 390×844 (AR RTL) | scrollWidth exactly 390, no horizontal overflow | **`scrollWidth` = 390 = clientWidth, dir=rtl** | PASS |
| T-5.7 | Mobile 375×812 (EN LTR) | no overflow | **scrollWidth = 375** | PASS |
| T-5.8 | i18n raw-key rendering at HEAD | all keys resolve (claim: zero raw keys) | **REFUTED at HEAD**: static analysis = 849/2,055 render sites raw (41.3%), 662 unique keys missing (46.0%), all 12 views affected; live-confirmed class via `nav.journey/nav.finance/nav.sav`, `shell.skipToContent` (code-level) — login surface unaffected (auth.* in zombie) | **FAIL** (P1) |

## T-6 — Dev-server API poisoning (first-hand reproduction)

| Test ID | Scenario | Expected | Actual | Verdict |
|---|---|---|---|---|
| T-6.1 | GET /api/leads (unauth) BEFORE touching broken route | 401 JSON | **401 JSON NO_SESSION** (healthy window, early session) | PASS |
| T-6.2 | GET /api/journey/export (the orphan route) | 401 JSON (any protected route shape) | **500** (broken import `isJourneyStalled` → module resolution failure at request time) | **FAIL** (P1) |
| T-6.3 | GET /api/leads (unauth) AFTER T-6.2 | 401 JSON | **500 HTML dev-error page** — global degradation persists; HTML leaks absolute paths/stack (dev-only); fail-closed preserved (no data exposed) | **FAIL** (P1 — new phenomenon class documented by Auditor C, reproduced by lead auditor) |

## T-7 — Database acceptance (read-only probes)

| Test ID | Check | Expected (per claims) | Actual | Verdict |
|---|---|---|---|---|
| T-7.1 | Live DB schema = 30 models | 25–30 tables | **30 tables, 1:1 with schema models** | PASS |
| T-7.2 | `_prisma_migrations` present, 17 applied | "migrations 17/17 applied" | **ABSENT — db-push provenance; 0 of 17 recorded; `migrate deploy` on this file would fail** | **FAIL (environment)** |
| T-7.3 | D12 partial unique indexes in live DB | "indexes present in live DB" (probe-passed on a copy at commit time) | **MISSING** — `sqlite_master` query by exact index names returns empty; Reservation carries only the 5 Prisma @@index entries | **FAIL (environment)** |
| T-7.4 | WAL mode ON | "WAL mode ON" | **`journal_mode=delete`** — REFUTED for current file (was true at commit time per snapshot receipt) | **FAIL (environment)** |
| T-7.5 | Census 8/43/21/46/8/23/18/185/132/2 | seeded dataset | **0 rows in all 30 tables** — DB empty; seed claims verified STATICALLY instead (seed.ts source counts match: 8/43/21/46/8/23/18/183/85 + tail = post-seed probe residue documented) | **BLOCKED (empty DB)** |
| T-7.6 | `PRAGMA foreign_key_check` / `integrity_check` | 0 violations / ok | **0 rows / ok — VACUOUS with 0 data rows (honest classification: not evidence of integrity, only structural sanity)** | PASS (structural only) |
| T-7.7 | Migration chain #17 content | per-apartment AND per-opportunity partial uniques | **VERBATIM VERIFIED** — `Reservation_apartment_live_hold_uq` ON (`apartmentId`) WHERE status IN ('ACTIVE','CLOSURE_REQUESTED'); same for `opportunityId` | PASS |
| T-7.8 | Supabase PG chain | 26 tables/65 FKs; CHECKs from constants; RLS default-deny | **VERIFIED**: 0001 = 26 CREATE TABLE + 65 FK; 0002 = 33 CHECK matching constants.ts vocabularies + 1 partial unique; 0003+0004 = 104+26 CREATE POLICY + 26+4 ENABLE RLS; default-deny org-claim `USING (orgId = jwt.org_id)` quoted on 5 tables | PASS (structural) |
| T-7.9 | PG chain D12 parity | both live-hold indexes on PG path (schema.postgres.prisma:611-617 claims parity) | **GAP: only per-apartment index exists (`0002:68-70`); per-opportunity index absent from the entire PG chain** | **FAIL (new P2 defect)** |
| T-7.10 | Schema↔live-DB column drift | none | **None** — all probed critical columns present (`closureRequestedById`, `stageChangedAt`, Arabic aliases, `role`, `orgId`) | PASS |
| T-7.11 | Seed FK-closure validation | 0 violations | **validate-seed.py: 606 rows, 0 parse/0 FK/0 order, counts MATCH** | PASS |
| T-7.12 | Stale handoff docs | seed.sql = 511 rows (claim) | **seed.sql = 606 rows; two handoff docs still claim 511** | FAIL (P3 documentation) |

## T-8 — Authenticated workflow & role-based security (Sections 6–7 of the mandate)

| Test ID | Scenario | Verdict | Rationale |
|---|---|---|---|
| T-8.1–T-8.16 | The full 16-step golden path (login → create lead → assign → qualify → opportunity → interaction → follow-up task → appointment → visit → pipeline → reservation → timeline → cross-account permissions → dashboard) | **BLOCKED (all)** | Live DB has **0 users** — no identity can authenticate (quick-login requires existing user rows; credentials require seeded hashes). Creating test identities requires executing the R13 recovery runbook (reseed), which is remediation work explicitly outside the audit mandate ("Do not fix issues during this audit"; "If a verification requires unsafe production access, mark it BLOCKED"). The substitute evidence: the code paths for all 16 steps verified statically with file:line (Auditor E, 12/12 areas) + the at-time receipts (worklog :4706 golden-path E2E, 32 screenshots; 333-probe standing matrix; 13-assertion R15 security matrix) — genuine but not re-executable today. |
| T-8.17 | Positive/negative RBAC live tests (agent→finance 403, ghost-404 IDOR, privilege escalation, org isolation) | **BLOCKED** | Same cause. Static verification: role gates located on every claimed route (`requireUser("MANAGER")` ×16 sites, ADMIN gates, ROLE_CEILING ×3); ghost-404 byte-identical by construction (single throw path verified); zero UI-only authorization across ~60 mutation routes. At-time receipts: WS-S 448-check battery, 325→333-probe matrix. |

## T-9 — Architecture acceptance spot-checks

| Test ID | Claim | Verdict | Evidence |
|---|---|---|---|
| T-9.1 | lib/server shared modules exist + imported | PASS | 7 modules with importers listed (e.g. `leads.ts` ← 19 routes; `visit-facets.ts` ← dashboard:27 + visits:24) |
| T-9.2 | Circular dependencies = 0 | PASS | Tarjan SCC over full src/ import graph = 0 cycles |
| T-9.3 | `: any` / `as any` / `@ts-ignore` = 0 | PASS | 0 real occurrences (9 raw matches are comments); caveat: `noImplicitAny:false` weakens strict (tsconfig:13) |
| T-9.4 | Guard coverage 69/73 | PASS (70/74) | 74 route files; 70 call requireUser; exceptions = login/session/logout (by design) + junk `/api` (FAIL, T-2.15) |
| T-9.5 | Error handling uniform | PASS | `fail()` in 73/74 routes; ApiError 55; parseBody 40; 2 minor ad-hoc 404s (documents thumb/file) |
| T-9.6 | Stage-constant dedup killed 8 re-declaration sites | **PARTIAL** | 6 server sites adopted; **2 client-side survivors found: `analytics-kpi.tsx:42`, `pipeline-view.tsx:47`** |
| T-9.7 | `opportunityInclude` dedup | **PARTIAL** | helper exists+used; include object still declared in both opportunities routes (:19/:33) |
| T-9.8 | Dead code removed | **FAIL at HEAD** | 10 dead files + 17 dead ui components + 2 dead hooks committed at 753d115; 4 dead parallel UI implementations (toast/sidebar/placeholder/stage-chip) |

## T-10 — UI/UX acceptance (structure-level; text layer covered by T-5.8)

| Test ID | Claim | Verdict | Evidence |
|---|---|---|---|
| T-10.1 | Binding design system | PASS | DESIGN_SYSTEM.md binding header; 61 oklch tokens × light+dark; 7-tier semantic type scale (globals.css:30-70) |
| T-10.2 | 12 views + role-gated nav | PASS | 15 view files (12 main + 3 helpers); minRole/hideFor gating verified (finance/analytics/audit/settings MANAGER+; leads/pipeline hideFor FIELD_REP) |
| T-10.3 | Leads row nesting a11y fix | PASS | lead-row.tsx:91-109 — tr no longer role="button"; interactive children isolated with stopPropagation; mobile LeadCard mirrors |
| T-10.4 | Touch targets ≥44px | PASS | `.crm-hit` floors (globals.css:612-651: ≥44px on coarse pointers) + `max-md:size-11` on shell/sidebar controls |
| T-10.5 | Kanban mini-map | PASS | pipeline-view.tsx:419-449 — chip row, IntersectionObserver, RTL-native scrollIntoView |
| T-10.6 | TrendChip + never-truncate fix | PASS | kpi-card.tsx:83-105 (honest absence, points-vs-%, aria) + :133-142 flex-wrap fix with documenting comment |
| T-10.7 | document.title per view | PASS (3/12 raw at HEAD) | shell.tsx:112-115 via VIEW_META ×12 views; journey/finance/sav titles raw via zombie |
| T-10.8 | Journey UX wired to live APIs | PASS | journey-view → /api/journey; performance → /api/journey/stats; rail derives client-side; **UI never calls the broken /api/journey/export** |
| T-10.9 | Evidence corpus authenticity | PASS | download/ = 1,299 PNGs across 85 entries; qa-final 41, qa-phase2 13, qa-r15 9; spot-checks plausible; NOTE: qa-master is flat (before/after mixed filenames, not subfolders) — minor corpus-hygiene note |

---

## Summary counts

| Verdict | Count | Notable |
|---|---|---|
| PASS | 42 | incl. 3 live security probes, 2 live responsive checks, seed validator, migration verbatim checks |
| FAIL | 11 | T-1.1 tsc@HEAD · T-1.3 build@HEAD · T-2.15 junk endpoint · T-4.4 X-Powered-By · T-5.1 console errors · T-5.8 raw keys · T-6.2 broken route · T-6.3 global poisoning · T-7.2 migrations table · T-7.3 D12 live indexes · T-7.4 WAL · T-7.9 PG index gap · T-7.12 stale docs (P3) |
| PARTIAL | 3 | T-9.6 / T-9.7 / T-10.7 |
| BLOCKED | 17 | T-7.5 (empty DB) + T-8.1–T-8.17 (all authenticated testing) |
| N-A | 1 | T-1.4 (no test runner by documented policy) |

**Reproduction statement:** the previously reported test results are NOT reproducible at HEAD today for the runtime classes (empty DB; broken route poisoning; raw keys) and ARE reproducible for the static classes (lint, seed validation, schema/migration inspection). All historical gate claims were independently confirmed accurate for their commit timestamps via `git ls-tree` file-presence proof at `b34d5b8`.
