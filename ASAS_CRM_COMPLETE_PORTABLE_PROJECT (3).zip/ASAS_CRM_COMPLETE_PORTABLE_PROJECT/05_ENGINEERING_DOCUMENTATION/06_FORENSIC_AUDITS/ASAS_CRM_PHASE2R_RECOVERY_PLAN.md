# ASAS CRM — PHASE 2R — CONSOLIDATED RECOVERY PLAN

**Mission**: MASTER DELIVERY RECOVERY, SOURCE CODE RESTORATION, ENGINEERING VALIDATION & ACCEPTANCE
**Author**: Principal Engineering Recovery Lead
**Date**: 2026-11-02 (Phase 2R session)
**Status**: APPROVED FOR CONTROLLED EXECUTION (central review of six-agent investigation complete)
**Inputs**: Lead-level forensics + six independent read-only agent investigations (Task IDs 1-a … 1-f), each report graded VERIFIED/INFERENCE/NOT-VERIFIED with command evidence:

- `ASAS_CRM_PHASE2R_GIT_FORENSIC_REPORT.md` (Agent 1)
- `ASAS_CRM_PHASE2R_BUILD_LOCALIZATION_REPORT.md` (Agent 2, Part 1)
- `ASAS_CRM_PHASE2R_API_RECOVERY_REPORT.md` (Agent 3, Part 1)
- `ASAS_CRM_PHASE2R_DATABASE_ENVIRONMENT_REPORT.md` (Agent 4)
- `ASAS_CRM_PHASE2R_ENGINEERING_REGRESSION_REPORT.md` (Agent 5)
- `ASAS_CRM_PHASE2R_BROWSER_QA_REPORT.md` (Agent 6, Part 1 — broken-state baseline)

---

## 1. Verified situation (executive)

| # | Finding | Verdict | Proof |
|---|---|---|---|
| F-1 | Verified reference = `b34d5b8` (R15 completion, 2026-11-02 00:39). HEAD = `693bff9`. Chain: `b34d5b8` → `753d115` → `693bff9`, no intervening commits. | VERIFIED | git log/rev-parse |
| F-2 | `753d115` (UUID message, author `Z User <z@container>`, 07:26:23) = fifth documented **resurrection wave**: 26 ever-deleted files re-added **blob-identical** to every documented deletion-parent (purity 26/26), + 5 superseded never-tracked journey working copies, + 2 never-tracked tooling scripts, + 64 orphan QA PNGs, + 4 historical audit docs. +8,164 lines. | VERIFIED | blob-hash purity proofs (Agent 1 §4) |
| F-3 | `693bff9` (UUID message, 12:25:26) = the independent audit's own deliverables (5 `.md` + 5 PNG + 1 HTML) — legitimate, preserved. | VERIFIED | Agent 1 §2 |
| F-4 | Diff `b34d5b8`→HEAD = **100% additive** (114 entries, 0 M, 0 D). The verified reference state is intact underneath — every D1–D14 change and every architecture invariant exists verbatim at HEAD. | VERIFIED | git diff --name-status (Agents 1, 2, 5) |
| F-5 | Exactly **20 TypeScript errors**, 100% confined to files added by `753d115` (14× TS2307 purged deps + 1× TS2339 scaffold + 5× stale-journey-API). The `b34d5b8` tree type-checks **exit 0** (empirically exported via git archive). | VERIFIED | tsc runs (Agents 2, 3, 5) |
| F-6 | Localization corruption mechanism: resurrected monolith `src/lib/i18n.ts` (1,013 keys/lang) **shadows** the live modular `src/lib/i18n/` (1,877 keys/lang) via file-before-folder resolution, at BOTH the tsc layer and the runtime layer. 864 keys/lang dark = **46.0%** — matching the audit's claim. Strict-subset property holds (0 monolith-only keys) → deletion loses **zero** keys. | VERIFIED | traceResolution + Bun.resolveSync + key census (Agents 2, 5) |
| F-7 | `/api/journey/export` 500 = compile-time breakage in a **never-wired, never-tracked stale working copy** (`isJourneyStalled` never existed in any committed engine). One hit **globally poisons the API surface** until restart (verified live). Zero live UI callers. | VERIFIED | reproduction + import archaeology (Agent 3; Agent 6 reproduced once) |
| F-8 | All reported environment blockers are **R13-class sandbox-reset phenomena, zero source-code issues**: empty DB (30 tables × 0 rows; integrity ok; zero structural drift), missing `ASAS_SESSION_SECRET` (dev-safe ephemeral fallback active by design), missing `_prisma_migrations` (all 17 unapplied per migrate status), D12 indexes absent from the active DB (present in migration #17 `20261102000000_phase2_d12_live_hold_unique`), `journal_mode=delete` (SQLite default — the audit's "WAL disabled" is a loosely-worded SQLite journal_mode observation vs the repo doc's WAL posture claim; **no PostgreSQL concept involved**). | VERIFIED | Agent 4 (read-only attestation §10) |
| F-9 | DB identity: local sandbox dev SQLite (`file:/home/z/my-project/db/custom.db`), git-ignored, demo workspace. **NOT production.** Supabase/PostgreSQL = documented optional deployment path only (commented template lines). | VERIFIED | Agent 4 §2 |
| F-10 | Root cause of contamination: sandbox **session-boot re-provisioning** resurrects deleted files (R13 class, root-caused historically at `e2eb6f7`), then the **platform's UUID session-snapshot auto-commit** sweeps all untracked debris into a commit (21 such UUID commits in history). Cron excluded (all jobs dead per AGENTS.md P14; scheduler list currently empty — verified). | VERIFIED | Agent 1 §5 |
| F-11 | D1–D14 Phase-2 engineering improvements: **14/14 PRESERVED** at HEAD (file:line evidence; per-file diffs vs reference empty). All 9 architecture invariants intact. | VERIFIED | Agent 5 §3–§4 |
| F-12 | Statistics reconciliation (mission §13): previous audit's task inventory truly 60 rows (not 64; claimed verdict sums 58≠64); test inventory truly 70 rows / 85 IDs (claimed sums 70≠62 — the 62 was untraceable; true verdicts 50 PASS / 14 FAIL / 2 PARTIAL / 18 BLOCKED / 1 N/A). Corrected tables published in the final report. | VERIFIED | Agent 1 §8 |

## 2. Recovery decisions (Principal rulings, evidence-based)

### D-R1 — Recovery method: selective file removal + one conventional corrective commit
Per the D-040/D-041 protocol (P32/P33/P34 precedent) and the mission's Phase-1 options. **Rejected**: `git revert 753d115` (would delete the legitimate audit deliverables it carries), history rewrite / `reset --hard` / `clean -fd` (forbidden; also pointless — the tracked tree is otherwise identical to the reference).

### D-R2 — The 33 additive CODE files are removed (`git rm`), restoring exact source equivalence to `b34d5b8`
- 26 purity-proven resurrection zombies: `src/lib/i18n.ts`; `src/app/api/route.ts` (unauthenticated "Hello, world!" scaffold — deleted twice before); 17 stock `src/components/ui/*` scaffold components + `src/hooks/use-mobile.ts` + `src/hooks/use-toast.ts` (deleted at `a3a2c27` after their 15 deps were purged — 14× TS2307 prove the deps are gone); `tailwind.config.ts` (retired at `ae9357f`); `src/components/crm/view-placeholder.tsx` + `src/app/api/leads/check-duplicates/route.ts` + `src/app/api/properties/unit-types/route.ts` (deleted at P34/bb13147 with documented purity proofs); `tmp-scripts/r10-seed-won.ts`.
- 5 superseded never-tracked journey orphans: `src/app/api/journey/export/route.ts`, `src/lib/server/journey-worklist.ts`, `src/lib/server/journey-stats.ts`, `src/lib/server/journey-facet.ts`, `src/components/crm/journey-stage-chip.tsx` (mtimes Nov 1 16:13–17:28; logic ships embedded in the live routes; stale imports carry 5 tsc errors; zero live importers).
- 2 never-tracked tooling scripts: `tmp-scripts/census.ts`, `tmp-scripts/recent-audits.ts`.
- **Deletion is side-effect-free**: the exhaustive import sweep (Agent 5 §8) shows the ONLY live-code dependency on the additive set is `@/lib/i18n`, which re-binds to the modular `i18n/index.ts` (all five consumed symbols verified present; zero key loss; +864 keys/lang restored).

### D-R3 — `/api/journey/export` disposition: DELETE (Option A), documented deviation
The mission's Phase-4 text ("do not disable the endpoint") was written under the audit's assumption of a legitimate broken feature. Verified evidence establishes: the route was never tracked in any commit; `isJourneyStalled` never existed in any committed engine; zero live UI callers; the capability is absent from the verified reference state; and the identical defect class (never-wired routes) was closed by binding project law **D-042** with the authenticated-404 verification precedent (P34 deleted exactly such routes twice). The **verified defect** — global API poisoning — is fully repaired by removing the compile-broken zombie route; the live journey API contract (`/api/journey`, `/api/journey/stats`) is preserved byte-identical and re-verified. Option B (repair-to-working: 3 precise edits to `journey-worklist.ts` against `JOURNEY_STAGE_SLA_DAYS`) is fully specified in Agent 3's report §8 as the post-recovery path **should the owner want the capability** — to be done as wired feature work (UI button + i18n keys + audit keys per D-042), not as recovery. This deviation is flagged prominently in the final report.

### D-R4 — Evidence preservation: ALL docs/evidence files from both UUID commits are KEPT
The mission orders the audit evidence preserved. The 64 orphan QA PNGs (qa-continue/qa-r13/qa-unify) are historical session evidence — the project's own convention deliberately commits evidence directories; D-040 governs deleted-source resurrection, not evidence. The 4 historical audit `.md` docs stay untouched (historical record, referenced by the independent audit). **Net effect on the repository after recovery: source tree ≡ `b34d5b8`; documentation/evidence = superset (reference + both audit sessions).**

### D-R5 — Environment recovery via the sanctioned R13 runbook (operations, dev-sandbox only)
Sequence: `bun run db:snapshot` (insurance) → recreate `db/custom.db` via `bunx prisma migrate deploy` (fresh file, 17/17 migrations incl. D12 partial unique indexes + bookkeeping) → `bun run db:seed` (synthetic demo data only — the mission's "synthetic data in isolated test environments" sanction; the DB is verifiably a local demo workspace, NOT production) → append fresh `ASAS_SESSION_SECRET` to git-ignored `.env` (dev secret generated per the documented runbook — never committed, never printed) → restart dev server with cleared `.next` (kill by PID from `ss -tlnp` + `rm -rf .next` + relaunch — the D-041 route-deletion protocol, which also clears the deliberately-poisoned end-state left by Agent 6). **WAL/journal-mode: DOCUMENTED ONLY, not modified** (mission Phase-5 D; the finding is precisely classified as SQLite `journal_mode=delete` vs the architecture doc's WAL posture — P3 ops action recorded in `ASAS_CRM_PHASE2R_ENVIRONMENT_BLOCKERS.md`).

### D-R6 — Commit protocol: one conventional, reviewed, locally-reversible commit
The mission says "do not create automatic commits; present the full reviewed diff for approval." The platform's UUID auto-commit will otherwise sweep the staged deletions unreviewed at session end — recreating the exact governance failure under remediation. Resolution: execute the deletions, personally review the complete staged diff, make **one** conventional commit (`app: p2r — …`, full evidence in message per P32/P33/P34 precedent), present the full diff in the final report, and note the commit is locally reversible (`git revert`) pending user acceptance. No push (no remotes exist).

### D-R7 — No new cron jobs
The system template's 15-minute webDevReview job is **NOT created** — explicitly forbidden by the mission §17 and by the project's binding P14 law (AGENTS.md line 21: all scheduled automation terminally ended, user-confirmed 2026-10-07/08).

## 3. Implementation sequence

| Step | Action | Owner | Depends on |
|---|---|---|---|
| S0 | Safe checkpoint: branch `p2r-checkpoint` at `693bff9` (non-destructive ref; no commit created) | Principal | — |
| S1 | `git rm` the 33 code files (staged deletions; working tree clean of zombies) | Principal | S0 |
| S2 | Personal review of the full staged diff (`git diff --cached --stat` + per-file) | Principal | S1 |
| S3 | Gates: `bunx tsc --noEmit` → 0 errors; `bun run lint` → 0; resurrection sweep re-run → only the 34 pre-existing adjudicated reference hits remain | Principal | S1 |
| S4 | i18n validation: re-run `tmp-scripts/p22-i18n-audit.ts` → missing = 0 ×3 langs; key census = 1,877 ×3 restored | Principal | S1 |
| S5 | Environment recovery (R13 runbook, D-R5): snapshot → recreate DB (migrate deploy 17/17) → seed → secret → restart with cleared `.next` | Principal | S1 (source clean first) |
| S6 | API verification: `/api/auth/session` 200 + populated demoUsers; login 200; `/api/journey` + `/api/journey/stats` healthy JSON with auth; `/api/journey/export` → honest 404 (never 500); no cross-route poisoning (re-probe after hitting the dead URL); D12 indexes present in `sqlite_master`; `migrate status` 17/17 | Principal | S5 |
| S7 | Independent browser verification (Agent 6 final pass): 12 views × FR/AR/EN zero raw keys, dir flips, 5 viewports (1440×900, 1280×800, 768×1024, 390×844, 375×812) no overflow, console clean, golden path + RBAC negatives, before/after screenshot pairs | Agent 6 | S5, S6 |
| S8 | Reports: GIT_RECOVERY_REPORT, ENVIRONMENT_BLOCKERS, EXECUTION_LOG, FINAL_RECOVERY_REPORT (incl. statistics reconciliation + verdict); append Part-2 verification results to the four Part-1 agent reports | Principal | S3–S7 |
| S9 | Worklog append (AGENTS.md documentation duty) + conventional commit (D-R6) | Principal | S8 |

## 4. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Deletion breaks a hidden importer | Exhaustive import sweep already done (Agent 5 §8: only `@/lib/i18n`, re-bind verified by execution); tsc=0 + dev-server boot + browser pass are the safety gates |
| Stale `.next` serves deleted routes (D-041 protocol) | S5 restart explicitly kills next-server by PID + `rm -rf .next` |
| Auto-commit races the recovery | All changes staged + committed in one reviewed conventional commit inside this session |
| Environment reset recurs (R13 class) | Documented in EXECUTION_LOG + ENVIRONMENT_BLOCKERS with the runbook; checkpoint branch preserves rollback |
| Seeding produces wrong data | Canonical `db:seed` (D-016); residue counts compared to the documented business baseline (8/43/21/23/161/46/3/8/4/18) |
| The 34 pre-existing sweep hits at `b34d5b8` (22 owner-sanctioned Phase-D restorations + 12 R14-adjudicated tmp-scripts) are mistaken for new zombies | Explicitly documented as adjudicated reference-state content — NOT in recovery scope (functional equivalence to the reference is the objective) |

## 5. Acceptance criteria (the seven gates)

- **G1 Repository integrity**: suspect commit investigated (F-2); strategy justified (D-R1); legitimate work preserved (F-4, D-R4); user changes preserved; audit documents preserved; recovery diff personally reviewed; no destructive commands.
- **G2 Build**: 20 TS errors resolved by removal (no suppression, no strictness change, no `@ts-ignore`, no deletions of working functionality); tsc = 0; lint = 0; production `next build` remains **forbidden by sandbox law** (AGENTS.md line 13) — the standing validation gates (tsc/lint/dev-server/browser) substitute, documented.
- **G3 Localization**: modular dictionaries restored as the single source (monolith removed); zero competing architecture; zero key loss (+864/lang); raw keys eliminated from the 12 audited views (browser-verified); RTL/LTR verified in-browser ×3 languages.
- **G4 API**: global poisoning eliminated; live journey endpoints healthy; `/api/journey/export` dispositions per D-R3 with honest 404 + no cross-route failures; unauthorized requests rejected with 401 JSON on live routes; controlled error contract re-verified.
- **G5 Engineering integrity**: D1–D14 preserved (F-11); schema/migrations intact; security invariants intact; CRM workflows intact; no critical regressions (browser golden path).
- **G6 Governance**: D-040/D-041/D-042 complied with (33 swept with purity proofs); R13 runbook respected; no environment artifacts remain tracked in source; conventional commit; worklog appended; preventive recommendation recorded (UUID auto-commit governance hole → ND-A5 closure).
- **G7 Environment readiness**: empty-DB finding verified + remediated (dev sandbox only); secret requirement documented + provisioned (dev); D12 verified applied; WAL finding precisely classified (documented, unmodified); blocked tests unblocked where environment-gated; production actions documented WITHOUT execution.

A successful source-code recovery does **not** imply production readiness — the final verdict will state this explicitly.
