# ASAS CRM — Phase 2R Recovery: Build & Localization Investigation Report

**Agent:** 2 (Task ID 1-b) — TypeScript, Build & Localization Recovery Investigation
**Date:** 2026-11-02
**Subject state:** git `main` @ `693bff9` (src tree identical to `753d115`; `693bff9` added docs/evidence only)
**Reference state:** `b34d5b8` ("feat: R15 — Phase 2+ four-indicator round", 2026-11-02 00:39)
**Mode:** READ-ONLY investigation. Zero source modifications, zero git state changes, zero commits, no `bun run build` (AGENTS.md:13), no DB/env touches. Scratch computation confined to `/tmp`.

> **PART 1 — INVESTIGATION (pre-recovery state). Implementation results will be appended by the Principal after the controlled recovery.**

**Legend:** ✅ VERIFIED (command evidence cited) · ⚠️ INFERENCE (reasoned, not directly executed) · ❓ NOT VERIFIED.

---

## §1 Executive summary

1. **`bunx tsc --noEmit` reports EXACTLY 20 errors (exit 1), in 17 files — every one of them added by contamination commit `753d115`, every one absent at reference `b34d5b8`.** ✅ The empirical proof is stronger than a file-list argument: the full `b34d5b8` tree (exported read-only to `/tmp`, repo untouched) type-checks with **exit 0**. Reference tsc state = clean; contamination alone broke HEAD. (§2, §3)
2. **Error composition:** 15 errors from 19 stock-scaffold files (14× TS2307 missing modules + 1× TS2339 cascade) whose 14 dependencies were purged from `package.json` at `a3a2c27` — which deleted **both** the deps **and** the files (verified in that commit's diff); `753d115` re-added the files *without* the deps. Plus 5 errors from journey-refactor orphans written against a stale `@/lib/journey` API (2× TS2724 + 1× TS2353 + 1× TS2345 + 1× TS2339 stale store action). All 24 implicated files are dead code with **zero live importers** (verified by rg over src/). (§2)
3. **Localization corruption confirmed and quantified.** With both `src/lib/i18n.ts` (3,253-line monolith) and `src/lib/i18n/` (modular tree) present, TypeScript **and** Bun's runtime resolver both bind `@/lib/i18n` to the **monolith** (file-before-folder — proven empirically via `tsc --traceResolution` and `Bun.resolveSync`). The monolith carries **1,013 keys/lang**; the live modular system carries **1,877 keys/lang**; the monolith is a **strict subset** (0 monolith-only keys), so **864 keys/lang (46.0%) are dark at HEAD**. Deleting the monolith loses zero keys. (§4)
4. **All 12 views render raw keys at HEAD** (verified per-view plus component subtrees; 3 sidebar nav labels and 3 of 12 `document.title`s raw; raw keys inside aria-labels). The login surface survives only because `auth.*` happens to live in both dictionaries. (§5)
5. **The recovery is deletion-shaped, not repair-shaped.** Blob-hash purity proofs (the D-040 law's required pre-deletion evidence) are already in hand: all 19 scaffold files are byte-identical to their pre-`a3a2c27` selves; all 5 resurrected files are byte-identical to their pre-deletion parents (`bb13147^`/`9d635d7^`/`ee04e81^`); the 5 journey orphans have no history at all before `753d115`. A `/tmp` post-recovery simulation of the i18n completeness gate returns **missing = 0 ×3 langs**. (§9)
6. **`bun run lint` → exit 0, zero output** — lint is green at HEAD and was green at reference; it is structurally blind to the zombie class (27 rules off, incl. `no-unused-vars`/`no-redeclare`). (§8)

---

## §2 The 20 TypeScript errors — full forensic table

Full raw output preserved at `/tmp/tsc-full-output.txt` (21 lines; line 20 is the continuation of error #19's message). Command: `bunx tsc --noEmit` (exit 1).

**Classification tally** ✅: 14× TS2307 + 1× TS2339 (scaffold class, 15 errors / 15 files) + 5 errors (orphan class: 1× TS2339 store-action + 2× TS2724 + 1× TS2353 + 1× TS2345 in 3 files) = **20 errors / 17 files**.
*(Note: the Principal's brief and the audit's T-1.1 prose say "15× TS2307"; the exact split is 14× TS2307 + 1× TS2339-cascade. Total is 20 either way.)*

### 2A — Scaffold class (15 errors, stock shadcn template files)

| # | File (line,col) | Code | Missing module | Origin | Root cause | Remediation |
|---|---|---|---|---|---|---|
| 2 | `src/components/ui/accordion.tsx` (4,37) | TS2307 | `@radix-ui/react-accordion` | added `753d115` (original add `7a7e255`; deleted `a3a2c27`) | dep purged at `a3a2c27` (package.json −15, bun.lock −61, files deleted); file resurrected without dep | **DELETE file** (D-040) |
| 3 | `src/components/ui/aspect-ratio.tsx` (3,39) | TS2307 | `@radix-ui/react-aspect-ratio` | same | same | **DELETE** |
| 4 | `src/components/ui/carousel.tsx` (6,8) | TS2307 | `embla-carousel-react` | same | same | **DELETE** |
| 5 | `src/components/ui/collapsible.tsx` (3,39) | TS2307 | `@radix-ui/react-collapsible` | same | same | **DELETE** |
| 6 | `src/components/ui/context-menu.tsx` (4,39) | TS2307 | `@radix-ui/react-context-menu` | same | same | **DELETE** |
| 7 | `src/components/ui/drawer.tsx` (4,43) | TS2307 | `vaul` | same | same | **DELETE** |
| 8 | `src/components/ui/hover-card.tsx` (4,37) | TS2307 | `@radix-ui/react-hover-card` | same | same | **DELETE** |
| 9 | `src/components/ui/input-otp.tsx` (4,43) | TS2307 | `input-otp` | same | same | **DELETE** |
| 10 | `src/components/ui/input-otp.tsx` (47,61) | TS2339 | `slots` does not exist on type `{}` | same | **cascade** of #9: `OTPInputContext` (line 46) resolves to `{}` when the module is missing, so `inputOTPContext?.slots[index]` (line 47) fails | **DELETE** (fixes both #9 and #10) |
| 11 | `src/components/ui/menubar.tsx` (4,35) | TS2307 | `@radix-ui/react-menubar` | same | same | **DELETE** |
| 12 | `src/components/ui/navigation-menu.tsx` (2,42) | TS2307 | `@radix-ui/react-navigation-menu` | same | same | **DELETE** |
| 13 | `src/components/ui/radio-group.tsx` (4,38) | TS2307 | `@radix-ui/react-radio-group` | same | same | **DELETE** |
| 14 | `src/components/ui/resizable.tsx` (5,37) | TS2307 | `react-resizable-panels` | same | same | **DELETE** |
| 15 | `src/components/ui/toast.tsx` (4,34) | TS2307 | `@radix-ui/react-toast` | same | same | **DELETE** |
| 16 | `src/components/ui/tooltip.tsx` (4,35) | TS2307 | `@radix-ui/react-tooltip` | same | same | **DELETE** |

**Supporting evidence (all ✅):**
- `git show a3a2c27 -- package.json` removes exactly 15 deps: 10 radix (`react-accordion|aspect-ratio|collapsible|context-menu|hover-card|menubar|navigation-menu|radio-group|toast|tooltip`), `embla-carousel-react`, `input-otp`, `react-resizable-panels`, `vaul`, `tailwindcss-animate`. 14 of these are imported by the erroring files (the 15th, `tailwindcss-animate`, is only referenced by the resurrected `tailwind.config.ts` — a CSS plugin, hence no TS2307).
- `git show --stat a3a2c27` shows the same commit deleting the files: 17 `src/components/ui/*` (incl. `chart.tsx`, `sidebar.tsx`, `toaster.tsx` which produce no tsc errors but are the same class), `src/hooks/use-mobile.ts`, `src/hooks/use-toast.ts`, `tmp-scripts/r10-seed-won.ts`.
- HEAD `package.json` still lacks all 14 packages (verified by rg per package — all ABSENT). `753d115` touched neither `package.json` nor `bun.lock` (its only non-src code file is the new `tailwind.config.ts`).
- **Blob purity ✅:** all 19 scaffold files (17 ui + 2 hooks) are `git hash-object`-identical at HEAD to their `a3a2c27^` (pre-deletion) versions — pure resurrection, zero content evolution.

### 2B — Journey-orphan class (5 errors, abandoned refactor working copies)

| # | File (line,col) | Code | Message (abridged) | Origin | Root cause | Remediation |
|---|---|---|---|---|---|---|
| 1 | `src/components/crm/journey-stage-chip.tsx` (29,49) | TS2339 | `openJourneyFocus` does not exist on type `CrmState` | added `753d115` (no earlier history — `git log --all` shows only `753d115`) | component written against an older/parallel store API; live `CrmState` (store.ts:136-183) has no `openJourneyFocus` action (it has propertiesFocus/pipelineFocus/financeFocus/savFocus tokens instead) | **DELETE file** — zero importers (rg over src/ finds none) |
| 17 | `src/lib/server/journey-stats.ts` (21,8) | TS2724 | `@/lib/journey` has no exported member `JourneyStatEntry` | added `753d115` (no earlier history) | stale API: live `src/lib/journey.ts` (747 lines) exports `computeJourney/computeUrgency/computeJourneyStats` with an **inline anonymous** entry type (`journey.ts:590-600`), not a named `JourneyStatEntry` | **DELETE file** — zero live importers (see below) |
| 18 | `src/lib/server/journey-stats.ts` (124,7) | TS2353 | `facts` does not exist in `LoadedJourneyEntry` | same | **cascade** of #17: `LoadedJourneyEntry extends JourneyStatEntry` (line 36) loses all base members when the base is unresolved, so the `entries.push({facts, journey, urgency, …})` literal fails | DELETE (fixed by #17's deletion) |
| 19 | `src/lib/server/journey-stats.ts` (134,37) | TS2345 | `LoadedJourneyEntry[]` not assignable to `computeJourneyStats`'s inline entry param | same | **cascade** of #17 (the expected param type in the error message is verbatim the live signature at `journey.ts:590-600`) | DELETE |
| 20 | `src/lib/server/journey-worklist.ts` (26,3) | TS2724 | `@/lib/journey` has no exported member `isJourneyStalled` | added `753d115` (no earlier history) | stale API: live journey engine computes stalls inside `computeJourneyStats` (`JourneyStatsLiveStage.stalled`, journey.ts:536-543); no `isJourneyStalled` export exists | **DELETE file** + its only consumer (below) |

**Live-importer analysis (all ✅, rg over src/):**
- `journey-stage-chip.tsx`: **0 importers**.
- `journey-stats.ts`: **0 importers**. (The only textual match, `src/components/crm/views/journey/journey-performance.tsx:55`, is a React-Query cache key string `queryKey: ["journey-stats"]` — not an import. `journey-performance.tsx` is a live file present at `b34d5b8`, added `23990cf`.)
- `journey-worklist.ts`: imported ONLY by `src/app/api/journey/export/route.ts` — itself a `753d115` orphan (no earlier history: `git log --all` = `753d115` only). No live UI code references `/api/journey/export` (rg exit 1).
- `journey-facet.ts` (also `753d115`, no tsc errors): 0 importers — dead code (audit ND-4).
- `view-placeholder.tsx`, `api/leads/check-duplicates/route.ts`, `api/properties/unit-types/route.ts`, `api/route.ts`: 0 importers / 0 fetch references; the junk `GET /api` returns an unguarded `{"message":"Hello, world!"}` (read at HEAD).

**Runtime consequence (documented by the independent audit; ⚠️ not re-triggered by me):** the export route's broken named import (`isJourneyStalled`) fails at dev-server module resolution — the audit reproduced that one request to `/api/journey/export` poisons every subsequent API request into 500 HTML dev-error pages (their T-6.2/T-6.3; `evidence/independent-audit/poisoned-api-response.html`). Current `dev.log` carries 10 `isJourneyStalled`/`journey-worklist` occurrences (log rotated after the audit's session, which saw 203).

---

## §3 Error-containment proof — "introduced by contamination"

**Claim: every tsc error lives in a file added by `753d115`; zero errors exist in files present at `b34d5b8`.** All ✅:

1. **File-level:** all 17 error files are ABSENT at `b34d5b8` (`git cat-file -e b34d5b8:<path>` per file — 17× ABSENT) and all were added by `753d115` (`git show --name-status 753d115 -- src/` = 29 files, all `A`; the 17 error files are among them — the other 12 additions produce no tsc errors but are the same zombie set).
2. **Tree-level:** `git diff --name-status b34d5b8 693bff9` contains **only `A` entries** (no M, no D — rg for non-`^A` returns nothing): the delta vs reference is **purely additive**, so no reference file's content changed. `store.ts`, `src/lib/i18n/`, `src/lib/journey.ts` are byte-identical between `b34d5b8` and HEAD (`git diff` = 0 lines each).
3. **HEAD vs contamination:** `git diff --name-only 753d115 693bff9 -- src/` = **0 files** — the audit commit `693bff9` added only docs/evidence; the src tree at HEAD *is* the `753d115` src tree.
4. **Empirical reference typecheck:** the full `b34d5b8` tree exported via `git archive b34d5b8` into `/tmp/b34-check` (repo untouched), with `node_modules` symlinked and `next-env.d.ts` copied, type-checks under the project's own tsconfig: **`bunx tsc --noEmit` → exit 0, zero errors.** The reference state was verifiably clean; the 20 errors are 100% attributable to `753d115`.
5. `753d115` totals ✅: 103 files, +8,164 insertions, zero modifications/deletions, bare-UUID message (violates AGENTS.md's "never UUID/noise messages" law), 0 references in the append-only `worklog.md` (rg for `ffa3a843|753d115` → no match) — the governance hole (audit ND-A5).
6. **Breakdown of the 103 files** ✅: 29 src files + `tailwind.config.ts` + 3 tmp-scripts (`census.ts`, `r10-seed-won.ts`, `recent-audits.ts`) + 4 docs/audits status documents + 66 evidence PNGs (`phase-status-audit` 2, `qa-continue` 19, `qa-r13` 19, `qa-unify` 26). *(The Principal's brief said "33 source files": the code-file count is 29 src + 1 tailwind + 3 tmp-scripts = 33 code files.)*

---

## §4 Localization architecture forensics

### 4.1 Resolution-order proof — the monolith shadows the modular system ✅

Both `src/lib/i18n.ts` (3,253 lines) and `src/lib/i18n/index.ts` (94 lines + `types.ts` + 21 `domains/*.ts`) exist at HEAD.

- **TypeScript layer:** `bunx tsc --noEmit --traceResolution` (filtered) shows, for **every** importer:
  `Loading module as file / folder, candidate module location '/home/z/my-project/src/lib/i18n' … File '/home/z/my-project/src/lib/i18n.ts' exists - use it as a name resolution result.` → `Module name '@/lib/i18n' was successfully resolved to '/home/z/my-project/src/lib/i18n.ts'`. The file is tried **before** the folder's `index.ts` (bundler moduleResolution; tsconfig:16 `moduleResolution: "bundler"`).
- **Runtime layer (Bun):** `Bun.resolveSync("@/lib/i18n", "/home/z/my-project/src")` → `/home/z/my-project/src/lib/i18n.ts`; same for the bare `./lib/i18n` specifier. The runtime binding is the zombie too (corroborated by the audit's live browser evidence class — raw `nav.*` keys visible in the rendered UI).
- At reference `b34d5b8` the monolith **does not exist** (`git ls-tree b34d5b8 -- src/lib/i18n.ts` → empty; only `src/lib/i18n/{index.ts,types.ts,domains/}`) — so at reference, `@/lib/i18n` necessarily binds the modular composition root. ✅

### 4.2 Importer map of `@/lib/i18n` ✅

rg `from ["']@/lib/i18n["']` over src/ → exactly **5 importers**, all currently bound to the zombie:

| Importer | Imports | Binding damage |
|---|---|---|
| `src/lib/client/store.ts:10` | `translate, dirFor,` + types `Lang, TextDir, TranslateFn` | **RUNTIME** — the app-wide `useT()`/`useDir()` (all UI text) |
| `src/lib/format.ts:14` | `type Lang` only | type-only (erased at runtime) |
| `src/components/crm/money-field.tsx:39` | `type Lang` only | type-only |
| `src/components/crm/documents/shared.tsx:13` | `type TranslateFn` only | type-only |
| `src/components/crm/bulk-copilot-dialog.tsx:40` | `type TranslateFn` only | type-only |

No file imports any `@/lib/i18n/` subpath (rg exit 1) → **the entire modular system (index.ts + types.ts + 21 domains) is orphaned at HEAD** — compiled only because tsconfig includes `src`. All 5 importers are byte-identical to their `b34d5b8` selves (purely-additive diff), so deletion of the monolith re-binds them to the modular root with no code change.

### 4.3 Dictionary quantification — monolith vs modular ✅

Scratch counters (bun, `/tmp`): `Object.keys()` on both `dictionaries` exports.

| Dictionary | fr | en | ar | Parity |
|---|---|---|---|---|
| Monolith `src/lib/i18n.ts` | **1,013** | **1,013** | **1,013** | full 3-lang parity inside the zombie |
| Modular `src/lib/i18n/index.ts` (21 domains) | **1,877** | **1,877** | **1,877** | full 3-lang parity |
| **Delta (modular-only = dark at HEAD)** | **864** | **864** | **864** | **46.0% of the live dictionary per lang** |

- **Strict-subset property ✅:** monolith-only keys = **0** for all three langs. The zombie is a strict subset of the modular dictionary → **deleting `src/lib/i18n.ts` loses zero keys** (matches audit ND-A2's "zero key loss — strict-subset property").
- **Lost key families ✅** (top 12 by count): `journey:139, sav:93, visits:86, finance:72, leads:68, oppd:59, fiche:56, audit:47, properties:32, pipeline:30, dash:25, lead:20` — matching the audit's claimed family list (journey 139 / sav 93 / visits 86 / finance 72 / leads 68) exactly.
- **Provenance ✅:** the HEAD monolith is `git hash-object`-identical to the pre-P7-1 file at `97e9c54` (blob `2a3d9f7f…`) and to its pre-P32-deletion parent `ee04e81^`. It is the OLD dictionary, deleted at P26 (de9a3d3) after the 20 domains-absent keys were migrated, resurrected twice since (P31-era env wave, then `753d115`).
- The modular tree follows AGENTS.md invariant #7 ✅ (fr/en/ar side-by-side per domain; e.g. `domains/journey.ts`: `journey.stage.CAPTURED` = "Capturé"/"Captured"/"مُلتقط" at lines 15/177/332; genuine Arabic confirmed in both systems — monolith `auth.password` = "كلمة المرور").

### 4.4 The raw-key rendering mechanism ✅

`src/lib/client/store.ts`:
- `useT()` (store.ts:337-342) binds `translate(lang, key, vars)` imported from `@/lib/i18n` (→ zombie at HEAD) to the persisted `lang` (zustand persist `asas-lang`, fr default).
- Both implementations share the identical fallback chain: `dict[key] ?? dictionaries.fr[key] ?? key` — **a missing key renders the raw key string**. Empirically: `translate("fr","nav.journey")` at HEAD → `"nav.journey"` (scratch run).
- `useDir()` (store.ts:347-349) = `dirFor(lang)`; `useDocumentLangSync()` (store.ts:351-357) sets `document.documentElement.lang` and `.dir`.

Because the zombie is a strict subset, every modular-only key falls through both lookups and renders raw — that is the entire P1 text-layer defect.

---

## §5 The 12 affected views + render-site inventory reconciliation

### 5.1 The 12 views ✅ (from `store.ts` `View`/`VIEWS`, the shell's `VIEW_META`, sidebar-nav)

`dashboard · journey · leads · pipeline · visits · tasks · properties · finance · sav · analytics · audit · settings`
(Hash-routed SPA views; audit T-10.2: "15 view files (12 main + 3 helpers)".)

### 5.2 Per-view raw-key verification ✅ (scratch scanner: static `t("…")`/`labelKey` literals vs the zombie fr dict)

| View | Static t-sites in view surface | Raw at HEAD | Evidence samples |
|---|---|---|---|
| dashboard | 6 + subtree | **AFFECTED** (subtree) | `kpi-card.tsx` `analytics.kpi.vsPrev`; `attention-strip.tsx` 13 raw (`dash.attention.title`, `dash.kpi.unstaffedVisits`…); `right-panels`, `activity-chart`, `pending-incentives-panel`, `recent-leads-table`, `today-panel` |
| journey | 71 | 65 raw | `journey.title`, `journey.perf.tab.*` |
| leads | 31 | 10 raw | `leads.archive.*` family |
| pipeline | 28 | 10 raw | `pipeline.truncated`, `pipeline.hideClosed.*` |
| visits | 26 | 7 raw | `visits.filter.reconfirm*` |
| tasks | 41 | 5 raw | `tasks.reopen*`, `tasks.resetFilters` |
| properties | 18 | 6 raw | `properties.view.grid*` |
| finance | 15 | 12 raw | `finance.call.success`, `finance.attention.title` |
| sav | 7 | 7 raw | `sav.attention.title`, `sav.filter.search`, `sav.rows` |
| analytics | 12 | 1 raw | `analytics.range.covered` |
| audit | 42 + subtree | **AFFECTED** (subtree) | `audit-target-overlay.tsx` 6 raw (`audit.entity.VISIT`, `audit.target.*`) |
| settings | 30 + subtree | **AFFECTED** (subtree) | `export-section.tsx` 8 raw (`settings.export.*`) |

Shell-level (touches every view) ✅: `shell.tsx` 4 raw (`shell.skipToContent`, `journey.title`, `finance.title`, `sav.title` — the latter three via `VIEW_META` → **`document.title = "journey.title — ASAS CRM"` etc., 3 of 12 titles raw**); `sidebar-nav.tsx` 6 raw (`shell.density` family + **`nav.journey`, `nav.finance`, `nav.sav`** — the 3 raw sidebar labels). → **All 12 views affected** (9 directly in their view files; dashboard/audit/settings via their component subtrees; all via the shell).

### 5.3 Reconciliation with the audit's 2,055 / 849 / 662 inventory

| Metric | Independent audit (T-5.8) | My independent scan | Note |
|---|---|---|---|
| Static render sites | 2,055 | **1,959** | methodology variants (my regex: `t("…")` + `labelKey` literals, excluding zombie files + i18n dirs) |
| Raw sites at HEAD | 849 (41.3%) | **768 (39.2%)** | same order, same conclusion |
| Unique raw keys | 662 | **628** | ⚠️ delta = scanner pattern scope (template-literal families, titleKey, zombie-file refs counted differently) |
| Files affected | 81 | **76** | same class |
| Dictionary gap | 864 keys (46.0%) | **864 keys (46.0%)** | **exact match** |
| Lost families | journey 139 / sav 93 / visits 86 / finance 72 / leads 68 | **identical** | **exact match** |

The audit's headline numbers are corroborated within scanner-methodology tolerance; the dictionary-level numbers match exactly. Both scanners agree the login surface is unaffected (`auth.*` exists in the zombie).

**Cross-check with the project's own validator** ✅: `bun tmp-scripts/p22-i18n-audit.ts` (read-only, safe) at HEAD → `files scanned: 334 · static keys referenced: 1,267 · MISSING IN ALL 3 LANGS: 618 · PARTIAL: 0 · 4 enum-completeness gaps` (`role.FIELD_REP`, `visit.status.REJECTED`, `commission.DEVELOPER`, `commission.CLIENT` — all four verified present in the modular dictionary, i.e. the gaps are pure shadowing symptoms).

**Post-recovery simulation** ✅ (scratch scanner with the 29 zombie/scaffold files excluded, keys checked against the modular dictionary): `files 282 · static sites 1,959 · keys missing from modular ×3 langs: 0` → the standing i18n gate returns to **missing = 0 ×3 langs** after the sweep.

---

## §6 RTL / LTR architecture verification

✅ All verified; **the RTL machinery is intact at HEAD — the contamination damages the text *values*, not the direction *plumbing*** (both dictionaries ship identical direction logic):

1. **`dirFor`** — byte-identical implementations in the monolith (`i18n.ts:11-13`) and the modular system (`i18n/types.ts:17-19`): `lang === "ar" ? "rtl" : "ltr"` (fr/en LTR, ar RTL).
2. **`<html>` sync** — `useDocumentLangSync()` (store.ts:351-357), mounted in `CrmShell` (shell.tsx:104), sets `document.documentElement.lang` and `document.documentElement.dir` on every language change; `layout.tsx:47` ships `<html lang="fr" suppressHydrationWarning>`.
3. **RTL CSS** — `globals.css` `[dir="rtl"]` rules: Arabic font stack for body, direction resets for dialogs/inputs/textareas, `.ltr-token` LTR escape hatch (phones/numbers), and lucide icon mirroring (`chevron-left/right`, `arrow-left/right`, `chevron-first/…`).
4. **Logical properties** — `ms-/me-/ps-/pe-/text-start/text-end/start-0/end-0` utilities used across crm components (settings targets-section, bulk-copilot-dialog, team dialogs, etc.).
5. **Runtime evidence** — the independent audit live-verified the login surface in AR (dir=rtl, Arabic fonts, `scrollWidth` exactly 390 at mobile-AR, no overflow; T-5.3/T-5.6). The AR *dictionary values* for post-P7-1 keys are among the 864 dark keys, so authenticated views would show raw keys inside an otherwise-correct RTL layout.
6. `LANGS = ["fr","en","ar"]`, persisted lang, `isLang` guard, and `setFormatLocale` (locale-aware DZD/date formatting) unchanged from reference.

---

## §7 Existing validation tooling inventory (tmp-scripts, read-only)

| Script | What it does | Re-runnable post-recovery? |
|---|---|---|
| **`tmp-scripts/p22-i18n-audit.ts`** (134 lines) | **THE reusable dictionary-completeness validator.** Walks src/, extracts static `t("key")`/`translate("key")` + dynamic template-literal prefixes, validates every key against the **bound** `@/lib/i18n` dictionaries ×3 langs; reports raw-key leaks (MISSING), partial-lang gaps, dynamic-prefix coverage, dead-key candidates, and a 15-vocabulary ENUM-COMPLETENESS matrix (constants.ts → `role.`/`stage.`/`visit.status.`… keys). This is the tool behind the standing "i18n literal scan … missing=0 ×3 langs" gate. | ✅ Yes — pure reads (fs walk + dictionary import + constants import). Ran it at HEAD (numbers in §5.3). Because it imports the *bound* module, it automatically audits whichever dictionary resolves: zombie at HEAD, modular after the sweep. |
| `tmp-scripts/i18n-analyze.ts` (21 lines) | Key-count per family + en/ar miss counts, importing `../src/lib/i18n` (relative — same file-before-folder binding). | ✅ Read-only; reports the *bound* dictionary (1,013/lang at HEAD → 1,877/lang post-recovery). |
| `tmp-scripts/i18n-peek.ts` (6 lines) | Prints sample keys per family from the bound dictionary. | ✅ Read-only. |
| `tmp-scripts/i7-validate.ts` (78 lines) | P7-1 zero-drift validator (legacy vs split: key sets, values, translate() equivalence, dirFor). Imports `./i18n-legacy` — **which does not exist at HEAD** → not runnable as-is (exactly why P33 deleted it: "dead ./i18n-legacy import"). | ❌ Not runnable (dead import). Not needed for recovery — its job (split equivalence) was proven at P7-1 and re-derivable from my §4.3 counts. Note: it exists at `b34d5b8` (resurrected by an earlier env wave, pre-dating this recovery's scope) and is excluded from tsconfig (`tmp-scripts` in exclude list), so it is tsc-inert. |
| `scripts/validate-seed.py` | DB-side seed validator (audit re-ran: PASS 606 rows). | Out of my lane (Agent DB), noted for completeness. |

**Standing-gate tooling conclusion:** a dictionary-completeness validator exists and is re-runnable safely (`p22-i18n-audit.ts`); the post-recovery expectation for it is `missing = 0 ×3 langs` + `0 enum gaps` (per my §5.3 simulation).

---

## §8 Reference-state baseline — what "restored" means, measurably

**At `b34d5b8` (all ✅ unless noted):**

| Dimension | Reference state | Evidence |
|---|---|---|
| tsc | **0 errors, exit 0** (src+prisma include set) | empirical: `git archive b34d5b8` → `/tmp/b34-check` → `bunx tsc --noEmit` exit 0 |
| lint | **0 errors** (unchanged by contamination; current HEAD also 0) | `bun run lint` → exit 0, zero output |
| i18n binding | `@/lib/i18n` → `src/lib/i18n/index.ts` (monolith absent) | `git ls-tree b34d5b8` — no `src/lib/i18n.ts` |
| i18n dictionary | **1,877 keys × fr/en/ar**; static scan missing = 0 ×3 langs | §4.3 counts; §5.3 post-recovery simulation |
| Shell | `nav.journey/finance/sav` translated; 12/12 `document.title`s translated; aria-labels (`shell.skipToContent`, density) translated | modular dict contains all these keys; §5.2 raw lists |
| API surface | `/api/journey/export` **does not exist** (404); `GET /api` does not exist (404); no junk/unauthenticated scaffold endpoint | route files absent at `b34d5b8` (`git cat-file -e` → ABSENT, all 4) |
| UI component set | no stock-scaffold `ui/*` shadow set (toast uses Sonner; no sidebar/view-placeholder/stage-chip duplicates) | files absent at reference; live equivalents unchanged |
| store.ts | byte-identical to HEAD (zero drift — contamination purely additive) | `git diff b34d5b8 HEAD -- src/lib/client/store.ts` = 0 |
| Historical gates | R15 close: "tsc 0, lint 0" (worklog :4760, :4767); FINAL a3a2c27: "tsc 0 · eslint 0"; P33/P34: "FR26b files 204→201, staticKeys=921, missing=0 ×3 langs" | worklog/commit messages quoted |

*(Note: the P33/P34-era "staticKeys=921 / files 201-205" figures describe the October-13 codebase; the tree has since grown (my scan: 282 live files, ~1,959 static sites, 1,267+ unique keys). The recovery target is the `b34d5b8` state, not the P34 census — expect the re-run gate to report the larger current numbers with missing=0. ⚠️ inference from scan deltas.)*

**Lint state (task item 7) ✅:** `bun run lint` = `eslint .` → **exit 0, zero output** — no errors or warnings in either reference files or contamination files. Caveat (audit T-1.2, config read): `eslint.config.mjs` has 27 rules set `"off"` including `@typescript-eslint/no-unused-vars` and `no-redeclare` — the gate cannot see the zombie class; zero in-code `eslint-disable` cheats (audit-verified).

---

## §9 Recommended remediation plan (file-level) — for Principal approval

**Shape: deletion-only, zero code changes, zero package changes.** All deletions are pre-justified by the D-040/D-041 law (AGENTS.md:17) and the purity proofs below. (The DB/env recovery runbook — R-E1/E2/E3 — is Agent 3/Principal lane; not repeated here.)

### 9.1 DELETE — the `753d115` code set (33 code files)

| Group | Files | Purity proof (all ✅, blob-hash vs deleting-commit parent) | Fixes |
|---|---|---|---|
| **i18n zombie (P1)** | `src/lib/i18n.ts` | ≡ `ee04e81^` (P32's deletion parent) and ≡ `97e9c54` (pre-P7-1); strict subset of modular (§4.3) | re-binds 5 importers to modular root; restores 1,877×3 dictionary; all 12 views' text layer |
| **Stock scaffold (17 ui + 2 hooks)** | `src/components/ui/{accordion,aspect-ratio,carousel,chart,collapsible,context-menu,drawer,hover-card,input-otp,menubar,navigation-menu,radio-group,resizable,sidebar,toast,toaster,tooltip}.tsx`, `src/hooks/{use-mobile,use-toast}.ts` | each ≡ `a3a2c27^` (deps+files deleted together at a3a2c27) | clears errors #2–#16 |
| **Journey orphans (5, new-to-head)** | `src/components/crm/journey-stage-chip.tsx`, `src/lib/server/journey-stats.ts`, `src/lib/server/journey-worklist.ts`, `src/lib/server/journey-facet.ts`, `src/app/api/journey/export/route.ts` | no prior history (`git log --all` = `753d115` only) — abandoned working copies; zero live importers (§2B) | clears errors #1, #17–#20; kills the API-poisoning trigger; removes dead `journey-facet` |
| **Resurrected dead surfaces (4)** | `src/components/crm/view-placeholder.tsx`, `src/app/api/leads/check-duplicates/route.ts`, `src/app/api/properties/unit-types/route.ts`, `src/app/api/route.ts` | ≡ `bb13147^` (P34 deletions) / `≡ 9d635d7^` (P33 deletion) | removes unguarded `GET /api` junk endpoint + never-wired routes (ND-A4) |
| **Config zombie** | `tailwind.config.ts` | retired at H2 (`ae9357f` "vestigial tailwind.config.ts retired"); unreferenced by any code (rg exit 1); Tailwind 4 is CSS-first (`globals.css:1 @import "tailwindcss"`, `postcss.config.mjs` `@tailwindcss/postcss`) | removes scaffold noise + the `tailwindcss-animate` reference |
| **tmp-scripts (3)** | `tmp-scripts/census.ts`, `tmp-scripts/r10-seed-won.ts`, `tmp-scripts/recent-audits.ts` | `r10-seed-won.ts` deleted at P33+a3a2c27, re-added; census/recent-audits new-to-head status-audit scratch | tsc-inert (tmp-scripts excluded from tsconfig) but D-040-class |

### 9.2 DISPOSITION — Principal decision (not code)

- **66 evidence PNGs** added by `753d115` (`evidence/phase-status-audit/` 2, `evidence/qa-continue/` 19, `evidence/qa-r13/` 19, `evidence/qa-unify/` 26) — orphaned artifacts of the abandoned journey workstream; recommend delete or move out of the evidence canon.
- **4 docs/audits status documents** added by `753d115` (`ASAS_CRM_EXECUTION_EVIDENCE_INDEX.md`, `ASAS_CRM_PHASE_COMPLETION_STATUS.md`, `ASAS_CRM_PROJECT_HEALTH_SNAPSHOT.md`, `ASAS_CRM_REMAINING_WORK_REGISTER.md`) — the prior status-audit's own deliverables; keep-or-delete is a governance call (they are historically accurate for `b34d5b8`).

### 9.3 EXECUTION PROTOCOL (per AGENTS.md laws — ⚠️ plan, not executed here)

1. Pre-deletion: re-run the content-hash purity proofs (commands preserved in this report; all already pass).
2. `git rm` the 33 code files → conventional commit message (e.g. `chore: D-040 resurrection sweep — remove the 753d115 zombie set (20 tsc errors → 0; i18n single-source restored)`) → **worklog entry** documenting `753d115`'s provenance and the sweep (closes ND-A5).
3. **Restart dev server with cleared `.next`** (AGENTS.md route-deletion law: stale route-type validator + `ss -tlnp` PID kill).
4. Re-run gates: `bunx tsc --noEmit` (expect **0**), `bun run lint` (expect **0**), `bun tmp-scripts/p22-i18n-audit.ts` (expect **missing=0 ×3 langs, 0 enum gaps**), unauthenticated API matrix back to byte-identical 401 JSON, `/api/journey/export` → 404, `GET /api` → 404, browser sweep 12 views × FR/AR/EN × desktop/mobile (spot-check `nav.journey`, `journey.title`, `dash.attention.title`, `finance.call.success`, `sav.rows` now translated).
5. Optional hardening (P2/P3 backlog, separate session — not part of the recovery): ND-B1/B2 tx-law fixes, ND-B8 client stage constants, ND-B9 X-Powered-By, ND-B12 db:migrate alias.

### 9.4 What is explicitly NOT remediated by this plan

- The 4 stale-API errors are **not** fixed by adding `JourneyStatEntry`/`isJourneyStalled`/`openJourneyFocus` exports: the orphan files are superseded working copies with zero live importers, and the reference state (`b34d5b8`) had neither them nor the export route. Repairing them would *add* API surface that reference never had.
- The 14 missing deps are **not** re-installed: `a3a2c27` deliberately removed them (dead-dependency cleanup, "toggle kept-with-evidence"); re-adding 15 packages to compile 19 dead files inverts the D-040 law.
- `tmp-scripts/i7-validate.ts`, `p13/p14/p15-cleanup`, `p2c-*`, `p6-9-*`, `q.ts`, `seed-finance/sav`, `count-check.ts` (12 further ever-deleted∧in-HEAD files, resurrected by *earlier* environment waves and present at `b34d5b8`): out of this recovery's scope (they are part of the reference state), but the standing D-040 sweep will keep flagging them — a separate hygiene decision for the Principal.

---

## §10 Verdict

**CONTAINMENT: CONFIRMED.** Exactly 20 tsc errors; all 17 implicated files added by `753d115`; all absent at `b34d5b8`; the reference tree empirically type-checks clean (exit 0). The contamination delta is purely additive (zero reference files modified).

**LOCALIZATION: CONFIRMED AND QUANTIFIED.** File-before-folder resolution binds `@/lib/i18n` to the 3,253-line zombie at BOTH the TypeScript layer (traceResolution) and the Bun runtime layer (resolveSync) — 1,013 vs 1,877 keys/lang → **864 keys/lang (46.0%) dark**, strict-subset property holds (zero-loss deletion), all 12 views render raw keys (verified per-view and per-subtree), 3 nav labels + 3 document titles + multiple aria-labels raw, 4 enum-label families raw.

**RECOVERY: DELETION-SHAPED, LOW-RISK, FULLY PRE-PROVEN.** Every deletion in the plan is backed by a completed blob-purity proof or a no-prior-history proof; a post-recovery simulation of the i18n gate returns missing = 0 ×3 langs; expected post-state = the verified `b34d5b8` baseline (tsc 0, lint 0, 401-JSON matrix, 12-view ×3-lang translated text layer).

**Approve the §9 plan.** No contradictions of substance were found with the Principal's context or the independent audit; the only corrections are minor count-labels (see below).

---

## Appendix — Contradictions & corrections vs the Principal's context brief

1. **"Fifteen TS2307 missing-module errors"** → precisely **14× TS2307 + 1× TS2339** (`slots` cascade in the same scaffold class). Total scaffold-class errors = 15 either way; grand total = 20. ✅ corrected in §2.
2. **"`753d115` added 33 source files"** → `753d115` added **103 files** total, of which **29 are src/ files** (+ `tailwind.config.ts` + 3 tmp-scripts = 33 *code* files; the rest are 4 docs + 66 PNGs). Same intended meaning; the precise split is in §3.
3. **"tmp-scripts/i22-i18n-audit.ts"** → the actual filename is **`tmp-scripts/p22-i18n-audit.ts`** (it exists and runs). `i7-validate.ts` exists but is **not runnable** (dead `./i18n-legacy` import). ✅ §7.
4. **Audit report minor internal miscounts (not load-bearing):** "22 domain files" → **21** domain modules; "18 template files" → 17 ui + 2 hooks = **19**; "16 uninstalled packages" → **14** produce TS2307s (+ `tailwindcss-animate` referenced only by the zombie config = 15 of the a3a2c27-purged 15). The audit's §1 "662 unique keys" vs §3.2 "864 keys" are different metrics (referenced-unique vs dictionary-delta), both defensible — see §5.3 reconciliation.
5. **Standing gate "staticKeys=921" (P33/P34)** — that is the October-13 epoch; the `b34d5b8`-era scan is larger (my count: ~1,267 unique static keys, 282 live files). Recovery acceptance should be anchored to **missing=0 ×3 langs** (holds in simulation), not the stale absolute counts. ⚠️ inference flagged in §8.
6. **Everything else in the context brief checked out exactly as stated** — 20-error list verbatim, a3a2c27 dual deletion (deps AND files) confirmed, 5-importer map confirmed, ~46% dictionary loss confirmed, 12-view list confirmed, `bun run lint` clean confirmed, `bun run build` never executed (forbidden, AGENTS.md:13).

---

*Investigation boundary honored: read-only except this report file; zero git mutations (the `git archive` extraction targeted /tmp only); zero source edits; no DB/env/secrets access; no builds. Scratch scripts live in /tmp (`i18n-count.ts`, `render-sites.ts`, `views-check.ts`, `subtree-check.ts`, `audit-settings-check.ts`, `post-recovery-check.ts`, `enum-check.ts`, `bun-resolve-test.ts`) and can be re-run for verification.*

---

# PART 2 — RECOVERY EXECUTION RESULTS (appended by the Principal)

**Executed remediation**: the §9 deletion plan, approved verbatim (Recovery Plan D-R2). `git rm` of all 33 additive code files (the monolith `src/lib/i18n.ts`, 17 stock ui components + 2 hooks, 5 journey orphans, 4 never-wired routes/scaffold, `tailwind.config.ts`, 3 tmp-scripts). Zero code written, zero compiler options touched, zero suppressions — the §2 error table's remediation column realized exactly.

## Verification results (this session, post-recovery)

| Gate | Result |
|---|---|
| `bunx tsc --noEmit` | **0 errors** (from the 20 catalogued in §2 — all resolved by removal of their carrier files, which were 100 % contamination-confined per §3's containment proof) |
| `bun run lint` | **exit 0** (unchanged — the class was structurally invisible to lint, as §7 predicted) |
| Module resolution re-bind | `@/lib/i18n` now resolves to `src/lib/i18n/index.ts` (the modular composition root) — the monolith no longer exists; runtime import verified by the validator itself (`dictionaries` = **1,877 keys ×3 langs**, from 1,013 → **+864 keys/lang, 46.0 % restored**) |
| `bun tmp-scripts/p22-i18n-audit.ts` | 305 files; 1,266 static keys; 48 dynamic prefixes; **missing = 0 real** (single hit = the pre-existing doc-comment example `t("key")` in `i18n/index.ts:3`'s RULE comment — present at the reference state, not a leak); partial = 0; **ENUM-COMPLETENESS MATRIX: 15 vocabularies, all enum members covered ×3 langs** |
| Strict-subset property realized | 0 keys lost (§4's proof); the 12 views' dark families (journey:139, sav:93, visits:86, finance:72, leads:68 …) re-bound |
| Browser (Agent 6 final pass, independent) | **12 views × FR/AR/EN = 36 DOM-wide scans (text + placeholder/aria-label/title/alt) → 0 raw keys**; `nav.journey/finance/sav` translated ×3; 3 view titles translated ×3; AR RTL flip ×12 views; EN LTR; FR default — §5's inventory fully reconciled to zero |
| Production build | NOT RUN — `bun run build` is forbidden by sandbox law (AGENTS.md:13, OOM class). Standing gates (tsc/lint/dev-server/browser) substitute; the contamination files that carried the 20 build-blocking errors are gone and the tree is byte-identical to `b34d5b8` (empty `git diff b34d5b8 -- src/ tailwind.config.ts tmp-scripts/`) |

## §9 plan → outcome cross-check

Every §9 prediction held: deletion-only restored tsc to 0; the i18n re-bind was side-effect-free (all five consumed symbols exist in the modular system); no dependencies re-installed (correct — the scaffold deps were deliberately purged at `a3a2c27`); no API surface repaired (correct — D-R3 disposition); PNG/docs disposition = PRESERVED per Recovery Plan D-R4 (mission's evidence-preservation directive supersedes the §9 "disposition" note).

**Part 2 verdict: localization architecture RESTORED — single-source modular system, 1,877 ×3, browser-verified zero raw keys across the audited surface; build gates green within sandbox law.**
