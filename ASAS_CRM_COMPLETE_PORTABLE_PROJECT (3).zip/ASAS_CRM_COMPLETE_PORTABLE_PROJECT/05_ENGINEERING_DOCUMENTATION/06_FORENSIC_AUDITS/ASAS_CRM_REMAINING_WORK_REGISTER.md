# ASAS CRM — Remaining Work Register

**Companion to:** `ASAS_CRM_PHASE_COMPLETION_STATUS.md` (same audit session, 2026-11-02).
**Scope:** every incomplete, unverified, failed, blocked, and deferred task identified by the roadmap trace — plus the current-state repair backlog introduced by the post-commit environment reset (which this audit was mandated NOT to execute).

Priorities: **R-A (P0)** = blocks correct operation / next engineering session · **R-B (P1)** = correctness or governance debt · **R-C (P2)** = polish, deferred-by-design, or owner-gated.

---

## Section 1 — Environment recovery backlog (introduced AFTER commit `b34d5b8`; blocks everything else)

| ID | Pri | Task | Status | Evidence / owner notes |
|---|---|---|---|---|
| R-01 | **R-A** | **Execute the R13 recovery runbook** (AGENTS.md): snapshot → kill dev server by PID → fresh `db/custom.db` → `bunx prisma migrate deploy` (17/17) → `bun run db:seed` (canonical census) → re-append fresh `ASAS_SESSION_SECRET` → subshell-detach restart. Until then: `/api/dashboard`, `/api/notifications`, `/api/leads` return 500 (missing `ProjectAssignment` table, missing `closureRequestedById` column — live DB is ~13 migrations behind code). | NOT STARTED (deliberately — this audit does not repair) | dev.log Prisma errors ×8; browser network log; read-only DB probe (7 users/44 leads/10 reservations, no `_prisma_migrations`) |
| R-02 | **R-A** | **Execute the D-040/D-041 resurrection sweep**: re-delete the 5 resurrected zombies after the content-hash purity proof (`src/lib/i18n.ts` — re-activates the P26/P32 raw-key defect live: `nav.journey`, `nav.finance`, `nav.sav`, `shell.skipToContent`, `shell.density`, `leads.archive.viewToggle.aria`, `leads.dup.button` observed raw in the running UI; `tailwind.config.ts` — module-not-found warnings in dev.log; `view-placeholder.tsx`, `check-duplicates/route.ts`, `unit-types/route.ts`). | NOT STARTED | git `26d253e` deleted all 5 (3,412 lines); files present on disk with Oct-2–4 mtimes; AGENTS.md mandates the sweep BEFORE any steady-state witness |
| R-03 | **R-A** | **Disposition the orphaned Nov-1-afternoon work** (6 source files + 3 evidence folders, never committed, never documented): either (a) complete the journey refactor (requires re-adding `openJourneyFocus` to the store, `JourneyStatEntry`/`isJourneyStalled` to `src/lib/journey.ts`, then wiring `journey-{stats,facet,worklist}.ts`, `api/journey/export`, `journey-stage-chip.tsx`) or (b) discard with a documented decision. Currently **6 of the 23 working-tree tsc errors** live here. | IN PROGRESS → abandoned mid-refactor (references non-existent exports) | mtimes 2026-11-01 14:46–17:38; no worklog/execution-log/commit mentions; tsc errors at `journey-stats.ts:21,124,134`, `journey-worklist.ts:26`, `journey-stage-chip.tsx:29` |
| R-04 | **R-A** | **Remove/ignore the 18 template-scaffold files** (`tailwind.config.ts` counted in R-02; `src/app/api/route.ts`; 18 `src/components/ui/*`; `use-mobile.ts`; `use-toast.ts`) — 16 missing-dependency tsc errors (react-accordion, embla-carousel, vaul, input-otp, react-menubar, … none installed). Either delete as non-app scaffold or install deps if any are wanted (none are imported by app code). | NOT STARTED | mtimes 2026-05-12/10-06; zero app importers (git grep); tsc error list |
| R-05 | R-B | **Re-create the DB backup baseline** after recovery (`db/backups/` is wiped — all snapshots referenced by delivery docs are gone: `custom-20261101-183934`, `custom-20261101-204258`, `custom-20261101-233426`, sha256 anchors `167d8889…`/`b0d926ac…` unverifiable). | NOT STARTED | `ls db/` (no backups dir) |
| R-06 | R-B | **Re-establish the mandated 15-min webDevReview cron job OR record its permanent termination per the P14 law.** The register is empty (job 494790 reaped — 7th documented occurrence). NOTE the standing conflict: AGENTS.md P14 law ("terminally ended; do not recreate absent an explicit user instruction") vs. the R14/R15 sessions' recreation citing a per-session system mandate. An explicit owner decision should settle which law governs. | BLOCKED [owner decision] | scheduler query this session (0 jobs); AGENTS.md P14; register addenda §1j/§1k; worklog 4721, 4760 |
| R-07 | R-B | **Fix the misleading empty-state**: a failed leads fetch (500) renders as «0 résultat(s)» — an honest error state is the app's own stated law (R5 fail-closed). Currently masked by R-01; re-check after recovery. | NOT STARTED (latent until R-01 fixed) | browser observation this session |

## Section 2 — Unverified / partially verified implementation claims

| ID | Pri | Task | Status | Evidence |
|---|---|---|---|---|
| R-08 | R-B | **PostgreSQL/Supabase RLS runtime verification** — 150 policy statements shipped (`0003_rls_policies.sql` ×130 + `0004` ×20) but never executed against a live PG instance (none available in any environment used). Structural validation only (engine-generated DDL, validated seed). | BLOCKED [env/owner — requires the owner's Supabase project] | FINAL_QA_REPORT §1 "BLOCKED (runtime) / PASS (structural)"; SUPABASE_SETUP.md §9 |
| R-09 | R-B | **Production-build verification** — `bun run build` forbidden in the sandbox (house law); build-strictness flags (`ignoreBuildErrors:false` — already removed; `reactStrictMode` flip G5-P1-2) never validated by an actual build. | BLOCKED [env] | AGENTS.md; G5-P1-2 roadmap row |
| R-10 | R-B | **Production demo-mode fail-fast runtime check** — `DEMO_MODE_PRODUCTION_MISCONFIG` code-verified but not runtime-verified (needs NODE_ENV=production, impossible here). | IMPLEMENTED, NOT runtime-verified | PHASE2 execution log W2.2 |
| R-11 | R-B | **Current-state re-verification of all runtime claims** after R-01/R-02 recovery: the 333-probe standing matrix, the 13-assertion security matrix, 12-view browser sweep, golden-path E2E. All were green at commit time with preserved receipts; none are re-runnable against the current stale DB. | NOT STARTED (depends on R-01, R-02) | worklog 4728–4729, 4762–4766 |

## Section 3 — Deferred-by-design / owner-gated (documented in the roadmap's Deferred section)

| ID | Pri | Task | Status | Evidence |
|---|---|---|---|---|
| R-12 | R-C | Vitest automated suites (transition tables, visibility matrices, DTO stripping) | REJECTED WITH JUSTIFICATION (house law: no test code in this environment; live-protocol + golden-path + CI static gates are the documented substitute). Revisit only if the environment policy changes. | PHASE2 plan §1.1; FINAL delivery §3 |
| R-13 | R-C | New-row-per-booking revival admin split-flow (durable end-state for reservation revival with dependents; current 409 guard is the safe shipped state; migration #17 removed the schema blocker) | DEFERRED (design direction documented) | PHASE2 plan §1.3; roadmap header |
| R-14 | R-C | Trigram search (PG variant only — rejected on SQLite) | DEFERRED [PG deployment] | PHASE2 plan §1.5 |
| R-15 | R-C | Production deployment checklist execution: `ASAS_DEMO_MODE=0`, TLS at Caddy, supervisor (systemd/K8s — NOT the dev-server pattern), monitoring, secret rotation | DEFERRED [deploy] — SECURITY.md owns the checklist | FINAL delivery §4 |
| R-16 | R-C | Git history purge (one real session-secret value + pre-purge demo DB in history; **required before any remote push** — repo currently has no remote, boundary intact) | BLOCKED [owner authorization — D-013] | GIT_HISTORY_PURGE.md; FINAL_QA_REPORT §1 |
| R-17 | R-C | Real-customer data export | BLOCKED [owner — no real customer data in this demo workspace] | DATA_EXPORT_BLOCKED.md |
| R-18 | R-C | RLS-equivalent documentation drift: AGENTS.md invariant #5 still says "uniqueness is NOT a DB index anymore (D-008)" — superseded by Phase-2 migration #17 partial unique indexes | NOT STARTED (one-line doc fix) | AGENTS.md vs migration #17 |
| R-19 | R-C | TruncationNotice shared extraction + deal-economics whole-file type-scale stage (ENG-F follow-ups; banner quartet already unified) | DEFERRED (≥3-surface bar met for the quartet only) | PHASE2 delivery §3 |
| R-20 | R-C | §38 IncentiveStatusChip coherence backlog candidate | CLOSED-with-evidence at PHASE2 (deleted in WS-S; 0 chip surfaces) — listed for traceability | PHASE2 execution log W3.3 |
| R-21 | R-C | Residual P3 UX items from Phase 1 audit (feedback timing, formatting discipline residuals beyond the 12 Wave-4 fixes) | PARTIALLY done (W4.3–W4.12 all verified); residuals folded into later UX rounds; any survivors are pre-verified as low-impact | UX_UI audit + MASTER execution log |

## Section 4 — Known environment-class risks (standing, documented by the project itself)

| ID | Risk | Standing mitigation (documented) |
|---|---|---|
| R-22 | Sandbox environment resets (R13 class): DB wipe/restore-to-old-snapshot, `.env` reversion, `db/backups` wipe, deleted-file resurrection (D-040/P32 class), cron reaping | AGENTS.md recovery runbook + mandatory resurrection sweep + "verify user count ≠ 0 before QA"; dev-watchdog; heap-capped relaunch. **Not an app defect; cannot recur in production** (root-cause determination, commit `e2eb6f7`). |
| R-23 | Dev-server OOM/reaper kills (2× OOM @2GB RSS observed; background processes reap minutes-scale) | setsid-detach + `--max-old-space-size=1400` + watchdog; production must run `next start` under a real supervisor |
| R-24 | Git history contains a dead-but-present secret (remediation = R-16) | never pushed; no remote; purge before any remote |
| R-25 | Turbopack stale-CSS/stale-module classes (observed P6-4/P8-9) | kill-all + `rm -rf .next` + restart protocol in AGENTS.md |

---

**Register summary:** 7 R-A/R-B environment-recovery items (R-01…R-07, of which R-01/R-02/R-03/R-04 are the P0 blockers), 4 verification-completeness items (R-08…R-11), 10 deferred/owner-gated items (R-12…R-21), 4 standing environment-class risks (R-22…R-25). **No open code defect at HEAD was identified by this audit that is not already registered** — the two live defects observed (raw i18n keys, API 500s) are environment artifacts with repo-verified fixes already shipped in history (P26/P32 deletions, migration chain).
