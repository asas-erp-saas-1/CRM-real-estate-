# ASAS CRM — Remediation Roadmap (Adopted)

> **STATUS 2026-11-02 (end of Round PHASE 2 — the controlled implementation round):**
> - **D12 closed at the DB layer** (the last documented theoretical race): migration #17 `phase2_d12_live_hold_unique` — partial unique indexes per apartment AND per opportunity (`WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')`), violation-probed on a DB copy (all 3 probes pass), live booking round-trip green (book → cancel → apartment released, census restored). P2002→ALREADY_RESERVED mapping was already in place.
> - **Production demo-mode fail-fast shipped** (SEC-V01's residual): `DEMO_MODE_PRODUCTION_MISCONFIG` (500) on quick-login + demoUsers suppression + boot warning — NODE_ENV-gated, sandbox untouched; SECURITY.md documents the mechanism.
> - **Two backlog features delivered live**: targets month-copy (POST /api/targets/copy + settings dialog + i18n ×3, live-verified byte-correct) and PDF first-page thumbnails (GET /api/documents/:id/thumb — poppler 72 DPI raster, 307 for images, D-021 scoped, live-verified in UI after two central integration fixes: the document-row PREVIEWABLE_MIME gate + a one-retry thumb fallback).
> - **Polish**: semantic type-scale law extended to 6 residual notice sites (truncation-banner quartet as one family + copilot risk callouts + noTags hint); the §38 IncentiveStatusChip candidate retired with git evidence (deleted in WS-S; 0 chip surfaces today).
> - Gates: tsc 0 · eslint 0 · zero console errors · mobile 390 exact · AR RTL + dark · role isolation intact. Evidence: `download/qa-phase2/` (13 screenshots).
> - Full detail: `ASAS_CRM_PHASE2_EXECUTION_LOG.md`.
>
> **STATUS 2026-11-01 (end of Round MASTER):** Wave 1 ✅ · Wave 2 ✅ (9/9) · Wave 3 ✅ (7/8 — W3.7 skipped w/ evidence) · Wave 4 ✅ (12/12) · Wave 5 ✅ (integration gates green, browser QA green, zero console errors). Full verification detail: ASAS_CRM_FINAL_DELIVERY_REPORT.md. Deferred items below remain open with evidence.
>
> **STATUS 2026-11-01 (end of Round FINAL — the deferred-items round):**
> - **Golden-path lifecycle E2E executed end-to-end** (create lead → contact → requirement → convert → visit → report → book → economics → validate → WON 7/7; the MASTER round's honest-limit #3 retired) — it surfaced **9 latent defects, all fixed and live-verified**: P1 closure-gate unreachable via UI (visits never linked opportunityId → server auto-link + dialog affordance), P1 first-economics-entry rejected as PENDING→PENDING (explicitTransition now requires a recorded state), P2 booking never advanced the opp stage (in-tx RESERVATION advance + trail), P2 RESERVE_STAGES dead-end (+RESERVATION), P2 no one-live-hold-per-deal guard (OPPORTUNITY_ALREADY_BOOKED 409), P2 frozen opp-dialog snapshot from the lead tab (onUpdated now refreshes), P2 journey ops never advanced lead.status (D11 family — activities NEW→CONTACTED + requirements →QUALIFIED, both in-tx with activity+audit), P3 ENGAGED blockers hardcoded (budget facts + honest blockers), D14 closedAt approximation (true fact first, DTO typed).
> - **Deferred list executed**: D9 sweeper scheduling (`lib/server/expiry-scheduler.ts`, HMR-safe singleton, 60s unref'd interval) · D12 idempotency (5s in-tx twin guard, `deduplicated:true`) · D13 metric definitions (`lib/metrics.ts` — WON_SHARE_ALL_TIME / CREATED_COHORT_RATE / JOURNEY_PEAK + TOTAL_AGE vs DAYS_IN_STAGE; analytics+dashboard adopt) · visit-ladder dedup (`visits/visit-ladder.ts`, reverse-index on VISIT_TRANSITIONS — the UI ladder can no longer drift from the server matrix) · **WAL mode ON** (snapshot → PRAGMA → integrity ok) · deps cleanup (15 removed + 19 dead files, react-toggle kept-with-evidence) · dynamic-import charts (recharts zero static importers; framer-motion deliberately kept global — MotionConfig) · analytics groupBy (verified already-at-target from MASTER; no churn) · stale `tmp-scripts/r10-seed-won.ts` deleted (canonical seeding lives in `prisma/seed.ts`).
> - **Regression**: 12 views + RTL/AR + dark + mobile 390 + role isolation + finance scope probe (agent 3 rows vs manager 14) — zero console errors. `tsc --noEmit` 0 · `eslint .` 0.
> - **Still open (documented)**: production deployment checklist (DEMO_MODE=0, TLS, supervisor, monitoring — SECURITY.md) · D12 concurrent-twin note (sequential double-click fully covered; a DB unique index would close the theoretical race) · trigram search (PG variant only).

Orchestration (user-mandated): parallel audit → consolidation → roadmap adoption → **parallel execution of independent tasks with disjoint file ownership** → central integration → regression & final QA.

## Wave 1 — Foundation (SERIAL, Principal) — no behavior change
| ID | Task | Files | Acceptance | Status |
|---|---|---|---|---|
| W1.1 | Persistent `ASAS_SESSION_SECRET` in `.env` (openssl rand) | .env | dev.log warning gone after reload | ⬜ |
| W1.2 | Add phantom dep `@radix-ui/react-direction` | package.json | bun install clean, typecheck pass | ⬜ |
| W1.3 | Security headers (sandbox-safe: nosniff + Referrer-Policy only; NO frame/CSP — preview iframe) | next.config.ts | headers present on responses | ⬜ |
| W1.4 | Cookie `secure` flag (prod-only) | api/auth/login/route.ts | flag conditional; dev unaffected | ⬜ |
| W1.5 | Absolute session expiry 7d | lib/server/session.ts | old cookie (issuedAt>7d) → 401 | ⬜ |
| W1.6 | `SAV_OPEN_STATUSES` const + adopt in SAV routes (closes latent enum-drift bug ARCH-T2/D5) | constants.ts (+ ENG-2 routes) | routes import const | ⬜ |
| W1.7 | DB snapshot + migration baseline (`migrate resolve --applied` ×14) | db/backups/, _prisma_migrations | migrate status: 14 applied, 0 pending | ⬜ |
| W1.8 | Index `Reservation @@index([orgId, incentiveStatus])` + additive push | schema.prisma | index exists; zero drift | ⬜ |

## Wave 2 — Business-logic integrity (ENG-1, parallel) — owns: api/reservations/**, lib/server/reservation-lifecycle.ts, api/opportunities/[id]/route.ts, api/properties/apartments/[id]/route.ts, api/leads/[id]/reactivate/route.ts, api/leads/[id]/route.ts (reassign part)
| ID | Task (defect) | Acceptance | Status |
|---|---|---|---|
| W2.1 | **D1 P1** revive guard: 409 `RESERVATION_HAS_DEPENDENTS` when Installment/Payment/SavCase exist on the row; else reset FULL economics+closure field set on revival | guard tested via API reasoning; fields reset verifiable | ⬜ |
| W2.2 | **D2** apartment PATCH + POST revive-block count `CLOSURE_REQUESTED` | RESERVED w/ closure-requested hold not flippable w/o force | ⬜ |
| W2.3 | **D3** opp→CLOSED_LOST 422 `ACTIVE_RESERVATION_EXISTS` while ACTIVE/CLOSURE_REQUESTED hold (manager may cancel first) | guard present + activity reason | ⬜ |
| W2.4 | **D4** booking stage precondition: working stages only; terminal stages → 422 w/ explicit code | CLOSED_LOST opp cannot be booked | ⬜ |
| W2.5 | **D7** validate_closure stamps opp stageChangedAt | field stamped on coupled write | ⬜ |
| W2.6 | **D8** reactivate: mutation+Activity+Audit in ONE tx | tx law satisfied | ⬜ |
| W2.7 | **D10** cancel releases apartment only if still RESERVED (sweeper parity) | BLOCKED not overwritten | ⬜ |
| W2.8 | **D5** lead reassign cascades `Opportunity.ownerId` for NON-TERMINAL opps (deal follows the client; agency-head decision) + activity note | reassign → kanban follows | ⬜ |
| W2.9 | **PERF-P1** paginate GET /api/reservations (leads clamp pattern) | page/pageSize honored; UI still works | ⬜ |

## Wave 3 — Architecture dedup + perf (ENG-2, parallel) — owns: NEW lib/server/{visit-facets,visits,tasks}.ts, api/visits/route.ts, api/visits/[id]/route.ts, api/tasks/route.ts, api/tasks/[id]/route.ts, api/dashboard/route.ts, api/sav/**, api/finance/installments/route.ts, api/analytics/route.ts, api/opportunities/route.ts
| ID | Task | Acceptance | Status |
|---|---|---|---|
| W3.1 | **T1 P1** extract `lib/server/visit-facets.ts` (unstaffed/fieldDecision/awaitingReconfirm predicates); import in dashboard + visits routes | KPI==list-total structural; typecheck | ⬜ |
| W3.2 | **T3** `lib/server/visits.ts` + `tasks.ts` (include + flatten + findVisit/findTask) mirroring leads.ts | duplication D1–D3 removed | ⬜ |
| W3.3 | **T4** `findOpportunity` helper; swap call-sites in OWNED files only | scoped lookup deduped where safe | ⬜ |
| W3.4 | SAV routes import `SAV_STATUSES`/`SAV_OPEN_STATUSES` (with W1.6) | D4/D5 closed | ⬜ |
| W3.5 | Cache-Control `private, max-age=30` on dashboard + analytics GET | header present | ⬜ |
| W3.6 | Paginate `/api/sav` + `/api/finance/installments` (UI compatibility checked) | bounded | ⬜ |
| W3.7 | Default pageSize 200→50 visits+opps IF UI passes explicit pageSize (verify first) | no UI regression | ⬜ |
| W3.8 | Copilot `AbortSignal.timeout` + 504 mapping | timeout enforced | ⬜ |

## Wave 4 — UI/UX engineering (ENG-3, parallel) — owns: src/components/crm/** + globals.css + i18n dicts + lib/format.ts
| ID | Task | Acceptance | Status |
|---|---|---|---|
| W4.1 | **P1 a11y** leads row nesting fix (row container + name-cell opener + action cells) | axe nested-interactive cleared | ⬜ |
| W4.2 | **P1 contrast** dark tokens (lang chip, role badge, sidebar footer ≥4.5:1) | axe contrast cleared | ⬜ |
| W4.3 | "Trouver des biens" feedback (scroll-into-view + count toast) | visible result feedback | ⬜ |
| W4.4 | Finance col rename "ÉCHÉANCE"→"LIBELLÉ" (+ i18n) | no duplicate header | ⬜ |
| W4.5 | Currency unification: DA everywhere; compact KPIs / full tables (shared formatter) | 1 convention | ⬜ |
| W4.6 | Persona-switch duplicate toast dedupe | single toast | ⬜ |
| W4.7 | Date/time picker FR locale + a11y labels | AT names French | ⬜ |
| W4.8 | Per-view `document.title` | titles change per view | ⬜ |
| W4.9 | Dashboard decision-card 2-line clamp + title tooltip | full data accessible | ⬜ |
| W4.10 | **D6** remove CLOSED_WON from create-opp dialog | option absent | ⬜ |
| W4.11 | **NEW FEATURE** Kanban column quick-jump (mini-map chip row) | navigation in ≤1 click | ⬜ |
| W4.12 | Mobile touch targets ≥44px on icon actions (shell/toolbar) | measured ≥44px | ⬜ |

## Wave 5 — Central integration + regression (Principal)
- git diff review · typecheck + lint · dev.log clean · **agent-browser E2E**: manager login → all views → AR/dark/mobile → agent role isolation → lifecycle E2E (create lead → qualify → opportunity → visit schedule → book → closure) → screenshots to download/qa-master/after/ · fix regressions · commit.

## Deferred (documented, not forgotten)
Vitest suites (transition tables, visibility matrices, DTO stripping) · deps cleanup (~16) · dynamic-import charts · analytics groupBy · WAL mode · prod env plumbing (DEMO_MODE=0, monitoring, TLS at Caddy) · D9 sweeper scheduling · D11/D12/D13/D14 domain polish · visit-ladder dedup · trigram search in PG variant.
