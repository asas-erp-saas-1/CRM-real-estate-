# ASAS CRM — PHASE 2.1 — ARCHITECTURE REMEDIATION REPORT

**Agent 1 lane (W0-A1 investigation + Principal implementation)** · 2026-11-02
**Baseline**: `dff2d6e` (Phase 2R delivery candidate, sixth wave swept).

---

## 1. Investigation verdict (Wave-0, read-only, evidence-verified)

The recovered baseline is in **markedly better architectural shape than the legacy audit scores suggested**: zero import cycles (full DFS proof), zero layering violations (no client code imports server modules), a single-source-of-truth discipline across auth/session/visibility/validation/journey/i18n, only 10 `any`/`as any` in 64,657 LOC, and a uniformly disciplined API layer (70 route files: 100% try/catch→`fail()`, zod via `parseBody`, org-scoped `visibility.ts` composition, `{data,total,page,pageSize}` pagination law). The legacy 65/100 score was taken at a contaminated HEAD; the real debts were **concentration, not entropy**.

## 2. Implemented remediations

| ID | Finding (evidence) | Fix delivered | Verified by |
|---|---|---|---|
| W1-3/A6#2 | 9 mutating endpoints without AuditLog | logAudit added: convert (in-tx), tags POST/DELETE (+Activity TAG rows + `TAG` type in ACTIVITY_TYPES + i18n ×3 + TYPE_DOT), match, present, opps POST, tasks POST, lead-tasks POST, visits POST (in-tx) | tsc/lint/159 tests; live routes 200 |
| W2-7/A1#6 | Prisma `log:['query']` unconditional (prod included) | gated `NODE_ENV==='production' ? ['error'] : ['query']` | code review; dev log still shows queries in dev |
| W2-9/A1#11 | No build-time server-only guard | `import 'server-only'` in `src/lib/db.ts` | tsc 0 (client import would fail to compile) |
| W2-6/A1#3 | Client wire-type mirror drift (`SavListResponse` missing page/pageSize; Lead omits 7 additive wire fields) | SavListResponse corrected (page/pageSize); Lead omissions documented as additive-harmless | `tests/unit/i18n.test.ts` guards the i18n side; tsc |
| W5-3/A6#10 | Unknown `/api/*` → HTML 404 | `src/app/api/[...path]/route.ts` JSON-envelope catch-all (all 5 methods, no-store) | live: `/api/nope` → 404 `application/json` |
| W5-8/A3#3 | Copilot rate limiter keyed per-lead (cross-agent throttle) | keyed `${user.id}:${lead.id}` | code; contract test pattern |
| W4-2/A5#2 | i18n parity unguarded (silent lang→fr→key fallback) | module-load PARITY GUARD: fr/en/ar key-set equality, PARITY_EXEMPT escape hatch (empty) | `tests/unit/i18n.test.ts` (1,878 keys ×3 parity); app boots |
| W5-1/A1#1 | Zero automated tests | **vitest suite: 9 files / 159 tests** — journey engine, ALL transition matrices (incl. new TASK_TRANSITIONS), phone, format, validation, matching, visibility scopes, live API contracts | `bun run test` → 159/159 |
| W5-2/A6#3 | All 12 views statically imported (one-bundle SPA) | React.lazy + Suspense per view, shared ViewSkeleton; shell overlays stay static | browser: dashboard/leads/pipeline/finance all render post-change, zero console errors |

## 3. Deferred (documented, justified)

| Item | Reason |
|---|---|
| W5-6 dashboard mega-handler split (632 lines, 12 sections) | P3 refactor with regression risk late in a large change session; the new SQL aggregates (W2-3) already removed the unbounded scans; the test suite now covers the matrices, lowering future-refactor risk. Next-touch extraction. |
| W5-7 visit PATCH guard extraction (~390 lines inline) | Same class: the route is law-documented and behavior-critical (report discipline, authority rules); extraction without dedicated QA window endangers stability. |
| W5-5 dead-export sweep (~25 symbols) | P3 cosmetic; touching ~15 files after parallel agent work raises conflict risk for zero behavioral gain. |
| W4-8 `pad()` ×3 consolidation | P3; three local date-string helpers are stable and small; consolidation queued for the next visit-dialogs touch. |

## 4. Regressions introduced: **none** — tsc 0 / eslint 0 / 159 tests / 12-surface API battery 200 / browser pass with zero console errors at 1440×900 and 375×812 (FR + AR RTL).
