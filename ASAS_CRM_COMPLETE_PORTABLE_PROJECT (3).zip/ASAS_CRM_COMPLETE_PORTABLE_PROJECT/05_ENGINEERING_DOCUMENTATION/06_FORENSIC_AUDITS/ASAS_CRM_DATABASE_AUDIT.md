# ASAS CRM — Database Audit (Agent B)

Method: read-only URI (`file:db/custom.db?mode=ro`), guard script refusing non-SELECT/PRAGMA. DB was empty at audit start; demo seed applied concurrently (~18:05 UTC); findings re-verified stable at 18:11 UTC.

## Schema: 30 models, verified 1:1 with `sqlite_master`; `schema.postgres.prisma` = generated production variant, models identical. Revenue chain: **Lead → Opportunity → Reservation → Installment → Payment**; inventory: Developer→Project→Building→Apartment; M-N: LeadTag, VisitApartment, ProjectAssignment; 1-1: Contact↔Lead, Requirement↔Lead.

Row counts: Org 1, User 8, Lead 43, Contact 20, Opportunity 21, Apartment 46, Visit 23, Task 18, Activity 183, Reservation 8, Installment 14, Payment 8, SavCase 7, AuditLog 86, SalesTarget 3.

## Integrity — VERBATIM RESULTS
- `PRAGMA integrity_check` → **ok** · `PRAGMA foreign_key_check` → **0 rows**
- 52 orphan sweeps → **all 0** (leads/activities/opps/tasks/visits/reservations/installments/payments/SAV/soft-FKs incl. `convertedContactId`, `incentiveDecidedById`)
- Business invariants all clean: SOLD↔CONVERTED 7/7, CLOSED_WON↔CONVERTED 7/7, 0 double-booked ACTIVE, 0 overpaid installments, 0 missing stamps (lostAt/closedAt/paidAt/resolvedAt), 0 phone-format violations
- **Phone duplicates: 0** (structural `@@unique([orgId,phone])`) · **Email duplicates: 1 pair** (`cmvy55hp8004…` CONVERTED + `cmvy55hsd009…` CONTACTED) — **OWNER DECISION: distinct phones = distinct persons, no merge** (phone is the identity key in this CRM)
- Unanchored SAV: 1 (seq 3 "Ascenseur bloqué" — common-areas case; policy: common-area cases may be unanchored, documented)
- Enum audit: every DISTINCT value in every enum-like column checked vs `constants.ts` → **zero out-of-vocabulary**

## Indexes: 81 physical, every `@@index`/`@@unique` present; `migrate diff` DB↔schema → **empty (zero structural drift)**. Hot paths all covered EXCEPT:
1. **P2: `Reservation[orgId, incentiveStatus]`** — polled by `/api/notifications` (`notifications/route.ts:262-273`) → full org scan today.
2. P3: `Visit.awaitingCustomerReconfirm` partial coverage; `Opportunity.updatedAt` unindexed (kanban sort); `%q%` LIKE scans (SQLite limit — documented).

## Migrations: 14 on disk; `migrate status` → "0 of 14 applied"; `_prisma_migrations` table ABSENT — DB was built via `db push`. **P1 remediation adopted:** snapshot → `prisma migrate resolve --applied` ×14 (records history; zero structural change since diff is empty).

## Cascades: RESTRICT protects the money chain (Reservation↔Opp/Apartment, Installment, Payment, Contact, Opportunity) ✅ · SET NULL detaches Activity/Task attribution on hard deletes (mitigated by soft-delete laws) · ⚠ `Project→Building→Apartment→VisitApartment` cascade-destructive path — no project-delete endpoint exists (operational risk only, documented) · raw SQLite connections have FKs OFF (Prisma enables them; sweep script recommended).

## Remediation (adopted)
| # | Sev | Item | Fix |
|---|---|---|---|
| 1 | P1 | Migration history unrecorded | snapshot + `migrate resolve --applied` ×14 (owner-executed) |
| 2 | P2 | Email-dupe pair | **Ruled distinct — no action** (decision registered) |
| 3 | P2 | Unanchored SAV-3 | accepted policy: common-areas may be unanchored |
| 4 | P2 | Missing `[orgId, incentiveStatus]` index | schema + additive migration |
| 5 | P3 | journal_mode=delete | WAL at next maintenance window (deferred — dev server live) |
| 6 | P3 | raw-FK OFF + soft FKs | app-side guards exist; orphan sweep registered as reusable script |
| 7 | P3 | schema-comment drift (Activity types, Requirement enums) + docs count 13/3 vs 14/4 | comment/doc refresh |
| 8 | P3 | visit `cmvy55hvg…` date moved w/o RESCHEDULED stamp | seed-created; PATCH stamps RESCHEDULED on date change? → deferred decision |
| 9 | P3 | LIKE table scans | accepted at current volume; trigram in PG variant |
