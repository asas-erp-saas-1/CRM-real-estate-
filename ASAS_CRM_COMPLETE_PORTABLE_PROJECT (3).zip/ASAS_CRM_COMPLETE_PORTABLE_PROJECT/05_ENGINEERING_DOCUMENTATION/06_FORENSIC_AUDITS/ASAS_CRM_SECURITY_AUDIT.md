# ASAS CRM — Security Audit (Agent C)

## AuthN: custom stateless HMAC cookie (`asas_user` = `userId.issuedAtMs.HMAC-SHA256`), scrypt passwords (N=16384), per-email sliding-window limiter (5/15min → 429), uniform INVALID_CREDENTIALS + DUMMY_HASH timing equalization, CSRF `assertSameOrigin` in `requireUser()` + `readJson()`, `passwordChangedAt` session invalidation. Single shared guard `requireUser(minRole)` — 100+ call sites, zero routes roll their own.

Roles: OWNER(100) > ADMIN(90) > MANAGER(70) > SALES_AGENT(40) = FIELD_REP(40). Record-level visibility via `lib/server/visibility.ts` (org-wide / own+pool / project-derived); scoped `findFirst` → foreign record = 404 identical to nonexistent (no existence leak).

## Role & Permission Matrix (verified from route code + live probes)
- **AGENT**: leads/opps/tasks/visits/SAV/documents/matching/journey R+W in-scope; tasks POST forces ownerId=self; targets own row only; **analytics/audit/export 403** (verified live); users: names+roles only (emails redacted).
- **MANAGER+**: org-wide R+W; corrections (illegal transitions w/ reason); reassign/bulk/import/merge; finance writes; reservation economics/validate/reject/cancel; user management (ADMIN rank, cannot touch OWNER — ROLE_CEILING).
- **FIELD_REP**: project-derived scope; may CONFIRM visits on assigned projects.
- Frontend nav gating mirrored server-side on every group — **no UI-only gate found**.

## Vulnerability Register
| ID | Sev | Finding | Evidence | Fix (adopted) |
|---|---|---|---|---|
| V-01 | **P0-if-deployed** | Demo quick-login: unauthenticated `GET /api/auth/session` lists users incl. OWNER id; `POST /login {userId}` takes over. Probes: session→200+leak; quick-login→404 (gate open, not 403). Attack chain stopped before final step. | session.ts:93-95 default-ON; session/route.ts:19-25; login/route.ts:53-92 | Sandbox-intentional (persona demo). Prod: `ASAS_DEMO_MODE=0` + fail-fast in production. |
| V-02 | P1-if-deployed | Seeded personas share public password `asas1234`, emails trivial | seed.ts:16,43; login-overlay.tsx:53 | Prod checklist: no seeded creds; forced first-login change |
| V-03 | P2 | Cookie lacks `secure` flag | login/route.ts:30-35 | `secure: NODE_ENV==="production"` |
| V-04 | P2 | No absolute session expiry (replay forever until password change) | session.ts:46-56 | 7-day max age on `issuedAtMs` |
| V-05 | P2 | No security headers; app framable; X-Powered-By present | next.config.ts:3-8; live responses | Sandbox-SAFE set only (nosniff, Referrer-Policy). **NO frame-deny/CSP** — preview panel iframes cross-origin; frame protection would break it. Accepted trade-off, documented. |
| V-06 | P1-if-deployed | `ASAS_SESSION_SECRET` unset → ephemeral | session.ts:28-35; dev.log warning | persistent secret in `.env` NOW |
| V-07 | P3 | In-memory limiter, per-email only | auth.ts:76 | persistent/IP limiter (deferred) |
| V-08 | P3 | Origin check allowances for non-browser clients | session.ts:208-232 | accepted (browsers can't forge forbidden headers); documented |
| V-09 | P3 | Prisma query log unconditional | db.ts:10 | prod log level (deferred) |
| V-10 | P3 | Cross-tenant email oracle on POST /users | users/route.ts:68 | muted 409 (deferred) |

## Black-box probes (exact results): no-cookie `/api/leads` etc → 401 ×15 groups · raw/forged cookie → 401 · cross-origin POST → 403 CROSS_ORIGIN_BLOCKED · OPTIONS foreign origin → 204 no ACAO · 6× wrong password → 429 on 6th · **zero unauthorized writes executed**.

## Verified-live positives: HMAC forgery rejected; scrypt+timing equalization; rate limiter fires; CSRF fires; zod on every body (0 raw `req.json()`); org-scoping on every query; ROLE_CEILING/self-role/last-owner guards; upload whitelist+size+path containment; audit trail on all mutations; zero console-logged user data; generic 500s.
