# ASAS CRM — Project Health Snapshot

**Companion to:** `ASAS_CRM_PHASE_COMPLETION_STATUS.md`, `ASAS_CRM_REMAINING_WORK_REGISTER.md`, `ASAS_CRM_EXECUTION_EVIDENCE_INDEX.md` (same audit session, 2026-11-02).
**Question answered:** what is the engineering health of ASAS CRM *as a repository*, *as a running system*, and *as a program* — and is it ready for the next engineering phase?

---

## 1. Health by dimension (dual reading: repository vs. current runtime)

| Dimension | Repository (git HEAD `b34d5b8`) | Current running environment | Grade (repo / runtime) |
|---|---|---|---|
| **Architecture** | Clean route→lib/server layering; DTO modules; shared guards on 69/73 app routes; decomposition program completed with line-count receipts; zero circular deps | Shell renders; module resolution integrity compromised by the resurrected `i18n.ts` shadow (file-before-folder) | **A− / C** |
| **Database (repo artifacts)** | 17-migration authoritative chain; partial unique indexes (D12); composite + incentive indexes; PG rendering with 65 FKs; CHECK vocabularies; RLS policy set (structural) | Live DB is an Oct-2-era snapshot: ~13 migrations behind, no `_prisma_migrations`, missing `ProjectAssignment` table + `closureRequestedById` column → 3+ core APIs 500 | **A / F** |
| **Security** | scrypt + HMAC sessions + absolute expiry + secure flag + CSRF/Fetch-Metadata origin checks + rate limiting + D-021 scoped queries + ghost-404 + role-aware DTO stripping (fail-closed) + demo-mode production fail-fast; probe matrices executed with receipts | Auth still works (login OK); authorization surface intact in code; the *data* currently served is 6 weeks stale (demo-era data, not a leak); RLS-on-PG never runtime-tested | **A− / B−** |
| **CRM business logic** | All lifecycle guards verified in code (D1–D10, booking preconditions, one-hold-per-deal, closure gate, auto-advance, journey engine shared by all surfaces) | Golden path unreachable (leads/dashboard APIs down) | **A / F** |
| **UI/UX** | Binding design system, semantic type scale, oklch tokens with documented WCAG repair, RTL/LTR ×3 languages, 12 views, mini-map, role-scoped dashboards; 300+ screenshot evidence corpus | Renders but degraded: 7+ raw i18n keys in shell/nav/leads; misleading «0 résultat(s)» empty state on failed fetch | **A− / C+** |
| **Performance** | 0 N+1 (audited), pagination on heavy endpoints, dynamic chart imports, cache headers, WAL, 10k-row benchmark receipts | Unmeasurable (core surfaces down) | **B+ / n.a.** |
| **Testing & quality** | 5-gate protocol (lint 0 · tsc 0 · matrix · console-0 · baseline byte-exact) executed every round with receipts; standing 333-probe matrix; golden-path E2E as the regression suite | Working tree: tsc FAILS (23 errors, all untracked-file contamination); lint 0; runtime gates red | **B+ / D** |
| **Governance & documentation** | Exceptional: worklog (4,771 lines), decision log (D-NNN), owner-decision register, honest-limits sections in every delivery doc, rejected-recommendation records, recovery runbooks | Two doc-drift items (AGENTS.md invariant #5 stale; roadmap task cells never flipped — status lives in header layers); undocumented orphaned afternoon work | **A / —** |

## 2. The single structural risk: environment ≠ repository

The program's actual weak point is not the code — it is the **lifetime of verified state in this sandbox**. Every "verified" runtime claim in the delivery docs was true at its commit timestamp and is preserved as evidence; the environment reset that followed the last commit (DB restored to Oct-2 era, backups wiped, deleted files resurrected, cron reaped) has pushed the *running system* below the verified baseline without touching the repository. The project diagnosed this class itself (R13 root-cause determination, commit `e2eb6f7`: sandbox re-provisions untracked state at session boot; "not an app defect; no in-repo fix warranted; the class cannot recur in production") and wrote the countermeasure into law (AGENTS.md: recovery runbook + mandatory D-040/D-041 resurrection sweep **before any steady-state witness**). The countermeasure exists, is documented, and simply has not been executed since the latest reset — because no engineering session has run since.

**Consequence for reading prior reports:** every claim of the form "gates green / console-0 / 17/17 migrations" in the Phase-1/Phase-2 documents is a **timestamped record**, not a statement about the present. This audit found zero evidence of fabrication — the receipts survive and check out — but a reader who treats those documents as a present-tense status will be wrong in exactly the ways §E-6 of the Evidence Index documents.

## 3. What genuinely remains (condensed from the register)

- **P0 — one recovery session:** execute the AGENTS.md runbook (reseed 17/17 + fresh secret + restart), the resurrection sweep (re-delete 5 zombies after purity proof), disposition the 6 orphaned journey-refactor files (complete-or-discard decision), clear the 18 template files. Working tree then returns to tsc-0.
- **P1 — re-verification pass:** re-run the standing matrix + browser sweep against the recovered state; re-establish `db/backups/` baseline; settle the cron-law conflict (P14 "terminally ended" vs. per-session recreation mandate) by owner decision.
- **Owner/env-gated (unchanged):** PG/Supabase RLS runtime test, production build, production deployment checklist, git-history purge before any remote, Vitest (policy-rejected).

## 4. Verdict — is ASAS CRM ready for the next engineering phase?

**As a repository: YES.** HEAD is coherent, the claimed remediation is present in code (43/43 verification checks this audit), quality gates pass on the tracked tree, governance documentation is unusually honest and complete, and no open code defect was found that is not already registered with an owner.

**As a running system: NOT YET — one documented recovery session away.** The current environment serves a broken dashboard, a broken leads list, and raw i18n keys. None of this is a code regression; all of it is the pre-documented environment-reset class with a pre-written countermeasure (Register items R-01…R-04).

**As a program: STRONG, with one systemic dependency.** The engineering process (evidence discipline, honest-limits reporting, rejected-recommendation records, recovery runbooks) is the most rigorous this auditor has seen in a project of this scale — but its runtime guarantees are only as durable as the session-boot protocol that re-establishes baseline after each sandbox reset. The next phase should begin by executing that protocol, then treating "environment recovery executed + resurrection sweep clean" as a standing entry condition for every future session, exactly as AGENTS.md already mandates.

**Recommended next-phase entry sequence (for the owner's next implementation session, not this audit):**
1. R-01 recovery runbook → 2. R-02 resurrection sweep → 3. R-03/R-04 orphan disposition → 4. tsc/lint/matrix/browser re-verification (R-11) → 5. owner decisions on R-06 (cron law), R-13 (revival split-flow), R-16 (history purge timing) → 6. then, and only then, new feature work.

---

*Audit boundary honored: zero implementation writes; zero schema/DB mutations; zero git operations beyond read-only inspection; zero deployments; zero pushes; user modifications preserved untouched (the 36 untracked paths are itemized, not altered). The only files created are this document set (4 audit documents) and 2 evidence screenshots under `evidence/phase-status-audit/`.*
