# ASAS CRM — CRM Domain Audit (Agent E)

## Lifecycle machines (EXISTING rules, cited)
- **Lead** (`constants.ts:13,90-105`; enforced `leads/[id]/route.ts:161-266`): NEW/CONTACTED/QUALIFIED/CONVERTED/CLOSED_LOST/REACTIVATED; skip-forward legal; CLOSED_LOST needs lostReason (+stamp); leaving CLOSED_LOST clears lost fields; CONVERTED terminal double-locked (entry+exit 422); illegal edges = MANAGER correction w/ reason + audit; mutation+Activity+Audit in ONE tx.
- **Journey** (`lib/journey.ts`): 8 stages DERIVED never stored (facts: lead status, lastContactAt, requirement, visits, opp stages, reservation statuses); WON outranks LOST; regression automatic; same pure fn runs server (journey/stats routes) + client (rail).
- **Opportunity** (`constants.ts:16-143`; `opportunities/[id]/route.ts`): 10 stages; forward-with-skip legal; CLOSED_LOST from every stage (reason); CLOSED_WON entry = correction-class + **visit/report gate** (≥1 COMPLETED visit on THIS opp + same lead + structured report) — enforced in PATCH and in validate_closure, no bypass; reopen of WON backed by CONVERTED reservation refused (OPPORTUNITY_BACKED_BY_SALE); stageChangedAt+closedAt stamped; delete only NEW/CLOSED_LOST w/o reservations; WIP limit warn-never-block (law).
- **Reservation** (two-step closure; `reservation-lifecycle.ts`): request_closure (agent/manager, evidence) → validate_closure (MANAGER, visit-gate in tx, idempotent status-preconditioned updateMany, ONE tx: CONVERTED + apartment SOLD + opp CLOSED_WON) / reject_closure → ACTIVE; cancel = MANAGER (reason, releases unit); expire = sweeper only (lazy, guarded release). Booking: in-tx apartment AVAILABLE re-read + latest-reservation ACTIVE check → 409.

## Confirmed defects (evidence)
- **D1 P1 — Reservation revive repurposes money records**: `reservations/route.ts:173-203` re-books by UPDATING the latest row; payload resets deal fields but NOT commission/incentive/closure families, and Installment/Payment/SavCase FK `reservationId` — old client's échéancier silently transfers to the new deal. **Live precondition: ACTIVE reservation w/ 5 installments (24.36M DZD) + 2 payments (8.7M DZD).**
- **D2 P2** — apartment PATCH coherence guard counts only ACTIVE (`apartments/[id]/route.ts:60-76`); CLOSURE_REQUESTED hold can be silently destroyed + stale closure fields survive revival.
- **D3 P2** — opp → CLOSED_LOST allowed while its ACTIVE/CLOSURE_REQUESTED reservation holds the unit; NULL-expiresAt holds never expire (D9) → permanent strand, invisible to orphan-holds card (which shows only no-hold RESERVED units).
- **D4 P2** — booking has no opp-stage precondition: can book on CLOSED_LOST/CLOSED_WON; validate_closure then flips CLOSED_LOST→WON with no resurrection-class audit.
- **D5 P2** — lead reassign doesn't cascade `Opportunity.ownerId` (nor tasks/visits): agent B's drawer+journey show the deal, kanban hides it (opp scope = ownerId); agent A's kanban shows it, drawer 404s.
- **D6 P2** — create-opp dialog offers CLOSED_WON birth; server always 422s (dialog rule copy diverged from server law).
- **D7 P3** — validate_closure doesn't stamp opp `stageChangedAt` (PATCH + creation do; seed masks it).
- **D8 P3** — `/reactivate` violates tx law: update then logActivity outside `$transaction`, no audit row, no fault hook.
- **D9 P3** — sweeper lazy (only reservations/notifications GETs); NULL-expiry holds immortal.
- **D10 P3** — `cancel` releases apartment unconditionally (sweeper guards "only if still RESERVED"; manager-set BLOCKED silently overwritten).
- **D11 P3** — manual activity POST: lastContactAt refresh outside tx; CALL on NEW lead doesn't advance status (journey=ENGAGED, chip=NEW).
- **D12 P3** — no idempotency on timeline writes (double-click = twin rows; 0 in DB today).
- **D13 P3** — three "conversion" definitions (analytics won/total; dashboard created-cohort-current-state; journey peak) + two aging semantics (total age vs days-in-stage).
- **D14 P3** — journey rail feeds approximated facts (`lostAt:null`, `closedAt: stageChangedAt`) vs worklist's true facts — client type lacks closedAt/lostAt.

## Rule duplication inventory (drift risks)
1. Birth-closed-won dialog contract vs server refusal (**contradictory** — D6). 2. CONVERTED bulk exclusion UI+server. 3. Visit ladders hand-coded ×3 (visit-row.tsx:71-109 "mirrors VISIT_TRANSITIONS", calendar-day-agenda.tsx:83-111, lead-drawer-info.tsx:115-118). 4. Terminal-at-birth prerequisites ×2. 5. Lost-reason law ×3 triggers. 6. WIP warning client-only (by design). 7. Journey facts mapping ×2 suppliers. 8. RESERVATION_STATUSES re-declared (missing CLOSURE_REQUESTED in `?status=` filter). 9. Orphan-holds predicate server/card (aligned).

## Data coherence (SELECT-only): statuses coherent; **perfect 7/7/7 triad** (WON↔CONVERTED↔SOLD); 0 orphan holds; 0 apartments w/ >1 reservation; 0 stranded visits/tasks on terminal deals; 0 duplicate activities; lost discipline perfect; D1 precondition present.

## Adopted fixes: D1 guard+reset (409 when installments/payments/SAV exist; else full economics/closure reset) · D2 count CLOSURE_REQUESTED both guards · D3 422 on LOST w/ active hold · D4 working-stages precondition + manager override w/ reason · D6 remove CLOSED_WON from dialog · D5 cascade open-opp ownership on lead reassign · D7 stamp · D8 tx+audit · D10 guarded release · P3 batch (D9/D11/D12/D13/D14 + ladders dedup) as follow-up.
