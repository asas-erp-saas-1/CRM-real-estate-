# ASAS CRM — Phase 2R API Architecture & Runtime Recovery Report (Task 1-c)

**Agent:** 3 (API architecture & runtime recovery investigation)
**Mode:** READ-ONLY investigation (no source modifications, no git state changes, no build, no DB seeding, unauthenticated probes only)
**Subject state:** git `main` @ `693bff9` (working tree clean) · reference `b34d5b8` · contamination `753d115` · dev server `next dev` :3000 (Next 16.1.3, Turbopack)
**Report status:** PART 1 — INVESTIGATION (pre-recovery state)

Fact marking convention used throughout: **[VERIFIED]** = directly re-executed/read this session with cited evidence · **[INFERENCE]** = reasoned from verified facts, not directly re-executed · **[NOT VERIFIED]** = could not be executed in current environment.

---

## §1 Executive summary

1. **The reported defect reproduces exactly as described** **[VERIFIED]**: `GET /api/journey/export` → `500 text/html; charset=utf-8` (11,189-byte Next.js dev error page), **byte-identical** to `evidence/independent-audit/poisoned-api-response.html` (`diff -q` → identical). The full Turbopack compiler error is embedded in the page's `__NEXT_DATA__` (decoded in §3).
2. **The blast radius is NOT route-local — it is the entire API surface** **[VERIFIED]**. After the first request to the broken route, every probed API route (`/api/journey`, `/api/journey/stats`, `/api/auth/session`, `/api/leads`, `/api/leads/check-duplicates`, `/api/properties/unit-types`, bare `/api`) returned the **identical** 500 HTML page with the same embedded journey-worklist compile error, while page routes (`GET /` → 200) stayed healthy. `dev.log` captures the healthy→poisoned transition live (line 443 `GET /api/auth/session 200` → line 444 compile error → line 624 `GET /api/auth/session 500`). The poisoning is sticky for the life of the dev-server process; only GET / (the client/pages compilation project) is unaffected.
3. **Root cause confirmed: a stale, never-committed, superseded working file** **[VERIFIED]**. `src/lib/server/journey-worklist.ts` (mtime 2026-11-01 17:26) imports `isJourneyStalled` from `@/lib/journey`; the current engine (== the `b34d5b8` version, mtime 20:34 — rewritten *after* the worklist loader was written) does not export it, and **no commit in the entire history ever did** (`git log --all -S "isJourneyStalled" -- src/lib/journey.ts` → empty). The abandoned refactor's consumers were swept into git by the environment auto-commit `753d115` (bare-UUID message, 103 files, +8,164 lines, purely additive, zero worklog mention) — the documented "resurrection" class (AGENTS.md:17, D-040/D-041).
4. **This is one facet of the P0 build failure** **[VERIFIED]**: `tsc --noEmit` (run read-only, `--incremental false`) → **exit 1, exactly 20 errors**, of which **1** is `journey-worklist.ts(26,3) TS2724: '"@/lib/journey"' has no exported member named 'isJourneyStalled'` — the only one in a module graph reachable from an API route. `next build` would abort on the 20 (no `ignoreBuildErrors`).
5. **The three resurrected routes' auth posture** **[VERIFIED]**: `check-duplicates` and `unit-types` do enforce `requireUser()` (authenticated, visibility-scoped — they are *policy* violations of D-042, not auth holes); **`GET /api` ("Hello, world!") enforces nothing — an unauthenticated public JSON endpoint** with no middleware behind it (no `src/middleware.ts` exists), live-verified 200 `{"message":"Hello, world!"}` by the audit's healthy-window probe (T-2.15) and deleted twice before in history (66b7c13, 9d635d7).
6. **Zero live UI callers** **[VERIFIED]**: no reference to `journey/export`, `check-duplicates`, or `unit-types` anywhere in `src/` except the route files themselves. The live journey UI is `journey-view.tsx` → `GET /api/journey` and `journey-performance.tsx` → `GET /api/journey/stats` — both self-contained, importing `@/lib/journey` directly, both **unmodified vs the reference state** (diff b34d5b8→HEAD on `src/app/api/` is purely additive: exactly 4 added route files, zero modified).
7. **Recommendation (§8–§9): Option A — delete the route + its stale dependency files** as this lane's slice of the D-040/D-041 resurrection sweep (P34 precedent, authenticated-404 verification). Option B (repair the import surface) is fully specified line-by-line in §8 as the fallback *only if* the Principal rules the journey-export capability genuinely wanted; Option C (wire new UI) is rejected as new-feature work the mission forbids.

---

## §2 Failure reproduction + blast-radius evidence

### 2.1 Primary reproduction [VERIFIED]

```
$ curl -s -o /tmp/p2r-export.html -w "%{http_code} %{content_type}" http://localhost:3000/api/journey/export
500 text/html; charset=utf-8            # body: 11,189 bytes, Next.js dev error page
$ diff /tmp/p2r-export.html evidence/independent-audit/poisoned-api-response.html
( no output — byte-identical )
```

### 2.2 Bogus-query probe [VERIFIED]

```
$ curl … "http://localhost:3000/api/journey/export?stage=BOGUS"
500 text/html; charset=utf-8            # same error page — query parsing never runs
dev.log: GET /api/journey/export?stage=BOGUS 500 in 11ms (compile: 7ms, render: 4ms)
```

### 2.3 Blast radius [VERIFIED — all probes executed in one window, after §2.1]

| Probe | Result | Body |
|---|---|---|
| `GET /api/journey` | `500 text/html` | identical error page |
| `GET /api/journey/stats` | `500 text/html` | identical error page |
| `GET /api/journey/export?stage=BOGUS` | `500 text/html` | identical error page |
| `GET /api/auth/session` | `500 text/html` | identical error page (`diff` vs export capture → identical) |
| `GET /api/leads` | `500 text/html` | identical error page |
| `GET /api/leads/check-duplicates` | `500 text/html` | identical error page |
| `GET /api/properties/unit-types` | `500 text/html` | identical error page |
| `GET /api` | `500 text/html` | identical error page |
| `GET /` (page route) | **`200 text/html`** | the app shell renders normally |

**Stickiness [VERIFIED]** — `dev.log` timeline of this very session:

```
line 443: GET /api/auth/session 200 in 23ms        ← healthy (pre-poisoning)
line 444: ⨯ ./src/lib/server/journey-worklist.ts:23:1   ← compile error enters
line 490: GET /api/journey/export 500 in 1314ms (compile: 1233ms)
line 519: GET /api/journey 500          line 548: GET /api/journey/stats 500
line 595: GET /api/journey/export?stage=BOGUS 500
line 624: GET /api/auth/session 500     ← previously-compiled route now degraded
line 653/682/711/740: GET /api/leads · check-duplicates · unit-types · /api — all 500
line 769: GET /api/auth/session 500     line 784: GET / 200   ← pages unaffected
```

The error page contains **no timestamp**, which is why the auditor's captured evidence and my reproduction are byte-identical. The current `dev.log` carries 4 journey-worklist error occurrences (mine); the audit session's log carried 203 — consistent with a dev-server restart between the audit and this session (the log starts fresh with an `EADDRINUSE` note and a healthy `GET /api/auth/session 200` window).

**Mechanism [INFERENCE, consistent with all observations]**: Turbopack dev compiles API route handlers as one `[app-route]` project. The broken module makes that project's compilation fail; the dev server then answers *every* request that needs the server-route runtime with the project-level error page — including routes that had compiled successfully earlier (session 200→500 above). Page/client compilation is a separate project, so `GET /` keeps serving 200. This matches the audit's ND-A3 description ("dev-mode module-resolution failure is sticky… server never recovers without a restart") exactly.

**POST probe [NOT VERIFIED — environment]**: the dev server (pid 1120) died at ~14:45 during this investigation — coinciding with a concurrent agent's `bun run build` + `/tmp/b34-check` tsc run against the shared `.next` (observed via `ps aux`; the project's own logs document this "mid-gap server death / R14 pattern" and the `.next`-conflict class). `POST /api/journey/export` therefore returned connection-refused (`000`). Inference: it would return the same 500 HTML — the failure occurs at module resolution, before method routing (as the bogus-query probe already proved for query handling). All other findings above were captured before the death.

---

## §3 Root-cause analysis

### 3.1 The embedded compiler error, decoded [VERIFIED]

The 500 HTML's `__NEXT_DATA__` carries `page:"/_error"`, `statusCode:500`, and:

```
./src/lib/server/journey-worklist.ts:23:1
Export isJourneyStalled doesn't exist in target module
 21 | import { toLeadDTO } from "@/lib/server/leads";
 22 | import { qp } from "@/lib/server/validation";
> 23 | import {
> 24 |   computeJourney,
> 25 |   computeUrgency,
> 26 |   isJourneyStalled,
> 27 |   JOURNEY_STAGES,
> 28 |   type JourneyStage,
> 29 | } from "@/lib/journey";

The export isJourneyStalled was not found in module
[project]/src/lib/journey.ts [app-route] (ecmascript).
Did you mean to import computeJourneyStats?
All exports of the module are statically known (It doesn't have dynamic exports).
So it's known statically that the requested export doesn't exist.

Import trace:
  App Route:
    ./src/lib/server/journey-worklist.ts
    ./src/app/api/journey/export/route.ts
```

`tsc` agrees: `src/lib/server/journey-worklist.ts(26,3): error TS2724: '"@/lib/journey"' has no exported member named 'isJourneyStalled'. Did you mean 'JourneyStage'?` — and reports **no other error in that file** (the rest of the 270-line module type-checks).

### 3.2 The current `@/lib/journey` export surface [VERIFIED — enumerated]

`src/lib/journey.ts` (748 lines; identical to the `b34d5b8` version — the b34d5b8→HEAD src diff does not touch it) exports:

| Category | Exports |
|---|---|
| Stage vocabulary | `JOURNEY_STAGES`, `JOURNEY_STAGE_SLA_DAYS`, `JOURNEY_FLOW`, types `JourneyStage` |
| Next-actions | `JOURNEY_NEXT_ACTIONS`, type `JourneyNextAction` |
| Urgency | `JOURNEY_URGENCY_TIERS`, type `JourneyUrgency`, `JOURNEY_URGENCY_TIERS`, `computeUrgency`, type `JourneyUrgencyAssessment` |
| Facts (inputs) | `JourneyLeadFacts`, `JourneyVisitFacts`, `JourneyOpportunityFacts`, `JourneyReservationFacts`, `JourneyFacts` |
| State (outputs) | `JourneyEvidenceItem`, `JourneyState`, `computeJourney` |
| Stats layer | `computePeakStage`, `computeJourneyStats`, types `JourneyStatsFunnelStep`, `JourneyStatsLiveStage`, `JourneyStatsOutcome`, `JourneyStats` |

**There is no `isJourneyStalled` — and there never was.** The current stalled-detection law lives *inside* `computeJourneyStats` (velocity panel, lines 674–683):

```ts
if (e.journey.since) {
  const age = daysBetween(e.journey.since, now);
  if (age >= 0) {                       // future `since` (upcoming visit anchors VIEWING) is not aging
    bucket.ageSum += age; bucket.datable += 1;
    if (age > JOURNEY_STAGE_SLA_DAYS[stage]) bucket.stalled += 1;
  }
}
```

…backed by the exported `JOURNEY_STAGE_SLA_DAYS` table (`CAPTURED:3, ENGAGED:7, QUALIFIED:7, VIEWING:14, NEGOTIATING:14, BOOKING:21` — no SLA for WON/LOST). This is the *equivalent* of the missing predicate — but it is aggregate-only; no per-customer boolean is exported anywhere.

### 3.3 Why the file is broken: superseded mid-refactor [VERIFIED]

- `src/lib/server/journey-worklist.ts` mtime **2026-11-01 17:26:22**; `src/app/api/journey/export/route.ts` mtime **2026-11-01 17:28:01** — written during the Nov-1 afternoon working session (the "R13 journey round" — see §7).
- `src/lib/journey.ts` mtime **2026-11-01 20:34:09** — the engine was rewritten **after** those consumers were written, and the shape that got committed at `b34d5b8` (2026-11-02 00:39) moved stalled detection into `computeJourneyStats` and never grew `isJourneyStalled`.
- `git log --all -S "isJourneyStalled" -- src/lib/journey.ts` → **empty**: no commit of the engine ever contained the symbol. The consumers were written against an *intended* engine surface that was never landed — an interrupted refactor (the register's classification: "IN PROGRESS → abandoned mid-refactor").
- The stale pair then sat **untracked** on disk until the environment auto-commit `753d115` (2026-11-02 07:26, bare-UUID message, purely additive, zero worklog reference) swept all untracked debris into git.
- `isJourneyStalled` appears in exactly two commits in all of history: `753d115` (adds the worklist import) and `693bff9` (adds the audit's evidence HTML, which embeds the error text). `JOURNEY_EXPORTED` appears only in `753d115` (the route file).

### 3.4 Classification

**Stale never-wired never-committed working artifact (superseded mid-refactor), committed by environment debris auto-commit — NOT a shared-infrastructure defect.** The shared infrastructure the route depends on (`@/lib/server/session|visibility|audit|csv|validation|leads`, `@/lib/phone`, `@/lib/db`) is intact and **unmodified vs `b34d5b8`** (the whole b34d5b8→HEAD diff on `src/` is purely additive). The runtime severity is nevertheless **global** (§2): one broken import poisons the dev server's entire API surface, and the same error is one of the 20 tsc failures that abort `next build` (ND-A1, P0).

The Principal's hypothesis — *stale superseded working file; compile-broken; zero live callers; never committed; functionality absent from the verified reference state* — is **CONFIRMED on all five counts**. The one refinement: the failure is **not route-local at runtime**; the import trace names the route, but the dev-mode blast radius is every API route.

---

## §4 The intended contract (from code + comments — the route *as written*)

`src/app/api/journey/export/route.ts` (121 lines) — the contract the file would serve **if it compiled**:

- **Method:** `GET` only (single exported handler).
- **Auth & role:** `requireUser("MANAGER")` first statement — per the file header, "the `journey.export` permission rides the same RBAC row as `lead.export` — exports are a management activity". Same-origin enforcement (D-018/19/20) lives inside `requireUser` as on every route.
- **Query params** (via `parseJourneyWorklistQuery`, the shared list/export contract):
  - `stage` — one of `JOURNEY_STAGES`, else `422 INVALID_STAGE` (with `allowed` list);
  - `owner` — `"me" | "unassigned"` (MANAGER+ only, ignored below) or an agent id validated against the caller's org → honest `422 UNKNOWN_OWNER` for stale ids;
  - `stalled=1` — stalled-only filter;
  - `query` — free text on name/phone/email.
- **Scope law (D-021):** `leadScope(user)` LEAD-visibility, `archived:false` (live funnel only), `take:500`; MANAGER+ sees the org (plus owner refinements), SALES_AGENT OWN+POOL, FIELD_REP the leads of visits on their assigned projects.
- **Pipeline ("export what you see"):** the *same* loader as `GET /api/journey` — one batched lead load with lean fact projections + ONE batched reservation fetch (Phase D money-path join, no N+1) → `computeJourney` → `computeUrgency` → stalled flag → prioritized order (urgency rank desc → reasons count desc → newest first).
- **Response 200:** `text/csv; charset=utf-8`, `Content-Disposition: attachment; filename="asas-parcours-YYYY-MM-DD.csv"`, `Cache-Control: no-store`; body from `csvDocument(HEADERS, rows)` — **semicolon-separated + UTF-8 BOM + CRLF** (FR-locale Excel default; same law as the leads export). 23 columns: `id, fullName, phone, phoneDisplay, email, journeyStage, stageSince, daysInStage, urgency, urgencyRank, stalled, nextAction, oppValue, reservationAmount, nextVisitAt, owner, score, priority, source, createdAt, lastContactAt, nextFollowUpAt`. Free-text columns flow through `csvEscape` (formula-injection defanging, P4-8 F-14); enum-ish columns export raw stable ids; `stalled` as `"1"/"0"`.
- **Side effect:** `logAudit({ action: "JOURNEY_EXPORTED", entity: "LEAD", after: { count, scope, filters } })` — `AuditLog.action` is a free-form `String` in the schema (no enum constraint [VERIFIED]), so the action value is runtime-valid as written.
- **Error modes:** unauthenticated → 401 JSON (NO_SESSION) via `requireUser`; below-MANAGER → 403 JSON `EXPORT_FORBIDDEN` with the French message «L'export du parcours client requiert le rôle Manager ou supérieur.»; invalid params → 422; everything else → `fail(error)` (the house `ApiError` contract).
- **Architecture-invariant compliance as written:** `requireUser` → query validation (`qp`-based, same as the live journey route) → visibility-scoped Prisma query → audit side effect → response; `ApiError` thrown — the route follows the house law; it is broken *only* at the import of its stale dependency.
- **Callers:** **zero** — no reference to `journey/export` anywhere in `src/` except the route file itself [VERIFIED].

**Comparison with the live leads export it mirrors** (`src/app/api/leads/export/route.ts` + `src/components/crm/views/leads/use-export.ts`) [VERIFIED]: same role gate (`requireUser("MANAGER")`), same CSV law (`csvDocument`/BOM/CRLF/`csvEscape`), same audit pattern (`LEADS_EXPORTED` with the applied filter set), same 403 handler shape — but the leads export is **wired** (`use-export.ts:52` `fetch("/api/leads/export…", { credentials: "same-origin" })`, 403 → actionable toast) and self-contained (no stale loader). The journey export was built to mirror it, but its "one pipeline, two consumers" extraction (`journey-worklist.ts`) is the part that was abandoned mid-refactor.

---

## §5 Resurrected routes — security posture [VERIFIED by code reading; runtime postures per audit healthy-window evidence]

| Route | Auth | Visibility | Verdict |
|---|---|---|---|
| `GET /api/leads/check-duplicates` | `requireUser()` ✓ (first statement) | `leadScope(user)` ✓ — foreign duplicates signaled existence-only (`foreignBlocked`) | **Authenticated; a D-042 policy violation, not an auth hole.** Zero live callers; the duplicate capability is served live by POST-side `DUPLICATE 409 + force:true`, the import preview, and P30's scan/merge/dismiss (P34 rationale). Deleted at P34 (`bb13147`) with authenticated-404 verification; resurrected by `753d115`. |
| `GET /api/properties/unit-types` | `requireUser()` ✓ | n/a (constant) | **Authenticated; D-042 violation.** Serves `UNIT_TYPES` which every client imports directly from `@/lib/constants` (redundant surface). Same P34 deletion + resurrection. |
| `GET /api` ("Hello, world!") | **NONE** — no `requireUser`, no origin check; and **no `src/middleware.ts` exists** at HEAD or at `b34d5b8` | none | **UNAUTHENTICATED PUBLIC INFO ENDPOINT.** Returns `200 {"message":"Hello, world!"}` to anyone (live-verified in the audit's healthy window, T-2.15; my probe hit the poisoned 500 instead, and the server later died — the code posture is unambiguous). Exposes no data (static scaffold string), so direct risk is LOW, but it (a) violates two closed hardening decisions — deleted at `66b7c13` (P2-era: "a LIVE «Hello, world!» production endpoint, GET /api 200, zero live references") and re-deleted at `9d635d7` (P33, D-041: "nothing ever-deleted ∧ in-HEAD is tolerable"), (b) breaks the 70/74 `requireUser` invariant (T-9.4's one non-design exception), and (c) would serve 200 unauthenticated in any production build. Classification: resurrection zombie, security-hygiene P3 (audit ND-A4/T-2.15). |

**Resurrection-cycle history** (why these keep coming back) [VERIFIED via `git log --diff-filter=A/D`]: the environment's bare-UUID auto-commits repeatedly re-add previously-deleted files, and documented engineering rounds sweep them. E.g. `src/app/api/route.ts`: created `7a7e255` (env) → deleted `66b7c13` (P2 hardening) → re-created `6441909`-era → deleted `9d635d7` (P33) → re-created `23c04c0` (env) → deleted `b6b70f4` (WS-B) → re-created `9cdf1fb` (env) → deleted `26d253e` (Phase D) → **re-created `753d115` — still unswept at HEAD**. `check-duplicates`/`unit-types` show the same multi-cycle pattern ending in the P34 deletion (`bb13147`) and the `753d115` resurrection. This is the fourth-plus resurrection — the class AGENTS.md:17 mandates sweeping before any steady-state witness.

---

## §6 Audit-claims cross-check

What the 693bff9 audit documents claimed about this endpoint, and my verification:

| Claim (doc) | My verification |
|---|---|
| INDEPENDENT_AUDIT §3.3 / risk #3 / ND-A3: "one request to `/api/journey/export` … poisons every subsequent API request to 500 HTML … including previously-compiled routes … never recovers without a restart" | **CONFIRMED first-hand** (§2: identical 500 HTML across all API routes; session 200→500 transition in dev.log; sticky through end of session). |
| ACCEPTANCE T-6.2: export returns 500 (expected 401 JSON) | **CONFIRMED** (§2.1). |
| ACCEPTANCE T-6.3: `/api/leads` 401 JSON → 500 HTML after touching the broken route | **CONFIRMED** for `/api/leads` and six other routes (§2.3). |
| ACCEPTANCE T-5.1: browser "Build Error" overlay on first load of `/` carrying the same error; console error; "203 occurrences in dev.log" | Overlay/console NOT re-verified by me (browser out of my probe scope; server died before I could re-probe `/`). The 203-occurrence figure matches the audit-session log; the **current** log has 4 (post-restart, mine) — consistent. |
| ACCEPTANCE T-10.8: journey UX wired to live APIs; **UI never calls the broken export** | **CONFIRMED** by grep: zero references to `journey/export` outside the route file; live wiring is `journey-view.tsx` → `/api/journey`, `journey-performance.tsx` → `/api/journey/stats`. |
| DEFECTS REGISTER ND-A1 (P0): build fails at HEAD, "20 tsc errors (15 missing-module … + 5 broken-symbol in journey orphans)" | **CONFIRMED by re-running** `tsc --noEmit --incremental false`: exactly 20 — 14× TS2307 + 1× TS2339 in `ui/*` scaffold, 3× in `journey-stats.ts` (`JourneyStatEntry` missing, ×2 shape), 1× `journey-stage-chip.tsx` (`openJourneyFocus`), 1× `journey-worklist.ts` (`isJourneyStalled`) — the last being the only route-reachable one. |
| ND-A3 remediation: "sweep removes the route (or fixes the 4 missing exports if journey export is genuinely wanted)" | Consistent with my §8 analysis (A vs B). |
| ND-A4: dead endpoints incl. junk `GET /api` (also unguarded) | **CONFIRMED** (§5). |
| REMAINING_WORK_REGISTER R-03: the orphaned Nov-1-afternoon work — 6 source files + 3 evidence folders, "either complete the journey refactor (requires re-adding `openJourneyFocus` … `JourneyStatEntry`/`isJourneyStalled` …) or discard with a documented decision" | **CONFIRMED**: the 6 files are `journey-{stats,facet,worklist}.ts`, `api/journey/export/route.ts`, `journey-stage-chip.tsx` + `tmp-scripts`; mtimes verified (worklist 17:26:22, route 17:28:01 — inside the register's 14:46–17:38 window). |
| PHASE_COMPLETION_STATUS: orphaned work "references non-existent exports → 6 of the 23 working-tree tsc errors … never claimed complete anywhere" | **CONFIRMED** (5 journey-class tsc errors at HEAD after the debris was committed; the 6th was a tmp-script). |
| "D-19 or similar API findings" | **No "D-19" exists** in any docs/audits file [VERIFIED by grep]. The operative identifiers are **ND-A1 / ND-A3 / ND-A4 / ND-A5** (register), **T-1.1 / T-1.3 / T-2.15 / T-5.1 / T-6.2 / T-6.3 / T-10.8** (acceptance), risk rows 1–3 (audit report). |
| Audit report §3.1 attributes the check-duplicates/unit-types/view-placeholder deletion to "the 26d253e sweep" | **Minor imprecision in the audit doc**: the D-042 deletion commit is `bb13147` (P34 — its message lists all three under `git rm ×3` with authenticated-404 verification); `26d253e` (Phase D) had deleted them in an *earlier* resurrection cycle. Both statements are true at different points of the multi-cycle history (§5). |

---

## §7 Git archaeology

- **Was a journey export route ever committed before the contamination? NO** [VERIFIED]: `git log --all --oneline -- src/app/api/journey/export/` → only `753d115`. Same for `src/lib/server/journey-worklist.ts`, `journey-facet.ts`, `journey-stats.ts`.
- **Was `JOURNEY_EXPORTED` ever an audit action anywhere? NO** [VERIFIED]: `git log --all -S "JOURNEY_EXPORTED"` → only `753d115` (the route file). It never existed in `src/lib/i18n`, constants, or any other file in history.
- **Did `isJourneyStalled` ever exist in a committed engine? NO** [VERIFIED]: path-filtered `git log --all -S "isJourneyStalled" -- src/lib/journey.ts` → empty; `git show b34d5b8:src/lib/journey.ts | grep -c isJourneyStalled` → 0.
- **The verified reference state (`b34d5b8`) has NO journey export**: its journey surface is exactly `GET /api/journey` (worklist) + `GET /api/journey/stats` (stats), both read and confirmed self-contained (importing `computeJourney`/`computeUrgency`/`computeJourneyStats` from `@/lib/journey` directly — the stats route even builds its per-customer entries inline rather than via any shared loader).
- **b34d5b8 → HEAD is purely additive on `src/`** [VERIFIED]: `git diff --name-status b34d5b8 HEAD -- src/app/api/` → exactly `A src/app/api/journey/export/route.ts`, `A src/app/api/leads/check-duplicates/route.ts`, `A src/app/api/properties/unit-types/route.ts`, `A src/app/api/route.ts` — **zero modified or deleted live routes** (duty #9 clean). The whole-tree delta is 114 files: 103 from `753d115` (incl. the i18n zombie, 17 `ui/*` scaffold components, 2 hooks, `journey-{stats,facet,worklist}.ts`, `journey-stage-chip.tsx`, `view-placeholder.tsx`, `tmp-scripts/`, 40+ evidence PNGs, 4 status docs) + 11 audit files from `693bff9`.
- **R13-era evidence that the feature once worked in-browser** [VERIFIED the artifacts exist; their content is screenshot-class]: `evidence/qa-r13/12-journey-export-toast.png` **exists** (19 files: `00-login` … `18-en-dark-leads`, incl. `03-journey`, `11-facet-qualified`, `13-facet-popover`, `14-facet-checked-tint`, `17-mobile-journey`). The sibling orphan folders imply the abandoned session's full surface: `evidence/qa-continue/` (19 PNGs incl. `13-stalled-filter`, `14-stalled-drill`, `18-agent-stalled` — a stalled-filter UI the *current* live worklist route/UI does **not** have, since `GET /api/journey` supports only `stage/owner/query`) and `evidence/qa-unify/` (9 PNGs). Implication [INFERENCE]: during the Nov-1 session the export endpoint (plus stalled filtering, journey-stage facets, and the stage chip) functioned in-browser against a then-current engine surface that exported `isJourneyStalled` — and that surface was superseded at 20:34 by the committed engine, orphaning every consumer. The screenshots are the only proof the endpoint ever executed; nothing committed ever referenced it.
- **The contamination commit profile** [VERIFIED]: `753d115` = bare-UUID message, 103 files / +8,164 lines, purely additive (`--diff-filter=DMRT` empty), ~7h after `b34d5b8`, zero worklog references — matching the environment's documented resurrection auto-commit class (AGENTS.md:17: "the environment resurrects deleted files into the tree (P25 small wave; P31 committed a 21-file wave unnoticed)"). `693bff9` (HEAD) only adds the audit documents and evidence on top.

---

## §8 Remediation options analysis

Mission constraints in tension: (i) "Repair the verified defect. Maintain the intended endpoint behavior and API contract. Do not disable the endpoint to avoid the problem." vs (ii) the recovery objective "restore a repository functionally equivalent to the previously verified reference state while preserving every legitimate engineering improvement made afterward" and the binding law **D-042: never-wired must be wired-or-deleted** (plus D-040/D-041: nothing ever-deleted ∧ in-HEAD is tolerable). Resolution hinges on one verified fact: **the endpoint has no existence in the verified reference state and no verified contract anywhere in history** (§7). The "verified defect" the mission names is the global 500 poisoning — and the *verified system's* behavior for this URL is a 404 (the same honest end-state P34 produced for the other never-wired routes, with authenticated-404 verification).

### Option A — DELETE the route + its stale dependency files (this lane's slice of the D-040 sweep)

**Work items (precise):**
1. `git rm src/app/api/journey/export/route.ts src/lib/server/journey-worklist.ts` — this defect's two-file set. (The coordinated sweep set owned by the other lanes, per the audit's ND-A1 recipe: `src/lib/i18n.ts`, `src/lib/server/journey-stats.ts`, `journey-facet.ts`, `src/components/crm/journey-stage-chip.tsx`, `view-placeholder.tsx`, the 17 `ui/*` scaffold components + 2 hooks, `check-duplicates` + `unit-types` + `api/route.ts` routes — each with its own content-hash purity proof per AGENTS.md.)
2. Content-hash purity proof for each file before deletion (`git rev-parse <deleting-commit>^:<path>` where applicable; for never-committed files, the never-tracked proof of §7 stands in).
3. **Restart-with-cleared-`.next` protocol** (AGENTS.md:17, learned at P33): kill the stale next-server **by PID from `ss -tlnp`** (pkill can leave the port held), clear `.next`, restart — route deletions leave a generated route-type validator referencing the deleted module until regeneration.
4. Verification: unauthenticated `GET /api/journey/export` → **404**; `GET /api/auth/session` → 200 JSON `{"user":null,…}`; the full unauth matrix back to 401-JSON shapes (the audit's T-2 battery); `tsc` loses the journey-worklist error; dev.log free of journey-worklist errors.
5. Governance repair (ND-A5): real commit message + worklog entry documenting `753d115`'s provenance and the sweep.

**Pros:** exact reference-state equivalence (mission objective ii); D-040/D-041/D-042 compliance; P34 precedent with authenticated-404 verification; kills the poisoning at its root; removes the only route-reachable tsc error. **Cons:** none technically; the mission sentence (i) is satisfied *by interpretation* — deleting a never-shipped artifact is not "disabling the endpoint to avoid the problem": the verified system's contract for `/api/journey/export` **is** 404, and the poisoned-API defect is fully repaired (not avoided).

### Option B — REPAIR: rewrite the stale imports against the current engine surface

**Precise work items (all in `src/lib/server/journey-worklist.ts`; the route file itself needs zero changes — every other import it uses resolves: `logAudit`, `requireUser/ApiError/fail`, `csvDocument/csvEscape`, `displayPhone` all verified present):**

1. **Import block (lines 23–29)** — replace with:
   ```ts
   import {
     computeJourney,
     computeUrgency,
     JOURNEY_STAGE_SLA_DAYS,
     JOURNEY_STAGES,
     type JourneyStage,
   } from "@/lib/journey";
   ```
   (drop `isJourneyStalled` — the only missing symbol; every other name is a verified current export).
2. **Add the day constant** near the top (not currently defined in this file): `const DAY_MS = 24 * 60 * 60 * 1000;`
3. **Replace line 219** `const stalledFlag = isJourneyStalled(journey, now);` with the current engine's stalled law (the exact semantics of `computeJourneyStats` lines 674–683, `JOURNEY_STAGE_SLA_DAYS` included):
   ```ts
   const ageDays = journey.since
     ? (now.getTime() - new Date(journey.since).getTime()) / DAY_MS
     : null;
   const stalledFlag =
     ageDays != null &&
     ageDays >= 0 && // a future since (upcoming visit anchors VIEWING) is not aging
     journey.stage !== "WON" &&
     journey.stage !== "LOST" &&
     ageDays > JOURNEY_STAGE_SLA_DAYS[journey.stage];
   ```
   (The WON/LOST guards also satisfy the `Record<Exclude<JourneyStage, "WON"|"LOST">, number>` index typing.)
4. Nothing else: `tsc` reports exactly one error in this file today; the facts cast, visibility scoping, batching, and sort all type-check as written.
5. Verification: dev hot-recompile (no restart needed); unauth `GET /api/journey/export` → 401 JSON NO_SESSION (requireUser is the first statement [INFERENCE from code — runtime verification BLOCKED today by empty DB/missing secret/server death]); then, after the R13 DB recovery runbook (not this lane), an authenticated CSV smoke: headers (`text/csv`, attachment, `no-store`), `stage=BOGUS` → 422 INVALID_STAGE, `owner=<stale-id>` → 422 UNKNOWN_OWNER, below-MANAGER → 403 EXPORT_FORBIDDEN, audit row `JOURNEY_EXPORTED` written.

**Residuals Option B leaves open:** (a) it does **not** cure ND-A1 — 19 other tsc errors still abort `next build` (the sweep is still required for the rest of the debris); (b) the route remains **never-wired** (zero UI callers) — an unwired-but-working route is precisely the class D-042 orders deleted; (c) the repaired `stalledFlag` **re-implements** a law the engine owns inside `computeJourneyStats` — a second definition, in tension with the codebase's G5 single-definition law; the honest B-variant would instead re-add a shared predicate to `src/lib/journey.ts` (e.g. `export function isJourneyStalled(journey: JourneyState, now: Date): boolean` over `JOURNEY_STAGE_SLA_DAYS`) — but that is an engine API surface change, i.e. new-feature work; (d) `journey-stats.ts`/`journey-facet.ts`/`journey-stage-chip.tsx` remain dead and (for two of them) still type-broken companions of the same abandoned round.

### Option C — REPAIR + WIRE (add the export button to `journey-view.tsx`)

**Rejected.** New UI feature work (button, hook, i18n keys ×3 languages, toasts, role-gating, matrix probes) — the mission states "It is NOT a new application development project"; it would also collide with the i18n lane's repair and expand the recovery scope contra objective (ii).

---

## §9 Recommendation

**Option A** — delete `src/app/api/journey/export/route.ts` and `src/lib/server/journey-worklist.ts` as this lane's slice of the coordinated D-040/D-041 resurrection sweep, executed with the P34 protocol (purity proof → `git rm` → restart-with-cleared-`.next` → authenticated/unauthenticated 404 verification → worklog + real commit message).

Rationale, in order of weight:
1. The endpoint is **not part of the verified reference state** and has no committed contract anywhere in history (§7) — "maintain the intended endpoint behavior and API contract" cannot refer to a behavior that was never shipped or verified; the verified system's behavior for this URL is 404.
2. The project's own binding law D-042 ("never-wired must be wired-or-deleted") and D-040/D-041 (nothing ever-deleted ∧ in-HEAD is tolerable) make the deletion *mandatory* once the purity proof is on record — leaving a zero-caller route in the tree is the same defect class P34 closed.
3. It is the only option that repairs the **global** API poisoning and the route-reachable build error while *also* restoring exact reference equivalence; Option B leaves the repo non-building (19 residual tsc errors) and the route still D-042-violating.
4. The P34 precedent (bb13147) did exactly this for the sibling resurrected routes, with documented authenticated-404 verification — the recovery re-establishes the same verified end-state.

**Conditional fallback (only on an explicit Principal ruling that the journey-export capability is genuinely wanted as a management endpoint):** execute the sweep first (restoring the reference state), then implement the feature as a *separately documented* change using the Option-B spec of §8 — preferably its honest variant (export a single shared `isJourneyStalled` predicate from `src/lib/journey.ts` rather than re-implementing the law in the loader) — and wire or explicitly register it per D-042. Until such a ruling, deletion is the correct disposition of the abandoned Nov-1 artifact, and the register's R-03 disposition question is answered: **discard with a documented decision**.

---

## §10 Verdict

**Root-cause classification [VERIFIED]:** stale, never-wired, never-committed working artifact (superseded mid-refactor on 2026-11-01, orphaned on disk, swept into git by the environment's bare-UUID auto-commit `753d115`), whose single broken import (`isJourneyStalled` from `@/lib/journey` — a symbol that never existed in any committed engine) (a) fails Turbopack's `[app-route]` compilation and thereby **poisons the entire dev-server API surface** (500 HTML on every API route, sticky until restart; pages unaffected), and (b) contributes one of the twenty tsc errors that abort `next build` at HEAD (ND-A1, P0). **Not a shared-infrastructure defect** — every shared module the route touches is intact and unmodified vs the reference state; the b34d5b8→HEAD diff on `src/app/api/` is purely additive (4 added route files, 0 modified).

**On the Principal's hypothesis:** CONFIRMED — stale superseded working file, compile-broken, zero live callers, never committed, functionality absent from the verified reference state. One correction: the failure is **not route-local at runtime**; the blast radius is the whole API surface of the dev server (the import trace names one route, the Turbopack error page answers them all).

**On the audit's claims:** corroborated on every point I could re-execute (poisoning, blast radius, tsc-20, zero UI callers, unguarded `GET /api`, orphaned-work classification); one minor imprecision noted (§6, the `26d253e` vs `bb13147` deletion attribution).

**Remediation:** Option A (delete, within the D-040 sweep, P34 protocol) — recommended; Option B fully specified as conditional fallback; Option C rejected.

**Operational notes for the recovery session:** (1) the dev server observed during this investigation (pid 1120) died at ~14:45 alongside a concurrent agent's `bun run build` against the shared `.next` — expect the R14-pattern server death and use the restart-with-cleared-`.next` protocol after any route deletion; (2) authenticated verification of any kind remains BLOCKED until the R13 DB recovery runbook (reseed + `ASAS_SESSION_SECRET`) is executed — outside this lane; (3) after the sweep, the standing verification battery for this lane is: unauth matrix → 401-JSON shapes, `GET /api` → 404, `GET /api/journey/export` → 404, `GET /` → 200 with no Build-Error overlay, `tsc` at the residual-baseline count, dev.log free of journey-worklist errors.

---

### Appendix — evidence index for this report

| Evidence | Where |
|---|---|
| Reproduction capture | `/tmp/p2r-export.html` (11,189 B; identical to `evidence/independent-audit/poisoned-api-response.html`) |
| Blast-radius captures | `/tmp/p2r-session.html` (== export capture), probe loop output (§2.3), `dev.log` lines 443–784 |
| Decoded compiler error | §3.1 (from `__NEXT_DATA__` of the 500 page) |
| tsc run | `node_modules/.bin/tsc --noEmit --incremental false` → 20 errors (full list §6) |
| Git commands | `git log --all -S`, `--diff-filter=A/D`, `git diff --name-status b34d5b8 HEAD`, `git show --stat` for 753d115 / 693bff9 / bb13147 / 9d635d7 / 66b7c13 |
| Route/module sources read | `api/journey/export/route.ts`, `lib/server/journey-{worklist,stats,facet}.ts`, `lib/journey.ts` (full), `api/journey/route.ts`, `api/journey/stats/route.ts`, `api/leads/export/route.ts`, `api/leads/check-duplicates/route.ts`, `api/properties/unit-types/route.ts`, `api/route.ts`, `use-export.ts`, `journey-view.tsx`, `journey-performance.tsx` |
| Audit docs cross-checked | INDEPENDENT_AUDIT_REPORT, REMAINING_DEFECTS_REGISTER, ACCEPTANCE_TEST_RESULTS, REMAINING_WORK_REGISTER, PHASE_COMPLETION_STATUS, EXECUTION_EVIDENCE_INDEX, QUALITY_AUDIT, SECURITY_AUDIT |
| Environment observations | dev-server death ~14:45; concurrent agents' `bun run build` + `/tmp/b34-check` tsc; `ps aux`; `ss -tlnp` |

*Investigation boundary honored: zero source modifications, zero git state changes, no build, no DB writes, no credentials, unauthenticated probes only. The only file created is this report.*

---

# PART 2 — RECOVERY EXECUTION RESULTS (appended by the Principal)

**Executed remediation**: Option A (this report's §9 recommendation), approved as Recovery Plan D-R3 with the full evidence chain and the deviation flag vs the mission's literal Phase-4 text. `git rm src/app/api/journey/export/route.ts src/lib/server/journey-worklist.ts` inside the D-040 sweep (plus the sibling orphans `journey-stats.ts`, `journey-facet.ts`, `journey-stage-chip.tsx` — zero live importers). The P34 protocol followed exactly: purity proof (never-tracked files — the supersession proof of §3/§6) → restart-with-cleared-`.next` (next-server killed BY PID 6723 from `ss -tlnp` → fresh pid 9703; `rm -rf .next`) → endpoint verification → worklog + conventional commit.

## Verification results (post-recovery, curl with cookie-jar sessions + independent browser pass)

| Test (mission Phase-4 battery) | Result |
|---|---|
| 1. Valid request (authed OWNER, journey worklist/stats) | `GET /api/journey` → **200 application/json**, 65 KB, 43-lead stage funnel, scope=org · `GET /api/journey/stats` → **200 application/json**, funnel 43→33→… |
| 2. Invalid request (`?stage=BOGUS`) | Clean JSON error contract (validation layer intact — route unchanged from reference) |
| 3. Unauthorized request | `GET /api/journey` unauth → **401 JSON** `{"error":"No active session…","code":"NO_SESSION"}` · SALES_AGENT on stats → **403 JSON** `FORBIDDEN_ROLE` (MANAGER+ role law intact) |
| 4. The formerly-poisoned URL | `GET /api/journey/export` → **404** (honest endpoint-gone; was 500 HTML with embedded compile error) — the P34-verified deletion pattern |
| 5. Unexpected server error containment | **Re-probe after dead-URL hit: session → 200, journey → 200** — the §2 global-poisoning class is ERADICATED at root (the compile-broken module no longer exists); browser pass confirms with the same server pid held throughout |
| 6. Database access | All live routes query the recovered DB (8 users / 43 leads / 21 opps seeded; journey funnel aggregates computed server-side) |
| 7. Regression of unrelated endpoints | `src/app/api/` diff vs reference = the 4 route deletions only, zero modifications; `GET /api` → **404** (the unauthenticated "Hello, world!" zombie swept — §5's finding closed); login/logout/session/dashboard/leads all healthy per the browser pass (36 view-loads, 0 console errors) |
| Content types | JSON on all live data routes; the 404 renders the standard Next.js not-found page (browser-verified) |
| Cross-route failures | **None** — the poisoning mechanism (turbopack compile error served as 500 HTML for every route once triggered) is structurally gone |

## §8 options → outcome

Option A executed per recommendation. Option B (repair-to-working: swap `journey-worklist.ts` import to `JOURNEY_STAGE_SLA_DAYS` + `DAY_MS` + inline the WON/LOST-guarded stalled law) remains specified in §8 as the owner's post-recovery path should the journey-CSV capability be wanted — as wired feature work (UI button + i18n keys + `JOURNEY_EXPORTED` audit keys in all 3 dicts, per D-042 "wired-or-deleted"). Option C remains rejected (new-feature work outside a recovery mission).

**Part 2 verdict: the verified API defect — global 500 poisoning from a compile-broken zombie route — is REPAIRED at root; live journey contracts verified end-to-end; honest 401/403/404 behavior throughout; zero cross-route regressions.**
