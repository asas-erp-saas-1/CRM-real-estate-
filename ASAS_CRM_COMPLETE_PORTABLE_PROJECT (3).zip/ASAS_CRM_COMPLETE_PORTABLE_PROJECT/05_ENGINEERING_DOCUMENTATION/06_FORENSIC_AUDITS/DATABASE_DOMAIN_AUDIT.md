# ASAS CRM — Phase 2 Database & Domain Model Audit (Task P2-c)

**Agent:** Database Architect + CRM Product Architect (audit subagent)
**Mode:** READ-ONLY (code analysis + read-only SELECTs via `tmp-scripts/p2c-*.ts` against `db/custom.db`)
**Inputs:** `worklog.md` (927 lines), `prisma/schema.prisma` (full), `prisma/seed.ts` (full), `src/lib/constants.ts`, 40+ API route files, master prompt `upload/Pasted Content_1790906996495.txt` (2322 lines).
**DB snapshot audited:** 1 org · 7 users · 1 pipeline (10 stages) · 7 tags · 25 leadTags · **44 leads** · 21 contacts · **22 opportunities** · 3 developers · 4 projects · 6 buildings · **46 apartments** · 15 requirements · 43 propertyMatches · 21 visits · 35 visitApartments · 20 tasks · **175 activities** · **10 reservations** · **123 auditLogs** · 0 savedSearches · 0 documents · 4 orgSettings · 4 salesTargets.

---

## 1. Executive summary

The schema is **well-designed for its stage** (25 models, ADR-disciplined String-as-enum, orgId on every tenant-owned record, transaction-safe reservation booking, append-only audit). Live data is **remarkably clean**: zero enum drift in Lead/Opportunity/Visit/Task/Apartment/Activity values, zero duplicate phones/emails (unique index holds in practice), zero reservation↔apartment status contradictions, and the R10-2 won-deal seeding is **7/7 coherent**.

However the audit found **four structural defects**:

1. **Enum drift, live:** `AuditLog.entity` contains two spellings — `"User"` (46 rows, written by 7 users/auth route call-sites) vs `"USER"` (17 rows, the documented convention). The audit view's entity filter and any future typed queries see a split taxonomy. Source: `src/app/api/users/route.ts:87`, `users/[id]/route.ts:87`, `users/[id]/reset-password/route.ts:51`, `auth/login/route.ts:50,94`, `auth/logout/route.ts:14`, `auth/change-password/route.ts:46`.
2. **Reservation expiry is FAKE-COMPLETENESS (PARTIAL):** `expiresAt` + an `EXPIRED` status value + a manual PATCH endpoint + a *pre*-expiry notification exist, but **nothing ever performs the ACTIVE→EXPIRED transition**. Post-due ACTIVE reservations drop out of the notification window entirely (`expiresAt: { gte: now, lt: horizon }`) and permanently block their apartment.
3. **Seed-created inventory deadlock:** 7 apartments (A-21, B-11, H-12, N-11, V-03 = RESERVED; A-31, H-21 = OPTIONED) carry their status **without any reservation row** — unreleasable through the reservation lifecycle, recoverable only by manual apartment PATCH. Plus 1 ACTIVE reservation (N-21) with `expiresAt = NULL` → a permanent hold.
4. **No migrations, `db:push --accept-data-loss`:** schema evolution can silently drop/recreate columns (SQLite table-recreate) with no confirmation prompt and no migration history. The R10-4 incident (stale Prisma client in the running server → `db.salesTarget undefined` → 500s until restart) is live evidence of the workflow's fragility.

State machines are **mostly free-form** (only 5 rules enforced app-side — see §7); the lead/opportunity lifecycles allow several semantically invalid transitions (documented below with code evidence).

---

## 2. Schema audit — model-by-model verdicts

| # | Model | Relationships / FK | Uniques & indexes | Nullability / timestamps | Verdict |
|---|-------|--------------------|-------------------|---------------------------|---------|
| 1 | **Organization** | root of all tenant models (19 back-relations) | `slug @unique` | createdAt/updatedAt ✓ | ✅ OK |
| 2 | **User** | orgId FK (Restrict default); 9 named back-relations | `email @unique` (global, not org-scoped — blocks same email across orgs when multi-tenant); `@@index([orgId,role])`, `@@index([orgId,active])` | `passwordHash String?` (demo personas); `active` soft-disable — **no DELETE API exists** → FK cascade gaps are theoretical | ✅ OK (note: role is String + ROLES constant, 7/7 values in constants) |
| 3 | **Pipeline** | orgId; stages cascade | `@@index([orgId])` | — | ⚠️ `isDefault` not unique per org (two defaults possible; GET opportunities picks `findFirst`) |
| 4 | **PipelineStage** | pipelineId FK **Cascade** | `@@unique([pipelineId,key])`, `@@index([pipelineId,order])` | `systemLocked` unused by API | ✅ OK — 10 keys in DB match `OPPORTUNITY_STAGES` exactly. Note: Opportunity does **not** FK to stage; stage strings are validated against constants only, so a constant absent from the seeded pipeline would pass zod but never render in the kanban |
| 5 | **Tag** | orgId; LeadTag cascade both sides | `@@unique([orgId,name])` | — | ✅ OK |
| 6 | **LeadTag** | cascade on lead & tag | `@@id([leadId,tagId])`, `@@index([tagId])` | — | ✅ OK |
| 7 | **Lead** | orgId; ownerId optional (SetNull default); tags/activities/tasks/visits/opportunities/contact/requirements | `@@unique([orgId,phone])` (the person key — verified 0 dups in practice); 7 composite indexes (status/source/ownerId/createdAt/nextFollowUpAt/archived/email); `convertedContactId @unique` | domain ts: lastContactAt, nextFollowUpAt, lostAt, reactivatedAt — all correctly stamped by their routes; `archived` soft-delete flag (the only soft-delete in the system) | ✅ Strong. ⚠️ `phone` immutable via PATCH (good); REACTIVATED status vs reactivate-endpoint semantics diverge (§7) |
| 8 | **Contact** | `leadId @unique` → **1:1 conversion snapshot**, not a first-class person | `@@index([orgId])` | createdAt/updatedAt ✓ | ⚠️ fullName/phone/email/notes duplicated from Lead at conversion, **never synced** — lead PATCH (name/email allowed on CONVERTED leads) silently diverges the copy (0 mismatches today; live risk). `type` comment promises `COMPANY` — no constant, no UI, 0 rows |
| 9 | **Opportunity** | orgId; leadId (required, Restrict); contactId/projectId/ownerId optional | `@@index([orgId,stage])`, `[orgId,ownerId]`, `[leadId]`, `[projectId]` — **no index on closedAt** | `closedAt` conflates won & lost (no lostAt); probability free-form (not forced 100 on won) | ⚠️ See §7: creation accepts any stage incl. CLOSED_WON **without stamping closedAt** |
| 10 | **Developer** | orgId; projects Restrict default | `@@index([orgId])` | — | ✅ OK |
| 11 | **Project** | orgId + developerId (required) | `@@index([orgId,developerId])`, `[orgId,status]` | deliveryDate ✓ | ✅ OK (status in PROJECT_STATUSES, 3/4 values used) |
| 12 | **Building** | projectId **Cascade** | `@@index([projectId])` | — | ✅ OK (no orgId — derived via project; consistent with join-table pattern) |
| 13 | **Apartment** | orgId + buildingId **Cascade** | `@@unique([orgId,buildingId,code])`; `[orgId,status]`, `[orgId,unitType]`, `[buildingId]` | no domain timestamps (status history only via AuditLog — no soldAt/reservedAt) | ✅ OK. ⚠️ deleting a Building cascades apartments+matches (no API does this — theoretical) |
| 14 | **Requirement** | `leadId @unique` (1:1) | — (no index beyond unique) | budget fields duplicated with Lead quick-snapshot → **1 drift row found** (Réda Mokrani: lead.budgetMax 16.5M vs req.budgetMax 20M) | ⚠️ denormalization accepted by design (quick snapshot vs full set) but never reconciled |
| 15 | **PropertyMatch** | requirementId/apartmentId **Cascade** | `@@unique([requirementId,apartmentId])`, `[apartmentId]` | reasons = JSON string | ✅ OK |
| 16 | **Visit** | orgId; leadId required; opportunityId/projectId/agentId optional | `[orgId,scheduledAt]`, `[orgId,agentId]`, `[orgId,status]`, `[leadId]` | attended nullable (set true/false on COMPLETED/NO_SHOW) ✓ | ✅ OK |
| 17 | **VisitApartment** | cascade both sides | `@@id([visitId,apartmentId])`, `[apartmentId]` | — | ✅ OK |
| 18 | **Task** | orgId; lead/opportunity/visit/owner optional | `[orgId,ownerId,status]`, `[orgId,dueAt]`, `[leadId]` | dueAt required ✓ | ⚠️ **PATCH validates `priority` as free `z.string().max(20)`** (POST validates against PRIORITIES) — future drift vector |
| 19 | **Activity** | orgId; 6 optional entity FKs (SetNull defaults) + actorId | `[orgId,leadId,occurredAt]`, `[orgId,occurredAt]`, `[orgId,type]` | `occurredAt` (domain) + `createdAt` (system) — correct dual semantics; seed backdates occurredAt, routes stamp `new Date()` | ✅ Excellent (unified timeline, §12) |
| 20 | **Reservation** | orgId; opportunityId required; **`apartmentId @unique` — one row per apartment EVER** (revive-on-rebook workaround documented in route); **agentId is a raw string, NO FK relation** (documented schema gap → orphan strings if a user is ever hard-deleted; `withAgents()` would just render null) | `[orgId,status]`, `[opportunityId]` | `expiresAt` nullable (**NULL = permanent reservation**, found 1: N-21); reason/contractRef/notary ✓ | ⚠️ Booking tx itself is exemplary (ADR-004); expiry never automated (§9) |
| 21 | **AuditLog** | orgId; actorId optional | `[orgId,entity,entityId]`, `[orgId,createdAt]`, `[orgId,actorId]` — **no `[orgId,action]`** for the undo scan | before/after JSON strings; append-only ✓ | ⚠️ **entity value drift `"User"`/`"USER"`**; action free-form strings (no union in `logAudit`) |
| 22 | **SavedSearch** | orgId + userId (required, no User back-relation declared — FK exists via `user` field? No: `userId String` with NO relation — raw string like Reservation.agentId) | `@@index([orgId,userId,entity])` | filters JSON | ⚠️ userId lacks a Prisma relation (raw FK string; deletes not possible via API today — theoretical orphan) |
| 23 | **Document** | orgId; uploader optional; **entityType/entityId polymorphic strings, no FK** (existence verified at upload via `verifyDocEntity`; entity deletes leave orphans — 0 docs today so unmeasurable) | `[orgId,entityType,entityId]`, `[orgId,createdAt]`, `[orgId,category]`; `storedName @unique` | analysis JSON + analyzedAt ✓ | ✅ OK for polymorphic design |
| 24 | **OrgSetting** | orgId | `@@unique([orgId,key])` | value JSON, app-side zod ✓ | ✅ OK |
| 25 | **SalesTarget** | orgId + userId FK (required) | `@@unique([orgId,userId,month])`, `@@index([orgId,month])` | month "YYYY-MM" regex-validated at API; 0-amount = documented clear-sentinel (row deleted) | ✅ OK (R10-4) — DB holds 4 rows, all `2026-10`, format valid |

**Soft-delete coverage:** only `Lead.archived`. Opportunities are hard-DELETE (restricted to NEW/CLOSED_LOST + no reservations); Documents hard-DELETE; Tasks use CANCELLED status; Users deactivate-only (no delete endpoint). This is *inconsistent but defensible* — the asymmetry (leads are the person-record → archive; opportunities are deal-records → delete-with-guard) should be documented as policy, not left implicit. Import-undo archives rather than deletes (good).

**onDelete summary:** explicit Cascade only on PipelineStage, LeadTag, Building→Apartment, PropertyMatch, VisitApartment; everything else uses Prisma defaults (Restrict for required FKs, SetNull for optional ones — which is what the opportunity DELETE route comment relies on and gets). User deletion is impossible via API → cascade gaps theoretical except the two raw-string FKs (`Reservation.agentId`, `SavedSearch.userId`).

---

## 3. Index vs query-pattern matrix (hot queries → hit/miss)

Actual SQLite indexes were read from `sqlite_master` (`tmp-scripts/p2c-indexes.ts`) — they match the schema exactly (db push applied them).

| Hot query (route) | Where shape | Index used | Verdict |
|---|---|---|---|
| Leads list (`/api/leads`) | `orgId + archived(default) + status? + source? + ownerId? + priority? + tagId?` + sort createdAt | `Lead_orgId_status_idx` / `Lead_orgId_archived_idx` / `Lead_orgId_createdAt_idx` | ✅ HIT (single-filter picks one; multi-filter intersects in SQLite — R6 verified 19–53ms @10k leads) |
| Lead text search | `OR(fullName/phone/phoneRaw/email contains)` | none (LIKE %x%) | ⚠️ MISS by nature — full org scan; acceptable at current scale |
| Duplicate check on lead create | `orgId + phone` / `orgId + email contains` | phone: `Lead_orgId_phone_key` ✅; email LIKE: scan | ⚠️ email check is a scan per creation (10k leads → few ms; note it) |
| Dashboard overdue tasks | `orgId + status=OPEN + dueAt < now` | `Task_orgId_dueAt_idx` (range) then filter status | ⚠️ partial HIT — no `[orgId,status,dueAt]` composite; fine ≤10k tasks |
| Dashboard today/upcoming visits + notifications | `orgId + status in (SCHEDULED,CONFIRMED) + scheduledAt range` | `Visit_orgId_scheduledAt_idx` or `[orgId,status]` | ⚠️ partial HIT — no `[orgId,status,scheduledAt]` composite |
| Dashboard hot opps / pipeline kanban | `orgId + stage in (...)` | `Opportunity_orgId_stage_idx` | ✅ HIT |
| Dashboard won-in-range / targets month | `orgId + stage=CLOSED_WON + closedAt range` | `[orgId,stage]` then residual filter on closedAt | ⚠️ partial HIT — no closedAt anywhere in an index (works because CLOSED_WON sets are small) |
| Notifications expiring reservations | `orgId + status=ACTIVE + expiresAt range` | `Reservation_orgId_status_idx` | ⚠️ partial HIT — no `[orgId,status,expiresAt]` |
| Uncontacted KPI | `orgId + lastContactAt IS NULL` | any orgId-prefixed index, then filter | ⚠️ scan of org leads per dashboard load (R6 measured fine) |
| Activity lead feed / org feed | `orgId(+leadId) order occurredAt desc` | `[orgId,leadId,occurredAt]` / `[orgId,occurredAt]` | ✅ HIT |
| Audit list + undo scan | `orgId(+entity/entityId/actorId)` / `orgId + action=LEADS_IMPORT_UNDONE` | entity triple ✅ / **action: no index** | ⚠️ undo scan reads org audit rows via orgId prefix + row filter (§5 cost analysis) |
| Reservations by apartment | `apartmentId` (unique) | `Reservation_apartmentId_key` | ✅ HIT |
| Matching engine | `orgId + status in (AVAILABLE)` take 500 | `Apartment_orgId_status_idx` | ✅ HIT |
| SalesTargets GET | `orgId + month` | `SalesTarget_orgId_month_idx` | ✅ HIT |
| Apartments list | `orgId + status? + unitType? + buildingId?` | `[orgId,status]`, `[orgId,unitType]`, `[buildingId]` | ✅ HIT |

**Missing composites (all P2 at current scale, worth adding before 10x task/visit growth):** `Task(orgId,status,dueAt)`, `Visit(orgId,status,scheduledAt)`, `Reservation(orgId,status,expiresAt)`, `Opportunity(orgId,stage,closedAt)`, `AuditLog(orgId,action)`.

---

## 4. Enum-drift results (constants vs actual DB values)

Read-only `GROUP BY` per column (`tmp-scripts/p2c-enum-drift.ts`):

| Column | DB values | Constants | Verdict |
|---|---|---|---|
| Lead.status | CLOSED_LOST 1 · CONTACTED 8 · CONVERTED 21 · NEW 13 · REACTIVATED 1 | LEAD_STATUSES (6) | ✅ no drift (QUALIFIED = 0 rows — valid, unused state) |
| Lead.source | 11 values | SOURCES (13) | ✅ no drift; **DEVELOPER_REFERRAL + OTHER never used** (0 rows) |
| Lead.priority | LOW/NORMAL/HIGH/URGENT | PRIORITIES | ✅ |
| Opportunity.stage | 9 values | OPPORTUNITY_STAGES (10) | ✅ (NEW = 0 rows) |
| Visit.status | CANCELLED 2 · COMPLETED 14 · CONFIRMED 2 · NO_SHOW 1 · SCHEDULED 2 | VISIT_STATUSES | ✅ (RESCHEDULED = 0 rows) |
| Reservation.status | ACTIVE 2 · CANCELLED 1 · CONVERTED 7 | 4 values | ✅ (**EXPIRED = 0 rows — nothing produces it**, §9) |
| Task.status / type / priority | OPEN 16/DONE 4 · 6 types · 4 priorities | TASK_STATUSES/TASK_TYPES/PRIORITIES | ✅ (DOCUMENT type used 2; OTHER/CANCELLED unused) |
| Apartment.status / unitType | AVAILABLE 28 · BLOCKED 1 · OFF_MARKET 1 · OPTIONED 2 · RESERVED 7 · SOLD 7 / 7 types | APARTMENT_STATUSES/UNIT_TYPES | ✅ (UNAVAILABLE unused; LAND unused) |
| Activity.type | 13 values incl. COPILOT 2 | ACTIVITY_TYPES (17) | ✅ (SMS/EMAIL/MEETING/ASSIGNMENT unused — valid options) |
| PipelineStage.key | 10 keys | OPPORTUNITY_STAGES | ✅ exact |
| Document.category/status/entityType | — (0 rows) | DOCUMENT_* | ✅ n/a |
| **AuditLog.entity** | **APARTMENT 19 · LEAD 19 · OPPORTUNITY 20 · ORGANIZATION 3 · USER 17 · `User` 46** | comment says LEAD/OPPORTUNITY/…/USER | ❌ **DRIFT CONFIRMED — 46 rows written with `"User"`** by 7 call-sites (users/auth routes). No constant exists for audit entities/actions at all |
| AuditLog.action | 15 values | none (free-form) | ⚠️ no taxonomy to drift against; `LEAD_BULK_*` actions defined in code, never exercised in DB |
| SalesTarget.month | `2026-10` ×4 | regex `^\d{4}-(0[1-9]|1[0-2])$` at API | ✅ |
| User.role / active | 5 roles / all true | ROLES (7) | ✅ (ACCOUNTING/OPERATIONS unexercised) |
| Contact.type | INDIVIDUAL ×21 | **none — comment-only enum** | ⚠️ COMPANY promised in schema comment, absent from constants/UI |

**Future-drift vectors (validation gaps):** Task PATCH priority = free string; `logAudit` action/entity = free strings; Requirement.payment/purpose/timeframe, Apartment.paymentPlan/orientation, SavedSearch.entity, Contact.type, Document analysis verdict — all comment-only enums with no constants. ADR-001 discipline is applied to *hot* entities but not to the long tail.

---

## 5. Data-integrity anomalies (read-only DB queries)

| Check | Result | Count |
|---|---|---|
| Leads owned by inactive users | none (0 inactive users) | **0** |
| Opportunities without lead | impossible (required FK) | **0** |
| Opps whose lead is not qualified/converted | Bilal H. (CLOSED_LOST lead, CLOSED_LOST opp — seed design) | **1** |
| Reservation ↔ apartment status contradictions (ACTIVE↔RESERVED, CONVERTED↔SOLD, CANCELLED↔…) | none | **0** |
| ACTIVE reservations past expiresAt (today) | none (H-31 expires 2026-10-23; N-21 has **no expiry**) | 0 live / **1 structural** (N-21 NULL expiresAt) |
| **Apartments RESERVED/OPTIONED with no reservation row** (seed legacy) | A-21, B-11, H-12, N-11, V-03 (RESERVED); A-31, H-21 (OPTIONED) | **7** |
| SOLD apartments without CONVERTED reservation | none | **0** |
| **R10-2 seed coherence (spot-verify)** | 7/7 CLOSED_WON: closedAt set ✓ · probability=100 ✓ · lead CONVERTED + convertedContactId ✓ · CONVERTED reservation + SOLD apartment ✓ · no nextAction ✓ | **7/7 CLEAN** |
| CLOSED_LOST opps missing closedAt/lostReason | none | **0** |
| Orphaned activity entity links (FK-enforced) | none; 0 activities with no entity linkage at all | **0** |
| Documents with entity+entityId pointing nowhere | 0 documents in DB | **0** (n/a) |
| AuditLog entityId orphans (APARTMENT spot-check) | none | **0** |
| Duplicate phones in org | none — `@@unique([orgId,phone])` holds | **0** |
| Duplicate emails in org | none | **0** |
| Contact↔Lead field drift (name/phone/email) | 0 today — but **no sync mechanism** (see §2 row 8) | 0 live / structural |
| Requirement↔Lead budget drift | Réda Mokrani lead.budgetMax 16.5M ≠ req.budgetMax 20M | **1** |
| Leads with lostReason outside CLOSED_LOST / CLOSED_LOST without reason | none | **0** |
| CONVERTED leads with residual lost fields | none | **0** |
| Stale nextFollowUpAt on terminal (CONVERTED) leads | 5 (seeded demo data) | 5 (cosmetic) |
| Stale SCHEDULED/CONFIRMED visits in the past | 1 | 1 (cosmetic) |
| Overdue OPEN tasks | 5 (demo's "En retard" — by design) | 5 |
| Archived leads | 0 (feature live, unused) | 0 |
| **AuditLog entity taxonomy split** | `User` 46 / `USER` 17 | **46 rows affected** |

---

## 6. Domain map (actual, as implemented)

```mermaid
erDiagram
    Organization ||--o{ User : "orgId"
    Organization ||--o{ Pipeline : ""
    Organization ||--o{ Tag : ""
    Organization ||--o{ Lead : ""
    Organization ||--o{ Contact : ""
    Organization ||--o{ Opportunity : ""
    Organization ||--o{ Developer : ""
    Organization ||--o{ Task : ""
    Organization ||--o{ Visit : ""
    Organization ||--o{ Activity : ""
    Organization ||--o{ AuditLog : ""
    Organization ||--o{ Reservation : ""
    Organization ||--o{ Requirement : "via Lead"
    Organization ||--o{ Apartment : ""
    Organization ||--o{ SavedSearch : ""
    Organization ||--o{ Document : "polymorphic"
    Organization ||--o{ OrgSetting : ""
    Organization ||--o{ SalesTarget : ""
    Pipeline ||--o{ PipelineStage : "cascade"

    User ||--o{ Lead : "LeadOwner (opt)"
    User ||--o{ Opportunity : "OpportunityOwner (opt)"
    User ||--o{ Task : "TaskOwner (opt)"
    User ||--o{ Visit : "VisitAgent (opt)"
    User ||--o{ Activity : "ActivityActor (opt)"
    User ||--o{ AuditLog : "AuditActor (opt)"
    User ||--o{ Document : "uploader (opt)"
    User ||--o{ SalesTarget : ""

    Lead ||--o{ LeadTag : ""
    Tag ||--o{ LeadTag : "cascade"
    Lead ||--o| Contact : "convertedContactId (1:1 snapshot)"
    Lead ||--o{ Opportunity : "leadId required"
    Lead ||--o{ Requirement : "leadId unique (1:1)"
    Lead ||--o{ Visit : ""
    Lead ||--o{ Task : ""
    Lead ||--o{ Activity : ""

    Contact ||--o{ Opportunity : "contactId opt"
    Contact ||--o{ Activity : ""

    Developer ||--o{ Project : ""
    Project ||--o{ Building : "cascade"
    Building ||--o{ Apartment : "cascade"
    Project ||--o{ Opportunity : ""
    Project ||--o{ Visit : ""

    Requirement ||--o{ PropertyMatch : "cascade"
    Apartment ||--o{ PropertyMatch : "cascade"
    Apartment ||--o| Reservation : "apartmentId UNIQUE (one row EVER)"
    Apartment ||--o{ VisitApartment : "cascade"
    Visit ||--o{ VisitApartment : "cascade"

    Opportunity ||--o{ Reservation : "opportunityId required"
    Opportunity ||--o{ Visit : "opt"
    Opportunity ||--o{ Task : "opt"
    Opportunity ||--o{ Activity : "opt"

    Visit ||--o{ Task : "opt (auto follow-up)"
    Visit ||--o{ Activity : ""
    Task ||--o{ Activity : ""
    Reservation ||--o{ Activity : ""

    Document }o--|| Organization : "entityType+entityId polymorphic (LEAD|OPPORTUNITY|RESERVATION|APARTMENT|PROJECT), no FK"
    Reservation }o--|| User : "agentId raw string, NO relation"
    SavedSearch }o--|| User : "userId raw string, NO relation"
```

**Funnel as implemented:** Lead (person lifecycle) → convert (tx: Contact snapshot + Opportunity @QUALIFIED) → Opportunity (10-stage deal pipeline) → Reservation (tx: apartment AVAILABLE→RESERVED) → CONVERTED → apartment SOLD. Matching: Requirement→PropertyMatch→Apartment (AVAILABLE only). Timeline: Activity is the universal log; AuditLog is the compliance ledger. Notifications: **computed live, no model** (deliberate).

---

## 7. State-machine matrix (enforced vs free-form)

Enforcement lives entirely in the PATCH routes (zod enums + a handful of guard clauses). There are no DB-level constraints beyond unique keys.

### Lead.status
| From → To | Enforced? | Side-effects |
|---|---|---|
| any → CONVERTED | ✅ **blocked** (422 INVALID_TRANSITION — convert endpoint only) | — |
| any → CLOSED_LOST | ✅ **conditional** — lostReason required (422 LOST_REASON_REQUIRED) | lostAt stamped; STATUS_CHANGE activity + audit |
| CLOSED_LOST → REACTIVATED | ✅ (PATCH) | lostReason/lostAt cleared, reactivatedAt stamped |
| CLOSED_LOST → CONTACTED | ✅ via `/reactivate` only (409 NOT_CLOSED_LOST otherwise) | fields cleared, reactivatedAt stamped, activity |
| **any other transition** (NEW↔CONTACTED↔QUALIFIED, backward jumps, CONVERTED→NEW/CLOSED_LOST/…) | ❌ **free-form** | activity + audit only |
| ⚠️ **CLOSED_LOST → CONTACTED/QUALIFIED via PATCH** | ❌ allowed — bypasses reactivate; **lostReason/lostAt NOT cleared** | semantic drift possible |
| ⚠️ **CONVERTED → CLOSED_LOST/NEW via PATCH** | ❌ allowed — converted lead can be "un-converted" while contact+opps remain; convertedContactId stays set (lead can never re-convert: 409 ALREADY_CONVERTED) | zombie state |
| convert endpoint precondition | ❌ **any status accepted** (NEW, CLOSED_LOST, even archived leads convert) | Contact+Opp created in tx |

### Opportunity.stage
| From → To | Enforced? | Side-effects |
|---|---|---|
| any → CLOSED_LOST | ✅ lostReason required | closedAt stamped |
| any → CLOSED_WON | ❌ nothing required (no reservation, no SOLD apartment, probability not forced to 100) | closedAt stamped |
| reopen (terminal → open) | ✅ closedAt cleared, lostReason cleared (unless provided) | STAGE_CHANGE activity + audit |
| **stage ordering / jumps** | ❌ free-form (kanban drag by design) | activity + audit |
| **create directly at CLOSED_WON/CLOSED_LOST** (`POST /api/opportunities` stage enum, no guard) | ❌ allowed — **closedAt NOT stamped at creation** → won deal invisible to targets/analytics | STAGE_CHANGE "créée" activity |
| DELETE | ✅ only NEW or CLOSED_LOST (422), blocked with reservations (422) | activities/tasks/visits SetNull |

### Visit.status
| From → To | Enforced? | Side-effects |
|---|---|---|
| any → COMPLETED | ✅ outcome required (422 OUTCOME_REQUIRED) | attended=true; terminal activity; followUpRequired → auto FOLLOW_UP task +1d (dedup by open task) |
| any → NO_SHOW | ❌ free | attended=false; activity |
| **COMPLETED → SCHEDULED again / CANCELLED → CONFIRMED** | ❌ free-form | re-entry allowed; attended not reset (stays true) |
| reschedule (same status + new scheduledAt) | ✅ handled | activity "replanifiée" |

### Task.status (OPEN/DONE/CANCELLED)
- ❌ fully free-form; DONE emits TASK activity (only on first DONE); **DONE→OPEN reopen allowed** (no activity on reopen).
- ⚠️ PATCH `priority` is an unconstrained string (POST validates) — drift vector.

### Reservation.status
| From → To | Enforced? | Side-effects |
|---|---|---|
| ACTIVE → CANCELLED/CONVERTED/EXPIRED | ✅ only from ACTIVE (409 RESERVATION_ALREADY_CLOSED); zod enum of exactly these three | tx: CANCELLED/EXPIRED → apartment AVAILABLE; CONVERTED → apartment SOLD; audit + activity |
| **ACTIVE → EXPIRED automatically when expiresAt passes** | ❌ **NOTHING DOES THIS** (see §9) | — |
| create | ✅ apartment must be AVAILABLE inside tx (409); unique apartmentId backstop (P2002→409); terminal rows revived on re-book | apartment → RESERVED; activity + audit |

### Apartment.status
| From → To | Enforced? | Side-effects |
|---|---|---|
| SOLD → AVAILABLE/OPTIONED | ✅ forbidden without `force:true` (422 FORBIDDEN_TRANSITION) | audit with forced flag |
| **everything else incl. RESERVED → AVAILABLE while an ACTIVE reservation exists** | ❌ allowed silently → desyncs reservation (apartment looks bookable; new booking then hits 409 ALREADY_RESERVED on the unique row → deadlock until the old reservation is cancelled) | audit only |
| RESERVED set manually without reservation row | ❌ allowed (seed did exactly this — 7 orphans) | audit only |

### Document.status
- ✅ **the only fully-enforced machine**: PENDING→VALIDATED|REJECTED, VALIDATED/REJECTED→PENDING (422 INVALID_STATUS_TRANSITION; DOC_STATUS_TRANSITIONS in constants).

### Lead bulk actions
- ✅ CONVERTED blocked in bulk; ❌ **bulk CLOSED_LOST stamps lostAt but not lostReason** — bypasses the single PATCH discipline (comment claims "stamped reason" but no reason is written).

**Top-3 enforcement gaps:** (1) Opportunity created directly at a terminal stage without closedAt; (2) Apartment PATCH can silently break reservation coherence (RESERVED→AVAILABLE with ACTIVE reservation; RESERVED without reservation); (3) Lead lifecycle bypasses (CONVERTED→anything, CLOSED_LOST→anything without clearing lost fields).

---

## 8. Missing / rejected domain concepts (vs master prompt §4 et al.)

### Explicitly rejected / deferred (documented in worklog or code)
| Concept | Status | Evidence |
|---|---|---|
| Notification as persisted model | ✅ deliberate | notifications route header: "computed LIVE from domain sources of truth (§49); nothing is persisted" |
| Note/Call/Email/Meeting/Reminder/Assignment as separate entities | ✅ consolidated into Activity types | §12 unified timeline is the stated primitive; ACTIVITY_TYPES covers all |
| Floor as entity | ✅ folded into Apartment.floorNumber + Building.floors | reasonable consolidation |
| NextAuth | deferred | R7/R10 handover rec — cookie+scrypt accepted for single-workspace |
| Inbound WhatsApp threads | partially deferred | R9-4 built outbound logging (wa.me + WHATSAPP activity); spec §11 anticipates Cloud API "future providers" |
| Lost Reason taxonomy | simplified | free-text lostReason (spec lists it as entity) |

### Silently missing (in spec §4/§5/§6/§24, no ADR, no worklog deferral note)
| Concept | Spec ref | What exists instead | Gap |
|---|---|---|---|
| **Campaign / Ad / Landing Page / Cost** | §4 Marketing, §6 ("campaign, ad, landing page, UTM…, first-touch, latest-touch") | free-text `Lead.campaign` + utmSource/Medium/Campaign strings | no spend/cost → sourcePerformance can't compute ROI or cost-per-lead; **utmContent, firstTouchSource, latestTouchSource fields missing entirely** |
| **Offer** | §4, §5 "multiple offers", §12 activity "offer" | OPTION stage + Apartment.OPTIONED as proxy | no offer document/amount/versioning; an opp can't hold multiple offers |
| **Commission** | §4, line 878, 2013 | nothing | no commission on CLOSED_WON (agentLeaderboard uses gross value) |
| **Customer** (distinct from Contact) | §4, §5 "a customer can buy multiple properties" | Contact = 1:1 conversion snapshot; repeat buyer = new opportunity on the same lead | no customer aggregate/360 view; Contact can't exist without a lead |
| **Company** | §4 | `Contact.type` comment only | no constant, no UI, 0 rows |
| **Granular permissions** (lead.read/lead.create/…) | §24 "Permissions must be granular" | role-rank `atLeastRole` only | ACCOUNTING/OPERATIONS roles exist with zero specific grants |
| **Team / Sales Team** | §4, §328 | org-wide roles only | no team membership/team targets |
| **Payment / Installments** (post-sale lifecycle step) | line 204 | `depositPaid` amount only | no installment schedule, no payment tracking after SOLD |
| **Consent/preferences** | §563 | nothing | silently dropped |
| **Document Version / Attachment** | §4 | single row per upload, `storedName @unique` | re-upload = new document, no lineage |
| Sales Activity | §4 | Activity + Task types | adequately covered |

**Verdict:** the lead→deal→inventory core is faithful to the spec; the **commercial-finance periphery (Campaign/Offer/Commission/Payment)** and **RBAC granularity** were silently simplified — they should be either ADR'd as out-of-scope-for-P2 or scheduled.

---

## 9. Reservation-expiry verdict — **FAKE-COMPLETENESS (PARTIAL)**

**Claimed (schema + UI + notifications):** `Reservation.expiresAt DateTime?`, status value `EXPIRED` ("ACTIVE | CONVERTED | CANCELLED | EXPIRED" in schema comment), `PATCH /api/reservations/:id` accepts `status: "EXPIRED"` (route line 15, title "Réservation expirée" line 22), notifications emit `RESERVATIONS_EXPIRING`, and the org setting `reservations.defaultExpiryDays` (default 14) prefills expiresAt in the reserve dialog (R7-3).

**Reality — nothing transitions a reservation to EXPIRED:**
- `rg "EXPIRED" src/` returns **ex hits**: `reservations/route.ts:19` (status list for the GET filter enum), `reservations/[id]/route.ts:1,15,22` (the manual PATCH). No cron, no background job, no instrumentation hook, no on-read transition anywhere in `src/` (verified by exhaustive grep; Next.js app has no scheduled task infra; no sweeper in the notifications route — it only *reads*).
- The manual PATCH requires a human to notice and act.

**Stale-state consequences:**
1. **Notification blind spot:** the expiring query is `expiresAt: { gte: now, lt: expiringHorizon }` (`notifications/route.ts:113`) — an ACTIVE reservation whose expiresAt is *already past* matches NEITHER bound → it silently disappears from the bell. Nothing in the product surfaces an overdue reservation.
2. **Permanent apartment lock:** the apartment stays `RESERVED` forever → `POST /api/reservations` for it returns 409 `APARTMENT_NOT_AVAILABLE` (status check) — correct per se, but with no expiry mechanism the unit is dead inventory until a human manually PATCHes the reservation.
3. **Manual-release trap:** an admin can PATCH the *apartment* RESERVED→AVAILABLE (that transition is NOT in `FORBIDDEN_APARTMENT_TRANSITIONS`) — but the reservation row stays ACTIVE, so any new booking attempt hits the absolute-unique `apartmentId` row → 409 `ALREADY_RESERVED`. The apartment is then *doubly* stuck (looks available, can't be booked) until the stale reservation is cancelled/expired by hand.
4. **NULL expiresAt = permanent hold:** N-21 (Fatima Zohra Merabet — F3 Kouba, opp QUALIFIED) is ACTIVE with `expiresAt = NULL` — a mid-funnel lead holds an apartment indefinitely. `expiresAt` is optional at creation (route schema `nullable().optional()`), so this recurs by design.

**Current DB exposure:** 0 ACTIVE reservations are past-due today (H-31 expires 2026-10-23 — inside the notification window; N-21 never expires). The defect is structural, not yet manifest — which is exactly what makes it dangerous: it will start biting silently the day a seeded/demo reservation crosses its expiry.

**Minimum fix:** a sweeper (e.g. at the top of the notifications GET and/or reservations GET, inside a transaction): `updateMany` reservations `status: ACTIVE, expiresAt: { lt: now }` → EXPIRED + apartment → AVAILABLE + audit; and make `expiresAt` default to `now + reservations.defaultExpiryDays` server-side (the prefill is client-side only today).

---

## 10. Migrations & change-management risk

- **No `prisma/migrations/` directory** — the schema is managed by `bun run db:push` = `prisma db push --accept-data-loss` (package.json line 10). `db:migrate`/`db:reset` scripts exist but point to a migrate workflow that was **never initialized**. **[RESOLVED Phase 1 Task 2 (D-014)**: `0_init` baseline committed + resolve-marked on the live DB + replay-validated; `--accept-data-loss` removed from the script — see `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md` for the authoritative flow. The text below is the original audit record.**]
- **Concrete risk:** `db push` diffs schema→DB and applies the cheapest path. On SQLite, many ALTERs (rename, drop column pre-3.35 semantics, type changes) are implemented as **table recreate + copy**; with `--accept-data-loss` the confirmation prompt is suppressed, so a rename modeled as drop+add silently discards the column's data, and dropping a model silently drops the table. There is **zero migration history** — no way to reconstruct or replay environments, and no review artifact for schema changes (the worklog shows schema evolution happened 6+ times: SavedSearch, Document, analysis columns, passwordHash, OrgSetting, SalesTarget).
- **Live evidence of fragility (R10-4):** after `db:push`, the running dev server held the stale Prisma client → `db.salesTarget undefined` → 500s until a manual double-fork restart. With `migrate dev` + generated client this class of drift is at least an explicit step.
- **Recommended path:** (1) baseline: `prisma migrate diff --from-empty --to-schema-datamodel prisma/schema.prisma --script > prisma/migrations/0_init/migration.sql` + mark applied (`prisma migrate resolve --applied`) so the existing `custom.db` is not rebuilt; (2) from then on `prisma migrate dev` only, committed migrations, remove `--accept-data-loss` from the default script; (3) SQLite caveats: avoid column renames (Prisma emits recreate; data survives the copy but locks the single writer), keep migrations small, and expect `migrate dev` to hold the DB lock briefly (dev-only cost).
- **seed.ts re-rannability:** guard = `if (db.user.findFirst()) skip` → idempotent but **all-or-nothing**: a crash mid-seed leaves partial data that the guard then refuses to repair. ~~It is **not wired into package.json**…~~ **[RESOLVED Phase 1 Task 4]**: now wired (`prisma.seed` config + `bun run db:seed`); won-deal history folded into `prisma/seed.ts` (tmp-scripts/r10-seed-won.ts deleted); fresh-install validated: migrate + seed → 7 CLOSED_WON / 236.2M DZD / ranges 29.3M-101.8M-236.2M; live-DB re-run = zero writes. Original audit text (superseded): no `db:seed` script, no `prisma.seed` config — invoked manually per worklog; the R10-2 won-deal seeding lived only in `tmp-scripts/r10-seed-won.ts` — a fresh `db push && seed` yielded **0 CLOSED_WON deals** → dashboard won/KPIs/conversionRate read 0 (the exact regression R10-1 diagnosed) while the current demo DB showed 236.2M. Seed drift between environments was guaranteed.

---

## 11. Query-efficiency spot-check

- **Dashboard route:** ~24 round-trips organized in 4 `Promise.all` batches (11 KPI counts/aggs + 4 agenda payloads + 4 funnel counts + 2 targets queries + 3 source-performance queries) + a conditional recentLeads fallback. This is fine: counts are cheap, batches keep latency low, and R6 benchmarked the full route at **35–49ms with 10,000 leads** (stress data since removed). No N+1: every payload uses a single `findMany` with an include graph.
- **undoneAuditIds scan (audit route, every page load):** one extra `findMany` (`orgId + action = LEADS_IMPORT_UNDONE`, take 500, `after` JSON parsed app-side). Current DB: **0 matching rows → ~zero cost**. At 10× audit volume (1.2k rows) still sub-ms. Long-term: the filter has no `[orgId,action]` index (SQLite walks an orgId-prefixed index and row-filters action — O(org audit rows) per audit page view), and the 500-cap means >500 undo records would silently miss older ones. Verdict: **acceptable now; add the index + a persisted `sourceAuditId` column (or `isUndone` flag on the import audit) before audit volume grows 100×.**
- **N+1 sweep:** none found. Leads list = 1 query + owner/tags include; lead aggregate = 1 query with take-100 activities; activities feed includes actor/lead/opportunity; reservations `withAgents` = 1 extra users query joined in memory; analytics uses groupBy + one in-memory join. `computeLeadMatches` = 2 reads + ≤20 **sequential** upserts (not wrapped in a transaction — an interruption leaves a partially-refreshed match set; benign, self-healing on next run).
- **SQLite single-writer / interactive transaction (reservations POST):** the tx body is exactly 4 statements (read apartment → read existing reservation → upsert reservation → update apartment) — **short and correct**; activity/audit writes happen *after* the tx (a post-tx crash loses the log entry, never the booking — the right trade). The PATCH lifecycle tx is 2 statements. The 20-write match upserts and the per-lead activity loops in bulk routes are the only multi-write sequences outside transactions — worth wrapping at scale.
- **Cross-cutting note:** `db.ts` runs with `log: ['query']` unconditionally — every request logs full SQL to dev.log (554 prisma:query lines in the current log) — noise + overhead to disable in production posture.

---

## 12. Recommendations (prioritized)

**P0 — correctness**
1. **Fix the AuditLog entity drift:** normalize `"User"` → `"USER"` in the 7 users/auth call-sites + one data-fix UPDATE; introduce an `AUDIT_ENTITIES`/`AuditAction` union (constants.ts + `logAudit` signature) so the taxonomy can't split again.
2. **Implement reservation expiry:** transactional sweeper on notifications/reservations GET (ACTIVE + expiresAt < now → EXPIRED + apartment AVAILABLE + audit + activity); default `expiresAt = now + reservations.defaultExpiryDays` server-side on POST (client prefill is not enforcement); extend or supplement the notification window to surface *already-expired* ACTIVE reservations.
3. **Adopt migrations:** baseline `prisma migrate` from the current schema (see §10), commit the `prisma/migrations/` dir, drop `--accept-data-loss` from the default script; wire `db:seed` into package.json and fold the R10-2 won-deal seeding into `prisma/seed.ts` so fresh installs reproduce the demo KPIs.

**P1 — integrity hardening**
4. Task PATCH: validate `priority` against PRIORITIES (close the drift vector).
5. Apartment PATCH: reject RESERVED→AVAILABLE while an ACTIVE reservation exists (or cascade-cancel it); reject setting RESERVED/OPTIONED without a reservation row; backfill or release the 7 seed-legacy orphan apartments.
6. Opportunity POST: forbid creating directly at CLOSED_WON/CLOSED_LOST (or stamp closedAt + probability then); force probability 100/0 on terminal transitions in PATCH.
7. Lead PATCH: clear lostReason/lostAt on any exit from CLOSED_LOST; consider locking identity fields (fullName/email) on CONVERTED leads or syncing the Contact snapshot; require lostReason for bulk CLOSED_LOST.
8. Contact: add COMPANY constant + UI, or remove the comment (stop promising an unmodeled value).

**P2 — performance & domain completeness**
9. Add the 5 missing composites: `Task(orgId,status,dueAt)`, `Visit(orgId,status,scheduledAt)`, `Reservation(orgId,status,expiresAt)`, `Opportunity(orgId,stage,closedAt)`, `AuditLog(orgId,action)`.
10. Model **Campaign** (name/source/cost/dates) → unlocks ROI/cost-per-lead in sourcePerformance (spec §6); then Offer and Commission for the commercial periphery (spec §4) — or ADR them out of scope explicitly.
11. Reconcile Requirement↔Lead budget duplication (single source or sync-on-write); make `lastContactAt` semantics explicit (updated only by contact-type activities + whatsapp route — status changes do not touch it).
12. Disable Prisma query logging outside dev; wrap the match-upsert loop in a transaction.

---

*Audit scripts (read-only, kept for reproducibility): `tmp-scripts/p2c-enum-drift.ts`, `p2c-integrity.ts`, `p2c-resv-detail.ts`, `p2c-indexes.ts`, `p2c-final.ts`. No modifications were made to src/, prisma/, or the database.*
