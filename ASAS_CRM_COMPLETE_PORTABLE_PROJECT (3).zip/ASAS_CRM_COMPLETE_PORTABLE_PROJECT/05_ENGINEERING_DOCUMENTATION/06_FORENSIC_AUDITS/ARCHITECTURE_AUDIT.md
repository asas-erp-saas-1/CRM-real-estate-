# ASAS CRM — Architecture Audit (GOV-2, Engineering Recovery Protocol Stage 2)

> **Supersedes** the Phase-2 audit (P2-a, commit `d28ca4f` — full original preserved in git history).
> Its 10 headline findings + §5 duplication table are dispositioned in §5 below.
>
> **Auditors:** GOV-2-a (API surface & contracts, read-only) · GOV-2-b (data isolation, workflow, DB,
> dead code, read-only) · main session (runtime verification legs).
> **Mode:** Stage 6 read-only audit (per `RECOVERY_GOVERNANCE_PROTOCOL.md` §1). No source/config/schema
> changes were made for or by this audit. The only writes: this doc, `worklog.md`, one read-only probe
> script (`tmp-scripts/gov2-b1-probe.ts`), and the documented P0 environment recovery at open (§1.1).
> **Evidence standard:** every finding carries file:line evidence, a severity × impact × confidence
> rating, and a CONFIRMED-vs-HYPOTHESIS label. "CONFIRMED (runtime)" = observed live this round.
> A check counts as passed only if actually executed and its result observed (§1.2).

---

## 1. Verification receipts (all executed 2026-10-19, this round)

### 1.1 P0 environment recovery (pre-audit, the R25-class reset — 11th observed occurrence)

At open: `.env` reduced to `DATABASE_URL` (session secret gone → ephemeral fallback) · DB schema-only,
all 25 tables 0 rows · migration bookkeeping lost (`migrate status`: 11 unapplied). Recovered per the
binding AGENTS.md recipe (secret value never printed): fresh `ASAS_SESSION_SECRET` → server killed →
`rm db/custom.db` → `migrate deploy` (11/11) → `generate` → `db:seed` → subshell-detach restart.
**Post-recovery:** `GET /` 200 · baseline **byte-exact** `8/43/21/23/161/46/3/8/4/18` · lint EXIT 0 ·
`tsc --noEmit` exactly the 4 tolerated errors (examples/websocket ×2, skills/ ×2; `src/` = 0).

### 1.2 Non-destructive checks (actual results)

| Check | Command | Result |
|---|---|---|
| Lint | `bun run lint` | **EXIT 0** (clean) |
| Type-safety | `bunx tsc --noEmit` | exit 2 — **exactly 4 pre-classified tolerated** (examples/skills; `src/` = 0) |
| Record-visibility matrix | `bun run tmp-scripts/p12-visibility-matrix.ts` | **231/231 PASS** (incl. D-021 agent-vs-agent isolation, 404 byte-equality, KPI null-gates, duplicates D-021 403) |
| B-1 scope-leak probe | `bun run tmp-scripts/gov2-b1-probe.ts` | **RUNTIME CONFIRMED** — see F-02; scratch reservation w/ exact-state cleanup (8→8) |
| B-6 users-email probe | (same script) | **RUNTIME CONFIRMED** — emails visible to any org member |
| Render walk | agent-browser | OWNER login → full dashboard (h1 + 7 h3 sections + 7-cell attention strip incl. «2 Doublons à fusionner») · **console errors ZERO** (HMR/DevTools info only) |
| Guard census vs GOV-1-b | exhaustive grep + ~30 route files read | **deltas: NONE** (59 files / **77 exported handlers**; the GOV-1-b "59" counted files) |

---

## 2. Executive summary — ranked findings

| # | ID | Finding | Sev | Status | One-line evidence |
|---|---|---|---|---|---|
| 1 | **F-01 / B-3** | **Reservation lifecycle (CONVERTED/CANCEL — the money-state change) has NO UI writer** — the §37/§38 machines it feeds never see UI-closed deals | **HIGH** | **FIXED 2026-10-19 (G5-P3-2, D-GOV-5)** — the two-step closure: migration p54 + action-based lifecycle + ClosureWorkflow UI + bell queue; matrix §40 + browser golden path | only client PATCH to `/api/reservations/:id` is `deal-economics.tsx:149-166` (economics keys only); no i18n key exists for a convert action (`rg "CONVERTED" src/components` → read-side only) |
| 2 | **F-02 / B-1** | **`RESERVATIONS_EXPIRING` bell group is the only unscoped aggregate** — org-wide to SALES_AGENT/FIELD_REP incl. foreign lead names | MEDIUM | **FIXED 2026-10-19 (G5-P3-1, D-GOV-5)** — `reservationScope` spread; matrix §37 FR37a–e; B-1 re-run inverted | `notifications/route.ts:123-135` (no `reservationScope` — cf. `:115` `...leadOwner`, `:106-112` `...visitAgent`); live probe: lina saw amine's reservation + lead name «Mohamed Larbaoui» |
| 3 | **F-03 / A-8** | Demo quick-login `{userId}` **default-ON** (`ASAS_DEMO_MODE` unset → enabled) | MEDIUM | CONFIRMED | `session.ts:93-95`; `login:57-80` (demo gate + lockout-respect, but default open); `.env` has no `ASAS_DEMO_MODE` key |
| 4 | **F-04 / A-9** | `next.config.ts` still `ignoreBuildErrors:true` + `reactStrictMode:false` (+ `output:"standalone"`) — type gate is convention-only, no CI backstop | MEDIUM | CONFIRMED | `next.config.ts:4-9` |
| 5 | **F-05 / A-1** | `leads/[id]` PATCH: `ownerId` reassign + `archived` lack role/owner gate — asymmetric vs bulk-assign (MANAGER) | MEDIUM | **FIXED 2026-10-19 (G5-P3-3, D-GOV-5)** — ownerId = MANAGER law (parity w/ bulk); archived = owner\|MANAGER; matrix FR38a–c | `leads/[id]/route.ts:106,143-151,167` vs `leads/bulk/route.ts:28`; bounded by D-021 scope (own+pool only) |
| 6 | **F-06 / A-4** | ~10 routes write Activity/Audit **after** the primary mutation, outside any transaction | MEDIUM | **FIXED 2026-10-19 (G5-P3-5, D-GOV-5)** — all 12 surfaces (incl. the visits/tasks DELETEs in the same files) fold mutation+Activity+Audit into ONE `$transaction`; `logActivity`/`logAudit` accept a tx client; permanent fault-injection probes (matrix §41, 28 new → 298/298) prove rollback + happy-path atomicity per site | `leads/[id]`, `apartments/[id]`, `reservations/route.ts` (POST, folded INTO the booking tx), `convert`, `visits` POST/PATCH/DELETE, `whatsapp`, `tasks/[id]` PATCH/DELETE, `leads/bulk`, `documents` (merge/import keep their audited post-commit design) |
| 7 | **F-07 / B-9** | Doc-drift cluster: STATE §14 stops at Phase 38 · DOMAIN_MODEL entity map stale · two roadmap files coexist | MEDIUM | **FIXED 2026-10-19 (GOV-3 + GOV-5 + G5-P4-3, D-GOV-5)** — three legs, three closures: (1) **DOMAIN_MODEL** re-verified line-by-line vs the live schema by GOV-3 Stage 3 (26 models; MARKETING/SalesTarget/6-status-list stale rows corrected; the file carries the GOV-3 stamp); (2) **two roadmap files** resolved by the GOV-5 restructure — legacy `ENGINEERING_ROADMAP.md` is an 8-line RETIRED redirect stub, MASTER_ENGINEERING_ROADMAP.md the single authoritative roadmap (re-verified G5-P4-3: zero stray references repo-wide; all 6 history-register doc pointers resolve); (3) **STATE §14/§2/§3** closed by G5-P4-3's pointer law — the 17-row Phase 20–38 fossil retired from "Next recommended actions" (incl. the stale R5/R6 row), §2's numbering gaps closed (P39/P40 rollback-lost rows + the P43 pointer row + the G5-era pointer row; every P41–P53 row mapped to its git commit), §3 stamp refreshed (12 migrations · matrix 320 · 190+ commits) | `MASTER_ENGINEERING_STATE.md:142-164` vs `:69-73`; `DOMAIN_MODEL.md:7,22` vs 26 live models; `MASTER_ENGINEERING_ROADMAP.md` + legacy `ENGINEERING_ROADMAP.md` |
| 8 | **F-08 / B-7** | **11 declared-but-unused dependencies** (next-auth, next-intl, date-fns + 8 more) | LOW-MED | **FIXED 2026-10-19 (G5-P4-1, D-GOV-5)** — all 11 root declarations purged, one commit per package (4f95101..b324492), per-package gate toll green ×11 + final closing gates (install clean · lint 0 · tsc exactly 4 · matrix 320/320 · baseline byte-exact); census re-verified against every hidden-use surface BEFORE removal (AR font = self-hosted woff2, not the npm pkg; sharp refs = natural language + an inert skills/ .js tool outside the tsc program; date-fns survives only as react-day-picker's own direct dep; uuid zero incl. prisma/tmp-scripts); browser golden path console-0 | 0-import census over `src/` (GOV-2-b worklog table); `package.json:58,62,68-69` |
| 9 | **F-09 / A-7** | Session cookie has no `secure` flag | LOW | CONFIRMED | `auth/login/route.ts:30-35` (httpOnly+lax+30d only) — deployment-gate item |
| 10 | **F-10 / B-8** | Helper duplication persists: `addDays` ×3, `startOfDay` ×5, `startOfWeek` ×2; `findLead` 9/19 sites | LOW | **FIXED 2026-10-19 (G5-P4-2, D-GOV-5)** — `src/lib/dates.ts` created as the ONE definition app-wide (startOfDay · endOfDay · addDays · startOfWeek · isSameDay — 15 local defs removed across 5 files; tasks-view's component-comparison isSameDay proven behaviorally equivalent & consolidated to the canonical timestamp form); `findLead` gained a backward-compatible `opts` pass-through (select/include verbatim) and 6 more sites migrated (convert · reactivate · leads/[id] PATCH · tasks · visits · opportunities POST) → 15/19 sites; 4 honest non-fits documented in leads.ts (copilot's include tree · leads/[id] GET include · duplicates dismiss's pair-count · merge's parallel pair — genuinely different query shapes, not duplicates); gates: lint 0 · tsc exactly 4 · matrix 320/320 · baseline byte-exact · browser golden path (dashboard KPIs · tasks date-groups · visits list+calendar) console-0 | `visits-calendar.tsx:55/61/68`, `visits-view.tsx:54/60/67`, `tasks-view.tsx:50/56`, `api/dashboard/route.ts:41`, `api/notifications/route.ts:51` |
| 11 | **F-11 / A-2** | `opportunities/[id]` DELETE lacks the owner\|MANAGER inner gate its siblings have; PATCH `ownerId` ungated | LOW | **FIXED 2026-10-19 (G5-P3-3, D-GOV-5)** — both gates landed; matrix FR38d–h | `opportunities/[id]/route.ts:53-56,120-145` vs `tasks/[id]:95`, `activities/[id]:35`, `visits/[id]:460` |
| 12 | **F-12 / A-3+B-5** | Reservation lifecycle has no owner/role gate (scope-only) **and** CONVERTED does not couple opportunity stage → CLOSED_WON (two-step win) | LOW | **FIXED 2026-10-19 (G5-P3-2/G5-P3-6, D-GOV-5)** — MANAGER-gated actions + the one-event coupling (CONVERTED+SOLD+CLOSED_WON in tx) | `reservations/[id]/route.ts:362,368,546-582` (lifecycle branch never touches `opportunity.stage`) |
| 13 | **F-13 / B-4** | Visits PATCH writes `agentId` without org validation (POST validates) | LOW | **FIXED 2026-10-19 (G5-P3-3, D-GOV-5)** — AGENT_NOT_FOUND on PATCH; matrix FR38i | `visits/[id]/route.ts:283` vs `visits/route.ts:188-193` (`AGENT_NOT_FOUND`) |
| 14 | **F-14 / B-6** | `GET /api/users` returns emails to any org member; matrix doc claims roster = names+roles | LOW | **FIXED 2026-10-19 (G5-P3-4, D-GOV-5)** — below-MANAGER roster minimized; MANAGER+ keeps (Équipe table); matrix FR39a–e; B-6 re-run inverted | `users/route.ts:27-30` vs `ROLE_DATA_VISIBILITY_MATRIX.md:43` |
| 15 | **F-15 / A-5+A-6** | Sequential non-tx multi-writes: visits POST (visit + createMany links) · documents POST (DB insert before file write) | LOW | **FIXED 2026-10-19 (G5-P3-5, D-GOV-5)** — visits POST = visit+links+timeline one tx (FR41e/f); documents POST reordered to file-write-BEFORE-row with tx(row+trail) + file compensation on failure (FR41y/z — disk and DB always agree; the old order left an orphaned row when the disk write failed) | `visits/route.ts`; `documents/route.ts` |
| 16 | **F-16 / A-10** | All 3 rate limiters in-memory, single-instance (documented trade-off; SQLite is single-node anyway) | LOW | CONFIRMED | `auth.ts:76`, `copilot:33`, `analyze:35` |
| 17 | **F-17 / B-10** | `User.email` globally unique (not per-org) — multi-tenant port note | INFO | CONFIRMED | `schema.prisma:51` |
| 18 | **F-18 / A-11+A-12** | Expiry sweeper scans cross-org; users email-uniqueness org-agnostic — multi-tenant port notes | INFO | CONFIRMED | `expiry.ts:24-28`; `users/route.ts:59-62` |
| 19 | **F-19 / B-11** | Unused ui/ primitives count drifted (17 recorded at P53 → **20** by importer census) — classification unchanged (stock shadcn scaffold, rejected as zombies) | INFO | CONFIRMED | importer scan over `src/components/ui/*.tsx` |

**Headline synthesis:** the platform's server-side discipline is strong and *verifiably* so (231/231
isolation matrix, 100% zod validation, 59/59 `fail()` error shape, 6 `$transaction` sites at exactly
the invariant-critical mutations, full visit transition matrix). The two real defects are both in the
**workflow-completeness class** (D-UX-057's law, now on the money path): the reservation lifecycle's
missing UI writer (F-01) and the one unscoped bell aggregate (F-02). Everything else is hardening
(F-03/F-04/F-09 deployment-gate class), consistency polish (F-05/F-11), hygiene (F-07/F-08/F-10), or
explicit port notes (F-17/F-18).

---

## 3. Architecture boundaries (verified current)

- **Shape:** single-route SPA (`/` — the AGENTS.md invariant) · 248 src files ≈ 48.3k LOC · **59 API
  route files / 77 exported handlers** · 26 Prisma models · 11 migrations (`0_init`→`p30_duplicate_management`,
  parity re-verified this round) · client-side view routing (zustand + URL hash).
- **Server/client boundary clean:** `z-ai-web-dev-sdk` confined to the 2 server routes (copilot,
  documents/analyze). No leakage into client code (grep-verified).
- **Guard architecture:** no `middleware.ts` — all protection handler-level: `requireUser()` on 74/77
  handlers (13 MANAGER-gated, 4 ADMIN-gated, 1 conditional bulk-assign); `auth/session` GET uses
  `getCurrentUser` (by design); `auth/login` POST is the public endpoint with `readJson→assertSameOrigin`
  CSRF closure (`validation.ts:12`). **This is an accepted design needing an explicit GOV-4 verdict**
  (GOV-1 seeded it; re-confirmed — the matrix's 401-wall probes passed).
- **Auth stack:** HMAC-SHA256-signed `asas_user` cookie (httpOnly, lax, 30d) · sessions voided by
  `passwordChangedAt` · scrypt (N=16384) · per-email lockout 5/15min · CSRF `assertSameOrigin` inside
  `requireUser` (`session.ts:131`) AND `readJson` (`validation.ts:12`).
- **State-machine enforcement tiers (GOV-2-b's verified map):** Visit = **full server-enforced matrix**
  (`VISIT_TRANSITIONS`, `constants.ts:54-71` → 422 `VISIT_ILLEGAL_TRANSITION`) · §37 commission =
  forward-only + pairing law + verified-amounts rungs + MANAGER+ gate · §38 incentive = edge machine +
  decided-row locks · Reservation = lifecycle-only-from-ACTIVE + booking tx (ADR-004) · Apartment =
  force-escape discipline + MANAGER+ gate (P47) · Lead/Opportunity = discipline-at-terminals (documented
  free-form — matches DOMAIN_MODEL; needs GOV-3 confirmation it's the intended business rule).
- **orgId tenant scoping:** universal — 59/59 files; every `[id]` route loads via `{id, orgId, ...scope}`
  findFirst. The one scope-law violation is F-02 (above).

## 4. Data isolation (verified current)

Per-role scoping map (`src/lib/server/visibility.ts`): MANAGER+ org-wide on all nine entity families ·
SALES_AGENT own+pool on leads/opps/tasks, `agentId ∨ null` on visits/reservations, lead-derived
contacts/activities, upload-or-linked documents · FIELD_REP **project-scoped** via ProjectAssignment
(visits on assigned projects; own tasks only, no pool; canConfirmVisit = assigned FIELD_REP or MANAGER+).
Dashboard null-gating: `funnel/sourcePerformance/commissions/pendingIncentives/pendingDuplicates/
unstaffedVisits` = null below MANAGER; `visitsAwaitingReconfirm` agent-scoped/null-FIELD_REP;
`visitsAwaitingFieldDecision` assignment-scoped/null-SALES_AGENT; `incentives` SALES_AGENT-only —
all re-proven live by the 231/231 matrix this round. Bell groups: 10 of 11 scoped — the exception is F-02.

## 5. Phase-2 audit dispositions (P2-a findings → current state)

| Phase-2 finding | Disposition | Evidence |
|---|---|---|
| #1 `db:push --accept-data-loss`, zero migrations | **FIXED** | 11 migrations; plain `db:push` script (`package.json:10-15`); parity re-verified §1.2 |
| #2 No React error boundary | **FIXED** | `src/app/error.tsx` + `global-error.tsx` (trilingual, digest-only) |
| #3 Org-level-only RBAC (agent reassigns any lead) | **FIXED (D-021)** — residual asymmetry = F-05 | `visibility.ts` + scoped findFirst everywhere; bulk-assign MANAGER |
| #4 Apartment mutations ungated | **FIXED** (P47) | `apartments/[id]/route.ts:31-33` `requireUser("MANAGER")` |
| #4b Reservation POST ungated | **BY DESIGN** (agents book holds) — lifecycle gate gap = F-12 | `reservations/route.ts:128-198` |
| #5 `ignoreBuildErrors` + strictMode off | **STILL OPEN** = F-04 | `next.config.ts:4-9` |
| #6 Hand-rolled role equality ×3 | **FIXED** | `atLeastRole` in 16 files; zero `=== "OWNER" \|\|` matches |
| #7 20 components > 400 lines | **EVOLVED — G5-P4-4 round 1 (2026-10-20): BOTH named top offenders decomposed** — dashboard 1162→**232**, leads 1083→**513**, visits-calendar 991→**395**+293+389 (grid/day-agenda/orchestrator), pipeline-view 1052→**395**+284+238+265 (card/column/moves-hook/shell); **round 2 (2026-10-20): lead-detail-drawer 850→274**+372+328 (header/info/orchestrator — the status-correction state machine + dialogs moved verbatim into the header surface; re-proven end-to-end through the extracted module: illegal edge → reason dialog → `LEAD_STATUS_CORRECTED` audit row carrying the reason); census 31→**30** files >400L (src excl. the D-042 `ui/` toolkit, incl. the i18n dictionaries — the roadmap convention), top: `api/reservations/[id]` 832 / analytics-view 775 / deal-economics 767 — the tier stays open, opportunistic (never freezes the product) | `wc -l` census (GOV-2-b) + G5-P4-4 receipts |
| #8 Helper duplication | **FIXED** — `useDebounced`→1, `ROLE_TONE`→1, visit-permission dup→consolidated; date helpers = F-10 **FIXED 2026-10-19 (G5-P4-2)**: `src/lib/dates.ts` the ONE definition app-wide, `findLead` 15/19 sites (4 documented non-fits) | census (GOV-2-b) + F-10 row above |
| #9 i18n.ts 3,046-line monolith | **FIXED** | `src/lib/i18n/` 18 dictionaries + composition root w/ duplicate-key guard |
| #10 VLM analyze no rate limit | **FIXED** — 30s/userId, 429 | `analyze/route.ts:14-35` |
| §2 unsigned raw-userId cookie | **FIXED** — HMAC-signed, constant-time, passwordChangedAt voiding | `session.ts:38-56,79-80` |
| §2 passwordless quick-login | **PARTIALLY** — demo-gated + lockout-respecting, default-ON = F-03 | `login:57-80` |
| §2 cookie no `secure` flag | **STILL OPEN** = F-09 | `login:30-35` |
| §2 `.env` + `db/custom.db` tracked in git | **FIXED** — both gitignored/untracked (GOV-1 receipt) | `git status` clean of both |
| §5 #11 hardcoded `fr-FR` Intl | **FIXED — G5-P4-5 (2026-10-20)**: `formatMonthShort` in `lib/format.ts` (the canonical `locale()` law + latn digits for AR); analytics `monthLabel` delegates — fr-DZ ≡ fr-FR short months proven byte-identical so the French default is unchanged; the chart memo now keys on `lang` (the stale-cache trap fixed) | live E2E: EN «May Jun…» · AR «ماي جوان جويلية أوت سبتمبر أكتوبر» + `dir=rtl`; zero live `fr-FR` Intl calls in src |
| §5 #12 `useSession` in `sidebar-nav` | **FIXED — G5-P4-5 (2026-10-20)**: hook moved VERBATIM to `src/lib/client/session.ts` (same queryKey → same cache); sidebar-nav is a consumer; 18 importers repointed — no component imports session state from another component (no context coupling) | grep census: 0 residual sidebar imports · exactly 1 definition |
| §5 #10 monthKey dup | **STILL PRESENT (minor)** | `api/analytics/route.ts` + calendar |
| scaffold `/api/route.ts` | **REMOVED** (P33) | git `9d635d7` |

**Phase-2 score:** 12 fixed · 3 partially · 2 still open · 3 evolved/by-design — the remediation
discipline between P3→P53 was real and traceable. (G5-P4-5 2026-10-20: §5 #11 + §5 #12
joined the fixed column — the two still-open rows are F-04/F-09, both deployment-gate
class riding P5; G5-P4-5 receipts: evidence/qa-g5p45/ + worklog.)

## 6. Verified-clean negatives (evidence of health, not absence of audit)

- 100% zod body validation (zero raw `req.json()`; multipart fields also zod-validated).
- Error shape `{error, code, details}` via `fail()` in **59/59** route files; coherent 400/401/403/404/
  409/413/415/422/429/500/502 discipline.
- `$transaction` at exactly the 6 invariant sites (booking ADR-004, reservation lifecycle, lead convert,
  import commit, duplicate merge w/ 30s timeout, expiry sweeper) — no transaction theater, no gaps at
  the money paths.
- Search route safe AND-composition (§40 fix holds); expiry sweeper guarded/idempotent; duplicate merge
  preserves references + history with post-commit audit.
- Seed satisfies every workflow invariant (duplicate pair, counter/unstaffed/§17.3 fixtures, ACTIVE hold
  w/ EXPECTED commission + PENDING incentive, 7 R5 legacy holds, 7 coherent CONVERTED+SOLD won deals).
- Migrations contain no destructive squash (DROPs = data-preserving SQLite rebuilds or documented cuts
  D-024/D-025).
- Hygiene: 0 real TODO/FIXME/HACK; dead-route scan 54/54 live (P53, re-verified clean by GOV-2-b census).

## 7. Evidence gaps (honest)

1. **F-01 severity depends on product intent:** whether managers close sales via the inventory force
   path in practice cannot be answered from seed data (its CONVERTED rows are seed-created) — needs
   owner confirmation at GOV-3/GOV-4.
2. Static-only items: transaction rollback behavior (code-read only, no fault injection in read-only
   mode) · limiter firing under contention · B-13-class SavedSearch upsert race (theoretical, noted,
   not elevated).
3. `react-hook-form`/`@dnd-kit`/`recharts` counted as used; a stricter tree-shake census (knip) might
   find marginal cases — outside read-only scope.

## 8. Feeds into GOV-4 / GOV-5 (the remediation candidates, gated on Stage-4 approval)

- **P1-class code fixes** (small, bounded, after approval): **ALL DONE 2026-10-19 (the D-GOV-5 execution arc)** —
  ~~F-02 reservationScope spread~~ (G5-P3-1) · ~~F-01 the CONVERTED/CANCEL UI surface~~ (G5-P3-2, the two-step
  closure) · ~~F-05/F-11 gate symmetries~~ (G5-P3-3) · ~~F-13 agentId org validation~~ (G5-P3-3) ·
  ~~F-14 email-select trim~~ (G5-P3-4).
- **Deployment-gate checklist items** (no code change now): F-03 `ASAS_DEMO_MODE=0` · F-04 build flags
  + the CI absence (register R3) · F-09 cookie `secure` · F-16 limiter persistence if multi-instance.
- **GOV-3 inputs:** Lead/Opportunity free-form transitions (intended business rule?) · reservation→
  CLOSED_WON coupling (explicit two-step by design?) · WORKFLOW_SPECIFICATION consolidation.
- **GOV-5 inputs:** F-07 doc-drift cluster · F-08 dependency purge (11 unused) · F-10 shared date
  helpers · component-size tier (25 files > 400L).
