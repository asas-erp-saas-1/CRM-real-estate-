# ASAS CRM — PHASE 2R — GIT RECOVERY REPORT

**Principal Engineering Recovery Lead** · 2026-11-02 · Companion to `ASAS_CRM_PHASE2R_GIT_FORENSIC_REPORT.md` (Agent 1, investigation phase) and `ASAS_CRM_PHASE2R_RECOVERY_PLAN.md` (approved plan D-R1…D-R7).

---

## 1. Chain of custody (verified)

| Commit | Date (UTC) | Author | Class |
|---|---|---|---|
| `b34d5b8` | 2026-11-02 00:39 | conventional (`feat: R15 — Phase 2+ four-indicator round…`) | **VERIFIED REFERENCE STATE** |
| `753d115` | 2026-11-02 07:26 | `Z User <z@container>` (UUID message `ffa3a843-…`) | **CONTAMINATION** — fifth documented resurrection wave |
| `693bff9` | 2026-11-02 12:25 | `Z User <z@container>` (UUID message `d8685017-…`) | Independent-audit deliverables — legitimate evidence, preserved |

No remotes, no tags, no stash, clean working tree at mission start. Both UUID commits are direct descendants of the reference with no intervening commits. The 21 UUID-message commits in history are the platform's session-snapshot auto-commit mechanism — the same mechanism that swept the resurrection wave into `753d115` 62 s after the previous session's last file write (Agent 1 §5; cron excluded: all scheduled jobs dead per P14 law, scheduler verified empty this session).

## 2. Contamination analysis (753d115 — 103 files, +8,164 lines)

| Class | Count | Disposition |
|---|---|---|
| Environment residue (resurrected ever-deleted files, **26/26 blob-identical** to every documented deletion-parent) | 26 | `git rm` (this recovery) |
| Confirmed source regressions (superseded never-tracked journey working copies carrying 5 of the 20 tsc errors + the API-poisoning route) | 5 | `git rm` |
| Uncertain tooling scripts (never tracked, never deleted) | 2 | `git rm` (disposable) |
| Obsolete generated artifacts (orphan QA PNGs: qa-continue 19 + qa-r13 19 + qa-unify 26) | 64 | **PRESERVED** (D-R4 — historical session evidence; project convention commits evidence dirs; mission orders evidence preserved) |
| Audit documentation (phase-status-audit docs + PNGs) | 6 | **PRESERVED** (historical record) |
| Legitimate engineering improvements after reference | **0** | — |
| Required configuration | 0 | — |

Purity-proof highlights (full table in Agent 1 §4): `src/lib/i18n.ts` = blob `2a3d9f7f…` identical across **five** documented deletions (P7-1 `392a743`, P26 `de9a3d3`, P32 `ee04e81`, `b6b70f4`, `26d253e`) and at `753d115`; `src/app/api/route.ts`, `tailwind.config.ts`, the 17-stock-component + 2-hook set (vs `a3a2c27^`), `view-placeholder.tsx` / `check-duplicates` / `unit-types` (vs `bb13147^` P34), `r10-seed-won.ts` — all byte-exact. The 5 journey orphans have **no deletion history** (never tracked): `journey/export/route.ts`, `journey-worklist.ts`, `journey-stats.ts`, `journey-facet.ts`, `journey-stage-chip.tsx` — mtimes Nov 1 16:13–17:28, i.e. working-session debris created **before** the reference commit, superseded by the live self-contained routes, importing an engine symbol (`isJourneyStalled`) that never existed in any committed engine.

**Zero modifications/deletions of reference files**: `git diff --name-status b34d5b8 HEAD` = 114 entries, 100 % `A`. The verified reference state was fully intact underneath the contamination — which made selective removal the safest recovery (no revert, no rewrite).

## 3. Recovery executed (the corrective change)

**Method (D-R1)**: selective file removal + one conventional corrective commit, per the D-040/D-041 protocol and the P32/P33/P34 precedent. **Rejected**: `git revert 753d115` (would delete the legitimate audit deliverables the commit carries), history rewrite / `reset --hard` / `clean -fd` (forbidden by mission §5/§17; also pointless given the additive-only diff).

**Safe checkpoint (Phase Zero duty)**: branch `p2r-checkpoint` created at `693bff9` before any change (non-destructive ref; no commit created; rollback anchor preserved).

**The removal** — `git rm` of exactly **33 files** (staged deletions, −7,767 lines):

1. `src/lib/i18n.ts` — the 3,253-line monolith shadow (the localization corruption root cause)
2. `src/app/api/route.ts` — unauthenticated "Hello, world!" scaffold zombie (public info endpoint, deleted twice before)
3. `src/app/api/journey/export/route.ts` — the API-poisoning route (D-R3 disposition, §4 below)
4. `src/app/api/leads/check-duplicates/route.ts` — never-wired route (P34/D-042 deleted, resurrected)
5. `src/app/api/properties/unit-types/route.ts` — never-wired route (P34/D-042 deleted, resurrected)
6. `src/components/crm/journey-stage-chip.tsx` — stale orphan (tsc error: `openJourneyFocus` gone from CrmState)
7. `src/components/crm/view-placeholder.tsx` — dead scaffold (P34/D-042 deleted, resurrected)
8–24. 17 stock `src/components/ui/*` scaffold components (`accordion, aspect-ratio, carousel, chart, collapsible, context-menu, drawer, hover-card, input-otp, menubar, navigation-menu, radio-group, resizable, sidebar, toast, toaster, tooltip`) — deleted at `a3a2c27` after their 15 dependencies were purged (14× TS2307 prove the deps are gone)
25. `src/hooks/use-mobile.ts` · 26. `src/hooks/use-toast.ts` — same wave
27. `src/lib/server/journey-facet.ts` · 28. `src/lib/server/journey-stats.ts` · 29. `src/lib/server/journey-worklist.ts` — stale journey orphans (4 tsc errors + the poisoning import chain)
30. `tailwind.config.ts` — vestigial config retired at `ae9357f` (its `tailwindcss-animate` import fails in dev.log)
31. `tmp-scripts/census.ts` · 32. `tmp-scripts/r10-seed-won.ts` · 33. `tmp-scripts/recent-audits.ts` — tooling residue (`r10-seed-won` a documented zombie; the two others disposable never-tracked scripts)

**Source-equivalence proof**: `git diff b34d5b8 -- src/ tailwind.config.ts tmp-scripts/` = **EMPTY** — the post-recovery source tree is byte-identical to the verified reference state. The repository's tracked content differs from the reference **only** by the preserved documentation/evidence additions (both audit sessions' deliverables + this mission's Phase 2R reports + `evidence/phase2r/`).

## 4. Preserved legitimate work (nothing lost)

- **The reference state itself**: 0 M/D — every D1–D14 change, all 9 architecture invariants, all security controls, all CRM workflows (Agent 5: 14/14 D-table, invariants a–h intact).
- **The independent-audit deliverables** (`693bff9`: 5 audit `.md` + 5 PNG + the poisoned-response HTML) — untouched.
- **Historical session evidence** (`753d115`'s 64 QA PNGs + 4 phase-status docs) — untouched (D-R4).
- **All 9 Phase 2R mission reports** (6 agent reports + recovery plan + this report + the final report) — added to `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/`.
- **Baseline evidence**: `evidence/phase2r/` (8 baseline + 27 final verification screenshots).
- **Working-tree safety**: no user work existed beyond the committed state (clean tree at mission start); no stashes existed; nothing discarded.

## 5. The `/api/journey/export` disposition (D-R3 — documented deviation)

The mission's Phase-4 text assumed a legitimate broken feature ("repair… do not disable"). Verified evidence (Agents 1/2/3/5) established: never tracked in any commit; imports an engine symbol that never existed (`isJourneyStalled` — `git log -S` empty across all history); zero live UI callers; capability absent from the verified reference state; identical defect class closed by binding law **D-042** with the authenticated-404 precedent (P34 deleted exactly such routes twice — two of them resurrected in this very wave). The **verified defect** — one hit globally poisoning every API route until restart (reproduced twice: audit + Agent 6) — is eradicated at the root by removing the compile-broken zombie route. The live journey API contract (`/api/journey`, `/api/journey/stats`) is byte-identical to the reference and re-verified end-to-end. Post-recovery behavior: `/api/journey/export` → honest **404** (never 500), with zero cross-route impact — the P34-verified "endpoint gone" pattern. **Option B** (repair-to-working: 3 precise edits to `journey-worklist.ts` against `JOURNEY_STAGE_SLA_DAYS` + inlined stalled law) remains fully specified in Agent 3 §8 as post-recovery feature work **should the owner want the capability** — to be executed as wired feature work (UI button + i18n keys + audit keys, per D-042 "wired-or-deleted"), not as recovery. This deviation from the mission's literal Phase-4 instruction is flagged here and in the final report.

## 6. Governance compliance

- **D-040/D-041** (deleted-means-deleted; resurrection sweep): 26 zombies re-deleted **after** the content-hash purity proof (26/26 identical); full-repo tsc gate back to reference behavior (src = 0; the 4 tolerated non-src errors are examples/skills only — unchanged class); route deletions followed the restart-with-cleared-`.next` protocol (next-server killed **by PID from `ss -tlnp`** — pid 6723 → fresh 9703 — plus `rm -rf .next`).
- **D-042** (never-wired must be wired-or-deleted): the 4 never-wired routes swept with the redundancy-with-live-surface purity proof (duplicates capability live via POST-side DUPLICATE 409 + import preview + P30 scan/merge/dismiss; UNIT_TYPES imported directly from `@/lib/constants` by every client; journey export — §5).
- **R13 recovery manual**: followed verbatim for the environment layer (§ `ASAS_CRM_PHASE2R_ENVIRONMENT_BLOCKERS.md`).
- **Commit law (AGENTS.md:19)**: one conventional commit `app: p2r — …` with full evidence in the message (vs the UUID noise class); locally reversible via `git revert` pending user acceptance (D-R6 — the alternative, leaving staged deletions for the platform's UUID auto-commit, would recreate the governance failure under remediation).
- **Preventive recommendation (ND-A5 closure)**: the platform's session-snapshot auto-commit is the mechanism that immortalized the resurrection wave (21 UUID commits in history). Recommendation recorded: every session that finds an unclean tree should run the ever-deleted ∧ in-HEAD sweep **before** closing, and UUID-commit contents should be diffed against the last conventional commit on session open (the P33 sweep law already mandates the former; the worklog entry formalizes it again).

## 7. Verification matrix (post-recovery, this session)

| Check | Result |
|---|---|
| `git diff b34d5b8 -- src/ tailwind.config.ts tmp-scripts/` | **EMPTY** (byte-identical to reference) |
| `bunx tsc --noEmit` | **0 errors** (was 20, all contamination-confined) |
| `bun run lint` | **0** (exit 0) |
| Resurrection sweep (ever-deleted ∧ in-HEAD) | contamination set = 0 remaining; 34 pre-existing adjudicated reference hits documented (22 owner-sanctioned Phase-D restorations + 12 R14-adjudicated tmp-scripts — reference-state content, out of scope, per functional-equivalence objective) |
| i18n validator (`p22-i18n-audit.ts`) | static keys 1,266 scanned; **missing = 0 real** (1 doc-comment false positive at `i18n/index.ts:3` — pre-existing at reference); partial = 0; enums complete ×3 langs; dictionaries = **1,877 ×3** (was 1,013 via monolith) |
| Dev server | restarted with cleared `.next`, pid 9703, stable through the entire verification pass (single-pid proof) |
| API gates | login 200 · `/api/journey` 200 JSON (43-lead funnel) · `/api/journey/stats` 200 JSON · dead URL **404** + **no cross-route poisoning** (session/journey stay 200 after hit) · unauth 401 JSON · agent-role 403 FORBIDDEN_ROLE · `GET /api` 404 |
| Browser (Agent 6, independent) | 12 views × FR/AR/EN = 36 DOM-wide scans **0 raw keys** · RTL flip ×12 · 5 viewports 0 px overflow · console **zero errors** · golden-path smoke · RBAC negative live 403s · 27 final screenshots |

## 8. Verdict

**Repository integrity restored.** The delivery candidate's source tree is functionally and byte-identical to the verified reference `b34d5b8`; all contamination is removed with purity proofs; all legitimate work (reference engineering + both audit sessions' evidence + this mission's reports) is preserved; no destructive Git command was used; the corrective change is one reviewed, conventional, locally-reversible commit on top of a preserved checkpoint branch.
