# ASAS CRM — PHASE 2.2 ARCHITECTURE IMPLEMENTATION

**Task owner:** Principal (integration) + Agents 2-b/2-c/2-d (view modules) · **Status: VERIFIED**

## 1. What actually changed

| Area | Change | Files |
|---|---|---|
| New product surface | Customers book (list-only API + workspace view) — reuses the CJ journey engine, the existing 360 lead drawer, STAGE_* visual tokens, TablePagination, useDebounced. Zero duplicated detail/mutation surface | `api/customers/route.ts`, `views/customers-view.tsx` |
| View registry | `customers` added to `View` union + `VIEWS` + hash routing + shell `VIEW_META` + sidebar nav | `store.ts`, `crm-app.tsx`, `shell.tsx`, `sidebar-nav.tsx` |
| i18n | New `customers` domain (34 keys × 3 langs) registered through the existing composition root (duplicate-key + parity guards active) | `i18n/domains/customers.ts`, `i18n/index.ts`, `common.ts` (nav key) |
| Facet composition | `unassigned=1` intake-pool facet on `/api/leads` (MANAGER+-gated 403) mirrors the `uncontacted=1` Wave-3A law | `api/leads/route.ts` |
| Health probe truthfulness | `/api/health` separates connectivity (`SELECT 1`) from migration bookkeeping (null on push-based DBs — was a false "degraded") | `api/health/route.ts` |

## 2. Complexity/duplication decisions (the "no overengineering" law)

- **No new drawer**: the Customer 360 IS the existing `LeadDetailDrawer` (journey rail + 6 tabs), deep-linked via `openLead(leadId)`. One 360 surface for leads AND customers.
- **No new mutation surface**: `/api/customers` is GET-only. All mutations flow through the existing scoped/audited lead/opportunity routes — no parallel authorization logic to maintain.
- **No new stage vocabulary**: journey-stage labels reuse `journey.stage.*` keys; visual stage tones reuse `STAGE_BAR`/`STAGE_ICON` from the journey view.
- **No competing state**: the view uses component-local workspace state (same family as journey/sav views); the shared `workspace-store` was NOT extended (its per-slice reset law stays intact — a future wave can lift it if amnesia is observed in practice).
- Agent 2-c discovered the pipeline kanban modules live in `src/components/crm/pipeline/` (not `views/pipeline/`) — the correct ownership boundary was respected.

## 3. Verification

- `bunx tsc --noEmit` → exit 0 (strict).
- `bun run lint` → 0 findings.
- `bun run test` → **163/163 passed** (was 159: +4 contract tests for the new surfaces, health test updated for truthful null migrations).
- Structural guard: the i18n composition root's duplicate-key + parity guards load clean with the new domain (fail-fast at module load).
- Found & fixed during integration: double-`?` URL bug in the customers query (`?${params}` where `qs()` already returns the leading `?`) — caught by browser network log (`??idle=1` → server read key `?idle`), fixed, filter re-verified end-to-end.
