# UX/UI Audit — Phase 2 (Task P2-d, retry)
Auditor: UX/UI + QA subagent · READ-ONLY (zero code changes) · Live: http://localhost:3000, persona Sarah Hamdi (MANAGER) · Viewport 1440×900 / 390×844 · FR + AR · 2026-10-02
Evidence: 8 screenshots in /home/z/my-project/download/qa-p2/ · console+page errors tracked via window.__errs (re-installed after each reload): **0 across entire session**, no hydration warnings.

## Executive summary — top friction points (ranked)
1. **No delete/undo for tasks & visits** (P3): only lifecycle actions exist (Terminer / Confirmer-Replanifier-Annuler). Accidental creation is permanent; this audit itself leaves undeletable test rows.
2. **Focus not restored to trigger on dialog close** (P3): Escape on create-lead dialog drops focus to `<body>` (2× reproduced). Keyboard users lose their place.
3. **Import auto-mapping ineffective** (P3): banner says "Mapping automatique appliqué" but fullName/phone/budgetMin all default to "— Ignorer —" — manual mapping forced for trivially-guessable headers.
4. **No unit picker in visit scheduling** (P3): visits scheduled at project level only; can't pin an apartment.
5. **Bulk-copilot error rows surface raw error labels** ("Échec · network") and offer no per-row retry (graceful otherwise: no crash, no infinite spinner).
Overall verdict: **mature, polished UI** — drawer density, validation a11y, mobile responsiveness, and RTL quality are all above par; findings are P3 polish, no P2-blocking UX defects.

## Per-check results
1. **Lead triage (#/leads) — PASS.** Search "mo": debounced, 7 rows (substring match incl. surnames). Filters: status = chip row; Source/Priorité/Agent = **native `<select>`** (instant apply, no Apply button; visual inconsistency vs shadcn Radix elsewhere — P3 polish). Row click → drawer; phone/status/owner/budget **all visible without scrolling** (header block, sheetH=900/viewport=900). Note typed+saved → instantly in Historique ("cette minute-ci"); toast not catchable at ~1.2s (duration too short or absent — P3). Escape closes. FRICTION subset: activities have no delete/edit.
2. **Task + visit creation — FRICTION (P3).** Task (drawer Tâches tab): title + Radix type/priority + **native datetime-local** picker (functional, no custom calendar), submit disabled until title ✓, appears instantly ✓. Visit (#/visits → Planifier): prospect combobox shows phone ✓, Projet + Agent selects, date+time, notes; toast "Visite planifiée" ✓. Calendar mode: per-day visit counts; day click → inline day agenda, visit visible w/ project+agent ✓. **No delete exists for task or visit anywhere** (drawer, tasks view, visits view) → no undo for accidental creation. Also: no unit/apartment picker in the visit dialog.
3. **Pipeline stage change — PASS.** Opportunity dialog → Étape Radix Select Qualifiée→Négociation → toast "Déplacée vers « Négociation »" → **persisted after full reload** ✓ (reverted afterwards — zero residue). Lost path: "Marquer comme perdue" dialog with reason field, Confirmer disabled until filled, Annuler cancels cleanly leaving stage unchanged ✓ (good quality; no quick-reason presets — micro).
4. **Global search — PASS.** Ctrl+K → palette; "mo" → grouped results (5 leads + opportunities w/ labels); ArrowDown moves selection visibly; Enter opens **deep-linked** drawer (#/leads/<id>); Escape closes drawer and normalizes URL to #/leads. Latency: instant (client-side).
5. **Import preview — PASS w/ FRICTION (P3).** /tmp/p2d-test.csv (2 rows, 1 bad) → mapping step → preview: **"1 valides · 0 doublons · 1 erreurs"**, row 2 flagged "Téléphone invalide", summary block "PROBLÈMES DÉTECTÉS 1× Téléphone invalide" ✓. Retour preserves mapping (good); close→reopen fully resets to step 1 ✓. **CANCELLED before commit — zero DB write.** Friction: auto-mapping claimed but not applied to obvious headers.
6. **Bulk copilot error handling — PASS (env deviation).** Gateway is **UP** (worklog said down — recovered). Happy path (2 leads): sequential queue w/ pacing, per-lead rows w/ AI summary + score, progress 0/2→2/2, footer "2 analysé(s) · 2 scores appliqués", Arrêter present, 0 console errors. Error path (endpoint blocked via browser network route): row → "Échec · network", footer "0 analysé(s) · 1 échec(s)", no crash, no infinite spinner ✓. Auto-apply defaults ON → see residue.
7. **Keyboard a11y — FRICTION (P3).** Tab traversal: visible 3px oklab focus ring on inputs AND Radix triggers ✓. Empty submit: specific messages ("Champ requis", "Numéro de téléphone invalide", "Champ requis"), inline placement, `aria-invalid=true`, `aria-describedby` wired, **focus jumps to first invalid field** ✓ — excellent. **BUG: Escape close → focus lands on `<body>`, not the trigger** (2× reproduced).
8. **Mobile 390×844 — PASS.** #/leads: table hidden → cards, scrollWidth=390 ✓ (BulkBar unreachable: no checkboxes on mobile cards — P3 note). #/visits calendar: 390 ✓, day click → inline agenda ✓. #/pipeline: 390 ✓. #/analytics: 390 ✓ (21 charts render). Zero horizontal overflow anywhere.
9. **RTL Arabic — PASS.** dir=rtl+lang=ar; leads table fully translated (الاسم/الهاتف/…/النقاط), row values localized (إنستغرام، جديد، عادية، 13 مليون دج); create-lead dialog: 13 complete Arabic labels, no truncation; dashboard Arabic KPIs; **latin digits everywhere** (no Arabic-Indic) — convention held. No overflow. Login overlay fully Arabic (incl. demo-password hint) + login via AR overlay works (sarah/asas1234 → #/dashboard).
10. **Console sweep — PASS.** window.__errs = 0 after every section; `agent-browser errors` empty; console: no hydration warnings, no warnings.

## Bug list (with repro)
- **B1 (P3) No delete for tasks/visits.** Repro: drawer Tâches tab → create task → row actions = {Terminer} only; #/visits → create visit → actions = {Confirmer, Terminer, Replanifier, Annuler} only. No DELETE control anywhere; API likely supports it (P2-a map) but UI never exposes it.
- **B2 (P3) Focus lost on dialog close.** Repro: #/leads → "Nouveau prospect" → press Escape → `document.activeElement === document.body` (expected: trigger button).
- **B3 (P3) Activity items immutable.** Repro: drawer → Historique → any entry: no delete/edit affordance (only lead-level Statut/Responsable dropdowns exist).
- **B4 (P3) Import auto-map no-op + misleading banner.** Repro: upload CSV with headers fullName,phone,budgetMin → all comboboxes "— Ignorer —" while step banner reads "Mapping automatique appliqué".
- **B5 (P3) Bulk-copilot error label raw.** Repro: block /api/leads/*/copilot → row error shows "Échec · network"; no retry action per row.
- **B6 (P3) Visit dialog lacks unit picker.** Repro: Planifier une visite → fields: Prospect/Projet/Agent/date/notes — no unit/apartment field.
- **B7 (P3, obs) Mobile bulk selection unavailable** — lead cards have no checkbox → BulkBar/Analyse IA unreachable at 390px.
- **B8 (P3, data) Possible duplicate lead:** two "Mohamed Larbaoui" rows (with/without email m.larbaoui@gmail.com) both match "mo" search — not investigated (scope).

## Residue for main-session cleanup (UI deletion impossible — B1/B3)
1. Task **"P2-d audit test task"** — lead hadj said hammou, due 2026-10-03 10:00, Suivi/Normale.
2. Visit — hadj said hammou · Villas Sidi Yahia · agent Sarah Hamdi · 2026-10-04 11:00 · status Planifiée.
3. Activity note **"P2-d audit test note"** — hadj said hammou, Note · Sarah Hamdi.
4. Copilot auto-apply: hadj said hammou aiScore **60→75** (+AI summary overwritten); +1 Copilote IA activity each on hadj said hammou & Réda Mokrani (Réda score 55→55 unchanged).
Cleaned/reverted: pipeline stage (Qualifiée→Négociation→Qualifiée, verified); import cancelled (0 rows); filters/checkboxes reset; language/viewport restored.

## Preserve list (what's good — don't break)
- Drawer info density (phone/status/owner/budget above the fold) + tabbed Historique/Tâches/Visites architecture.
- Deep-linkable drawers (#/leads/:id) + palette→Enter→drawer→Escape flow with URL normalization.
- Form validation stack: specific messages, aria-invalid/describedby, focus-first-error, visible focus rings.
- Import preview: valid/duplicate/error counters, per-row error flags, mapping preserved on Retour, full reset on reopen.
- Mobile: 0 horizontal overflow on 4 views, table→card collapse, inline calendar day agenda.
- RTL: full mirroring, no truncation, latin-digit convention, complete AR login overlay.
- Bulk copilot queue UX (progress, per-row states, abort, summary footer) — handles both success and failure without crashing.

## Recommendations (ranked, max 10)
1. Add delete (with confirm) for tasks & visits — closes B1, enables undo; also unblocks audit residue cleanup.
2. Restore focus to trigger on dialog/drawer close (Radix onOpenChange focus management) — B2.
3. Delete/edit affordance for activity entries (MANAGER+ gated) — B3.
4. Fuzzy import header auto-mapping (fullName→Nom complet, phone→Téléphone…) + suppress banner when nothing mapped — B4.
5. Bulk copilot: map fetch/network errors to friendly French copy + per-row "Réessayer" — B5.
6. Visit dialog: cascading unit picker (project → available apartments) — B6.
7. Mobile bulk-selection mode (long-press or "Sélectionner" toggle on cards) to expose BulkBar on phones — B7.
8. Toast duration ≥2.5s (activity/task creation confirmations currently imperceptible).
9. Replace native filter selects with shadcn Select for control consistency.
10. Dedupe-check the two "Mohamed Larbaoui" leads (B8) via phone/email matching.

## Screenshots (download/qa-p2/)
01-leads-filter · 02-drawer-task-created · 03-calendar-day · 04-pipeline-dialog · 07-mobile-leads · 08-mobile-visits-cal · 09-rtl-leads · 10b-rtl-login-overlay
