# ASAS CRM — Independent Engineering Acceptance Audit Report

**Audit type:** Independent external acceptance audit (read-only; zero implementation writes).
**Audit date:** 2026-11-02 (this session, ~10:50–12:30 UTC).
**Audit team:** Six specialized read-only auditors (A Architecture · B Database · C Security · D UI/UX · E CRM Business Logic · F QA/Testing/Delivery) + lead acceptance auditor performing first-hand runtime/browser verification.
**Subject state:** git `main` @ `753d1157469d0e46d1a09aeb902517cfae11913c` (bare-UUID message `ffa3a843-519c-4c27-943e-d767e5360004`, 2026-11-02 07:26:23 +0000), 303 commits, single branch, no remote, working tree clean (0 modified / 0 untracked).
**Baseline comparison:** last documented engineering commit `b34d5b8` ("feat: R15 — Phase 2+ four-indicator round", 2026-11-02 00:39:06 +0000) — every prior delivery document describes this state.

---

## 1. Executive verdict

**Has ASAS CRM genuinely completed the engineering work claimed during Phase 0, Phase 1, and Phase 2?**

**Yes — the engineering is real.** Every material claim sampled by the six independent auditors was located in the codebase with file:line precision and matched its description: the shared-guard architecture (70/74 routes through `requireUser`), the 17-migration chain including the D12 partial-unique-index migration, the D1–D14 business-logic defect fixes (revival guard + full economics reset, closure gate on all three CLOSED_WON paths, reassign cascade, auto-advance transactions), the session hardening (HMAC + timingSafeEqual + 7-day absolute expiry + CSRF origin checks verified live), the design system (61 oklch tokens, 7-tier semantic type scale), the a11y engineering (row-nesting fix, 44px touch floors, skip-to-content), and the R15 features (TrendChip with the never-truncate flex-wrap fix, kanban mini-map). The prior delivery documents were **accurate at their commit timestamps** — this audit found zero evidence of fabrication, and the evidence receipts (screenshots, probe logs, worklog gate entries) survive and check out.

**No — the project as it stands is not acceptable.** A single undocumented commit `753d115`, made ~7 hours after the last documented round closed, added 103 files (+8,164 lines) of resurrected deleted code, abandoned broken in-progress code, and sandbox template scaffold. This commit — not any engineering round — is the proximate cause of every current defect: **the build fails at HEAD** (20 tsc errors → `next build` aborts; CI static gates red), **the i18n text layer is broken** (a 3,253-line zombie `src/lib/i18n.ts` shadows the modular 1,877-key dictionary for the app-wide store → 662 unique keys / 849 of 2,055 render sites / all 12 views render raw keys), **the dev-server API surface degrades globally** (one request to the broken `/api/journey/export` — reproduced first-hand in this audit — poisons every subsequent API request to 500 HTML), and the commit **escapes the worklog governance entirely** (`grep -c "ffa3a843\|753d115" worklog.md` = 0) while violating the project's own binding D-040/D-041 resurrection-sweep law.

Additionally, the **live environment cannot demonstrate any authenticated behavior**: the database is schema-current but empty (0 users, 0 leads, 0 reservations — a `db push` artifact with no `_prisma_migrations`, no D12 indexes, WAL off), `ASAS_SESSION_SECRET` is unset, and `db/backups/` is wiped. All authenticated acceptance testing (Sections 6–7 of the mandate) is **BLOCKED** by this state.

**Verdict per phase:**

| Phase | Verdict |
|---|---|
| Phase 0 — discovery & baseline | **PASS** (independently re-verified from surviving artifacts) |
| Phase 1 — six-workstream audit + 9 deliverables | **PASS** (all deliverables exist with substantive content; findings cross-checked against real code — 43/43 spot-verifications by the prior status audit, re-confirmed by this audit's six auditors) |
| Phase 2 — remediation waves 1–7 | **PASS as engineering executed at `b34d5b8`** (code verified; at-time runtime receipts genuine) · **FAIL as the deliverable state at HEAD `753d115`** (build broken, text layer broken, governance broken) |

**Final recommendation: REJECT — ADDITIONAL ENGINEERING REQUIRED.**

The rejection is narrow and precisely scoped: the required engineering is **one recovery session** (delete the 753d115 zombie set after the content-hash purity proof → execute the R13 DB recovery runbook → re-run the standing verification matrix), not a re-engineering program. The underlying Phase 0/1/2 work merits acceptance at `b34d5b8`; the delivery state at HEAD does not qualify. A passing code build alone would not have qualified it for production anyway (empty live DB, PG RLS never runtime-tested, no production build ever executed — see the Readiness Assessment).

---

## 2. Scope reviewed

- **Repository:** 303-commit `main` history; the `b34d5b8`→`753d115` delta (103 files, all additions — verified by `git diff --name-status`); all 20 05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ deliverables; AGENTS.md operating laws; worklog.md (4,770 lines) gate entries; package.json + lockfile.
- **Code:** 74 API routes under `src/app/api/**`; `src/lib/server/*` (session, auth, guards, lifecycle, visibility, DTO, visit-facets, metrics); `src/lib/client/store.ts`; `src/lib/journey.ts`; `src/lib/constants.ts`; ~150 crm components; `src/app/globals.css`.
- **Database:** `prisma/schema.prisma` (30 models) + `prisma/schema.postgres.prisma`; `prisma/migrations/` (17 dirs, incl. the D12 raw-SQL migration read verbatim); `supabase/migrations/` 0001–0004 (26 CREATE TABLE / 65 FKs / 130+20 RLS statements counted; default-deny org-claim SQL quoted); `prisma/seed.ts` (1,745 lines, census counted statically); live `db/custom.db` probed read-only (30 tables, 0 rows, journal_mode=delete).
- **Runtime:** dev server on :3000 (turbopack); unauthenticated API matrix; browser session (agent-browser) on the login surface at 1440/1280/390/375 widths × AR-RTL/EN-LTR/FR; console and network capture; dev.log forensics (203 journey-worklist error occurrences).
- **Evidence corpus:** `download/` (85 entries, 1,299 PNGs) + `evidence/` (18 dirs, 155 PNGs) — counts verified; specific screenshots spot-checked for plausibility.

**Out of scope / BLOCKED:** authenticated workflows (empty DB — no test identities can exist without executing the recovery runbook, which is remediation, not audit); PostgreSQL/Supabase RLS runtime behavior (no PG instance anywhere); production build (forbidden by house law in this environment); real-customer data (none exists in this demo workspace).

---

## 3. Independent findings

### 3.1 The decisive discovery — commit `753d115`

| Attribute | Finding | Evidence |
|---|---|---|
| Content | 103 files, +8,164 lines, **zero modifications, zero deletions** | `git show 753d115 --stat` |
| Message | Bare UUID — no description of any kind | `git log -1` |
| Documentation | **Recorded nowhere**: worklog.md (append-only, 4,770 lines) has 0 references to the hash or UUID | `grep -c` = 0 |
| Contents class | (1) 5 resurrected zombies deleted earlier in history (`src/lib/i18n.ts` 3,253 lines — deleted in P26/P32 eras; `tailwind.config.ts` — retired in H2; `view-placeholder.tsx`, `check-duplicates/route.ts`, `unit-types/route.ts` — deleted in the 26d253e sweep); (2) 6 abandoned broken journey-refactor files + their 40 evidence screenshots (never referenced by any doc; 5 tsc errors; 1 missing store action); (3) 18 sandbox template scaffold files (17 shadcn ui components + 2 hooks referencing 16 uninstalled packages); (4) the previous status-audit's own 4 documents + 2 screenshots | file mtimes + `git log --diff-filter=D` for each deletion |
| Consequences | tsc 20 errors → build fails; i18n zombie shadows modular dictionary for 5 live importers incl. the app store; `/api/journey/export` broken import → dev-server global API poisoning (reproduced); unguarded junk `GET /api` endpoint reactivated | every auditor + first-hand |

The commit's profile (UUID message, adds-only, environment-scaffold content, ~7h after round close, no worklog entry) matches the **R13-class environment re-provisioning** the project itself documented ("sandbox re-provisions untracked state at session boot" — root-cause determination, commit `e2ebf7f`) — except that this time the re-provisioned files were **committed to the repository**, converting an environment artifact into a code defect. The project's own AGENTS.md law anticipated exactly this class and mandates a resurrection sweep **before any steady-state witness** (AGENTS.md:17) — the sweep was not executed before this audit, and the audit mandate (correctly) forbade executing it.

### 3.2 The i18n zombie — the single worst code defect at HEAD

- `src/lib/i18n.ts` (zombie, ~1,013 keys/lang) + `src/lib/i18n/` (modular, 22 domain files, 1,877 FR keys) **both exist**; TypeScript/bundler file-before-folder resolution binds `@/lib/i18n` to the zombie — **empirically proven** via `tsc --traceResolution` ("Module '@/lib/i18n' was successfully resolved to '/home/z/my-project/src/lib/i18n.ts'").
- 5 live importers re-bound, including the app-wide store `src/lib/client/store.ts:10` (imports `translate`, `dirFor`).
- The zombie is a **strict subset** of the modular dictionary (0 zombie-only keys) → **864 keys (46.0%) missing**, including the entire `journey` (139), `sav` (93), `visits` (86), `finance` (72), `leads` (68) families.
- Blast radius: **849 of 2,055 static t()/labelKey render sites (41.3%) render raw keys at HEAD; 81 component files affected; all 12 views**; 3 sidebar nav labels (`nav.journey/finance/sav`) raw; 3 of 12 `document.title`s raw; raw keys inside `aria-label`s (skip-link text, density toggle, TrendChip title, restore button, mini-map group) — an a11y regression layered on intact a11y structure.
- The entire modular i18n system is **orphaned at HEAD** (zero importers).
- Recovery is a **one-file deletion with zero key loss** (strict-subset property).

### 3.3 The dev-server API poisoning — reproduced first-hand

Sequence reproduced in this session: healthy window (unauthenticated `GET /api/leads` → 401 JSON, byte-identical bodies across all protected endpoints) → one request to `GET /api/journey/export` (broken import chain) → **every subsequent API request returns 500 HTML dev-error pages** (including previously-compiled routes), leaking absolute paths/stack traces in the HTML. The dev server never recovers without a restart. Fail-closed preserved (no data exposed), but the 401 JSON contract breaks app-wide. dev.log carries 203 occurrences of the journey-worklist error. The browser visit shows the "Build Error" overlay on first load; after dismissing it, the login surface renders fully.

### 3.4 The live database — schema-current, data-empty, provenance-drifted

- 30 tables matching the 30 schema models exactly; critical columns all present (incl. `closureRequestedById`, `stageChangedAt`, Arabic alias columns); `Reservation_orgId_incentiveStatus_idx` present.
- **0 rows in every table** — the delivery docs' census claims (8/43/21/… and the "17/17 migrations applied, D12 indexes present in live DB, WAL ON" indicator battery) describe a state wiped by the environment reset. Current truth: `_prisma_migrations` ABSENT (db-push provenance — `migrate deploy` would fail), **D12 partial unique indexes MISSING from live DB** (checked `sqlite_master` by exact index name), `journal_mode=delete` (WAL claim REFUTED for the current file).
- Repo artifacts are pristine: the 17-migration chain is coherent and cumulative; migration #17's two partial unique indexes verified verbatim (per-apartment AND per-opportunity, `WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')`); the Supabase PG chain is structurally sound (26 tables/65 FKs; 33 CHECK constraints matching `constants.ts`; 150 RLS statements with genuine default-deny org-claim semantics — quoted and verified on 5 sample tables).
- **Cross-provider gap found:** the PG chain contains ONLY the per-apartment live-hold index; `schema.postgres.prisma:611-617` claims both indexes deploy — overstated comment / missing 0005 migration. (New defect, P2.)
- Seed tooling: `prisma/seed.ts` census statically re-counted (8 users/43 leads/21 opps/… matches claims); `scripts/validate-seed.py` re-run read-only → **PASS** (606 rows, 0 parse/FK/order violations, counts MATCH); `supabase/seed.sql` is 606 rows while two handoff docs still claim 511 (stale docs, P3).

### 3.5 Security — the strongest domain (10/10 areas verified; zero P0/P1)

Live-verified this session: CSRF origin enforcement (cross-origin POST → 403 `CROSS_ORIGIN_BLOCKED`; same-origin → 200; login with empty body → 422 not 403); the full unauthenticated matrix (11 protected endpoints → byte-identical 401 JSON in the healthy window); security headers on live responses (`X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`; CSP/frame-deny absent per the documented preview-iframe trade-off). Code-verified: HMAC-SHA256 + `timingSafeEqual` + 7-day absolute expiry + password-change invalidation; scrypt with lockout-respecting quick-login; DUMMY_HASH timing equalization; ROLE_RANK hierarchy + ROLE_CEILING (ADMIN cannot touch OWNER); D-021 scoped `findFirst` with orgId AND visibility on all sampled routes; ghost-404 byte-identical by construction (single throw path); fail-closed DTO allowlist + below-manager email stripping; **zero UI-only authorization** across ~60 mutation routes.
New findings: git history still contains one dead session-secret blob + ~10 commits with the demo DB (contained: no remote; the project's own purge plan pre-verified as accurate — escalates to P0 only if a remote is added before purge); scrypt cost constants declared but never passed (correct-by-coincidence, P3); `X-Powered-By` unsuppressed (P3); junk unguarded `GET /api` (P3, from the zombie commit).

### 3.6 CRM business logic — 12/12 areas verified; 6 new defects (2 MEDIUM, 4 LOW)

All claimed fixes located and verified: LEAD_TRANSITIONS + in-tx auto-advance (activities NEW→CONTACTED, requirements →QUALIFIED); OPPORTUNITY 10-stage matrix + correction escape hatches; the PENDING→PENDING economics fix (correctly living in `reservation-trust.ts:258-283`); D1 revival guard + complete field-reset list (checked field-by-field against the schema); D2/D3/D4 guards with exact error codes; D10 guarded release + sweeper parity; D7 stageChangedAt stamp; D8 single-tx reactivate; D5 reassign cascade via `OPP_CLOSED_STAGES`; **the closure gate on all three enumerated CLOSED_WON write sites** (grep-exhaustive); P54 two-step closure states; pure journey engine shared by all surfaces; visit auto-link + ladder reverse-index; appointments one-source (exactly 1 writer, 1 mount); D13 metrics + adoption; 5 transition matrices → 422 with explicit codes; dup-submission coverage (activities 5s twin guard; reservations tx-409 + unique indexes; leads dup-409).
**New defects:** ND-1 (MEDIUM) `oppBefore` read post-transaction → dedicated stage-change audit row unreachable; ND-2 (MEDIUM) request/reject_closure write their Activity+Audit **outside** the house tx law (the exact class D8 fixed); ND-3 apartment dialog blind to CLOSURE_REQUESTED holds (display-only); ND-4 `journey-facet.ts` dead+unwired; ND-5 `PRE_BOOKING_STAGES` hand-declared (drift risk); ND-6 revival keeps `createdAt` → "latest row wins" can pick the wrong row.

### 3.7 QA/delivery — the root systemic weakness

- **No automated test runner exists** (house law "no test code in this environment" — documented, with the live-protocol substitute). This is the structural reason the 753d115 regression could be committed silently: nothing executable fails on a broken import or a shadowing file.
- `bunx tsc --noEmit` → **exit 1, 20 errors** (15 missing-dependency from template scaffold + 5 broken-symbol from journey orphans). All 20 files provably absent at `b34d5b8` (`git ls-tree`) → **"tsc 0" was true at every documented round close; 753d115 alone broke HEAD.**
- `bunx eslint .` → exit 0 — but the config disables ~30 rules incl. `no-unused-vars`/`no-redeclare`, so the gate is structurally blind to the entire zombie class. Zero in-code `eslint-disable` cheats.
- `next build` **deterministically fails at HEAD** (no `ignoreBuildErrors` — verified removed at H2 `ae9357f`). CI (`.github/workflows/ci.yml`) is well-formed (static + database gates) but red on HEAD's code.
- Worklog gate entries (tsc 0/lint 0 per round) all located and quoted (:4492/:4709/:4718/:4744/:4760/:4767) — accurate for their times; the golden-path E2E entry (:4706) exists with its 32-screenshot receipt corpus.
- Dependency cleanup claim verified real (a3a2c27: 15 deps removed, 19 files deleted) — and then partially undone by the zombie wave re-adding source that needs the removed packages.

---

## 4. Overall engineering assessment

**As a codebase at `b34d5b8`:** unusually disciplined. Clean layering with zero circular dependencies (Tarjan-verified over the full import graph), 0 `any`/`as any`/`@ts-ignore`, uniform `ApiError`/`fail()` error contract across 73/74 routes, exhaustive server-side authorization, honest documentation with rejected-recommendation records and honest-limits sections. The remediation waves genuinely improved maintainability (the dedup extractions are imported where claimed; the dead-code purges really happened with receipts).

**As the deliverable at HEAD `753d115`:** below the project's own verified baseline. Build broken, text layer broken, one dead parallel implementation for four UI concepts (toast/sidebar/placeholder/stage-chip), an unguarded scaffold endpoint, and a governance hole (an undocumented commit above the append-only log).

**As a running system in this environment:** unreachable beyond the login surface. The login surface itself is genuinely good — fully translated in FR/AR/EN (all `auth.*` keys are in the zombie), RTL machinery live-verified today (dir=rtl, Arabic fonts, RTL-aware layout), zero horizontal overflow at 390/375 (scrollWidth EXACTLY equal to viewport), clean persona-grid unmounting with the empty DB, and graceful failed-login toast feedback.

**The honest causal picture:** the previous status audit (05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_PHASE_COMPLETION_STATUS.md, baseline b34d5b8) concluded "code IMPLEMENTED, environment DEGRADED." That conclusion was accurate then. Since that audit, two things changed: the environment reset again (DB now empty rather than stale — a *different* degraded state), and **someone committed the environment's debris into the repository** (753d115), converting "environment-only degradation" into "codebase degradation." The prior audit's verdict "repository YES · environment NOT YET" is now "repository NOT YET (one sweep away) · environment NOT YET (one runbook away)."

---

## 5. Critical risks

| # | Risk | Severity | Exposure |
|---|---|---|---|
| 1 | Build failure at HEAD (20 tsc errors; `next build` and CI both red) | **P0 (delivery-blocking)** | Any consumer of the current commit |
| 2 | i18n zombie shadowing — 46% dictionary loss, 849 render sites raw, a11y labels raw | **P1** | All 12 views' text layer at HEAD |
| 3 | Dev-server global API poisoning via broken `/api/journey/export` (+ path disclosure in dev HTML) | **P1** | Every API request after first trigger of the route |
| 4 | Empty live DB + missing `_prisma_migrations` + missing D12 indexes → no runtime verification possible; `migrate deploy` would fail on this file | **P1 (environment)** | Runtime acceptance, D12 invariant enforcement |
| 5 | Git history contains a dead session secret + demo DB (~10 commits); purge plan exists but unexecuted; **escalates to P0 if a remote is added first** | P2 (contained) | Repository provenance |
| 6 | No automated tests (house law) — the enabler of the silent 753d115 regression; every future regression of this class will also be silent | P2 (systemic) | Whole program |
| 7 | PG chain missing the per-opportunity live-hold index while schema.postgres.prisma claims parity | P2 | Future Supabase deployment |
| 8 | Reservation-lifecycle audit-trail gaps (ND-1/ND-2) | P2 | Money-path audit completeness |
| 9 | `ASAS_SESSION_SECRET` unset today (ephemeral fallback active — sessions die on restart) | P2 (environment) | Session durability |

---

## 6. Evidence limitations

1. **Authenticated behavior is BLOCKED** — the empty DB makes login impossible without executing the recovery runbook (remediation, outside the audit mandate). All "verified at commit time" runtime claims rest on preserved receipts (screenshot corpora, probe logs, worklog entries) whose provenance this audit checked (commits, file lists, plausibility) but whose runtime behavior could not be re-executed.
2. **PostgreSQL/Supabase RLS is structurally verified only** — 150 policy statements read and semantically assessed (default-deny org-claim pattern quoted on 5 tables), but no PG instance exists anywhere in the environment. Classified per Rule 5: RLS existence ≠ RLS correctness → NOT VERIFIED at runtime (known, honestly documented by the project itself).
3. **Production build never executed in any environment** (house law) — build failure at HEAD is deterministically inferred from tsc + the absence of `ignoreBuildErrors`, not from an actual failed build run.
4. Screenshots certify appearance, not function (Rule 6) — the corpus was verified as genuine artifacts of their times, and the code those times captured was verified present; functional claims additionally rest on the probe logs and worklog gate entries.
5. The audit deliberately did not repair, reseed, restart, or sweep — so every environment-caused symptom documented here remains observable in place.

---

## 7. Final recommendation

# REJECT — ADDITIONAL ENGINEERING REQUIRED

**Justification:** the acceptance question is answered against the deliverable as it stands, and HEAD fails its own project's binding laws: it does not build, it does not render its text layer, its API surface self-degrades, and its provenance is undocumented. None of these are attributable to the Phase 0/1/2 engineering (which is real and verified), and none are expensive to repair — but they must be repaired and re-verified before acceptance.

**The required engineering (precisely scoped, in order):**
1. **Resurrection sweep at HEAD** (the project's own law, AGENTS.md:17): content-hash purity proof → `git rm` the 753d115 zombie set (the 5 resurrected files + 6 journey orphans + 18 template files + junk routes; disposition the 40 orphan screenshots) → commit with a real message → worklog entry documenting 753d115 and the sweep.
2. **R13 recovery runbook** (AGENTS.md): fresh DB → `prisma migrate deploy` (17/17) → `bun run db:seed` → verify census + both D12 indexes in `sqlite_master` → re-append `ASAS_SESSION_SECRET` → restart.
3. **Re-verification:** tsc 0 / lint 0 / unauthenticated matrix back to 401-JSON / browser sweep (12 views × FR/AR/EN × desktop/mobile) / the standing 333-probe matrix / golden-path E2E.
4. **Then the P2 backlog:** PG-chain per-opportunity index (or comment fix), ND-1/ND-2 tx-law fixes, handoff-doc staleness (511→606), scrypt explicit params, `X-Powered-By` off.

**What would upgrade the verdict to ACCEPT WITH CONDITIONS:** items 1–3 executed with receipts (the engineering base at `b34d5b8` already merits it). **What would qualify for CONTROLLED PRODUCTION RELEASE later:** the owner-gated items the project itself registers (DEMO_MODE=0 plumbing, TLS/supervisor/monitoring, git-history purge before any remote, PG RLS runtime verification on the owner's Supabase project).

---

*Audit boundary honored: zero implementation writes; zero schema/DB mutations (read-only SQLite probes only); zero git operations beyond read-only inspection; zero pushes/deploys; user modifications preserved (working tree untouched — it was already clean); secrets examined by presence/hash only, never printed. Files created by this audit: the five deliverable documents (A–E) in 05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ and 5 screenshots + 1 captured HTTP response under evidence/independent-audit/. The mandated 15-minute webDevReview cron job was deliberately NOT created: this session is an audit under an explicit "do not continue development" directive, and a recurring autonomous development job would contradict it.*
