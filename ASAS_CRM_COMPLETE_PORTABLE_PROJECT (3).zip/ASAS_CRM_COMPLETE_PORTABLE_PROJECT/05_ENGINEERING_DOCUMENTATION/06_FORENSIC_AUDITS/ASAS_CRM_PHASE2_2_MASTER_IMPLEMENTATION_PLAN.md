# ASAS CRM — PHASE 2.2 MASTER IMPLEMENTATION PLAN

**Date:** 2026-11-03 · **Principal:** Principal Software Architect & Implementation Lead
**Baseline:** HEAD `0f4299c` (clean tree), dev server verified live on :3000, DB seeded
(8 users / 43 leads / 20 contacts / 21 opportunities / 23 visits / 183 activities), VLM UX
review of the 4 core surfaces captured in `evidence/phase2_2/baseline-*.png`.

## 1. MISSION

Transform ASAS CRM from a well-architected but table-centric app into a **relationship
workspace**: every core page must answer "what should I do next, for whom" — not just
"display data". Six dimensions (Architecture, Database, Security, CRM Logic, UI/UX,
Performance) with proof, not prose.

## 2. BASELINE FINDINGS (verified this session)

| Surface | State | Key gap |
|---|---|---|
| Dashboard | Role-scoped (own/org) attention strip exists | Attention items and KPI cards are not wired to direct action/navigation; agent vs manager framing is similar |
| Journey (Parcours) | Guided lifecycle worklist, 8-step funnel | Sits between Leads and Pipeline without a distinct "customer" identity |
| Leads | Full table + filters + bulk + j/k nav | No quick actions on rows (call/WhatsApp/qualify/assign), no rotting signal, no intake pool emphasis |
| Pipeline | Kanban + value + aging chips | Cards lack stage-progress position, no quick stage advance, column stats minimal |
| **Customers** | **MISSING PRODUCT SURFACE** — Contact model exists (20 rows, 1:1 with converted Lead) but **no view, no API route** | The #1 user ask: "صفحة العملاء ليست مجرد جدول؛ بل مساحة لإدارة العلاقة التجارية" |
| Auth/RBAC | Server-side visibility scopes (leadScope/taskScope/…) everywhere | Extend the same law to the new customers surface — no frontend-only enforcement |

## 3. WORK REGISTER

| Task ID | Owner | Domain | Scope (owned files) | Acceptance |
|---|---|---|---|---|
| 2-a | Principal | CRM Logic + UI/UX + Database | `i18n/domains/customers.ts`, `api/customers/route.ts`, `views/customers-view.tsx` + `views/customers/*`, `sidebar-nav.tsx`, `store.ts` (View type) | Customers workspace live: health-signal list (journey stage, open opps value, last-interaction rot, next action), opens the existing 360 drawer; visibility-scoped; negative-tested |
| 2-b | Agent 2 | UI/UX + CRM Logic | `views/leads-view.tsx`, `views/leads/*`, `i18n/domains/leads.ts` | Row quick actions (WhatsApp/call), rotting colorization on last-contact, MANAGER+ inline assign on unassigned pool, intake KPI mini-strip; lint+tsc clean |
| 2-c | Agent 3 | UI/UX + CRM Logic | `views/pipeline-view.tsx`, `views/pipeline/*`, `i18n/domains/pipeline.ts` | Card stage-position badge, column headers with count+value+avg aging, quick advance action on card, closed-card compact mode; lint+tsc clean |
| 2-d | Agent 4 | UI/UX | `views/dashboard-view.tsx`, `views/dashboard/*`, `i18n/domains/dashboard.ts` | Attention items navigate to filtered surfaces; KPI cards navigate; agent "My Day" hero vs manager "Team overview" captions; lint+tsc clean |
| 5 | Principal | Integration | whole tree | `bun run lint` + `tsc --noEmit` + vitest suite green |
| 6 | Principal | Security | `api/customers/*` | curl negative tests: cross-agent 403/404, unauthenticated 401; positive: manager sees all |
| 7 | Principal | QA | browser | 1440/1280/768/390 + AR RTL; core click-throughs; console clean; evidence PNGs |
| 8 | Principal | Delivery | `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_PHASE2_2_*.md` ×9 | Documents describe implemented+verified state only |

## 4. EXECUTION LAW

- One primary owner per file set; shared files (store.ts, sidebar-nav.tsx) touched ONLY by the Principal (Task 2-a) — subagents must not edit them.
- i18n: every new user-facing string in all three dictionaries (fr/en/ar) of the owning domain file. No hardcoded strings.
- No @ts-ignore, no any, no suppressed tests. Server-side authorization on every new route.
- Reuse over creation: the Customer 360 opens the EXISTING lead drawer (journey rail + tabs) — no duplicate drawer implementation.
