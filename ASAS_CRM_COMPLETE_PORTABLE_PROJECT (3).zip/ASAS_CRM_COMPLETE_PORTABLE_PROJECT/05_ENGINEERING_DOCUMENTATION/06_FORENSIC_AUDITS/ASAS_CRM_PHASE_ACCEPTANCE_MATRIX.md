# ASAS CRM — Phase Acceptance Matrix

**Companion to:** `ASAS_CRM_INDEPENDENT_AUDIT_REPORT.md` (same audit session, 2026-11-02).
**Method:** every roadmap task (ASAS_CRM_REMEDIATION_ROADMAP.md + PHASE2 execution log + R15 addendum) was independently re-verified against the codebase by the six-auditor team. Verdicts use the mandate's taxonomy (PASS / PARTIAL PASS / FAIL / NOT IMPLEMENTED / NOT VERIFIED / BLOCKED / NOT APPLICABLE) — IMPLEMENTED is never used as a substitute for PASS. Dual reading is applied where the honest answer requires it: **at the last documented engineering commit `b34d5b8`** vs **at HEAD `753d115`** (the delivery state).

---

## 1. Phase-level acceptance

| Phase | Claimed | Independent verdict at `b34d5b8` | Independent verdict at HEAD `753d115` (delivery state) | Rationale |
|---|---|---|---|---|
| **Phase 0** — discovery & baseline (11 items) | Done | **PASS** (11/11 re-verified from surviving artifacts: git history, worklog, MASTER_ENGINEERING_STATE, AGENTS.md, docs/ tree) | **PASS** (unchanged — no Phase-0 artifact touched by 753d115) | Evidence intact and re-inspected this audit |
| **Phase 1** — six-workstream audit + 9 deliverables | Done | **PASS** (6/6 workstreams + 9/9 deliverables with substantive content; findings cross-checked against real code; spot-verifications passed) | **PASS** (documents unchanged; one prior status-audit doc set now sits alongside them) | The audit documents remain accurate descriptions of their baseline `a5dac11`–`b34d5b8` era |
| **Phase 2** — remediation waves 1–7 | "Gates green, tsc 0, lint 0, zero console errors" at R15 close | **PASS as executed** (code verified present by six auditors; at-time runtime receipts genuine and provenanced) — with honestly-documented limits (PG RLS untested, no production build, no automated tests) | **FAIL as the deliverable** — HEAD does not build (20 tsc errors), text layer broken (46% keys lost), API surface self-poisoning, governance hole | The engineering is real; the delivery state is not acceptable. The failure is attributable to the undocumented 753d115 commit, not to any wave's work |

---

## 2. Wave-level acceptance (Phase 2, seven-wave taxonomy)

| Wave | Scope | Verdict at `b34d5b8` | Verdict at HEAD | Key evidence |
|---|---|---|---|---|
| **Wave 1** — Engineering foundation | Layering, type safety, error handling, guards | **PASS** (6/6 areas) | **PARTIAL PASS** — layering/guards/error-contract intact at HEAD (verified: 70/74 requireUser, 0 cycles, 73/74 fail()); but HEAD adds the unguarded junk `GET /api` + template scaffold polluting type safety | Auditor A §1/§5/§6; tsc 20 errors at HEAD |
| **Wave 2** — Database & data integrity | Schema, migrations, constraints, indexes, census | **PASS in repo artifacts** (17-migration chain verbatim-verified incl. D12; PG rendering 26/65; CHECK vocabularies; seed census statically re-counted + validator re-run PASS) | **FAIL on the live DB** (empty; no `_prisma_migrations`; D12 indexes absent; WAL off — all environment-class, repairable by runbook) + **new PG-chain gap ND-B3** | Auditor B §2/§3/§5 |
| **Wave 3** — Security & privacy | AuthN, authZ, RBAC, RLS-equivalent, isolation | **PASS** (10/10 areas independently verified; live CSRF/401 matrix/headers green; zero P0/P1 security findings) | **PASS (code) / PARTIAL (runtime)** — all gates server-side and intact; live unauthenticated matrix held in the healthy window; authenticated tests BLOCKED (empty DB); dev-mode poisoning degrades the 401 JSON contract app-wide | Auditor C; T-2/T-3/T-6 |
| **Wave 4** — CRM business logic | D1–D14, lifecycle matrices, closure gate, money path | **PASS** (12/12 areas with file:line; closure gate exhaustively enumerated on all 3 CLOSED_WON write sites) | **PASS (code, verified at HEAD)** — none of the logic files touched by 753d115; 2 new MEDIUM audit-trail defects found (ND-B1/B2) + 4 LOW | Auditor E |
| **Wave 5** — UI/UX engineering redesign | Design system, 12 views, RTL, a11y, responsive | **PASS as engineered** (61 oklch tokens; 7-tier type scale; row-nesting fix; 44px floors; mini-map; TrendChip+wrap fix — all verified at HEAD in code) | **FAIL in the text layer at HEAD** (849/2,055 render sites raw via zombie; 3 nav labels; 3 titles; raw aria-labels) — structure intact, words broken | Auditor D |
| **Wave 6** — Performance & code cleanup | N+1, pagination, dynamic imports, dead code, deps | **PASS at `b34d5b8`** (dynamic imports verified today; cache headers verified today; deps cleanup commit verified) | **FAIL at HEAD** — the zombie wave re-adds ~30 dead files + 4 dead parallel implementations + source needing removed packages; dead-code law violated | Auditor A §4; Auditor F §6 |
| **Wave 7** — Integration & regression | Gates, matrix, browser sweeps, delivery | **PASS at time** (receipts preserved and provenanced: worklog :4706/:4709/:4767; 1,299-PNG corpus; 333-probe matrix) | **FAIL as re-verification** — tsc red, console red, runtime unreachable; **BLOCKED** for all authenticated re-verification (empty DB) | Auditor F; T-1/T-5/T-6 |

---

## 3. Task-by-task acceptance review (the roadmap inventory)

### Wave 1 — Foundation

| Task | Verdict | Basis |
|---|---|---|
| W1.1 persistent `ASAS_SESSION_SECRET` | **PARTIAL PASS** | Code + documented at time; `.env` today = DATABASE_URL only → secret gone (env regression); ephemeral fallback active |
| W1.2 `@radix-ui/react-direction` dep | **PASS** | package.json + 1 live importer verified |
| W1.3 security headers | **PASS** | Live-verified today: nosniff + Referrer-Policy on responses |
| W1.4 cookie `secure` prod-only | **PASS** | `login/route.ts:37` code-verified |
| W1.5 absolute 7d expiry | **PASS** | `session.ts:38,64` — enforced in `verifySessionCookie` on every request |
| W1.6 `SAV_OPEN_STATUSES` + adoption | **PASS** | `constants.ts:510/517`; both SAV routes import |
| W1.7 migration baseline + snapshot | **PARTIAL PASS** | Chain + lockfile in repo (verified); live DB has NO `_prisma_migrations` (env); backups wiped |
| W1.8 `@@index([orgId, incentiveStatus])` | **PASS** | `schema.prisma:672` + index PRESENT in live DB (Auditor B) |

### Wave 2 — Business-logic integrity

| Task | Verdict | Basis |
|---|---|---|
| W2.1 (D1) revive guard + full reset | **PASS** | `reservations/route.ts:248-259` (3 dependents counted in-tx) + `:294-318` (complete field list verified vs schema) |
| W2.2 (D2) apartment counts CLOSURE_REQUESTED | **PASS** | `apartments/[id]:63-79` |
| W2.3 (D3) CLOSED_LOST blocked by live hold | **PASS** | `opportunities/[id]:175-188` |
| W2.4 (D4) booking stage precondition | **PASS** | `reservations/route.ts:196-203` |
| W2.5 (D7) validate_closure stamps stageChangedAt | **PARTIAL PASS** | Stamp works (`reservation-lifecycle.ts:213`); dedicated audit row unreachable (ND-B1) |
| W2.6 (D8) reactivate single-tx | **PASS** | `reactivate/route.ts:39-69` — tx boundary quoted |
| W2.7 (D10) guarded release | **PASS** | `reservation-lifecycle.ts:333-336` + sweeper parity `expiry.ts:47-50` |
| W2.8 (D5) reassign cascades opp ownership | **PASS** | `leads/[id]:335-338` via `OPP_CLOSED_STAGES` |
| W2.9 (PERF-P1) reservations bounded | **PASS** | page/pageSize honored (default 200/max 500 — documented design) |

### Wave 3 — Architecture dedup + perf

| Task | Verdict | Basis |
|---|---|---|
| W3.1 (T1) visit-facets extraction | **PASS** | `visit-facets.ts:26/43/64` imported by dashboard:27 + visits:24 (KPI≡list structural) |
| W3.2 (T3) visits/tasks helpers | **PASS** | Both modules + importers verified |
| W3.3 (T4) findOpportunity helper | **PARTIAL PASS** | Helper exists + used; `opportunityInclude` still duplicated in 2 routes (ND-B10) |
| W3.4 SAV consts adoption | **PASS** | (= W1.6; verified) |
| W3.5 Cache-Control headers | **PASS** | Verified TODAY: `dashboard/route.ts:627` + `analytics/route.ts:290` = `private, max-age=30` |
| W3.6 paginate SAV/installments | **PARTIAL PASS** | Bounded (`take:500` documented design), not paginated — documented deviation |
| W3.7 pageSize 200→50 | **NOT APPLICABLE** | Skipped with evidence at MASTER round (UI does not pass explicit pageSize — verified) |
| W3.8 copilot timeout + 504 | **PASS** | `copilot/route.ts:38,347` — Promise.race timer, 504 mapping |

### Wave 4 — UI/UX engineering

| Task | Verdict | Basis |
|---|---|---|
| W4.1 leads row nesting a11y | **PASS** | `lead-row.tsx:91-109` verified at HEAD |
| W4.2 dark contrast tokens | **PASS** | Token blocks verified; axe receipts at time (cannot re-run axe — env) |
| W4.3 "Trouver des biens" feedback | **PARTIAL PASS** | Shipped at time (receipt); not re-verifiable today (env) |
| W4.4 finance col rename | **PARTIAL PASS** | Shipped at time; finance surface 20/20 keys raw at HEAD (zombie — not a rename defect) |
| W4.5 currency unification | **PARTIAL PASS** | Shipped at time (receipt); not re-checkable today |
| W4.6 persona toast dedupe | **PARTIAL PASS** | Same class |
| W4.7 date picker FR locale | **PARTIAL PASS** | Same class |
| W4.8 per-view document.title | **PASS** | `shell.tsx:112-115` ×12 views verified at HEAD (3 titles raw via zombie — ND-A2) |
| W4.9 decision-card clamp + tooltip | **PARTIAL PASS** | Shipped at time |
| W4.10 (D6) CLOSED_WON absent from create dialog | **PASS** | Dialog sources `OPPORTUNITY_STAGES` from server constants; matrix has no CLOSED_WON row (Auditor E §7) |
| W4.11 kanban mini-map | **PASS** | `pipeline-view.tsx:419-449` verified at HEAD |
| W4.12 touch targets ≥44px | **PASS** | `.crm-hit` floors (globals.css:612-651) + `max-md:size-11` sites verified |

### Wave 5 — Central integration + regression

| Task | Verdict | Basis |
|---|---|---|
| W5 integration + E2E + screenshots | **PASS at time / BLOCKED as re-verification** | Receipts genuine (32-PNG qa-final; worklog :4706); today: tsc red, DB empty, poisoning active |

### PHASE 2 controlled round (2026-11-02 00:12 commit `0d36f3e`)

| Task | Verdict | Basis |
|---|---|---|
| W2.1 D12 migration (raw SQL partial uniques) | **PARTIAL PASS** | Migration #17 verbatim-verified in repo (both indexes); **live DB lacks them** (env — R-E2); violation-probe receipts at time |
| W2.2 demo-mode production fail-fast | **PARTIAL PASS** | Code-verified (`session.ts:115-117`, login route); runtime-verification impossible (NODE_ENV=production) — honestly documented then and now |
| W2.3 SECURITY.md mechanism doc | **PASS** | Read; accurate |
| W3.1 targets month-copy | **PARTIAL PASS** | Commit + code verified; byte-correct receipt at time; runtime re-verification BLOCKED (empty DB) |
| W3.2 PDF first-page thumbnails | **PARTIAL PASS** | Commit verified (`thumb/route.ts` + doc-thumb.tsx + `Cache-Control: private,max-age=86400`); integration-fix history consistent; runtime BLOCKED |
| W3.3 type-scale polish batch | **PASS** | 6 conversion sites verified in code; survey verdicts documented |
| W4 central integration fixes ×2 | **PASS at time** | Both fixes located in code (`document-row.tsx` PREVIEWABLE_MIME gate; one-retry thumb fallback) |
| W5 browser regression (13 screenshots) | **PASS at time / BLOCKED now** | Corpus verified; runtime unreachable |

### R15 round (commit `b34d5b8`)

| Task | Verdict | Basis |
|---|---|---|
| Dashboard KPI trend chips | **PASS (code) / PARTIAL (runtime)** | `kpi-card.tsx:83-105` + flex-wrap fix `:133-142` verified; `analytics.kpi.vsPrev` aria key raw at HEAD (ND-A2) |
| Stage-constant dedup (8 sites) | **PARTIAL PASS** | 6 server sites adopted; 2 client survivors (ND-B8) |
| a11y backport (analytics aria) | **PASS** | Verified in code |
| 4-indicator verification battery | **PASS at time / NOT VERIFIED now** | Worklog :4761-4767 receipts; live DB claims (17/17, D12 present, WAL) REFUTED for the current file (env reset) |

### Deferred list (roadmap "Deferred" section)

| Task | Verdict | Basis |
|---|---|---|
| Vitest suites | **NOT APPLICABLE** | REJECTED with documented justification (house law) — respected by every round; risk formally registered as ND-A1's enabler |
| D9 sweeper scheduling | **PASS — LIVE TODAY** | dev.log shows the 60s expiry-sweeper polling loop running (first-hand runtime evidence) |
| D12 idempotency twin guard | **PASS** | `activities/route.ts:24,70-92,151` (5s in-tx, `deduplicated:true`) |
| D13 metric definitions | **PASS** | `lib/metrics.ts` + adoption in analytics:12 / dashboard:24 verified |
| visit-ladder dedup | **PASS** | `visit-ladder.ts:33-90` reverse-index over VISIT_TRANSITIONS |
| WAL mode ON | **FAIL (current state)** | `journal_mode=delete` — was true at time (snapshot receipt); env regression (R-E5) |
| deps cleanup (15+19) | **PASS at `b34d5b8` / FAIL at HEAD** | Commit `a3a2c27` verified real; zombie wave re-adds dependents of removed packages (ND-A1) |
| dynamic-import charts | **PASS** | 4 `dynamic()` sites verified TODAY (dashboard-view:52; analytics-view:44/48/52) |
| analytics groupBy | **PASS at time** | Verified already-at-target at MASTER; no churn (documented) |
| trigram search (PG) | **NOT APPLICABLE** | Deferred by design [PG deployment] |

---

## 4. Verdict counts (the full assessed inventory: 42 roadmap units + 12 PHASE2/R15 units + 10 deferred units = 64)

| Verdict | Count | Decomposition |
|---|---|---|
| **PASS** | **33** | 24 verified at HEAD in code/live today + 9 pass-at-time with intact code (integration fixes, at-time receipts, SECURITY.md, groupBy, polish) |
| **PARTIAL PASS** | **18** | 12 runtime-re-verification BLOCKED by environment (golden path, targets-copy, thumbnails, browser sweeps, indicator battery, W4.3-W4.9 residuals) + 6 with genuine code-level gaps (W1.1 env, W1.7 migrations table, W2.5 ND-B1, W3.3 ND-B10, W3.6 bounded-not-paginated, R15 stage-dedup ND-B8, trend-chip runtime) |
| **FAIL** | **4** | WAL (current state) · deps-cleanup (HEAD state) · 4-indicator battery's live-DB claims (current state) · [phase-level: Phase-2-as-deliverable at HEAD] — all four are either env-class or 753d115-attributable, none are wave-engineering failures |
| **NOT IMPLEMENTED** | **0** | — |
| **NOT VERIFIED** | **0** (as standalone) | Covered inside PARTIAL PASS rows (the at-time-verified-but-env-blocked class); the mandate's Rule 7 is honored by not counting them as PASS |
| **BLOCKED** | **1** (Wave-5-as-reverification, counted within PARTIAL above; standalone count: authenticated test classes per Acceptance Test Results T-8) | Empty-DB class |
| **NOT APPLICABLE** | **3** | W3.7 (skipped with evidence), Vitest (rejected with justification), trigram (deferred by design) |

**Honest net position:** of the 64 assessed units, **33 PASS outright**, **18 PARTIAL** (of which ~12 are environment-blocked re-verification with intact code, 6 carry small real gaps), **4 FAIL on current-state grounds** (0 on engineering-execution grounds), **0 NOT IMPLEMENTED**, **3 N/A**. At the last documented engineering commit `b34d5b8`, the equivalent tally would be 51 PASS / 9 PARTIAL / 0 FAIL / 3 N-A with the same environment caveats — which is why the engineering is judged real while the delivery state is judged unacceptable.
