# ASAS CRM — Quality Audit (Agent F)

## Gates (actually run): typecheck ✅ exit 0 · eslint ✅ exit 0, 0 warnings · **tests: NONE EXIST** (0 test files, no framework) · build: disallowed in env. Hygiene: 0 eslint-disable, 0 @ts-ignore, 6 TODOs, 314 source files / 65.5k LOC / 68 routes / 172 'use client'.

## Test coverage: manual protocol only (`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/TEST_STRATEGY.md` 7-gate) + CI static gates (`ci.yml`: install+generate+lint+typecheck, DB gate on throwaway db) + 78 QA folders / 1,156 screenshots. **Critical missing (prioritized)**: auth/session probes; visibility.ts scope matrices; 4 transition-law tables (pure, zero-DB, ideal first Vitest targets); transactional integrity (double-booking 409s, import undo, merge); zod CRUD; role-aware DTO stripping; pure libs (phone/csv/matching/expiry).

## Performance
**N+1: CLEAN — zero `await db.` in loops across 68 routes** (batching via updateMany/createMany/Map-joins throughout).
| ID | Sev | Finding | Evidence |
|---|---|---|---|
| P-1 | **P1** | `/api/reservations` unbounded, heaviest include | reservations/route.ts:113-117 |
| P-2 | P2 | zero caching on dashboard (~30 q/GET) + analytics (~20 q/GET) | session.ts:109-111 ok() |
| P-3 | P2 | analytics in-memory aggregation over unbounded rows | analytics/route.ts:61-64,136-143,204-213 |
| P-4 | P2 | finance overview + installments unbounded (full ledger + nested payments) | finance routes |
| P-5 | P2 | `/api/sav` unbounded | sav/route.ts:119 |
| P-6 | P2 | recharts+framer-motion (23 files) in single-route SPA bundle; **0 dynamic imports** | rg verified |
| P-7 | P3 | dashboard 5,000-row day bucketing (capped, documented) | dashboard/route.ts:346-352 |
| P-8 | P3 | visits/opps default pageSize=200 | visits:48, opportunities:35 |
| P-9 | P3 | copilot LLM no timeout | copilot/route.ts:315-325 |
| P-10 | P3 | todayTasks/todayVisits no take | dashboard:229-245 |

Pagination scorecard: leads/tasks/activities/audit/notifications/visits/opps/search/export/journey/duplicates ✅ · **reservations/finance/sav ❌**.

## Dependencies
- **Phantom dep P2: `@radix-ui/react-direction` imported (providers.tsx:10) but NOT in package.json** — works via hoisting only. FIX NOW.
- Unused (grep-verified, 0 app importers beyond dead wrappers): embla-carousel-react, input-otp, react-resizable-panels, vaul, tailwindcss-animate, @radix-ui/{accordion,aspect-ratio,menubar,navigation-menu,toggle,tooltip,radio-group,collapsible,hover-card,context-menu} + dead toast stack (ui/toast+toaster+use-toast+@radix-ui/react-toast; sonner is live) + ui/chart dead. **~16 removable deps / ~15 dead ui files.**
- Used & healthy: react-query 69, lucide 134, sonner 48, zod 42, dnd-kit, RHF, cmdk, next-themes, zustand, react-day-picker, z-ai-web-dev-sdk, prisma. No duplicate majors; all current-gen.

## Dev server health (dev.log full read): no compile errors, no stack traces, no 5xx; EADDRINUSE = stale restart attempt (server is the live one); HEAD /downloads/index.html 404; 2× 401 = QA probes; warm GET / 20-48ms; cold compile 19.8s (dev-only); warnings: allowedDevOrigins not configured (preview host), ephemeral session secret. Live probe: GET / → 200 in 48ms.

## DevOps register: R-1 P1(prod) ephemeral secret → persistent .env NOW · R-2 P2 zero error monitoring → defer w/ doc · R-3 P2 **db/backups/ never created** → snapshot NOW + before waves · R-4 ✅ db:push/reset never automatic · R-5 ✅ dual schemas byte-identical · R-6 P2 phantom dep → NOW · R-7 P3 next.config minimal (strictMode off, no allowedDevOrigins, no headers) · R-8 P3 Caddy plain HTTP (sandbox-appropriate) · R-9 ✅ env hygiene, no committed secrets.

## Adopted plan: Sprint-1 correctness/safety (secret, reservations pagination, phantom dep, snapshot+baseline) · Sprint-2 perf/hygiene (30-60s cache dashboard/analytics, groupBy analytics, paginate finance/sav, dynamic-import charts, deps cleanup, snapshots schedule, CI drift check) · Sprint-3 hardening (allowedDevOrigins, strictMode, pageSize 50, copilot timeout, headers, Playwright smoke).
