# ASAS CRM — Phase 2 Implementation Plan

**Mission:** Transform the validated Phase 1 audit findings into measurable engineering improvements (the controlled implementation phase).
**Date opened:** 2026-11-02 · **Baseline:** git `de787ec` (main, clean tree) · typecheck ✅ 0 · eslint ✅ 0 · dev server healthy :3000 · cron register: 15-min webDevReview job ABSENT again (5th documented reap — recreate at close).

---

## 1. Phase 1 review & independent validation (FIRST ACTION — executed)

All nine Phase 1 deliverables were located and read (`05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_*.md`, `AGENTS.md`, git history, worklog, schema + migration chain). Each critical finding was re-verified against the current implementation:

| Phase 1 finding | Validation verdict | Current state |
|---|---|---|
| SEC-V01 demo-mode takeover (P0-if-deployed) | **Confirmed fixed-as-designed**: quick-login fail-closes 403 `DEMO_MODE_DISABLED` when `ASAS_DEMO_MODE=0` (login route, verified in code); sandbox demo is intentional product surface. Residual = **production fail-fast missing** → adopted as P2-W2.2 | Partially open |
| DOM-D1 reservation revival money-transfer (P1) | **Confirmed fixed**: `RESERVATION_HAS_DEPENDENTS` 409 guard + full economics/closure reset verified in `api/reservations/route.ts:241-319` | Closed |
| ARCH-T1 KPI↔facet drift (P1) | **Confirmed fixed**: `lib/server/visit-facets.ts` exists, adopted by dashboard + visits | Closed |
| PERF-P1 unbounded reservations (P1) | **Confirmed fixed**: pagination (default 200/max 500) verified `route.ts:93-162` | Closed |
| DB-1 unrecorded migrations (P1) | **Confirmed fixed**: chain authoritative, 16 applied (R14 recovery ran `migrate deploy 16/16`) | Closed |
| SEC-V06/F-R1 ephemeral session secret (P1) | **Confirmed fixed**: persistent `.env` secret | Closed |
| E2E-FINAL 9 latent defects (2×P1) | **Confirmed fixed**: all guards present in code (`OPPORTUNITY_NOT_BOOKABLE`, `OPPORTUNITY_ALREADY_BOOKED`, visit auto-link, explicitTransition recorded-state requirement) | Closed |
| D12 concurrent twin race | **Partially closed**: 5s in-tx twin guard covers the sequential double-click; **DB partial unique index remains open** (the roadmap's own documented durable fix) → adopted as P2-W2.1 | Open |
| UX/UI P1 a11y + contrast | Confirmed fixed (MASTER round, live axe/tree evidence) | Closed |
| Backlog: month-copy for sales targets | Valid, unimplemented, real manager productivity win → P2-W3.1 | Open |
| Backlog: PDF thumbnails (first-page raster) | Valid, unimplemented; `renderPdfPages()` infra already exists → P2-W3.2 | Open |
| §38 incentive-status chip coherence + semantic type-scale | Valid P3 polish → P2-W3.3 | Open |

### Rejected / modified recommendations (with reasons)

1. **Vitest automated suites** (Quality Audit's top gap) — **REJECTED for this environment**: house law "no test code in this environment" (system policy); the golden-path browser protocol + the 333-probe standing matrix + CI static gates ARE the test strategy. Not silently dropped — this is the documented decision.
2. **Production build verification** — disallowed in this sandbox (`bun run build` forbidden; CI static gates cover lint+typecheck only).
3. **New-row-per-booking revival flow** — **kept deferred**: the 409 guard + manual handling is the safe shipped state. Wave 2's partial unique indexes remove the future schema blocker, but changing the row-reuse pattern mid-flight adds regression risk for zero user-visible benefit today. Durable end-state direction stays documented.
4. **PostgreSQL RLS migration** — N/A: this is the SQLite platform; the D-021 scope law + role-aware DTO stripping are the enforced equivalents (all previously live-verified, negative probes included).
5. **Trigram search** — PG-variant only, rejected on SQLite (documented since Phase 1).

## 2. Final implementation sequence (dependency-aware)

### Wave 1 — Foundation (SERIAL, Principal) — status ✅
- W1.1 Read all Phase 1 deliverables + independent validation (table above).
- W1.2 DB snapshot baseline + census (sha256 recorded).
- W1.3 Browser smoke baseline (login + views render, console clean) — inherited from R14 close (same commit, clean tree); re-verified at Wave 5 regression.
- W1.4 This plan document.

### Wave 2 — Integrity hardening (SERIAL, Principal — DB changes centrally coordinated)
| ID | Task | Files | Acceptance |
|---|---|---|---|
| W2.1 | **D12 race closure**: partial unique indexes — one live hold per apartment, one live hold per opportunity — via raw-SQL migration #17 (`CREATE UNIQUE INDEX … WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')`). Pre-check current data for violations (expected 0); probe constraint firing on a **DB copy** (never the live DB); apply via `migrate deploy`; live booking regression. The route's existing P2002→`ALREADY_RESERVED` mapping makes this a drop-in backstop. | `prisma/migrations/20261102*_phase2_d12_live_hold_unique/migration.sql` (+ schema.prisma comment) | index present; violation INSERT rejected on copy; `migrate status` clean; booking E2E green |
| W2.2 | **Production demo-mode fail-fast**: quick-login refuses when `NODE_ENV=production` AND demo mode still on (500-class `DEMO_MODE_PRODUCTION_MISCONFIG`); one-time boot warning in production. Sandbox untouched (NODE_ENV=development). | `api/auth/login/route.ts`, `lib/server/session.ts` | code paths guarded; sandbox demo unaffected |
| W2.3 | SECURITY.md production checklist updated to reference the fail-fast. | `SECURITY.md` | doc reflects mechanism |

### Wave 3 — Feature wave (PARALLEL — disjoint file ownership)
| ID | Agent / Task ID | Task | Files owned |
|---|---|---|---|
| W3.1 | ENG-D / **Task 3-a** | **Targets month-copy**: `POST /api/targets/copy {fromMonth,toMonth}` (ADMIN; upsert per source row; overwrite semantics with per-row before/after audit `SALES_TARGET_COPIED`; 422 on bad months; refuses copy onto the same month). Settings UI: "Copier vers…" affordance with confirm dialog showing source summary. i18n ×3 (fr/en/ar). | `api/targets/copy/route.ts` (new), `settings/targets-section.tsx`, i18n dicts |
| W3.2 | ENG-E / **Task 3-b** | **PDF first-page thumbnails**: `GET /api/documents/[id]/thumb` — visibility-checked, poppler first-page raster at thumb DPI, PNG response with immutable cache; `renderPdfPages` gains optional DPI; DocThumb uses the thumb URL (image docs keep the direct file URL). | `api/documents/[id]/thumb/route.ts` (new), `documents/doc-thumb.tsx`, `lib/server/documents.ts` |
| W3.3 | ENG-F / **Task 3-c** | **Polish batch**: incentive-status chip coherence across reservation surfaces (the R6B-census backlog candidate); semantic type-scale pass on the residual `text-[12px]/[11px]` notices; tab order/focus ring audit of the settings page. | `components/crm/**` (chip + notice surfaces only) |

### Wave 4 — Integration + styling detail pass (SERIAL, Principal)
- Central review of all agent diffs (architecture coherence, i18n completeness, RBAC on new endpoints).
- Mandatory styling-detail pass tied to the new surfaces (copy-dialog hierarchy, thumb hover states) + one platform detail upgrade chosen from live inspection.

### Wave 5 — Regression + delivery (SERIAL, Principal)
- `tsc --noEmit` + `eslint .` + dev.log review.
- agent-browser regression: manager login → targets copy flow (live) → documents surface with PDF thumb (live) → booking E2E (live hold still works — proves the unique index didn't break the golden path) → AR-RTL → dark → mobile 390 → agent role isolation. Screenshots → `download/qa-phase2/`.
- Docs: execution log, roadmap update, final delivery report addendum, migration documentation, worklog entry.
- Recreate the mandated 15-min webDevReview cron job.
- Commit.

## 3. Risk assessment

| Risk | Mitigation |
|---|---|
| Unique index breaks historical data (pre-existing double-holds) | Pre-check query before index creation; seed dataset audited clean (MASTER round: zero double-bookings); if violations found → stop and document, never auto-fix |
| `migrate dev` would see schema-drift on partial indexes (not schema-expressible) | House law already forbids `migrate dev` on this DB (`migrate deploy` only); migration header documents the raw-SQL reason; schema.prisma comment updated |
| Poppler raster on thumb route = per-request CPU | Thumb DPI low (~60), page 1 only, immutable Cache-Control (browser caches forever per doc id); images keep direct file URL (no raster) |
| Demo fail-fast breaks sandbox demo | Guard is NODE_ENV-gated (production only); sandbox NODE_ENV=development — verified unaffected |
| Agents collide on shared files | Disjoint ownership table above; i18n dicts = per-domain key prefixes (targets.* vs docs.* vs polish surfaces — no shared keys); central review before integration |

## 4. Acceptance criteria (Definition of Done)

Per the mission's §13, Phase 2 closes when: the D12 theoretical race is DB-enforced (verified by a violation probe on a DB copy + live booking still green); production demo fail-fast is coded and documented; both backlog features are live and browser-verified end-to-end (FR/AR/EN, responsive, dark); the polish batch is applied; all gates green (tsc 0, eslint 0, zero console errors in the walkthrough); all four deliverable docs updated; the cron register recreated. Honest limits will be stated (per §14: implemented-verified vs implemented-not-fully-verified vs deferred).
