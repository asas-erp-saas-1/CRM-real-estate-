# ASAS CRM — Phase 2R Browser & UI/UX QA Report

**PART 1 — BROKEN-STATE BASELINE (pre-recovery)** · [§1–§10 + baseline evidence index below]
**PART 2 — FINAL VERIFICATION (post-recovery)** · [§11–§21 appended after Part 1's evidence index — includes the before/after table (§20) and the final independent verdict (§21)]

**Task ID (Part 1):** 1-f · Agent 6 (Browser, UI/UX & Independent QA)
**Task ID (Part 2):** 4-a · same Agent 6, final independent verification pass
**Part 1 session:** 2026-11-02, ~15:00–15:10 UTC (broken state, dev server pid 6723)
**Part 2 session:** 2026-11-02, ~15:24–15:33 UTC (recovered state, dev server pid 9703 — never restarted by this agent)
**Mode:** read-only browser QA of the broken pre-recovery state · zero source writes (only this report + `evidence/phase2r/` screenshots)
**Environment:** dev server `next dev` on `http://localhost:3000` (next-server v16.1.3, PID 6723, freshly restarted ~30 s before this session — "Ready in 1402ms"), git HEAD `753d115` (broken state), live DB `db/custom.db` = 30 tables / 0 rows, `ASAS_SESSION_SECRET` unset, demo mode defaults ON.
**Tooling:** `agent-browser` (headless Chromium via Playwright) — DOM/accessibility-tree inspection, programmatic raw-key scans (`document`-wide, incl. `placeholder` / `aria-label` / `title` attributes), network tracking, console/page-error capture, screenshots at 1440×900 / 768×1024 / 390×844.

---

## §1 Executive summary

The browser-verifiable broken state is **narrower than the static-analysis blast radius but real and precisely reproducible**:

1. **The login surface is the one part of the UI that still works end-to-end.** It renders fully translated in FR (default), AR (with a verified `dir="rtl"` flip) and EN; a document-wide raw-key scan (visible text + placeholders + aria-labels + title attributes) found **zero raw i18n keys** in all three languages; `document.title` is the static brand string "ASAS — CRM Immobilier" (not a raw key); the layout holds with **zero horizontal overflow at 1440×900, 768×1024 and 390×844 (AR-RTL)**. This is consistent with the audit's finding that all `auth.*` keys live inside the 3,253-line zombie monolith `src/lib/i18n.ts` — the login surface survives the 46% dictionary loss by accident of key placement.
2. **Everything behind the login is BLOCKED, honestly.** The database has 0 users, so the documented demo credential (`nadia@asas.dz` / `asas1234`) fails with a graceful, *translated* inline error ("Email ou mot de passe incorrect.") and a 401 JSON server response. The 12 views, their raw-key damage (849/2,055 render sites per audit), the raw nav labels and the 3 raw view titles are **not browser-verifiable in this state** — they are BLOCKED, not "probably fine".
3. **The API poisoning is confirmed first-hand and is global.** In the healthy window, `GET /api/auth/session` → 200 JSON and unauthenticated `GET /api/leads` → 401 JSON (`NO_SESSION`, fail-closed). One deliberate browser navigation to `GET /api/journey/export` → **500** with the embedded turbopack compile error `./src/lib/server/journey-worklist.ts:23:1 — Export isJourneyStalled doesn't exist in target module`. A single subsequent probe of `/api/auth/session` (previously 200) then returned **500 with the identical error HTML** — the documented global degradation, reproduced exactly once per mandate.
4. **One audit claim did NOT reproduce in the clean-restart state:** the "Build Error" overlay + console error on first page load (audit T-5.1). With a freshly restarted server and no prior compilation of the broken route, the first load of `/` had a **clean console** (only benign HMR/Fast-Refresh/React-DevTools messages). The overlay-and-console-error symptom manifests only once the broken route has been compiled — i.e. it is a *contamination symptom*, not an unconditional first-load property of HEAD. The underlying defect is nonetheless real (proven by the deliberate reproduction).
5. **Dev-server state at session end: POISONED.** The last two browser actions left every API route returning 500 HTML. Per mandate the server was not restarted by this agent; the Principal's recovery restart clears it. **Any API probing by other agents after 15:07 UTC sees contamination symptoms, not fresh defects.**

**Classification counts for this pass: VERIFIED 16 · BLOCKED 9 classes · NOT VERIFIED / NOT REPRODUCED 3.**

---

## §2 Environment & access matrix

| Surface | Reachable? | Notes |
|---|---|---|
| `GET /` (login SPA shell) | ✅ YES | 200, client-rendered, full shell + login overlay |
| Language switcher (FR / EN / ع) pre-login | ✅ YES | Group `aria-label` "Changer de langue"; 3 buttons; works without auth |
| `GET /api/auth/session` (healthy window) | ✅ YES | 200 JSON `{"user":null,"organization":null,"demoUsers":[]}` — client polls it on load |
| `POST /api/auth/login` | ✅ reachable, ❌ cannot succeed | 401 JSON (empty DB — no user rows); see §5 |
| Unauthenticated protected APIs | ✅ YES (probe only) | `GET /api/leads` → 401 JSON `NO_SESSION` (fail-closed contract intact pre-poisoning) |
| 12 authenticated views (`#/dashboard` … `#/settings`) | ❌ BLOCKED | Requires a session; DB has 0 users → login impossible |
| Persona quick-login grid | ❌ BLOCKED (renders as unmounted) | `demoUsers: []` from empty DB — grid cleanly unmounted (matches audit T-5.2) |
| Sidebar nav labels / view titles / view text layer | ❌ BLOCKED | Part of the authenticated shell |
| `GET /api/journey/export` | ⚠️ touched exactly ONCE (deliberate, §7) | 500 — triggers global poisoning; mandate forbids more |
| Production build (`bun run build`) | ❌ FORBIDDEN by house law | Not attempted |
| DB seeding / server restart | ❌ FORBIDDEN for this agent | Not attempted |

---

## §3 Login surface localization evidence (FR / AR / EN)

### 3.1 French (default) — VERIFIED — `evidence/phase2r/baseline-01-login-fr-1440.png`

- `document.documentElement`: `lang="fr"`, `dir="ltr"`.
- Rendered strings (from `document.body.innerText` + accessibility tree): "Connexion" (h1) · "Accédez à votre espace de travail" · "Adresse email" · "Mot de passe" · "Afficher le mot de passe" (password-visibility button, aria) · "Se connecter" · "Mot de passe oublié ?" · marketing panel "ASAS / Real Estate CRM / Pipeline commercial structuré / Moteur d'appariement d'inventaire / Copilote IA & documents" · footer "© 2026 ASAS · Alger, Algérie — v2.0".
- Login button correctly **disabled** until both required fields are filled (progressive-enable behavior works).
- **Raw keys found: NONE.**

### 3.2 Arabic (ع) — VERIFIED, RTL flip works — `evidence/phase2r/baseline-02-login-ar-rtl-1440.png`

- `document.documentElement`: `lang="ar"`, **`dir="rtl"`** — direction flip verified programmatically after a single click on the "ع" button.
- Rendered strings: "تسجيل الدخول" · "ادخل إلى مساحة عملك" · "البريد الإلكتروني" · "كلمة المرور" · "هل نسيت كلمة المرور؟" · marketing "نظام CRM عقاري / مسار مبيعات منظّم / محرك مطابقة المخزون العقاري / مساعد ذكي ووثائق".
- **Raw keys found: NONE.**

### 3.3 English (EN) — VERIFIED — `evidence/phase2r/baseline-03-login-en-ltr-1440.png`

- `document.documentElement`: `lang="en"`, `dir="ltr"`.
- Rendered strings: "Sign in" · "Access your workspace" · "Email address" · "Password" · "Forgot your password?" · marketing "Real Estate CRM / Structured sales pipeline / Inventory matching engine / AI copilot & documents".
- **Raw keys found: NONE.**

### 3.4 Raw-key inventory (login surface)

A document-wide programmatic scan was run in each language over (a) all text nodes, (b) `placeholder`, `aria-label`, `title`, `alt`, `aria-description`, `aria-placeholder` attributes, matching the pattern `(nav|auth|login|dash|common|shell|journey|leads|pipeline|visits|tasks|properties|finance|sav|analytics|audit|settings|errors|actions|ui)\.[a-zA-Z][a-zA-Z0-9_.]*`:

| Language | Visible-text raw keys | Attribute raw keys |
|---|---|---|
| FR | 0 | 0 |
| AR | 0 | 0 |
| EN | 0 | 0 |

Single false positive encountered: the literal string `error.tsx` inside a Next.js RSC payload `<script>` (flight data chunk name), not user-visible. **Conclusion: the login surface itself carries zero raw i18n keys at HEAD** — consistent with the audit's static finding that `auth.*` keys exist inside the zombie monolith. The 849-raw-render-site damage begins *behind* the login.

### 3.5 `document.title` check — VERIFIED (login surface)

`document.title` = **"ASAS — CRM Immobilier"** in all three languages (static brand string — not localized, not a raw key). The audit's claim that 3/12 *view* titles render raw (journey / finance / sav) concerns the authenticated shell and is **BLOCKED** for this pass (see §8).

---

## §4 Console & network findings

### 4.1 Console — VERIFIED clean in the healthy window (fresh restart)

Full console capture after first load and through the FR→AR→EN switches and the login attempt:

```
[info] %cDownload the React DevTools ... (React DevTools promo — benign)
[log]  [HMR] connected
[log]  [Fast Refresh] rebuilding / done in 1226ms   (×5 cycles — on-demand dev compilation, benign)
[log]  [Fast Refresh] done ...
```

**Zero JavaScript errors. Zero page errors (`agent-browser errors` → empty).** No React warnings (no key/prop-type/hyddration warnings).

**Important divergence from audit T-5.1:** the audit observed a "Build Error" overlay + console error `Export isJourneyStalled doesn't exist in target module` *on first load*. In this session — after the Principal's clean restart and before any compilation of the broken route — the first load was **clean**. The audit's symptom is therefore a **post-contamination** presentation of the same defect, not an unconditional property of a freshly restarted HEAD. The underlying broken import is nonetheless real and was reproduced deliberately (§7).

### 4.2 Network — VERIFIED

- `GET /` → 200; all `_next/static` chunks, fonts, manifest, icon → 200.
- **`GET /api/auth/session` (Fetch) → 200** `{"user":null,"organization":null,"demoUsers":[]}` — the session-bootstrap contract works in the healthy window; empty `demoUsers` correctly unmounts the persona quick-login grid.
- `HEAD /downloads/index.html` (Fetch) → **404** — traced read-only to `src/components/crm/login-overlay.tsx:191-203`: a deliberate self-gating probe for the environment-side handoff-ZIP mirror (`public/downloads/index.html`, git-ignored). Environments without the mirror never render the link; the 404 is **expected, silently handled, not a defect**. Flagged for the final pass only as "confirm it stays silent".
- `POST /api/auth/login` → 401 (see §5).

---

## §5 Login attempt — BLOCKED classification evidence

**Credential used (documented demo creds): `nadia@asas.dz` / `asas1234` — exactly one attempt.**

- **Server:** `POST /api/auth/login` → **401** (JSON error contract; fail-closed — no session issued).
- **UI failure mode:** a graceful **inline form error**, translated, not a raw key:

  > `Email ou mot de passe incorrect.`

  rendered in a `div.text-muted-foreground.col-start-2` slot (form error region). No crash, no navigation (URL stays `/`), no console error, no page error.
- **Form state preserved:** email field retains `nadia@asas.dz`; password field retains its 8 characters. Submit button re-enabled.
- **No toast element** (`[data-sonner-toast]` / `[role=status]`) was present at capture time (+2.5 s after submit) — the audit's T-5.5 described a transient toast (auto-dismissing per Sonner default); this pass captured the persistent inline error instead. Both observations support the same conclusion: *graceful failure*. Mechanism detail (toast vs inline) recorded as NOT VERIFIED.
- **Persona quick-login grid:** cleanly unmounted (`demoUsers: []` — no seeded users exist).

**CLASSIFICATION: BLOCKED.** Authenticated workflow testing is impossible in this state: the DB has 0 rows in all 30 tables, so no credential can ever succeed and no quick-login persona exists. The failure observed is the *correct* fail-closed behavior of a healthy auth layer against an empty user store — the blocker is environmental (empty DB + unset `ASAS_SESSION_SECRET`), not an auth bug. **No authenticated view was fabricated as "tested".**

---

## §6 Responsive spot-checks (login surface)

| Viewport | Language / dir | `clientWidth` | `scrollWidth` | Overflow | Evidence |
|---|---|---|---|---|---|
| 1440×900 (desktop) | FR / ltr | 1440 | 1440 | **none** | `baseline-01-login-fr-1440.png` |
| 390×844 (mobile) | AR / **rtl** | 390 | 390 | **none** | `baseline-05-login-mobile-390-ar-rtl.png` |
| 768×1024 (tablet) | EN / ltr | 768 | 768 | **none** | `baseline-06-login-tablet-768-en.png` |

**VERIFIED: the login layout holds at all three mandated sizes, including the hardest case (RTL at 390 px mobile width — `scrollWidth` exactly equals `clientWidth`, no horizontal scroll).** Matches and extends the audit's T-5.6/T-5.7 (390 AR / 375 EN).

---

## §7 API poisoning reproduction (single deliberate reproduction — last browser actions)

**Mandate compliance: `/api/journey/export` was hit exactly ONCE, as the final browser action. The one subsequent probe was `/api/auth/session`. No further API requests were made by this agent afterwards; the browser was then closed.**

### 7.1 Healthy window (before)

| Probe | Result |
|---|---|
| `GET /api/auth/session` (browser fetch on load) | **200** JSON `{"user":null,"organization":null,"demoUsers":[]}` |
| `GET /api/leads` (curl, unauthenticated) | **401** JSON `{"error":"No active session. Reload the page.","code":"NO_SESSION","details":null}` — byte-shape matches the audit's fail-closed contract |

### 7.2 The trigger — `GET /api/journey/export` (browser navigation) — `evidence/phase2r/baseline-07-api-poisoning-journey-export.png`

- Network log: `[Document] GET http://localhost:3000/api/journey/export → 500`.
- The response is a Next.js `/_error` page (statusCode 500) whose embedded `__NEXT_DATA__` carries the exact turbopack compile error:

```
./src/lib/server/journey-worklist.ts:23:1
Export isJourneyStalled doesn't exist in target module
  21 | import { toLeadDTO } from "@/lib/server/leads";
  22 | import { qp } from "@/lib/server/validation";
> 23 | import {
     | ^^^^^^^^
> 24 |   computeJourney,
> 25 |   computeUrgency,
> 26 |   isJourneyStalled,          ← the orphan symbol
> 27 |   JOURNEY_STAGES,
> 28 |   type JourneyStage,
> 29 | } from "@/lib/journey";
```

- Root cause confirmed from the served error itself: the resurrected orphan `src/lib/server/journey-worklist.ts` (from commit `753d115`) imports `isJourneyStalled` from `@/lib/journey`, where that export no longer exists — the route fails to compile at request time.

### 7.3 The blast radius — one subsequent probe — `evidence/phase2r/baseline-08-api-poisoning-global-session.png`

- `GET /api/auth/session` (browser navigation) → **500** `[Document]` — a route that had returned **200 JSON** earlier in this same session.
- The `__NEXT_DATA__` of the poisoned response embeds the **identical** `journey-worklist.ts:23:1 / isJourneyStalled` compile error — i.e. the unrelated session route now serves the broken route's error HTML.
- The two error-page screenshots are byte-sized identically (92,124 bytes each) — the served error page is the same artifact both times.
- **GLOBAL API POISONING: CONFIRMED** (audit T-6.2/T-6.3 reproduced exactly).

### 7.4 Session end-state

**The dev server is left POISONED** (every API route → 500 HTML until restart). This is the documented end-state of the baseline pass; per mandate this agent does not restart it. *Note to the Principal / other agents: any API probe after 15:07 UTC in this session reflects contamination, not fresh defects — restart before further API work.*

---

## §8 Audit-claims reconciliation (independent audit + acceptance-test browser pass)

Reference: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_INDEPENDENT_AUDIT_REPORT.md`, `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_ACCEPTANCE_TEST_RESULTS.md` (T-5/T-6/T-10), `evidence/independent-audit/*.png` (01-build-error-live, 02-login-ar-rtl, 03-login-failed-ar, 04-login-mobile-390-ar, 05-login-mobile-375-en, poisoned-api-response.html).

| Audit claim | This pass | Detail |
|---|---|---|
| T-5.1 "Build Error" overlay + console error on first load | **NOT REPRODUCED (clean-restart state)** | First load after fresh restart: clean console, no overlay. Symptom is post-contamination (route compiled); underlying defect independently proven in §7.2 |
| T-5.2 Login renders fully translated FR | **RE-VERIFIED** | Exact same strings (§3.1) — `baseline-01` |
| T-5.3 AR switch → RTL (`dir=rtl`, `lang=ar`, full AR) | **RE-VERIFIED** | §3.2 — `baseline-02` |
| T-5.4 EN switch → LTR | **RE-VERIFIED** | §3.3 — `baseline-03` |
| T-5.5 Failed login → graceful feedback, no crash | **RE-VERIFIED (conclusion); mechanism detail NOT VERIFIED** | Inline translated error + 401; no toast element captured at +2.5 s (§5) |
| T-5.6/T-5.7 Mobile 390 (AR) / 375 (EN) no overflow | **RE-VERIFIED (390 AR)** | `scrollWidth=390` exact; extended with 768 tablet + 1440 desktop (§6). 375 not re-run (superseded by 390 + audit receipt) |
| T-5.8 849/2,055 render sites raw · 662 unique keys · 46% missing · all 12 views | **BLOCKED (view-level)** | Views unreachable without auth. Login-surface sub-claim ("login unaffected, `auth.*` in zombie") **RE-VERIFIED**: zero raw keys in 3 languages (§3.4) |
| 3 sidebar nav labels raw (`nav.journey/finance/sav`) | **BLOCKED** | Sidebar is the authenticated shell |
| T-10.7 3/12 `document.title` raw (journey/finance/sav) | **BLOCKED (view-level); login title RE-VERIFIED not-raw** | "ASAS — CRM Immobilier" brand string in all languages (§3.5) — consistent with the audit (login is not among the 3 raw views) |
| T-10.8 "UI never calls the broken /api/journey/export" | **RE-VERIFIED (negative evidence)** | My entire pre-poisoning browser session (loads, 3 language switches, login POST) made zero requests to that route; the only hit was my deliberate one |
| T-6.1 Healthy window: 401 JSON fail-closed | **RE-VERIFIED** | `/api/leads` → 401 `NO_SESSION` JSON (§7.1) |
| T-6.2 `GET /api/journey/export` → 500 (broken import) | **RE-VERIFIED** | Exact error text captured (§7.2) |
| T-6.3 Global poisoning: subsequent routes → 500 HTML | **RE-VERIFIED** | `/api/auth/session` 200→500, identical error HTML (§7.3) |
| Session route 200 `{"user":null,...,"demoUsers":[]}` | **RE-VERIFIED** | §4.2 |
| Persona grid cleanly unmounted on empty DB | **RE-VERIFIED** | No persona buttons in any snapshot; `demoUsers: []` |
| 12 views render (structure-level), role-gated nav, kanban mini-map, TrendChip, a11y structure | **BLOCKED** | Auth-gated; not browser-verifiable in this state |
| 2,055 rendering points / static-analysis counts (1,013 vs 1,877 keys) | **NOT VERIFIED (out of browser scope)** | Static-analysis domain (Agents 1–4); consistent with every browser-visible symptom but not re-derived here |
| Junk `GET /api` 200 "Hello, world!" (T-2.15) | **NOT VERIFIED (not probed)** | Out of this pass's mandated scope; safe for the final pass to re-check |

---

## §9 Recommended post-recovery verification plan (final-pass checklist)

To be executed by the final QA pass **after** the resurrection sweep (zombie deletion), the R13 DB recovery runbook (migrate → seed → census → D12 indexes → `ASAS_SESSION_SECRET`), and a fresh dev-server restart:

1. **Pre-flight (healthy window):** `GET /api/auth/session` → 200 JSON with populated `demoUsers`; `GET /api/leads` unauthenticated → 401 JSON `NO_SESSION` (fail-closed contract); console of first `/` load → zero errors.
2. **Login (positive):** `nadia@asas.dz` / `asas1234` → success toast, redirect into the shell, session cookie set, `GET /api/auth/session` → 200 with user. Also exercise one quick-login persona.
3. **12 views × 3 languages:** `#/dashboard`, `#/leads`, `#/journey`, `#/pipeline`, `#/visits`, `#/tasks`, `#/properties`, `#/finance`, `#/sav`, `#/analytics`, `#/audit`, `#/settings` — in FR, AR, EN. On each: document-wide raw-key scan (text + `placeholder`/`aria-label`/`title` attributes) → **must be zero**; specifically assert `nav.journey`, `nav.finance`, `nav.sav` and `dash.attention.title`-class strings are *translated*, and the 3 previously-raw view titles (`journey`/`finance`/`sav`) resolve.
4. **RTL/LTR integrity:** `dir` flips with language on every view; no horizontal overflow in RTL; RTL-aware components (kanban mini-map scroll direction, journey rail) spot-checked.
5. **Viewports:** 1440×900, 1280×800, 768×1024, 390×844, 375×812 — `scrollWidth === clientWidth` on each visited view (any overflow = defect).
6. **Console cleanliness:** zero JS errors / page errors on every view × language × viewport; no unexpected 404s beyond the documented self-gating `/downloads/index.html` HEAD probe (which must remain silently handled).
7. **`/api/journey/export` after recovery:** unauthenticated → 401 JSON (never 500); authenticated (appropriate role) → 200 export payload or documented auth behavior; **then re-probe `/api/auth/session` and `/api/leads` — both must remain healthy** (no global poisoning; the compile-error class must be gone because the orphan import chain is deleted).
8. **Authenticated flows (the audit's T-8 golden path, 16 steps):** login → create lead → assign → qualify → opportunity → interaction → follow-up task → appointment → visit → pipeline → reservation → timeline → cross-account permission negatives (agent→finance 403, ghost-404 IDOR, ROLE_CEILING) → dashboard. Plus logout → session invalidated.
9. **Regression guards from this baseline:** login button disabled-until-valid; failed-login inline error translated with values retained; persona grid renders with seeded users.
10. **Static cross-checks (reference, non-browser):** tsc 0 / eslint 0; standing 333-probe matrix.

---

## §10 Verdict (Part 1 — baseline; superseded by §21 after recovery)

> **UPDATE (Part 2):** every negative finding in this Part-1 verdict was re-tested in the recovered state and is now RESOLVED — see the before/after table in §20 and the final independent verdict in §21. This section is preserved verbatim as the baseline record.

**The broken pre-recovery state is browser-confirmed on every surface that is reachable without authentication, and honestly BLOCKED everywhere else.**

- **LOGIN SURFACE: OK.** Fully localized (FR/AR/EN), RTL machinery works, zero raw keys, zero console errors (clean restart), zero horizontal overflow at 3 viewports, graceful translated failure on impossible login. The only UI fragment unaffected by the i18n zombie — because its keys happen to live in the zombie.
- **AUTHENTICATED UI: BLOCKED (empty DB).** All 12 views, nav labels, view titles, view text layer, RBAC, golden path — unverifiable in this state; the audit's view-level claims rest on their static analysis + at-time receipts, which this pass could neither confirm nor refute at runtime.
- **API SURFACE: POISONED ON DEMAND — reproduced.** One hit of `/api/journey/export` (500, `isJourneyStalled` compile error verbatim) globally degrades every API route to 500 HTML (verified via `/api/auth/session` 200→500). Fail-closed preserved; the dev server was left in the poisoned end-state for the Principal's restart.
- **Baseline established for Phase 2R:** 8 screenshots + programmatic DOM/network/console captures under `evidence/phase2r/`, structured for direct before/after comparison in the final verification pass (§9).

**Bottom line for the recovery mission:** delete the zombie (restores the 1,877-key modular dictionary), execute the DB recovery runbook (unblocks all authenticated verification), and the login surface proves the shell, design system, RTL engine, and error handling are all structurally intact underneath — the damage is a text/data layer problem, not a framework problem.

---

### Evidence index (this pass)

| File | Content |
|---|---|
| `evidence/phase2r/baseline-01-login-fr-1440.png` | Login surface, French, 1440×900 — fully translated, no raw keys |
| `evidence/phase2r/baseline-02-login-ar-rtl-1440.png` | Login surface, Arabic, 1440×900 — `dir="rtl"` verified |
| `evidence/phase2r/baseline-03-login-en-ltr-1440.png` | Login surface, English, 1440×900 — LTR |
| `evidence/phase2r/baseline-04-login-failed-fr-1440.png` | Failed login (nadia@asas.dz / asas1234) — inline translated error, values retained — BLOCKED evidence |
| `evidence/phase2r/baseline-05-login-mobile-390-ar-rtl.png` | Mobile 390×844, Arabic RTL — no overflow |
| `evidence/phase2r/baseline-06-login-tablet-768-en.png` | Tablet 768×1024, English — no overflow |
| `evidence/phase2r/baseline-07-api-poisoning-journey-export.png` | `GET /api/journey/export` → 500 dev-error page (isJourneyStalled compile error) |
| `evidence/phase2r/baseline-08-api-poisoning-global-session.png` | Subsequent `GET /api/auth/session` → 500 identical error page — global poisoning confirmed |

*Constraints honored: zero source modifications; zero git state changes; no server restart/kill; no DB seeding; no `bun run build`; `/api/journey/export` hit exactly once (final browser action); one subsequent probe only. Writes limited to this report and `evidence/phase2r/`.*

---

# PART 2 — FINAL VERIFICATION (post-recovery)

**Task ID:** 4-a · Agent 6 (Browser, UI/UX & Independent QA) — the mission's Phase Seven, executed as an independent challenge of the Principal's recovery.
**Session date:** 2026-11-02, 15:24–15:33 UTC.
**Recovered state under test:** dev server restarted with cleared `.next` (pid 9703, next-server v16.1.3), fresh DB via `migrate deploy` + canonical seed, `ASAS_SESSION_SECRET` provisioned, 33 contamination files `git rm`-ed (source byte-identical to reference `b34d5b8` per Principal's proof).
**Method:** same tooling and the same two-tier raw-key scanner as Part 1 (full-match `^[a-z]+\.[a-zA-Z0-9_.]+$` + i18n-family-prefix match, over all text nodes **and** `placeholder`/`aria-label`/`title`/`alt`/`aria-description` attributes) — installed as `window.__qa()` and re-run on every view × language, plus document-level overflow measurement, network tracking, and console/page-error capture. Results are directly comparable with Part 1.

---

## §11 Environment & access matrix (recovered)

| Surface | Reachable? | Result |
|---|---|---|
| `GET /` | ✅ | 200; login surface with **8 persona quick-login tiles** (Nadia OWNER, Karim ADMIN, Sarah MANAGER, Amine/Lina/Yacine SALES_AGENT, Mounia/Riadh FIELD_REP — exactly the documented roster, with translated role labels) |
| `GET /api/auth/session` | ✅ | 200 JSON, `demoUsers` populated with 8 personas |
| Credential login | ✅ | `nadia@asas.dz` / `asas1234` → **success** (also quick-login persona path verified) |
| 12 authenticated views × 3 languages | ✅ | all render with live seeded data — see §13 |
| `GET /api/journey/export` | ⚠️ touched exactly once | clean **404** — no poisoning (§17) |
| Mutations | deliberately NOT exercised | one benign dialog open/close only (§18); zero create/update/delete submissions |
| Server restart / DB writes / build | forbidden | not attempted; server pid 9703 is the **same process** at pass start and pass end |

## §12 Pre-flight & positive login

- `GET /` → 200; first-load console **clean** (only benign HMR/Fast-Refresh/React-DevTools lines; zero errors/warnings, zero page errors).
- `/api/auth/session` → 200 JSON with the 8-persona roster (above).
- **Positive login (credential path):** filled `nadia@asas.dz` / `asas1234` → success → app shell mounts, dashboard renders with live data (11 never-contacted, 6 late follow-ups, funnel 36/15/7/6/5, 36 new leads +620%, 102M DA gains, 461M DA pipeline value, 2.0M DA commissions, hot opportunities, recent-leads table). `document.title` = "Tableau de bord — ASAS CRM".
- **Quick-login persona path:** the Nadia persona tile — also used later at 390×844 in Arabic — logs in successfully. Both documented login paths work.
- Part 1 §9 regression guards all hold: submit button disabled-until-valid (observed on the login form), persona grid renders with seeded users.

## §13 The 12 audited views × 3 languages — raw-key scan matrix

**36/36 view × language combinations scanned (dashboard, journey, leads, pipeline, visits, tasks, properties, finance, sav, analytics, audit, settings × FR / AR / EN). RESULT: 0 raw keys — in rawFull, rawFam AND rawAttrs tiers — in every single combination.** Every view rendered with live seeded data; `overflowPX = 0` everywhere.

| View (hash) | FR title | AR title | EN title | Renders | Raw keys |
|---|---|---|---|---|---|
| #/dashboard | Tableau de bord — ASAS CRM | لوحة القيادة — ASAS CRM | Dashboard — ASAS CRM | ✅ | **0** |
| #/journey | Parcours client — ASAS CRM | رحلة العميل — ASAS CRM | Customer Journey — ASAS CRM | ✅ | **0** |
| #/leads | Prospects — ASAS CRM | العملاء المحتملون — ASAS CRM | Leads — ASAS CRM | ✅ | **0** |
| #/pipeline | Pipeline — ASAS CRM | مسار البيع — ASAS CRM | Pipeline — ASAS CRM | ✅ | **0** |
| #/visits | Visites — ASAS CRM | الزيارات — ASAS CRM | Visits — ASAS CRM | ✅ | **0** |
| #/tasks | Tâches — ASAS CRM | المهام — ASAS CRM | Tasks — ASAS CRM | ✅ | **0** |
| #/properties | Inventaire — ASAS CRM | المخزون العقاري — ASAS CRM | Inventory — ASAS CRM | ✅ | **0** |
| #/finance | Finance — ASAS CRM | المالية — ASAS CRM | Finance — ASAS CRM | ✅ | **0** |
| #/sav | SAV — ASAS CRM | خدمات ما بعد البيع — ASAS CRM | After-sales — ASAS CRM | ✅ | **0** |
| #/analytics | Analytique — ASAS CRM | التحليلات — ASAS CRM | Analytics — ASAS CRM | ✅ | **0** |
| #/audit | Journal d'audit — ASAS CRM | سجل التدقيق — ASAS CRM | Audit log — ASAS CRM | ✅ | **0** |
| #/settings | Paramètres — ASAS CRM | الإعدادات — ASAS CRM | Settings — ASAS CRM | ✅ | **0** |

**The baseline's known-dark keys are specifically confirmed fixed:**
- Sidebar nav labels: journey → "Parcours client" / "رحلة العميل" / "Customer Journey"; finance → "Finance" / "المالية" / "Finance"; sav → "SAV" / "خدمات ما بعد البيع" / "After-sales" — translated in all three languages (EN nav verified verbatim: `SALES | Dashboard | Customer Journey | Leads | Pipeline | Visits | Tasks | OPERATIONS | Inventory | Finance | After-sales | Analytics | ADMINISTRATION | Audit | Settings`).
- The 3 previously-raw view titles (journey / finance / sav): all translated in all three languages (table above).
- `document.title` on the login surface remains the brand string "ASAS — CRM Immobilier" on fresh loads; per-view titles are the translated `"<view> — ASAS CRM"` pattern. (One cosmetic note in §19.)
- Data-deep views verified non-vacuous: finance renders real aggregates ("Échéancier total 93M DA · Appelé 63M DA · Encaissé 39M DA · Reste 24M DA"), journey renders the funnel/stage chips over live leads (§18), leads lists the 43 seeded leads.

## §14 RTL depth check (Arabic)

- `dir="rtl"` + `lang="ar"` flip verified on **all 12 AR views** (not just the login surface as in Part 1).
- **Sidebar flips to the right:** nav/aside bounding box measured at x=1216→1440 (right edge of the 1440 viewport) in AR vs left-anchored in FR/EN.
- **Table columns flow right→left:** leads table `th` computed style `text-align: start` with `direction: rtl`; the first DOM column renders on the right (first cell at x≈1143).
- **No horizontal overflow:** `scrollWidth === clientWidth` at the document level on every view × language (incl. content-heavy leads and journey in RTL). The 11-column leads table scrolls **inside its `crm-table-sticky` container** (1353px table in an 1150px client-width scroll region) — an intentional by-design pattern, not page overflow; `document/body.scrollWidth` stays exactly at viewport width.

## §15 Responsive spot-checks (dashboard + leads)

| Viewport | Language / dir | Dashboard overflow | Leads overflow | Evidence |
|---|---|---|---|---|
| 1440×900 | FR / AR / EN | 0 px | 0 px | `final-02/04`, `final-07/08`, `final-09` |
| 1280×800 | EN | 0 px | 0 px | (scan logs, §13) |
| 768×1024 | EN | 0 px | 0 px | `final-10` |
| 390×844 | **AR / rtl** | 0 px | 0 px | `final-12/13/21` |
| 375×812 | EN | 0 px | 0 px | (scan logs) |

- At mobile widths the sidebar collapses to a "Menu" sheet containing the translated nav **and** the language switcher — all 12 views listed, fully translated; sheet opens/closes cleanly (`final-12`).
- No clipped or overlapping chrome observed at any viewport; the mobile leads view renders card/list layout without document-level overflow.

## §16 Console & network (whole pass)

- **Console: ZERO errors, ZERO warnings, ZERO page errors across the entire pass** — 2 successful logins + 3 logout/login cycles, 36 view×language loads, 5 viewport changes, 2 dialogs, the dead-URL hit, hash deep-links (`#/leads/<id>`). The only console lines are benign dev-tooling messages (React DevTools promo, `[HMR] connected`, `[Fast Refresh] rebuilding/done`).
- **Network non-2xx inventory — every item expected and honest:**
  - `HEAD /downloads/index.html` → 404 (×2, on login-surface loads) — the single tolerated item, the documented self-gating handoff-mirror probe (Part 1 §4.2); silent by design.
  - `GET /api/journey/export` → **404** — the deliberate single dead-URL test (§17).
  - 401s (`/api/dashboard`, `/api/users`, `/api/notifications`, `/api/analytics`) — momentary post-logout fetches from the still-mounted shell; **fail-closed 401 JSON**, no user-visible error.
  - 403s (`/api/analytics?days=30` ×2, `/api/finance/overview`) — as SALES_AGENT: live server-side RBAC enforcement captured in-browser (§19).

## §17 Dead URL + no-poisoning (the Part-1 killer, re-tested)

1. **The trigger (hit exactly once):** browser navigation to `http://localhost:3000/api/journey/export` → **clean Next.js 404 page** ("404 — This page could not be found."), HTTP 404 `[Document]`. **No compile error, no 500, no `isJourneyStalled`, no dev-error overlay.** The endpoint is honestly gone. (`final-14`)
2. **No cross-route poisoning:** navigated back to the app root → the session cookie persisted (no re-login), the dashboard re-rendered immediately with live data and 0 raw keys.
3. **Independent API probes after the hit:** `GET /api/auth/session` → **200 JSON**; unauthenticated `GET /api/leads` → **401 JSON `NO_SESSION`** (content-type `application/json` — the fail-closed contract, byte-shape identical to Part 1's healthy window).
4. **Server stability over the whole pass:** the dev server is the **same process (pid 9703)** at pass start (15:24, elapsed 01:41) and pass end (15:33, elapsed 10:40) — never restarted by this agent — and remained fully healthy after the dead-URL hit and 36 view loads. **The Part-1 global-poisoning phenomenon is eradicated at its root** (orphan import chain deleted), not merely avoided.

## §18 Golden-path smoke (data-driven interactivity, read-only)

| Step | Result |
|---|---|
| Leads view | 43 seeded leads render; translated columns (Nom, Téléphone, Source, Statut, Priorité, Budget, Agent, Dernier contact, Prochain suivi, Score); sortable headers; row selection checkboxes (`final-04`) |
| Lead drawer (Réda Mokrani) | Opens on row click; **journey rail fully translated** — "PARCOURS CLIENT · Étape 1 sur 7 · Capturé → Contacté → Qualifié → Visite → Négociation → Réservation → Gagné · PROCHAINE ÉTAPE RECOMMANDÉE: Premier contact / Journaliser un contact"; full lead detail (source, budget, typologie, localisation, score 26/100, étiquettes); tabs Aperçu/Historique/Tâches/Visites/Opportunités; deep-link hash `#/leads/<id>` works; closes on Escape; **0 raw keys** (`final-15`) |
| Journey worklist | Funnel + stage chips translated over live data — "Capturé 10 · Contacté 10 · Qualifié 3 · Visite 7 · Réservation 2 · Gagné 7 · Perdu 1", "Clients actifs (35)", filters (Toute l'agence / Tout le parcours); the entire 139-key `journey.*` family that was dark at HEAD now renders in French; **0 raw keys** (`final-16`) |
| Analytics | 8 SVG chart elements render with translated headings (Entonnoir commercial, Pipeline par étape, Tendance mensuelle, Par source, Classement des agents, Durée par étape); **0 raw keys** (`final-17`) |
| Benign dialog | "Nouveau prospect" dialog opened — fully translated form (Nom complet, Téléphone, Email, WhatsApp, Source with 14 translated options, Priorité, Agent…) — then closed via Escape. **No submission; zero DB mutations in the entire pass** (`final-18`) |

## §19 RBAC negative (D-021 law) + cosmetic observations

Logged out as Nadia → logged in as `amine@asas.dz` (SALES_AGENT):
- **Sidebar nav hides the MANAGER+ views:** the agent sees only "Tableau de bord · Parcours client · Prospects · Pipeline · Visites · Tâches · Inventaire · SAV" — **Analytique, Finance, Audit, Paramètres are all absent** from the nav (`final-20`).
- **Direct URL attack on the hidden view:** forcing `#/analytics` as the agent renders a graceful, translated guard state — "**Accès restreint — Accès réservé aux managers et administrateurs.**" — no crash, no raw keys, no data flash.
- **Server-side defense captured live (network log):** `/api/analytics?days=30` → **403** ×2 and `/api/finance/overview` → **403** as the agent. Defense-in-depth confirmed: UI gating + view-level guard + server 403s.
- Logged out at the end of the test (login surface restored).

**Cosmetic observations (non-blocking, recorded for the backlog):**
1. After an in-session logout, `document.title` retains the last view's title (e.g. "Analytique — ASAS CRM") over the login overlay instead of resetting to the brand string; fresh loads show "ASAS — CRM Immobilier" correctly. Cosmetic only.
2. Post-logout, the still-mounted shell fires a few API fetches that 401 before the overlay unmounts — expected fail-closed behavior, invisible to the user, no console errors.

## §20 Before/after table (Part 1 baseline → recovered state)

| # | Part 1 finding (baseline, broken state) | After state (this pass) |
|---|---|---|
| 1 | Login surface FR/AR/EN fully translated, 0 raw keys | **UNCHANGED-EXPECTED** — still 0 raw keys; now with the 8-persona grid rendering (translated role labels) |
| 2 | Persona quick-login grid unmounted (`demoUsers: []`) | **FIXED** — 8 personas render; quick-login path verified (Nadia tile, incl. at 390 AR) |
| 3 | Login BLOCKED (empty DB): 401 + translated inline error | **FIXED** — credential login (nadia@asas.dz) and quick-login both succeed; shell + dashboard mount |
| 4 | `document.title` = brand string on login surface | **UNCHANGED-EXPECTED** on fresh loads (new cosmetic note: stale title after in-session logout, §19) |
| 5 | 12 views BLOCKED (no auth) — untestable | **FIXED + VERIFIED** — all 12 render ×3 languages with live seeded data; 36/36 scans = 0 raw keys |
| 6 | Nav labels `nav.journey` / `nav.finance` / `nav.sav` raw (audit claim) | **FIXED** — translated in FR/AR/EN (Parcours client/Finance/SAV · رحلة العميل/المالية/خدمات ما بعد البيع · Customer Journey/Finance/After-sales) |
| 7 | 3/12 view titles raw (journey/finance/sav) (audit claim) | **FIXED** — all 12 titles translated in all 3 languages (§13 table) |
| 8 | 849/2,055 render sites raw · 46% keys dark (audit static claim) | **BROWSER-SIDE RESOLVED** — 0 raw keys across 36 DOM-wide scans incl. placeholder/aria-label/title/alt attributes; journey drawer rail, worklist chips, analytics headings, dialogs all translated |
| 9 | API poisoning: `/api/journey/export` 500 → global 500 HTML (reproduced) | **FIXED** — clean 404; zero cross-route contamination; same-pid server healthy through the whole pass |
| 10 | Healthy-window fail-closed 401 JSON contract | **UNCHANGED-EXPECTED** — unauth `/api/leads` → 401 JSON `NO_SESSION` still exact |
| 11 | Console clean on first load (fresh restart) | **UNCHANGED-EXPECTED + EXTENDED** — clean for the entire pass (36 view-loads, dialogs, dead-URL, RBAC) |
| 12 | Responsive: no overflow at 1440 / 390-AR / 768 | **EXTENDED** — 0 px overflow at all 5 mandated viewports (1440/1280/768/390-AR/375) × dashboard + leads |
| 13 | RTL flip verified on login surface only | **EXTENDED** — RTL verified on all 12 views; sidebar flips right; table columns flow right→left |
| 14 | Authenticated workflows/RBAC BLOCKED | **PARTIALLY UNBLOCKED (scope of this pass)** — RBAC negative verified (nav hiding + view guard + live 403s); golden-path smoke verified (drawer/journey rail/worklist/charts/dialog); the full 16-step mutating golden path intentionally NOT exercised (read-only mandate) — residual item for the owner's own final E2E, per the mission's read-only boundary |

## §21 Final independent verdict

**Every browser-verifiable acceptance criterion from Part 1's §9 recommended plan was executed and PASSED.**

- **GATE 3 — LOCALIZATION: PASS (independently browser-verified).** 36/36 view × language combinations scanned DOM-wide (text + placeholder/aria-label/title/alt/aria-description) with the identical scanner as the baseline: **zero raw keys**. The three known-dark nav labels and the three previously-raw view titles resolve in all languages; the 139-key journey family renders fully (drawer rail + worklist); dialogs, error states, RBAC guard copy, and the persona grid are translated; `dir`/`lang` flip correctly; titles follow the "<translated view> — ASAS CRM" pattern. This is direct runtime proof that the zombie deletion re-bound `@/lib/i18n` to the modular dictionaries.
- **GATE 4 — API SURFACE STABILITY (browser aspects): PASS.** The Part-1 killer route is now an honest 404 with zero cross-route contamination; fail-closed contracts intact (401 JSON unauth, 403 JSON for role violations, captured live in-browser); session persistence across full page navigations; the dev server survived the entire adversarial pass on one process.
- **GATE 5 — AUTHENTICATED APP QUALITY (browser aspects): PASS.** App shell + 12 views render with live seeded data; golden-path smoke (lead drawer → journey rail, journey worklist stage chips + funnel, analytics charts, benign dialog) all translated and functional; responsive at all 5 mandated viewports with zero overflow; console clean throughout; RBAC defense-in-depth verified (hidden nav + view-level guard + server 403s).

**Residuals (non-blocking, for the backlog):** the two cosmetic items of §19 (stale `document.title` after in-session logout; transient post-logout 401 fetches), and the full mutating 16-step golden path which this read-only mandate correctly excluded — recommend the owner's own post-acceptance E2E exercise it once.

**Independent verdict: the recovered state passes the browser QA gate. From this agent's independent vantage point, the Phase 2R recovery is browser-verified COMPLETE for localization (Gate 3) and for the browser aspects of API stability (Gate 4) and authenticated app quality (Gate 5).**

---

### Evidence index (Part 2 — final pass)

| File | Content |
|---|---|
| `final-01-login-personas-fr.png` | Login surface with 8 persona quick-login tiles (FR) — seeded DB restored |
| `final-02-dashboard-fr-1440.png` | Dashboard, French, 1440×900 — live data, 0 raw keys |
| `final-03-journey-fr-1440.png` | Journey view, French — previously the worst-affected view |
| `final-04-leads-fr-1440.png` | Leads view, French — 43 seeded leads, translated columns |
| `final-05-pipeline-fr-1440.png` | Pipeline, French |
| `final-05-visits-fr-1440.png` | Visits, French |
| `final-05-tasks-fr-1440.png` | Tasks, French |
| `final-05-properties-fr-1440.png` | Properties/Inventory, French |
| `final-06-finance-fr-1440.png` | Finance, French — previously-raw title, live aggregates (93M DA) |
| `final-06-sav-fr-1440.png` | SAV, French — previously-raw title |
| `final-06-analytics-fr-1440.png` | Analytics, French |
| `final-06-audit-fr-1440.png` | Audit log, French |
| `final-06-settings-fr-1440.png` | Settings, French |
| `final-07-journey-ar-rtl-1440.png` | Journey, Arabic RTL — dir=rtl verified |
| `final-08-leads-ar-rtl-1440.png` | Leads, Arabic RTL — sidebar right, table RTL |
| `final-09-dashboard-en-1440.png` | Dashboard, English |
| `final-10-dashboard-tablet-768.png` | Dashboard, 768×1024 tablet — 0 overflow |
| `final-11-dashboard-mobile-390-en.png` | Dashboard, 390×844 mobile (EN) — 0 overflow |
| `final-12-mobile-menu-390-ar-rtl.png` | Mobile menu sheet, 390×844 AR RTL — translated nav + language switcher |
| `final-13-leads-mobile-390-ar-rtl.png` | Leads, 390×844 AR RTL — 0 overflow |
| `final-14-dead-url-journey-export-404.png` | `/api/journey/export` → clean 404 (NOT 500) — dead URL honest |
| `final-15-lead-drawer-journey-rail-fr.png` | Lead drawer with fully-translated journey rail (7 stages + recommended next step) |
| `final-16-journey-worklist-stage-chips-fr.png` | Journey worklist — funnel + stage chips translated over live data |
| `final-17-analytics-charts-fr.png` | Analytics — 8 SVG charts, translated headings |
| `final-18-new-lead-dialog-fr.png` | Benign dialog open (New Lead form, translated) — closed without submission |
| `final-19-logout-login-surface-fr.png` | Logout returns to login surface |
| `final-20-agent-role-nav-rbac-fr.png` | SALES_AGENT nav — Analytique/Finance/Audit/Paramètres hidden (D-021) |
| `final-21-dashboard-mobile-390-ar-rtl.png` | Dashboard, 390×844 AR RTL via quick-login — 0 overflow |

*Part 2 constraints honored: zero source modifications; zero git state changes; no server restart/kill (pid 9703 identical at pass start/end); no DB mutations (read-only interactions; one dialog opened and closed without submission); `/api/journey/export` hit exactly once; no `bun run build`; no secrets printed; no cron jobs. Writes limited to this report and `evidence/phase2r/final-*.png`.*
