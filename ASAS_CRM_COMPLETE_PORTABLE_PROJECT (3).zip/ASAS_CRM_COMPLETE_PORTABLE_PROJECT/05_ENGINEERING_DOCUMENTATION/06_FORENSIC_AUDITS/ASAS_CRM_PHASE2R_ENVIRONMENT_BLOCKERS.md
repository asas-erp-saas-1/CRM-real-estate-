# ASAS CRM — PHASE 2R — ENVIRONMENT BLOCKERS REGISTER

**Mission Phase Five output.** Every blocker reported by the independent audit was individually investigated (Agent 4, strictly read-only, full attestation in its §10) and classified. **Verdict up front: all blockers are ENVIRONMENT-class (R13 sandbox-reset phenomena) — ZERO source-code issues.** The active database is a local sandbox dev SQLite file, verifiably NOT production.

---

## Blocker register (7-field format per mission §10)

### R-E1 — Empty active database
| Field | Finding |
|---|---|
| Actual condition (verified) | `db/custom.db`: 30 tables, **0 rows in every table** (incl. AuditLog); file healthy (`integrity_check` = ok, `foreign_key_check` = 0 rows); zero structural drift vs `schema.prisma` (`migrate diff` → "No difference detected") |
| Evidence | `bun:sqlite` readonly census (Agent 4 §3); row counts re-verified post-recovery: 8 users / 43 leads / 21 opps / 8 reservations |
| Technical impact | No login possible → all authenticated QA blocked |
| Environment affected | Local sandbox dev DB only (git-ignored `/db/`; `DATABASE_URL=file:/home/z/my-project/db/custom.db`; provider sqlite) |
| Required action | R13 runbook: `bun run db:seed` (synthetic demo data — canonical since D-016) |
| Responsible party | Operations (sandbox), not source code |
| Production risk | **None** — no production database exists in this environment; Supabase/PostgreSQL is a documented *optional* deployment path (commented `.env.example` lines, inert `supabase/` migration chain, CI uses a local file). Seeding executed in-recovery (synthetic demo data in the isolated sandbox — the mission's own sanction) |

### R-E2 — Migration bookkeeping absent + D12 indexes missing
| Field | Finding |
|---|---|
| Actual condition (verified) | `_prisma_migrations` table absent (all 17 migrations reported unapplied); **D12** (twin race guard) defined in migration #17 `20261102000000_phase2_d12_live_hold_unique` (commit `0d36f3e`) — two partial unique indexes (`Reservation_apartment_live_hold_uq` on `apartmentId`, `Reservation_opportunity_live_hold_uq` on `opportunityId`, each `WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')`), present in migrations and `schema.prisma:607-615`, **absent from the active DB** (6 Reservation indexes, zero live_hold matches) |
| Evidence | Agent 4 §4–§5 (sqlite_master DDL vs migration SQL; `migrate status`) |
| Technical impact | Bookkeeping loss blocks future `migrate dev`; missing D12 indexes remove the DB-enforced twin-race backstop (the interactive-transaction guard remains the primary enforcement — D-008) |
| Environment affected | Local sandbox dev DB only |
| Required action | Recreate the (empty, data-free) DB via `bunx prisma migrate deploy` → 17/17 applied incl. D12 — **executed in-recovery** (the DB held zero rows; nothing to lose; snapshot taken first) |
| Responsible party | Operations |
| Production risk | Documented without execution for production: at deploy time run `migrate deploy` (idempotent) — D12 is enforced by the migration chain, which is intact in the repo |
| Post-recovery state | **VERIFIED RESOLVED**: 17/17 applied, "Database schema is up to date!", both live_hold indexes present in `sqlite_master` |

### R-E3 — `ASAS_SESSION_SECRET` missing
| Field | Finding |
|---|---|
| Actual condition (verified) | `.env` contained only `DATABASE_URL`; secret read at exactly ONE site — `src/lib/server/session.ts:28-35` (HMAC-SHA256 signing of the `asas_user` cookie; timingSafeEqual verify; 7-day absolute expiry) |
| Evidence | Agent 4 §6; dev.log carried the ephemeral-fallback warning pre-recovery |
| Technical impact | Sessions signed with an ephemeral `randomBytes(32)` per boot (dev-safe fallback + console.warn) — every restart invalidates all sessions; **not** a boot failure (the `0d36f3e` "prod fail-fast" concerns `ASAS_DEMO_MODE`, not the secret — verified in `session.ts:115-125`) |
| Environment affected | Local sandbox only |
| Required action | Append a fresh secret to git-ignored `.env` (runbook: `randomBytes(24)` / `openssl rand -hex 32`) — **executed in-recovery** (value generated inline, never printed, never committed; `.env` is git-ignored by the Phase-1 F-04 purge) |
| Responsible party | Operations |
| Production risk | Production provisioning documented **without execution** (mission §17 forbids creating production secrets): set via the deployment platform's secret store before first boot |

### R-E4 — `db/backups/` wiped
| Field | Finding |
|---|---|
| Actual condition | The documented snapshot directory was empty at mission start (same reset class) |
| Required action | `bun run db:snapshot` before risky DB work — **executed in-recovery** (`db/backups/custom-20261102-152228.db` of the pre-recovery file) |
| Classification | Environment, trivial |

### R-E5 — "WAL configuration disabled" (audit claim — precisely classified)
| Field | Finding |
|---|---|
| Actual condition (verified) | `PRAGMA journal_mode` = **`delete`** — the SQLite default; no `-wal`/`-shm` sidecars; **nothing in source/config/migrations ever sets it** |
| Evidence | Agent 4 §7 |
| Technical impact | None on integrity (integrity_check ok); a durability/concurrency posture difference only |
| Environment affected | Local sandbox dev file |
| Required action | **Documented, deliberately NOT executed** (mission Phase-5 D: "Do not modify live database configuration"): the operational action is `PRAGMA journal_mode = wal` on the DB file, matching `DATABASE_ARCHITECTURE.md`'s WAL posture claim |
| Responsible party | Operations |
| Production risk | P3 — include `journal_mode=wal` in the deployment checklist |
| **Classification of the audit's claim** | The audit's "WAL disabled/off" is a **SQLite `journal_mode` finding, loosely worded** — the auditors probed the SQLite file and contrasted `delete` with the repo doc's "WAL" posture claim. **No PostgreSQL `wal_level`/`archive_mode`/WAL-archiving concept is involved anywhere** (verified: no such references exist in the repo). The mission's suspicion ("do not describe PostgreSQL WAL as simply disabled") was correct to demand precision: the precise finding is *SQLite journal_mode=delete on a re-provisioned dev file where the never-repo-enforced WAL pragma reverted to default* |

### R-E6 — Authenticated testing blocked (consequence of R-E1+R-E3)
| Field | Finding |
|---|---|
| Actual condition | All authenticated test items were BLOCKED at audit time (empty DB + no secret → no login) |
| Required action | Resolve R-E1/R-E3 then re-run — **executed in-recovery**: authenticated verification now complete (login 200; 12 views ×3 langs browser-verified; RBAC negatives live; golden-path smoke; see BROWSER_QA_REPORT Part 2) |
| Classification | Environment (transient), resolved |

## Source-vs-environment classification verdict

| Audit-reported defect | Class | Disposition |
|---|---|---|
| 20 TypeScript errors / build failure | **Source** (contamination files) | Fixed by the D-040 sweep (this mission) |
| Localization corruption (46 % / 849 raw points / 12 views) | **Source** (monolith shadow) | Fixed by the sweep; browser-verified 0 raw keys |
| `/api/journey/export` 500 + global poisoning | **Source** (zombie route) | Fixed by the sweep (honest 404; no poisoning) |
| Empty database | **Environment** (R13) | Recovered (seed; 8/43/21/… baseline) |
| `ASAS_SESSION_SECRET` missing | **Environment** (R13) | Recovered (dev secret provisioned) |
| D12 index missing | **Environment** (migration unapplied) | Recovered (17/17 deploy; indexes verified) |
| WAL "disabled" | **Environment** (SQLite journal_mode) | Documented precisely; unmodified per mission |
| `_prisma_migrations` absent | **Environment** (R13) | Recovered (bookkeeping restored) |

**Production actions documented WITHOUT execution** (mission §17): production `migrate deploy` (D12 rides the chain), production secret provisioning via deployment secret store, `journal_mode=wal` in the deploy checklist, and the gateway/Caddy production posture. A successful source-code recovery does not imply production readiness — see the final report.
