# ASAS CRM — PHASE 2.1 — CRM DOMAIN REMEDIATION REPORT

**Agent 4 lane (W0-A4 investigation + Principal implementation)** · 2026-11-02

---

## 1. Investigation verdict

The domain layer is **unusually disciplined**: every entity's lifecycle is governed by a single server-enforced adjacency matrix or law table in `constants.ts` (with manager-gated, reason-gated correction hatches); the 8-stage journey is a pure derivation shared by server and client; mutation+trail atomicity is the norm; reporting reads the same constants as write paths. The residual risk concentrated in **seams between rules** — ownership cascades that moved opps but not tasks, half-updating contact stamps, duplicated stage literals, a nullable hold-expiry trusting UI prefill.

## 2. The customer lifecycle (as implemented + enforced, post-remediation)

```
LEAD:  NEW → CONTACTED → QUALIFIED → CONVERTED(terminal, /convert tx: Contact+Opp+flip+Activity+Audit)
       any-working → CLOSED_LOST (lostReason+lostAt required) → REACTIVATED → working
       Guards: LEAD_TRANSITIONS matrix; MANAGER+ correctionReason hatch; first-contact auto-advance
       (contact activity OR completed visit — W3-9 closes the visit gap).

OPPORTUNITY: NEW→QUALIFIED→VISIT_SCHEDULED→VISIT_COMPLETED→NEGOTIATION→OPTION→RESERVATION→CONTRACT→{WON|LOST}
       Forward skips legal; CLOSED_WON birth refused; booking auto-advances pre-booking stages (shared
       OPP_PRE_BOOKING_STAGES — W3-6); validate_closure couples CONVERTED→CLOSED_WON; sale-backed
       reopen refused; stageChangedAt on EVERY move (incl. convert-created — W3-8).

RESERVATION: ACTIVE →request_closure(agent, evidence)→ CLOSURE_REQUESTED →validate(MANAGER)→ CONVERTED
             [ONE tx: reservation + apartment SOLD + opp CLOSED_WON + FULL trail — W3-5]
             reject(MANAGER, reason)→ACTIVE; cancel(MANAGER, reason)→CANCELLED(+guarded release);
             expiry sweeper (lazy + 60s interval) → EXPIRED; floor-role bookings get server-side
             expiresAt default from org settings (W1-5 — immortal holds closed).

VISIT: SCHEDULED→{CONFIRMED(rep)|COMPLETED(outcome+report)|NO_SHOW|CANCELLED|RESCHEDULED|REJECTED(rep)}
       report immutable; COMPLETED stamps lead lastContactAt (+NEW→CONTACTED — W3-9) and auto-creates
       the FOLLOW_UP task in-tx.

TASK:  OPEN→{DONE|CANCELLED}; reopen(DONE/CANCELLED→OPEN) = owner-or-MANAGER correction (W3-4 matrix);
       FOLLOW_UP completion clears an overdue lead.nextFollowUpAt in-tx (W3-3b).
```

## 3. Implemented remediations

| ID | Finding | Fix | Verification |
|---|---|---|---|
| W3-1/A4#1 | **Bulk reassign didn't cascade opportunities** (single PATCH did — the two paths disagreed) | shared `reassignLeadCascade()` (open opps + OPEN tasks + future ACTIVE visits — W3-2 included) used by BOTH single PATCH and bulk assign | tsc; matrices covered by 33 tests |
| W3-2/A4#6 | **Reassign orphaned open tasks & visits** (new owner's My Day missed follow-ups) | tasks (OPEN) + visits (SCHEDULED/CONFIRMED, future) cascade in the same tx; terminal/DONE stay with history | same helper |
| W3-3/A4#4 | **nextFollowUpAt never auto-advanced** (journey urgency +100 forever after fresh contact) | contact activity clears OVERDUE nextFollowUpAt (future commitments preserved); FOLLOW_UP task completion clears it in-tx | code; journey tests cover urgency inputs |
| W3-4/A4#7 | **Task status machine ungated** (DONE→OPEN silently legal) | `TASK_TRANSITIONS` + `canTransitionTask`; illegal edge 422; reopen gated owner/MANAGER+ | `constants-matrices.test.ts` |
| W3-5/A4#8 | **Reservation money-trail not atomic** (logs written AFTER tx — crash window left CONVERTED sale with no trail) | ALL FOUR lifecycle actions (request/validate/reject/cancel) now write Activity+Audit INSIDE the tx | code (F-06 law now uniform) |
| W3-6/A4#9 | **Duplicated stage literals** (HOT_STAGES ×2; RESERVE_STAGES vs PRE_BOOKING_STAGES drift risk) | hoisted: `OPP_HOT_STAGES`, `OPP_PRE_BOOKING_STAGES`, `OPP_UI_RESERVE_ELIGIBLE` (the UI's deliberately narrower set documented as such) in constants.ts; 4 consumer sites converted | tsc; matrices tests |
| W3-7/A4#10 | **Closure UI re-implemented the lifecycle law by hand** | `canRequest/canDecide/canCancel` now derived from `RESERVATION_LIFECYCLE` | tsc |
| W3-8/A4#11 | **Convert-created opps lacked stageChangedAt** (kanban aging fell back to createdAt) | stamped in the convert tx | code |
| W3-9/A4#12 | **Visit completion didn't advance the lead** (NEW + lastContactAt:null while journey said VIEWING) | COMPLETED stamps lastContactAt + NEW→CONTACTED in the visit tx | code |
| W1-1/A4-adj | Merge orphaned SavCase | see DATABASE report | — |
| W2-10 | Lead.convertedAt first-class column | see DATABASE report | — |

## 4. FE/BE validation agreement (post-remediation)

- Opp stage change: FE and BE share the exact same imported matrix (parity by construction).
- Money: FE MoneyField strips minus signs; server now REJECTS negatives (422) — the server is no longer weaker than the client (W1-2).
- Reservation expiry: UI prefill + server default now agree (org setting is the single source).
- Lead create: client fullName min-2 vs server min-1 and local EMAIL_RE vs z.email — benign direction (server broader), documented, not forced.

## 5. Deferred (documented)

- Installments payable on non-CONVERTED reservations (A4#14) — **business decision required** (deposit-flow vs sale-backed échéancier); left as-is with the guard question recorded.
- Lead reactivate clears on-row lost fields (history preserved in AuditLog before-snapshot) — accepted design.
- Duplicate channels by phone/email (Lead unique only on (orgId, phone)) — accepted design (duplicates engine + KPI).
