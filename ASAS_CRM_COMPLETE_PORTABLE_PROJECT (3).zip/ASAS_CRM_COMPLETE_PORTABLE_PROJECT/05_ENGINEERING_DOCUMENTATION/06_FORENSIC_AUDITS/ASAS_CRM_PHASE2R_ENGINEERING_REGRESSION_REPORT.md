# ASAS CRM — Phase 2R Engineering Regression Audit Report

**Task ID:** 1-e (AGENT 5 — Architecture, Security & CRM Regression Audit)
**Mission:** ASAS CRM Phase 2R Recovery — verify previous Phase 2 engineering improvements (D1–D14) have NOT been lost, and that no architecture/security/CRM regressions exist vs the verified reference state.
**Mode:** STRICTLY READ-ONLY (no source edits, no git state changes, no builds, no DB mutations). Only this report file was created.
**Subject state:** `main` @ `693bff9` (HEAD) · reference = `b34d5b8` · contamination = `753d115` (adds-only) · `693bff9` = audit deliverables (adds-only).
**Date:** 2026-11-02 (this session).

Evidence classes used throughout: **VERIFIED** (first-hand command/file evidence quoted below) · **INFERENCE** (derived from verified facts) · **NOT VERIFIED** (runtime behavior not executable in this read-only audit).

---

## §1 Executive summary

1. **Reference-state integrity is mathematically intact** (§2): `git diff --name-status b34d5b8 HEAD` (unfiltered) = **114 entries, 100% `A`, 0 `M`, 0 `D`**. Every tracked file at the verified reference exists **byte-identical** at HEAD. Therefore **every D1–D14 change, every architecture invariant, every security control, and every CRM workflow that existed at `b34d5b8` exists verbatim at HEAD.** No engineering work was lost — the regression class is purely *additive contamination*, never modification.
2. **D1–D14: 14/14 PRESERVED** (§3). Each fix was located by reading the actual file at HEAD and confirmed identical to the reference via per-file `git diff b34d5b8 HEAD -- <file>` = empty (19 key files checked; trivially true for all tracked files given 0 M entries).
3. **All 9 architecture invariants (AGENTS.md:23–33) intact** (§4): data-route law, HMAC session, demo-mode gate + production fail-fast, RBAC (ROLE_CEILING/SELF_*/LAST_OWNER), reservation double-booking tx + lazy sweeper, enum-as-string, i18n single-source (modular system intact — the *monolith shadow* is the known contamination), frontend laws, same-origin enforcement.
4. **CRM business logic: no regressions** (§5) — 73 reference routes all present, byte-identical; the 4 extra routes are contamination zombies.
5. **First-hand static gates:** `bunx tsc --noEmit` = **exactly 20 errors, 100% in additive files** (journey-stats 3, input-otp 2, journey-worklist 1, 13 zombie ui components 1 each, journey-stage-chip 1). Zero errors in any reference-state file → deleting the contamination restores `tsc 0`. The independent audit's "20 tsc errors" claim is **CONFIRMED to the digit**.
6. **The i18n re-bind is safe** (§8): executed a read-only dictionary comparison — the zombie monolith has **1,013 keys/lang, the modular system 1,877 keys/lang, zombie-only keys = 0** (strict subset) → deleting `src/lib/i18n.ts` loses **zero** keys and gains 864/lang; all five symbols live code imports (`translate`, `dirFor`, `Lang`, `TextDir`, `TranslateFn`) exist in `src/lib/i18n/index.ts`/`types.ts`.
7. **Gate 5 verdict: SATISFIABLE by the planned recovery** (§9) — delete the 33 additive code files (+ disposition of the 64 orphan PNGs / audit docs), with the documented route-deletion restart protocol. The only live-code dependency on the additive set is `@/lib/i18n` (5 files), which re-binds safely. **No other live file imports any of the 33 files — verified by exhaustive import sweep.**

---

## §2 Reference-state integrity proof

**Commands executed (read-only):**

```
git rev-parse HEAD        → 693bff9f690f1d3f33c0785fc4539ee0c920c151
git rev-parse b34d5b8     → b34d5b84c6fbbe916ac5383ce953b6549bc8a299
git diff --name-status b34d5b8 HEAD          → 114 entries
git diff --name-status b34d5b8 HEAD | grep -c '^M' → 0
git diff --name-status b34d5b8 HEAD | grep -c '^D' → 0
git diff --name-status b34d5b8 HEAD | grep -c '^A' → 114
git diff --name-status b34d5b8 HEAD -- src/   → 29 A, 0 M, 0 D
git status --porcelain                       → only ?? (untracked Phase-2R sibling-agent reports under 05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/)
```

**VERIFIED facts:**
- 114 changes between reference and HEAD, **all additions**: 29 src files + `tailwind.config.ts` + 3 `tmp-scripts/*.ts` + 4 audit docs + 77 evidence PNGs (64 orphan + 13 independent-audit/qa evidence).
- **Zero modifications, zero deletions of any tracked file anywhere in the tree** (checked without path filter — expected 0, measured 0).
- Working tree clean of modifications (only untracked Phase-2R recovery reports from sibling agents — not tracked, not part of the diff).

**Corollary (the foundation of recovery):** because the diff contains only `A` entries, for EVERY tracked file F present at `b34d5b8`, `git diff b34d5b8 HEAD -- F` is empty — F is blob-identical at HEAD. This holds for all D1–D14 implementation files, all security modules, all CRM routes, the schema, and the 17-migration chain. **Statement made explicitly, as required.**

Blob-identity spot-proofs of the resurrected zombies (content-hash purity, per the D-040/D-041 law):
- `src/app/api/route.ts` @ HEAD sha256 `bb3323e7…` == `9d635d7^` (pre-P33 deletion) `bb3323e7…` — VERIFIED identical (scaffold deleted at 66b7c13 P2-era, re-deleted at 9d635d7 P33).
- `tailwind.config.ts` @ HEAD sha256 `ade68223…` == `ae9357f^` (pre-H2 retirement) `ade68223…` — VERIFIED identical.
- `src/lib/i18n.ts` deletion history verified (`ee04e81`/P32 among others) — consistent with the resurrection-class narrative.

---

## §3 D1–D14 preservation table

Canonical D-list source: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_CRM_DOMAIN_AUDIT.md` (defect definitions) + `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_REMAINING_DEFECTS_REGISTER.md` §3 (closure evidence) + `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_PHASE2_IMPLEMENTATION_PLAN.md` / `ASAS_CRM_PHASE2_EXECUTION_LOG.md` (W2.x/D12 waves) + `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_REMEDIATION_ROADMAP.md` (W2.1–W2.10 mapping). Every implementation file was READ at HEAD; every row's "identical" claim rests on the §2 proof (0 M entries) plus an explicit per-file `git diff --stat b34d5b8 HEAD -- <file>` = empty (all 19 files run: 0-line output).

| D# | Defect (one-line) | Implementation at HEAD (file:line, READ) | Present | Identical to b34d5b8 | Verdict |
|---|---|---|---|---|---|
| **D1** P1 | Reservation revival silently transfers old deal's Installment/Payment/SavCase + stale economics | `src/app/api/reservations/route.ts:241-259` (409 `RESERVATION_HAS_DEPENDENTS` guard: installment+payment+savCase counts, in-tx) + `:296-319` (FULL reset: 22 explicit nulls across commission/incentive/closure/converted families) | Y | Y (diff empty) | **PRESERVED** |
| **D2** P2 | Apartment PATCH coherence guard counted only ACTIVE — CLOSURE_REQUESTED hold destroyable | `src/app/api/properties/apartments/[id]/route.ts:58-79` (`status: { in: ["ACTIVE","CLOSURE_REQUESTED"] }` in the live-hold count; 422 `APARTMENT_RESERVATION_ACTIVE`) + booking-side mirror `reservations/route.ts:229-239` | Y | Y | **PRESERVED** |
| **D3** P2 | Opp→CLOSED_LOST allowed while live hold strands the unit | `src/app/api/opportunities/[id]/route.ts:168-188` (in-tx live-hold re-read; 422 `ACTIVE_RESERVATION_EXISTS`) | Y | Y | **PRESERVED** |
| **D4** P2 | Booking without opp-stage precondition + no one-live-hold-per-deal | `reservations/route.ts:192-203` (422 `OPPORTUNITY_NOT_BOOKABLE` for terminal stages) + `:262-283` (409 `OPPORTUNITY_ALREADY_BOOKED`, in-tx, excludes the row being revived) | Y | Y | **PRESERVED** |
| **D5** P2 | Lead reassign didn't cascade Opportunity.ownerId (kanban/drawer desync) | `src/app/api/leads/[id]/route.ts:328-360` (in-same-tx `updateMany` on non-terminal opps via shared `OPP_CLOSED_STAGES`; ASSIGNMENT activity + LEAD_ASSIGNED audit with `opportunitiesReassigned`) | Y | Y | **PRESERVED** |
| **D6** P2 | Create-opp dialog offered CLOSED_WON at birth (server always 422s) | `src/components/crm/pipeline/create-opportunity-dialog.tsx:224` (`OPPORTUNITY_STAGES.filter((s) => s !== "CLOSED_WON")`; W4.10 comment) + server-side `refuseBirthClosed()` `opportunities/route.ts:148` | Y | Y | **PRESERVED** |
| **D7** P3 | validate_closure didn't stamp opp stageChangedAt | `src/lib/server/reservation-lifecycle.ts:213` (`stageChangedAt: now` in the coupled CLOSED_WON update; W2.5/DOM-D7 comment) — with the known ND-B1 caveat (audit-row reachability), a pre-existing reference-state polish item, NOT a regression | Y | Y | **PRESERVED** |
| **D8** P3 | /reactivate violated tx law (update, then trail outside tx, no audit) | `src/app/api/leads/[id]/reactivate/route.ts:39-69` (mutation + Activity + AuditLog in ONE `db.$transaction`; guards `ALREADY_REACTIVATED`/`NOT_CLOSED_LOST`) | Y | Y | **PRESERVED** |
| **D9** P3 | Sweeper lazy — past-due/NULL-expiry holds immortal | `src/lib/server/expiry.ts` (idempotent, guarded updateMany, audited `RESERVATION_EXPIRED`, actor=null) + `src/lib/server/expiry-scheduler.ts` (HMR-safe globalThis singleton, 60s `.unref()` interval) + wiring: `notifications/route.ts:63` (awaited) & `reservations/route.ts:91` (awaited) + scheduler import `notifications/route.ts:17`. Runtime polling NOT VERIFIED by this audit (dev.log rotated; code wiring VERIFIED) | Y | Y | **PRESERVED** |
| **D10** P3 | cancel released apartment unconditionally (overwrote manual BLOCKED) | `reservation-lifecycle.ts:333-336` (guarded `updateMany` `where status:"RESERVED"`) + sweeper parity `expiry.ts:47-50` + audit-only-when-flipped `:347-361` | Y | Y | **PRESERVED** |
| **D11** P3 | Activity POST: lastContactAt outside tx; CALL on NEW didn't advance status | `src/app/api/leads/[id]/activities/route.ts:63` (NEW→CONTACTED advance rule) + `:70-146` (activity row + lastContactAt + status advance + STATUS_CHANGE activity + audit, all in ONE tx) | Y | Y | **PRESERVED** |
| **D12** P3→DB | No idempotency on timeline writes; concurrent twin race on live holds | App layer: `activities/route.ts:24,80-92` (5s in-tx twin guard, `deduplicated:true` 200 re-answer). DB layer: `prisma/migrations/20261102000000_phase2_d12_live_hold_unique/migration.sql` (READ verbatim: BOTH partial unique indexes `Reservation_apartment_live_hold_uq` / `Reservation_opportunity_live_hold_uq`, `WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')`) + `prisma/schema.prisma:607-615` comment + P2002→`ALREADY_RESERVED` mapping `reservations/route.ts:422-427`. Live-DB index presence = environment-class (R-E2, Agent 4's domain); repo artifacts VERIFIED | Y | Y | **PRESERVED** |
| **D13** P3 | Three inline "conversion" formulas + two aging semantics, drift-prone | `src/lib/metrics.ts` (READ whole file: `pct1`, `totalAgeDays`, `daysInStage`, `salesCycleDays`, `roundDays`; the three conversion questions + two aging semantics documented) + adoption VERIFIED: `api/dashboard/route.ts:24`, `api/analytics/route.ts:12` | Y | Y | **PRESERVED** |
| **D14** P3 | Journey rail fed approximated facts (lostAt:null, closedAt:stageChangedAt) | `src/lib/journey.ts:88,107` (facts types carry `lostAt`/`closedAt`) + true-fact supplier `api/journey/route.ts:145,155` (`lostAt: lead.lostAt?.toISOString() ?? null`, `closedAt: o.closedAt?.toISOString() ?? null`) + client rail `lead-journey-rail.tsx:93` (closedAt-first with documented fallback) | Y | Y | **PRESERVED** |

**Additional Phase 2 items verified (from the plan/log):** W2.2 production demo fail-fast — `session.ts:115-125` (`isDemoModeMisconfigured()` + one-time boot warn), `api/auth/login/route.ts:64-68` (500 `DEMO_MODE_PRODUCTION_MISCONFIG` on quick-login), `api/auth/session/route.ts:19-21` (demoUsers suppressed) — all PRESENT & identical. W2.3 SECURITY.md reference (not re-read; doc-class). R15 stage-constant dedup — `constants.ts:35,41` (`OPP_CLOSED_STAGES`, `ACTIVE_VISIT_STATUSES`, satisfies-typed) + adoption (`leads/[id]:336`, `opportunities/route.ts:64` via `[...OPP_CLOSED_STAGES]`) — PRESENT.

**D1–D14 verdict: 14/14 PRESERVED, zero LOST.**

---

## §4 Architecture invariants spot-check (AGENTS.md:23–33, the 9 laws)

| Law | Check performed (read-only) | Result |
|---|---|---|
| **a. Data-route law** (requireUser → zod → visibility-scoped query → side effects → ok/fail) | READ fully: `api/leads/route.ts` (requireUser:25; `[{orgId, ...leadScope(user)}]` base:33; zod parseBody on POST; logActivity/logAudit), `api/opportunities/route.ts` (requireUser:29; oppScope base:38; refuseBirthClosed:148), `api/reservations/route.ts` (requireUser:86/181; reservationScope base:99; parseBody:183; in-tx side effects + trail). Spot: tasks (`taskScope` base:28), visits (`visitScope` base:40), dashboard (fragments:72-75), audit (MANAGER gate:18), analytics (MANAGER gate:24), export/bundle (MANAGER gate:127). Scope composition law respected (fragments spread into base conditions; explicit `OR` never adjacent to a spread scope in the sampled routes — the search `OR` conditions are separate `conditions.push` entries composed under `AND`) | **INTACT (VERIFIED)** |
| **b. Session HMAC** | READ `src/lib/server/session.ts`: `signSession`/`verifySessionCookie` (HMAC-SHA256, 3-part cookie, `timingSafeEqual` on hex, strict shape regex), 7-day absolute expiry (:38,64), `passwordChangedAt` invalidation (:90), DUMMY-fallback secret with warn (:28-35). `getCurrentUser` strips passwordChangedAt before returning | **INTACT (VERIFIED)** |
| **c. Same-origin (D-018/19/20)** | `assertSameOrigin` defined `session.ts:238-262` (Sec-Fetch-Site same-origin/none allowance, Host + X-Forwarded-Host candidates, CROSS_ORIGIN_BLOCKED 403); called INSIDE `requireUser` (`session.ts:161`) AND inside `readJson` (`validation.ts:12`) — the two choke points; `clientIp` rightmost-only (`session.ts:181-184`) | **INTACT (VERIFIED)** |
| **d. RBAC (user management)** | `api/users/route.ts:65` (ROLE_CEILING create), `api/users/[id]/route.ts:48,54,57,75` (ROLE_CEILING / SELF_ROLE_CHANGE / SELF_DEACTIVATION / LAST_OWNER, precedence comment :45), `api/users/[id]/reset-password/route.ts:32` (ROLE_CEILING) | **INTACT (VERIFIED)** |
| **e. Enum-as-string (shared constants)** | READ `src/lib/constants.ts` index: `ROLES`, `LEAD_STATUSES`, `OPPORTUNITY_STAGES`, `OPP_CLOSED_STAGES`, `ACTIVE_VISIT_STATUSES`, `APARTMENT_STATUSES`, `VISIT_STATUSES`, `OPPORTUNITY_TRANSITIONS`, `TASK_TYPES/STATUSES`, `FOLLOW_UP_OUTCOMES`, `OUTCOME_BEARING_TYPES`, `ACTIVITY_TYPES`, `SAV_STATUSES`, `RESERVATION_STATUSES`, `RESERVATION_LIFECYCLE` — all exported from the single source; zod validation via qpEnum/parseBody at the routes | **INTACT (VERIFIED)** |
| **f. i18n single-source (modular)** | `src/lib/i18n/domains/` = 21 domain modules + `index.ts` (composition root with duplicate-key fail-fast) + `types.ts` — all present & identical. The known contamination: `src/lib/i18n.ts` (3,253-line monolith, additive zombie) shadows `@/lib/i18n` for 5 live importers via file-before-folder resolution — being removed in recovery; **the modular system itself is untouched and orphaned-at-HEAD, not damaged** | **SYSTEM INTACT (VERIFIED); shadowing = contamination runtime effect, not lost work** |
| **g. Frontend laws** | react-query in views (leads-view 6 hooks, journey-view 2); `crm/states.tsx` ErrorState/EmptyState present, adopted by 8+ components (lead-tab-*, team-section, entity-documents, duplicates-dialog, detail drawer); semantic type scale + oklch tokens live in `globals.css` (`@import "tailwindcss"` + `tw-animate-css`, Noto Sans Arabic self-hosted) | **INTACT (VERIFIED, spot-level)** |
| **h. Reservation double-booking (D-008 law) + lazy expiry sweeper** | `reservations/route.ts:205-420`: apartment re-read INSIDE `db.$transaction` (:209), AVAILABLE check (:211), live-hold re-check (:225-239), one-hold-per-deal (:268-283), apartment flip + in-tx trail + fault hooks. Sweeper: `expiry.ts` awaited at reservations GET:91 + notifications GET:63, idempotent, audited, guarded release parity with D10. D12 partial unique indexes = the absolute backstop (repo artifacts verified §3) | **INTACT (VERIFIED)** |

**Invariant-9 (request forgery)** covered under (c). **Invariant-3 (demo-mode gate)**: `isDemoMode()` `session.ts:103-105` default-ON sandbox law intact; production fail-fast W2.2 intact (§3 addendum).

---

## §5 CRM business logic verification (read-only code review)

**Route census:** `git ls-tree -r HEAD src/app/api` = **74 route.ts files = 70 reference routes + 4 additive zombie routes** (`api/route.ts`, `journey/export`, `leads/check-duplicates`, `properties/unit-types`). All 70 reference routes present; `requireUser(` adoption = **70 files**; the only routes without it are the 3 pre-auth routes (`auth/login`, `auth/logout`, `auth/session` — by design; login/logout/session handle cookie establishment) + the zombie `api/route.ts`. This reproduces the independent audit's "70/74" figure exactly — **with the 4th non-guarded route being the contamination's junk endpoint, not reference code**.

**Domain-by-domain (all byte-identical per §2; presence + key laws re-read):**

| Domain | Evidence READ at HEAD | Status |
|---|---|---|
| Lead lifecycle — convert | `leads/[id]/convert/route.ts`: D-021 scoped findLead, `ALREADY_CONVERTED` 409, contact+opportunity+lead-flip+activity in ONE tx (F-06 + fault hook) | VERIFIED intact |
| Lead lifecycle — reactivate | `reactivate/route.ts` (D8, §3) | VERIFIED intact |
| Lead ownership / visibility | `lib/server/visibility.ts` READ whole: leadScope/taskScope/oppScope/visitScope/contactScope/activityScope/reservationScope/installmentScope/savScope/documentScope/canConfirmVisit/assertLeadVisible — all fragments present; OWN+POOL for agents, project-derived for FIELD_REP, undefined for MANAGER+ | VERIFIED intact |
| Opportunities + pipeline | `opportunities/route.ts` (birth gates, terminal discipline) + `opportunities/[id]/route.ts` READ whole: OPPORTUNITY_TRANSITIONS adjacency guard, manager correction escape hatch + `OPPORTUNITY_STAGE_CORRECTED`, §9.2 desync law (`OPPORTUNITY_BACKED_BY_SALE`), D3 guard, closure visit gate (`assertClosureVisitGate` :166), LOST_REASON_REQUIRED, ownerId MANAGER-gate, DELETE discipline (NEW/CLOSED_LOST only, HAS_RESERVATIONS) | VERIFIED intact |
| Activities | `leads/[id]/activities/route.ts` (D11 + D12 twin guard, §3); OUTCOME_TYPE_MISMATCH law | VERIFIED intact |
| Tasks / Visits | `tasks/route.ts` (requireUser:20, taskScope base:28, parseBody POST:81), `visits/route.ts` (requireUser:32, visitScope base:40) — pattern + scope laws intact | VERIFIED intact |
| Reservations (D-008 law + lifecycle) | `reservations/route.ts` (booking tx, §3/§4h) + `reservation-lifecycle.ts` READ whole (4 actions: request/validate/reject/cancel; authority→source-state→prerequisite guard chain; status-preconditioned claim = idempotent money-state event; guarded release) | VERIFIED intact |
| Apartments | `properties/apartments/[id]/route.ts` (D2 + P47 server-side MANAGER gate + FORBIDDEN_TRANSITIONS + in-tx audit) | VERIFIED intact |
| Journey engine | `lib/journey.ts` (pure engine, facts types incl. D14) + `api/journey/route.ts` (true-fact supplier, lead-scope law, ONE batched reservation join — no N+1) + `api/journey/stats/route.ts` imports from `@/lib/journey` (the REAL engine — not the zombie modules) | VERIFIED intact |
| Reports / analytics | `api/analytics/route.ts` (MANAGER gate:24, metrics.ts adoption:12), `api/dashboard/route.ts` (visibility fragments, R15 trends), `api/export/bundle/route.ts` (MANAGER gate:127) | VERIFIED intact |
| Notifications + expiry | `notifications/route.ts:63` awaited sweeper + `:17` scheduler import | VERIFIED intact |
| Users / RBAC | §4d | VERIFIED intact |
| Role-aware DTO (Workstream S) | `reservations/route.ts:153-162` — `reservationDtos(user, data)` serialization before every GET response variant + POST 201 (`reservationDto` :434); `lib/server/reservation-dto.ts` present (not re-read in full — byte-identical per §2) | VERIFIED intact |

**Conclusion: no CRM business-logic regression exists vs the reference.** The independent audit's Auditor-E verdict ("12/12 areas verified, none of the logic files touched by 753d115") is **CONFIRMED** by my independent re-reading.

---

## §6 Additive-files security review (the only new attack surface)

The 33 additive code files (29 src + `tailwind.config.ts` + 3 `tmp-scripts`) — all read/inspected:

| Surface | Finding | Severity |
|---|---|---|
| **`src/app/api/route.ts`** (GET /api) | READ: 5 lines returning `{message:"Hello, world!"}`. **Unauthenticated, zero auth, zero data access** — no session read, no DB, no mutation, no secret. Blob-identical to the scaffold deleted at 66b7c13 (P2-era) and 9d635d7 (P33). Junk public surface that violates the fail-closed posture (the only non-pre-auth route without requireUser) — but leaks nothing | **P3 (junk endpoint)** — CONFIRMED, inert data-wise |
| **`api/leads/check-duplicates/route.ts`** | `requireUser()` at :12 — authenticated; never wired to any client (D-042 dead endpoint) | Inert (authenticated) |
| **`api/properties/unit-types/route.ts`** | `requireUser()` at :8 — authenticated; never wired | Inert (authenticated) |
| **`api/journey/export/route.ts`** | `requireUser("MANAGER")` at :56 (MANAGER+ enforced per its code) — but **compile-broken**: its dependency `journey-worklist.ts:26` imports `isJourneyStalled` from `@/lib/journey`, which does NOT export that symbol (rg over src finds `isJourneyStalled` ONLY inside journey-worklist.ts itself — stale import CONFIRMED). This broken module is the trigger of the dev-server global API poisoning (audit's ND-A3; mechanism VERIFIED in code; the poisoning phenomenon itself NOT VERIFIED at runtime by this read-only audit — consistent with the module-resolution failure and with the current dev.log still carrying 2 `journey-worklist.ts` compile-error occurrences) | Broken zombie (P1 via ND-A3 mechanism) |
| **17 resurrected ui components + 2 hooks** | **Import sweep (exhaustive):** no LIVE file imports any of them. The only cross-references are zombie↔zombie: `toast` ← `use-toast.ts`; `use-mobile` ← `ui/sidebar.tsx`; `use-toast` ← `ui/toaster.tsx`. No live ui component imports any zombie module (checked every non-zombie `src/components/ui/*.tsx`); no file under `src/app/page.tsx`, `src/components/crm/**`, `src/lib/**` imports any zombie path (full-pattern sweep = empty). 16 referenced packages are uninstalled → 15 of the 20 tsc errors | **INERT (VERIFIED)** — dead code only |
| **`src/lib/i18n.ts`** (monolith) | READ head/exports: pure data+type module (`Lang`, `TextDir`, `dirFor`, `dictionaries`, `TranslateFn`, `translate`), zero imports, zero security-relevant surface. Harm = dictionary key shadowing only (text layer) | No security surface (CONFIRMED) |
| **`tailwind.config.ts`** | READ: v3-style JS config importing `tailwindcss-animate`. **Not loaded by the live pipeline**: `postcss.config.mjs` registers only `@tailwindcss/postcss`; `globals.css` is CSS-first (`@import "tailwindcss"` + `@import "tw-animate-css"`); NO `@config` directive anywhere; NO file imports the config (rg = empty). The Tailwind-4 toolchain nevertheless probes the root JS config when it exists → dev.log carries 42 `tailwindcss-animate` module-not-found warnings (⚠ non-fatal for CSS generation; log pollution). Blob-identical to the pre-H2 retired version | **No runtime CSS effect; log pollution only (VERIFIED)** |
| **3 tmp-scripts** (`census.ts`, `r10-seed-won.ts`, `recent-audits.ts`) | Standalone bun scripts importing `@prisma/client` only; outside the Next build graph; never referenced by src | Inert |

**Net new attack surface = one unauthenticated 5-line static JSON endpoint (P3) + two authenticated-but-dead endpoints + one compile-broken MANAGER-gated route.** No new data exposure, no auth logic changes, no new mutation paths reachable by clients.

---

## §7 Audit-claims cross-check (independent audit's regression claims)

Sources: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_INDEPENDENT_AUDIT_REPORT.md` + `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_REMAINING_DEFECTS_REGISTER.md` + (cross-refs) `ASAS_CRM_FINAL_READINESS_ASSESSMENT.md`, `ASAS_CRM_PHASE_ACCEPTANCE_MATRIX.md`.

| # | Audit claim | My verdict | My evidence |
|---|---|---|---|
| 1 | "Build fails at HEAD — 20 tsc errors → next build aborts; CI red" (ND-A1) | **CONFIRMED (to the digit, first-hand)** | `bunx tsc --noEmit` → exactly **20 errors**, file-attributed 100% to additive files: journey-stats 3, input-otp 2, journey-worklist 1, 13 zombie ui ×1, journey-stage-chip 1. Zero errors in reference files. Build-abort is INFERENCE from tsc + `ignoreBuildErrors` absent (next.config.ts READ — not present); build itself not run (house law) |
| 2 | "i18n text layer broken — zombie shadows modular dict; 849/2,055 render sites raw; 12 views; a11y labels raw" (ND-A2) | **CONFIRMED as contamination runtime effect / REFUTED as lost engineering work** | Mechanism VERIFIED: `@/lib/i18n` bound to the monolith for the 5 live importers incl. `store.ts:10` (runtime import of translate/dirFor); strict-subset property VERIFIED BY EXECUTION: 1,013 vs 1,877 keys/lang, zombie-only = **0**. The 849-site/12-view counts are the audit's measurements — consistent (INFERENCE), not re-counted by me. **The modular i18n system is intact and byte-identical — no i18n engineering lost** |
| 3 | "Dev-server global API poisoning via /api/journey/export — one request degrades every subsequent API request to 500 HTML" (ND-A3) | **PARTIAL (mechanism CONFIRMED in code; phenomenon NOT re-reproduced by this read-only audit)** | Stale `isJourneyStalled` import VERIFIED (§6); current dev.log still carries the `journey-worklist.ts` compile error (2 occurrences — log since rotated from the audit's 203). The poisoning is the documented dev-mode sticky module-resolution failure — credible, consistent, not re-executed |
| 4 | "D1–D14 fixed with file:line; closure gate on all 3 CLOSED_WON paths" | **CONFIRMED** | §3 table (14/14 re-read). Third closure path verified: `opportunities/route.ts:148` `refuseBirthClosed()` + `[id]:166` `assertClosureVisitGate` + `reservation-lifecycle.ts:177` `assertClosureVisitGate` |
| 5 | "D12 partial unique indexes MISSING from live DB; _prisma_migrations absent; DB empty" (R-E1/R-E2) | **CONFIRMED as environment-class; repo artifacts intact** | Migration #17 + schema comment VERIFIED verbatim in repo (§3). Live-DB state is Agent 4's domain (DATABASE_ENVIRONMENT report); my read-only check of `.env` shows `ASAS_SESSION_SECRET` ABSENT (R-E3 CONFIRMED current). Not a code regression — the reference never carried these DB rows either post-reset |
| 6 | "RLS runtime NOT VERIFIED" (R-C2) | **CONFIRMED (still true; N/A on SQLite)** | PG-side only; not a regression of reference code |
| 7 | "SEC-V01 production fail-fast code-verified (session.ts:115-117)" | **CONFIRMED** | Read at :115-125 + login route :64-68 + session route :19-21 (§3) |
| 8 | "70/74 routes through requireUser" | **CONFIRMED with precision: 70/70 reference authed routes guarded; the 4 unguarded = 3 pre-auth (login/logout/session) + 1 zombie junk endpoint** | §5 census |
| 9 | "ND-B1 oppBefore post-tx read → unreachable audit row; ND-B2 request/reject_closure outside tx law" | **CONFIRMED as NEW pre-existing reference-state defects — NOT regressions** (existed verbatim at b34d5b8) | `reservation-lifecycle.ts:225-228` (post-tx read) and :123-159/:279-315 (no $transaction wrapper) — both READ; identical to reference per §2 |
| 10 | "ND-B3 PG chain missing per-opportunity live-hold index while schema.postgres.prisma claims both" | **CONFIRMED (pre-existing reference gap, not a regression)** | `schema.postgres.prisma:611-617` READ (claims both deploy); supabase chain grep: only `Reservation_apartmentId_active_key` (`20261030000002_business_constraints.sql:68`) — no opportunity-index |
| 11 | "Governance hole — 753d115/ffa3a843 recorded nowhere in worklog" (ND-A5) | **CONFIRMED** | `rg -c "753d115|ffa3a843" worklog.md` = 0 |
| 12 | "Zombie set = resurrected files blob-identical to pre-deletion versions" | **CONFIRMED (spot-verified 2 of them; Agents 1-2 hold the full 26-file proof)** | api/route.ts + tailwind.config.ts sha256-identical to pre-deletion blobs (§2) |
| 13 | "The commit escapes worklog governance / violates D-040/D-041" | **CONFIRMED** | AGENTS.md:17 law READ; adds-only diff VERIFIED |
| 14 | "Underlying Phase 0/1/2 engineering merits acceptance at b34d5b8; recovery = one sweep session" | **CONFIRMED — and strengthened by my diff-level proof that HEAD's tracked content is byte-identical to b34d5b8** | §2 |

**Cross-check conclusion (as the mission predicted):** every "regression" claim resolves to the **contamination's runtime effects** (tsc/build break, i18n shadowing, API poisoning, junk endpoint) or to **environment-class** conditions (empty DB, missing indexes/secret) — **none resolves to lost or damaged reference-state engineering work.** The audit's new engineering defects (ND-B1/B2/B3…) are genuine but pre-existing at the reference (newly *discovered*, not *introduced*).

---

## §8 Recovery risk analysis — import graph of the 33 additive files

**Who imports whom (exhaustive, verified by rg sweeps):**

```
LIVE CODE (reference, 73 routes + ~150 components + lib)
  └─ imports additive set ONLY via '@/lib/i18n'  →  resolves FILE-first to src/lib/i18n.ts (the zombie monolith)
       • src/lib/client/store.ts:10   → RUNTIME: { translate, dirFor } + types { Lang, TextDir, TranslateFn }
       • src/lib/format.ts:14              → TYPE-ONLY: Lang
       • src/components/crm/money-field.tsx:39        → TYPE-ONLY: Lang
       • src/components/crm/documents/shared.tsx:13   → TYPE-ONLY: TranslateFn
       • src/components/crm/bulk-copilot-dialog.tsx:40 → TYPE-ONLY: TranslateFn
  └─ imports NOTHING else from the additive set (full-pattern sweep over page.tsx / components/crm / lib /
     every non-zombie components/ui file → EMPTY)

ADDITIVE SET (33 files)
  ├─ zombie ui (17) + hooks (2): referenced ONLY zombie↔zombie
  │     toast ← use-toast.ts ; use-mobile ← sidebar.tsx ; use-toast ← toaster.tsx
  │     (+ their imports of LIVE modules: ui/button etc., and 16 UNINSTALLED packages — the tsc errors)
  ├─ journey orphans: journey-stats.ts + journey-facet.ts ← imported by NOBODY (dead);
  │     journey-worklist.ts ← imported ONLY by api/journey/export/route.ts (zombie→zombie);
  │     journey-stage-chip.tsx + view-placeholder.tsx ← imported by NOBODY
  │     (note: journey-performance.tsx's `queryKey: ["journey-stats"]` is a react-query STRING key —
  │      its fetch target is the LIVE /api/journey/stats — NOT an import of the zombie module)
  ├─ 4 zombie routes: framework-auto-mounted endpoints (api/, journey/export, check-duplicates, unit-types)
  ├─ tailwind.config.ts: imported by NO source file; probed by the Tailwind toolchain only
  └─ 3 tmp-scripts: standalone, outside the build graph
```

**Deletion side-effect analysis:**

1. **i18n re-bind (the intended effect):** after `git rm src/lib/i18n.ts`, `@/lib/i18n` resolves to `src/lib/i18n/index.ts` (folder index). **VERIFIED SAFE:**
   - All five symbols exist in the modular system: `translate` (index.ts:82), `dirFor` (index.ts:93 re-export of types.ts:15), `Lang`/`TextDir`/`TranslateFn` (types.ts:3/6/13, re-exported index.ts:94). `translate`/`dirFor` are real functions (runtime-checked via bun import).
   - **Zero key loss — strict-subset property re-verified by execution** (read-only dictionary comparison): zombie 1,013 keys/lang ⊂ modular 1,877 keys/lang; zombie-only keys = **0** for fr/en/ar. Post-deletion the app GAINS 864 keys/lang (the journey/sav/visits/finance/leads families the audit enumerated).
   - The type-only importers (format.ts, money-field, documents/shared, bulk-copilot-dialog) resolve identically in the modular system.
2. **No other live importer exists** — exhaustively swept (§6/§8 graph). Deleting the other 32 files breaks no live import.
3. **tsc restoration:** all 20 errors are inside additive files → deleting the set returns `bunx tsc --noEmit` to 0 (VERIFIED by per-file error attribution; the two zombie routes that themselves typecheck — export route + check-duplicates + unit-types + api/route.ts — are also removed, taking their broken dependency chain with them).
4. **Route-deletion operational law (AGENTS.md:17):** deleting route modules requires the restart-with-cleared-`.next` protocol (stale generated route-type validator; kill stale next-server by PID from `ss -tlnp`). This is a recovery-runbook step, not a code risk. (NOT VERIFIED at runtime here — read-only audit.)
5. **tailwind.config.ts deletion:** removes the dev.log `tailwindcss-animate` module-not-found warnings; **no CSS behavior change** — the live pipeline is CSS-first (`@import "tailwindcss"` in globals.css; postcss registers only `@tailwindcss/postcss`; no `@config`; no importer). VERIFIED.
6. **Dev.log / API surface:** removing `journey/export` eliminates the poisoning trigger and its compile-error log class; removing `api/route.ts` closes the unauthenticated junk endpoint (GET /api → 404 again).
7. **Residual disposition items (outside my lane):** 64 orphan PNGs under evidence/ + the 4 audit docs in 05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ (the audit docs are legitimate deliverables committed at 693bff9; the PNGs are orphaned evidence of the zombie journey work — disposition per the Principal/Agent 1).

**Verdict: deletion of the 33 additive code files is side-effect-free for live code except the intended, verified-safe i18n re-bind.**

---

## §9 Gate 5 verdict (Engineering Integrity)

Gate 5 as defined by the mission — *previous architecture improvements preserved; D1–D14 verified; database/schema consistency maintained; security improvements preserved; CRM core workflows correct; no critical regressions introduced* — **CAN BE SATISFIED by the planned recovery (delete the 33 additive code files + the documented restart protocol), on the following per-condition basis:**

| Gate 5 condition | Verdict | Basis |
|---|---|---|
| Previous architecture improvements preserved | **YES — PROVEN** | §2: 0 M / 0 D in b34d5b8→HEAD; every reference file byte-identical at HEAD |
| D1–D14 verified | **YES — 14/14** | §3: every fix READ at HEAD with file:line + per-file empty diff |
| Database/schema consistency maintained | **YES at repo level** (schema.prisma, schema.postgres.prisma, 17-migration chain incl. D12 #17 — all intact, byte-identical). Live-DB re-provisioning (migrate deploy 17/17 + seed + indexes + secret) is the R13 runbook — Agent 4's verified domain, environment-class, not a code regression | §2/§3; R-E1/E2/E3 confirmed current |
| Security improvements preserved | **YES** | §4b/c/d + W2.2 fail-fast + role-aware DTO + 70/70 reference routes guarded; the only security-adjacent additions are the P3 junk endpoint and dead-but-authenticated endpoints — all removed by the sweep | 
| CRM core workflows correct | **YES (code-level)** | §5: all lifecycle/ownership/pipeline/report surfaces present and byte-identical; runtime re-verification gated on DB recovery (as at every prior round) |
| No critical regressions introduced | **YES, POST-RECOVERY** | The only regressions at HEAD are the contamination's effects (20 tsc errors, i18n shadowing, API-poisoning trigger, junk endpoint) — all eliminated by deleting the 33 files (§6/§7/§8). Zero reference regressions exist (§2) |

**Recovery risks identified (all mitigated):** (1) i18n re-bind — verified safe (§8.1); (2) route deletions need cleared-`.next` restart — documented house protocol; (3) nothing else imports the additive set — exhaustively verified. No code-level risk to the reference was found.

**Gate 5: PASS conditional on executing the planned deletion (engineering-integrity dimension).** Runtime re-verification (browser matrix, 333-probe standing matrix, golden-path E2E) remains the post-recovery protocol per the mission plan.

---

## §10 Read-only attestation

- **No file was created or modified except this report** (`05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_PHASE2R_ENGINEERING_REGRESSION_REPORT.md`).
- **No git state changes**: no commits, no adds, no branch/tag operations — `git status --porcelain` before/after shows only pre-existing untracked sibling-agent reports plus this file.
- **No `bun run build`** (forbidden). `bunx tsc --noEmit` was executed as a read-only static gate (no artifacts emitted); one read-only `bun -e` dictionary comparison imported source modules without writing anything.
- **No DB access** beyond reading repo files; no curl against live endpoints; no dev-server interaction.
- Tools used: `git` (read-only: rev-parse/log/ls-tree/diff/show/status), `rg`, file reads, `bunx tsc --noEmit`, `bun -e` (read-only module evaluation).

**Facts marked VERIFIED vs INFERENCE vs NOT VERIFIED** — applied throughout (§1–§9). Summary of the NOT-VERIFIED set: runtime API-poisoning reproduction (mechanism only), runtime sweeper polling, the audit's 849-render-site count (mechanism + strict-subset math verified instead), live-DB index presence (Agent 4's report covers it), production-build abort (deterministic inference from tsc + absence of `ignoreBuildErrors`).

**Contradictions / observations found:**
1. **Taxonomy bookkeeping (minor, no substance):** the Principal's brief says "3 tmp-scripts" in one place and "2 tmp-scripts" in another; the repo has **3** (`census.ts`, `r10-seed-won.ts`, `recent-audits.ts`). Total additive code files = **33** (29 src + tailwind.config.ts + 3 tmp-scripts). The "26 zombies + 5 journey orphans + 2 tmp-scripts = 33" split undercounts tmp-scripts by one and counts `view-placeholder.tsx`/`journey-stage-chip.tsx` differently than the audit's "5 resurrected + 6 journey + 18 template" split — same total, different bins.
2. **AGENTS.md invariant 5 wording is stale w.r.t. D12** (pre-existing at the reference, NOT a regression): it says "uniqueness is NOT a DB index anymore (D-008)" — D12 later added *partial* unique indexes as the absolute backstop (the global-index ban stands). The authoritative current law lives in `schema.prisma:607-615` and migration #17's header; `reservations/route.ts:10-17`'s "migrate to a partial unique index on PostgreSQL" comment is likewise pre-D12 stale. Cosmetic doc drift only.
3. **dev.log has rotated since the independent audit** (203 journey-worklist occurrences → 2 now; mtime Nov 2 15:06). The error class remains observable; no contradiction with the code-level findings.
4. No contradiction with Agents 1-4's reported findings was encountered; the adds-only purity, blob-identity, zombie inertness, and i18n shadowing all re-verified first-hand.

---

*AGENT 5 — end of report. The engineering base at `b34d5b8` is fully intact at HEAD `693bff9`; every defect at HEAD is additive contamination or environment-class. Delete the 33, run the restart protocol, and Gate 5's engineering-integrity conditions are met.*
