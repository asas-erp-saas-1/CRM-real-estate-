# ASAS CRM — PHASE 2.2 PERFORMANCE & QA REPORT

**Task owner:** Principal · **Status: VERIFIED**

## 1. Performance findings (measured, not claimed)

| Surface | Measurement | Result |
|---|---|---|
| `GET /api/customers` (20-contact book, full fact projection + batched reservations) | dev-server log | **200 in 18ms** |
| Query count per customers request | Prisma log | 2–3 statements (contacts + reservations [+ search probe]) — no N+1 |
| Leads KPI strip | request count | **0 new requests** (rides `["dashboard","30d"]` + `["notifications"]` caches — same keys/queryFns) |
| Pipeline column stats + card badges | new API fields | **0** (client-side derivation from already-fetched `stageChangedAt`) |
| Customers view chunk | lazy per-view split | separate chunk compiled + loaded on first navigation (W5-2 law preserved) |
| Bundle | no new dependencies added | `package.json` unchanged this phase |

No before/after percentage claims are made beyond these measured facts (the
anti-fabrication law).

## 2. Test suite

`bun run test` → **9 files, 163/163 passed** (0 skipped — dev server reachable):
- Unit: phone 17, i18n 10, visibility 14, validation 14, + journey/metrics/constants suites.
- Contract (live server): session-gate negatives, JSON 404, health envelope
  (updated for truthful null-migrations), bogus login, app shell — **plus new**:
  customers 401 gate, gate-ordering, manager envelope + KPI consistency + row
  contract + idle-facet consistency, unassigned facet gate.
- Regression: zero previously-passing tests broken.

## 3. Lint / type gates

- `bun run lint` → 0 findings (one `set-state-in-effect` violation caught and
  fixed during implementation — page reset moved into the input handler).
- `bunx tsc --noEmit` → exit 0 (strict; no `any`, no `@ts-ignore`).

## 4. Browser QA (agent-browser, this session)

- **Flows verified**: login (demo persona + credentials), manager dashboard →
  all 7 views sweep, leads KPI strip + row actions, pipeline monitoring,
  customers list → idle filter → 360 drawer → escape → re-toggle, user switch
  (manager → agent), agent My-Day framing + scoped customers, AR RTL switch,
  hash deep-link persistence across reload.
- **Console**: after clearing mid-edit Fast-Refresh artifacts, current state is
  clean (no console errors, no page errors) — stale entries explained and
  re-verified on a fresh reload.
- **Bugs found & fixed during QA**: (1) double-`?` in customers query URL
  (silent default-masking — caught via network log, fixed, re-verified);
  (2) `/api/health` false "degraded" on push-based DBs (fixed with the
  SELECT 1 / bookkeeping split).

## 5. Remaining defects register

| ID | Defect | Severity | Status |
|---|---|---|---|
| P2.2-R1 | Finance/SAV dashboard attention cards land unfiltered (component-local bucket state, no transient token — the `pipelineFocus` pattern not yet applied) | Low | DEFERRED (documented; needs a shared store extension) |
| P2.2-R2 | Customers workspace state is component-local (dies on view switch — same behavior as journey/sav; lift to workspace-store only if amnesia is observed in daily use) | Low | DEFERRED (deliberate, documented) |
| P2.2-R3 | `ASAS_SESSION_SECRET` not set in this sandbox → sessions reset on server restart (environment, not source; production fail-fast already exists) | Env | OPEN (ops) |
