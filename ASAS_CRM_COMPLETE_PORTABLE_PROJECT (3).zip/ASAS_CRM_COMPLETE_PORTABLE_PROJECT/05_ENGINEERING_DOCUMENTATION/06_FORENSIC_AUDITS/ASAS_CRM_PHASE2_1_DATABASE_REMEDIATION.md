# ASAS CRM — PHASE 2.1 — DATABASE REMEDIATION REPORT

**Agent 2 lane (W0-A2 investigation + Principal implementation)** · 2026-11-02
**Baseline**: 17/17 migrations applied (post-reset replay), D12 partial uniques live, integrity_check ok, foreign_key_check empty.

---

## 1. Investigation verdict

The database is **structurally healthy**: schema↔migrations↔live-DDL agree endpoint-to-end; the FK-action matrix is a deliberate three-tier policy (RESTRICT business anchors / SET NULL attribution stamps / CASCADE pure junctions); D12 live-hold invariants are DB-enforced with verified semantics; every mutation folds Activity+AuditLog into the same transaction; index coverage cross-check found **no justified missing index** for any hot filter. The material risks were narrow: one real bug (merge→SavCase), one precision hazard (Float money + 1e-9 epsilon), and scale-dependent items.

## 2. Implemented remediations

| ID | Finding | Fix delivered | Verification |
|---|---|---|---|
| W1-1/A2#1 | **Merge orphans SavCase** — `merge/route.ts` re-pointed 9 child tables but not `SavCase.leadId` (FK SET NULL → silent detach on absorbed-lead delete) | `tx.savCase.updateMany` joins the re-point set; `moved.savCases` in the Activity body + audit payload | tsc; merge route contract unchanged |
| W1-2/A2#2 | **Money guard mis-scaled** — payments epsilon `1e-9` below REAL float noise at DZD magnitudes (false 422 / silent under-collection) | `MONEY_EPSILON = 0.01` (centime scale) in the in-tx balance check | code; W1-4 test path |
| W1-2/A4#3 | **Negative money API-reachable** (optionalNumber had no min on reservation amount/deposit, opp value) | new `optionalMoney` schema (min 0, max 1e10) in validation.ts; applied to all three surfaces | **live probe**: POST amount:-500 → 422 `"Le montant ne peut pas être négatif"` |
| W1-4/A4#5 | **Payment TOCTOU** — remaining computed outside write tx (two concurrent submissions could both pass) | balance re-read + decision INSIDE `db.$transaction` | code (house pattern from reservations route) |
| W1-5/A4#2 | **Immortal holds** — API booking with `expiresAt:null` locked a unit forever (sweeper only matches `< now`) | server-side default from `reservations.defaultExpiryDays` org setting for floor roles; MANAGER+ explicit omission honored as intentional open hold | code + settings loader wired |
| W2-10/A2#15 | **Lead lacked `convertedAt`** (derivable only via Activity/Contact hop) | migration `20261102150000_phase21_lead_converted_at` (SQLite + Supabase parity): column + backfill from linked Contact; convert route stamps it in-tx | `migrate deploy` applied (18 migrations); `/api/health` → migrations:18 |
| W2-2/A2#4 | **Document polymorphic link orphans on opp DELETE** (no FK on entityType/entityId) | guarded DELETE now re-points docs to the parent LEAD (or deletes when no lead), audited, one tx | tsc; opp DELETE contract preserved (HAS_RESERVATIONS gate unchanged) |
| W2-3/A2#7+A6#5 | **Unbounded scans + JS aggregation** — incentives all-time/month full-row findMany + reduce; pendingIncentives no take; wonOppsWithSource unbounded | `_sum`/`_count` aggregates; items capped `take:50` with EXACT separate count; wonOpps capped 5000 | `/api/dashboard` → 200 live |
| W2-4/A6#4 | **SAV list full-table scan** (no take, full-relation include, JS sort+slice) | `take: 5000` house cap (derived in-memory sort order preserved — documented PERF-P4 law) | `/api/sav` → 200 live |
| W2-5/A6#12 | **Analytics monthlyTrend JS bucketing** (full-window row scan) | SQL-side per-month `count`/`aggregate` (12 bounded queries replace 2 unbounded scans) | `/api/analytics` → 200 live |
| W2-8/A2#10 | **Matching engine stale rows + N+1** — 20 sequential upserts; fallen rows never pruned | ONE transaction: `deleteMany` stale SUGGESTED rows outside new top-20 (PRESENTED preserved as history) + upserts in-tx | tsc; matching tests 16/16 |
| W2-11/A2#18 | Stale "no DB unique index" comment (D12 exists) | comment corrected to name the D12 backstop + P2002 mapping | review |
| W2-1/A2#3 | **Zero CHECK constraints on enum vocabularies (SQLite)** | **Documented decision**: the Supabase/PostgreSQL chain already carries 35 CHECK constraints (`20261030000002_business_constraints.sql` — the production path IS covered); adding CHECKs to the dev SQLite file requires table rebuilds for zero dev value. SQLite CHECKs = deferred until a PostgreSQL-first deploy. | supabase chain inspected |
| — | **PG schema drift repair**: `fullNameAr/nameAr ×4` (arabic_aliases) never mirrored to `schema.postgres.prisma` | four alias columns added + `supabase/migrations/20261102150000_…sql` parity file | schema diff clean |
| W5-4/A2#6 | **Per-poll 5k-lead duplicate re-scan** (bell × tabs × users) | 60s TTL cache (`pendingDuplicatePairsCached`) + `bustDuplicateCache` on merge/dismiss | code; notifications → 200 live |

## 3. Schema governance state (three sources of truth)

- `prisma/schema.prisma` (SQLite dev) — **authoritative for the app**, 18 migrations, `migrate deploy` only (house law).
- `prisma/schema.postgres.prisma` — parity restored this phase (convertedAt + arabic aliases).
- `supabase/migrations/*.sql` — parity file added; 35 CHECK constraints live here (the production-grade chain).

## 4. ERD summary (text form)

**Organization** 1—N → User, Lead, Contact, Opportunity, Developer, Project, Task, Visit, Activity, AuditLog, Pipeline, Tag, Reservation, Requirement, Apartment, SavedSearch, Document, OrgSetting, ProjectAssignment, LeadDuplicateDismissal, Installment, Payment, SavCase, SalesTarget (orgId on every tenant row, RESTRICT).
**User** 1—N: Lead(owner), Opportunity(owner), Task(owner), Visit(agent/confirmed/rejected/reported), Activity(actor), AuditLog(actor), Document(uploader), Payment(recordedBy), SavCase(assignee/createdBy) [SetNull]; SalesTarget [RESTRICT]; ProjectAssignment [Cascade].
**Lead** 1—1 Contact + Requirement (unique, RESTRICT); 1—N Opportunity/Visit/Task/Activity/SavCase; N—M Tag (LeadTag, Cascade); convertedContactId + **convertedAt** (new).
**Opportunity** N—1 Lead/Project/Contact/User; 1—N Reservation (RESTRICT); stage history: stageChangedAt/closedAt/lostReason.
**Developer** 1—N Project (RESTRICT) → Building (Cascade) → Apartment (Cascade, unique(orgId,buildingId,code)); Apartment 1—N Reservation (RESTRICT), 1—N SavCase (SetNull), N—M Visit (VisitApartment), 1—N PropertyMatch (Cascade).
**Reservation** 1—N Installment (RESTRICT) → 1—N Payment (RESTRICT); live-hold: D12 partial uniques on apartmentId & opportunityId WHERE status IN (ACTIVE, CLOSURE_REQUESTED).
**Pipeline** 1—N PipelineStage (unique(pipelineId,key), wipLimit advisory); **ProjectAssignment** M:N Project↔User; **Document/Activity/AuditLog**: polymorphic/multi-FK attachments.

## 5. Data Dictionary (core deltas this phase)

| Column | Type | Semantics |
|---|---|---|
| `Lead.convertedAt` | DATETIME? (PG: TIMESTAMPTZ?) | conversion instant; stamped in convert tx; backfilled from Contact.createdAt |
| `Lead/Contact.fullNameAr`, `Developer/Project.nameAr` | TEXT? | Arabic-script display alias (R14 search + AR locale) |
| D12 `Reservation_apartment_live_hold_uq` / `_opportunity_live_hold_uq` | partial unique | one live hold per unit / per deal (ACTIVE ∪ CLOSURE_REQUESTED) |

## 6. Database safety compliance

No production database exists in this sandbox. All changes: dev SQLite via `migrate deploy` (18/18), synthetic seed data only, snapshot insurance taken pre-reset (`db/backups/custom-20261102-165438.db`), no destructive production migrations, no RLS/policy changes, no real customer data.
