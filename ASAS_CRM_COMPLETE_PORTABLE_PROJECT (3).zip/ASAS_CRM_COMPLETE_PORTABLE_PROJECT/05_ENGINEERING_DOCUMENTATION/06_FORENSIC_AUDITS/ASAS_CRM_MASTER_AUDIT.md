# ASAS CRM — Master Engineering Audit (Consolidated)

**Mission:** Master engineering audit, architectural review, remediation & final delivery.
**Method:** Parallel read-only audit by 6 specialized agents (A–F) → central consolidation → adopted roadmap → parallel implementation of independent tasks → central integration → regression & final QA.
**Date:** 2026-11-01 · **Baseline:** git `a5dac11` (main, clean tree) · typecheck ✅ · eslint ✅ · dev server healthy on :3000.

---

## 1. Platform Health — Executive Assessment

**Overall verdict: structurally sound, unusually disciplined, with a short list of genuine latent defects — none of them currently corrupting data.**

| Domain | Grade | Headline |
|---|---|---|
| Architecture | **A−** | Clean layering, 0 circular deps, shared-guard adoption 76/48/47/41 sites; debt = enumerable duplication pockets |
| Database | **A** | 0 orphans (52 checks), 0 FK violations, 0 enum drift, perfect 7/7/7 WON↔CONVERTED↔SOLD triad; migration history unrecorded (P1) |
| Security | **B+** | Discipline rare: scrypt, HMAC sessions, CSRF origin checks, scoped-404 IDOR defense, zod everywhere; exposure is *configuration* (demo mode P0-if-deployed, ephemeral secret) |
| Business logic | **B+** | 4 server-enforced transition matrices, transactional money path, unbypassable visit/report gate; risks concentrated in reservation **revival pattern** (P1) + reservation/deal guard gaps |
| UI/UX | **A−** | Professional i18n (FR/AR/EN), RTL solid, role isolation verified live; gaps in a11y (row nesting, 3 dark contrast nodes), feedback timing, formatting discipline |
| Quality/Perf | **B** | 0 type/lint debt, 0 N+1, batched queries; **zero automated tests**, 3 unbounded endpoints, ~16 unused deps, no monitoring |

## 2. Critical Findings (P0/P1 — full detail in domain audits)

| ID | Sev | Finding | Source |
|---|---|---|---|
| **SEC-V01** | P0 (deploy) | Demo mode defaults ON: unauthenticated visitor can harvest OWNER userId from `GET /api/auth/session` then quick-login as OWNER. Verified live (probe stopped one step before completion). Intentional in sandbox; fatal in production. | Agent C |
| **DOM-D1** | **P1** | Reservation "revive" repurposes the prior deal's money records on re-booking: `reservations/route.ts:173-203` updates the latest row in place WITHOUT resetting commission/incentive/closure fields — and Installment/Payment/SavCase rows FK to `reservationId`. **Live precondition present**: ACTIVE reservation carries 24.36M DZD installments + 8.7M DZD payments. | Agent E |
| **ARCH-T1** | P1 | Dashboard KPI predicates hand-mirrored into visits route facets ("mirrored field-for-field" self-admitted comment) — silent drift breaks KPI↔deep-link equivalence. | Agent A |
| **PERF-P1** | P1 | `GET /api/reservations` unbounded (no pagination) with the heaviest row shape in the app. | Agent F |
| **DB-1** | P1 | Migration history unrecorded: DB built via `db push`, `_prisma_migrations` absent — `migrate deploy` would fail on this DB. Zero *structural* drift (migrate diff empty). | Agent B |
| **SEC-V06/F-R1** | P1 (deploy) | `ASAS_SESSION_SECRET` unset → ephemeral per-restart secret (all sessions die on restart). | Agents C/F |

## 3. P2 Highlights (76 further findings — see domain docs)

- **DOM-D2/D3/D4**: apartment coherence guard ignores `CLOSURE_REQUESTED`; opportunity can close LOST while holding a unit; booking has no stage precondition → money path can resurrect a CLOSED_LOST deal.
- **DOM-D5**: lead reassignment doesn't cascade opportunity ownership → split visibility (drawer vs kanban).
- **DOM-D6**: create-opportunity dialog offers CLOSED_WON; server always refuses (422).
- **SEC-V03/V04/V05**: no `secure` cookie flag; no absolute session expiry; no security headers.
- **ARCH-T2/T3/T4**: SAV enum re-declared inline (latent filter-drift bug); visitInclude/taskInclude duplicated; `findOpportunity` missing (5× scoped-lookup repetition).
- **DB-4**: missing index `Reservation[orgId, incentiveStatus]` on the polled notifications query.
- **PERF-P2..P6**: no caching on dashboard/analytics (~30 queries/GET); in-memory aggregation over unbounded rows; finance/SAV unbounded; no code-splitting (recharts+framer-motion in one bundle).
- **UX-1/2 (P1-class a11y)**: nested interactive controls in leads rows (axe: 25 nodes); 3 dark-mode WCAG 4.5:1 failures.
- **UX-3..9 (P2)**: "Trouver des biens" no feedback; EN a11y names in date pickers; dashboard decision-card truncation; duplicate "ÉCHÉANCE" column; currency format drift (DA/DZD/M); duplicate persona-switch toast.
- **QUAL**: phantom dep `@radix-ui/react-direction`; ~16 unused deps + dead ui files; no snapshots ever taken.

## 4. What is NOT broken (verified, evidence-backed)

- Referential integrity: `integrity_check=ok`, `foreign_key_check` 0 rows, 52 orphan sweeps → 0, enum vocabulary 100% in-bounds, payment coverage exact, zero double-bookings.
- AuthZ engineering: single shared `requireUser` guard (100+ call sites), scoped-404 IDOR defense (foreign record = 404, byte-identical to nonexistent), ROLE_CEILING, audit trail on all mutations, zod on every body, CSRF + rate-limit verified live by black-box probes.
- Lifecycle discipline: server-enforced adjacency matrices single-sourced in `constants.ts` and imported by UI; won-path visit/report gate enforced on all three paths with no bypass; journey engine is pure, derived, and shared by all surfaces.
- Performance hygiene: **zero N+1** across 68 routes; batching via updateMany/createMany/Map-joins throughout.
- Today's dataset: **zero impossible states** (all defects are code-level latent paths).

## 5. Engineering Decisions (adopted by Principal)

1. **D1 revival fix = guard + full reset** (minimal root-cause-adjacent change, preserves the one-row-per-available-unit pattern): refuse revival when Installment/Payment/SavCase rows exist (409 with explicit code); otherwise reset the FULL economics/closure field set on revival. Creating-new-rows-per-booking deferred (would need partial-unique-index migration — documented in roadmap).
2. **Demo mode**: intentional in this sandbox (persona grid = the product demo). Remediation = env plumbing + production checklist + fail-fast in production, NOT breaking the sandbox demo.
3. **Email-duplicate pair** (distinct phones): ruled **distinct persons** under the CRM's phone-identity law — no merge. Phone-duplicate demo pair in seed is intentional (P30 workflow demo).
4. **Session hardening**: persistent secret in `.env` now; `secure` flag + 7-day absolute expiry in code.
5. **Security headers**: only sandbox-safe set (X-Content-Type-Options, Referrer-Policy). NO frame-deny/CSP — the preview panel iframes the app cross-origin; frame protection would break it. Documented accepted trade-off.
6. **No big-bang refactors**: preserve the route→lib/server layering; finish the 3 unfinished helper families (visits/tasks/opportunities) instead.

## 6. Adopted execution order (user-mandated orchestration)

```
Parallel Audit (done) → Consolidation (this doc set) → Roadmap adoption
→ Wave 1 foundation (serial, me) → Waves 2–5 parallel (ENG-1/2/3, disjoint file ownership)
→ Central integration (me) → Regression + agent-browser E2E → Final delivery report
```

**Domain detail:** `ARCHITECTURE_AUDIT` → 05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ · `DATABASE` → same · `SECURITY` → same · `UX_UI` → same · `CRM_DOMAIN` → same · `QUALITY` → same · Roadmap: `ASAS_CRM_REMEDIATION_ROADMAP.md` · Living log: `ASAS_CRM_EXECUTION_LOG.md`.
