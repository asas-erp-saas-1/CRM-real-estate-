# ASAS CRM — Phase 2 Security Audit (Task P2-b)

- **Auditor:** Security Engineer subagent (P2-b), Phase 2 forensic audit
- **Date:** 2026-10-02 (UTC)
- **Scope:** READ-ONLY review of `src/` + live black-box testing of the running API (`http://localhost:3000`, dev server). No `src/` modifications, no server restart, no agent-browser.
- **Method:** code reading of all 40+ API routes + server libs (`session.ts`, `auth.ts`, `validation.ts`, `documents.ts`, `csv.ts`, `audit.ts`, `settings.ts`), Prisma schema, Caddyfile, `.env`, git index, committed SQLite DB (read-only SELECTs via bun+Prisma), and **22 live curl test batteries (T1–T20)** including forged-cookie authentication, passwordless login, RBAC escalation, IDOR probes, upload abuse, CSRF content-type, and login timing analysis. All test residue was cleaned (1 test user + 4 audit rows deleted; final state verified: 7 users, escal-user gone).

---

## 1. Executive summary

| Severity | Count | Finding IDs |
|---|---|---|
| **P0** | 1 | F-01 |
| **P1** | 4 | F-02, F-03, F-04, F-05 |
| **P2** | 6 | F-06 … F-11 |
| **P3** | 8 | F-12 … F-19 |

**Top risks (fix order):**

1. **F-01 (P0) — Unauthenticated full account takeover.** `GET /api/auth/session` (no auth required) returns the userId of every active user incl. the OWNER; `POST /api/auth/login {userId}` authenticates as any of them with **no password**; alternatively the raw `asas_user=<userId>` cookie alone authenticates. Verified live: forged cookie → OWNER session with zero credentials and zero audit trail. The login page also *displays* the shared demo password. As shipped, the app has no effective authentication boundary.
2. **F-04 (P1) — Secrets in VCS.** `.env` and `db/custom.db` are git-tracked; the committed DB contains all 7 users' emails, IDs, roles and scrypt password hashes; the plaintext demo password is public. Offline credential verification/cracking is trivial.
3. **F-05 (P1) — No session revocation primitive.** Sessions are stateless raw-id cookies; password reset does NOT invalidate existing sessions (only deactivation kills a session, via `active:false` check in `getCurrentUser`).
4. **F-07 (P2) — ADMIN → OWNER privilege escalation** via unrestricted `role` on user create/patch (verified live: ADMIN created an OWNER user, then passwordless-logged-in as it).
5. **F-08/F-10/F-11 (P2) — object-level RBAC gap on document status, post-parse upload size cap, unthrottled AI analyze endpoint.**

The **tenant isolation (orgId scoping) and role gates are otherwise consistently implemented and passed every live probe** — see §4 Verified-good.

---

## 2. Methodology

**Live-tested (curl, dev server :3000):** T1 forged-cookie OWNER auth · T2 forged-cookie protected access · T3/T4 fabricated + SQLi-shaped cookie ids · T5 passwordless quick-login · T6 credential-error uniformity · T7 lockout (5/15min) · T8–T13 RBAC matrix (403s, self-guards, LAST_OWNER) · T14/T14b/T14c ADMIN→OWNER creation + passwordless login chain · T15/T15b/T15c fabricated-id IDOR probes across 13 `[id]` routes (GET/PATCH/DELETE) · T16 pageSize clamp · T17 CSRF content-type · T19/T19b/T19c upload MIME/size/entity guards · T20 login timing side-channel (5 samples each arm).

**Code-read:** every route under `src/app/api/**` (requireUser presence, orgId in every `[id]` where-clause, zod parseBody usage, passwordHash select audit); `src/lib/server/*` helpers; `prisma/schema.prisma`; `Caddyfile`; `.gitignore`; git index (`git ls-files`); committed DB via read-only Prisma script (`tmp-scripts/p2b-db-inspect.ts`).

---

## 3. Findings

### F-01 — P0 — Unauthenticated full account-takeover chain (demoUsers disclosure × passwordless quick-login × unsigned cookie)

- **Evidence (code):**
  - `src/app/api/auth/session/route.ts:12-19` — when unauthenticated, returns `demoUsers` = `{id, name, role}` of up to 8 **active users across ALL orgs** (no auth, no org scoping).
  - `src/app/api/auth/login/route.ts:37-57` — `{userId}` body → sets session cookie as that user. No password. **No rate limit on this branch** (see F-03).
  - `src/lib/server/session.ts:23-32` — `getCurrentUser()` trusts the raw `asas_user` cookie value as a userId (see F-02).
  - `src/components/crm/login-overlay.tsx:49,301-304` — the shared demo password `asas1234` is hardcoded and **displayed on the public login page**; the persona grid offers one-click login as any user incl. OWNER.
- **Evidence (live):**
  - `curl http://localhost:3000/api/auth/session` (no cookie) → 200 with all 7 userIds incl. `Nadia Benali / OWNER`.
  - T1: `curl -H "Cookie: asas_user=<owner-id>" /api/auth/session` → **200 authenticated as OWNER Nadia** — no login ever performed, no audit row written.
  - T2: same forged cookie on `GET /api/users?includeInactive=1` → full user directory.
  - T5: `POST /api/auth/login {"userId":"<amine-id>"}` → 200 session as Amine.
- **Impact:** complete authentication bypass — any network-reachable attacker becomes any user (incl. OWNER) with zero credentials and zero trace (forged-cookie path writes no audit rows).
- **Recommended fix (minimal):** gate all three mechanisms behind one `DEMO_MODE` env flag (default false in prod): (a) omit `demoUsers` from the session response, (b) reject `{userId}` login bodies (or require the demo flag), (c) remove the demo-password hint. Independently, sign the cookie (F-02) so an id alone is insufficient.
- **Fix validation:** with `DEMO_MODE=false`: unauth session → `{user:null}` without `demoUsers`; `{userId}` login → 400/404; cookie-signing rejects forged ids (401). Re-run T1/T2/T5 → all must fail.

### F-02 — P1 — Unsigned session cookie (raw userId, no HMAC / session table)

- **Evidence:** `src/lib/server/session.ts:23-32` — cookie value = raw userId; `db.user.findFirst({where:{id, active:true}})`. No signature, no expiry server-side, no session store (schema has no Session model — `prisma/schema.prisma` grep).
- **Live:** T1 (above) — forging `asas_user=<id>` authenticates. T3: fabricated cuid → 401 (no 500). T4: `' OR '1'='1` → treated as unknown id (Prisma parameterization; no SQL injection).
- **Impact:** any userId leak = permanent account impersonation. UserIds are exposed by: the unauthenticated session endpoint (F-01), `GET /api/users`, audit `entityId`/`actorId`, the committed DB (F-04).
- **Recommended fix:** sign the cookie value: `userId.exp.hmacSHA256(userId+exp, SERVER_SECRET)`; reject expired/tampered values in `getCurrentUser`. A session table (id, userId, createdAt, revokedAt) is the fuller path if logout-everywhere is needed — otherwise the signed cookie + a `passwordChangedAt` claim (F-05) suffices.
- **Validation:** forged `asas_user=<plain-id>` → 401; tampered signature → 401; legitimate login still 200 after server restart.

### F-03 — P1 — Passwordless quick-login `{userId}`, unthrottled and lockout-bypassing

- **Evidence:** `src/app/api/auth/login/route.ts:37-57` — the `{userId}` branch performs no `assertNotLocked` and no credential check; only `active:true`. The credentials branch (lines 59-100) is rate-limited; this one is not.
- **Live:** T5 → 200 as Amine. Additional live proof of lockout bypass: after T20 locked `amine@asas.dz` credential login (429), quick-login for the same user still returned **200**.
- **Impact:** unlimited, unthrottled authentication attempts as any active user (brute-forcing cuids is impractical, but ids are handed out unauthenticated — F-01); defeats the login rate limiter entirely for persona targets.
- **Recommended fix:** remove, or gate behind the same `DEMO_MODE` flag as F-01 and apply `assertNotLocked(user.email)` on that branch too.
- **Validation:** with demo mode off → `{userId}` body rejected; with demo mode on, 5 rapid failures via credentials then `{userId}` → still allowed only if lockout intentionally scoped to credentials (decide + document).

### F-04 — P1 — `.env` and `db/custom.db` git-tracked; passwordHash + PII in VCS

- **Evidence:** `git ls-files` → `.env`, `db/custom.db`, `db/docs-test.pdf`, `db/docs/.gitkeep`. Read-only DB inspection (`tmp-scripts/p2b-db-inspect.ts`): all 7 users with `id | email | role | active | scrypt:<salt>:<hash>` (hash len 104). `.gitignore` does not exclude `.env`/`db/`. Plaintext demo password is public (worklog, login overlay, `src/lib/server/auth.ts:26`).
- **Impact:** offline verification/cracking of all credentials from repo history; user enumeration (emails); userIds directly usable for F-02. `DATABASE_URL` path disclosure (low value here).
- **Recommended fix:** `git rm --cached .env db/custom.db db/docs-test.pdf`; add `.env*` and `db/` to `.gitignore`; rotate every password (they share a public plaintext); consider BFG/git-filter-repo for history if the repo ever leaves the sandbox.
- **Validation:** `git ls-files | grep -E '\.env|custom\.db'` → empty; fresh clone cannot authenticate with `asas1234`.

### F-05 — P1 — No session invalidation on password reset / compromise

- **Evidence:** `src/app/api/users/[id]/reset-password/route.ts:36-45` — swaps `passwordHash`, clears in-memory login failures, returns temp password; **no session revocation** (impossible: cookie = raw userId, no server state). `src/app/api/auth/change-password/route.ts:7` comment: “the session cookie stays valid (no cookie change needed)”. Only `active:false` kills sessions (`session.ts:28` `active: true` in where).
- **Impact:** an admin reset (e.g., suspected compromise) leaves the attacker's existing/forged session fully working; there is no logout-everywhere primitive.
- **Recommended fix (minimal, no session table):** add `passwordChangedAt DateTime` to User; embed it in the signed cookie (F-02) and reject in `getCurrentUser()` when `cookie.pca !== user.passwordChangedAt`. Set it in reset-password and change-password.
- **Validation:** login → admin resets that user's password → next request with the old cookie → 401.

### F-06 — P2 — In-memory rate limiters: single-instance, reset on restart

- **Evidence:** `src/lib/server/auth.ts:61` (`attempts = new Map()`), `src/app/api/leads/[id]/copilot/route.ts:31-32` (`lastRunAt = new Map()`, 20s per **lead**, not per user). Multi-instance/hot-restart deployments lose all lockout state; a restart clears an active lockout (observed indirectly: state lives only in module scope).
- **Impact:** brute-force window reopens on every deploy/restart; horizontal scaling silently disables limiting.
- **Recommended fix:** document single-node constraint; if ever multi-instance, move to SQLite table (same DB, already single-writer) keyed `email, windowStart`. Keep per-user (not just per-lead) scoping for copilot.
- **Validation:** unit test: 5 failures → 429; simulate restart (new module instance) → optionally persists if table-backed.

### F-07 — P2 — ADMIN can create/promote OWNER-rank users (rank escalation)

- **Evidence (code):** `src/app/api/users/route.ts:40-44` — POST schema `role: z.enum(ROLES)` with **no rank ceiling** (`ROLES` includes OWNER); `requireUser("ADMIN")` (rank: OWNER+ADMIN). `src/app/api/users/[id]/route.ts:30,74-81` — ADMIN may PATCH any member's role, including to OWNER (only self-change and last-owner are blocked).
- **Evidence (live):** T14 — forged cookie as Karim/ADMIN → `POST /api/users {name:"P2b Escal Test", role:"OWNER"}` → **201** (user persisted; cleaned up after). T14b — passwordless quick-login as the new OWNER → 200. T14c — forged cookie as it → OWNER session.
- **Impact:** any ADMIN (or anyone forging/quick-logining as an ADMIN via F-01/F-03) mint OWNER accounts; even without the auth flaws, ADMIN self-escalation via a confederate account is possible (temp password is returned in the 201).
- **Recommended fix:** rank ceiling — only OWNER may create/patch users **to** ADMIN/OWNER rank (422 otherwise); ADMIN creates ≤ MANAGER. Verify `ROLE_RANK[body.role] < ROLE_RANK.OWNER || actor.role === "OWNER"`.
- **Validation:** as ADMIN, POST role=OWNER → 422; as OWNER → 201. PATCH promote-to-OWNER as ADMIN → 422.

### F-08 — P2 — Document PATCH (incl. VALIDATED/REJECTED) has no object-level RBAC

- **Evidence:** `src/app/api/documents/[id]/route.ts:48-65` — PATCH requires only `requireUser()` (any org member); no uploader-or-MANAGER check, unlike DELETE (line 110) and analyze (`analyze/route.ts:183`). Status transitions gate only the state machine. UI implies MANAGER+ (“validate/reject/reset MANAGER+” per R7-3 worklog) — server is permissive.
- **Impact:** a SALES_AGENT can flip KYC-ish document statuses (VALIDATED/REJECTED) and rewrite titles/notes of colleagues' documents via API, diverging from the intended review workflow.
- **Recommended fix:** mirror the delete rule: status/notes changes to documents not uploaded by self require MANAGER+ (title-only edits could stay open); simplest is the same `uploadedById !== user.id && !atLeastRole(user.role,"MANAGER")` guard for any PATCH.
- **Validation:** as SALES_AGENT PATCH someone else's doc status → 403; own doc → 200; as MANAGER → 200.

### F-09 — P2 — `fail()` returns raw internal error messages on 500

- **Evidence:** `src/lib/server/session.ts:57-59` — non-ApiError path: `console.error("[api]", error)` then responds `{error: message}` with `error.message` (Prisma messages include table/column/engine details).
- **Live:** no 500 reproduced (all probed error paths return clean 4xx with `{error, code, details}`) — flagged as hardening from code inspection; the catch-all remains reachable by unexpected Prisma/FS errors.
- **Impact:** internal structure disclosure on unhandled errors.
- **Recommended fix:** respond `{error:"Internal error", code:"INTERNAL"}` in production; keep the detailed `console.error` server-side (already present).
- **Validation:** temporarily throw in a route (dev) → response body is generic; server log retains detail.

### F-10 — P2 — Upload size cap enforced only after full body parse; no proxy body limit

- **Evidence:** `src/app/api/documents/route.ts:72-90` — `await req.formData()` (parses the entire multipart into memory) happens **before** `file.size > DOC_MAX_SIZE_BYTES` (8MB). `Caddyfile` has no `request_body { max_size … }` directive. Route handlers in Next App Router have no default body limit.
- **Live:** T19c — a 9MB upload is fully transferred then rejected 413 `DOC_TOO_LARGE` (correct verdict, late enforcement).
- **Impact:** authenticated memory-amplification DoS (e.g., 2GB multipart → buffered before rejection); repeated requests exhaust the single Node process.
- **Recommended fix:** add `request_body { max_size 12MB }` to the Caddy proxy (defense at the edge); optionally check `req.headers.get("content-length")` before `formData()`.
- **Validation:** 9MB upload via :81 → 413 from Caddy without reaching the app; content-length > cap short-circuit returns 413.

### F-11 — P2 — AI analyze endpoint is unthrottled (cost/abuse)

- **Evidence:** `src/app/api/documents/[id]/analyze/route.ts` — no rate limiter anywhere in the file (compare copilot route's 20s/lead limiter). Guard is uploader-or-MANAGER + images only; every call sends the full base64 image to the vision model.
- **Impact:** any uploader/manager can loop analyze on an image → LLM spend amplification and DB churn (analysis persisted per call). Legitimate but unbudgeted surface.
- **Recommended fix:** mirror the copilot pattern: in-memory 20–30s per document id (and/or per user), 429 with retryAfterMs.
- **Validation:** two rapid analyzes on the same doc → second gets 429; after window → 200.

### F-12 — P3 — Login timing side-channel (email enumeration) — **RESOLVED P4**

- **Evidence (code):** `login/route.ts:75-84` — when email unknown, `verifyPassword(pw, undefined)` returns false immediately (`auth.ts:37` `if (!stored) return false`) without running scrypt; known email + wrong password runs scrypt (~50ms+).
- **Evidence (live, T20):** unknown-email ×5 → `0.020/0.006/0.005/0.035/0.008`s; known-email wrong-pw ×5 → `0.072/0.049/0.057/0.079/0.182`s. Clearly separable distributions despite identical error bodies (T6: both `"Email ou mot de passe incorrect"` / `INVALID_CREDENTIALS`).
- **Impact:** user email enumeration via timing (message-level anti-enumeration is defeated).
- **Recommended fix:** on user-not-found, run `verifyPassword(password, DUMMY_HASH)` (fixed pre-computed scrypt string) before answering 401.
- **Validation:** re-run T20 → both arms within ~±10ms of each other.
- **RESOLUTION (P4):** DUMMY_HASH constant + `verifyPassword(body.password, user?.passwordHash ?? DUMMY_HASH)`; measured AFTER: unknown 37-46ms (median 38.9) vs known 38-41ms (median 40.2) — Δmedian 1.3ms. Lockout (429 ACCOUNT_LOCKED) and byte-identical 401 bodies unchanged. Transcript: agent-ctx/p4-8-security.md.

### F-13 — P3 — Temp passwords generated with `Math.random()`

- **Evidence:** `src/app/api/users/route.ts:47-54` and `src/app/api/users/[id]/reset-password/route.ts:16-23` — `Math.floor(Math.random()*alphabet.length)` over a 53-char alphabet, 6 chars → ~35 bits, non-CSPRNG. (Login limiter throttles online guessing, so exposure is mainly predictability of the PRNG sequence.)
- **Recommended fix:** `randomBytes` over the same alphabet (e.g., rejection-sample 6 bytes); consider 8 chars.
- **Validation:** generated values match `Asas-[A-HJ-NP-Za-km-z2-9]{6,8}` and `crypto` is the source (code review).

### F-14 — P3 — CSV export formula injection — **RESOLVED P4**

- **Evidence:** `src/app/api/leads/export/route.ts:41-46` — `csvEscape` quotes `"`/`;`/CR/LF correctly but does not neutralize leading `=`, `+`, `-`, `@` (e.g., a lead named `=CMD|'/C calc'!A0` exports raw; `fullName` is free-text via POST /api/leads and CSV import).
- **Impact:** spreadsheet formula execution on the MANAGER's machine when the export is opened (classic CSV injection).
- **Recommended fix:** in `csvEscape`, if `/^[=+\-@\t\r]/.test(s)` prefix a `'` (and keep quoting).
- **Validation:** create lead `=1+1`, export, open in Excel/LibreOffice → cell shows literal text, no evaluation.
- **RESOLUTION (P4):** csvEscape defangs `/^[=+\-@\t\r]/` with `'` prefix before quoting; import strips exactly one defang marker (round-trip verified live: `'=SUM(1+1)` re-imports to `=SUM(1+1)`, duplicate + INVALID_PHONE reporting intact). Transcript: agent-ctx/p4-8-security.md.

### F-15 — P3 — `x-forwarded-for` trusted verbatim (audit-only) — **RESOLVED P5**

- **Evidence:** `src/lib/server/session.ts:78-81`; consumed only by `logAudit` (`audit.ts:57`) to persist `ip`. Direct :3000 access lets clients forge their audit IP; through the Caddy `:81` route, Caddy **replaces** XFF with `{remote_host}` (Caddyfile lines 9, 18) — partial mitigation.
- **Impact:** audit-trail attribution can be falsified when the app port is directly reachable (as in this sandbox).
- **RESOLUTION (P5):** `clientIp()` now parses XFF from the **RIGHT** — the rightmost entry is the one our infrastructure vouches for (Caddy replaces → single entry; nginx-style append proxies add the real client IP last; leftmost entries are client-forgeable). Live-verified: direct `X-Forwarded-For: 1.2.3.4, 9.8.7.6` → audit row records `9.8.7.6`; forged `6.6.6.6` sent through the `:81` gateway → audit records Caddy's `::1` (replace semantics confirmed).

### F-16 — P3 — Cookie hardening (no `secure`, 30-day lifetime, no rotation)

- **Evidence:** `login/route.ts:26-31` — `httpOnly, sameSite:"lax", path:"/", maxAge: 30d`; no `secure` (HTTP sandbox constraint), no expiry server-side, no rotation on privilege change.
- **Recommended fix (prod):** add `secure: true` behind TLS; shorten to e.g. 7d; rotate value on role change (ties into F-02 signed cookie).

### F-17 — P3 — Unauthenticated `demoUsers` not org-scoped (multi-tenant leakage)

- **Evidence:** `session/route.ts:13-18` — `db.user.findMany({where:{active:true}})` with no orgId filter, take 8. Single-org today; in a multi-tenant deploy, one org's login page would disclose another org's user ids/names/roles.
- **Recommended fix:** scope to a designated demo org id constant, or drop entirely with DEMO_MODE=false (F-01).

### F-18 — P3 — Client-declared MIME trusted (no magic-byte validation)

- **Evidence:** `documents/route.ts:92-97` — `file.type` (multipart-declared) is the only type check; no content sniffing. A non-PDF stored as `application/pdf`.
- **Impact:** integrity only — downloads are forced `attachment` + `no-store` with whitelisted content types (file/route.ts:34-42), so no stored-XSS vector; mis-typed files circulate.
- **Recommended fix (optional):** check magic bytes (`%PDF-`, PNG/JPEG/WEBP signatures) before write.

### F-19 — P3 — Any org member can list inactive users' emails

- **Evidence:** `users/route.ts:23-30` — `requireUser()` (any role) + `?includeInactive=1` returns email/name/role/active for all org users including deactivated ones. Intended for the team table (OWNER/ADMIN UI), but the server gate is any-authenticated.
- **Recommended fix:** require MANAGER+ when `includeInactive` is set (cheap, aligns with the UI).

---

## 4. Verified-good controls (with evidence)

| Control | Evidence |
|---|---|
| **Org-scoping (tenant isolation) on every `[id]` route** | Code sweep: every handler loads via `findFirst({where:{id, orgId}})` (or helper `findLead`/`findDocument`) before any read/write — leads, opportunities, visits, tasks, reservations, documents (+file/analyze), users, saved-searches, tags, apartments, projects, matching, import-undo audit load. Saved-search DELETE additionally scopes `userId` (own rows only). |
| **IDOR probes all 404, never 500** | Live T15/T15b/T15c: fabricated cuid across 13 endpoints (GET/PATCH/DELETE) → 404 with clean `{error, code}` bodies; no stack/internal detail. |
| **RBAC role gates** | Live: Sarah/MANAGER PATCH users → 403 `FORBIDDEN_ROLE` (T8); POST users → 403 (T9); reset-password → 403 (T13); audit/analytics/export/import gated MANAGER+ (code); targets POST gated ADMIN (code). |
| **Privilege self-guards (R8-2)** | Live: self role change → 400 `SELF_ROLE_CHANGE` (T10); self deactivate → 400 `SELF_DEACTIVATION` (T11); demote last OWNER by ADMIN → 400 `LAST_OWNER` (T12). |
| **Password storage** | `auth.ts:20-49`: scrypt N=16384 r=8 p=1, 32-byte key, per-user 16-byte salt, NFKC normalization, `timingSafeEqual` — no external deps. `passwordHash` never selected in any response (grep audit of every `select` — only the two auth routes fetch it and strip/never-return it). |
| **Audit trail hygiene** | All `logAudit` call sites in auth/users routes reviewed: no password material ever persisted (reset stores userId/email/method; change stores userId only). Verified in code (R8-2 claim confirmed). |
| **No raw SQL / SQLi** | `rg queryRaw|executeRaw` over `src/` → 0 matches. Live cookie SQLi probe (`' OR '1'='1`) harmless (T4). All filtering via Prisma (parameterized). |
| **XSS surface** | `dangerouslySetInnerHTML` only in stock shadcn `chart.tsx` (CSS injection guard) — no other usage in `src/`. |
| **Input validation coverage** | Every POST/PATCH/PUT route goes through `parseBody`/`validate` (zod) — `rg "\.json\(\)"` in `src/app/api` → 0 direct calls; malformed JSON → 400 `INVALID_JSON` (live T17). Query params via `qp*` helpers with enum whitelists → 422 `INVALID_FILTER`. |
| **Login lockout + anti-enumeration messages** | Live T7: 5 failures → 6th = 429 `ACCOUNT_LOCKED` (with retryAfterMs); T6: unknown-email vs wrong-password → byte-identical error body (timing caveat = F-12). |
| **CSV import caps** | `csv.ts:6-7` (2000 rows / 600KB) enforced at `import/route.ts:234-236` (422 `TOO_MANY_ROWS`) + zod `.max(IMPORT_MAX_CSV_BYTES)` on the body; preview capped at 200 rows; parser is linear (no ReDoS patterns); budgets regex-anchored. |
| **Document upload path** | Live T19: `text/html` → 415 `DOC_BAD_TYPE`; 9MB → 413 `DOC_TOO_LARGE`; fake entity id → 404 `ENTITY_NOT_FOUND` **before** any disk write. Code: filename sanitization `[a-zA-Z0-9._-]` + `docFilePath` containment check (`documents.ts:26-49`) blocks path traversal; stored name server-generated; orphan-file cleanup on failed insert; download serves `attachment` + `private, no-store` + RFC5987 filename (org-scoped lookup). |
| **CSRF baseline** | `sameSite=lax` blocks cross-site POST cookie attachment + JSON-only bodies reject form POSTs (live T17 → 400). Residual: lax allows top-level GET navigation only; recommend Origin header check in production (noted in checklist). |
| **Pagination DoS cap** | Live T16: `?pageSize=99999` → clamped to 100 (leads) — `parseIntParam` max bounds on list routes. |
| **Session fallback removed (R7)** | No implicit demo fallback: absent/stale cookie → 401 `NO_SESSION` on all protected routes (live: unauth `/api/leads` → 401); fabricated cookie id → 401 (T3). |
| **Client IP handling** | XFF only used for audit `ip` (no security decision); Caddy overwrites XFF at the edge for the :81 route. |

---

## 5. Production checklist (demo mechanisms to disable/change)

1. **Disable demo surfaces** (F-01): `DEMO_MODE=false` → no `demoUsers` in `/api/auth/session`, no `{userId}` quick-login, no demo-password hint on the login page, no sidebar persona switcher.
2. **Sign the session cookie** (F-02) with a `SERVER_SECRET` from env; add `secure:true`; shorten lifetime; validate signature + expiry in `getCurrentUser`.
3. **Purge secrets from git** (F-04): untrack `.env` + `db/custom.db` (+ `db/docs-test.pdf`), extend `.gitignore`, rotate every user password, scrub history if the repo is ever published.
4. **Session invalidation** (F-05): `passwordChangedAt` claim checked server-side (or session table); reset-password bumps it.
5. **Rank ceiling on user management** (F-07): only OWNER assigns ADMIN/OWNER.
6. **Document PATCH RBAC** (F-08): uploader-or-MANAGER, mirroring DELETE/analyze.
7. **Generic 500s** (F-09) in production mode.
8. **Proxy body limit** (F-10): Caddy `request_body { max_size 12MB }`.
9. **Throttle AI endpoints** (F-11): analyze limiter per document/user; consider a global daily LLM budget.
10. **Dummy-hash on unknown email** (F-12); **crypto RNG for temp passwords** (F-13); **CSV formula neutralization** (F-14); **Origin/Referer check middleware** for state-changing routes (CSRF defense-in-depth beyond `lax`).
11. **Multi-tenant hardening** (F-17): scope/eliminate `demoUsers`; (F-19) gate `includeInactive` to MANAGER+.
12. **Rate-limiter persistence** (F-06) if the deployment ever leaves single-node SQLite.

### Recommended fix order

1. F-01 (demo flag + cookie signing kills the takeover chain) — includes F-02/F-03 gating.
2. F-04 (git secrets + password rotation).
3. F-05 (session invalidation via `passwordChangedAt`).
4. F-07 (rank ceiling) — cheap, closes internal escalation.
5. F-08, F-10, F-11 (object RBAC, proxy cap, AI throttle).
6. P3 batch (F-12–F-19) as hardening sweep.

---

*Audit artifacts: `tmp-scripts/p2b-db-inspect.ts`, `tmp-scripts/p2b-audit-inspect.ts`, `tmp-scripts/p2b-cleanup.ts` (read/cleanup only; no `src/` files were touched). Test residue fully removed (escalation user + 4 audit rows deleted; DB back to 7 users). Transient note: the in-memory login limiter locked `amine@asas.dz` credentials for ~15 min from ~15:21Z (timing test) — self-expiring, quick-login path unaffected, no server restart permitted to clear it.*
