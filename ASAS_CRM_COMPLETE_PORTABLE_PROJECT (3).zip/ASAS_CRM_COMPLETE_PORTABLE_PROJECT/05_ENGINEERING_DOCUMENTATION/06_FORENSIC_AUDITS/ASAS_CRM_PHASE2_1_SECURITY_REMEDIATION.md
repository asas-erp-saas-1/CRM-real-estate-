# ASAS CRM — PHASE 2.1 — SECURITY REMEDIATION REPORT

**Agent 3 lane (W0-A3 investigation + Principal implementation)** · 2026-11-02

---

## 1. Investigation verdict

The authorization layer is **genuinely well-engineered** — materially stronger than the legacy 82/100 suggests: one `requireUser` chokepoint covers 68/70 route files (the 2 exemptions are login endpoints, same-origin-guarded via `readJson`); org-scoping + record-level visibility compose through ONE primitive module (`visibility.ts`) with correct AND-composition; foreign records 404 byte-identically to ghosts; field-level financial minimization (§37/§38) is enforced at a serialization chokepoint; ROLE_CEILING/SELF_*/LAST_OWNER all server-side; zero `$queryRaw` with interpolation; forged-cookie and cross-origin probes rejected live. **No P0. UI-only enforcement: none found.**

## 2. Implemented remediations

| ID | Finding | Fix | Verification |
|---|---|---|---|
| W1-6/A3#4 | **Multipart buffers before size check** — `req.formData()` read the full body, the 8MB cap fired after (authed memory-exhaustion vector) | Content-Length pre-check (cap + 64KB multipart overhead margin) BEFORE parsing; post-parse file.size remains authoritative | tsc; documents route contract unchanged |
| W1-7/A3#6 | **Create-time ownerId not MANAGER-gated** (PATCH/bulk were) — the D-GOV-5 "assignment is managerial" law had a POST gap | POST /api/leads: below-MANAGER ownerId → 403 FORBIDDEN_ROLE | code; matrix below updated |
| W1-8/A3#1+#5 | **Demo-mode hardening** — nothing forced `ASAS_DEMO_MODE=0` in a deployment pipeline (the passwordless quick-login chain is default-ON) | new `/api/health` endpoint exposes `demoMode`/`demoModeMisconfigured` booleans — an EXECUTABLE deploy assertion (`curl …/api/health \| jq -e '.demoMode==false'`); docs updated path | **live: 200 `{"demoMode":true,…}`** in sandbox (correct); prod fail-fast behavior preserved |
| W5-8/A3#3 | Copilot limiter global-per-lead (one agent throttles another on the same lead) | keyed `(user, lead)` | code |
| W1-2 | Negative money accepted server-side while UI strips minus signs (server weaker than client) | `optionalMoney` law on reservation amount/deposit + opp value | live 422 probe |

## 3. Role × Permission matrix — as ENFORCED server-side (post-remediation)

Roles: `OWNER(100) > ADMIN(90) > MANAGER(70) > SALES_AGENT(40) = FIELD_REP(40)`.

| Capability | OWNER | ADMIN | MANAGER | SALES_AGENT | FIELD_REP |
|---|---|---|---|---|---|
| Record visibility | org | org | org | OWN+POOL | project-scoped |
| Create lead/opp/task/visit/SAV/doc; match; copilot; saved searches | ✅ | ✅ | ✅ | ✅ | ✅ (no pool) |
| **Create lead WITH ownerId (assignment)** | ✅ | ✅ | ✅ | **403 (W1-7 — was open)** | **403** |
| Reassign lead (PATCH/bulk) + workload cascade | ✅ | ✅ | ✅ | 403 | 403 |
| request_closure | ✅ | ✅ | ✅ | responsible agent only | via scope |
| validate/reject/cancel closure; §37/§38 economics | ✅ | ✅ | ✅ | 403 | 403 |
| Illegal status/stage corrections (+reason) | ✅ | ✅ | ✅ | 422 | 422 |
| Delete task/opp/doc; archive lead | ✅ | ✅ | ✅ | owner-of-record | owner-of-record |
| Task reopen from terminal | ✅ | ✅ | ✅ | **owner only (W3-4)** | owner only |
| Analytics/audit/finance/exports/duplicates/merge/import/incentives | ✅ | ✅ | ✅ | 403 | 403 |
| User create/role edit/reset-password; targets; pipeline WIP | ✅ | ✅ | 403 | 403 | 403 |
| Manage OWNER-rank accounts | ✅ only | 403 ROLE_CEILING | 403 | 403 | 403 |
| Own password change | ✅ | ✅ | ✅ | ✅ | ✅ |

## 4. RLS Matrix (PostgreSQL/Supabase deployment posture)

This deployment is **application-layer authorization on SQLite** (documented house posture); the Supabase chain carries `20261030000003_rls_policies.sql`. The application-layer equivalent verified this phase:

| Layer | Mechanism | Status |
|---|---|---|
| Authn | HMAC-SHA256 cookie, constant-time compare, F-05 password-change invalidation | verified clean (W0-A3 live probes) |
| Authz (query scope) | `visibility.ts` scope fragments on every findFirst/findMany | verified (9 scope-builder unit tests) |
| Authz (role) | `requireUser(minimum)` chokepoint ×68 routes | verified |
| Tenant isolation | orgId predicate on every tenant table query | verified (grep-audited + tests) |
| Field-level | §37/§38 DTO minimization at serialization | verified |
| CSRF | same-origin chokepoint ×70 routes (incl. login) | live 403 probe |
| Injection | zero raw SQL (except the static health COUNT) | verified |

## 5. Deferred (documented)

- Session revocation epoch (stateless 7-day cookies; F-05 covers password-change invalidation) — M effort, production-scale item.
- Durable rate-limit store (in-memory per-process) — S–M, production-scale.
- Idle timeout policy — product decision.
- `ASAS_DEMO_MODE=0` enforcement in a real pipeline — now ASSERTABLE via /api/health; actual enforcement happens at deploy time (documented in ENVIRONMENT_VARIABLES.md).

## 6. Regressions: **none** — 401/404/422 negative battery green live; 159 tests; browser RBAC surfaces unchanged.
