# ASAS CRM — PHASE 2.1 — QA & PERFORMANCE REPORT

**Agent 6 lane (W0-A6 investigation + A6' test-suite implementation + Wave-6 integration verification)** · 2026-11-02

---

## 1. Test coverage: before → after

| Layer | Before (legacy audit: 15/20) | After |
|---|---|---|
| Unit — domain engines | none | `journey.test.ts` 30 its (stages, urgency +100/+80/+60, stats aggregation) |
| Unit — law matrices | none | `constants-matrices.test.ts` 33 its (LEAD/OPP/TASK/VISIT/RESERVATION matrices + vocab invariants + atLeastRole) |
| Unit — phone | none | 17 its (incl. the **double-country-code bug** found & fixed: `213555123456` → `+213213…`) |
| Unit — format/i18n | none | 19 + 10 its (DZD ×3 locales, date clock, **fr/en/ar key-set parity 1,878×3**, fallback chain) |
| Unit — validation | none | 14 its (optionalMoney negative/cap rejection, empty-string normalization) |
| Unit — matching | none | 16 its (score bands, gates, weights) |
| Unit — visibility scopes | none | 14 its (SALES_AGENT ownOrPool, MANAGER undefined, FIELD_REP project-scoped) |
| Contract — live API | manual curl matrix only | 6 its (401 NO_SESSION envelope + forged cookie, 404 JSON catch-all, /api/health 200 + demoMode assert, bogus login never HTML/500, GET / 200) |
| Runner | no framework, no script | vitest 5.1, `bun run test` → **9 files / 159 tests / 159 passed** |

Infrastructure guarantees: `@/lib/db` aliased to a **throwing stub** (the suite can never touch SQLite), `server-only` stubbed, tests typechecked against real src types (`tests/tsconfig.json`), contract suite self-skips loudly if the dev server is down (stays a meaningful gate).

## 2. Performance remediations delivered

| Item | Fix | Class |
|---|---|---|
| One-bundle SPA (12 static views) | per-view React.lazy + Suspense | P1 — client payload |
| Incentives JS reduce over full scans | `_sum`/`_count` aggregates | P2 — server |
| pendingIncentives unbounded | take 50 + exact count | P2 — server |
| wonOppsWithSource unbounded | take 5000 (house cap) | P2 — server |
| SAV full-table scan | take 5000 (derived sort law preserved) | P2 — server |
| Analytics monthlyTrend full-window rows | SQL-side per-month count/aggregate | P2 — server |
| Per-poll duplicate re-scan (5k leads/minute/tab) | 60s TTL cache + bust on merge/dismiss | P2 — server |
| Matching stale rows + N+1 | one-tx prune + upserts | P3 — server |
| Query logging in prod | dev-only | P2 — server |

N+1 audit: zero `await`-in-`.map` patterns exist anywhere (grep-proven); the remaining sequential loops (matching upserts, settings upserts, expiry sweeper) are bounded-by-small-N and deliberate.

## 3. Integration & regression verification (Wave 6)

- **Static gates**: tsc 0 · eslint 0 · 159/159 tests.
- **Live API battery (authed, admin cookie)**: /api/health, /dashboard, /reservations, /leads, /opportunities, /tasks, /sav, /analytics, /journey, /notifications, /visits, /finance/installments — **all 200**.
- **Negative battery (live)**: unauth → 401 JSON; unknown path → 404 JSON (new catch-all); negative-money POST → **422 with the new "Le montant ne peut pas être négatif"** message (W1-2 proven live).
- **Browser (read-only)**: login → admin persona → dashboard → leads → pipeline → finance; AR RTL (dir=rtl, lang=ar, zero overflow at 1440 and 375); console zero errors; 8 screenshots in evidence/phase2_1/.
- **Cross-workstream integration**: schema change (convertedAt) + Prisma regenerate + route stamping + migration backfill all consistent (health reports migrations:18); i18n additions (activity.tag ×3) parity-guarded; UI codemods didn't break the i18n parity test; lazy-loading composes with the shell overlays.

## 4. Genuine bugs found by the new suite

1. `normalizePhone` double country code (bare `213…` → `+213213…`) — **fixed** (W5-bugfix) with regression test.
2. `format.ts` doc drift (compact example) — cosmetic, noted.

## 5. Deferred (documented)

- E2E browser automation as a test-suite member (the manual 7-gate protocol + this pass cover it; a Playwright suite is the next QA wave).
- Full mutating golden-path E2E + multi-user concurrency (P2R C-4 — proper QA window).
- request-ID/latency observability layer (S–M, production-scale).
