# ASAS CRM — Phase 2R Recovery · Database, Supabase & Environment Verification Report

**Task ID:** 1-d (AGENT 4 — DATABASE, SUPABASE & ENVIRONMENT VERIFICATION)
**Mode:** STRICTLY READ-ONLY (attestation in §10).
**Date:** 2026-11-02 (this session).
**Subject state:** git `main` @ `693bff9` (working tree clean; no remote; branch `main`).
**Inputs verified:** `prisma/schema.prisma`, `.env`, `.env.example`, `AGENTS.md`, `prisma/migrations/**` (17 dirs), `supabase/**`, `src/lib/server/session.ts`, `src/app/api/auth/login/route.ts`, `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_{INDEPENDENT_AUDIT_REPORT,DATABASE_AUDIT,REMAINING_DEFECTS_REGISTER,PHASE2_IMPLEMENTATION_PLAN,PHASE2_EXECUTION_LOG}.md`, `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md`, `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md`, `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md`, `worklog.md` (targeted), live `db/custom.db` (bun:sqlite, `readonly: true`).
**Fact labels:** [VERIFIED] = directly observed this session · [INFERENCE] = reasoned from verified evidence · [NOT VERIFIED] = could not be checked read-only.

---

## §1 Executive summary

The "active database" of ASAS CRM is **a local sandbox development SQLite file** — `db/custom.db`, git-ignored, addressed by `DATABASE_URL=file:/home/z/my-project/db/custom.db`, provider `sqlite` in `prisma/schema.prisma`. **There is no live Supabase/PostgreSQL connection anywhere in this environment** [VERIFIED]. Supabase exists only as a *documented, optional deployment path* (commented-out template lines in `.env.example`, a `supabase/` migration chain + seed + `config.toml`, and `prisma/schema.postgres.prisma`) — none of it is wired to any active env var or running service.

The live DB file is **structurally current but data-empty**: 30 tables (1:1 with the 30 schema models), **0 rows in every table** (including `AuditLog`), `integrity_check = ok`, zero foreign-key violations, and **zero structural drift vs `prisma/schema.prisma`** (`prisma migrate diff` → "No difference detected"). However:

1. **`_prisma_migrations` is absent** → `bunx prisma migrate status` reports **all 17 migrations as not applied** (bookkeeping lost — the documented R13 phenomenon) [VERIFIED].
2. **The D12 partial unique indexes are MISSING from the live DB** — they exist as migration #17 on disk (`20261102000000_phase2_d12_live_hold_unique`) but not in `sqlite_master` [VERIFIED]. The schema-vs-DB diff is blind to them precisely because Prisma cannot express partial indexes — the migration chain is the only carrier.
3. **`ASAS_SESSION_SECRET` is missing from `.env`** (which contains only `DATABASE_URL`) → the running dev server logs the ephemeral-fallback warning; sessions reset on every restart [VERIFIED in `dev.log`].
4. **`journal_mode = delete`** (the SQLite default) while `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md` documents a "WAL" posture [VERIFIED]. The audit's "WAL disabled/off" claim is a **SQLite journal_mode finding** — there is no PostgreSQL `wal_level`/`archive_mode` claim anywhere in the audit corpus.

**Every one of these five conditions is an ENVIRONMENT issue (the R13 sandbox-reset class), not a source-code issue.** The repo itself is complete and correct for recovery: the 17-migration chain is coherent and contains the D12 SQL; `prisma validate` passes; the seed (`prisma/seed.ts`, wired to `bun run db:seed`) exists; the session-secret fallback and production demo-mode fail-fast are coded as designed. This matches the independent audit's own classification (REMAINING_DEFECTS_REGISTER §4: "Environment-class blockers … NOT code defects") and two prior identical wipe signatures in `worklog.md:4361/:4400`. The contamination commit `753d115` touches **no** `prisma/`, `.env`, or `db/` files [VERIFIED — its 103-file list is docs/audits + evidence PNGs only], so none of the DB/env blockers are attributable to it.

The sanctioned recovery (AGENTS.md:17, quoted in §8) is an operations runbook: fresh DB → `bunx prisma migrate deploy` (17/17) → `bun run db:seed` → re-append `ASAS_SESSION_SECRET` → restart; optionally re-apply `PRAGMA journal_mode = wal` (R-E5). No source changes required.

---

## §2 Database identity — local SQLite dev DB, not production

| Item | Finding | Status |
|---|---|---|
| Prisma datasource | `datasource db { provider = "sqlite", url = env("DATABASE_URL") }` — `prisma/schema.prisma:9-12` | [VERIFIED] |
| Active `DATABASE_URL` | `file:/home/z/my-project/db/custom.db` — the sole line of `.env` (50 bytes total) | [VERIFIED] |
| Active DB file | `db/custom.db` — 626,688 bytes (153 pages × 4096), mtime Nov 2 14:00; git-ignored via `.gitignore:40` (`/db/`); `git ls-files db/` → empty (never in VCS) | [VERIFIED] |
| Postgres/Supabase env vars | **None.** No env var in `.env` points at any Postgres/Supabase host; no `.env.local`/`.env.production` exists (only `.env` + tracked `.env.example`) | [VERIFIED] |
| Supabase artifacts in repo | `supabase/migrations/` (0001–0004 SQL), `supabase/seed.sql`, `supabase/config.toml`, `prisma/schema.postgres.prisma` — the *documented optional* PG deployment path (`.env.example:8-15` comments it out; `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md`, `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md`) | [VERIFIED — inert/documented, not active] |
| CI database | `.github/workflows/ci.yml:69,74` → `DATABASE_URL: file:./db/ci-check.db` (a CI-local SQLite file — not production) | [VERIFIED] |
| Deployment configs | No `vercel.json`, no `Dockerfile`, no `docker-compose.yml`; `next.config.ts` references no DB | [VERIFIED] |
| Running services | Dev server on :3000 (`next-server`, pid 1120) + Caddy gateway on :81 — the sandbox pattern of AGENTS.md ("Dev server must run on port 3000") | [VERIFIED] |
| Project purpose | AGENTS.md:8 — "Demo workspace with seeded data incl. coherent won-deal history" (real-estate CRM for the Algiers market) | [VERIFIED] |

**Verdict:** the "active database" is the **local sandbox development SQLite file** — a demo workspace per the project's own charter. It is NOT a production database, and no production/remote DB is referenced by any tracked file or live environment variable. [VERIFIED]

**Supabase clarification (mission item):** the "Supabase" mention in commit `ae9357f`'s context corresponds to `.env.example`'s *commented-out optional PostgreSQL path* (Session Pooler URL template) + the `supabase/` chain — a documented deployment option for a future owner-executed deployment (see `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md` provider matrix). Nothing in the current environment connects to it. The independent audit's own scope note concurs: "no PG instance exists anywhere in the environment". [VERIFIED]

---

## §3 Current DB state — full census (bun:sqlite, `readonly: true`)

30 tables, **0 rows in every single one** — including `AuditLog` (no audit residue either; the wipe was total):

| Table | Rows | | Table | Rows |
|---|---|---|---|---|
| Activity | 0 | | Organization | 0 |
| Apartment | 0 | | Payment | 0 |
| AuditLog | 0 | | Pipeline | 0 |
| Building | 0 | | PipelineStage | 0 |
| Contact | 0 | | Project | 0 |
| Developer | 0 | | ProjectAssignment | 0 |
| Document | 0 | | PropertyMatch | 0 |
| Installment | 0 | | Requirement | 0 |
| Lead | 0 | | Reservation | 0 |
| LeadDuplicateDismissal | 0 | | SalesTarget | 0 |
| LeadTag | 0 | | SavCase | 0 |
| Opportunity | 0 | | SavedSearch | 0 |
| OrgSetting | 0 | | Tag | 0 |
| User | 0 | | Task | 0 |
| Visit | 0 | | VisitApartment | 0 |

[VERIFIED — `SELECT COUNT(*)` per table via a read-only connection]

- Table `Customer` does **not** exist — leads are the customer entities (Lead → Contact conversion), matching the schema's 30 models 1:1. [VERIFIED]
- Health: `PRAGMA integrity_check` → **ok**; `PRAGMA foreign_key_check` → **0 rows**. The file is a clean, structurally sound, *empty* schema. [VERIFIED]
- File properties: page_size 4096, page_count 153, encoding UTF-8, user_version 0, `foreign_keys=0` on my raw connection (per-connection default; Prisma enables FKs per connection — documented in DATABASE_AUDIT: "raw SQLite connections have FKs OFF (Prisma enables them)"). [VERIFIED]
- No `-wal`/`-shm`/`-journal` sidecars in `db/` (only `custom.db`) — consistent with journal_mode `delete`. [VERIFIED]
- `db/backups/` is wiped (audit R-E4): the directory does not exist — `db/` contains only `custom.db`. [VERIFIED]

For contrast, the last known-good seeded census (Phase 2 / R15 indicator battery, before the reset): Org 1 / User 8 / Lead 43 / Opportunity 21 / Apartment 46 / Reservation 8 / Activity 185 / AuditLog 132. [VERIFIED as documented claims in `ASAS_CRM_PHASE2_EXECUTION_LOG.md` R15 addendum — the runtime state itself was wiped after the fact]

---

## §4 Migration chain vs applied state

**Chain on disk (17 migrations, `prisma/migrations/`)** [VERIFIED]:

```
0_init
20261003020538_p4_composite_indexes
20261007120000_p8_9_schema_catchup_stage_changed_at
20261007234744_p11_stage_wip_limit
20261008022052_p13_finance_installments
20261008154438_p14_sav_cases
20261008231000_p16_remove_sav
20261009050000_p18_crm_premium_operating_model
20261009080000_p20_visit_decision_lifecycle
20261011090000_p29_commercial_trust
20261011150302_p30_duplicate_management
20261019174640_p54_two_step_closure
20261027140445_phase_c_visit_report
20261031101714_pd_finance_sav_targets
20261101184000_master_w18_incentive_index
20261101224756_arabic_aliases
20261102000000_phase2_d12_live_hold_unique   ← LATEST (migration #17, commit 0d36f3e)
```

**Applied state in the live DB: NONE recorded.**

- `SELECT name FROM sqlite_master WHERE name LIKE '%prisma%'` → **`[]`** — the `_prisma_migrations` table does not exist. [VERIFIED]
- `bunx prisma migrate status` → "17 migrations found in prisma/migrations. Following migrations have not yet been applied:" — **lists all 17, including `0_init`**. (Healthy expected output per `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md`: "Database schema is up to date!".) [VERIFIED — verbatim output captured]
- Yet the physical schema is current through migration #16: `PipelineStage.wipLimit` (p11), all finance/commission/incentive columns on `Reservation` (pd_finance), `Reservation_orgId_incentiveStatus_idx` (w18), `Lead.fullNameAr` (arabic_aliases #16) are all present. [VERIFIED via `PRAGMA table_info` + `sqlite_master`]
- `bunx prisma migrate diff --from-url <copy-of-db> --to-schema-datamodel prisma/schema.prisma` → **"No difference detected"** — zero structural drift between the live file and `schema.prisma`. (Run against a `/tmp` **copy** of the DB so the original file was never opened writable — see §10.) [VERIFIED]

**Provenance verdict [INFERENCE, high confidence]:** the current file was produced by a schema-sync of `schema.prisma` (`prisma db push`-class) rather than `migrate deploy`: schema-complete but bookkeeping-free, and therefore **missing everything that lives only in raw migration SQL** — the two D12 partial unique indexes (§5). This matches the independent audit's phrasing ("a `db push` artifact with no `_prisma_migrations`") and the house DB audit's Phase-1-era finding ("DB was built via `db push`"), i.e. the recurring R13 re-provisioning behavior of this sandbox.

**Historical corroboration (the phenomenon is recurring and documented):** AGENTS.md Round addendum: "Migration chain is now authoritative (15 applied; `_prisma_migrations` present)" (P18 era); Phase 2 plan: "16 applied (R14 recovery ran `migrate deploy` 16/16)"; R15 battery: "migrations 17/17 applied · D12 partial unique indexes present in live DB"; then the reset. `worklog.md:4361` and `:4400` record **two earlier wipes with the identical forensic signature** ("0 rows in EVERY model … `_prisma_migrations` MISSING … journal_mode=delete; no -wal/-shm; `.env` carries only DATABASE_URL"). [VERIFIED as documented history]

**Documented remediation paths** (operations, not code): AGENTS.md:17 — "A restored DB may lose `_prisma_migrations` bookkeeping → `bunx prisma migrate resolve --applied 0_init` BEFORE `migrate dev` (bookkeeping only)"; the Phase 1 DB audit adopted `migrate resolve --applied` ×14 for a *restored* DB; the current defects register prescribes the cleaner fresh-file path (R-E1/R-E2): fresh `db/custom.db` → `bunx prisma migrate deploy` (17/17, creates the D12 indexes + bookkeeping) → `bun run db:seed`. [VERIFIED as documented procedures — none executed by this agent]

---

## §5 D12 index — definition, presence, verdict

**Disambiguation first [VERIFIED]:** "D12" in the Phase 2 context is the **Phase 1 audit defect ID D12 — the concurrent twin (double-booking) race** — NOT decision-log `D-012` (which is "Secrets purge: current-tree remediation only", DECISION_LOG.md:58). The Phase 2 plan adopted it as task W2.1; commit `0d36f3e` ("feat: PHASE 2 — controlled implementation round (D12 DB-enforced + prod fail-fast …)") implemented it.

**Definition [VERIFIED — migration SQL read verbatim], `prisma/migrations/20261102000000_phase2_d12_live_hold_unique/migration.sql` (migration #17):**

```sql
CREATE UNIQUE INDEX `Reservation_apartment_live_hold_uq`
  ON `Reservation` (`apartmentId`)
  WHERE `status` IN ('ACTIVE', 'CLOSURE_REQUESTED');

CREATE UNIQUE INDEX `Reservation_opportunity_live_hold_uq`
  ON `Reservation` (`opportunityId`)
  WHERE `status` IN ('ACTIVE', 'CLOSURE_REQUESTED');
```

Semantics (per the migration header): one live hold per apartment AND one live hold per opportunity, enforced at the DATABASE layer — the durable closure of the D12 interleaved-commit race; partial by design so EXPIRED/CANCELLED/CONVERTED rows leave the index (re-booking stays legal; the ADR-004 global-unique deadlock lesson is preserved). Prisma cannot express partial indexes → raw SQL by design; the DB is managed `migrate deploy`-only (house law — `migrate dev` would flag them as drift). The route's existing P2002 catch maps violations to 409 `ALREADY_RESERVED`.

**Presence matrix:**

| Location | Present? | Evidence |
|---|---|---|
| Migration files (chain) | **YES** | migration #17 exists with the two `CREATE UNIQUE INDEX` statements [VERIFIED] |
| `prisma/schema.prisma` comment | YES (documentation) | schema.prisma:607-615 documents both indexes + the deploy-only law [VERIFIED] — not schema-expressible, so not in the datamodel itself |
| **Active DB (`db/custom.db`)** | **NO** | `SELECT name, sql FROM sqlite_master WHERE type='index' AND tbl_name='Reservation'` → 6 indexes (orgId_status_expiresAt, opportunityId, status_expiresAt, orgId_agentId, orgId_incentiveStatus + the implicit PK autoindex); global search `name LIKE '%live_hold%' OR sql LIKE '%live_hold%'` → **`[]`** [VERIFIED] |
| `bunx prisma migrate status` | Agrees | lists `20261102000000_phase2_d12_live_hold_unique` among the not-yet-applied [VERIFIED] |
| Supabase PG variant | PARTIAL (known defect ND-B3) | only the per-apartment index exists (`supabase/migrations/20261030000002_business_constraints.sql:70` — `Reservation_apartmentId_active_key`); the per-opportunity one is missing while `schema.postgres.prisma` claims parity [VERIFIED] |

**Verdict:** D12 is **defined in the repository (migration #17, present), and ABSENT from the active database** — precisely the bookkeeping-free re-provisioned file's blind spot. The invariant is therefore NOT operative on the live file; the application-level in-transaction guards in `POST /api/reservations` (status re-read + check inside `db.$transaction`) remain the first line and fully cover the sequential double-click, but the theoretical interleaved-commit race is open until the indexes are applied. With **0 reservations in the DB** the exposure today is nil; it becomes real the moment data exists without the indexes (i.e. if one seeded via `db push` instead of `migrate deploy`). The documented recovery (R-E2: fresh DB → `migrate deploy` 17/17) recreates both indexes; acceptance = both index names present in `sqlite_master` + violation probe on a COPY fires. [VERIFIED]

---

## §6 ASAS_SESSION_SECRET — usage map, fail-fast behavior, recovery

**Where it is read [VERIFIED — the ONLY code site]:** `src/lib/server/session.ts:28-35`:

```ts
const SESSION_SECRET =
  process.env.ASAS_SESSION_SECRET ??
  (() => {
    console.warn(
      "[session] ASAS_SESSION_SECRET not set — generated ephemeral secret (sessions reset on restart)",
    );
    return randomBytes(32).toString("hex");
  })();
```

**How it is used [VERIFIED]:** HMAC-SHA256 key signing the `asas_user` session cookie — `signSession()` builds `${userId}.${issuedAtMs}.${hmacHex}`; `verifySessionCookie()` recomputes the HMAC and compares with `timingSafeEqual` (constant-time), enforces the 7-day absolute expiry (`SESSION_MAX_AGE_MS`) and password-change invalidation (`passwordChangedAt`). Consumed by `getCurrentUser()` → `requireUser()` on every protected route. Raw-userId cookies and tampered values are treated as "no session".

**Current condition [VERIFIED]:** `.env` contains only `DATABASE_URL` — the secret is ABSENT. The running dev server is on the ephemeral fallback: `dev.log` contains the exact warning string `[session] ASAS_SESSION_SECRET not set — generated ephemeral secret (sessions reset on restart)`. Impact: every dev-server restart invalidates all sessions (login does not break; session *durability* does).

**Fail-fast behavior — precise semantics [VERIFIED]:**
- **The app does NOT refuse to boot when the secret is missing — in dev OR production.** The fallback is a *dev-safe* design: ephemeral per-process secret + a loud `console.warn`; the code comment states "PRODUCTION MUST SET ASAS_SESSION_SECRET".
- The "prod fail-fast" shipped in commit `0d36f3e` (W2.2) is a **different variable — `ASAS_DEMO_MODE`**, not the session secret: `isDemoModeMisconfigured()` = `NODE_ENV === "production" && demoMode` → one-time boot warning in `session.ts:119-125` + quick-login 500 `DEMO_MODE_PRODUCTION_MISCONFIG` (`api/auth/login/route.ts:64-70`) + `demoUsers` suppressed on `/api/auth/session`. In the sandbox (`NODE_ENV=development`) it is inert by construction.
- So the accurate statement is: *secret missing → ephemeral fallback + warning (documented behavior, P2 environment issue R-E3); demo mode in production → fail-fast refusal (code-verified, runtime-not-verified — R-C4).* Conflating the two would be a misreading of the Phase 2 commit message.

**Configuration location [VERIFIED]:** the git-ignored `.env` at the project root (`ASAS_SESSION_SECRET=<value>`); tracked template `.env.example:22` (`ASAS_SESSION_SECRET=replace-me-openssl-rand-hex-32`); full contract in `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md` (required in production; server-only; runtime read).

**Sanctioned generation methods (documented; NOT executed by this agent):**
- AGENTS.md:17 (R13 runbook): "re-append `ASAS_SESSION_SECRET` from a fresh `randomBytes(24)` + restart server."
- `.env.example` + `ENVIRONMENT_VARIABLES.md`: "Generate with: `openssl rand -hex 32`."

Minor doc inconsistency [VERIFIED]: two documented generation recipes (24 random bytes vs 32 bytes-as-64-hex). Both produce a valid HMAC-SHA256 key (any length accepted); functionally irrelevant, noted for the record. Also note the git-history caveat: the historical secret blob must never be re-used (D-012/D-013; GIT_HISTORY_PURGE.md).

---

## §7 WAL / journal-mode — the precise finding

**Actual value [VERIFIED]:** `PRAGMA journal_mode` on the live `db/custom.db` (read-only connection) → **`delete`** — which is the SQLite *default* journal mode. There are no `-wal`/`-shm` sidecar files. `journal_mode=wal` is a persistent property of the DB file itself; `delete` is what any freshly created / re-provisioned / `db push`-built file carries unless someone executes `PRAGMA journal_mode=wal`.

**Does anything in the source/config set it? [VERIFIED — NO]:** `rg "journal_mode|PRAGMA|pragma"` over `src/`, `prisma/`, `tmp-scripts/` → the only PRAGMAs are `foreign_keys` / `defer_foreign_keys` **inside migration SQL** (standard Prisma-generated table-rewrite boilerplate). `src/lib/db.ts` is a plain `PrismaClient` (no pragmas). `prisma/schema.prisma` carries no SQLite pragma directives (SQLite has no schema-level journal-mode knob). Nothing in the repo ever executes `PRAGMA journal_mode=wal`.

**What the audit docs actually say [VERIFIED — exact quotes]:**

| Document | Wording |
|---|---|
| `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_DATABASE_AUDIT.md` (item 5, P3) | "journal_mode=delete → WAL at next maintenance window (deferred — dev server live)" |
| `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_INDEPENDENT_AUDIT_REPORT.md` §1 | "a `db push` artifact with no `_prisma_migrations`, no D12 indexes, WAL off" |
| Same, §3.4 | "`journal_mode=delete` (WAL claim REFUTED for the current file)" — and §2: "live `db/custom.db` probed read-only (30 tables, 0 rows, journal_mode=delete)" |
| `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_REMAINING_DEFECTS_REGISTER.md` R-E5 (P2, ENV class) | "WAL claim currently false (`journal_mode=delete`) → Re-apply PRAGMA after recovery → acceptance: `PRAGMA journal_mode` = wal" |
| `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md` (posture claim) | "SQLite single-file (`db/custom.db`, WAL) + Prisma 6" |

**Classification [VERIFIED]:** the audit's "WAL disabled/off" is a **SQLite `journal_mode` finding, loosely worded**. The auditors ran (or relied on) `PRAGMA journal_mode` against the SQLite file, got `delete`, and contrasted it with the architecture doc's "WAL" posture claim. There is **no PostgreSQL `wal_level`, `archive_mode`, or WAL-archiving claim anywhere in the audit corpus** — no managed-service configuration is involved; the word "WAL" refers to SQLite's write-ahead-logging journal mode. Per the mission's framing: this is **not** a mislabeled PostgreSQL claim; it is a real SQLite configuration observation expressed in shorthand, whose substance is: *"the documented WAL posture is not (or no longer) set on the current file, because the file was re-provisioned after a reset and nothing in the repo re-applies the pragma."*

**Materiality:** P3 per the house DB audit, P2 (ENV class) per the defects register. It is a performance/durability-tuning property of a single-writer dev file — `integrity_check` is `ok` and FK checks are clean, so no data-integrity consequence. Remediation is a one-line operations action (`PRAGMA journal_mode = wal` after recovery — R-E5), zero source code involved. (Worth noting: since no migration/source ever sets it, "WAL ON" was itself a manually-applied, non-reproducible-from-repo state — the durable fix would be a documented ops step or a `PRAGMA` executed by tooling; that is an operations-policy observation, not a code defect.) [INFERENCE on the origin of the prior WAL state; the current `delete` value itself is VERIFIED]

---

## §8 Environment blockers register

All five blockers (+ the sixth observed collateral) are **environment-class**: repairable by the documented runbook without code changes. Format per mission: actual condition / evidence / impact / environment affected / required action (documented, quoted) / responsible party / production risk.

| # | Blocker | Actual condition (verified) | Evidence (command → output) | Technical impact | Environment affected | Required action (documented — NOT executed) | Responsible party | Production risk |
|---|---|---|---|---|---|---|---|---|
| 1 | **Empty DB** (audit: "Active database contains zero rows") | 0 rows in all 30 tables incl. `AuditLog` | bun:sqlite readonly `SELECT COUNT(*)` per table → all 0 | No login possible (no users) → all authenticated QA/acceptance BLOCKED; demo workspace charter unfulfilled | Local sandbox dev DB only | AGENTS.md:17: "verify `user` count ≠ 0 before QA; recover via `bun run db:seed` (canonical since D-016)" — full runbook R-E1: fresh DB → `bunx prisma migrate deploy` (17/17) → `bun run db:seed` | Operations/deployment (sandbox session entry) | None to production (production deploys fresh + owner-seeded); blocks acceptance of the *sandbox* deliverable only |
| 2 | **`ASAS_SESSION_SECRET` missing** | `.env` holds only `DATABASE_URL`; ephemeral fallback ACTIVE in the running server | `Read .env` (1 line); `rg -a ASAS_SESSION_SECRET dev.log` → "[session] ASAS_SESSION_SECRET not set — generated ephemeral secret (sessions reset on restart)" | Sessions reset on every server restart; signed-cookie continuity lost (auth still functions per-restart) | Local sandbox only (prod would carry its own env) | AGENTS.md:17: "re-append `ASAS_SESSION_SECRET` from a fresh `randomBytes(24)` + restart server" (R-E3; `.env.example` documents `openssl rand -hex 32`) | Operations/deployment | Production deployments MUST set it (documented); here: zero — sandbox-only durability nuisance |
| 3 | **`_prisma_migrations` absent** | Bookkeeping table does not exist | sqlite_master `LIKE '%prisma%'` → `[]`; `bunx prisma migrate status` → all 17 "not yet been applied" | Tooling cannot see applied state; naive `migrate deploy` on this file would attempt to replay (and `migrate dev` would flag drift); provenance untraceable via Prisma | Local sandbox dev DB only | AGENTS.md:17: "A restored DB may lose `_prisma_migrations` bookkeeping → `bunx prisma migrate resolve --applied 0_init` BEFORE `migrate dev` (bookkeeping only)" — or the R-E1 fresh-file + `migrate deploy` path | Operations/deployment | None (fresh production installs run `db:deploy` from scratch — bookkeeping created then) |
| 4 | **D12 partial unique indexes absent** | Neither `Reservation_apartment_live_hold_uq` nor `Reservation_opportunity_live_hold_uq` exists in the live DB | sqlite_master index query on `Reservation` → 6 indexes, no live_hold; global `LIKE '%live_hold%'` → `[]` | The D12 DB-enforced one-live-hold invariant is not operative on the live file; in-tx route guards still cover the sequential race; theoretical interleaved-commit race open once data exists (today: 0 reservations → zero live exposure) | Local sandbox dev DB only | R-E2: same runbook — "migrate deploy creates both indexes"; acceptance: "Both index names present in `sqlite_master`; violation probe on a COPY fires" | Operations/deployment (the SQL exists in the chain; applying it is a deploy step) | Real *if* someone deployed by `db push`/schema-sync instead of the migration chain — production deploys use `migrate deploy`, which creates them. Separate known P2: PG chain lacks the per-opportunity index (ND-B3) — a repo defect for the *optional* Supabase path, already registered |
| 5 | **"WAL disabled"** (precise: `journal_mode=delete` vs documented WAL posture) | `PRAGMA journal_mode` → `delete` (SQLite default); no `-wal`/`-shm` sidecars; nothing in source/config ever sets it | bun:sqlite readonly `PRAGMA journal_mode` → `{"journal_mode":"delete"}`; `rg journal_mode\|PRAGMA src/ prisma/` → only migration-SQL FK pragmas | Performance/durability tuning only (single-writer dev file); integrity unaffected (`integrity_check` ok) | Local sandbox dev DB only | R-E5: "Re-apply PRAGMA after recovery" → acceptance "`PRAGMA journal_mode` = wal" — one ops statement, zero code | Operations/deployment | None (a production Postgres/Supabase deployment has an entirely different WAL story managed by the provider; nothing in this repo claims otherwise) |
| 6 | (Collateral, audit R-E4) **`db/backups/` wiped** | Directory absent; `db/` contains only `custom.db` | `ls db/` → custom.db only | No sha256-anchored snapshot baseline for the recovery session | Local sandbox only | R-E4: "Re-establish baseline after recovery" → fresh `bun run db:snapshot` post-recovery | Operations/deployment | None |

**Quoted R13 recovery law (AGENTS.md:17, verbatim, the canonical procedure):**

> "Environment resets can wipe DB data AND revert .env between sessions (observed Phase 4, R13): verify `user` count ≠ 0 before QA; recover via `bun run db:seed` (canonical since D-016) + re-append `ASAS_SESSION_SECRET` from a fresh `randomBytes(24)` + restart server. A restored DB may lose `_prisma_migrations` bookkeeping → `bunx prisma migrate resolve --applied 0_init` BEFORE `migrate dev` (bookkeeping only)."

---

## §9 Source-vs-environment classification verdict

**Source-code issues among the five investigated blockers: NONE. [VERIFIED]**

- The migration chain (incl. D12 SQL #17) is complete and coherent on disk; `bunx prisma validate` → "The schema at prisma/schema.prisma is valid 🚀"; `migrate diff` DB-copy↔schema → "No difference detected".
- The seed exists and is wired (`package.json` → `"prisma": {"seed": "bun run prisma/seed.ts"}` → `bun run db:seed`).
- The session-secret fallback + production demo-mode fail-fast are coded exactly as documented (session.ts, login route).
- Nothing in the repo sets or requires a non-default journal mode; the WAL posture claim lives in one doc line and its remediation is an ops PRAGMA.
- No tracked file points at a production/remote DB: `DATABASE_URL` appears only in `.env.example` (template), CI (`file:./db/ci-check.db` — CI-local SQLite), docs, and `supabase/seed.sql` (the optional PG path). No `vercel.json`, no Dockerfile, no git remote (`git remote -v` → empty).

**Environment issues: ALL FIVE (plus R-E4).** They share one root cause — the R13-class sandbox reset/re-provisioning that wipes `db/` data and reverts `.env` — with the identical signature previously documented twice (worklog:4361, :4400) and classified by the independent audit itself as "Environment-class blockers (repairable by the documented runbook; NOT code defects)".

**Contamination-commit cross-check [VERIFIED]:** `git show 753d115 --name-only` → 103 files, all `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/*.md` + `evidence/**.png`; `rg -i "prisma|\.env|db"` over that list → **zero matches**. The contamination is purely additive docs/evidence and contributes nothing to any DB/env blocker. (The code damage attributed to 753d115 elsewhere — tsc/i18n/journey — is outside this agent's remit and untouched here.)

**One repo-side caveat for completeness [VERIFIED, already registered]:** ND-B3 — the *optional Supabase PG chain* lacks the per-opportunity live-hold index that `schema.postgres.prisma`'s comment claims; and ND-B12 — `package.json` still exposes a `db:migrate` = `migrate dev` alias that contradicts the deploy-only law. Both are pre-registered P2/P3 repo defects affecting the *future optional* PG path / developer ergonomics — neither affects the active SQLite environment nor any of the five blockers above.

---

## §10 Read-only attestation

Every command executed this session (all read-only; the only writes were the single deliverable report file below and a scratch `/tmp` copy of the DB that was created and deleted for a safe diff — the real `db/custom.db` was only ever opened `readonly: true`):

1. `Read` — AGENTS.md, prisma/schema.prisma, .env, .env.example, prisma/migrations/20261102000000_…/migration.sql, prisma/migrations/20261101224756_…/migration.sql, prisma/migrations/20261101184000_…/migration.sql, src/lib/server/session.ts, src/app/api/auth/login/route.ts, 05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_PHASE2_IMPLEMENTATION_PLAN.md, ASAS_CRM_INDEPENDENT_AUDIT_REPORT.md, ASAS_CRM_DATABASE_AUDIT.md, ASAS_CRM_REMAINING_DEFECTS_REGISTER.md, 05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md, 05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md (head).
2. `bun -e` with `new Database('/home/z/my-project/db/custom.db', {readonly: true})` — `SELECT name FROM sqlite_master WHERE type='table'`; `SELECT COUNT(*)` per table; `PRAGMA journal_mode / page_size / page_count / foreign_keys / encoding / user_version`; index queries on `sqlite_master` (`type='index'`, `tbl_name='Reservation'`, `LIKE '%live_hold%'`, `LIKE '%prisma%'`); `PRAGMA table_info('PipelineStage'|'Lead'|'Reservation')`; `PRAGMA integrity_check`; `PRAGMA foreign_key_check`.
3. `git log --oneline -5`; `git status --short` (clean); `git show 753d115 --name-only` (+ `rg` over the list); `git show 693bff9 --stat`; `git show 0d36f3e --stat`; `git remote -v` (empty); `git branch --show-current`; `git check-ignore -v db/custom.db .env`; `git ls-files db/` (empty).
4. `ls -la prisma/migrations/ db/ .env*`; `ls supabase/migrations/ 05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ 05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ 05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/`; `ls Dockerfile docker-compose.yml vercel.json` (absent).
5. `rg` / `Grep` — `ASAS_SESSION_SECRET` (repo-wide, src/prisma); `journal_mode|journal-mode|WAL|wal_level|archive_mode` (repo-wide); `journal_mode|PRAGMA|pragma` (src/prisma/tmp-scripts); `D-012|D12|live_hold` (DECISION_LOG, schema.prisma, execution log); `DATABASE_URL` (src/, repo-wide tracked); `fullNameAr` (schema); worklog WAL/journal lines; audit-doc WAL lines; `rg -a ASAS_SESSION_SECRET dev.log`.
6. `bunx prisma migrate status` (read-only reporting) — output captured in §4.
7. `bunx prisma validate` (read-only schema check) — valid.
8. `bunx prisma migrate diff --from-url file:/tmp/asas-readonly-probe.db --to-schema-datamodel prisma/schema.prisma` — **run against a `/tmp` COPY** (`cp db/custom.db /tmp/asas-readonly-probe.db`, then `rm` of that copy after) so the live DB was never opened writable; diff-only output "No difference detected".
9. `ss -tlnp | rg "3000|81"` (server state observation); `cat next.config.ts`, `.gitignore`, `src/lib/db.ts`, package.json excerpts, CI excerpt, supabase business-constraints excerpt, DECISION_LOG excerpt, execution-log excerpts via `sed`/`rg`.

**NOT executed (per hard constraints):** `prisma migrate dev / deploy / resolve / reset`, `db push`, `db seed`, any write to `.env`, `db/`, or source; no secret generated; no server restart. The single file created/modified by this agent: **this report** (`05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_PHASE2R_DATABASE_ENVIRONMENT_REPORT.md`).

---

*End of report — AGENT 4, Task 1-d.*
