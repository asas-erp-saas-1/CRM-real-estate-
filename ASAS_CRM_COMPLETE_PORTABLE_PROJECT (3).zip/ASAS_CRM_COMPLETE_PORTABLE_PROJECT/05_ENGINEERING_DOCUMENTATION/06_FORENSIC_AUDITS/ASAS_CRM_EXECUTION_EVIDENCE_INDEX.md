# ASAS CRM — Execution Evidence Index

**Companion to:** `ASAS_CRM_PHASE_COMPLETION_STATUS.md` (same audit session, 2026-11-02).
**Purpose:** structured index of the evidence supporting every major completion claim, classified per the audit mandate into: **[DOC]** documentary · **[SRC]** source-code · **[DB]** database · **[TEST]** test/command output · **[RUN]** runtime & browser. Claims without inspectable evidence are marked NOT VERIFIED — none were found beyond those listed.

---

## E-1. Repository & baseline evidence

| Claim | Class | Evidence (inspectable) |
|---|---|---|
| Repository = `/home/z/my-project`, branch `main`, 302 commits, no remote | [DOC] | `git rev-parse --show-toplevel`; `git branch -a`; `git rev-list --count HEAD`; `git remote -v` (empty) |
| HEAD `b34d5b8` = R15 round, 2026-11-02 00:39:06 +0000 | [DOC] | `git log -1 --format='%ci %s'` |
| Working tree = 36 untracked / 0 modified tracked | [DOC] | `git status --porcelain` (36 lines, all `??`) |
| Round chronology Nov 1–2: R7-PDF 00:29 → CJ 07:52 → NJ 08:30 → MASTER 19:31 → FINAL 21:10 → R14 23:06 → PHASE 2 00:12 → R15 00:39 | [DOC] | `git log --format='%h %ci %s' --since=2026-11-01` (verbatim output preserved in this session) |
| Each round's commit message carries its own delivery summary (the "audit trail in git") | [DOC] | e.g. `9e783bf` (MASTER, 6 agents + 4 waves), `a3a2c27` (FINAL, 9 latent defects), `0d36f3e` (PHASE 2), `b34d5b8` (R15) |

## E-2. Phase 1 audit deliverables (existence + substance)

| Claim | Class | Evidence |
|---|---|---|
| 9 deliverable files exist with real content | [DOC] | `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_{MASTER,ARCHITECTURE,DATABASE,SECURITY,UX_UI,CRM_DOMAIN,QUALITY}_AUDIT.md` + `ASAS_CRM_REMEDIATION_ROADMAP.md` + `ASAS_CRM_EXECUTION_LOG.md`; line counts 28–127; MASTER_AUDIT read in full this session (grades table, 6 P0/P1 findings with file:line anchors, decisions register) |
| Security audit substance (not a stub) | [DOC]+[SRC] | ASAS_CRM_SECURITY_AUDIT.md contains the authN design summary + role matrix + live-probe results; every mechanism it names was located in code by sub-agent AUDIT-V1 (scrypt `auth.ts:44-64`; HMAC `session.ts:44`; expiry `session.ts:38,64`; requireUser pattern) |
| Database audit included ERD + 52 integrity checks | [DOC]+[DB] | `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/DATABASE_DOMAIN_AUDIT.md` (375 lines, ERD); integrity claims re-runnable (and re-run where possible this session: `PRAGMA integrity_check` → ok) |
| UX audit browser evidence (49 screenshots) | [RUN] | `download/qa-master/` (49 before + 13 after, present on disk) |
| Audit executed by 6 parallel agents ~18:00–18:15 Nov 1 | [DOC] | ASAS_CRM_EXECUTION_LOG.md timeline table; commit `9e783bf` message |

## E-3. Remediation implementation evidence (source-code, verified THIS session by sub-agents)

**Sub-agent AUDIT-V1 (Waves 1–2): 17 exact FOUND + 1 PARTIAL (scrypt location nuance) — 18/18 located.**
Key anchors: security headers `next.config.ts:17-18` · cookie secure `login/route.ts:37` · 7d expiry `session.ts:38,64` · SAV_OPEN_STATUSES `constants.ts:517` · incentive index `schema.prisma:672` · D1 guard `reservations/route.ts:248-258` + economics reset `:296-318` · D2 `apartments/[id]/route.ts:68-69` · D3 `opportunities/[id]/route.ts:175-186` · D4 `reservations/route.ts:196-202` · D5 cascade `leads/[id]/route.ts:335-337` · D7 `reservation-lifecycle.ts:213` · D8 single-tx `reactivate/route.ts:39-69` · D10 `reservation-lifecycle.ts:333-335` · pagination `reservations/route.ts:96-97,144-162` · OPPORTUNITY_ALREADY_BOOKED `:268-282` · expiry-scheduler `expiry-scheduler.ts:32-55` · requireUser coverage 70/74 route files (93 call sites; 3 by-design exceptions + 1 template junk file).

**Sub-agent AUDIT-V2 (Waves 3–7 + Phase-2 features): 21 FOUND + 4 PARTIAL (all documented-intentional) — 25/25 located.**
Key anchors: visit-facets `visit-facets.ts:26,43,64` imported by `dashboard/route.ts:27` + `visits/route.ts:24` · visits/tasks helpers `visits.ts:11,23,37-55` / `tasks.ts:6-13` · findOpportunity `opportunities.ts:18` · cache headers `dashboard/route.ts:627`, `analytics/route.ts:290` · SAV pagination `sav/route.ts:101-102` · copilot 60s timeout `leads/[id]/copilot/route.ts:40,342-353` · kanban mini-map `pipeline-view.tsx:194-232,424-445` · per-view titles `shell.tsx:108-115` · day-picker locale `lead-drawer-info.tsx:109,297-301` · DA currency `format.ts:48` · adjacency matrices `constants.ts:103,138,153` + UI importers · dark tokens `globals.css:248-315` (5.8:1 comment) · metrics `metrics.ts` + adopters · visit-ladder `visit-ladder.ts:49-90` · lead auto-advance `activities/route.ts:63` + `requirements/route.ts:76-77` · D12 partial unique indexes `migrations/20261102000000_phase2_d12_live_hold_unique/migration.sql:30-36` · targets copy `targets/copy/route.ts:33` (ADMIN gate) · PDF thumb `documents/[id]/thumb/route.ts:66` (poppler `documents.ts:145`) · demo fail-fast `session.ts:115` + `login/route.ts:64-68` · reservation DTO `reservation-dto.ts:47,77-124` (fail-closed floor allowlist) · journey engine `journey.ts:32-41,175,489,590` · i18n domains `i18n/index.ts:34-82` (21 domain files) · RTL `store.ts:346-357` + `globals.css:335-370`.

**Known intentional deviations (documented at source, not defects):** tasks.ts has no findTask (only include); installments `take:500` cap instead of pagination (`installments/route.ts:105-110` comment — SQL pagination would lie on derived buckets); copilot uses Promise.race timer not AbortSignal (SDK exposes no abort — route comment); metrics names are docblock vocabulary over exported helpers.

## E-4. Quality-gate evidence (command outputs)

| Claim | Class | Evidence |
|---|---|---|
| tsc = 0 at HEAD | [TEST]+deduction | This session: `bunx tsc --noEmit` on working tree → 23 errors, **every one inside untracked files** (16 template-dep errors in `src/components/ui/*`; 6 orphan-journey errors in `src/lib/server/journey-{stats,worklist}.ts` + `journey-stage-chip.tsx:29`; 1 in journey-stats). Tracked-file subset = 0 errors → HEAD state clean. Historical: per-round "tsc 0" receipts in worklog 4709, 4720, 4729, 4767. |
| eslint = 0 | [TEST] | This session: `bunx eslint .` → exit 0. Historical receipts same rows. |
| Migration chain = 17 files | [DOC] | `prisma/migrations/`: `0_init` + 16 timestamped (p4 → p8_9 → p11 → p13 → p14 → p16 → p18 → p20 → p29 → p30 → p54 → phase_c → pd_finance_sav_targets → arabic_aliases → phase2_d12) — matches the claimed 17/17. |
| Golden-path E2E executed (create lead → … → WON 7/7) | [RUN][DOC] | worklog 4706 (26+ screenshots referenced at `download/qa-final/` — folder present on disk); FINAL delivery addendum §1 (9-defect table with severities) |
| 333-probe standing matrix green | [TEST][DOC] | worklog 4728–4729 (R14 re-anchor record: 325 standing + 8 new, two consecutive fresh-seed cycles; 3 drift classes found+fixed — the record demonstrates the matrix was actually run, not asserted) |
| R15 security probe matrix (13 assertions) | [TEST][DOC] | worklog 4762 (3 mismatches investigated and classified BY-DESIGN — the signature of a genuinely executed probe set) |
| WS-S role-aware DTO battery (448 checks) | [TEST][DOC] | commit `e9dae1b` message (detailed battery description incl. both-directions D-021 probes) + `download/qa-ws-s/` on disk |
| 10k-lead performance benchmark | [TEST][DOC] | worklog 464 (dashboard 35–49ms, leads 19–53ms, CSV export 243–311ms — 3 passes) |
| Clean-room handoff validation | [TEST][DOC] | 05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/FINAL_QA_REPORT.md (matrix with PASS/FAIL/BLOCKED/NOT RUN per test; disclosed env-precedence incident + byte-exact restore) |

## E-5. Runtime & browser evidence

| Claim | Class | Evidence |
|---|---|---|
| Historical per-round browser regressions (12 views, RTL, dark, 390px, role isolation, console-0) | [RUN] | Screenshot corpora on disk: `download/qa-master/` (62), `download/qa-final/`, `download/qa-phase2/` (13), `download/qa-r15/` (9), `evidence/qa-r14/` (13), `evidence/cj-journey/` (15), `evidence/cj-perf/` (12), + ~20 more `download/qa-*` folders (p4, p6, p11, p25, p26, p30, p31, p39, p44, p47, p49, p50, p52, phase-b, phase-c, phased-d7r1..r6, ux-palette, uxa, ws-s…) — total 300+ captures incl. VLM verdict JSONs |
| **Current runtime state (this audit's first-hand captures)** | [RUN] | `evidence/phase-status-audit/01-manager-dashboard-broken.png` (manager quick-login → dashboard error alert + raw nav keys), `02-leads-view.png` (leads view: raw `leads.dup.button`, `leads.archive.viewToggle.aria`, «0 résultat(s)») · network log: `GET /api/dashboard` 500 ×5, `/api/notifications` 500 ×3, `/api/leads` 500 ×2 · dev.log: Prisma P2021 `ProjectAssignment` ×4, P2022 `closureRequestedById` ×4 · login/auth/quick-login persona grid: working, fully translated (both dictionaries share auth.* keys) |
| Current DB state | [DB] | read-only probe: integrity ok · 25 tables · 7 users / 44 leads / 10 reservations · `_prisma_migrations` ABSENT · file mtime 2026-10-02 16:40 (R10-era — matches `tmp-scripts/r10-seed-won.ts` 16:28) |
| Supabase PG layer shipped structurally | [SRC][DOC] | `supabase/migrations/`: `0001` init DDL, `0002` CHECK vocabularies, `0003_rls_policies.sql` (130 policy statements), `0004` (20) + `seed.sql` + validator scripts; commit `8679c0f` |

## E-6. Environment-regression evidence (the post-commit divergence)

| Finding | Class | Evidence |
|---|---|---|
| 5 deleted files resurrected | [DOC]+[SRC] | `git log --diff-filter=D -- src/lib/i18n.ts` (deletion chain de9a3d3 → ee04e81 → 26d253e); `git show 26d253e --stat` (5 files, 3,412 deletions); files present on disk with Oct 2–4 mtimes; `git ls-tree HEAD` confirms absence from HEAD |
| i18n shadowing re-activates P26/P32 defect | [RUN]+[SRC] | raw keys observed live (7 keys, §E-5); import graph: `lib/client/store.ts:10` imports `@/lib/i18n` → resolver prefers file `i18n.ts` over directory `index.ts`; the defect class + its UI damage are pre-documented verbatim in commit `ee04e81` (P32: "280 domains-only keys rendered RAW — login overlay «Mounia Larbaoui role.FIELD_REP» browser-caught") |
| Orphaned afternoon work is broken | [TEST] | tsc errors referencing non-existent exports: `openJourneyFocus` (journey-stage-chip:29), `JourneyStatEntry`/`facts` (journey-stats:21,124,134), `isJourneyStalled` (journey-worklist:26) |
| Cron register reaped | [RUN] | scheduler query this session: 0 jobs; project register documents 7 occurrences of the class |
| Backups wiped | [DOC] | `ls db/backups/` — directory absent |

## E-7. Evidence-grade caveats (honest limits of THIS audit)

1. Historical runtime evidence (screenshots, probe outputs) is **preserved artifact**, not re-executable today against the current environment — the DB it ran against is gone. Where the artifact itself is inspectable (screenshots on disk, command receipts in worklog), the claim is graded VERIFIED-at-time; where only the report text survives, the code-level verification of this audit (E-3) carries the claim.
2. The R15 "four indicator" verification (Database/Security/Engineering/UI-UX live batteries, worklog 4761–4766) cannot be re-run for the same reason; its receipt structure (mismatch investigations, byte-level census anchors) bears the signature of genuine execution.
3. No automated test suite exists anywhere in the repo (house-law rejection, R-12) — every [TEST] item above is a command-output or live-protocol receipt, which is the project's documented substitute strategy.
4. This audit ran **zero mutating commands** against source, schema, DB, or git (browser interaction + read-only probes + two read-only sub-agents only; the two screenshots and the three audit documents are the only new files).
