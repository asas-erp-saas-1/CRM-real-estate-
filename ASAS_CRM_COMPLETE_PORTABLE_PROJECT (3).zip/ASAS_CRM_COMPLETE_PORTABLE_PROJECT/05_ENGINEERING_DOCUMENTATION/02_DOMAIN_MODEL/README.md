# 02_DOMAIN_MODEL

**Purpose (EN):** Real-estate CRM domain model, agency operating model, workflow specification.
**الغرض:** نموذج مجال العقارات ونموذج عمل الوكالة وسير العمليات.
**Documents:** 3 · **Renamed from:** `domain`

| # | File | Title | Bytes |
|---:|---|---|---:|
| 1 | `AGENCY_OPERATING_MODEL.md` | ASAS — Agency Operating Model (product truth) | 8,025 |
| 2 | `DOMAIN_MODEL.md` | DOMAIN MODEL & CRM WORKFLOWS | 7,879 |
| 3 | `WORKFLOW_SPECIFICATION.md` | WORKFLOW SPECIFICATION — ASAS CRM (GOV-3, Engineering Recovery Protocol Stage 3) | 25,087 |

--- Part of `ASAS_CRM_COMPLETE_PORTABLE_PROJECT/05_ENGINEERING_DOCUMENTATION` — see root `README.md` for the master index.
