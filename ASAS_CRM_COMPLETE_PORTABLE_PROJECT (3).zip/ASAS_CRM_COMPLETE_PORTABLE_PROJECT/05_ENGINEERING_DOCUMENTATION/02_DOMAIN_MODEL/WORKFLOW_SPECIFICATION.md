# WORKFLOW SPECIFICATION — ASAS CRM (GOV-3, Engineering Recovery Protocol Stage 3)

> **Status: BINDING source of truth for workflow specification** (protocol deliverable mapping §3:
> "consolidated workflow state diagrams are the GOV-3 gap" — this file closes it).
> Supersedes the workflow fragments scattered across `AGENCY_OPERATING_MODEL.md` (the operating-model
> capture — remains the product-intent truth), `PHASE20_VISIT_DECISION_LIFECYCLE.md`,
> `PHASE18_CRM_PREMIUM_OPERATING_MODEL.md`, and `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/USER_JOURNEYS.md` (journeys now point here).
>
> **Verification method (the owner's GOV-3 directive):** every claim below is triangulated —
> (a) **internal evidence**: live schema (`prisma/schema.prisma`, 26 models), live constants
> (`src/lib/constants.ts`), live route code (file:line cited), and the GOV-2 receipts (matrix 231/231,
> runtime probes); (b) **external evidence**: web-search receipts EXT-1…EXT-8 (§1 — the domain's
> real-world anchors: Algerian law 11-04, Ouedkniss, WhatsApp practice, numbering plan, DZD, CRM
> industry benchmarks); (c) **explicit unknowns**: unresolved business rules are marked OPEN-DECISION
> in §9 — never invented, never silently confirmed. **Nothing below was confirmed without a live check.**
>
> Scope: CRM only (D-025 — no ERP). Lead intake → qualification → appointment → field visit →
> reservation → sale, plus the deal economy (agency commission + rep incentive) that is the only
> money the CRM carries.

---

## 1. External verification receipts (web-searched 2026-10-19, `tmp-scripts/gov3-external-verify.ts`)

| ID | Domain claim (from the operating-model capture) | Verdict | External anchor |
|---|---|---|---|
| EXT-1 | Ouedkniss is a real dominant classifieds platform; a genuine real-estate lead channel | **CONFIRMED** | ouedkniss.com/.dz — «1er site des annonces en Algérie», 1M+ annonces, immobilier the headline category |
| EXT-2 | WhatsApp-first selling is a real operating pattern (not an invented one) | **CONFIRMED** | WhatsApp Business real-estate playbooks (property alerts, fast personal contact — trengo/cap-learning Africa guides) |
| EXT-3 | Property sales in Algeria require a notary; a **reservation contract** stage legitimately precedes the deed | **CONFIRMED — STRONG** | **Algerian law 11-04, art. 25** (fgcmpi.org.dq official PDF): «Le contrat de réservation est le contrat par lequel un promoteur immobilier s'engage à livrer au réservataire…» — the Reservation entity has a real legal instrument behind it; notarial contract mandatory for validity |
| EXT-4 | Agency commission received from the developer (primary sales) or the client — both sides occur in practice | **CONFIRMED** | Algerian agency-fee guides: ~1% seller + 1% buyer (lamacta 2025), 3% scales (lkeria) — commission is two-sided in practice, matching `COMMISSION_SOURCES = DEVELOPER \| CLIENT` |
| EXT-5 | Phone normalization law (+213, mobile 05/06/07 → drop leading 0, closed 10-digit plan, E.164 canonical) | **CONFIRMED** | Wikipedia «Telephone numbers in Algeria» + ARPCE.dz (the regulator): closed plan, +213, mobile prefixes 5/6/7 — the implementation `src/lib/phone.ts:22-42` matches the plan exactly |
| EXT-6 | DZD amounts in whole dinars (centimes obsolete) | **CONFIRMED** | Wikipedia «Algerian dinar»: subdivided into 100 centimes, «now obsolete due to their extremely low value» — whole-dinar `amountDZD` fields are the correct convention |
| EXT-7 | The pipeline shape (qualification → visit → offer/reservation → closing) is industry-standard, real-estate-elaborated | **CONFIRMED** | Standard 7-stage sales pipelines (gigradar/Salesforce/close.com: prospecting → qualification → … → closing) — ASAS's 10-stage pipeline elaborates the standard with real-estate-specific visit/option/reservation rungs |
| EXT-8 | Facebook/Instagram/Google attribution sources reflect real Algerian lead-gen practice | **CONFIRMED** | Active Algerian Meta-Ads agencies targeting promoteurs immobiliers (optiimyzer, NovaCreation — which itself advertises on Ouedkniss) |

**Result:** the operating model's externally-checkable facts all survived external verification.
The one externality the CRM deliberately does NOT model: law 11-04's *promesse de vente/compromis*
paperwork and notary fees — out of CRM scope (the `notary`/`contractRef` fields on Reservation are
the honest boundary markers; heavy document workflow → future consideration, never auto-added).

---

## 2. Lead intake across channels (attribution never lost)

**Channels (live `SOURCES`, `constants.ts` — byte-verified == the operating-model capture's 13):**
`WEBSITE · FACEBOOK_ADS · INSTAGRAM · WHATSAPP · OUEDKNISS · GOOGLE · TIKTOK · REFERRAL · WALK_IN ·
PHONE · EXISTING_CUSTOMER · DEVELOPER_REFERRAL · OTHER` — attribution rides `Lead.source` +
`Lead.campaign` from intake through the whole funnel (EXT-1/EXT-8: the channels are the real
Algerian acquisition surface).

**Intake laws (verified in code):**
- **Phone identity**: `orgId + phone` DB-unique (`schema.prisma:198`); normalization to E.164 +213
  (`src/lib/phone.ts:22-42` — 05/06/07 mobile, 021 landline, 00-prefix, international passthrough;
  matches the ARPCE plan per EXT-5).
- **Duplicate discipline (§12.2)**: POST duplicate → 409 with the existing row (force:true override
  = the production «Créer quand même» path); the P30 scan/dismiss/merge machine + the P53 shared
  predicate (`lib/server/duplicates.ts`) — scan ≡ KPI ≡ bell **by construction**; MANAGER+ gated
  (agent scan 403, matrix FR36c live).
- **Soft delete**: `archived` flag (never row deletion).

## 3. Lead lifecycle

**States (live `LEAD_STATUSES`, `constants.ts:13`):**
`NEW → CONTACTED → QUALIFIED → CONVERTED (terminal) · CLOSED_LOST · REACTIVATED`

**G5-P3-7 (D-GOV-5 §9.1 — LANDED 2026-10-19): the `LEAD_TRANSITIONS` adjacency matrix
(`constants.ts`) governs every status PATCH — the controlled-state-machine rule.**

```
NEW ──► CONTACTED ──► QUALIFIED ──► [convert endpoint] ──► CONVERTED (terminal, 409 ALREADY_CONVERTED)
 │   └──────► QUALIFIED (skip-forward: legal — intake fast-track)
 ├──► CLOSED_LOST (lostReason REQUIRED — single:422 & bulk:422)
 │          └─[reactivate endpoint]─► CONTACTED (409 unless CLOSED_LOST; clears lost fields)
 │          └────[PATCH]──► REACTIVATED (matrix edge: the comeback record)
 CONTACTED ──► QUALIFIED · CLOSED_LOST
 QUALIFIED ──► CLOSED_LOST (CONVERTED only via POST /convert — dedicated flow)
 CONVERTED: [] — terminal, NO PATCH exit, NO correction hatch
 CLOSED_LOST ──► REACTIVATED (matrix) — the only row-edge; CONTACTED via /reactivate or manager correction
 REACTIVATED ──► CONTACTED · QUALIFIED · CLOSED_LOST (work resumes)
 any illegal edge ──► 422 LEAD_ILLEGAL_TRANSITION (agent) · MANAGER+ + correctionReason
                      → 200 + LEAD_STATUS_CORRECTED audit row (reason rides the row — the
                      traceable override; matrix probes §42 FR42a–m)
```

**Enforced discipline (verified):** CONVERTED locked (`INVALID_TRANSITION` when targeted,
`CONVERTED_LOCKED` when left — `leads/[id]:126-135`) · lostReason required incl. bulk
(`leads/bulk` — the P2-c gap is FIXED) · reactivate = CLOSED_LOST→CONTACTED only · convert is
transactional ($transaction, Contact + Opportunity) · the D-021 scope wraps every transition
(in-scope only; foreign = 404) · bulk actions filter to matrix-eligible rows only (the surgical,
no-partial-subset law) · UI companion: the drawer's status menu offers legal edges to everyone
+ a manager-only "Corrections" group whose picks route through the mandatory reason dialog.

**Design posture — RESOLVED (DECISION 1, §9 → G5-P3-7 EXECUTED):** the free-form freedom was
a defect; the adjacency matrix is now the single source of truth, mirrored by the UI and pinned
by the §42 probes (matrix 320/320).

## 4. Qualification & assignment

- **Ownership model**: `ownerId` (agent) ∨ null = the shared intake **pool** (OWN+POOL, D-021 —
  the deliberate product decision; AUTHORIZATION_MODEL §3.1 grounds it).
- **Assignment**: single-lead PATCH `ownerId` = self-service handover on in-scope records
  (documented non-restriction); **bulk assign = MANAGER+** (`leads/bulk:28`) — the asymmetry is
  GOV-2 finding F-05, a confirmed inconsistency awaiting Stage-4 triage, not a workflow rule.
- **FIELD_REP assignment**: `ProjectAssignment` (unique `[projectId,userId]`, `schema.prisma:634`),
  MANAGER+ writes; assignee must be an ACTIVE FIELD_REP (422 `ASSIGNEE_NOT_FIELD_REP` /
  `ASSIGNEE_INACTIVE` §17.2); reassignment audits future-work facts (covered/affected visits).

## 5. The appointment (visit) machine — full server-enforced matrix

**States (live `VISIT_TRANSITIONS`, `constants.ts:54-71` — the ONLY fully matrix-enforced machine):**

```
SCHEDULED ──► CONFIRMED ──► COMPLETED (terminal: outcome required)
    │            │    └──► NO_SHOW ──► [only exit: RESCHEDULED]
    │            │    └──► CANCELLED (terminal)
    │            └──► RESCHEDULED (a pending proposal: confirmable/completable/cancellable)
    │            └──► SCHEDULED (executive reset: MANAGER+ ONLY, unwinds presence stamps, audited)
    └──► REJECTED (terminal; reason required — the proposal is dead)
    └──► NO_SHOW · CANCELLED · COMPLETED (direct from SCHEDULED)
COMPLETED / CANCELLED / REJECTED: [] — a correction is a NEW visit, never history rewrite
```

**Authority laws (all live-verified, matrix 231/231):**
- **Confirm** (SCHEDULED/RESCHEDULED→CONFIRMED): the **assigned FIELD_REP of the visit's project**
  (presence = authority) or MANAGER+ by rank — the follow-up agent NEVER confirms (the operating
  model's central separation). The confirming PATCH may carry the final date.
- **Reject** (SCHEDULED→REJECTED, terminal, reason required) and **counter-proposal**
  (`{scheduledAt, proposeAlternative}`): share the confirmation authority basis (D-026). The
  original slot (`proposedAt`) never moves; the counter arms `awaitingCustomerReconfirm`, lifted
  ONLY by the visit's agent or MANAGER+ («client reconfirmé»).
- **The 3-way partition of pending visits** (P49/P50): unstaffed (§17.3, MANAGER+ KPI) /
  field-decision (FIELD_REP backlog) / customer-reconfirm (agent backlog) — disjoint by construction.
- **§17.3 unstaffed exception**: SCHEDULED/RESCHEDULED visit on a project with no ACTIVE FIELD_REP
  assignment = explicit operational exception; never auto-assign; MANAGER+ sees the KPI + cell;
  the safe recovery is assigning an eligible rep (probe-verified: assignment resolves the exception).
- **Concurrency**: any PATCH may carry `expectedUpdatedAt` → 409 `VISIT_STALE` (no silent
  cross-actor overwrite).
- Illegedge → 422 `VISIT_ILLEGAL_TRANSITION` (matrix guard fires first, D-027).

## 6. Outcomes → opportunity pipeline

**Stages (live pipeline seed, 10 stages):** `NEW → QUALIFIED → VISIT_SCHEDULED → VISIT_COMPLETED →
NEGOTIATION → OPTION → RESERVATION → CONTRACT → CLOSED_WON / CLOSED_LOST` (the EXT-7 industry
pipeline elaborated with real-estate rungs).

**G5-P3-7 (D-GOV-5 §9.1 — LANDED 2026-10-19): the `OPPORTUNITY_TRANSITIONS` adjacency matrix
(`constants.ts`) governs every stage PATCH.** Routine FORWARD moves (any later stage — one motion,
skip allowed; the kanban multi-column drag is progress, not ceremony) stay open to in-scope
users · CLOSED_LOST is reachable from every working stage (lostReason required) · every
BACKWARD move, terminal reopen, and any PATCH entry into CLOSED_WON is a manager correction:
authority → the §9.2 desync law → the mandatory `correctionReason` → the dedicated
`OPPORTUNITY_STAGE_CORRECTED` audit row. **PATCH entry into CLOSED_WON is correction-class on
EVERY edge** — the canonical money path is the two-step closure (`validate_closure` couples
reservation CONVERTED + apartment SOLD + opportunity CLOSED_WON in ONE transaction, §7); a
manager may record an out-of-flow win only with the audited reason. **Reopening a CLOSED_WON
backed by a CONVERTED reservation is refused outright** (422 `OPPORTUNITY_BACKED_BY_SALE` — the
§9.2 desync law: the money-path triad stays coherent; an unbacked won card reopens as a normal
manager correction).

**Enforced discipline (verified):** terminal creation requires `closedAt` (422
`TERMINAL_STAGE_REQUIRES_CLOSED_AT` — the P2-c gap is FIXED) · closing forces probability 100/0
and stamps/clears `closedAt`+`lostReason` (incl. reopen) · lostReason required on close (single
and create) · DELETE only NEW/CLOSED_LOST without reservations (409/422) · WIP-limit editor
ADMIN+ · stage PATCH ADMIN+-gated (the kanban is the MANAGER+/ADMIN vocabulary surface) ·
UI companion: a refused move answers 422 → the shared CorrectionReasonDialog collects the
reason and re-sends (board drag, mobile move and the detail-dialog select alike); below
MANAGER the server's descriptive refusal is the honest toast (matrix §42 FR42n–u).
**Design posture — RESOLVED (DECISION 1, §9 → G5-P3-7 EXECUTED):** the any-target freedom was
a defect; the adjacency matrix is now the single source of truth (forward-only among working
stages, structurally recomputed by probe FR42b), pinned by the §42 probes (matrix 320/320).

## 7. Reservation → sale (the money path)

**States (schema + `RESERVATION_LIFECYCLE` in constants.ts — G5-P3-2/D-GOV-5):**
`ACTIVE → CLOSURE_REQUESTED → CONVERTED · CANCELLED · EXPIRED` — the TWO-STEP closure
(the owner's approved design, §9.2; IMPLEMENTED 2026-10-19):

```
booking (POST, in-scope agent or above):
  $transaction — re-reads apartment AVAILABLE, enforces one-ACTIVE-row (409s) →
  Reservation(ACTIVE, expiresAt default) + apartment → RESERVED

STEP 1 — request_closure (the responsible agent OR MANAGER+; evidence REQUIRED, 422):
ACTIVE ──► CLOSURE_REQUESTED  (closureEvidence + requestedBy/At stamps; audited; the
                               manager bell gains the RESERVATIONS_CLOSURE_REQUESTED queue;
                               the expiring warning keeps covering the hold)

STEP 2 — validate_closure (MANAGER+ only; the ONE transactional money-state event):
CLOSURE_REQUESTED ──► CONVERTED  [$transaction: apartment → SOLD + opportunity → CLOSED_WON
                                   (closedAt, probability 100 — idempotent: an already-won card
                                   is never rewritten); status-preconditioned updateMany = the
                                   retry/concurrency guard: a repeated or concurrent validation
                                   flips ZERO rows → safe 409 RESERVATION_ALREADY_CLOSED]

correction paths (MANAGER+; mandatory reason — the directive's controlled-override law):
CLOSURE_REQUESTED ──► ACTIVE     (reject_closure: reason REQUIRED, closure fields cleared, audited)
ACTIVE|CLOSURE_REQUESTED ──► CANCELLED  (cancel: reason REQUIRED; tx: apartment → AVAILABLE)
ACTIVE|CLOSURE_REQUESTED ──► EXPIRED    (sweeper: guarded, idempotent, closure fields cleared,
                                          apartment released — a request does not freeze the clock)

The free-form `status` PATCH is DEAD (422 EMPTY_PATCH) — named actions only, every action
gated by the law table (from-states × authority × prerequisites). The UI writer lives in
DealEconomicsSection's ClosureWorkflow (agent: prepare w/ evidence; manager: the verification
checklist + validate/reject/cancel) — the F-01 money path is CLOSED.
```

**The deal economy (the ONLY money in the CRM, D-025 — EXT-3/EXT-4 anchor the real-world shapes):**
- `commissionAmount` + `commissionFrom` (DEVELOPER|CLIENT) — agency commission, MANAGER+ writes
  (403 `COMMISSION_FORBIDDEN` below), visible management-side.
- `agentIncentive` — the rep's incentive: visible to the reservation's agent («Mes incentives») +
  management; §38 edge machine `PENDING → APPROVED/REJECTED; APPROVED → PAID` (422 on illegal edges,
  decided-row locks, server-set decidedBy/At + paidAt).
- §37 commission ladder `EXPECTED → EARNED → RECEIVED` — forward-only (422 regression), pairing
  law (422 `COMMISSION_PAIRING`), verified-amounts-required rungs, field locks (409), explicit
  `rebase:true`+reason escape; every move audited.
- `depositPaid` stays (a commercial fact of the reservation — EXT-3's acompte/indemnité
  d'immobilisation analog); everything past it (échéanciers, encaissements) is ERP, out of scope.

**Former gaps on this path — ALL FIXED (2026-10-19, the D-GOV-5 execution arc):**
- **F-01 (HIGH)**: ~~the lifecycle PATCH has no UI writer~~ → **FIXED (G5-P3-2)**: the two-step
  closure is implemented end-to-end (schema migration p54 + the action-based lifecycle + the
  ClosureWorkflow UI + the manager bell queue + matrix §40 FR40a–p + the browser golden path).
- **F-12/B-5**: ~~CONVERTED does not couple the opportunity to CLOSED_WON~~ → **FIXED (G5-P3-2/
  G5-P3-6)**: manager validation = one transactional event (reservation CONVERTED + apartment SOLD
  + opp CLOSED_WON w/ closedAt) — idempotent + concurrency-guarded; the lifecycle is MANAGER-gated.
- **F-02/B-1**: ~~the RESERVATIONS_EXPIRING bell group is org-wide below MANAGER~~ → **FIXED
  (G5-P3-1)**: `reservationScope` spread; regression probes FR37a–e.

## 8. Role access & incentive visibility (per-role workflow map)

| Role | Sees | Acts | Money visibility |
|---|---|---|---|
| OWNER (100) | everything org-wide | everything; assigns projects; may conduct visits (rank path) | all commissions + incentives |
| ADMIN (90) | everything org-wide | users/pipeline-stage/config/audit | all |
| MANAGER (70) | org-wide operational data | confirms visits (rank); sets commissions/incentives; assignments; duplicates; import/export | all |
| SALES_AGENT (40) | own + pool; shared inventory; **own incentives** | full lead→visit→reservation chain on in-scope records; schedules visits, NEVER confirms; reconfirms counters w/ client | `agentIncentive` on own reservations only |
| FIELD_REP (40) | **project-scoped** (assigned projects' visits + their leads/opps/activities); own tasks; NO pool | **confirms/rejects/counters on-site**; completes visits w/ report | — (no incentive surface) |

Cross-rep isolation: 404-byte-identical (matrix FR1/FR2/FR10); leakage channels closed (§4 of the
visibility matrix — search/counts/AI/bulk all scope-composed; the ONE deviation is F-02 above).

## 9. DECISIONS REGISTER — originally the GOV-3 OPEN DECISIONS; resolved 2026-10-19 by the owner's
   Ratification & Execution Directive (**D-GOV-5** — `DECISION_LOG.md`; original texts preserved, resolutions
   appended; items 5 remains open)

1. **Lead/Opportunity transition freedom**: no adjacency matrices (NEW→QUALIFIED direct legal; any
   opp stage PATCH legal). DOMAIN_MODEL documents this as free-form by design; GOV-2-b reads it as
   "discipline-at-terminals only".
   → **RESOLVED (D-GOV-5): the free-form freedom was NOT intended — it is a defect.** Controlled state
   machines are the owner's rule: every important-workflow transition needs a defined source state,
   destination state, authorization rule, and prerequisites; an editable UI field is never itself
   permission to change status. Authorized managers may correct/reopen with mandatory reason +
   permission + audit (explicit, limited, traceable overrides); no unnecessary approval steps on
   routine work; stricter controls on material events. **Remediation: G5-P3-7 — EXECUTED
   2026-10-19** (LEAD_TRANSITIONS + OPPORTUNITY_TRANSITIONS matrices live in `constants.ts`,
   enforced in `leads/[id]` · `leads/bulk` · `opportunities/[id]`, the manager-reason escape
   hatch audited as LEAD_STATUS_CORRECTED / OPPORTUNITY_STAGE_CORRECTED, the §9.2 desync law
   refusing sale-backed CLOSED_WON reopens, the UI companions live, pinned by matrix §42
   FR42a–v, 320/320 — see §3/§6).
2. **The two-step win path**: reservation CONVERTED (apartment SOLD) does NOT set the opportunity
   to CLOSED_WON — the rep/manager moves the kanban card as a second explicit act. Seed models
   both steps. Deliberate explicit-action design (analytics key off stage+closedAt) or desync risk?
   → **RESOLVED (D-GOV-5): two-step closure APPROVED — but the two steps are prepare→validate, not two
   unrelated manual acts.** (i) the responsible agent prepares the closure request with required business
   evidence; (ii) an authorized manager validates (client, unit, terms, references, evidence) and confirms
   the final successful-sale state. Separate workflow states + validation actions; no forced two-human
   separation of duties (a manager who also sells meets the same validation); idempotent, retry-safe,
   duplicate/concurrency-safe. Per the directive's referential-integrity requirement, manager validation
   is ONE transactional business event: reservation CONVERTED + apartment SOLD + opportunity CLOSED_WON
   (w/ closedAt) together, traceable to the validating user. **Remediation: G5-P3-2** (the money-path UI
   writer, F-01) + G5-P3-6 (lifecycle gates).
3. **F-01 — closing a real sale in the UI**: the reservation CONVERTED/CANCEL transition is
   API-complete (matrix-proven) but has no UI writer. How do managers actually close sales today
   (force-apartment-status workaround? nothing?).
   → **RESOLVED (D-GOV-5): the two-step closure specification IS the answer** — agents prepare closure
   requests; managers validate and finalize. Sizing fixed: a closure-request workflow state on the
   reservation lifecycle + the agent/manager UI surfaces. **Remediation: G5-P3-2.**
4. **R5 legacy holds**: 7 seeded RESERVED apartments with no ACTIVE reservation (pre-system
   history) — release vs requalify, owner-gated since P17 (standing register row).
   → **RESOLVED 2026-10-19 (D-GOV-6, G5-P2-5):** RELEASED to AVAILABLE through the P47 audited PATCH
   (MANAGER, 200×7, audit ×7 — the least disruptive maintainable remedy; backfill rejected as invented
   commercial records); the seed no longer recreates unbacked holds; H-31 remains the only (backed) hold.
   The RESERVED⇒has-reservation invariant now holds at install time.
5. **Inbound WhatsApp threads / Ouedkniss API ingestion**: channels are attribution sources today;
   automated ingestion is NOT specced (deferred by worklog evidence). Any move there = a new
   product decision, not a gap-fill.
6. **Arabic microcopy**: machine-generated, human review pending (standing register row).
   → **STANDARD SPECIFIED (D-GOV-5):** professional Modern Standard Arabic (not colloquial Darja) for the
   formal interface; genuine RTL/LTR per language; consistent terminology; no invented legal meanings.
   The "human review" gate becomes an **MSA-conformance audit** of the existing AR dictionaries
   (engineering task, roadmap P4).
   → **AUDIT EXECUTED 2026-10-20 (G5-P4-7, DONE):** all 19 AR dictionaries reviewed (four-batch parallel
   audit, every candidate finding verified against the live files); 117 string fixes across 17 domain files
   in five defect clusters (agent-term unification to the مندوب family · the lead qualifier restored ·
   role terms corrected · Darja/register · grammar/orthography incl. one factual CSV-delimiter error);
   7 findings honestly declined w/ rationale; gates green + the RTL browser walk console-0 — receipts in
   the roadmap's P4 tier table + worklog G5-P4-7. The G5-P2-6 standing row is CLOSED.

## 10. Evidence appendix (this round's live receipts)

- Schema: 26 models / uniques — `prisma/schema.prisma` (`Lead @@unique([orgId,phone])`:198 ·
  `LeadDuplicateDismissal @@unique([orgId,leadAId,leadBId])`:228 · `Apartment @@unique([orgId,
  buildingId,code])`:378 · `ProjectAssignment @@unique([projectId,userId])`:634 · `User.email
  @unique`:51).
- Constants: `ROLES` (5 — FIELD_REP not MARKETING) · `SOURCES` (13 == capture) · `LEAD_STATUSES` (6) ·
  `VISIT_TRANSITIONS` (full matrix) · `APARTMENT_STATUSES` (7 — UNAVAILABLE included) ·
  `COMMISSION_STATUSES`/`INCENTIVE_STATUSES`/`COMMISSION_SOURCES` — `src/lib/constants.ts:10,13,
  30,54-71,167,177`.
- Guards: opp terminal-create 422 `opportunities/route.ts:115-121` · probability forced
  `opportunities/[id]/route.ts` (closing branch) · bulk lostReason 422 `leads/bulk:76-82` ·
  phone E.164 `src/lib/phone.ts:22-42`.
- Runtime: GOV-2 receipts (matrix 231/231 · B-1/B-6 runtime probes · browser console-0).
- External: EXT-1…EXT-8 (§1 — receipts JSON at `/tmp/gov3-search-receipts.json`; script committed).
- Doc-drift fixed by this round: DOMAIN_MODEL entity map & state matrix (see its GOV-3 stamp) ·
  visibility-matrix stale rows (annotated) · USER_JOURNEYS pointer + factual fixes.
