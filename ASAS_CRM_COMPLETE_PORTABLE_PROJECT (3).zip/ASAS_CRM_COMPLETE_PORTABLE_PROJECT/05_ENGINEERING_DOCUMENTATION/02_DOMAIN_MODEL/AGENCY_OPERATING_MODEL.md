# ASAS — Agency Operating Model (product truth)

**Canonical capture of the user's operating-model mandate (2026-10-08 — the "PromptConnex" reference).** Engineering program: `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/PHASE18_CRM_PREMIUM_OPERATING_MODEL.md`. This file describes HOW the agency lives; the code must match it.

## The agency (CRM premium — immobilier, Alger)

Agence immobilière de vente (promoteurs/clients). Le périmètre du CRM premium est le cycle de vie commercial : Lead (entrées site web, annonces réseaux sociaux, campagnes WhatsApp, campagnes Ouedkniss) → Qualification → Opportunité → Visite → Réservation → Contrat. **Après le CRM premium vient l'ERP** : tout contenu comptable/financier lourd (échéanciers, encaissements, objectifs de revenus) est HORS périmètre CRM — il ne reste que l'économie du deal : commission d'agence + incentive du représentant.

## Les rôles et leur vie

1. **Président · CEO (directeur général de l'agence)** — `OWNER`. Ajoute des délégués et leur **assigne les projets et responsabilités nécessaires selon leur cycle de vie** dans le projet et la plateforme. Peut visiter les projets lui-même, voire mener des visites terrain (toujours autorisé par rang : confirmation, complétion).
2. **Administrateur** — `ADMIN`. Administration de la plateforme (équipe, paramètres, audit).
3. **Directeur exécutif** — `MANAGER`. Direction exécutif : données org-wide, confirme les visites, saisit les commissions d'agence, gère les assignations terrain.
4. **Représentant commercial (représentant de suivi)** — `SALES_AGENT. Les clients qui entrent leurs informations via le site web (publicités réseaux sociaux, campagnes WhatsApp, campagnes Ouedkniss) lui appartiennent : il suit, relance, **planifie le rendez-vous et l'ajoute à l'agenda — mais ne confirme PAS le rendez-vous**. Il voit l'incentive reçue sur la vente.
5. **Représentant terrain (de visite)** — `FIELD_REP`. Assigné à un ou plusieurs projets par le CEO/la direction. **C'est lui qui confirme le rendez-vous en arrivant sur place** — parfois il confirme la date de visite et la date finale entre à l'agenda. **Aucune information n'apparaît pour un autre représentant** : chaque projet a son représentant terrain, un représentant peut gérer plusieurs projets ; sa visibilité de données est limitée aux projets assignés.

## Le workflow du rendez-vous (visite)

```
Représentant commercial            Représentant terrain (projet)          Direction
────────────────────────           ─────────────────────────────          ─────────
suivi du lead (WhatsApp/tél.)
   │
planifie le RDV → agenda           arrive sur place
   status = SCHEDULED ───────────►  CONFIRME ────────────────────────────  peut confirmer
   (ne confirme jamais)            (fixe parfois la date finale          (CEO inclus)
                                     → agenda porte la date finale)
        │                          REFUSE (motif requis — P20/D-026) :
        │                          la proposition est morte ; le rep
        │                          de suivi replanifie si besoin
        │                          CONTRE-PROPOSE un créneau ─────────┐
        │                                                            │
   ◄──────────────────────────────────────────────────────────────────┘
   « à reconfirmer avec le client » (ambre) : le rep de suivi vérifie
   auprès du client puis marque « client reconfirmé » (seul l'agent
   de la visite ou la direction)
                                   visite → COMPLETED (compte-rendu)
                                   absence → NO_SHOW
```

Loi serveur : `SCHEDULED → CONFIRMED` = FIELD_REP assigné au projet de la visite, ou MANAGER+. Le PATCH de confirmation peut porter la date finale (`scheduledAt`). Sceaux `confirmedAt`/`confirmedById` + entrée de timeline.
Loi serveur (P20/D-026) : **REFUS** (`SCHEDULED → REJECTED`, terminal, motif requis) et **contre-proposition** (`{scheduledAt, proposeAlternative}`) partagent l'autorité de confirmation (FIELD_REP assigné ou MANAGER+). Le créneau d'origine (`proposedAt`) ne bouge jamais ; la contre-proposition arme `awaitingCustomerReconfirm`, que seul l'agent de suivi de la visite (ou la direction) lève (« client reconfirmé ») ; tout PATCH peut porter `expectedUpdatedAt` → 409 `VISIT_STALE` (aucun écrasement silencieux entre acteurs concurrents).
Loi serveur (P20-B/D-027) : **matrice de transitions consolidée** (`VISIT_TRANSITIONS`, `src/lib/constants.ts`) — toute arête hors matrice → 422 `VISIT_ILLEGAL_TRANSITION`. COMPLETED/CANCELLED/REJECTED sont **terminaux** (une correction = une NOUVELLE visite, jamais une réécriture de l'historique) ; NO_SHOW ne peut que se replanifier (l'absence est un fait immuable) ; une visite RESCHEDULED reste une proposition en attente (confirmable/clôturable/annulable). La réinitialisation directionnelle `CONFIRMED → SCHEDULED` est réservée à MANAGER+ (403 `VISIT_RESET_FORBIDDEN` — le terrain qui a confirmé ne peut pas défaire sa confirmation), **déroule les sceaux de présence** (`confirmedAt`/`confirmedById`) et laisse une trace d'audit `VISIT_RESET_TO_SCHEDULED`.
Loi serveur (P20-C/D-028, §17.3 du mandat) : **exception « sans représentant terrain »** — une visite en attente terrain (SCHEDULED/RESCHEDULED) sur un projet sans représentant éligible (aucune assignation à un FIELD_REP **actif**) est une exception opérationnelle explicite : jamais d'assignation d'une personne arbitraire. La direction la voit (KPI d'attention `unstaffedVisits` sur le tableau de bord, cellule ambre réservée MANAGER+ ; puce « Aucun représentant terrain » sur les lignes de visite), la récupération est l'action sûre : **assigner un représentant éligible** (Équipe terrain, vue Projets) — l'assignation résout l'exception (constaté par sonde). Un utilisateur désactivé ne reçoit jamais de nouvelle assignation (422 `ASSIGNEE_INACTIVE`, §17.2) ; chaque changement d'assignation conserve le travail futur affecté dans la piste d'audit (visites en attente couvertes/affectées + représentants restants).

## L'économie du deal (seul argent du CRM)

- **Commission d'agence** — `Reservation.commissionAmount` + `commissionFrom` (`DEVELOPER` = commission reçue du promoteur, ou `CLIENT` = commission reçue du client). Saisie par la direction (Directeur exécutif/Admin/Président). Visible direction.
- **Incentive du représentant** — `Reservation.agentIncentive`. Visible par le représentant concerné (agent de la réservation) et la direction ; agrégé sur le tableau de bord du représentant ("Mes incentives").

HORS périmètre (futur ERP) : échéanciers, appels de fonds, encaissements, rapprochement, objectifs de revenus. `Reservation.depositPaid` (acompte à la réservation) reste : c'est un fait commercial de la réservation, pas de la comptabilité.

## Sources d'entrée (attribution — déjà couvert par `SOURCES` + `Lead.campaign`)

`WEBSITE`, `FACEBOOK_ADS`, `INSTAGRAM`, `WHATSAPP` (campagnes), `OUEDKNISS` (campagnes), `GOOGLE`, `TIKTOK`, `REFERRAL`, `WALK_IN`, `PHONE`, `EXISTING_CUSTOMER`, `DEVELOPER_REFERRAL`, `OTHER` — l'attribution n'est jamais perdue à travers l'entonnoir.

## Ce qui est hors de la vie de la plateforme

SAV/après-vente (D-024 — retiré), tout domaine comptable/ERP, rôles sans vie opérationnelle (Marketing — l'attribution de campagne vit sur le lead ; Comptabilité — ERP ; Opérations — jamais utilisé). Ne rien ajouter qui n'apporte pas de valeur à ce modèle.
