# DOMAIN MODEL & CRM WORKFLOWS

> **GOV-3 verification stamp (2026-10-19):** this file was re-verified line-by-line against the live
> schema (26 models), live constants, and live route code; externally-checkable facts were web-verified
> (receipts in `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/WORKFLOW_SPECIFICATION.md` §1). The stale rows found (MARKETING role,
> SalesTarget, the P2-c free-form gaps since fixed in code, the 6-status apartment list) are corrected
> below. Full workflow state diagrams now live in **`WORKFLOW_SPECIFICATION.md`** (the consolidated
> source of truth); this file keeps the entity map + invariants.
>
> Full entity/integrity evidence: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/DATABASE_DOMAIN_AUDIT.md`.

## Entity map (live — 26 Prisma models, verified against `prisma/schema.prisma`)

```
Organization 1─* User (roles: OWNER > ADMIN > MANAGER > SALES_AGENT > FIELD_REP — ROLES, constants.ts:10; active flag)
Organization 1─* Pipeline 1─* PipelineStage (@@unique [pipelineId,key]; WIP limits — the 10-stage vocabulary)
Organization 1─* Developer 1─* Project 1─* Building 1─* Apartment
                                          (@@unique [orgId,buildingId,code];
                                           status: AVAILABLE/RESERVED/OPTIONED/SOLD/BLOCKED/UNAVAILABLE/OFF_MARKET)
Project 1─* ProjectAssignment *─1 User(FIELD_REP) (@@unique [projectId,userId] — the Équipe terrain, D-025)
Lead (@@unique [orgId,phone]; archived soft-delete; source/campaign attribution; score 0-100)
  ├─ *─1 User (owner ∨ null = the shared intake pool, D-021 OWN+POOL)
  ├─ 1─* Activity (timeline: type CALL/NOTE/WHATSAPP/COPILOT/…)          ├─ 1─* Task (owner, dueAt)
  ├─ 1─* Visit (agentId, scheduledAt, project) *─* Apartment (via VisitApartment — the visited units)
  │        (full transition matrix: VISIT_TRANSITIONS, constants.ts:54-71)
  ├─ 1─1? Requirement (matching: budget/rooms/locations/payment) ─* PropertyMatch (requirement×apartment,
  │        @@unique [requirementId,apartmentId]; tunable org weights)
  ├─ 1─* Opportunity (deal lifecycle; value DZD; stage → PipelineStage; owner; closedAt/lostReason discipline)
  │        └─ 1─* Reservation (apartment hold: ACTIVE/CONVERTED/CANCELLED/EXPIRED; expiresAt;
  │                 booking tx ADR-004; expiry sweeper; carries the deal economy — commissionAmount/
  │                 commissionFrom(DEVELOPER|CLIENT) + §37 ladder + agentIncentive + §38 machine)
  └─ 1─1? Contact (created at conversion — the client snapshot; convertedContactId unique)
Tag *─* Lead (via LeadTag, @@unique [orgId,name] on Tag) · SavedSearch (per user)
Document (entity+entityId polymorphic, category, storedName unique, VLM analysis JSON)
LeadDuplicateDismissal (@@unique [orgId,leadAId,leadBId] — §12.2 merge/dismiss machine, P30/P53)
OrgSetting (@@unique [orgId,key] — the tunable notification/matching knobs)
AuditLog (append-only; actor nullable = system) · Notification (computed, never persisted)
```

**Removed from earlier maps (verified gone):** SalesTarget (D-025 → finance out of CRM), MARKETING/
ACCOUNTING/OPERATIONS roles (P18), Note/Call entities (Activity types), Floor (→ floorNumber),
payment/installment models (D-022 shipped → D-025 removed → future ERP).

## Core workflow (as implemented — full diagrams: `WORKFLOW_SPECIFICATION.md`)

Lead → (qualification via PATCH status) → [Visits scheduled → FIELD_REP confirms on site → outcomes]
→ CONVERT endpoint → Contact + Opportunity (QUALIFIED) → pipeline stages (QUALIFIED→VISIT_SCHEDULED
→VISIT_COMPLETED→NEGOTIATION→OPTION→RESERVATION→CONTRACT→CLOSED_WON/CLOSED_LOST) → Reservation
(tx: apartment AVAILABLE check → hold + apartment RESERVED; expiresAt default) → won: closedAt
stamped, reservation CONVERTED (tx: apartment SOLD), §37 commission ladder + §38 incentive machine
feed from there. **Known gap (GOV-2 F-01): the reservation CONVERTED/CANCEL transitions have no UI
writer — API-complete, UI-absent; OPEN-DECISION 3 in the workflow spec.**

## State-machine enforcement matrix (GOV-3 re-verified — P2-c verdicts updated)

| Entity | Enforced rules (live code) | Remaining posture (OPEN-DECISION 1 — owner-gated) |
|---|---|---|
| Lead.status | CONVERT endpoint only (409 ALREADY_CONVERTED); CONVERTED locked; CLOSED_LOST requires lostReason — single **and bulk** (422, `leads/bulk:76-82` — P2-c gap FIXED); reactivate = CLOSED_LOST→CONTACTED only; lost fields cleared on exit | No adjacency matrix (NEW→QUALIFIED legal) — documented free-form, needs owner confirmation |
| Opportunity.stage | terminal creation requires closedAt (422 `TERMINAL_STAGE_REQUIRES_CLOSED_AT` — P2-c gap FIXED); closing forces probability 100/0 + stamps closedAt; lostReason required; reopen clears closedAt/lostReason; DELETE only NEW/CLOSED_LOST w/o reservations | Any stage PATCH legal (no adjacency matrix) — same owner question |
| Visit.status | **FULL matrix** (`VISIT_TRANSITIONS`) — illegal edge → 422; COMPLETED/CANCELLED/REJECTED terminal (P2-c "COMPLETED re-open allowed" is OBSOLETE — fixed by D-027); NO_SHOW only exits via RESCHEDULED; CONFIRMED authority = assigned FIELD_REP or MANAGER+; executive reset MANAGER+-only + audited | none — exemplary |
| Reservation.status | booking tx (APARTMENT_NOT_AVAILABLE + one-ACTIVE-row 409s); lifecycle only from ACTIVE (409 RESERVATION_ALREADY_CLOSED); CONVERTED/CANCEL tx flips apartment SOLD/AVAILABLE; expiry sweeper guarded/idempotent | lifecycle UI writer absent (F-01); CONVERTED⇏CLOSED_WON coupling (OPEN-DECISION 2) |
| Apartment.status | SOLD guard (force:true to leave SOLD); RESERVED-release blocked while an ACTIVE reservation exists (422, force escape — P2-c desync gap FIXED); MANAGER+ gate on mutations (P47); 7 statuses (UNAVAILABLE was missing from the old map) | setting RESERVED with no reservation row possible (7 seed-legacy instances = R5 data decision) |

## Domain concepts: present / deferred / missing

- **Present (P18 scope — `AGENCY_OPERATING_MODEL.md` is the product truth)**: Lead/Opportunity/
  Reservation split (ADR-003), Activity-as-timeline, matching engine w/ tunable weights, saved
  searches, audit trail, documents+VLM OCR, project assignments + field-visit confirmation
  discipline + deal economics (P18/D-025), duplicate management (§12.2 scan/dismiss/merge + the P53
  waypoint triplet), notifications-as-computed-aggregates (11 bell groups).
- **Explicitly deferred/consolidated** (worklog evidence): notifications-as-model, Note/Call
  entities, Floor→floorNumber, inbound WhatsApp threads / Ouedkniss API ingestion (OPEN-DECISION 5),
  NextAuth (cookie+scrypt covers single-workspace).
- **Silently missing vs original spec** (candidates — need product decision, do NOT auto-add):
  Campaign/Ad/LandingPage/Cost (ROI analytics absent), Offer, Customer aggregate, Company, granular
  permissions (role-rank only), Teams, consent tracking, document versioning, ~~SAV cases~~ (D-024),
  ~~Payments/Installments~~ (D-022→D-025), ~~Sales targets~~ (R10-4→D-025), ~~Commission~~ (shipped
  as the D-025 deal-economics form: agency commission + agent incentive on the reservation).

## Lifecycle invariants worth preserving

- Every mutation of consequence writes Activity (user-visible) + AuditLog (forensics) — keep.
- Org+phone uniqueness on Lead (dedup at import + DB level, `schema.prisma:198`).
- Reservation booking transaction (ADR-004): in-tx apartment status re-read; uniqueness enforced
  transactionally; partial unique index planned for PostgreSQL.
- The one-scope-predicate law: aggregates (KPI/bell) and machines (scan) ask through the SAME
  shared writer (P53's `duplicates.ts` pattern) — drift becomes structurally impossible.
