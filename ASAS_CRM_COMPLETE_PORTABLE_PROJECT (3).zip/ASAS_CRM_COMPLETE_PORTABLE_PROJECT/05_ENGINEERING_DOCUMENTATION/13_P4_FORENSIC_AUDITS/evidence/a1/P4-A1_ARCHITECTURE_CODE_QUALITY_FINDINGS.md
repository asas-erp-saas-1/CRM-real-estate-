# P4-A1 — Architecture & Code Quality Audit Findings (READ-ONLY)

- **Task ID:** P4-A1 (Agent 1 — Architecture & Code Quality Auditor)
- **Date:** 2026-11-06 (session of the Phase-4 production-readiness audit)
- **Repo:** /home/z/my-project @ HEAD `6201496`, branch `main`, clean tree at start (only `?? 05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/` untracked evidence dirs)
- **Mode:** STRICT READ-ONLY. No existing file modified. No build/test/migrate/db-write executed. Only writes: this file (+ `/tmp` probes).
- **Baseline cited (principal's, NOT re-run):** lint exit 0 (0 errors / 41 warnings); typecheck exit 0; full suite 772/772 passed (44 files, 60.9s); `prisma migrate status` = 25 migrations, up to date.

---

## 1. Methodology & commands

Inspection performed with `wc -l`, Grep/Glob/LS/Read tools, `git log/ls-files` reads, and read-only `curl` probes. Every number below comes from a command actually run this session (command → output recorded inline). No `cat`/`find`/`grep` used; `rg` used only via the Grep tool and for file listing/line-count pipelines (equivalent to the sanctioned `wc -l` counting).

Commands and their outputs (abridged to the figures used):

| # | Command | Output (verbatim/summarized) |
|---|---|---|
| M1 | `wc -l src/lib/services/*.ts \| sort -rn` | `2020 total · reservations 745 · dashboard 631 · installments 418 · payments 226` |
| M2 | `wc -l src/lib/server/*.ts \| sort -rn` | `8325 total` over **40 files**; top: offer-lifecycle 1036 · scoring 551 · lead-capture 539 · reservation-lifecycle 500 · session 425 |
| M3 | `rg --files src/app/api \| rg 'route\.ts$' \| xargs wc -l \| sort -rn` | `12990 total` over **87 route files** (avg ≈ 149 lines) |
| M4 | `wc -l` on dashboard/reservations/finance routes | dashboard **28** · reservations **75** · reservations/[id] 121 · payments **41** · installments **52** · installments/[id] 38 · finance/overview 111 |
| M5 | Grep `queryKey: \[` in `src/` | **0 matches** |
| M6 | Grep `qk\.` in `src/` | 250 occurrences across **66 files** |
| M7 | Grep `from "@/lib/client/focus"` in `src/` | **20 files** |
| M8 | Grep `const VIEWS\|NAV_SECTIONS\|SECTIONS =\|VIEW_META` in `src/` | only view-registry.ts definitions + sidebar-nav.tsx *derived* `SECTIONS = NAV_SECTIONS.map(...)` + tombstone comments in shell.tsx:14, store.ts:12-14 |
| M9 | Grep `: any\b\|as any\b\|<any>\|@ts-ignore\|@ts-expect-error\|@ts-nocheck` in `src/` | 12 raw matches — **all 12 are prose in comments** (e.g. "any authenticated user"); **0 actual `any`-typed code** |
| M10 | Grep `as unknown as\|<any>\|@ts-ignore...` (precise) | 16 `as unknown as` in 6 files (db.ts 4, reservation-economics.ts 8, obs.ts 1, notification-cache 1, store.ts 1, copilot route 1) |
| M11 | Grep `[a-zA-Z_$][\w$]*!\.` in `src/` | 47 lines with non-null assertions (visit-dialogs 15, journey-performance 10, apartment-detail-dialog 7, leads/bulk route 9, others ≤2) |
| M12 | Grep `return fail\(error\)` in `src/app/api` | 111 occurrences across **85 of 87** route files (the other 2: `[...path]` JSON-404 catch-all by design; `health` self-contained try/catch) |
| M13 | Grep `try \{` in route files | 86 of 87 route files contain try blocks |
| M14 | `rg --files src/components` → `wc -l` | **175 component files** (crm 145 of which 131 .tsx; ui 29; brand 1); `components/crm` = 41,883 lines; `src` total = **81,909 lines** |
| M15 | `rg --files src/lib/i18n/domains \| xargs wc -l` | 21 domain files, 7,616 lines (+ index 185 + types 17 = 7,818 total) |
| M16 | `rg -l "z-ai-web-dev-sdk"` | src imports: **exactly 1 module** (`src/lib/server/ai-provider.ts:20`) → consumed by the 2 AI routes (copilot, documents/analyze). **Zero client-side imports.** |
| M17 | Zombie absence checks (`[ -e ]`) | ABSENT: `src/lib/i18n.ts`, `src/app/api/route.ts`, `src/components/crm/view-placeholder.tsx`, `src/app/api/leads/check-duplicates/`, `src/app/api/properties/unit-types/` |
| M18 | `git log --all --diff-filter=D --name-only \| sort -u` ∩ `git ls-files` (the D-040 resurrection sweep) | **22 files** — all in the finance/sav/targets family; see finding A1-F010 |
| M19 | `curl http://127.0.0.1:3000/api/health` (+ dashboard + unknown path) | **Connection refused**; `ss -ltnp` shows **no listener on :3000**. Runtime probes → NOT VERIFIED (server not restarted per rules) |
| M20 | `ls tests/unit \| wc -l` etc. | unit 29 + security 11 + contract 4 = **44 test files** (matches principal's baseline figure) |
| M21 | Grep `from "@/lib/server\|from "@/lib/db\|from "@/lib/services"` in `src/components` + `src/hooks` | **0 matches** (client never imports server/db code) |
| M22 | Grep `from "@/components"` in `src/lib` | **1 match**: `src/lib/client/workspace-store.ts:30` (type-only) — finding A1-F003 |
| M23 | Grep `from "@/lib/client\|from "@/components"` in `src/app/api` | **0 matches** (server never imports client code) |
| M24 | Grep `MAX_MONEY_DZD\|1e12\|10_000_000_000` in `src/` | see finding A1-F001 |
| M25 | Orphan sweep: for every file under `src/components` + spot-check of `src/lib/server` modules, search importers | **0 true orphans** (all "orphans" resolved to relative imports or `next/dynamic`/registry lazy loads) |

---

## 2. Architecture map (measured)

### 2.1 Layers (as built, verified from code)

```
Browser SPA
  src/app/page.tsx (15) → Providers → CrmApp (crm-app.tsx, 96)
    └─ CrmShell (shell.tsx 318) + sidebar-nav (423) + login-overlay
         └─ 12 hash-routed views (#/<view>) via VIEW_REGISTRY (view-registry.ts, 250)
            → lazy per-view chunks (React.lazy + next/dynamic sub-chunks)
Client state layer  src/lib/client/** (10 files, 2,513 lines)
    zustand: store.ts (219 — view/hash/lang/density/recents)
             workspace-store.ts (207 — per-user transient workspace facets)
             focus.ts (182 — the ONE focus-token contract)
    react-query: query-keys.ts (196 — the ONE typed key factory `qk`)
                 query-invalidation.ts (81 — deal/convert fan-out graph)
    api.ts (91 — typed fetch + client ApiError) · session.ts (21) · types.ts (1,207 — DTO grab-bag)
    whatsapp.ts (59)
        │  fetch /api/** (same-origin, credentials)
        ▼
HTTP layer  src/app/api/** — 87 route.ts files, 12,990 lines (avg ≈149)
    src/proxy.ts (Next 16 middleware successor) — stamps x-request-id/route/start for ALL /api/*
    per-route: requireUser(role?) → zod parseBody → domain call → ok()/fail() envelope
        ▼
Domain layer
    src/lib/services/**        — 4 files, 2,020 lines (payments 226 · installments 418 ·
                                  dashboard 631 · reservations 745 incl. shared booking core)
    src/lib/server/**          — 40 files, 8,325 lines (offer-lifecycle 1036, scoring 551,
                                  lead-capture 539, reservation-lifecycle 500, session 425,
                                  visibility, validation, audit, logger, obs, faults, expiry …)
        ▼
Data layer  Prisma 6.11.1 + SQLite (db/custom.db) — 33 models (schema.prisma), 25 migrations
```

Shared cross-cutting: `src/lib/constants.ts` (799 — client-safe enum vocabulary, no prisma import), `src/lib/i18n/**` (21 domain dictionaries, fr/en/ar, module-load duplicate-key + 3-language parity guards, Arabic 6-form plurals), `src/lib/format.ts` (251), `src/lib/journey.ts` (769), `src/lib/phone.ts` (88), `src/lib/metrics.ts` (58).

### 2.2 Measured module inventory

| Module | Files | Lines | Notes |
|---|---|---|---|
| `src` total | — | **81,909** | |
| API routes `src/app/api/**/route.ts` | **87** | **12,990** | 12,990/87 ≈ 149 avg |
| Domain services `src/lib/services/` | 4 | 2,020 | payments/installments/dashboard/reservations |
| Server domain modules `src/lib/server/` | 40 | 8,325 | largest: offer-lifecycle 1,036 |
| Client state/lib `src/lib/client/` | 10 | 2,513 | types.ts alone 1,207 |
| i18n `src/lib/i18n/` | 23 | 7,818 | 21 domains + index + types |
| Components `src/components/` | **175** | ~44,7xx (crm 41,883 + ui + brand) | 131 crm .tsx + 14 crm .ts + 29 ui + 1 brand |
| App shell `src/app` (non-api) | 9 | small | page 15 · layout 70 · error 181 · global-error 84 |
| Hooks `src/hooks/` | 1 | — | use-debounced |
| Prisma schema | 1 | 33 models | verified `^model ` count |

Top-10 largest API routes (god-route watch):

| Rank | Route file | Lines | Character |
|---|---|---|---|
| 1 | `api/visits/[id]/route.ts` | **628** | PATCH body ≈ lines 175–578 inline (outcome discipline, gates, trail) |
| 2 | `api/opportunities/[id]/route.ts` | **548** | PATCH ≈ 390 lines inline stage machine |
| 3 | `api/notifications/route.ts` | **500** | one 440-line GET with 12 inline notification projections |
| 4 | `api/leads/route.ts` | 489 | GET ≈ 257 lines inline filter/sort/pagination query building |
| 5 | `api/leads/[id]/route.ts` | 464 | |
| 6 | `api/leads/import/route.ts` | 397 | |
| 7 | `api/leads/[id]/copilot/route.ts` | 390 | AI orchestration inline |
| 8 | `api/visits/route.ts` | 366 | POST booking guards + tx inline |
| 9 | `api/export/bundle/route.ts` | 362 | |
| 10 | `api/leads/duplicates/merge/route.ts` | 343 | |

Largest 5 components: pipeline-view 926 · visits/visit-dialogs 903 · pipeline/create-opportunity-dialog 845 · create-lead-dialog 814 · leads-view 796.

### 2.3 Dependency direction verdict

- **UI → API → services/server → db holds.** Verified: 0 imports of `@/lib/server|@/lib/db|@/lib/services` from `src/components` or `src/hooks` (M21); 0 imports of `@/lib/client|@/components` from `src/app/api` (M23); 0 imports of client/components from `src/lib/services` (M22 companion).
- **One layering inversion found:** `src/lib/client/workspace-store.ts:30` — `import type { Filters, SortKey } from "@/components/crm/views/leads/filters"` (lib → components, type-only). Contradicts the project's own stated law ("routing config belongs to the lib layer, components are consumers" — view-registry.ts header). No runtime cycle (type-only), but the inversion is real. → **A1-F003**.
- 71/87 route files import `@/lib/db` directly — acceptable in this modular-monolith style (routes ARE the domain layer for the 80% of domains not yet service-extracted), but it marks the extraction as partial. → **A1-F002**.

---

## 3. P1-claims verification matrix (criterion → claim → actual → verdict)

Source challenged: `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_FINAL_ACCEPTANCE_REPORT.md` criteria 4, 10, 11, 12.

| Claim | Reported (P1) | Actual (this audit, command) | Verdict |
|---|---|---|---|
| Services: payments 226 lines | 226 | **226** (`wc -l`) | **VERIFIED — exact match** |
| Services: reservations 745 | 745 | **745** | **VERIFIED** |
| Services: dashboard 631 | 631 | **631** | **VERIFIED** |
| Services: installments 418 | 418 | **418** | **VERIFIED** |
| Route slimmed: dashboard 28 | 28 | **28** | **VERIFIED** |
| Route slimmed: reservations 75 | 75 | **75** | **VERIFIED** |
| Route slimmed: payments 41 | 41 | **41** | **VERIFIED** |
| Route slimmed: installments 52 | 52 | **52** | **VERIFIED** |
| (context) reservations/[id] PATCH route | — | 121 lines, pure adapter dispatching to reservation-lifecycle/-economics | Consistent with adapter pattern |
| ARCH-03: single view registry; 4 drifting copies deleted | VERIFIED | `view-registry.ts` (250) is the sole registry (12 views + NAV_SECTIONS + lazy map). store.ts imports `isView` (tombstone at :12-14); sidebar-nav.tsx:53 imports NAV_SECTIONS/VIEW_REGISTRY (its `SECTIONS` at :58 is a derived `.map`, not a re-enumeration); shell.tsx:14 tombstone ("local VIEW_META copy is deleted"); crm-app.tsx:20 renders via `VIEW_COMPONENTS`. No `VIEW_META`/local `VIEWS` union found anywhere (M8). | **VERIFIED** |
| ARCH-06: 0 raw `queryKey: [` literals (was 231) | VERIFIED | **0 matches** in `src/` (M5); single typed factory `qk` with 250 usages across **66 files** (M6; P1 said "64 consumer files per W4 report" — 66 measured today, consistent with later growth). Tests `tests/unit/query-keys.test.ts` present. | **VERIFIED** |
| ARCH-05: focus.ts single contract, six store slots deleted, ~20 consumers | VERIFIED | `focus.ts` (182 lines) is the single discriminated contract; store.ts keeps no focus slots (tombstone at :69-73); exactly **20 files** import `@/lib/client/focus` (M7). `tests/unit/focus.test.ts` present. | **VERIFIED** |
| Extraction introduced no duplicated business logic between routes and services | (implied by W2-A3 contract) | Payments: route = zod only, all laws in service — **no duplication**. Reservations: POST/GET thin; `bookUnitInTx` shared core is imported by BOTH the direct route path and offer-lifecycle convert (`offer-lifecycle.ts:46` imports `bookUnitInTx`) — **shared, not duplicated**; `[id]` PATCH delegates to reservation-lifecycle/economics which themselves reuse financial-semantics helpers (route header explicitly documents "deliberately re-declares NEITHER"). Installments: route = zod + service calls. Dashboard: route 28 lines, all projection in service. **No duplicated booking/payment laws found.** | **VERIFIED (no duplication found)** |
| Reservations services + lifecycle modules | — | Domain spans `lib/services/reservations.ts` (745) AND `lib/server/reservation-{lifecycle,economics,trust,dto}.ts` (500+235+334+132) — deliberate split, coherent, but split across two directories | Observation → **A1-F007** |

**Net: every re-measurable P1 architecture claim reproduced exactly.** The P1 acceptance report's architecture section is accurate to the line.

---

## 4. Findings register

Severity scale: CRITICAL (blocks production) / HIGH (material risk) / MEDIUM (debt with real consequences) / LOW (hygiene) / INFO (observation).

| ID | Severity | Module | Location | Observation | Impact | Evidence | Recommendation |
|---|---|---|---|---|---|---|---|
| **A1-F001** | **MEDIUM** | finance/validation | `src/app/api/finance/installments/route.ts:36`, `src/app/api/finance/installments/[id]/route.ts:21`, `src/lib/server/csv.ts:205`, `src/app/api/targets/route.ts:33`, `src/components/crm/settings/targets-section.tsx:49`, `src/app/api/reservations/[id]/route.ts:49` | Money-cap single-sourcing (DB-12) is **partially implemented**. The shared `MAX_MONEY_DZD = 10_000_000_000` exists in `validation.ts:109` and the payments route imports it — but the two **installments** routes still carry the old private `1e12` cap (100× the shared ceiling), `csv.ts` import parsing uses `1e12`, and targets route + targets-section each re-declare a private `MAX_AMOUNT_DZD = 10_000_000_000`; reservations/[id] re-declares the inline literal. | An échéancier line (or CSV-imported amount) can be created at up to 1e12 DZD while payments against it cap at 1e10 — an installments amount two orders of magnitude above every other money law passes API validation. Future cap changes require a 7-site scavenger hunt — exactly what DB-12's comment claims was eliminated. | Grep M24 output (6 sites listed). Status: **Partially implemented**. | Route the two installments schemas and csv.ts through `MAX_MONEY_DZD`; import (not re-declare) the constant in targets route/section and reservations/[id]. |
| **A1-F002** | **MEDIUM** | api/visits, api/opportunities, api/notifications, api/leads | `api/visits/[id]/route.ts` (628), `api/opportunities/[id]/route.ts` (548), `api/notifications/route.ts` (500), `api/leads/route.ts` (489), `api/leads/[id]/route.ts` (464) | The W2-A3/ARCH-01 "thin HTTP adapter + domain service" pattern is applied to exactly **4 domains** (reservations/payments/installments/dashboard). The other heavyweights keep full business logic inline in route files: visits PATCH outcome machine (~400 lines), opportunities PATCH stage machine (~390 lines), notifications' 12 projections (440 lines in one GET), leads GET query builder (257 lines). 71/87 route files import `@/lib/db` directly. | Inconsistent layering: business laws for visits/opportunities/leads/notifications are not unit-testable without HTTP mocks; route files are the de-facto largest maintenance surface; regression risk concentrates where tests are contract/e2e style. This is debt, not a defect — the inline code still uses the shared envelope, scoped queries, and tx discipline. | M3 table (route sizes), M2 (services inventory = 4 files only), Read of visits/[id] PATCH (lines 175–578), notifications GET (lines 57–500). Status: **Partially implemented** (architecture pattern exists, coverage ~4/12 domains). | Continue the extraction wave: visits + opportunities + notifications projections are the highest-value next services; leads GET query builder third. |
| **A1-F003** | LOW | client/lib | `src/lib/client/workspace-store.ts:30` | Lib-layer module imports **types** from a component (`@/components/crm/views/leads/filters`). Type-only, no runtime cycle, but an upward import that the codebase's own layering law forbids. | Layering inversion; the `Filters`/`SortKey` vocabulary for the persisted-workspace contract is owned by a view-local component, so any refactor of leads filters can break the lib contract. | Read of workspace-store.ts line 30; M22 grep (the only components import under src/lib). Status: **Implemented** but violates stated layering. | Move `Filters`/`SortKey` into `src/lib/client/` (e.g. types.ts or a workspace contract module) and re-export from the component. |
| **A1-F004** | LOW | observability docs | `src/lib/server/session.ts:188` vs `src/proxy.ts` | session.ts's header comment says "Every /api request passes through **src/middleware.ts**" — that file does not exist; the actual correlation layer is `src/proxy.ts` (Next.js 16's renamed middleware convention, confirmed by proxy.ts's own header). The code path is correct (requestContext() reads the headers proxy.ts stamps); only the comment is stale. A worklog line (3051) likewise says "no middleware.ts". | Misleads future maintainers/auditors grepping for middleware.ts; documentation drift class this project treats as a regression risk. | Glob for middleware.ts → 0; Read of proxy.ts + session.ts:186-217. Status: **Implemented** (proxy.ts) / comment **stale**. | Update the session.ts comment to reference `src/proxy.ts`. |
| **A1-F005** | LOW | reservations/economics | `src/lib/server/reservation-economics.ts:79,167,168,189,190,202,216,225` | Eight `as unknown as ReservationRow` casts in the §37/§38 trust machine. The included Prisma payload evidently doesn't satisfy the declared row type, so the module bridges with double-casts. | Type safety hole in the most financially sensitive server module: a schema change to commission/incentive fields would not be caught by the compiler at these sites. | M10 grep (8 occurrences, single file). Status: **Partially implemented** (typed API, untyped interior). | Derive `ReservationRow` from `Prisma.ReservationGetPayload<{include: …}>` (the pattern payments.ts already uses) and delete the casts. |
| **A1-F006** | LOW | tooling | `tsconfig.json`, `eslint.config.mjs` | Strict mode is on (`strict: true`, `noImplicitAny: true`) but nothing beyond Next defaults (`noUncheckedIndexedAccess`/`exactOptionalPropertyTypes` absent), and ESLint **disables** `no-explicit-any`, `no-non-null-assertion`, and `ban-ts-comment`. Measured discipline is nonetheless excellent (0 `any`, 0 `@ts-ignore`, 16 justified `as unknown as`, ~47 non-null assertions mostly in react-query `enabled`-guarded callbacks). | Current type hygiene is good by measurement, not by enforcement — a future contributor can regress it without any gate firing. | Read tsconfig.json; Read eslint.config.mjs rules block; M9/M10/M11 greps. Status: **Implemented** (strict) / **unenforced** (lint off). | Re-enable `@typescript-eslint/no-explicit-any` and `ban-ts-comment` as errors when the ratchet allows (the config's own ENG-05 plan anticipates this); consider `noUncheckedIndexedAccess`. |
| **A1-F007** | LOW | module organization | `src/lib/services/` vs `src/lib/server/reservation-*.ts` | One domain (reservations) spans two directories: `services/reservations.ts` (list/create/booking core) and `server/reservation-{lifecycle,economics,trust,dto}.ts` (PATCH domain). Similarly offers live entirely under `server/offer-lifecycle.ts` (1,036 lines) with no `services/` counterpart. | Two homes for "domain logic" complicates the navigation law ("every business law lives in src/lib/services/…" — route headers claim this for 4 domains only); onboarding friction, inconsistent doc claims. | M1/M2 inventories; reservations route headers cite both module families. Status: **Partially implemented** (placement unification). | Either promote reservation-lifecycle/economics/trust + offer-lifecycle into `src/lib/services/`, or restate the law as "domain modules live in services/ OR server/ per domain" and stop claiming single placement. |
| **A1-F008** | LOW | client types | `src/lib/client/types.ts` (1,207 lines, 60+ exported interfaces) | Single grab-bag of every client DTO (User…JourneyStatsResponse). One file for all view contracts. | Merge-conflict magnet and unclear ownership per domain; contradicts the otherwise strong per-domain decomposition (i18n domains, per-view folders). | Grep of `^export interface` (60+ entries, one file). Status: **Implemented** (works) / hygiene debt. | Split by domain when next touched (leads/pipeline/finance/sav/…), or at least section it with a TOC. |
| **A1-F009** | LOW | environment | port 3000 | The briefing states the dev server is RUNNING at 127.0.0.1:3000; from this audit shell **connection is refused and `ss -ltnp` shows no listener on :3000**. Per read-only rules I did NOT start or restart anything. | All *runtime* verification (live 200s, envelope shapes on the wire, hash navigation in a browser, cache headers) is impossible for this agent this session; my verification is static-analysis only. | M19 (curl → `curl: (7) Failed to connect`; ss listing without :3000). Status: **Not verified** (runtime). | Principal should note the environment discrepancy; other agents' runtime evidence (a5-uiux screenshots exist) covers parts of it. |
| **A1-F010** | INFO | repo hygiene | git history | D-040 resurrection sweep (ever-deleted ∧ in-HEAD) intersects at **22 files** — the entire finance/sav/targets family (`api/finance/**`, `api/sav/**`, `api/targets`, components, i18n domains). These are the **documented Phase D re-introduction** (P13/P14 — i18n index.ts:53-56 comment "Phase D — collections & after-sales (P13/P14 re-introduction)"; current routes use the CURRENT Installment/Payment models, not the old dead models). The specifically-claimed zombies are all ABSENT (M17): i18n.ts monolith, api/route.ts, view-placeholder.tsx, leads/check-duplicates, properties/unit-types. | No unexplained resurrection; the documented regression class is currently clean. | M17 + M18 commands and outputs; `git log --oneline -3` (HEAD 6201496). Status: **Verified clean** (with the documented Phase-D exception). | Keep running the D-040 sweep in later phases (the environment has a proven resurrection history). |
| **A1-F011** | LOW | dependencies | `package.json` | (a) `prisma` CLI is a **prod** dependency (justifiable for `db:deploy`/migrate in the container — but worth an explicit decision note). (b) `z-ai-web-dev-sdk` ^0.0.18 is a 0.x range — unstable semver surface for the AI features; worklog (line 4513) records portability verification via `npm view`. (c) All deps caret-ranged with `bun.lock` committed — reproducible. Every spot-checked dependency is actually used (dnd-kit 3 files, recharts 2, react-day-picker 2, next-themes 3, cmdk 1, sonner 53, RHF 7, radix slider/progress/direction 1 each, framer-motion 24, cva 5, tw-animate-css 1 via globals.css). | Minor supply-chain/pinning exposure on a 0.x SDK; no dead dependencies detected. | Read package.json; per-dep grep counts (Bash loop); `ls bun.lock`. Status: **Implemented** (clean usage) / **Not verified** (registry-level audit of transitive deps out of scope). | Pin `z-ai-web-dev-sdk` exact if AI features are production-critical; document the prisma-in-prod decision. |
| **A1-F012** | INFO | error handling | `src/lib/server/{validation,session,logger}.ts`, `src/app/{error,global-error}.tsx` | Error architecture is systematic and verified: `ApiError{status,code,details}` + `ok()/fail()` envelope with request-id echo, error categorization, metrics; zod → 422 VALIDATION_ERROR with field details; same-origin enforcement inside `readJson()`/`requireUser()`; 111 `fail(error)` sites across 85/87 routes; try/catch in 86/87 route files; client `api.ts` mirrors the envelope into a client `ApiError`; `error.tsx` (segment boundary, trilingual, digest-only) + `global-error.tsx` (self-contained inline-styles, own `<html>`); logger with deep pattern-based redaction + truncation; 500 bodies stay generic (F-09). | Positive finding — this is a strength of the codebase. | M12/M13 greps; Reads of validation.ts, session.ts (174-217, 270-305), error.tsx, global-error.tsx, logger.ts, api.ts. Status: **Implemented/Tested** (logger/validation/fail envelope have unit tests in the 772 baseline). | None — preserve. |

---

## 5. Prioritized technical debt (top items)

1. **Route→service extraction incomplete (A1-F002, MEDIUM).** The four P1 services are exemplary thin-adapter implementations, but visits/[id] (628), opportunities/[id] (548), notifications (500) and leads (489+464) carry hundreds of lines of inline domain logic in route files. Highest-value next wave: `visits` outcome machine, `opportunities` stage machine, `notifications` projections, `leads` query builder — each already has the W2-A3 template to copy (pure rules + orchestrator + route ≤ ~75 lines).
2. **Money-cap single-sourcing (A1-F001, MEDIUM).** Six sites still carry private caps — two of them 100× the shared ceiling (1e12 vs 1e10). One-line-each fix; eliminates a real validation inconsistency on échéancier amounts and CSV import.
3. **Type-safety enforcement gaps (A1-F005 + A1-F006, LOW).** The 8 double-casts in reservation-economics (the money-trust module) plus lint rules that would silently admit `any`/`@ts-ignore` back in. Small, contained, high-leverage.

Follow-ups: A1-F003 (move Filters/SortKey into lib), A1-F004 (stale middleware comment), A1-F007 (services/ vs server/ placement law), A1-F008 (types.ts split).

---

## 6. Honest NOT VERIFIED list

- **Runtime behavior of any endpoint** — dev server unreachable from this audit shell (port 3000 refused; no listener). Per rules I did not start it. All P1 "Live: GET /api/dashboard 200 (36,509 B)…" runtime citations remain historical evidence, unchallenged and unreproduced. Status: **Not verified (this session)**.
- **`bun run build` output** — forbidden in sandbox; never run by me or (per principal) this session. Status: **Not verified**.
- **Test suite results** — cited from the principal's fresh baseline (772/772, 44 files). I verified the **file inventory** (44 = 29 unit + 11 security + 4 contract) but did not execute the suite. Status: **Tested (baseline, cited)** / not re-run.
- **P0/P2 acceptance claims** outside my scope (backup drills, rate limiting, retention, perf baselines) — not re-verified here.
- **Transitive dependency audit** (supply-chain, CVE scan) — out of scope; only direct-usage checks performed.
- **Prisma migration count** — cited from principal's baseline (25, up to date); I verified schema has 33 models and the migrations directory exists in git, but did not run `migrate status` (db-writing-adjacent command; avoided).
- **Browser-level UX claims** (hash navigation titles, focus jumps) — static code confirms the mechanisms; runtime unverified (see bullet 1).

---

## 7. Architecture-fit judgment (scope item 10)

The modular monolith is the right shape for a single-org Algerian real-estate CRM: one deployable, one SQLite file, cookie sessions, no queues/microservices (the AGENTS.md over-engineering ban is honored — no broker/K8s anywhere). The single-route hash SPA with a 12-view registry is internally consistent (deep links `#/leads/:id`, per-view lazy chunks, role-floored nav mirroring server gates) and demonstrably governed (three "ONE registry" consolidations ARCH-03/05/06 all re-verified this session with zero regressions found). SQLite for a ~10-user org with 33 models and 25 migrations is defensible; the documented SQLite-reliability work (P0_2) is the compensating control. Forced patterns? Two candidates: (a) the *dual* domain-module placement (services/ vs server/) reads as a half-finished convention rather than a design; (b) `types.ts` as a 1,207-line shared DTO grab-bag is the one place the per-domain discipline was not applied. Neither blocks production; both are queued above.

**Overall verdict: architecture claims verified; code quality high; debt is concentrated, known-shaped, and non-blocking.**
