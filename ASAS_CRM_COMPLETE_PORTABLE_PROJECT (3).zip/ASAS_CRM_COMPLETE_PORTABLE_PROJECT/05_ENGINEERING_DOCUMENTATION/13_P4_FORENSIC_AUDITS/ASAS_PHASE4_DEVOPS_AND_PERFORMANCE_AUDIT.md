# ASAS CRM — Phase 4 DevOps, CI/CD, Performance & Operations Audit

| | |
|---|---|
| **Auditor** | P4-A6 (DevOps, CI/CD, Performance & Operations) |
| **Date** | 2026-11-06 (all measurements and probes 18:54–19:03 UTC) |
| **Mode** | READ-ONLY production-readiness audit. Zero file modifications outside `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/` deliverables + `/tmp/`. No build, no full test suite, no migrations, no deploys, no process restarts/kills by this agent. |
| **Server under test** | dev server at http://127.0.0.1:3000 (Next 16.1.3, Turbopack dev, Bun 1.3.14, SQLite `db/custom.db`, demoMode ON, NODE_ENV=development) |
| **Evidence** | `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/evidence/a6/` (8 artifacts) — every number below was measured by this agent unless explicitly attributed to a prior phase |

---

## 1. Methodology

- **Config reading**: `next.config.ts`, `tsconfig.json`, `eslint.config.mjs`, `vitest.config.ts`, `tests/tsconfig.json`, `.github/workflows/ci.yml`, `.env`/`.env.example` (names only), `package.json`, backup/restore/retention scripts.
- **Live probes** (read-only): one login POST (MANAGER persona `sarah@asas.dz`), GETs only thereafter; custom `x-request-id` headers to correlate responses ↔ log lines; byte-window isolation on the server log to attribute Prisma `prisma:query` lines to single requests.
- **Performance**: sequential `curl -w '%{time_total}'`, 2+ warmup requests per endpoint then N=20 timed requests, mean/p50/p95/max computed by the standard awk recipe. DEV-MODE numbers (Turbopack, per-route dev overhead) — production `next start` is unmeasurable in this sandbox (build forbidden).
- **`bun run perf:baseline`**: **SKIPPED — it writes** (`mkdirSync` + `writeFileSync` → `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/perf-baseline-<ts>.json`, scripts/perf-baseline.ts:118–129). Its HTTP behavior is GET-only + one login (verified by reading), but the filesystem write violates this audit's write scope. The protocol (warmups, sequential, warm sample, cold reported separately) was replicated with curl instead.
- **`bun run retention:dry`**: **RUN** after reading `scripts/retention.ts` + `src/lib/server/retention.ts` and confirming the dry path is read-only (counts + findFirst/findMany + manifest reads only). Zero-write proof: `sha256(db/custom.db)` identical before/after.
- **Internet check**: read-only curl of `vercel.com/docs` pages (status codes + extracted statements recorded, access date 2026-11-06).
- **Zero-truth posture**: prior-phase claims (P0-7 CI report, P2 observability/performance/notification/retention reports, PRODUCTION_READINESS.md) were re-checked against the current tree and against live behavior; contradictions are findings.

**Environment events during this audit (honest register):**
1. The dev server was **OOM-killed at ~18:55Z** (`Out of memory: Killed process 1898 (next-server)`, anon-rss 2,551,908 kB; my health probe 60 s earlier showed `rssMb:2535`). This agent did not restart it (law); a parallel phase-4 agent relaunched it at 18:59Z with stdout redirected to `/tmp/p4a3-dev.log` (fd verified: `/proc/14487/fd/1 → /tmp/p4a3-dev.log`), which therefore served as the live log source for post-restart evidence. `dev.log` itself is frozen at 18:54:19 (1,490,941 bytes).
2. A concurrent bun workload (1.3 GB RSS, `Bun Pool 2 invoked oom-killer`) plus the server's own 2.5 GB caused the kill — shared-sandbox load, not a defect introduced by this audit's probes (4 traced GETs + 1 login + ~350 perf GETs after the restart).

---

## 2. Build & tooling configuration — verdict table

| Config | Setting (verified in tree) | Verdict |
|---|---|---|
| `next.config.ts` `output` | `"standalone"` | ✅ matches `start` script `node .next/standalone/server.js` (self-hosted posture). |
| `next.config.ts` `typescript.ignoreBuildErrors` / `eslint.ignoreDuringBuilds` | **NOT SET** (absent → Next defaults = `false`) | ✅ build fails on type/lint errors. **Contradicts** PRODUCTION_READINESS.md (2026-10-20) which still claims `ignoreBuildErrors:true` — that flag has since been removed; the stale doc is finding A6-F05. |
| `next.config.ts` `reactStrictMode` | **`false`** | ⚠️ **Contradicts P0-7's claim of `reactStrictMode:true`** (A6-F01). Dev double-render/double-effect verification is OFF; impure-render bugs surface once per cycle. Deliberate but undocumented in next.config (no comment explains it). |
| `next.config.ts` images | not configured (no remote loaders) | ✅ no unbounded image optimizer surface. |
| Security headers | `X-Content-Type-Options`, `Referrer-Policy` set globally; CSP/XFO deliberately deferred to the edge (comment cites security audit V-05) | ✅ posture documented; edge config is deployment work (not in repo). |
| `tsconfig.json` | `strict:true`, `noEmit`, `noImplicitAny`, `isolatedModules`, path alias `@/*` | ✅ strict. `skipLibCheck:true` and `allowJs:true` are standard-tolerated. Excludes docs/evidence/skills from typecheck (scoped). |
| `tests/tsconfig.json` | extends root, `incremental:false` | ✅ tests type-checked under same strictness (not in CI separately — covered by `tsc --noEmit` over `src`+`prisma` includes; tests are NOT in the root `include` — see A6-F13 note). |
| `eslint.config.mjs` | flat config: next core-web-vitals + TS presets; errors: `no-unreachable`, `no-debugger` (zero tolerated); warnings: `no-unused-vars`(ignored `_`), `exhaustive-deps`, `prefer-const`; many rules deliberately off with an ENG-05 ratchet comment | ⚠️ tolerated-warning posture: **lint exits 0 with 41 warnings** (Principal baseline today). No `--max-warnings` cap → warning debt can grow silently (A6-F09). |
| `vitest.config.ts` | `allowOnly:false` ✅; `poolOptions.forks.maxWorkers:12` (documented OOM law, 4 GB sandbox) ✅; `testTimeout 30s`; aliases: `@/lib/db` → throwing stub (tests never open SQLite), `server-only` stub ✅; **no coverage config, no thresholds** | ✅ infra sound; coverage not enforced (A6-F13). |
| `package.json` | scripts verified: `dev` pipes through `tee -a dev.log` (log-growth risk), `db:backup`/`db:restore:drill`/`retention:dry`/`retention:apply`/`perf:baseline` present; `packageManager: bun@1.3.14` pinned; `bun.lock` present (CI `--frozen-lockfile` reproducible) | ✅ |

**Build strictness verdict**: typecheck-strict and build-error-failing posture is real (flags absent = strict defaults; `tsc --noEmit` exit 0 today per Principal baseline). Two deviations from prior claims: `reactStrictMode:false` (contradicts P0-7) and the stale PRODUCTION_READINESS.md flags row. The full build path itself remains **never executed** anywhere in this sandbox (law) — see NOT VERIFIED.

---

## 3. CI/CD readiness

`.github/workflows/ci.yml` (read in full): 3 jobs, triggers `push`/`pull_request` on `main`.

| Job | Steps | Local reproducibility |
|---|---|---|
| `static-gates` (20 min cap) | checkout → Bun 1.3.14 → `bun install --frozen-lockfile` → `bunx prisma generate` → `bun run lint` → `bun run typecheck` → **`bun run build`** | lint/typecheck ✅ proven today (exit 0). **`bun run build` NEVER runnable in this sandbox** (standing law) — the build step of CI is structurally unproven locally (A6-F07-adjacent; honest limitation). |
| `database-gates` (20 min) | `prisma migrate deploy` → `migrate status` → `db:seed` (isolated `db/ci-check.db`) → `validate-seed.py supabase/seed.sql` | `migrate status` ✅ proven today (25/up-to-date). Isolated deploy+seed proven historically (P0-1/P0-7 reports); not re-run today (out of read-only scope). |
| `test-gates` (25 min) | migrate+seed to `db/ci-test.db` → boot `bun run dev` (health-polled ≤120 s, `jq -e '.dbOk == true'`) → `bun run test` (full suite) → **demo-mode-OFF negative probes** (restart with `ASAS_DEMO_MODE=0`: `demoMode==false`, quick-login 403 `DEMO_MODE_DISABLED`, unauthenticated `demoUsers` empty) → teardown `pkill` | full suite ✅ proven today (772/772, 44 files, exit 0 — Principal baseline). Demo-off probes proven historically (P0-7 local replication). |

**"Tests can't silently skip" — verified from code:**
- `tests/contract/api.test.ts` (read in full, 196 lines): bounded preflight (3 attempts × 2 base URLs, 3 s timeout) and on failure **throws at collection time** with the exact remedy (lines 41–49) → the run FAILS, never skips. Comment documents the P0-7 law; `bun run test:unit` is the explicit serverless path.
- `vitest.config.ts` `allowOnly:false` → any `.only`/`describe.only` fails the run deterministically.
- Both claims re-verified in the current tree. ✅ (P0-7 claim **stands**.)

**Honest remote-CI status**: `git remote -v` → **empty** (re-verified this session). No remote, no GitHub Actions execution has ever run this workflow. **REMOTE CI = NOT VERIFIED — an environment limitation, not an app defect.** The workflow file itself is syntactically coherent (3 jobs, `[main]` triggers, Bun pinned, frozen lockfile, isolated DBs, teardown `if: always()`). CI reproducibility caveat: `static-gates` includes a build that is locally unprovable, and `test-gates` boots the dev script which `tee -a dev.log`s (harmless on an ephemeral runner).

**CI verdict**: workflow design is sound and its non-build commands are locally proven today. Two structural gaps: remote execution unverifiable (no remote), and the build gate has never executed anywhere. The documented gate order (PRODUCTION_READINESS.md §"Deployment-phase gate order": history purge BEFORE any remote) correctly sequences this.

---

## 4. Environment & runtime configuration

- **`.env` ↔ `.env.example` parity**: exactly 3 names in each — `DATABASE_URL`, `ASAS_SESSION_SECRET`, `ASAS_DEMO_MODE` (values never read/printed). `.env.example` documents generation (`openssl rand -hex 32`), demo-mode law, PostgreSQL/Supabase variant, and the AI-provider contract (no env vars; `.z-ai-config` file — not present in this sandbox cwd/home → AI routes 503 `AI_PROVIDER_UNAVAILABLE`, which is the documented expected state). `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md` is a complete inventory (3 vars + NODE_ENV, provider matrix, build-time vs runtime). ✅ complete for the app surface.
- **Production fail-fast boot gate** (`src/lib/server/boot.ts` + `src/instrumentation.ts`): `register()` runs `assertProductionEnvironment(process.env)` on every nodejs-runtime server start; production violations **throw → startup crashes**: `SESSION_SECRET_MISSING` / `SESSION_SECRET_PLACEHOLDER` (known placeholders set) / `SESSION_SECRET_WEAK` (<32 chars) / `DEMO_MODE_PRODUCTION`. Non-production never gated. Covered by `tests/unit/boot-env.test.ts` (11 tests incl. the at-floor length boundary and multi-violation ordering — read in full). ✅ **claim verified.**
- **demoMode posture (production misconfig detection)** — three independent layers: (1) boot crash (above); (2) runtime `isDemoModeMisconfigured()` one-time loud console warning on post-boot env drift (session.ts:160–172) + surfaced as `demoModeMisconfigured` on `/api/health`; (3) CI demo-off negative probes. Health exposes `demoMode`/`demoModeMisconfigured`/`sessionSecretConfigured` (presence only) for external deploy gates: `curl /api/health | jq -e '.demoMode == false'`. ✅ strongest misconfig detection of any surface audited.
- **NODE_ENV**: managed by the runtime, never set in `.env` (documented); `NODE_ENV=production` also disables Prisma query logging (`db.ts`: prod `log:['error']` — no query events, obs dbQueries honestly report zeros).
- **Production-config completeness checklist** (app-level): DATABASE_URL ✓, ASAS_SESSION_SECRET ✓ (gated), ASAS_DEMO_MODE=0 ✓ (gated), ASAS_LOG_LEVEL (optional, default info in prod) ✓, ASAS_BACKUP_KEEP (optional, default 14) ✓. **Missing (external, documented, not implemented)**: TLS/edge (Caddy), external log shipping, backup scheduler, monitoring consumer. No placeholder/secret leakage vector in the env surface.

---

## 5. Observability — code verification + LIVE evidence

**Code (all read in full)**: `logger.ts` (JSON-per-line `{ts,level,event,…}`, levels debug→error, `ASAS_LOG_LEVEL`; deep pattern-based redaction `/password|secret|token|cookie|authorization|credential|api[-_]?key|private[-_]?key|session/i`, depth ≤6, strings ≤512, stacks ≤5 frames; errors→stderr) ✅; `obs.ts` (per-route ring buffer 256, ≤200 route keys, error-category counters, db-query ring, globalThis-anchored against Turbopack chunk duplication) ✅; `proxy.ts` (Next 16 `src/proxy.ts` convention, matcher `/api/:path*`, stamps `x-request-id` [well-formed client/edge ids accepted, garbage replaced], `x-asas-route` normalized pattern, `x-asas-request-start`; echoes id on the response) ✅; `route-pattern.ts` (UUID/cuid/numeric → `:id`) ✅; `ok()/fail()` (session.ts) record metrics + emit `http_request`/`api_error` lines + echo the id ✅.

**Live evidence (mine, this session):**

Four traced requests with custom ids (pre-crash server, `dev.log` window 1,470,002→1,490,941 bytes — full window archived in `evidence/a6/devlog-traced-requests.txt`):

```
{"ts":"2026-11-06T18:54:17.918Z","level":"debug","event":"http_request","requestId":"a6audit-sessn-0002","route":"/api/auth/session","method":"GET","status":200,"durationMs":14}
{"ts":"2026-11-06T18:54:18.138Z","level":"debug","event":"http_request","requestId":"a6audit-dashb-0004","route":"/api/dashboard","method":"GET","status":200,"durationMs":109}
```
— the SAME ids echoed on the HTTP responses (`x-request-id: a6audit-sessn-0002` / `a6audit-dashb-0004`, headers captured). Correlation chain **verified live**. Post-restart, the same chain verified again for `/api/notifications` (`a6qmiss-190217` → `durationMs:31`, `a6qhit-190217` → `durationMs:12`) and for two `/api/metrics` rejections whose `api_error` lines carry the exact response-header ids (`38e44d7d-…` 403 AUTHZ; `0f646e3f-…` 401 AUTH).

**`/api/metrics` RBAC (live)**: MANAGER cookie → **403 `{"error":"Requires role ADMIN or higher.","code":"FORBIDDEN_ROLE"}`**; anonymous → **401**. ADMIN-only gate verified live (MANAGER probe) + code (`requireUser("ADMIN")`) + contract tests (SALES_AGENT 403 / ADMIN 200 with snapshot shape). Sarah being MANAGER, the 200-path was verified by tests + code only (A6 verification limit, honestly noted).

**Health v2 live output (paste, pre-crash 18:54:08Z):**
```json
{"status":"ok","dbOk":true,"dbLatencyMs":1,"migrations":25,"demoMode":true,"demoModeMisconfigured":false,"sessionSecretConfigured":true,"uptimeSec":1430,"nodeEnv":"development","rssMb":2535,"checkedAt":"2026-11-06T18:54:08.455Z"}
```
Post-restart (19:02:32Z): same envelope, `rssMb:2067`, `dbLatencyMs:1`, `migrations:25`. All P2-claimed v2 fields present and truthful (`migrations` reflects the real chain length; `rssMb` enabled capacity triage — and in fact let me witness the OOM, see §11).

**Gap found (A6-F04)**: `/api/health` and the `/api/[...path]` JSON-404 catch-all **bypass `ok()/fail()`** (both build `NextResponse.json` directly). Consequences, verified live: the 404 catch-all echoes `x-request-id` (the proxy sets it) but emits **no `http_request`/`api_error` JSON line and records no obs metrics** — my `a6audit-404xx-0003` 404 appears in the log only as the Next dev line `GET /api/nonexistent 404 in 85ms`. Same for health probes. This contradicts obs.ts's header comment "every API response passes through one of them [ok()/fail()]": the metrics store undercounts 404s and health probes. Minor (both routes are cheap/known), but it is a real claim-vs-code deviation.

---

## 6. Performance — fresh measurements (the core re-audit)

**Method**: dev server restarted 18:59Z (post-OOM, by a parallel agent); all samples 19:00:28–19:00:48Z; sequential curl; 2 warmups per endpoint (5–8 for dashboard re-runs) then N=20 timed requests; MANAGER cookie; shared sandbox (other audit agents may generate background load — inherent environment noise, documented). **These are DEV-MODE (Turbopack) numbers.** Production `next start` is unmeasurable here (build forbidden). Raw outputs: `evidence/a6/perf-fresh-core.txt`, `perf-fresh-p2set.txt`.

### 6.1 Required surface (fresh, this audit)

| Endpoint (GET) | mean | p50 | p95 | max |
|---|---|---|---|---|
| `/api/health` (no auth) | 37.0 ms | 21.0 ms | **77.6 ms** | 112.7 ms |
| `/api/auth/session` | 19.9 ms | 15.9 ms | **44.8 ms** | 46.6 ms |
| `/api/dashboard` (1st run, ~30 s post-restart) | 169.2 ms | 117.6 ms | **275.7 ms** | 496.2 ms |
| `/api/leads?limit=20` | 30.4 ms | 17.7 ms | **60.0 ms** | 98.2 ms |
| `/api/opportunities` | 16.9 ms | 14.8 ms | **24.7 ms** | 34.7 ms |
| `/api/notifications` | 12.7 ms | 10.8 ms | **26.4 ms** | 27.0 ms |
| `/api/finance/overview` | 15.2 ms | 13.8 ms | **19.3 ms** | 22.6 ms |
| `/api/visits` | 19.9 ms | 16.0 ms | **24.2 ms** | 65.3 ms |

### 6.2 P2-comparable surface + dashboard warm-up sensitivity

| Endpoint (GET) | mean | p50 | p95 | max | P2 measured p95 (N=30, 03:35Z) | P2 dev-gate budget | Verdict |
|---|---|---|---|---|---|---|---|
| `/api/dashboard` (rerun, w=5) | 48.1 ms | 42.4 ms | **92.1 ms** | 103.0 ms | 51 ms | ≤150 ms | ✅ PASS |
| `/api/dashboard` (rerun2, w=8) | 39.7 ms | 36.9 ms | **50.6 ms** | 62.1 ms | 51 ms | ≤150 ms | ✅ PASS |
| `/api/analytics?days=30` | 29.8 ms | 26.8 ms | **44.4 ms** | 49.4 ms | 50 ms | ≤150 ms | ✅ PASS |
| `/api/leads?page=1&pageSize=50` | 18.5 ms | 16.2 ms | **29.0 ms** | 39.0 ms | 24 ms | ≤100 ms | ✅ PASS |
| `/api/pipeline/stages` | 12.4 ms | 12.1 ms | **14.8 ms** | 15.6 ms | 11 ms | ≤60 ms | ✅ PASS |
| `/api/search?q=cher` | 20.6 ms | 17.8 ms | **36.7 ms** | 40.5 ms | 29 ms | ≤100 ms | ✅ PASS |
| `/api/notifications` | 12.7 ms | 10.8 ms | **26.4 ms** | 27.0 ms | 28 ms | ≤100 ms | ✅ PASS |
| `/api/journey/stats` | 17.5 ms | 16.9 ms | **19.6 ms** | 21.9 ms | 15 ms | ≤80 ms | ✅ PASS |
| `/api/dashboard` (post-restart window) | 169.2 ms | 117.6 ms | **275.7 ms** | 496.2 ms | — | ≤150 ms | ❌ **BUDGET EXCEEDED** in the cold/warm-up window |

### 6.3 Interpretation (honest)

1. **P2's p95 11–51 ms claims REPRODUCE** in steady state: every P2-budgeted endpoint passes today with the same order of magnitude (my steady p95s: 14.8–92.1 ms vs P2's 11–51 ms; slightly higher across the board — the fresh server was compiling routes and carrying ~2 GB RSS under concurrent multi-agent load).
2. **The dashboard dev-gate budget (≤150 ms) is exceeded during the post-restart warm-up window** (p95 275.7 ms, max 496 ms; settles to 50.6–92.1 ms after 5–8 warmups). The P2 budget table is a **steady-state gate**, not a cold-start gate — that qualification is not in the P2 doc (A6-F07). Operationally: any future `perf:baseline` run too soon after a restart will false-fail the gate.
3. Endpoints never budgeted by P2 (session, opportunities, finance/overview, visits, health) all measure p95 ≤ 78 ms warm — no new hotspot exists.
4. **DB layer**: health `dbLatencyMs` measured 1–2 ms live; single-request query volumes measured directly (§7) — dashboard ≈ 65 queries/request (counted in the traced dev.log window), notifications miss = 32 / hit = 2.
5. Memory-as-performance: RSS grew 986 MB → 2,174 MB in 73 s of my moderate sequential load (fresh server) — the OOM class is a **capacity** constraint on this 4 GB sandbox, and it fired mid-audit (§1, A6-F02).

---

## 7. Notification polling cost — verified with a precise query count

**Code (read in full)**: `use-notifications.ts` — `refetchInterval` = pure function of last payload (urgent/warning → 60 s; quiet → 300 s), `refetchIntervalInBackground:false` (explicit; source-scan-guarded by tests per P2), `refetchOnWindowFocus:true`, `staleTime:30_000`. `notification-cache.ts` — `ScopedTtlCache` TTL 30 s (= client staleTime), ≤64 entries LRU, **scope keys from the same visibility primitives the route uses** (`org:${orgId}` for MANAGER+, `agent:…`/`field:…` otherwise — cross-visibility leakage impossible by construction), globalThis-anchored singleton, hit/miss counters exposed on `/api/metrics`.

**Live measurement (byte-window isolation on `/tmp/p4a3-dev.log`, exactly one `http_request` line per window → zero contamination):**

| Scenario | Prisma queries counted | Detail |
|---|---|---|
| **Cache MISS** (TTL expired, full recompute) | **32** | tables: Lead 8, Visit 6, Reservation 5, Task 3, Project 3, User 2, ProjectAssignment 2, RevokedSession 1, OrgSetting 1, Opportunity 1, Apartment 1 (+expiry sweeps riding the miss) — window log archived |
| **Cache HIT** (1.0 s later, inside 30 s TTL) | **2** | exactly `User` auth lookup + `RevokedSession` check — nothing else |
| `generatedAt` replay | miss = hit = `2026-11-06T19:02:17.519Z` | cached payload replayed verbatim (the externally observable hit signal) |

**Verdict on the P2 claim "warm poll = 2 queries (auth lookup only)": TRUE — reproduced exactly (2/2 queries, `generatedAt` byte-identical).** The pre-optimization claim of ~35–40 queries per manager poll is also corroborated in kind (32 today, dataset-dependent). Warm `/api/notifications` latency measured p95 26.4 ms — consistent with the cached path. The P2 notification-optimization report's numbers **stand**.

---

## 8. Background jobs

- **Expiry scheduler** (`src/lib/server/expiry-scheduler.ts` + `expiry.ts`, both read): `setInterval` 60 s, `.unref()`, globalThis singleton (HMR-safe), booted from `src/instrumentation.ts` `register()` (ENG-07: sweeps from server START, not first request) with the notifications route as second entry point. Sweeps: `expireDueReservations` (ACTIVE/CLOSURE_REQUESTED past `expiresAt` → EXPIRED + apartment release + guarded opportunity-stage correction, all in one transaction with audit + timeline) and `expireDueOffers`. Idempotent, indexed `[status, expiresAt]` scans; silent when nothing due; failures warn, never crash.
- **Live evidence**: the last two `dev.log` lines before the OOM freeze ARE a scheduler tick (Reservation + Offer expiry scans, 18:54:19); post-restart, the same scan pattern recurs in `/tmp/p4a3-dev.log` (5 Offer + 9 Reservation expiry scans within ~3 min; line 9102 = the exact `status IN (?,?) AND expiresAt < ?` shape) — the scheduler demonstrably ticks on its own clock and additionally rides notifications cache-misses.
- **Retention machinery** (`scripts/retention.ts` + `src/lib/server/retention.ts`, read in full): PROTECTED/OPERATIONAL(730 d)/DIAGNOSTIC(90 d) classes; PROTECTED rows unreachable by the deletion WHERE-clauses by construction; apply = operator-only CLI, **triple-gated** (fresh verified backup <15 min + `--confirm-purge` typed flag + archive-JSONL-before-delete). **`bun run retention:dry` executed by this audit: zero writes PROVEN (`sha256(db/custom.db)` identical before/after); report truthful: 0 eligible rows in all three classes (audit 186 total/20 diagnostic, activity 187/123 operational, loginFailure 11).** Dry-run claim from P2 retention report **stands**.
- **⚠️ Defect found in the apply gate (A6-F03)**: the live dry-run reported `applyGuard.freshBackupFound:false` **despite** `db/backups/backup-20261106T185536Z/manifest.json` existing with `integrity:"ok"` and age ~2 min. Root cause (verified in code + engines): backup manifests carry compact stamps `ts:"20261106T185536Z"` (`backup-logic.mts` `formatStamp`/`STAMP_RE`), but `retention.ts` `findFreshBackup()` parses them with `Date.parse()` → **NaN for the compact form (verified in both bun and node)** → every real manifest is skipped → **`retention:apply` can NEVER be authorized by a real backup** (fail-closed, so safe — but the documented workflow is broken). The unit test that "passes the gate" feeds an ISO-format `ts` the real system never writes (`tests/unit/retention.test.ts:112`) — a cross-module contract test gap.

---

## 9. Deployment & hosting compatibility (critical judgement, zero trust)

**Architecture facts (code-verified)**: single-instance SQLite monolith — `db/custom.db` file (Prisma, `migration_lock.toml` sqlite), document binaries on the local filesystem (`db/docs/`, `DOCS_DIR = <cwd>/db/docs` per VERCEL_SETUP.md §4; backup.sh tars it), in-process 60 s expiry scheduler, process-local notification cache + obs metrics + lead-capture rate limits (10/min per token, 30/min per IP, in-memory sliding windows — restart resets them; login lockout is DB-backed and survives restarts), `output:"standalone"` + `node .next/standalone/server.js` start path.

**(a) VPS / Docker single node — COMPATIBLE by design.** File persistence (DB + docs), the scheduler, the caches, the rate limits and the metrics all fit one long-lived process; the standalone output exists precisely for this; SQLite-to-PostgreSQL remains optional (direct connection documented for long-lived self-hosted servers in ENVIRONMENT_VARIABLES.md). Required production accompaniments (external): reverse proxy/TLS (Caddy, deferred by design), log rotation/shipping (JSON lines ready), backup cron (scripts exist, scheduler absent), uptime probe consuming `/api/health`.

**(b) Vercel / serverless — INCOMPATIBLE for the current architecture in four ways, only ONE of which the repo documents.** Official Vercel documentation (fetched live 2026-11-06, HTTP 200):

- `https://vercel.com/docs/functions/runtimes`: *"Vercel functions have a read-only filesystem with writable /tmp scratch space up to 500 MB."* and *"Functions are archived when not invoked: Within 2 weeks for Production Deployments, Within 48 hours for Preview Deployments."*
- `https://vercel.com/docs/functions/concurrency-scaling`: *"how many instances of your functions can run simultaneously… scale to a maximum of 30,000 on Hobby and Pro or 100,000 on Enterprise."*
- (The task-brief URL `vercel.com/docs/serverless-functions/using-serverless-functions` returns **404** — doc moved; live equivalents cited above.)

| Single-instance assumption | Consequence on Vercel | Documented in repo? |
|---|---|---|
| SQLite file + `db/docs/` uploads | no persistent writable FS (only per-instance /tmp) → DB and uploads non-durable | ✅ VERCEL_SETUP.md §4 (documents the uploads caveat + Supabase Storage as NOT-implemented fix; the DB moves to Supabase PostgreSQL per the doc) |
| in-process 60 s expiry scheduler | instances archive/recycle; setInterval does not keep ticking → **D9 returns** (no-traffic expiry stops), only the demand-driven lazy sweeps remain | ❌ NOT documented |
| in-memory rate limits (lead-capture) | effective limit × instance count; windows reset on recycle → anti-spam degraded | ❌ NOT documented |
| process-local notification cache + obs metrics | cache dedup collapses across instances (perf regression); `/api/metrics` reports one random instance's numbers → monitoring meaningless | ❌ NOT documented |

**Assessment of the repo's own hosting posture**: `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/PRODUCTION_READINESS.md` (last full review **2026-10-20**) gate order targets **GitHub → Supabase → Vercel**, and its "Runtime compatibility" row honestly marks the production runtime (Vercel) NOT VALIDATED. But the doc predates P0-7/P2 and is **stale on multiple rows** (claims `ignoreBuildErrors:true` — absent today; 12 migrations — now 25; "no unit-test framework" — now 772 tests; "Logging: no structured pipeline" — P2 added JSON lines + request IDs) — it also **does not surface the four serverless incompatibilities**; VERCEL_SETUP.md surfaces exactly one. **Verdict: the Vercel path as documented would ship a system whose expiry automation, abuse controls and operational metrics silently degrade; the honest status is "Vercel = major rework" (scheduler externalization [Vercel Cron], shared-store rate limiting, storage adapter, metrics aggregation), not a config-only deploy. The standalone/VPS path matches the code as built.** (A6-F06.)

---

## 10. Operational risk register

| ID | Risk | Severity | Evidence (measured/verified this audit) |
|---|---|---|---|
| A6-F01 | `reactStrictMode:false` contradicts P0-7's documented `true`; dev-side double-render verification OFF; no in-file comment records the decision | Medium | next.config.ts:11 (read); P0-7 report claim (read) |
| A6-F02 | OOM incident class recurred DURING this audit: next-server killed at 2.55 GB RSS in the 4 GB sandbox (5th+ documented occurrence); fresh server ramped 986→2,174 MB RSS in 73 s under moderate load | High (environment/ops) | dmesg `Killed process 1898`; health `rssMb:2535` pre-crash; `rssMb:2067` post-restart; vitest 12-worker cap comment |
| A6-F03 | Retention apply-gate timestamp contract mismatch: manifests `YYYYMMDDTHHMMSSZ` vs `Date.parse` → NaN → `freshBackupFound` always false → `retention:apply` unexecutable against real backups (fail-closed). Unit test masks it with ISO-format fixtures | Medium | Live dry-run vs manifest (18:57:29Z vs 18:55:36Z backup); `Date.parse` NaN verified in bun+node; retention.ts:168; backup-logic.mts formatStamp; retention.test.ts:112 |
| A6-F04 | `/api/health` + JSON-404 catch-all bypass `ok()/fail()` → no structured log line, no obs recording (metrics undercount 404s/probes); contradicts obs.ts "every API response" claim | Low | Route code (both read); live 404 `a6audit-404xx-0003` produced no JSON line (dev.log window archived) |
| A6-F05 | PRODUCTION_READINESS.md stale (2026-10-20): wrong build flags, 12-vs-25 migrations, "no vitest", "no structured logging" — the deployment-phase entry checklist no longer reflects the tree | Medium | Doc read + current-tree verification throughout §2–§5 |
| A6-F06 | Hosting-target contradiction: documented production runtime (Vercel) incompatible with 4 single-instance assumptions (scheduler/rate-limits/metrics/cache) + SQLite/docs persistence; only the FS caveat documented | High (deployment decision) | Vercel official docs (cited, 2026-11-06); VERCEL_SETUP.md §4; PRODUCTION_READINESS.md gate order; obs.ts/notification-cache.ts/lead-capture.ts/expiry-scheduler.ts single-instance comments |
| A6-F07 | Perf dev-gate budgets are steady-state only: post-restart warm-up window violates the dashboard budget (p95 275.7 ms > 150 ms; settles to 50.6–92.1 ms); methodology qualification missing from P2 doc | Low | §6.2 table (measured) |
| A6-F08 | Log continuity breaks on crash/restart: dev.log frozen at OOM (18:54:19); restarted server writes to `/tmp/p4a3-dev.log` (ephemeral) — the structured-log trail for post-crash traffic is off-tree; no log rotation on `tee -a dev.log` (unbounded growth while canonical) | Low (sandbox) / Medium (prod log growth) | File mtimes/sizes; `/proc/14487/fd/1`; package.json dev script |
| A6-F09 | Lint warning debt uncapped: 41 warnings exit 0; no `--max-warnings` gate → gradual rot risk (ENG-05 ratchet is process, not enforcement) | Low | eslint.config.mjs (read); Principal baseline 0 errors/41 warnings |
| A6-F10 | No external alerting/monitoring: in-process metrics only; a fatal crash (today's OOM) is invisible to the app itself; `/api/health` exists but nothing consumes it in a supervisory loop | Medium (production) | obs.ts single-instance law; no watchdog/alerting config in repo (P2 decision: no Sentry, JSON seam ready) |
| A6-F11 | Backup cadence is manual: scripts excellent (VACUUM INTO + integrity-check-on-snapshot + manifest + retention 14 + drill-mode restore), but NO scheduler exists; sandbox resets wipe untracked backups (R13 finding) | Medium | backup.sh/restore.sh (read); no cron/systemd units in repo; PRODUCTION_READINESS.md Backup PARTIAL |
| A6-F12 | In-process state lost on every restart: obs metrics (uptime/counters/p95), notification cache (hit-rate resets), rate-limit windows — acceptable single-instance trade-offs but they make "restart" an observability+abuse-control event | Low (documented) | obs.ts/notification-cache.ts/lead-capture.ts design comments; witnessed restart |
| A6-F13 | Test-infra gaps: no coverage thresholds; `tests/**` outside tsconfig `include` (type-check coverage of tests depends on editors/CI tsc scope) | Low | vitest.config.ts (no coverage block); tsconfig include list |
| A6-F14 | Single-writer log law fragility in dev: `tee -a` chain breaks when an operator launches `next dev` directly (as happened post-restart) | Low | /proc fd evidence |

**Positive verifications (prior claims that STAND)**: no-silent-skip contract law (throw-at-collection + `allowOnly:false`) ✅; boot fail-fast gates + 11 unit tests ✅; health v2 envelope live ✅; request-ID correlation live ✅; `/api/metrics` ADMIN-gating live (403 MANAGER / 401 anon) ✅; notification warm-poll = 2 queries + `generatedAt` replay live ✅; retention dry-run write-free ✅; expiry scheduler ticking live ✅; P2 steady-state p95s reproduced ✅; email/SMS evaluation honestly BLOCKED (no credentials — verified: no provider keys exist) ✅.

---

## 11. Staging readiness — requirement checklist (no deployment performed)

| # | Requirement | Readiness state (repo evidence) |
|---|---|---|
| 1 | `ASAS_SESSION_SECRET` strong (≥32 chars, non-placeholder) | ✅ READY — boot gate crashes otherwise (instrumentation.ts); generation documented; placeholder set blocked |
| 2 | `ASAS_DEMO_MODE=0` | ✅ READY — boot crash + health assertion + CI demo-off probes (3 layers) |
| 3 | `NODE_ENV=production` | ✅ READY (mechanism) — set by runtime/standalone; never manually set; query-logging off in prod |
| 4 | `migrate deploy` against staging DB | ✅ READY — `db:migrate:deploy` script; chain 25 migrations up-to-date (verified today); CI replays it on isolated DBs |
| 5 | Seed-or-empty decision | ✅ READY — `prisma/seed.ts` idempotent (seeds only when no users; proven in recoveries per docs) |
| 6 | Verified `next build` + `node .next/standalone/server.js` boot | ❌ **BLOCKED** — build never executed in this sandbox (law); standalone start path UNVALIDATED anywhere; must be the first staging action |
| 7 | Backup schedule (cron/systemd) + offsite | ⚠️ PARTIAL — backup/restore drill scripts READY and tested; scheduler + offsite NOT wired (manual-only) |
| 8 | Health/uptime monitoring consumer + alerting | ⚠️ PARTIAL — `/api/health` v2 READY (deploy-gate assertions documented); no external consumer/alerting exists |
| 9 | Reverse proxy / TLS (Caddy) + cookie `Secure` flip | ⚠️ PARTIAL — deferred-by-design to edge (documented); no config artifact in repo; F-15 residual closes only here |
| 10 | Log shipping/rotation for JSON lines | ⚠️ PARTIAL — JSON-lines seam READY (parseable); no shipper/rotation wired |
| 11 | DB provider decision (SQLite single-node vs PostgreSQL) | ✅ READY for single-node (current schema); PostgreSQL variant exists but NOT VALIDATED (provider swap is a repo operation) |
| 12 | Operator runbook (restart, recovery, retention, restore) | ✅ READY — restore.sh interlocks, retention triple-gate (modulo A6-F03 fix), AGENTS.md ops law; production runbook is thin (PRODUCTION_READINESS.md admits PARTIAL) |
| 13 | Secret-rotation procedure | ⚠️ PARTIAL — policy docs referenced (.env.example, SECURITY_HARDENING, GIT_HISTORY_PURGE) + "never reuse committed values" law; no per-secret rotation RUNBOOK with cadence |

**Staging verdict**: a **single-node (VPS/Docker) staging environment can be operated safely with the current artifacts** provided item 6 (first-ever `next build` + standalone boot validation) is executed as the entry gate and items 7–10 are wired at the host level (they are external-to-app by design). A **Vercel/serverless staging cannot** — it requires the A6-F06 rework first. The in-app safety gates (boot crash, demo-off probes, health assertions) are the strongest readiness assets; the unexecuted build and the stale readiness matrix are the weakest.

---

## 12. Findings register (summary)

| ID | Severity | One-line statement |
|---|---|---|
| A6-F01 | Medium | `reactStrictMode:false` in the tree contradicts P0-7's claimed `true` — claimed strictness posture partially false (build-error strictness itself IS real: flags absent). |
| A6-F02 | High (env/ops) | OOM class recurred live during the audit (2.55 GB next-server killed; 986→2,174 MB in 73 s post-restart) — the 4 GB sandbox remains capacity-bound; the 12-worker vitest cap is the right mitigation, dev-server RSS growth is unbounded in dev mode. |
| A6-F03 | Medium | Retention `--confirm-purge` backup gate can never pass against real manifests (compact-stamp `ts` vs `Date.parse` → NaN); fail-closed but workflow-breaking; test fixture uses the wrong format. |
| A6-F04 | Low | Health + 404-catch-all routes bypass the observability builders (no log line, no metrics) — obs "every API response" comment overclaims. |
| A6-F05 | Medium | PRODUCTION_READINESS.md is stale on ≥5 rows (flags, migration count, test framework, logging, CI state) — unreliable as the deployment entry checklist until refreshed. |
| A6-F06 | High (deployment) | Documented Vercel production target conflicts with four single-instance assumptions (scheduler, rate limits, metrics, cache) + file persistence; only the filesystem caveat is documented — the Vercel path needs rework, not config. |
| A6-F07 | Low | Dashboard dev-gate budget is steady-state-only (post-restart window: p95 275.7 ms vs ≤150 ms budget) — budget table lacks the cold-window qualification. |
| A6-F08 | Low/Medium | Log continuity + growth: crash froze dev.log; restart logs to /tmp (off-tree); `tee -a` never rotates. |
| A6-F09 | Low | 41 lint warnings tolerated with no cap (ratchet is procedural, not enforced). |
| A6-F10 | Medium | No external alerting/monitoring consumer — crashes are externally invisible (today's OOM proved it: nothing in-repo noticed). |
| A6-F11 | Medium | Backup cadence manual-only (scripts READY, scheduler absent, offsite absent). |
| A6-F12 | Low | Restart = observability/abuse-control reset (documented single-instance trade-off, witnessed). |
| A6-F13 | Low | No coverage thresholds; tests outside tsconfig include scope. |
| A6-F14 | Low | Dev log single-writer law breaks when the server is launched outside the npm script (happened post-restart). |

## 13. NOT VERIFIED (honest list)

1. **Remote CI execution** — no git remote exists (structurally impossible in this sandbox); workflow never ran on GitHub Actions. Environment limitation, not an app defect.
2. **`bun run build` / standalone `server.js` boot** — build forbidden in this sandbox; the production start path has never executed anywhere. The single largest unverified production assumption.
3. **`/api/metrics` 200-path as ADMIN** — my persona is MANAGER (403 verified live); the 200 snapshot shape is verified by code + contract tests only.
4. **Production-runtime performance** (`next start`) — all numbers here are dev-mode Turbopack (documented caveat; P2's deferral of bundle/production profiling to a build-capable phase is correct).
5. **Supabase/PostgreSQL provider path** — schema variant + docs exist; never exercised (PRODUCTION_READINESS marks it NOT VALIDATED; concurred).
6. **Live restore drill execution** — Agent 2's mandate; this audit assessed the procedure (scripts + interlocks read; drill mode provably never touches the live DB) without running it.
7. **Task-brief Vercel doc URL** — returns 404 (moved); equivalent live official pages cited instead (runtimes + concurrency-scaling, 2026-11-06).
8. **`perf:baseline` script run** — skipped by law (it writes a JSON artifact); protocol replicated manually with curl.

---

## Appendix — evidence inventory (`05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/evidence/a6/`)

| File | Content |
|---|---|
| `live-evidence.txt` | Master evidence: OOM record, correlation lines, health v2 outputs, metrics RBAC, notification miss/hit counts, scheduler scans, retention dry-run + timestamp-mismatch proof, Vercel doc statements |
| `perf-fresh-core.txt` | Fresh N=20 measurements, 8 required endpoints |
| `perf-fresh-p2set.txt` | Fresh N=20, P2-comparable set + dashboard warm-up re-runs |
| `devlog-traced-requests.txt` | The exact 79-line dev.log window containing my 4 traced requests |
| `notif-miss-32queries.log` | Full byte-window log of one cache-MISS notifications request (32 queries) |
| `notif-hit-2queries.log` | Full byte-window log of one cache-HIT notifications request (2 queries) |
| `retention-dry-run.json` | Complete `retention:dry` output (with applyGuard false-negative) |
| `health-live-final.json` | Final live health v2 snapshot |
