# ASAS CRM — Phase 4: Critical & Consolidated Findings Register

**Consolidated by:** Principal Engineering Lead · **Date:** 2026-11-06
**Sources:** Six independent agent audits (P4-A1 Architecture, P4-A2 Database, P4-A3 Security, P4-A4 CRM Domain, P4-A5 UI/UX, P4-A6 DevOps/Performance) + Principal's own reproductions.
**Deduplication law:** identical findings reported by multiple agents are merged into ONE register row with the corroborating agent IDs cited. Every CRITICAL/HIGH finding and all MEDIUMs were either reproduced by the Principal or carry two independent agent evidences.

**Severity counts: CRITICAL 0 · HIGH 3 (all environment/deployment-shaped, not application-code defects) · MEDIUM 10 · LOW 17 · INFO 9.**

---

## 1. HIGH findings

### P4-H01 — OOM incident class recurred during the audit (environment)
- **Origin:** A6-F02; corroborated independently by A1 (server unreachable), A2 (server absent 18:53Z), A3 (down 18:55Z, restarted), A4 (down 18:54–19:01Z).
- **Location:** sandbox host (4 GB) vs `next dev` RSS; measured ramp 986→2,174 MB in 73 s post-restart (A6); kill observed at 2.55 GB RSS. Principal post-restart health: `rssMb:2031`.
- **Impact:** any long-running instance in a 4 GB host is reaped; no auto-watchdog exists (a 15-min cron watchdog referenced in old commits is **not currently armed** — cron registry empty at audit start). In production the in-process expiry scheduler stops with the process (sweeps resume lazily on next read — A4).
- **Reproduction:** live, witnessed 5× this session by 5 agents.
- **Recommendation:** staging host ≥8 GB headroom or container memory limit + restart policy; external watchdog; keep the lazy-resume sweep as backstop. **Not an application-code defect.**

### P4-H02 — Vercel/serverless hosting path incompatible with 4 single-instance assumptions (deployment)
- **Origin:** A6-F06 (Principal verified the code facts).
- **Location:** `src/lib/server/expiry-scheduler.ts:36` (in-process `setInterval` — Principal grep-confirmed); process-local rate limits (`lead-capture.ts`, login lockout in-DB but window state in-memory); in-process obs metrics/cache; SQLite file `db/custom.db` + uploads in `db/docs/`.
- **Evidence:** official Vercel docs fetched live 2026-11-06 (read-only FS + `/tmp` ≤500 MB; functions archived after 48 h idle; up to 30,000 instances) — only the filesystem caveat is documented in `VERCEL_SETUP.md`; the other three incompatibilities are undocumented.
- **Impact:** choosing Vercel as-is silently breaks expiry sweeps (D9 regression), multiplies rate-limit budgets, and loses metrics — rework, not configuration.
- **Recommendation:** host on a single node (VPS/Docker — compatible by design, `output:"standalone"` confirmed) **or** rework the 4 mechanisms before any serverless target; fix the documentation.

### P4-H03 — Production build has never been executed anywhere (operational blocker, environment)
- **Origin:** A6 staging gate; corroborated by repo facts.
- **Location:** `next build` forbidden by sandbox policy; `.github/workflows/ci.yml` contains the build step but has never run (no git remote — Principal: `git remote -v` empty).
- **Impact:** the `start` script (`node .next/standalone/server.js`) is an **unvalidated production assumption**; tsc+lint green is strong but not proof of a successful Next production build.
- **Recommendation:** the first-ever `next build` + standalone boot + health check must be the **entry gate of the staging environment** (cannot be satisfied in this sandbox — recorded as BLOCKED here, condition C1 in the readiness gate).

---

## 2. MEDIUM findings

| ID | Finding (merged IDs) | Location | Status / Reproduction | Impact | Recommended action |
|---|---|---|---|---|---|
| **P4-M01** | Retention apply-gate permanently fail-closed: `Date.parse("YYYYMMDDTHHMMSSZ")` = NaN → `findFreshBackup` never matches → destructive apply can never be authorized by a real backup; unit test fixture uses ISO format so the bug is invisible to the suite (A2-F02 = A6-F03) | `src/lib/server/retention.ts:168` | **Principal reproduced:** `Date.parse("20261106T185536Z") → NaN` vs ISO → valid; A2 live-proved `freshBackupFound:false` with a 2-min-old integrity-ok backup | Retention:apply is inert (fail-safe direction — nothing can be deleted); the documented "triple-gated" control is actually single-gated-by-bug | Fix the parse (manifest emits compact stamps); fix the test fixture to the real manifest format; re-run live refusal probe |
| **P4-M02** | Backup cannot bootstrap on a clean workspace: `backup.sh` mkdirs `db/docs` only; `backup-run.mjs:55` uses `mkdir(…, {recursive:false})` → first-ever `db:backup` fails ENOENT (A2-F01) | `scripts/backup.sh:31`, `scripts/lib/backup-run.mjs:55` | **Principal confirmed by code read**; A2 reproduced live (workspace had zero backups at audit start) | Fresh deployments cannot produce their first backup without manual mkdir | `mkdir -p db/backups` in backup.sh (keep the non-recursive inner dir for the same-second collision law) |
| **P4-M03** | Demo seed plants public password in production-shaped environments: `db:deploy` = `migrate deploy && db seed`; seed writes OWNER+7 personas with `DEMO_PASSWORD="asas1234"` (literal shown on the login overlay); boot gates do not cover the seed path (A3-F01) | `prisma/seed.ts:21`, `package.json` `db:deploy`, `login-overlay.tsx:52` | **Principal confirmed by code read** | Deployment footgun: an operator following the documented deploy script on a real server creates an OWNER account with a public password | Guard the seed (refuse when `NODE_ENV=production` unless an explicit `--i-know` flag), or document mandatory password rotation post-deploy |
| **P4-M04** | Money-cap asymmetry — P1 carry-forward F2 **still open**: installments routes validate `.max(1e12)` vs shared `MAX_MONEY_DZD` (1e10) = 100× the money law; 3 more sites re-declare private 1e10 copies (A1-F001 = A3-F02 = A4-F001) | `api/finance/installments/route.ts:36`, `installments/[id]/route.ts:21`, `server/csv.ts:205`, `api/targets/route.ts:33`, `settings/targets-section.tsx:49`, `api/reservations/[id]/route.ts:49` | **Principal confirmed** (route line 36 re-read) | Schedule lines can carry 100× the ceiling and flow into scheduled/called KPIs | Single-source the cap from `validation.ts`; one-line fixes ×6 |
| **P4-M05** | Service-extraction covers 4 of ~12 domains; god-routes remain: visits 628, opportunities/[id] 548, notifications 500, leads 489, leads/[id] 464 lines with inline domain logic; 71/87 routes import db directly (A1-F002) | `src/app/api/**` | A1 measured (wc -l) | Maintainability debt (known-shaped, queued as wave 2) | Apply the existing W2-A3 extraction template to visits/opportunities/notifications/leads |
| **P4-M06** | `reactStrictMode:false` in the tree contradicts the P0-era reported flip to `true` (A6-F01) | `next.config.ts:11` | **Principal confirmed by direct read** | Config-integrity discrepancy (dev-time double-render checks absent); prior report accuracy issue | Flip to `true` and re-run the dev sweep, or document the deliberate off |
| **P4-M07** | `PRODUCTION_READINESS.md` stale on ≥5 rows (strict flags, 12-vs-25 migrations, "no vitest", logging, CI) (A6-F05) | `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/PRODUCTION_READINESS.md` | A6 doc-vs-repo diff | Future operators will act on false readiness facts | Refresh the document against Phase-4 evidence |
| **P4-M08** | No scheduled backup cadence and no offsite copy; backups manual-only; `db/backups/` co-located on the same disk (A2-F04 = A6-F11) | operations | A2 (zero backups existed at audit start) | RPO unbounded | Schedule `db:backup` (cron/systemd), define offsite copy |
| **P4-M09** | No external alerting/monitoring consumer: health v2 + ADMIN metrics exist in-process; today's fatal OOM was invisible in-repo (A6-F10) | operations | A6 live (metrics 403/401 gates verified; no consumer) | Silent outages | External uptime check + alert channel before real data |
| **P4-M10** | Legacy `db:snapshot` is a raw `cp` of the live DB — violates the project's own "NEVER a live file-copy" consistency law; torn-page footgun still wired as an npm alias (A2-F03) | `package.json:23` | **Principal confirmed by read** | One command away from an inconsistent "backup" | Retire the alias or route it through VACUUM INTO |

---

## 3. LOW findings

| ID | Finding (origin) | Location | Note |
|---|---|---|---|
| P4-L01 | Direct-booking audit `after.value = reservation.amount` while `Opportunity.value` never written at booking — P1 F3 carry-forward **still open** (A3-F03 = A4-F002) | `services/reservations.ts:609`, flagged in `financial-semantics.ts:48-52` | documented deferral |
| P4-L02 | No payment-recording idempotency (double-submit below remaining balance creates two Payment rows; only EXCEEDS_REMAINING caps totals) (A4-F003) | `services/payments.ts` | contrast: activities have D12 dedup |
| P4-L03 | Process-local rate limiting (capture/copilot/analyze) — restart resets; single-instance law (A3-F04) | `lead-capture.ts:215-269` | carry-forward, documented |
| P4-L04 | Per-email-only lockout → cheap targeted account-lockout DoS; distinct-email spray grows `LoginFailure` until manual purge (A3-F05) | `auth.ts:84-117` | |
| P4-L05 | h1→h3 heading-level skip on dashboard (A5-F01) | dashboard view | deliberate flat outline was P2-documented; A5 re-measured a skip |
| P4-L06 | Touch targets below 44px best practice (32×28, 36×36 measured; 54 dashboard buttons <40px tall) — WCAG 2.5.8 AA (24px) passes (A5-F02) | topbar/density controls | = P1 F4 open |
| P4-L07 | 7 console warnings: missing `audit.action.*` i18n keys ×3 languages (LEAD_TOUCH_RECORDED, LOGIN_LOCKED, LOGIN_FAILED) (A5-F03) | `src/lib/i18n/domains/audit.ts` | |
| P4-L08 | `/api/health` + 404-catch-all bypass `ok()/fail()` → no structured log line / metrics ("every API response" overclaim) (A6-F04) | `api/health/route.ts`, `api/[...path]/route.ts` | |
| P4-L09 | Dashboard perf budget is steady-state-only; post-restart cold-window p95 275.7 ms > 150 ms budget (A6-F07) | perf docs | document the warm-up window |
| P4-L10 | dev.log continuity: single-writer law breaks when the server is launched outside the npm script; `tee -a` never rotates (A6-F08, A6-F14) | `package.json` dev script | environment/ops hygiene |
| P4-L11 | 41 lint warnings (P2 documented 38 — drift +3), no ratchet cap (A6-F09) | eslint | |
| P4-L12 | Restart resets obs metrics / notification cache / rate-limit windows (A6-F12) | by-design trade-off | documented |
| P4-L13 | No coverage thresholds; tests outside tsconfig include (A6-F13) | vitest/tsconfig | |
| P4-L14 | Layering inversion (type-only lib→component import) (A1-F003) | `workspace-store.ts:30` | type-only |
| P4-L15 | Dependency hygiene: `prisma` CLI in prod deps; `z-ai-web-dev-sdk` 0.x unstable range (all 43 deps verified used) (A1-F011) | `package.json` | |
| P4-L16 | "depuis 1 jours" pluralization slip on kanban (A5-F04) | pipeline view | trivial |
| P4-L17 | Money stored as Float/REAL — SQLite platform limit, owner-gated, mitigated by MONEY_EPSILON + guarded sums (A2-F06) | `prisma/schema.prisma` | documented |

## 4. INFO / positive-verification notes

- **P4-I01** (A1-F010): resurrection sweep clean — all historically-deleted zombies confirmed ABSENT (i18n monolith, api/route.ts, view-placeholder, check-duplicates, unit-types); 22 ever-deleted-then-back files are all the documented Phase-D re-introductions.
- **P4-I02** (A1-F012): error architecture systematic — envelope on 85/87 routes, try/catch on 86/87, dual React error boundaries, redacting logger.
- **P4-I03** (A3): CSRF origin checks live (cross-origin login/logout → 403 `CROSS_ORIGIN_BLOCKED`); field-rep project-scope denial verified live; email minimization below MANAGER verified.
- **P4-I04** (A4): §37/§38 role-aware DTO — SALES_AGENT login shows **0 leaks** of 15 restricted reservation keys (allowlist, fail-closed).
- **P4-I05** (A2): installed `@prisma/client` 6.19.2 vs declared `^6.11.1` (runtime truth; WAL analysis anchored to installed engine).
- **P4-I06** (A4): `GET /api/leads?limit=N` silently ignored (contract is `pageSize`); score reasons can show negative day counts for future-dated seed data (cosmetic).
- **P4-I07** (A3): opportunities/[id] has no GET handler (405) — detail authz lives on PATCH; session-governance suite intentionally leaves `yacine@asas.dz` locked ≤15 min post-run.
- **P4-I08** (A2-F08): `db:restore:drill` self-appends the backup dir — passing one explicitly double-passes the positional; the strict interlock refuses (exit 2, live-observed).
- **P4-I09** (A6): P2's under-claiming pattern verified — notification load was *worse* than the mission assumed pre-P2 and is now 2 queries warm; budgets were measured, reproduced fresh this session.

## 5. Rejected claims log (audit-of-the-auditor)

| Claim | Source | Principal verdict | Evidence |
|---|---|---|---|
| "ci.yml trigger branches mangled (`ain]`)" | A2-F05 | **REJECTED** | Direct read of `.github/workflows/ci.yml` shows clean `branches: [main]` on push + pull_request; workflow intact with static/database/test gates |
| (Session-brief expectation) "P1/P2 zero execution; HEAD `67cd5ff`; 204 tests; migrations 20" | prior session summary | **REJECTED** | Actual: HEAD `6201496`; P1 (682/682 era) and P2 (772/772 era) fully executed and documented in `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/`, `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/`; 25 migrations; fresh 772/772 run this session |

Both rejections demonstrate the zero-trust rule applied symmetrically — to the auditee *and* to the auditors.

## 6. Defect-free verification highlights (what was probed and PASSED)

Authorization (60+ black-box probes, byte-identical ghost 404s) · session forgery/tampering (401s) · CSRF · lockout (live 429) · public capture no-oracle 401 · document security laws · migration chain 25/25 + virgin-DB rebuild identical · fresh backup + restore drill PASS with live DB untouched · financial atomicity (35 fault stages) · offer concurrency (parallel activates → one 201/one 409) · attribution math exact to the dinar · 18 responsive probes zero overflow · RTL live · 0 console errors across 12 views · steady-state p95 14.8–50.6 ms.

*No secrets, database URLs, or credentials appear in this document.*
