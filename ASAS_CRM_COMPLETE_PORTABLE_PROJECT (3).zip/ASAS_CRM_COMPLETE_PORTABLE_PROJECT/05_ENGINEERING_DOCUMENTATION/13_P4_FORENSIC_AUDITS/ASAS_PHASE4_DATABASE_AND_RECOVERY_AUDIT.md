# ASAS CRM — Phase 4 / Agent 2 (P4-A2) Database, Migrations & Data Integrity Audit

**Auditor:** AGENT 2 — Task ID P4-A2 (Database, Migrations & Data Integrity Auditor)
**Date:** 2026-11-06
**Mode:** STRICT READ-ONLY production-readiness audit. The original `db/custom.db` was NEVER opened for writing. Zero trust in prior reports — every claim below was re-derived from live evidence gathered this session.

**Evidence basis:** all commands were executed 2026-11-06 ~18:45–19:00 UTC in `/home/z/my-project`. Raw outputs are preserved under `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/evidence/a2/` (files 01–06 + `prisma_facts.mjs`); disposable-copy databases live under `/tmp/` (`/tmp/p4-a2-fresh.db`, `/tmp/p4-a2-fresh2.db`, `/tmp/p4a2/*.mjs` helper scripts). DB reads used `bun:sqlite` with `{readonly:true}` (the mission's suggested `node:sqlite` module is not resolvable by this Bun 1.3.14 build — `bun:sqlite` is the equivalent builtin; the sanctioned backup tooling itself runs under Node 24 where `node:sqlite` works). Prisma-connection facts were obtained with a script issuing ONLY `SELECT`/`PRAGMA` reads (`05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/evidence/a2/prisma_facts.mjs`).

**Headline verdict:** SQLite is the ONLY active engine. The migration chain is exactly 25 folders ↔ 25 applied rows, 1:1, checksum-identical, zero drift. A virgin database rebuilt from `prisma migrate deploy` alone is SCHEMA-IDENTICAL to the live DB (138/138 objects, byte-identical SQL DDL) — including all four live-hold partial unique indexes, which live INSIDE the migration chain (the reproducibility concern is closed). Fresh backup + restore drill: **PASS** ("original db/custom.db — NOT TOUCHED"). Integrity checks: `integrity_check=ok`, `quick_check=ok`, `foreign_key_check` clean. Census matches the claimed seed exactly. Four Medium findings concern the recovery toolchain (first-run backup bootstrap failure, a fail-closed `Date.parse` bug that permanently disables the retention apply gate, a legacy file-copy snapshot script that contradicts the consistency law, and the absence of any scheduled backup cadence).

---

## 1. Methodology & exact commands

| # | Question | Command(s) | Read-only? |
|---|---|---|---|
| 1 | Active engine | `grep DATABASE_URL .env` (value inspected, session secret NOT printed); Read `src/lib/db.ts`; `rg -i 'supabase\|postgres\|createClient\|pg' src/ package.json` | yes |
| 2 | Schema | Read `prisma/schema.prisma` (1136 lines); `rg '^model \|@@unique\|@@index' prisma/schema.prisma` | yes |
| 3 | Migration chain | `ls -1d prisma/migrations/*/`; `bun:sqlite` readonly SELECT on `_prisma_migrations`; per-migration sha256(file) vs `checksum` column; `bunx prisma migrate status` | yes |
| 4 | Reproducibility | `rm -f /tmp/p4-a2-fresh.db && DATABASE_URL="file:/tmp/p4-a2-fresh.db" bunx prisma migrate deploy` (env-var override — `.env` and live DB untouched); `sqlite_master` diff live vs fresh | yes (disposable copy) |
| 5 | Indexes | `SELECT type,name,tbl_name,sql FROM sqlite_master WHERE name LIKE '%live_hold%'` on live + fresh DBs; Read `prisma/migrations/20261102000000_phase2_d12_live_hold_unique/migration.sql`, `prisma/migrations/20261105180000_p1_offer_option/migration.sql`, `prisma/live-hold-indexes.sql` | yes |
| 6 | Runtime posture | `PRAGMA journal_mode/busy_timeout/page_size/foreign_keys/...` via raw readonly conn AND via the live Prisma connection (SELECT/PRAGMA only) | yes |
| 7 | Transactions | `rg '\$transaction\(' src/` (62 sites); Read `src/lib/services/payments.ts`, `installments.ts`, `reservations.ts`, `src/lib/server/reservation-economics.ts`, `offer-lifecycle.ts`; `rg` expectations in `tests/security/fault-injection.test.ts` | yes |
| 8 | Backup/restore | `bun run db:backup`; `bun run db:restore:drill`; Read `scripts/backup.sh`, `restore.sh`, `scripts/lib/backup-run.mjs`, `backup-engine.mjs`, `backup-logic.mts`, `restore-run.mjs`, `scripts/retention.ts`, `src/lib/server/retention.ts`; `bun run retention:dry` (report only; apply NOT run) | sanctioned non-destructive |
| 9 | Data integrity | `PRAGMA integrity_check` / `quick_check` / `foreign_key_check`; full census of all 36 tables; live-hold invariant probes; status distributions | yes |
| 10 | Data-loss risks | `.gitignore`, `crontab -l`, `.github/workflows/ci.yml`, `git remote -v`, `db/docs` inspection | yes |

NOT executed (per mandate): `bun run build`, full `bun run test`, `db:push`, `db:reset`, `db:seed`, `prisma migrate dev`, `retention:apply`, any write to `db/custom.db`.

---

## 2. Active engine verdict — **SQLite ONLY; PostgreSQL/Supabase dormant**

- `.env:1` → `DATABASE_URL=file:/home/z/my-project/db/custom.db` (the only DB-related vars in `.env` are `DATABASE_URL`, `ASAS_SESSION_SECRET`, `ASAS_DEMO_MODE` — no `SUPABASE_*`/`PG*` keys; secret value not reproduced in this report).
- `src/lib/db.ts` constructs a single global `PrismaClient` from `@prisma/client` (schema `provider = "sqlite"`, `prisma/schema.prisma:9-12`). No `pg`, no `postgres`, no `@supabase/supabase-js` in `package.json` dependencies; the only source-code match for supabase/postgres in `src/` is a comment (`src/lib/server/visibility.ts:192` — "PostgreSQL port (a proper FK + RLS policy replaces this)").
- Dormant artifacts verified present but unwired: `prisma/schema.postgres.prisma` (generated variant, provider=postgresql, 30 models), `supabase/` (5 SQL migrations + config.toml + seed.sql). `package.json` contains no script or dependency that connects to them; `scripts/validate-seed.py supabase/seed.sql` only validates SQL text in CI.
- Runtime confirmation: the live Prisma connection reports `sqlite_version() = 3.46.0` and `journal_mode = delete` (evidence 03).

**Verdict: Implemented · Integrated · Runtime verified.** SQLite is the single active engine; the PG/Supabase path is documentation + generated artifacts only.

---

## 3. Schema review (`prisma/schema.prisma`, 35 models, 1136 lines)

**Structure:** Organization-rooted multi-tenant model — `orgId` on every tenant-owned record. 35 models ↔ 35 app tables in the live DB (exact 1:1; the 36th table is `_prisma_migrations`). 56 FK constraints in `0_init` alone with deliberate `ON DELETE RESTRICT` (tenancy spine: Organization/User/Pipeline/Tag…), `CASCADE` (composition: PipelineStage, LeadTag, VisitApartment) and `SET NULL` (soft references).

**Key integrity-bearing constraints (verified present in the live DB):**
- `Lead @@unique([orgId, phone])` — duplicate-booking guard; `Tag @@unique([orgId, name])`; `Apartment @@unique([orgId, buildingId, code])`; `PipelineStage @@unique([pipelineId, key])`; `Installment @@unique([reservationId, seq])` (concurrent seq race → P2002 → 409 SEQ_CONFLICT, `src/lib/services/installments.ts:246-249`); `SavCase @@unique([orgId, seq])`; `SalesTarget @@unique([orgId, userId, month])`; `PropertyMatch @@unique([requirementId, apartmentId])`; `LeadDuplicateDismissal @@unique([orgId, leadAId, leadBId])`; `RevokedSession @@unique([userId, issuedAtMs])` (point-lookup revocation check piggybacked on the user select); `OrgSetting @@unique([orgId, key])`.
- **Live-hold uniqueness (the D12 race closure):** Prisma cannot express partial unique indexes, so these are raw SQL *inside migrations*: `Reservation_apartment_live_hold_uq` / `Reservation_opportunity_live_hold_uq` (`WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')`, migration `20261102000000_phase2_d12_live_hold_unique/migration.sql:30-36`) and `Offer_apartment_live_hold_uq` / `Offer_opportunity_live_hold_uq` (`WHERE status IN ('ACTIVE','CONFIRMED') [AND apartmentId IS NOT NULL]`, migration `20261105180000_p1_offer_option/migration.sql:58-64`). All four exist in the live DB and in the fresh-DB rebuild (evidence 02). `prisma/live-hold-indexes.sql` is the idempotent `IF NOT EXISTS` companion that `bun run db:push` re-applies after `prisma db push` converges `schema.prisma` (which does not contain the partials — a bare `prisma db push` would strip them; house law: deployment is `migrate deploy` only).
- **P1/P2 additions reviewed:** `Offer` (negotiable proposal + provisional unit hold, 4 read-path indexes + 2 live-hold partials), `LeadCaptureToken` (public capture), `RevokedSession` (exact-cookie revocation exception list + `User.sessionsRevokedAt` watermark), `LoginFailure` (DB-backed sliding-window rate limiting, composite `[email, at]` index), `LeadTouch` (multi-touch attribution; `Lead.source` immutable by API contract).
- Index coverage is dense and query-annotated: org-scoped composites (e.g. `Opportunity [orgId, stage, closedAt]`, `Reservation [orgId, status, expiresAt]` + sweeper `[status, expiresAt]`, `Task [orgId, status, dueAt]`, `AuditLog [orgId, entity, entityId]`…). Live DB: 36 tables, 102 indexes (36 implicit PK/unique-auto), 23 explicit `CREATE UNIQUE` indexes, 0 triggers, 0 views.

**Schema-level gaps noted (assessed, not blocking):**
- Money as `Float` → SQLite `REAL` (schema lines 474, 710-711, 732-743, 810, 1037, 1058, 1130). Prisma `Decimal` is unsupported on SQLite; the PG variant deliberately keeps `DOUBLE PRECISION` with Float→Decimal explicitly gated on an owner decision (`prisma/schema.postgres.prisma:14`). Mitigations in-app: `MONEY_EPSILON` balance math and server-guarded `payment.amount ≤ installment remaining` (payments planner). → finding A2-F06 (Low).
- Status vocabularies are `String` + app-side validation (ADR-001, SQLite has no enums) — accepted platform trade-off, consistently applied.
- No native FK-level multi-tenant isolation (RLS is PG-only) — org scoping is enforced at the query layer (`orgId` first key of nearly every index; visibility module); documented for the PG port.

**Verdict: Implemented · Integrated · Runtime verified** (schema ↔ DB verified object-by-object; see §6).

---

## 4. Migration chain — exact reconciliation (25 = 25)

`ls -1d prisma/migrations/*/ | wc -l` → **25**. `SELECT migration_name, finished_at, applied_steps_count, rolled_back_at FROM _prisma_migrations ORDER BY migration_name` → **25 rows, every row `finished_at` set, `applied_steps_count=1`, `rolled_back_at=NULL`** (no failed, no rolled-back, no partial applications). Programmatic folder↔row diff: `in DB but NOT in folders: []`, `in folders but NOT in DB: []`, `exact 1:1 ordered match: true`. Per-migration `sha256(migration.sql)` vs the applied `checksum` column: **0 mismatches of 25** — the chain on disk is byte-identical to what was applied. `bunx prisma migrate status` → "25 migrations found in prisma/migrations" + "Database schema is up to date!" (corroborates the Principal's baseline verbatim).

| # | Migration (folder = DB row, checksum-verified) | finished_at (epoch ms) | rolled_back |
|---|---|---|---|
| 1 | 0_init | 1793989816138 | null |
| 2 | 20261003020538_p4_composite_indexes | 1793989816140 | null |
| 3 | 20261007120000_p8_9_schema_catchup_stage_changed_at | 1793989816143 | null |
| 4 | 20261007234744_p11_stage_wip_limit | 1793989816144 | null |
| 5 | 20261008022052_p13_finance_installments | 1793989816144 | null |
| 6 | 20261008154438_p14_sav_cases | 1793989816147 | null |
| 7 | 20261008231000_p16_remove_sav | 1793989816149 | null |
| 8 | 20261009050000_p18_crm_premium_operating_model | 1793989816153 | null |
| 9 | 20261009080000_p20_visit_decision_lifecycle | 1793989816155 | null |
| 10 | 20261011090000_p29_commercial_trust | 1793989816163 | null |
| 11 | 20261011150302_p30_duplicate_management | 1793989816164 | null |
| 12 | 20261019174640_p54_two_step_closure | 1793989816167 | null |
| 13 | 20261027140445_phase_c_visit_report | 1793989816172 | null |
| 14 | 20261031101714_pd_finance_sav_targets | 1793989816183 | null |
| 15 | 20261101184000_master_w18_incentive_index | 1793989816184 | null |
| 16 | 20261101224756_arabic_aliases | 1793989816208 | null |
| 17 | 20261102000000_phase2_d12_live_hold_unique | 1793989816209 | null |
| 18 | 20261102150000_phase21_lead_converted_at | 1793989816211 | null |
| 19 | 20261104010000_g5_hot_query_indexes | 1793989816211 | null |
| 20 | 20261104020000_g5_loss_reason_code | 1793989816212 | null |
| 21 | 20261105180000_p1_offer_option | 1793989816213 | null |
| 22 | 20261105190000_p1_lead_score | 1793989816215 | null |
| 23 | 20261105200000_p1_capture_token | 1793989816216 | null |
| 24 | 20261106030000_p2_session_governance | 1793989816217 | null |
| 25 | 20261106040000_p2_lead_touch | 1793989816218 | null |

The historical "18 folders vs 19 expected" discrepancy is confirmed superseded: the P0-6 governance report's own status line read 18 at its time; the chain has since grown to 25 with no gaps (`20261105*` P1 pair, `20261106*` P2 pair appended cleanly). The health endpoint's `migrations` value = 25 — verified BOTH directly against `_prisma_migrations` (25 rows) AND via the live HTTP probe once the dev server came up (see below): `GET /api/health` → `{"status":"ok","dbOk":true,"dbLatencyMs":1,"migrations":25,"demoMode":true,"demoModeMisconfigured":false,"sessionSecretConfigured":true,…}` (its route computes `COUNT(*) FROM _prisma_migrations`, `src/app/api/health/route.ts:42`).

**Server availability note (honest timeline):** at ~18:53 UTC the endpoint was UNREACHABLE (`curl` exit 7, no :3000 listener, no `next` process — a discrepancy with the mission briefing). At ~18:59–19:00 an external actor (not P4-A2 — I never started/stopped it) booted `next dev -p 3000`; the probe at 19:05 succeeded and matches the Principal's baseline exactly.

**Verdict: Implemented · Integrated · Runtime verified.**

---

## 5. Reproducibility test — virgin DB rebuild

```
$ rm -f /tmp/p4-a2-fresh.db
$ DATABASE_URL="file:/tmp/p4-a2-fresh.db" bunx prisma migrate deploy
SQLite database p4-a2-fresh.db created at file:/tmp/p4-a2-fresh.db
25 migrations found in prisma/migrations
Applying migration `0_init` … Applying migration `20261106040000_p2_lead_touch`
All migrations have been successfully applied.
```
(Full first-run log with all 25 "Applying" lines: `evidence/a2/02b-fresh-deploy-full.log`; a SECOND virgin DB `/tmp/p4-a2-fresh2.db` reproduced the same result — 138 objects, 0 drift.)

`sqlite_master` comparison, live `db/custom.db` vs `/tmp/p4-a2-fresh.db` (both opened readonly):

```
live objects: 138 | fresh objects: 138
objects ONLY in live DB: []
objects ONLY in fresh DB: []
sql text drift count: 0            ← every CREATE TABLE/INDEX DDL string byte-identical
fresh _prisma_migrations rows: 25 | live: 25
tables identical: true | count: 36
data rows User: live=8 fresh=0 …   ← differences are DATA only, as expected
```

**The critical reproducibility question is closed:** the live-hold partial unique indexes live INSIDE the migration chain (`20261102000000_phase2_d12_live_hold_unique` + `20261105180000_p1_offer_option`), so `migrate deploy` ALONE reproduces them — all 4 partials exist in the fresh DB (evidence 02). `prisma/live-hold-indexes.sql` is NOT a hidden out-of-migration step for deployment; it exists only to re-arm the indexes after the `db:push` PROTOTYPING path (package.json:15 wires it), because `schema.prisma` cannot express partials. No schema drift of any kind between a chain-only rebuild and the live database.

**Verdict: Tested · Runtime verified — reproducibility PERFECT (schema-identical).**

---

## 6. Index verification (live DB)

- 102 indexes total (36 implicit), incl. 23 explicit `CREATE UNIQUE INDEX` (4 of them the live-hold partials).
- All four live-hold partials present with correct predicates (verbatim `sql` captured in evidence 02):
  - `Reservation_apartment_live_hold_uq ON Reservation(apartmentId) WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')`
  - `Reservation_opportunity_live_hold_uq ON Reservation(opportunityId) WHERE status IN ('ACTIVE','CLOSURE_REQUESTED')`
  - `Offer_apartment_live_hold_uq ON Offer(apartmentId) WHERE status IN ('ACTIVE','CONFIRMED') AND apartmentId IS NOT NULL`
  - `Offer_opportunity_live_hold_uq ON Offer(opportunityId) WHERE status IN ('ACTIVE','CONFIRMED')`
- Behavioral corroboration on live data: zero violations of either live-hold invariant (probes over `Reservation`/`Offer` grouped by apartmentId with `HAVING n>1` returned 0 rows); Reservation statuses: 7 CONVERTED + 1 ACTIVE; Offer: 1 DRAFT / 1 ACTIVE / 1 CONVERTED — the ACTIVE reservation and ACTIVE offer hold different units, consistent with `Apartment` statuses (1 RESERVED, 1 OPTIONED, 35 AVAILABLE, 7 SOLD, 1 OFF_MARKET, 1 BLOCKED).

**Verdict: Implemented · Runtime verified.**

---

## 7. SQLite runtime posture

| Setting | Raw tool connection (bun:sqlite, fresh) | **Live Prisma connection (the app runtime)** |
|---|---|---|
| `journal_mode` | `delete` | **`delete`** |
| `busy_timeout` | 0 (tool default — irrelevant to the app) | **5000 ms** (engine-applied, every physical connection) |
| `foreign_keys` | 0 (SQLite default — raw tools don't enable it) | **1 (ON)** |
| `page_size` | 4096 | 4096 |
| `synchronous` | 2 (FULL) | — |
| engine SQLite | bun:sqlite 3.53.0 (tooling only) | **3.46.0** (the app runtime) |

(The Prisma-connection facts were read through the app's own engine via SELECT/PRAGMA only — evidence 03; they re-confirm P0-2's Step D claims exactly: busy_timeout 5000, foreign_keys ON, journal delete.)

**WAL-blocked assessment — the rationale STILL HOLDS, re-verified end-to-end this session:**
- The application runtime SQLite is **3.46.0** (queried through the live Prisma connection, not assumed) — inside the documented WAL-reset bug range 3.7.0–3.51.2. Installed Prisma is `@prisma/client` 6.19.2 (bun.lock; P0-2's probe of 6.19.3 found the identical bundled 3.46.0 — no in-scope upgrade within Prisma 6; Prisma 7 is an architectural migration, correctly deferred).
- No `-wal`/`-shm`/`-journal` sidecars exist; `journal_mode=delete` is stable (P0-2 T4: `delete → delete` across client reopen).
- **Is delete-journal + busy_timeout 5000 safe for this single-instance app?** Yes, as documented: one Next.js process, one Prisma pool, local filesystem (not NFS — WAL-compatible storage if ever enabled). Delete-journal serializes writers and blocks readers only for the duration of an active write transaction; with the engine-level 5000 ms busy-timeout absorbing contention (P0-2's T1: 10 concurrent readers during a 600 ms held lock — all succeeded; T2: competing writers waited out the lock, no `SQLITE_BUSY`), and every financial mutation being a short single `$transaction` (§8), the posture is sound for the current deployment shape. The trade-off (no reader/writer concurrency during writes, no snapshot isolation across connections) is accepted and documented; the future trigger (Prisma 7 driver-adapter SQLite) remains the right unlock.
- Note for operators: raw ad-hoc tool connections (bun:sqlite/node:sqlite defaults) get busy_timeout=0 and foreign_keys=OFF — the sanctioned tooling sets its own posture (backup engine: read-only + busy_timeout 30000 on every connection, `scripts/lib/backup-engine.mjs:93-96`); the app itself is fully covered by the engine.

**Verdict: Implemented · Runtime verified** (WAL enablement remains **Blocked by design — evidence still valid**).

---

## 8. Transaction boundaries

62 `$transaction(` sites across `src/` (grep evidence). The financial paths were read line-by-line:

| Path | Transaction shape | Audit/trail inside the SAME tx? |
|---|---|---|
| `src/lib/services/payments.ts:139` recordPayment | re-read of committed payments INSIDE tx → `payment.create` → `installment.update` (status stamp on full coverage) → **`injectTxFault(req,"payments-post")`** → `logAudit(PAYMENT_RECORDED)` + `logActivity` | **YES** (fault hook deliberately sits between money writes and trail writes) |
| `src/lib/services/installments.ts:194` createInstallment | seq claim (`findFirst orderBy seq desc`) → `create` → fault hook → `logAudit(INSTALLMENT_CREATED)`; P2002→409 SEQ_CONFLICT | **YES** |
| `src/lib/services/installments.ts:383` updateInstallment | planner guards → update → audit (INSTALLMENT_UPDATED/CALLED/CANCELLED) | **YES** |
| `src/lib/services/reservations.ts:669` createReservation | shared `bookUnitInTx` (guards + hold + apartment flip) → `logActivity(RESERVATION)` + `logAudit(APARTMENT_RESERVED)`; P2002 (live-hold index) → 409 ALREADY_RESERVED | **YES** |
| `src/lib/server/reservation-economics.ts:127` | `reservation.update` (commission/incentive) → fault hook → per-event `logAudit(COMMISSION_SET/REBASE, INCENTIVE_*)` | **YES** |
| `src/lib/server/offer-lifecycle.ts:347,508,675,753,810,907` (draft/patch/confirm/cancel/expire/**convert**) | convert = booking core + status-preconditioned claim (`updateMany where status=CONFIRMED` → 0 rows = safe 409) + `convertedReservationId` link + OFFER_CONVERTED & APARTMENT_RESERVED audits + activities — ONE commit | **YES** |

Corroboration: `tests/security/fault-injection.test.ts` ("every fold site rolls back atomically") asserts the money row AND its audit row are BOTH zero after an injected mid-transaction failure (e.g. lines 223-226: `installment.count(fault-line)==0` AND `auditLog.count(INSTALLMENT_CREATED … fault-line)==0`), and P0-2's T3 probe proved full atomic rollback of a payment+installment+auditLog transaction under a forced failure. **No committed money without its trail is structurally enforced.**

**Verdict: Implemented · Integrated · Tested** (fault-injection suite) · code Runtime-verified this session by read.

---

## 9. Backup & recovery assessment (with FRESH drill evidence)

**Toolchain review** (`scripts/backup.sh` → `scripts/lib/backup-run.mjs` + `backup-logic.mts` + `backup-engine.mjs`; `scripts/restore.sh` → `restore-run.mjs`):
- **Snapshot = `VACUUM INTO`** on a READ-ONLY source connection with busy_timeout 30000 (`backup-engine.mjs:93-104`) — page-consistent by construction, can never capture journal sidecars, never a live file-copy. Correct and best-practice for a journal-mode SQLite.
- **Verification ON THE SNAPSHOT**: `PRAGMA integrity_check` must answer exactly `ok` or the run fails (exit 1, "a backup without verified integrity is a failure"); census of 6 canonical tables recorded.
- **Manifest**: runId, ts, integrity verdict, census, per-artifact sha256+bytes (db snapshot + docs tarball), keep. Strict self-validation (`validateManifest`) incl. tamper shapes; restore re-verifies artifact hashes, demands byte-identical restored copy, re-runs integrity + census match. Vitest-covered (67 tests per P1 report).
- **Retention**: keep-N (default 14, env `ASAS_BACKUP_KEEP`), 1-hour age floor, only `backup-*` dirs managed, unknown-mtime = never delete. Applied during my run: `retention kept=1 deleted=0`.
- **Restore interlock**: drill mode NEVER touches the live DB (writes only under `db/restore-drills/`); live mode requires BOTH `--confirm-restore` AND the typed `--i-understand-this-overwrites-the-live-db` (strict parsing — misspelling = unknown flag = refusal, exit 2); live path takes a VACUUM INTO safety snapshot of the current DB first, then atomic `rename()` over `db/custom.db`, replaces `db/docs/`, re-verifies integrity+census, and instructs a server restart (old inode held open by the running process). Sound design.

**FRESH backup (this session, verbatim):**
```
[backup] engine=node:sqlite (Node built-in)     ← sqlite3 CLI absent; engine logged, never silent
[backup] snapshotting db/custom.db → db/backups/backup-20261106T185536Z/db-20261106T185536Z.sqlite (VACUUM INTO, read-only source connection)
[backup] snapshot  … — 1064960 bytes, sha256 6be978d5c43dda32…
[backup] integrity ok — PRAGMA integrity_check run ON THE SNAPSHOT
[backup] census    users=8 leads=43 opportunities=21 reservations=8 apartments=46 documents=0
[backup] BACKUP OK → db/backups/backup-20261106T185536Z
```

**FRESH restore drill (this session, verbatim key lines):**
```
[restore:drill] artifacts verified — sha256 + size match the manifest (db-20261106T185536Z.sqlite, docs-20261106T185536Z.tar.gz)
[restore:drill] restored db/restore-drills/20261106T185544Z/custom.db (byte-identical to the snapshot, sha256 6be978d5c43dda32…)
[restore:drill] integrity ok — PRAGMA integrity_check on the RESTORED copy
[restore:drill] census   users=8 leads=43 opportunities=21 reservations=8 apartments=46 documents=0 — MATCHES MANIFEST (…)
[restore:drill] original db/custom.db — NOT TOUCHED (drill mode writes only under db/restore-drills/)
[restore:drill] PASS — drill restore verified end-to-end; live DB untouched
```
Live-DB-untouched proof: `db/custom.db` size 1,097,728 / mtime 2026-11-06 18:54:08 / sha256 `bb0d44e3…` — unchanged before, during and after both operations (mtime predates the backup 18:55:36 and drill 18:55:44).

**Adequacy / RPO-RTO:**
- **RTO: minutes.** Live restore = safety VACUUM INTO (~1 s for 1.1 MB) + verified copy + atomic rename + docs extract + verify + dev-server restart. Drill-verified path, interlocked, artifact-hash-checked.
- **RPO: unbounded by default.** Nothing schedules `db:backup` (no cron entries, no systemd timer, no CI step, no in-app scheduler — verified). At audit start **`db/backups/` did not exist in this workspace** (zero backup history; the P1-era backups/drills cited in docs are from prior workspace states). Backups are also co-located on the same filesystem as the DB (`db/backups/` inside the repo tree, git-ignored via `/db/`) — a single-disk failure takes DB AND backups together. → findings A2-F01/A2-F04.

**Verdict: Backup+restore machinery: Implemented · Integrated · Runtime verified (fresh drill PASS this session). Cadence/automation & offsite: Not implemented (A2-F04). Bootstrap on clean workspace: BROKEN (A2-F01).**

---

## 10. Data integrity results + census

```
PRAGMA integrity_check    → ok
PRAGMA quick_check        → ok
PRAGMA foreign_key_check  → 0 rows (no FK violations / no orphaned rows anywhere)
```

**Concurrent-writer observation (full transparency):** after my read-only passes, at 19:03 the live DB file changed externally (size 1,097,728 → 1,101,824, sha256 `bb0d44e3…` → `f5aabd3e…`) — timeline analysis attributes this to the dev server an external actor booted at ~18:59–19:00, NOT to any P4-A2 operation (all my connections were `readonly`; the sanctioned backup/drill tools write only NEW files; my hash chain proves the file was byte-stable through all of my operations 18:54–18:59). Post-change re-verification: census of all 36 tables UNCHANGED, `sqlite_master` re-diff vs the fresh DB still 138/138 objects with 0 SQL drift, `_prisma_migrations` still 25/25 finished, `integrity_check` ok, `journal_mode` still delete. Evidence 07.

Census (live `db/custom.db`, all 36 tables) vs claims:

| Table | Live count | Claimed (mission/P1 docs) | Match |
|---|---|---|---|
| User | **8** | 8 | ✅ |
| Lead | **43** | 43 | ✅ |
| Opportunity | **21** | 21 | ✅ |
| Reservation | **8** | 8 | ✅ |
| Apartment | **46** | 46 | ✅ |
| Document | **0** | 0 | ✅ |
| Payment | 8 | "(+ payments…)" unnumbered | — |
| Installment | 14 | "(+ installments…)" unnumbered | — |
| SavCase | 7 | "(+ sav…)" unnumbered | — |
| SalesTarget | 3 | "(+ targets…)" unnumbered | — |
| Offer | 3 | — | — |
| AuditLog | 186 | — | — |
| Activity | 187 | — | — |
| Task 18 · Visit 24 · VisitApartment 43 · Contact 20 · Requirement 14 · PropertyMatch 3 · LeadTag 26 · Tag 7 · PipelineStage 10 · Building 6 · Project 4 · Developer 3 · ProjectAssignment 3 · LeadTouch 3 · RevokedSession 2 · LoginFailure 11 | | | |
| LeadCaptureToken 0 · LeadDuplicateDismissal 0 · SavedSearch 0 · OrgSetting 0 · Organization 1 · Pipeline 1 · _prisma_migrations 25 | | | |

The six explicitly claimed seed values match **exactly** (and the backup manifest's independent census of the VACUUM INTO snapshot agrees, proving the snapshot sees the same data). `LeadCaptureToken=0` is expected (public capture tokens are runtime-created, not seeded). No orphaned rows (foreign_key_check clean); single org (`Organization=1`, all 8 users on it — demo-mode tenant).

**Verdict: Runtime verified — integrity CLEAN, census MATCHES claims.**

---

## 11. Data-loss risk register

| ID | Risk | Exposure | Mitigation present | Status |
|---|---|---|---|---|
| R1 | WAL blocked (delete journal) — writer blocks readers during active tx | Low (single process, short txs, engine busy_timeout 5000) | documented P0-2 rationale (still valid — runtime 3.46.0 re-verified in bug range) | Accepted/documented |
| R2 | Single-file DB on local FS; backups co-located on same disk | **High if disk lost** | manual VACUUM INTO backups; NO offsite copy, NO schedule | OPEN (A2-F04) |
| R3 | No automated backup cadence (manual-only; zero backups existed at audit start) | RPO = unbounded between operator actions | self-verifying artifacts would make automation trivial | OPEN (A2-F04) |
| R4 | First-run backup bootstrap failure (`db/backups/` parent missing) | Backup system cannot produce its FIRST backup on a clean workspace | none — reproduced this session (exit 1 ENOENT) | OPEN (A2-F01) |
| R5 | Legacy `db:snapshot` file-copy (`cp` of live DB) contradicts the VACUUM-INTO-only law | Torn-page snapshot that "looks fine until opened" | npm alias still exposed (package.json:23) | OPEN (A2-F03) |
| R6 | Retention apply gate permanently closed (`Date.parse` bug) | Fail-closed; LoginFailure/diagnostic rows grow unbounded (currently 11 rows — negligible) | none (bug) | OPEN (A2-F02) |
| R7 | Upload documents storage (`db/docs/`) | Currently EMPTY (documents=0); files outside DB are covered by the docs tarball in every backup; restore replaces the tree | backup/restore cover db/docs; magic-byte verification at upload (P1) | Covered |
| R8 | Migration drift / unreproducible schema | None found — 25/25 checksum-identical; virgin rebuild schema-identical incl. live-hold partials | CI database-gates (local-proven) + house law deploy-only | CLOSED (verified) |
| R9 | Float money representation | Theoretical rounding at extremes; DZD-scale values + MONEY_EPSILON + guarded sums | owner-gated decision documented for PG port | Accepted/documented (A2-F06) |

---

## 12. Findings

| ID | Severity | Finding | Evidence | Impact | Recommendation |
|---|---|---|---|---|---|
| **A2-F01** | **Medium** | **Backup cannot bootstrap on a clean workspace**: `scripts/backup.sh` mkdirs `db/docs` (line 31) but never `db/backups`; `scripts/lib/backup-run.mjs:55` uses `mkdir(backupDir, { recursive: false })` (leaf only) → first-ever `bun run db:backup` fails `ENOENT … mkdir '…/db/backups/backup-…'` exit 1. Reproduced LIVE this session (workspace had no `db/backups/`). | evidence 05 §5.1 | The recovery posture is broken exactly when zero backups exist — the worst possible data-loss window; any fresh clone/reset silently has NO backup capability until someone debugs it. | Add `mkdir -p db/backups` to `scripts/backup.sh` (or `mkdir(backupsRoot, {recursive:true})` before the leaf mkdir in the runner). One-line fix. |
| **A2-F02** | **Medium** | **Retention apply gate permanently closed**: `src/lib/server/retention.ts:168` does `Date.parse(manifest.ts)` on the backup stamp `YYYYMMDDTHHMMSSZ` (`backup-logic.mts:36 STAMP_RE`) — `Date.parse("20261106T185536Z") = NaN` (proof in evidence 06) → `findFreshBackup` never matches any manifest → `applyGuard.freshBackupFound=false` **even 3 minutes after a fresh backup** (live dry-run output) → `retentionApply` can never be authorized. | evidence 06 | Fail-closed (safe direction), but the sanctioned purge machinery is dead code at runtime, and its breakage is masked because the dry-run itself works. Diagnostic rows (LoginFailure etc.) grow unbounded. | Parse the stamp with a regex → `Date.UTC(y,m,d,H,M,S)` (or add an ISO `generatedAt` to the manifest and parse that). Add a unit test asserting `findFreshBackup` matches a just-written manifest. |
| **A2-F03** | **Medium** | **Legacy `db:snapshot` script violates the consistency law**: `package.json:23` — `cp db/custom.db "db/backups/custom-<ts>.db"` is a live byte-copy of a journal-active database, the exact torn-page hazard the backup system's own documentation forbids ("NEVER a live file-copy", `backup-run.mjs:59-71`). Still exposed as an npm alias. | package.json:23 vs scripts/lib/backup-run.mjs:59-71 | An operator reaching for the older, shorter command produces silently-inconsistent snapshot files that pass a quick `ls` and fail on open; retention also (deliberately) never cleans `custom-*.db` files, so they accumulate looking authoritative. | Remove the `db:snapshot` script or reimplement it as `VACUUM INTO` (the backup engine already exposes `vacuumInto`). |
| **A2-F04** | **Medium** | **No scheduled/automated backup cadence and no offsite copy**: no crontab entries, no systemd timer, no CI backup step, no in-app scheduler invokes `db:backup`; backups live under `db/backups/` on the same disk as the DB. At audit start the workspace had **zero** backups. | `crontab -l` (empty), `.github/workflows/ci.yml` (no backup step), `ls db/backups/` (absent pre-audit) | RPO is whatever the last manual run was — with no schedule and no offsite target, a disk failure loses DB + backups together. RTO is fine; RPO is the gap. | Schedule `bun run db:backup` (cron/systemd timer or a supervised loop) + copy the newest backup-<ts>/ directory off-host (artifacts are self-verifying: integrity verdict + sha256 + census in every manifest, so automation can trust-but-verify). |
| **A2-F05** | **Low** | **CI trigger branch filter mangled**: `.github/workflows/ci.yml` `on.push.branches` / `on.pull_request.branches` read `ain]` (looks like a corrupted `main]`) — the database-gates job (fresh `migrate deploy` + seed + validator) would never fire on real pushes. Caveat: the workflow itself declares remote execution NOT YET VERIFIED (repo has **0 git remotes** — verified). | `.github/workflows/ci.yml:19-21`; `git remote -v` → empty | The migration-chain gate that CI is supposed to enforce is not protecting anything in practice; local runs are proven but manual. | Repair the branch filter (`main`), and once a remote exists, verify one green remote run of the database-gates job. |
| **A2-F06** | **Low** | **Money stored as Float/REAL**: all DZD amounts are `Float` in SQLite (e.g. schema lines 474, 710-711, 810, 1037, 1058). Platform limit (Prisma Decimal unsupported on SQLite); PG variant deliberately keeps DOUBLE PRECISION with Float→Decimal gated on an explicit owner decision (`prisma/schema.postgres.prisma:13-14`). Mitigated in-app by `MONEY_EPSILON` balance math + server-guarded amounts. | schema + payments.ts planner | Theoretical rounding drift at extreme magnitudes; current DZD-scale values and epsilon-guarded sums make practical risk negligible. Audit trail records amounts as JSON — consistent. | Keep the owner gate visible in the risk register; when PostgreSQL lands, treat Integer-cents/Decimal as a deliberate financial-semantics migration, not a silent retype. |
| **A2-F07** | **Info** | **Declared vs installed Prisma drift**: `package.json` declares `^6.11.1`; installed runtime is `@prisma/client` 6.19.2 (bun.lock; `node_modules/@prisma/client/package.json`). The mission briefing's "Prisma 6.11.1" is not the runtime truth (P0-2 correctly reported 6.19.2). | evidence 03 | None functionally (semver-compatible; the WAL-block analysis is anchored to the installed 6.19.2 engine = SQLite 3.46.0, which I re-verified live). | Pin the dependency (e.g. `6.19.2` exact) so ops/recovery docs cite the true engine. |
| **A2-F08** | **Info** | **`db:restore:drill` double-positional gotcha**: the npm script already appends `$(ls -td db/backups/backup-* | head -1)`; passing a backupDir explicitly (as suggested in some runbooks) double-passes the positional and the strict interlock REFUSES (exit 2, "expected exactly one <backupDir>, got 2") — correct safety behavior, surprising UX. Verified live this session. | evidence 05 note | Minor operator confusion; no safety impact (the interlock is doing its job). | Either document "run it bare" in the runbook, or make the npm script tolerate an injected argument (pass through only when the caller supplies one). |
| A2-P01 | Positive (verified) | Migration chain 25/25 exact 1:1, all checksums match, no failed/rolled-back rows; `migrate status` clean. | §4, evidence 01 | — | — |
| A2-P02 | Positive (verified) | Virgin-DB `migrate deploy` reproduces a schema-IDENTICAL database (138 objects, 0 SQL drift) including all 4 live-hold partial unique indexes — the indexes live INSIDE the migration chain; `live-hold-indexes.sql` is only the `db:push` re-arm companion. | §5-6, evidence 02 | — | — |
| A2-P03 | Positive (verified) | Fresh backup + restore drill PASS with the live DB untouched (sha256-verified). | §9, evidence 05 | — | — |

---

## 13. Status summary (vocabulary per mandate)

| Area | Status |
|---|---|
| Active engine (SQLite-only, PG dormant) | Implemented · Integrated · Runtime verified |
| Schema (35 models, constraints, indexes) | Implemented · Integrated · Runtime verified |
| Migration chain (25, 1:1, checksum-identical) | Implemented · Integrated · Runtime verified |
| Reproducibility (virgin-DB rebuild) | Tested · Runtime verified |
| Live-hold partial unique indexes | Implemented · Runtime verified (in-chain + in-DB + in-fresh-DB) |
| Runtime posture (delete journal + busy_timeout 5000 + FK ON) | Runtime verified; WAL enablement **Blocked (by design, evidence re-validated)** |
| Transaction boundaries (money + audit atomic) | Implemented · Integrated · Tested (fault-injection) · code-verified |
| Backup toolchain (VACUUM INTO + manifest + verification) | Implemented · Integrated · Runtime verified (fresh PASS) — bootstrap bug A2-F01 |
| Restore toolchain (interlocked drill/live) | Implemented · Integrated · Runtime verified (drill PASS) |
| Backup cadence / offsite | **Not implemented** (A2-F04) |
| Retention apply machinery | **Partial** — dry-run works; apply gate permanently closed by bug (A2-F02, fail-closed) |
| Data integrity (integrity/quick/FK checks) | Runtime verified — CLEAN |
| Seed census vs claims | Runtime verified — exact match |

---

## 14. Honest NOT VERIFIED / BLOCKED list

1. **`GET /api/health` live HTTP probe — RESOLVED mid-audit (initially NOT VERIFIED).** At ~18:53 UTC the endpoint was unreachable (exit 7, no :3000 listener, no next process — contradicting the briefing). At ~18:59–19:00 the dev server was booted by an external actor (P4-A2 never started/stopped it, per the absolute rules); the 19:05 probe returned `{"status":"ok","dbOk":true,"dbLatencyMs":1,"migrations":25,"demoMode":true,…}` — matching the Principal's baseline and my direct DB verification (25 rows in `_prisma_migrations`). Evidence 07.
2. **Full test suite (772/772)** — not re-run (out of read-only mandate; uses test stubs/isolated DBs anyway). Principal's baseline accepted.
3. **Live contention probes (P0-2 T1/T2/T3)** — historical evidence accepted (same engine family re-verified: installed client 6.19.2, SQLite 3.46.0, busy_timeout 5000 read back live); the probes themselves were not re-executed this session.
4. **Remote CI execution** — not verifiable: the repository has zero git remotes (`git remote -v` empty); the workflow file itself declares remote runs NOT YET VERIFIED. Local equivalents of its database-gates were re-proven (virgin `migrate deploy`, §5).
5. **Supabase/PostgreSQL dormant path parity** (`supabase/` SQL chain, `schema.postgres.prisma`, RLS policies) — dormant by design; not applied/exercised anywhere in the active stack; parity not audited (out of scope for the active-engine audit).
6. **`retention:apply` destructive path** — deliberately NOT executed (mandate); its gate behavior is deduced from the verified `findFreshBackup` bug + dry-run applyGuard output (fail-closed).
7. **Live-restore path** (`--confirm-restore --i-understand-this-overwrites-the-live-db`) — deliberately NOT executed against the live DB (would violate the read-only mandate); assessed by code read + drill + interlock refusal test (double-positional refusal observed live).
8. **Migration authoring discipline** ("migrate dev only on scratch DBs" house law) — a process claim; cannot be verified retroactively from artifacts. The applied chain itself is checksum-verified against the on-disk files.

---

## 15. Files created by this audit (and only these)

- `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/ASAS_PHASE4_DATABASE_AND_RECOVERY_AUDIT.md` — this deliverable (the ONE report file).
- `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/evidence/a2/01-migration-chain.txt`, `02-reproducibility.txt`, `02b-fresh-deploy-full.log`, `03-runtime-posture.txt`, `04-integrity-census.txt`, `05-backup-restore-drill.txt`, `06-retention-dryrun.txt`, `07-health-and-concurrent-writer.txt`, `prisma_facts.mjs` — raw evidence (all read-only captures; `prisma_facts.mjs` issues only SELECT/PRAGMA).
- `db/backups/backup-20261106T185536Z/` + `backup-20261106T185910Z/` — NEW backup artifacts produced by the sanctioned `bun run db:backup` (non-destructive: VACUUM INTO reads the live DB read-only; the live file is never written by the tool).
- `db/restore-drills/20261106T185544Z/` — drill output of the sanctioned `bun run db:restore:drill` (writes only under `db/restore-drills/`).
- `/tmp/p4-a2-fresh.db`, `/tmp/p4-a2-fresh2.db`, `/tmp/p4a2/*.mjs` — disposable reproducibility databases + helper scripts.

**No existing file was modified.** `db/backups/` and `db/restore-drills/` are git-ignored via the `/db/` rule in `.gitignore`, so the working tree shows only the new untracked `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/` documentation.

```
$ git -C /home/z/my-project status --short
?? 05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/
```

— END OF REPORT —
