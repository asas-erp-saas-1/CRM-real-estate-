# ASAS CRM — Phase 4 Security, Authorization & Privacy Audit

**Auditor:** AGENT 3 (Task ID: P4-A3) — Security, Authorization & Privacy Auditor
**Date:** 2026-11-06
**Mode:** READ-ONLY production-readiness audit. Code review + safe live probes (GET/HEAD + logins + rejected-writes only). Zero source modifications, zero DB writes (all DB access via `node:sqlite` `readOnly:true`).
**Repo:** /home/z/my-project — Next.js 16.1.3 (App Router), React 19, TS 5, Bun 1.3.14, Prisma 6.11.1 + SQLite `db/custom.db` (ACTIVE engine; Supabase/PostgreSQL dormant — see §8.4).
**Evidence:** `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/evidence/a3/` (probe scripts, probe logs 1–3, response bodies, ghost-404 MD5s, DB state snapshot).
**Status vocabulary:** PASS / PARTIAL / FAIL / NOT VERIFIED, enforced throughout.

---

## 1. Executive verdict

The authentication, authorization and privacy posture of ASAS CRM is **strong for its documented single-organization, single-instance deployment model**. The session mechanism (HMAC-SHA256 signed cookie, constant-time compare, absolute 7-day expiry, DB-backed exact-pair + watermark revocation), the boot fail-fast gates, and the record-visibility model in `src/lib/server/visibility.ts` are consistently implemented at the server layer and verified both by genuinely adversarial test suites (which I read line-by-line, not just trusted) and by 60+ live probes executed in this audit. The residual risk concentrates in **deployment footguns** (a demo seed carrying a publicly-known password can be applied to a production DB through `bun run db:deploy`), **honest single-instance limitations** (process-local rate limiting), and **two low-severity carry-forward quirks** (money-cap asymmetry, booking audit semantics) — none of which constitute a remotely exploitable privilege-escalation path today.

## 2. Methodology

1. **Code review (zero trust).** Full reads of: `session.ts`, `auth.ts`, `boot.ts`, `instrumentation.ts`, `demo-org.ts`, `visibility.ts`, `lead-capture.ts`, `documents.ts`, `file-verification.ts`, `logger.ts`, `audit.ts`, `proxy.ts`, all `/api/auth/**` routes, `metrics`, `audit`, `users`, `documents/[id]/file`, `public/lead-capture`, `[...path]` catch-all, `prisma/schema.prisma` (RevokedSession / LoginFailure / LeadCaptureToken models), `prisma/seed.ts`, `.env.example`, `package.json`.
2. **Test-suite verification.** Read `tests/security/**` (permission-matrix — 123 declarative MATRIX rows + 12 payload/ghost/transition its; session-governance — 13 its; demo-isolation — 5 its; document-security — 16 its; public-capture — 15 its; fault-injection — 35 its; offer-concurrency — 8 its; financial-atomicity — 5 its; attribution — 11 its; lead-score — 6 its) plus `tests/unit/{boot-env,session-cookie,demo-mode-gate,logger,file-verification}.test.ts` to establish **what the 772-test baseline actually asserts**. It asserts what the prior reports claim — the suites are genuinely adversarial (black-box against the live server, real Prisma fixtures, byte-identical-envelope comparisons, fault injection with `x-test-inject`).
3. **Live probes.** 60+ HTTP probes against `http://127.0.0.1:3000` (see §5 table + `evidence/a3/probe-log-{1,2,3}.txt`). Only GET/HEAD plus: login POSTs (credential + demo quick-login), ONE deliberate invalid-credentials POST (P03), one public-capture POST with a garbage token (P53, rejected by the server), and cross-origin login/logout POSTs that are rejected pre-auth (P61/P62 — CSRF negative probes). **No business data was created, modified or deleted.**
4. **DB reconnaissance.** Read-only `node:sqlite` queries to select probe targets (users, org, leads/opps/reservations per owner, ProjectAssignment rows). Verified `journal_mode=delete` (WAL still not enabled — P2 carry-forward).
5. **Log/bundle inspection.** `dev.log` (4,807 lines) grepped for secret leakage; client tree (`src/lib/client`, `src/components`) grepped for secret-bearing code.

**Environment deviation, disclosed honestly:** the documented dev server was found **DOWN** at 18:55Z (last `dev.log` entry 18:54:18; no `next` process; Caddy :81 → 502). I started `./node_modules/.bin/next dev -p 3000` myself (output redirected to `/tmp/p4a3-dev*.log` — **`dev.log` untouched**, no source files modified) and re-ran it per probe batch because the sandbox reaps background processes between tool sessions. All probes executed against this freshly started server on the unmodified DB.

---

## 3. Authentication & session analysis

### 3.1 Cookie mechanics (`src/lib/server/session.ts`)

| Property | Implementation | Verdict |
|---|---|---|
| Signing | `HMAC-SHA256(`${userId}.${issuedAtMs}`, ASAS_SESSION_SECRET)`; value `${userId}.${issuedAtMs}.${hmacHex}` | PASS (code, session.ts:47-51) |
| Constant-time compare | `timingSafeEqual` on equal-length buffers, strict format pre-checks (`/^\d{1,15}$/`, `/^[0-9a-f]{64}$/`) | PASS (session.ts:60-64) |
| Cookie flags | `httpOnly; SameSite=Lax; Path=/; Max-Age=604800` — **live-verified** in P01/P40 `Set-Cookie` (`evidence/a3/bodies/P01.hdr`); `secure` only when `NODE_ENV=production` (code, login/route.ts:40) | PASS (dev shows no `Secure`, correct for plain-HTTP sandbox) |
| Client/server expiry agreement | cookie `maxAge` 7d (seconds) == `SESSION_MAX_AGE_MS` 7d (ms); unit-tested (`session-cookie.test.ts`: "SESSION_MAX_AGE_MS is exactly 7 days") | PASS |
| Absolute expiry | `Date.now() - issuedAtMs > SESSION_MAX_AGE_MS` → null (session.ts:71) — a stolen-but-valid cookie dies at day 7 regardless of activity | PASS |
| Validation on every request | `getCurrentUser()` called by `requireUser()` in every authed route; absent/stale/forged/revoked → 401 `NO_SESSION` | PASS (live P50/P52 + matrix rows A) |
| Forged cookie | raw `userId`-style cookie → 401 `NO_SESSION` | PASS (live P04; matrix `auth/leads.post.forged-cookie`) |
| Tampered cookie | 1 flipped hex char in signature → 401 `NO_SESSION` | PASS (live P05 — executed against a real, otherwise-valid cookie) |
| Session response shape | `{id, orgId, name, email, role}` + self-scoped `{issuedAt, expiresAt}` — **no `passwordHash`**; login route strips hash before echoing | PASS (live P02: `user keys: id,orgId,name,email,role`) |

### 3.2 Revocation (P2/W2 layer)

- **Exact-pair revocation** (`RevokedSession` `@@unique([userId, issuedAtMs])`): logout writes the (userId, issuedAtMs) row; `getCurrentUser` piggybacks a filtered `revokedSessions` select on the user query (zero extra round-trip). A replayed logged-out cookie is dead. Verified by `session-governance.test.ts:71` ("a logged-out cookie no longer authenticates even when replayed verbatim") — **NOT re-probed live** (would require a logout POST on a real session; code + test coverage judged sufficient; the logout route read confirms the upsert).
- **Revoke-all watermark** (`User.sessionsRevokedAt`): self mode (any user) + ADMIN/OWNER force mode scoped to `orgId` (`sessions/revoke-all/route.ts:37-48`, foreign-org target → no-oracle 404). Audited as `SESSIONS_REVOKED` (mode SELF/ADMIN). Tests: session-governance:100,123,138,152.
- **Password-change invalidation** (`passwordChangedAt`, F-05): every cookie issued before a change/reset dies (`session.ts:126`); `change-password` bumps it and clears lockout state. Code-verified; tested in unit suite.
- **Idempotent logout** on stale sessions; sweeps inert revocation rows (>8d) on the write path.

### 3.3 Credential auth (`src/lib/server/auth.ts`)

- scrypt N=16384/r=8/p=1, 16-byte salt, 32-byte key, `timingSafeEqual` verification; serialization `scrypt:salt:hash`.
- Temp passwords via CSPRNG `randomInt` over an unambiguous alphabet (`Asas-XXXXXX`).
- **Login lockout:** DB-backed (`LoginFailure`, `@@index([email, at])`) sliding window — 5 failures / 15 min → 429 `ACCOUNT_LOCKED` with `retryAfterMs`; success clears; sweep of dead rows on the write path; **restart-survivable by design**. Quick-login respects the same lockout (F-03) — **accidentally verified live**: my first field-rep probe used Yacine's userId, whose account was still inside the test suite's residual lockout window, and got `429 ACCOUNT_LOCKED {"retryAfterMs":71374}` (P40, `evidence/a3/bodies/P40.body`) — an unplanned but genuine live confirmation of F-03.
- **No email-enumeration oracle (F-12):** unknown emails verify against a precomputed `DUMMY_HASH` so both 401 arms burn one scrypt run; envelope byte-identical (tested; live P03 shows the single envelope `{"error":"Email ou mot de passe incorrect","code":"INVALID_CREDENTIALS","details":null}` — timing not re-measured live, code+test carry it).
- **CSRF:** `assertSameOrigin` in `requireUser` (all authed routes) AND in `readJson` (pre-auth mutations: login/quick-login). **Live-verified:** foreign-Origin login → 403 `CROSS_ORIGIN_BLOCKED` (P61), foreign-Origin logout → 403 (P62), `Sec-Fetch-Site: same-origin` browser-vouched mismatch → 200 (P63, D-020 allowance), same-origin control → 200 (P64). Layered on `SameSite=Lax` + JSON-only bodies.

**Assessment:** the session layer is production-shaped and defense-in-depth is real (signature + absolute expiry + 3 revocation mechanisms + origin checks). Residual: per-email-only lockout (see A3-F05).

---

## 4. Verified role-permission matrix

Roles (verified in `src/lib/constants.ts:10` + live DB): **OWNER(100) > ADMIN(90) > MANAGER(70) > SALES_AGENT(40) = FIELD_REP(40)**. The task brief's "DIRECTOR" does not exist — actual set is `["OWNER","ADMIN","MANAGER","SALES_AGENT","FIELD_REP"]`. Sarah Hamdi (`sarah@asas.dz`) is a **MANAGER** (verified live P02 + DB). Rank gates via `atLeastRole`; data scope via `visibility.ts` (`seesAllRecords` = MANAGER+).

Enforcement is server-side only (`requireUser` + scope fragments composed into every query; detail routes use scoped `findFirst`). Live-verified cells marked ✓L; otherwise verified by code read + the black-box permission-matrix suite (123 rows).

| Capability (server surface) | OWNER/ADMIN | MANAGER | SALES_AGENT | FIELD_REP | Enforcement location |
|---|---|---|---|---|---|
| Login (credentials) | ✓ | ✓ | ✓ | ✓ | login/route.ts |
| Demo quick-login (demo mode only) | demo | demo | demo | demo | login/route.ts:60-129 + demo-org.ts |
| Leads list/detail | org-wide | org-wide | OWN+POOL | project-derived | visibility.ts:67-72 ✓L |
| Opportunities list | org | org | OWN+POOL | project-derived | visibility.ts:82-87 ✓L |
| Reservations list | org | org | own∨pool∨in-scope-opp | project-derived | visibility.ts:138-149 ✓L |
| Visits list/detail | org | org | own∨null agent | assigned projects only | visibility.ts:90-94 ✓L |
| SAV cases list | org | org | assignee∨creator∨pool∨client-world | project-derived | visibility.ts:165-184 ✓L |
| Documents list/download/thumb | org | org | own∨inventory∨visible-entity | same (no FIELD_REP branch — seesAllRecords false → ownOrPool path) | visibility.ts:194-213 ✓L (list) |
| Finance overview / installments / payments (money) | ✓ | ✓ | 403 | 403 | requireUser("MANAGER") ✓L + COMMISSION gate |
| Analytics | ✓ | ✓ | 403 | 403 | analytics/route.ts:24 ✓L |
| Audit trail | ✓ | ✓ | 403 | 403 | audit/route.ts:18 ✓L |
| Journey stats | ✓ | ✓ | 403 | 403 | ✓L (P37) |
| Operational metrics `/api/metrics` | ✓ | **403** | 403 | 403 | metrics/route.ts:22 (`requireUser("ADMIN")`) ✓L (P13 sarah→403) |
| Leads export / export bundle | ✓ | ✓ | 403 EXPORT_FORBIDDEN | 403 | ✓L (P35/P36) |
| Leads import / undo, duplicates merge/dismiss | ✓ | ✓ | 403 | 403 | matrix rows B |
| Settings read | ✓ | ✓ | ✓ | ✓ | ✓L (P14 via sarah; P34-context) |
| Settings write | ✓ | ✓ | 403 | 403 | settings/route.ts:27 |
| User management (create/patch/reset-password) | ✓ | 403 | 403 | 403 | requireUser("ADMIN") + org-scoped findFirst |
| Revoke other users' sessions | ✓ (own org) | 403 | 403 | 403 | sessions/revoke-all:37 |
| Offer convert/cancel, reservation closure validation, economics writes | ✓ | ✓ | 403 | 403 | reservation-economics.ts:74-76; matrix rows H |
| Lead assignment (ownerId set/change, bulk) | ✓ | ✓ | 403 FORBIDDEN_ROLE | 403 | matrix rows G |
| Apartment status/notes PATCH, project assignments | ✓ | ✓ | 403 | 403 | matrix rows B |
| Capture-token mint/list/revoke | ✓ | ✓ | 403 | 403 | public-capture tests:319,332 |
| Public lead capture POST | n/a — token-gated, unauthenticated by design | | | | lead-capture.ts |

**What the 123-row matrix actually covers** (read, not trusted): anon 401 across 28 surfaces + forged cookie + public-surface positives + JSON catch-all 404; MANAGER-floor 403s (20 rows); ADMIN-floor 403s for MANAGER (6); positive controls proving floors are floors (27); org-isolation ghosts org-A↔org-B including quick-login foreign-org and bidirectional rows (21); D-021 same-org record-scope denials (6); assignment-permission 403s (4); unauthorized state transitions incl. two-step closure and money gate (9). Plus 12 payload-level its (no-demo-fallback session, byte-identical 401 envelope, list-scoping for foreign/agent/fieldrep, email minimization) and 4 ghost-pair byte-equality its. **The claim is accurate.**

---

## 5. Org/agent isolation — live probe results

All probes: curl vs `http://127.0.0.1:3000`. Bodies archived under `evidence/a3/bodies/`. "ghost" = fabricated id `p4-nonexistent-000`.

| # | Actor | Request | Status | Body/code | Verdict |
|---|---|---|---|---|---|
| P01 | sarah (MANAGER, credentials) | POST /api/auth/login | 200 | Set-Cookie: `httpOnly; SameSite=lax; Path=/; Max-Age=604800` (no Secure — dev) | PASS |
| P02 | sarah | GET /api/auth/session | 200 | user {id,orgId,name,email,role}; session {issuedAt, expiresAt 7d}; no hash | PASS |
| P03 | anon | POST login wrong password (ONE attempt) | 401 | `INVALID_CREDENTIALS` generic envelope | PASS |
| P04 | anon | GET /api/leads, forged cookie | 401 | `NO_SESSION` | PASS |
| P05 | anon | GET /api/leads, tampered sig (1 hex char) | 401 | `NO_SESSION` | PASS |
| P10–P16 | sarah | leads/users/audit/settings/finance-overview | 200 | users include email (MANAGER+); audit rows org-scoped | PASS |
| P13 | sarah | GET /api/metrics | **403** | `FORBIDDEN_ROLE` (ADMIN-only) | PASS |
| P16 | sarah | GET /api/leads/{ghost} | 404 | `LEAD_NOT_FOUND` (md5 681eacbf…) | PASS |
| P20 | amine (SALES_AGENT, quick-login) | POST login {userId} | 200 | cookie issued; user shape clean | PASS |
| P21 | amine | GET /api/leads/{own lead} | 200 | lead detail | PASS |
| P22 | amine | GET /api/leads/{lina's lead} | **404** | `LEAD_NOT_FOUND` — **byte-identical to P23** (md5 681eacbf…) | PASS (no oracle) |
| P23 | amine | GET /api/leads/{ghost} | 404 | same md5 | PASS |
| P24 | amine | GET /api/opportunities?pageSize=100 | 200 | n=5; lina's opp **absent**; amine's present; owners={amine} | PASS |
| P25 | amine | GET /api/opportunities/{lina opp} | 405 | no GET handler (detail surface is PATCH — matrix covers PATCH 404) | PASS w/ note (A3-F07) |
| P26 | amine | GET /api/reservations?pageSize=100 | 200 | n=2; lina's res **absent**; agentIds={amine} | PASS |
| P27 | amine | GET /api/visits?pageSize=100 | 200 | n=6; agentIds={amine} only | PASS |
| P28–P31, P37 | amine | finance-overview / metrics / audit / analytics / journey-stats | **403** | `FORBIDDEN_ROLE` each | PASS |
| P32/P33 | amine | sav / documents lists | 200 | scoped lists (docs empty) | PASS |
| P34 | amine | GET /api/users | 200 | **email key absent** on all 8 rows (minimization) | PASS |
| P35/P36 | amine | leads/export, export/bundle | 403 | `EXPORT_FORBIDDEN` | PASS |
| P40 (1st) | yacine (accidental) | quick-login while locked | **429** | `ACCOUNT_LOCKED {retryAfterMs:71374}` — live F-03 proof | PASS |
| P41 | mounia (FIELD_REP) | GET /api/leads?pageSize=100 | 200 | n=11 — exactly the leads having visits on her 2 assigned projects (DB cross-check: zero out-of-scope ids) | PASS |
| P42 | mounia | GET /api/leads/{amine's lead} | 200 | correct D-025: that lead has a visit on Les Oliviers (mounia-assigned) | PASS (by design) |
| P43/P44 | mounia | analytics / finance-overview | 403 | `FORBIDDEN_ROLE` | PASS |
| P45 | mounia | GET /api/visits?pageSize=100 | 200 | n=14; **zero off-project visits** | PASS |
| P46 | mounia | GET /api/visits/{visit on assigned project} | 200 | project-derived visibility | PASS |
| P47 | mounia | GET /api/visits/{visit on unassigned project} | **404** | `VISIT_NOT_FOUND`; same visit → 200 for MANAGER (P4D) → scope-driven, not existence-driven | PASS |
| P48/P49 | mounia | metrics / audit | 403 | `FORBIDDEN_ROLE` | PASS |
| P4C | mounia | GET /api/users | 200 | no email keys | PASS |
| P50/P52 | anon | GET /api/leads, /api/metrics | 401 | `NO_SESSION` | PASS |
| P51 | anon | GET /api/auth/session | 200 | `user:null` + demoUsers (8 × {id,name,role} only — no emails) — demo mode ON (sanctioned dev shape) | PASS |
| P53 | anon | POST /api/public/lead-capture {garbage token} | 401 | `INVALID_TOKEN` generic no-oracle envelope | PASS |
| P54 | anon | GET /api/{unknown} | 404 | JSON catch-all `NOT_FOUND` | PASS |
| P60 | anon | POST login {ghost userId} | 404 | `USER_NOT_FOUND` — same envelope the demo-isolation suite proves byte-identical for foreign-org ids | PASS |
| P61/P62 | anon | POST login / logout with `Origin: http://evil-p4a3.example` | 403 | `CROSS_ORIGIN_BLOCKED` (CSRF layer live) | PASS |
| P63 | anon | POST login, foreign Origin + `Sec-Fetch-Site: same-origin` | 200 | D-020 browser-vouched allowance (header unforgeable by JS) | PASS (by design) |

**Cross-org (multi-tenant) isolation** could not be exercised live (single org in DB; creating a second org would be a write). Verified instead by: code (every list composes `orgId` + scope; every detail route uses `findFirst({id, orgId, ...scope})`), the permission-matrix org-B fixture suite (creates a real org-B tenant with credentials and probes 21 directions incl. bidirectional ghosts + quick-login foreign-org), and demo-isolation tests. Verdict: **PASS (code + tests; live NOT VERIFIED for a real second org).**

---

## 6. Upload/download security

- **Storage:** `{projectRoot}/db/docs/{storedName}`; `storedName = ${cuid-like id}-${sanitized original}`; sanitization keeps `[a-zA-Z0-9._-]` only (documents.ts:32-39) — path separators/traversal cannot survive the write path.
- **Read-path containment (W3-A5/SEC-06):** `resolveDocReadPath` compares `realpath(target)` strictly inside `realpath(DOCS_DIR)` — symlink escapes and crafted rows flatten into the same 404 ghost as a missing file (no oracle). Tested: traversal row (`../../../etc/passwd`) and an actual symlink swap inside `db/docs` pointing at `/etc/passwd` both → byte-identical 404 (document-security.test.ts:520,528).
- **Client MIME untrusted:** `sniffMime` magic-byte table (PNG/JPEG/PDF/WEBP + PK-zip family sniffed but NOT whitelisted). `verifyFileContent` decides acceptance by SNIFFED type only; the declared type is metadata (mismatch flagged in audit). Stored type = sniffed type; the download route RE-DERIVES the served type from bytes and falls back to the stored value only for unrecognized bytes; `X-Content-Type-Options: nosniff` + `Cache-Control: private, no-store` on every egress. Tests: lying declaration accepted-as-sniffed; random bytes → 422 `INVALID_FILE_CONTENT`; OOXML → 422; 8MB+1 → 413 `DOC_TOO_LARGE` (cap `DOC_MAX_SIZE_BYTES = 8MB`, constants.ts:482; both Content-Length pre-check and post-read size check in the route).
- **Authorization:** list/detail/thumb/file all `requireUser()` + `findFirst({id, orgId, ...(await documentScope(user))})` — foreign-org/out-of-scope/nonexistent are byte-identical 404s. `?inline=1` stays whitelist-gated (PDF/images only) so inline can't smuggle an executable content type.
- **Egress audit:** every successful download writes exactly one `DOC_DOWNLOADED` row (fire-and-forget post-resolve, pre-stream; audit hiccup never blocks a legitimate read — deliberate non-transactional choice on a read path, documented). Test asserts the four successful downloads are the ONLY rows for the marker entity.
- **PDF rasterization** (analyze/thumb): poppler via `execFile` with 30s timeout, temp-dir isolation, page budget (3), always cleaned.

**Verdict: PASS.** (Live list-scope probe P33 OK; upload/download flows not re-run live — covered by the 16-test black-box suite which creates and tears down real files.)

---

## 7. Public endpoints & rate limiting

`POST /api/public/lead-capture` (lead-capture.ts + route):

- **Token model:** `asas_lc_` + 128-bit secret; **hash-only storage** (sha-256; plaintext returned exactly once at mint); mint/list/revoke are MANAGER+; listing projection excludes the hash; revoke is idempotent soft-delete. Audit rows carry token id/label — never the secret.
- **No state oracle:** unknown/expired/revoked all → one byte-identical 401 `INVALID_TOKEN`; timing-safe hash re-compare on the match path (defense-in-depth over the unique-index lookup). **Live-verified** (P53).
- **Mass-assignment fence:** `.strict()` zod whitelist; honeypot `companyWebsite` (generic success, zero side effects); DZ-phone normalization gate; 60s min-interval per org+phone (in-memory); durable duplicate fence (`@@unique([orgId, phone])` race backstop) → NOTE activity + flagged audit, never a second lead.
- **Generic success law:** created/duplicate/honeypot/interval all answer `{ok:true}` — no enumeration signal.
- **Atomicity:** lead + score cache + activity + audit + useCount increment in ONE transaction; P2002 race degrades to the duplicate path.
- **Rate limiting:** IP budget 30/min FIRST (bounds work pre-token-resolution — tested: an unknown token cannot bypass the IP gate), then token budget 10/min keyed by DB row id; 429 + `Retry-After`; map hygiene at 4,096 entries.
- **CSRF N/A by design:** unauthenticated, cross-origin is the feature; the route reads JSON directly, never credentialed.

**Single-instance honesty (A3-F04):** the capture windows, the phone-interval map, and the sibling copilot/analyze limiters are **process-local** — reset on restart and non-shared across instances. The code documents this as the accepted trade-off of the no-Redis single-instance architecture; a horizontal deployment would need the documented shared-store end-state. The **login lockout, by contrast, is DB-backed** and restart-/instance-safe. `/api/metrics` observability is likewise process-local (documented). This limitation is real but bounded: the durable fences (token validity, duplicate law, honeypot) survive restarts; only the flood budget resets.

---

## 8. Secret management & production boot gates

### 8.1 Boot gates (P0-3)

`src/instrumentation.ts` → `register()` (NEXT_RUNTIME=nodejs) → `assertProductionEnvironment(process.env)`:

- `NODE_ENV=production` + missing/weak(<32)/placeholder `ASAS_SESSION_SECRET` → **crash at startup** (`SESSION_SECRET_MISSING/WEAK/PLACEHOLDER`).
- `NODE_ENV=production` + `ASAS_DEMO_MODE=1` → **crash** (`DEMO_MODE_PRODUCTION`).
- Non-production: zero gating (sandbox untouched). All 11 assertions in `tests/unit/boot-env.test.ts`; multiple-violations reporting tested.
- Defense-in-depth for post-boot env drift: `isDemoModeMisconfigured()` → login quick-login 500 `DEMO_MODE_PRODUCTION_MISCONFIG`; `/api/auth/session` suppresses `demoUsers`.
- Demo mode is **off by default** (`=== "1"` is the only enabling spelling — loose truthy spellings rejected, unit-tested).

**Live sandbox state (presence-only, values never printed):** `.env` carries `DATABASE_URL`, `ASAS_SESSION_SECRET` (present, 48 chars, non-placeholder), `ASAS_DEMO_MODE=1`, no `NODE_ENV` — the documented sanctioned dev shape. **Verdict: PASS.** The only path that undermines safe-by-default is the seed footgun below.

### 8.2 Dev fallback

Without `ASAS_SESSION_SECRET`, session.ts falls back to an ephemeral per-process secret with a loud console.warn — production-impossible due to the boot gate; acceptable for local/test.

### 8.3 AI provider

`z-ai-web-dev-sdk` reads a `.z-ai-config` JSON (cwd → home → /etc); **no environment variables, no secrets in repo**; unconfigured → 503 `AI_PROVIDER_UNAVAILABLE` (graceful). No `.z-ai-config` in the project root. No `process.env` secret reads anywhere in `src/` beyond `ASAS_SESSION_SECRET`/`ASAS_DEMO_MODE`/`ASAS_LOG_LEVEL`/`NODE_ENV` (inventory grep).

### 8.4 Dormant Supabase/RLS

- `package.json` has **no Supabase/Postgres client dependency**; `rg supabase src/` → zero matches. All matches are docs + a dormant `prisma/schema.postgres.prisma` and `.env.example` comments.
- Security therefore rests **entirely on the app layer** (`visibility.ts` org+record scoping). For the documented single-org, single-instance SQLite deployment this posture is sound: every route composes `orgId` + scope fragments server-side, and the black-box matrix + my live probes exercise exactly that layer. For a future multi-tenant PostgreSQL/Supabase port, the code itself flags the plan (`documentScope` docblock: "a proper FK + RLS policy replaces this") — until then, RLS absence is NOT a live exposure. **Verdict: PASS for the current deployment law; carries a documented port-time requirement.**

### 8.5 Seed footgun (A3-F01 — see findings)

`prisma/seed.ts` has no `NODE_ENV=production` guard and `bun run db:deploy` = `migrate deploy && db seed`: on a fresh production DB this seeds 8 demo personas — including the OWNER — with the password `asas1234`, which is a **literal in the client bundle** (`login-overlay.tsx:52`, rendered as the demo hint). The boot gate does not cover the seed path.

---

## 9. Log redaction & data exposure

- **Logger** (`src/lib/server/logger.ts`): deep, pattern-based redaction — `SENSITIVE_KEY_PATTERN = /password|passphrase|secret|token|cookie|authorization|credential|api[-_]?key|private[-_]?key|session/i` replaces matching VALUES with `[REDACTED]` at any depth; depth/array/string bounding (6/50/512); error stacks truncated to 5 frames; client responses keep generic 500 messages (F-09) with Prisma internals staying server-side. Unit-tested (`logger.test.ts`).
- **dev.log inspection (4,807 lines):** 412 grep hits for sensitive-looking tokens — **all benign**: 325× SQL column name `passwordChangedAt` and 83× column name `passwordHash` in `prisma:query` debug lines (parameterized `?` placeholders — values never logged), plus route names containing "reset-password". **Zero cookie values, zero token secrets, zero password values.** The prisma:query channel itself is debug-level (silent at production info level).
- **Client bundle:** no secret-bearing code in `src/lib/client` / `src/components` (grep). The only credential-like literal is the intentional demo password hint (demo UX, see A3-F01 for the production caveat).
- **Data minimization, live-verified:** below MANAGER the user roster drops `email` (P34/P4C vs P11); unauthenticated `demoUsers` carries only `{id,name,role}` (P51); `/api/auth/session` exposes self-scoped session dates only; login/session bodies never echo `passwordHash` (P01/P02/P20).
- **PII note (privacy):** audit rows for LOGIN/LOGIN_FAILED/LOGIN_LOCKED carry `after.email` + request IP; retention policy classifies auth-noise diagnostics for 90-day purge while security-relevant auth events are protected longer (730-day operational horizon for the protected class). This is a reasonable security/privacy trade-off for an internal CRM, but the privacy story depends on the (manual) retention script being run — `bun run retention:apply`.

---

## 10. Audit logging coverage

`logAudit` writes org-scoped rows (orgId, actorId, action, entity, entityId, before/after JSON, ip, createdAt). Grep inventory: **80+ distinct action types**, including every mandated event: `LOGIN`, `LOGIN_FAILED`, `LOGIN_LOCKED` (both flows), `LOGIN_QUICK`, `LOGOUT`, `SESSIONS_REVOKED` (SELF/ADMIN + watermark), `DOC_DOWNLOADED`, `DOC_UPLOADED`, `LEAD_MERGED`, `CAPTURE_TOKEN_CREATED/REVOKED`, `LEAD_CAPTURE_PUBLIC`, financial (`INSTALLMENT_CREATED/UPDATED`, `PAYMENT_RECORDED`, `SALE_VALIDATED`, `PRICE_CHANGED`), lifecycle (`OFFER_*`, `RESERVATION_*`, `OPPORTUNITY_*`, `LEAD_*`, `VISIT_*`, `SAV_CASE_*`, `USER_*`, `SETTINGS_UPDATED`, `EXPORT_BUNDLE`, `LEADS_EXPORTED/IMPORTED/IMPORT_UNDONE`).

- **Atomicity:** the tx-aware `logAudit(input, tx)` folds trail rows into the primary mutation's transaction — fault-injection suite (35 its) proves money+audit+activity roll back together (no committed mutation without its trail, no orphaned trails).
- **Org scoping + role gate:** `/api/audit` is MANAGER+ and `orgId`-scoped (live P12 sarah 200 / P30+P49 403).
- **Gaps:** (a) unknown-email login failures leave no AuditLog row (no org exists) — mitigated by the structured `login_failed_unknown_email` log line with normalized email+IP; (b) `DOC_DOWNLOADED` is deliberately non-transactional (read path — documented, acceptable); (c) direct-booking `OPPORTUNITY_STAGE_CHANGED.after.value` carries `reservation.amount` (A3-F03, carry-forward).

---

## 11. STRIDE summary

| Threat | Realistic attack path | Current mitigation | Status |
|---|---|---|---|
| **Spoofing** | Forged/tampered session cookie | HMAC-SHA256 + timing-safe compare; strict format checks | MITIGATED (live P04/P05) |
| | Passwordless quick-login takeover (F-01 chain) | Demo-mode gate (off by default; prod boot crash + runtime 500/empty roster); designated-demo-org scoping; ghost-identical 404; lockout-respecting | MITIGATED (live P60 + tests) |
| | CSRF on mutations | SameSite=Lax + assertSameOrigin (authed + pre-auth) + JSON-only | MITIGATED (live P61–P64) |
| | Credential stuffing | scrypt + DB-backed 5/15min lockout + generic 401 + dummy-hash timing parity | MITIGATED w/ residual A3-F05 |
| **Tampering** | Cookie payload manipulation | Signature covers userId+issuedAt; absolute expiry | MITIGATED (live P05) |
| | Server-side state tampering | tx-atomic mutations + audit-in-tx; offer/reservation concurrency guards (unique holds, 409s) | MITIGATED (suites) |
| **Repudiation** | "I didn't do that" | 80+ audit actions, actor+IP+org, tx-coupled; DOC_DOWNLOADED egress trail; LOGIN_QUICK audited | MITIGATED (residual: A3-F03 semantics) |
| **Information disclosure** | Cross-agent/cross-org record access | visibility.ts scope fragments + scoped findFirst; byte-identical 404 ghosts (live md5 equality) | MITIGATED (live + suites) |
| | PII minimization failures | email redaction below MANAGER (live); demoUsers minimal; log redaction (grep-verified) | MITIGATED |
| | Existence oracles | ghost-pair byte equality on leads/offers/reservations/users/tokens/visits (live P22≡P23) | MITIGATED |
| **DoS** | Login-flood on known accounts | DB-backed lockout (429); audit of lockouts | PARTIAL — per-email lockout is itself a cheap DoS vector (A3-F05) |
| | Public-capture flood | IP+token budgets, honeypot, size/whitelist gates | PARTIAL — process-local, restart resets (A3-F04) |
| | Resource exhaustion (upload/PDF) | 8MB cap, poppler timeout, page budget, pagination caps | MITIGATED |
| **Elevation of privilege** | Role-floor bypass | requireUser(role) everywhere (live 403s from MANAGER and below across 10 surfaces) | MITIGATED |
| | Assignment/economics self-dealing | ownerId laws + COMMISSION_FORBIDDEN money gate (MANAGER+) | MITIGATED (matrix + code) |
| | Seeded demo OWNER in production | boot gates do NOT cover the seed path | **GAP — A3-F01 (MEDIUM)** |

---

## 12. Findings register

| ID | Severity | Location | Finding | Reproduction / Evidence | Impact | Recommendation | Exploitability |
|---|---|---|---|---|---|---|---|
| **A3-F01** | **MEDIUM** | `prisma/seed.ts:21` (no prod guard); `package.json` `db:deploy` (= migrate deploy **&& db seed**); `src/components/crm/login-overlay.tsx:52` (password literal in client bundle) | Demo seed can be applied to a production database: `bun run db:deploy` on a fresh prod DB seeds 8 personas incl. an OWNER with the publicly-documented password `asas1234`. The boot fail-fast gates cover env only — not the seed path. | Read `package.json` scripts + `prisma/seed.ts` (guard grep: no NODE_ENV check); login-overlay renders the password hint from the bundle constant. | Total account takeover of a mis-seeded production org via ordinary credential login (quick-login is irrelevant — the password itself is public). | Refuse to seed when `NODE_ENV=production` unless `ASAS_ALLOW_DEMO_SEED=1`; or remove `db seed` from `db:deploy`; add a production checklist line "NEVER seed". | Requires one operator mistake on a fresh prod DB (not remotely exploitable on a correctly deployed instance). |
| **A3-F02** | LOW | `src/app/api/finance/installments/route.ts:36`, `src/app/api/finance/installments/[id]/route.ts:21` (`.max(1e12)`) vs `MAX_MONEY_DZD = 10_000_000_000` (`validation.ts:109`) | Money-cap asymmetry (P1 carry-forward, still open): installment amounts accept up to 1e12 DZD while the single-sourced cap elsewhere is 10B. | Code read (this audit); flagged in `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/ASAS_CRM_P1_FINAL_ACCEPTANCE_REPORT.md` F2. | MANAGER+ can enter an installment schedule line 100× above the sanctioned ceiling — consistency/typo-safety issue, no direct money movement. | Replace both 1e12 literals with `MAX_MONEY_DZD`. | Authenticated MANAGER+ only; accidental more likely than malicious. |
| **A3-F03** | LOW | `src/lib/services/reservations.ts:607-610` | Direct-booking audit semantics (P1 carry-forward, still open): the `OPPORTUNITY_STAGE_CHANGED` audit row for a direct booking writes `after.value = reservation.amount`. | Code read; flagged in P1 acceptance report F3 / P1 scoring doc ("trail presentation only"). | Slightly misleading audit trail semantics (stage-change row carries a money value); no column written. | Set `after.value` to the opportunity value or drop the key. | Not exploitable; reporting clarity only. |
| **A3-F04** | LOW | `src/lib/server/lead-capture.ts:215-269` (+ copilot/analyze limiters, `metrics` snapshot) | Process-local rate limiting (P1/P2 carry-forward, still true): capture/IP/token/phone-interval windows reset on restart and do not span instances; single-instance architecture law, honestly documented in code. | Code read; public-capture tests exercise the windows within one process. | Flood budget resets on every restart/deploy; multi-instance deploy would multiply budgets. | Accepted trade-off for single-instance; if horizontal scaling is ever planned, move budgets to the shared store first (documented end-state). | Remote, low-impact (durable fences unaffected). |
| **A3-F05** | LOW | `src/lib/server/auth.ts:84-117` | Lockout is keyed by email only: 5 wrong passwords lock ANY known account for 15 min (cheap targeted lockout DoS, e.g. against `sarah@asas.dz` before a Monday standup); distributed guessing against one account gets a fresh 5-try budget per window indefinitely; distinct-email spray grows `LoginFailure` until the manual 90-day retention purge. | Code read; live observation of a residual test lockout blocking quick-login (P40 429). | Availability nuisance + slow-grind guessing surface; no confidentiality impact. | Add an IP-dimension budget alongside the email window; consider CAPTCHA/escalating delays after repeated lockouts; schedule `retention:apply`. | Remote, cheap, but effect is temporary lockout only. |
| **A3-F06** | INFO | `tests/security/session-governance.test.ts:176-214` | Test side-effect: the suite deliberately locks `yacine@asas.dz` (5 failures) and leaves the rows — yacine stays locked ≤15 min after each full test run on the shared dev DB (acknowledged in test comments as intended lockout-survivability evidence). | DB read: 5 LoginFailure rows for yacine at 18:46Z; my P40 at 18:59Z → 429 with 71s remaining. | Dev-workspace nuisance only; self-expires. | Optional: teardown `clearFailures(yacine)` (trivially via one successful login) — but the residual state IS the restart-survivability proof; document instead. | None (dev-only). |
| **A3-F07** | INFO | `src/app/api/opportunities/[id]/route.ts` (PATCH+DELETE only) | No GET detail handler for opportunities: `GET /api/opportunities/{id}` → 405. Detail authorization is enforced (and tested) on the PATCH surface; list scoping verified live. | Live P25 → 405; matrix rows `org/opportunities.patch…` → 404. | API-shape inconsistency; no authz impact. | Add a scoped GET handler for symmetry (post-Phase-4). | None. |
| **A3-F08** | INFO | `src/lib/server/session.ts:401-425` | `assertSameOrigin` trusts `Sec-Fetch-Site: same-origin|none` to override an Origin/Host mismatch (D-020 proxy-chain allowance). Sound for browsers (forbidden header — JS cannot forge it); inert for non-browser clients, who can equally just omit Origin. | Live P63 (foreign Origin + `Sec-Fetch-Site: same-origin` → 200 login). | None in the browser threat model; documented rationale in code. | Keep as-is; re-evaluate if a future gateway strips Sec-Fetch-* inconsistently. | Not exploitable by the CSRF attacker class. |

**No CRITICAL or HIGH findings.** Prior-report claims (P0-3, P0-4, P1, P2) re-verified against code/tests/live probes: **accurate** — no claim failed verification. WAL remains disabled (`journal_mode=delete`, DB-verified) — operational carry-forward, not a security control gap.

---

## 13. NOT VERIFIED list

1. **Real cross-org (multi-tenant) live probe** — the live DB has a single organization; creating a second org would violate read-only rules. Covered by code + the permission-matrix/demo-isolation suites that build a real org-B tenant. (Matrix row `org/quick-login.userId×orgB → 404` + ghost-pair byte equality.)
2. **Production boot crash, executed** — boot gates verified by code read + `boot-env.test.ts` (11 assertions), not by an actual `NODE_ENV=production` start (forbidden: no builds/deploys).
3. **`Secure` cookie flag in production** — code-verified (`secure: process.env.NODE_ENV === "production"`); dev legitimately omits it. Not live-observable in this sandbox.
4. **Login timing parity (F-12)** — envelope byte-equality verified live (P03) and by test; the ~45ms scrypt timing parity is code+test-verified only (not re-measured — the timing probe would consume additional invalid-credential attempts against the shared dev DB).
5. **Live lockout trigger on a fresh account** — deliberately NOT performed (rule: no lockout brute-forcing). The mechanism is verified by tests read + the accidental P40 observation of a residual lockout.
6. **Live document upload/download round-trip** — no documents exist in the DB; the 16-test document-security suite (real PNG/PDF uploads, traversal/symlink ghosts) carries this. Live list-scope probe P33 returned a scoped (empty) list.
7. **Live revoke-all / logout replay** — code + session-governance tests; not re-probed live (would exercise additional POSTs on real sessions beyond the sanctioned login set).
8. **Full 772-test re-run** — Principal's baseline accepted per instructions; I verified WHAT the security suites assert by reading them, not by re-execution.
9. **`db/docs` physical state** — directory exists per code; contents not enumerated (not needed; no Document rows exist).

---

## Appendix A — probe environment disclosure

- Documented dev server found DOWN at 2026-11-06T18:55Z (no `next` process; Caddy :81 upstream 502; `dev.log` last line 18:54:18). I started `next dev -p 3000` directly (bypassing the `tee -a dev.log` npm script) with output to `/tmp/p4a3-dev*.log`; the sandbox reaped it between tool sessions, so each probe batch restarted it. **No existing files modified; no DB writes; `dev.log` untouched by me.**
- My probes wrote only: `/tmp/p4a3-*` files, `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/evidence/a3/**`, this report, plus the server's own legitimate auth-state side effects (one `LoginFailure` row for sarah from P03, `LOGIN`/`LOGIN_QUICK`/`LOGIN_FAILED` audit rows — the app's normal behavior, minimized to the sanctioned single invalid attempt).
