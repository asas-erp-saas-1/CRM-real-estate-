# ASAS CRM — Phase 7.1 — Database Deployment Compatibility

**Agent 4 — Database & Runtime Deployment Compatibility**
**Safety law honored:** no migration, seed, or destructive command ever ran against the original `db/custom.db`; all runtime tests used isolated copies.

## 1. Source database (canonical, untouched)

- Engine: SQLite (single file) via Prisma 6.19.2 client; schema `prisma/schema.prisma`; 25 migrations applied (`dbOk`, `migrations:25` in hosted health).
- File: `/home/z/my-project/db/custom.db`, 1.1 MB; protected by `/db/` gitignore (R13 wipe-and-restore law) and `dev.sh` R13 guards.
- Pre-repair checkpoint backup (this phase): `db/backups/backup-20261108T173052Z/` — VACUUM INTO snapshot, sha256 recorded, `PRAGMA integrity_check` OK on the snapshot, census users=8, leads=43, opportunities=21, reservations=8, apartments=46, documents=0. Retention: kept=2, deleted=0.

## 2. Packaging path (`database-runtime-build.sh`, verified by execution)

- `cp -a db/. → $BUILD_DIR/db/` — copies the live DB **plus** `db/backups/` and `db/docs/` into the artifact (~2 MB total; inert but present — matches observed artifact listing).
- `DATABASE_URL="file:$TARGET_DB_PATH" bun run db:push` — schema sync **against the copy** (log: "The database is already in sync with the Prisma schema"). The original is never opened for write by the packaging step.
- The artifact DB is therefore a byte-copy of the preview data (business records included) with the schema re-verified.

## 3. Hosted runtime path (verified by the post-repair sim)

- `start.sh` exports `DATABASE_URL=file:/app/db/custom.db` (packaged path) — a **process env var**, which overrides the `.env` value baked at build time (the workspace `.env`'s absolute sandbox path `file:/home/z/my-project/db/custom.db` is thereby neutralized on the host).
- Prisma client resolves `env("DATABASE_URL")` at engine init (`src/lib/db.ts` constructs the client with no datasource override) → hosted queries hit the packaged DB. Sim proof: `/api/health` → `dbOk:true, migrations:25, dbLatencyMs:1`; OWNER login + session reads succeeded against the isolated copy.

## 4. Persistence characteristics (host side — inferred from the platform contract, flagged honestly)

- The Z.ai native artifact model embeds the DB in the deployable package: **each publish deploys a snapshot of the preview data**; writes on the hosted instance are not round-tripped to the sandbox (no reverse-sync mechanism exists in any `.zscripts` script). Consequence: the hosted instance is the live system after publish; the sandbox preview remains the development copy. Data created in the preview after a publish appears in the *next* publish.
- Host-side durability across restarts of the *hosted* instance cannot be verified from the sandbox (observability limitation, per mission §2) — the artifact's `restart` semantics belong to the platform.
- **Never performed (per mission):** migrations or seeds against the original DB during this investigation; replacement of `db/custom.db`; any `prisma migrate reset`.

## 5. Migration & seed safety posture (unchanged, verified by inspection)

- Production seed guard: seeding is explicit-opt-in (`db:deploy:demo` only); the boot gate refuses `ASAS_DEMO_MODE=1` in production; `db:push` in packaging is additive schema sync on the copy.
- `prisma db execute --file prisma/live-hold-indexes.sql` (part of `db:push`) runs inside packaging against the copy — idempotent index DDL.
