# ASAS CRM — Phase 7 / P7-T6: Prioritized Development Backlog for the Next Native Phase (Phase 8+)

**Task ID:** P7-T6 · **Agent:** 6 — Architecture & Next Development Backlog
**Date:** 2026-11-08 · **Repo state:** `main` @ `3ec9603`, clean tree (verified this session)
**Operating context (owner decision):** development continues **natively inside the Z.ai environment** — no external deployment, no GitHub/Vercel/Docker/Supabase for now; the **Preview Panel on port 3000 is the primary acceptance surface**.
**Engineering baseline (Phase 6 close):** 884/884 tests (53 files), tsc 0 errors, lint 0 errors/42 warnings, 25 migrations, 31 models, 16 RHF+Zod dialogs, payment idempotency hard-gated, security acceptance 9/9, production build exit 0 (twin, ×5), first-ever full lifecycle executed in-sandbox. **No open CRITICAL/HIGH defect remains.**

**Constraint compliance:** READ-ONLY on the repository — the only file created/modified by this task is this document. No tests, builds, tsc, lint, cron, package or prisma changes were run/made.

---

## Sources read ( grounding basis )

1. `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_FINAL_READINESS_GATE.md` — §2 defect dispositions, §5 residual register (the primary A/B candidate pool)
2. `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_EXECUTIVE_REPORT.md` — verdict rationale, §3 defect yield, §7 owner action list
3. `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_MONITORING_ACCEPTANCE.md` — §3 signal inventory (VERIFIED-LIVE/PARTIAL/BLOCKED), §5 four documented script design notes
4. `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/evidence/a6-ops/08-owner-checklist-external.md` — the exact owner-side external activation package (E-category source)
5. `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_CRM_E2E_ACCEPTANCE.md` — journeys A–I, §5 defects D-1…D-6, §8 honest NOT-VERIFIED list
6. `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_OPERATIONAL_RUNBOOK_VALIDATION.md` — procedure table + §2 runbook corrections
7. `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_SECURITY_ACCEPTANCE.md` — §6 LOW/INFO observations (settings drift, CUID_RE, temp passwords), §7 NOT-VERIFIED list
8. `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/ASAS_PHASE6_CI_CD_REPORT.md` — F-CI-2 attribution-test hygiene note
9. `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_EXECUTIVE_REPORT.md` + `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_STAGING_READINESS_GATE.md` — §3 residual register (P4-M05/P4-L04/P4-L13/WAL/lint-ratchet carry-forward), §5 honest NOT-VERIFIED
10. `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_UI_UX_ACCEPTANCE.md` — §2.2 compact exceptions E1–E5, §5 deferred UX limitations (close-✕, EN sweep, coarse-pointer, medianTitle)
11. `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/ASAS_CRM_P2_EMAIL_SMS_EVALUATION.md` (W5-1/W5-2, Agent 6A) — provider decision (Brevo / Infobip / Twilio $0.273 LIVE-verified), the complete §7 implementation design contract incl. `DryRunAdapter`, §8 credential checklist, §10 next actions
12. `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/ASAS_CRM_P2_NOTIFICATION_OPTIMIZATION.md` — what in-app notifications DO today (polling + TTL cache; SSE/WS rejected with documented revisit trigger)
13. `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_REMAINING_WORK_REGISTER.md` + `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_REMAINING_DEFECTS_REGISTER.md` — R-06/R-13/R-14/R-16/R-17, ND-B3/ND-B7/ND-B9, Section 4/5 environment + carried items
14. `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ASAS_CRM_PHASE4_CRITICAL_FINDINGS.md` — P4-M05 (god routes, measured), P4-L04 (lockout-DoS), P4-L13 (coverage thresholds)
15. `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/DATA_EXPORT_BLOCKED.md` + `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATA_MIGRATION_GUIDE.md` (referenced) — real-data export owner-gated; 18-step pipeline delivered
16. `worklog.md` (5,025 lines — head 200 + closing segments read; P1-FA limitations F1–F5 and offer/scoring/service-extraction history)
17. **App surface:** `src/app/api/**` (87 routes incl. offers, sav, finance/payments, documents+analyze, lead-capture, export/bundle, metrics, health) and `src/components/crm/views/**` (12 views: dashboard, leads, pipeline, visits, tasks, properties, analytics, audit, journey, finance, sav, settings)
18. **Code spot-checks this session (read-only):** `api/settings/route.ts` (GET has no role gate — drift confirmed), `lib/server/auth.ts` (temp password `Asas-`+6 = 11 chars; SCRYPT_N/R/P declared but not passed), `next.config.ts` (no `poweredByHeader`), `package.json` (`db:migrate` now deploy-safe — ND-B12 closed), `scripts/backup.sh` (documents tarball IS included), `src/lib/i18n/domains/pipeline.ts` (`medianTitle` has no singular variant).

---

## 1. Executive summary

Phase 6 closed with **zero open CRITICAL/HIGH defects**; the final gate's own words: "the residual register contains no CRITICAL/HIGH item" (Final Readiness Gate §4). The honest Phase 8 backlog is therefore **not a defect backlog** — it is, in order of weight:

1. **Verification debt** — surfaces the app has never had checked: axe/a11y, keyboard/screen-reader flows, EN view-by-view sweep, coarse-pointer hit-testing, concurrency/load (P6-T4 §8.5, P5 UI/UX §5.3–5.4, Phase 5/6 "sequential probes only" residual).
2. **One large, fully-designed-but-unbuilt daily-ops capability** — outbound notification delivery (visit reminders, reservation-expiry warnings, payment confirmations). The P2 provider evaluation already contains a complete implementation contract (§7: DeliveryRecord/ConsentRecord schema, outbox retry, templates-as-code, webhook ingestion, **DryRunAdapter**) and is blocked *only* on live provider credentials — the dry-run engine itself is natively buildable today.
3. **A pocket of documented LOW residuals** — all small, all natively fixable (settings role drift, CUID_RE, 11-char temp passwords, lint ratchet, F-CI-2, WAL, scrypt wiring, X-Powered-By).
4. **Deferred maintainability debt** (god-route extraction, lockout-DoS redesign, coverage thresholds) — real, known-shaped, and deliberately NOT Phase 8 work per the owner's no-big-refactor stance.

Category totals: **A 13 · B 5 · C 7 · D 7 · E 8 = 40 items.** Priorities: P0 ×3 (A1, B1, C1), P1 ×3 (A4, A6, C2), P2 ×10, P3 ×16, E ×8 (owner-side, unranked beyond recommended order). Every A/B/C item traces to a cited document section or a code spot-check performed this session; the single Agent-proposed-new items (B2, D3, D4) are explicitly flagged.

---

## 2. Category A — Critical engineering defects (in-app, natively fixable)

Nothing here is CRITICAL/HIGH today (Phase 6 fixed P6-D1, P6-F5, F-CI-1, P6-D1b with regression guards). Category A is the **documented LOW-residual and debt register**, converted into executable backlog items.

| ID | Title | Pri | Biz | Sec | Data | UX | Maint | Perf | Cplx | Effort | Agent shape |
|---|---|---|---|---|---|---|---|---|---|---|---|
| A1 | Dialog mobile-clipping family sweep + automated rect-scan guard | **P0** | Med | Low | **Med** | High | Med | Low | Low | S–M | A5 UI/UX + E2E pass |
| A2 | `GET /api/settings` role-gate decision (code↔matrix drift) | P2 | Low | Med | Low | Low | Med | Low | Low | S | A3 Security |
| A3 | `CUID_RE` route-pattern normalization edge (metrics labels) | P2 | Low | Low | Low | Low | Med | Med | Low | S | A6 Ops (metrics owner) |
| A4 | API temp-password entropy + force-change-on-first-login | P1 | Low | **High** | Low | Low | Low | Low | Med | S–M | A3 Security |
| A5 | Login lockout-DoS redesign (P4-L04) | P2 | Low | **High** | Low | Low | Med | Low | Med | M | A3 Security |
| A6 | SQLite WAL enablement (carried since P0) | P1 | Low | Med | **High** | Low | Low | Med | Med | S | A2 Database |
| A7 | Lint-warning ratchet (42 → monotone decreasing) | P3 | Low | Low | Low | Low | **High** | Low | Low | S | A1 Build/CI |
| A8 | F-CI-2: attribution test self-cleanup (virgin-DB dependency) | P3 | Low | Low | Low | Low | Med | Low | Low | S | A4 Domain + A1 |
| A9 | God-route service extraction (P4-M05) — **deferred, tracked** | P3 | Low | Low | Low | Low | **High** | Low | **High** | L | A4 Domain |
| A10 | Coverage thresholds (P4-L13) | P3 | Low | Low | Low | Low | Med | Low | Low | S | A1 Build/CI |
| A11 | scrypt cost constants dead-wired (ND-B7 — verified still true) | P3 | Low | Med | Low | Low | Med | Low | Low | S | A3 Security |
| A12 | `X-Powered-By` header suppression (ND-B9 — unverified at runtime) | P3 | Low | Low | Low | Low | Low | Low | Low | S | A3 Security |
| A13 | Health-watch loop upgrade: error-rate check in-loop, `health_degraded` precision, optional scheduler heartbeat | P2 | Med | Med | Med | Low | Med | Med | Med | S–M | A6 Ops/Monitoring |

### A1 — Dialog mobile-clipping family sweep + automated rect-scan guard — **P0**
P6-D1b proved the failure mode: `installment-detail-dialog.tsx` silently clipped **financial content** at 390 px behind `body{overflow-x:hidden}` — invisible to the page-level scrollWidth check — root cause `grid-item`/`min-w-0` pattern (Phase 6 Gate §2, P6-D1b disposition; E2E §5 D-1). The gate's residual register explicitly recommends the "dialog grid-item/min-w-0 pattern audit across other dialogs (recommended sweep)" (Final Readiness Gate §5). Phase 6 also proved the **detection method**: per-element `getBoundingClientRect()` leaf scan excluding scrollable containers (E2E §2). This item = apply the method to **every DialogContent surface** (~33 surfaces per the Phase 5 dialog inventory `00-dialog-inventory.md`), fix any positive findings with the D-1 remedy pattern (`min-w-0`, responsive stacking, truncation), and leave a repeatable guard script/test so the class cannot silently return.
**Acceptance evidence:** rect-scan report over all dialog surfaces at 390×844 (FR+AR) with 0 clipped leaves; before/after screenshots for any fixed dialog; the scan script committed under `scripts/` (or tests/) and its output filed under `05_ENGINEERING_DOCUMENTATION/18_PHASE_8_AUTHENTICATION_ARCHITECTURE/evidence/`; full suite + tsc + lint green.

### A2 — `GET /api/settings` role-gate decision — P2
Security acceptance §6.1: `ROLE_DATA_VISIBILITY_MATRIX.md` §3 says SALES_AGENT → 403, but the route's GET is open to any authenticated role (matching weights + notification thresholds — org-scoped, non-PII); PUT is correctly MANAGER-gated. Code spot-check confirms `requireUser()` with no role argument. Decide one way — tighten GET to MANAGER+, or refresh the matrix cell — and make doc and code agree. Cheap, and it protects the permission-matrix-as-contract discipline that 123-row matrix testing relies on.
**Acceptance:** matrix cell and live probe agree (either 403 for SALES_AGENT with a probe transcript, or the updated matrix row committed); one regression test pinning the chosen behavior.

### A3 — `CUID_RE` normalization edge — P2
`route-pattern.ts:10` `/^c[a-z0-9]{20,}$/i` misses sub-20-char id shapes, so an 18-char probe id appeared RAW in `x-asas-route` log/metrics labels (Security acceptance §6.2). No authorization impact, but it is an unbounded metric-key cardinality risk on the `/api/metrics` seam. Widen the pattern (or hash-truncate unknown shapes) and pin with unit tests over adversarial id shapes.
**Acceptance:** unit tests (18-char, unicode, 10 KB id) all normalize/hash; live probe shows no raw id in the label; metrics cardinality re-checked on `/api/metrics`.

### A4 — Temp-password entropy + first-login change — P1
`generateTempPassword()` = `Asas-` + 6 CSPRNG chars ≈ **34.6 bits**, 11 chars — below the 12-char bar the `provision-owner` CLI itself sets (Security acceptance §6.3; gate §5 "11-char API temp passwords"; code spot-check confirms). It is one-time-display, but it is an unrotated credential handed to real users on the owner's future staging. Lengthen to ≥12 chars from the unambiguous alphabet AND/OR require change on first login (the stronger fix; touches login flow + one migration-free user flag if `mustChangePassword` already exists — verify).
**Acceptance:** generator unit tests (length, alphabet, entropy estimate); if force-change implemented: E2E journey "first login → forced change → old password 401"; audit row for the forced change.

### A5 — Login lockout-DoS redesign (P4-L04) — P2
Per-email-only DB-backed lockout (survives restarts — verified Phase 6) still enables (a) cheap targeted **account-lockout DoS** against a known colleague's email and (b) distinct-email spray that grows `LoginFailure` until manual purge (Phase 4 Critical Findings P4-L04; Phase 5 gate §3 carries it; P1-FA limitation F1). Redesign along the documented direction: key the lockout on (email, client-IP) pairs with a lower per-pair threshold + higher per-account threshold, plus automated `LoginFailure` retention purge. Single-instance law still applies (process-local/in-DB limits are correct for the native deployment).
**Acceptance:** lockout test matrix (attacker-IP lockout does not bar the legitimate user from another IP; spray capped by retention sweep); probe transcripts; existing 429 `ACCOUNT_LOCKED` suite extended.

### A6 — SQLite WAL enablement — P1
Carried since P0: WAL blocked by a Prisma engine bug range (re-validated at engine 3.46.0, Phase 4 gate B); no `PRAGMA journal_mode=wal` exists in source today (spot-check). WAL materially improves crash-durability and read/write concurrency for the native single-node file DB — a data-integrity axis item, not a nicety. Re-validate against the current engine (6.11.1 per package.json), enable at boot (lib/db.ts), and re-prove the backup/restore drills on top of WAL (VACUUM INTO interacts correctly, but the drill evidence must be refreshed).
**Acceptance:** `PRAGMA journal_mode` = wal on dev AND twin after boot; backup + restore drill PASS evidence on a WAL-mode DB (byte-identical, census-exact); full suite green.

### A7 — Lint-warning ratchet — P3
0 errors / 42 warnings (Phase 6 §3; +1 benign from the P6-D1 fix, reconciled). Introduce a ratchet check (fail CI if warnings > recorded count; record drops). Mechanical, protects the "0 errors" invariant from warning rot.
**Acceptance:** ratchet script wired into the local gate chain; a deliberate new warning fails the gate (probe evidence); count ratchets downward over time.

### A8 — F-CI-2 attribution test cleanup — P3
`tests/security/attribution.test.ts` probes "first lead in the agent's list" and leaves 3 touches with no cleanup — green only on a virgin DB; local re-runs fail on `firstTouchChannel` (Phase 6 CI/CD report F-CI-2; evidence a4-ci/08 §45–47). Make the test self-cleaning (afterAll rollback of its own writes) so the documented "two consecutive local runs green" property holds.
**Acceptance:** two consecutive `vitest run tests/security/attribution.test.ts` on the same DB, both green; census unchanged after the runs.

### A9 — God-route service extraction (P4-M05) — P3, **deliberately deferred**
Measured at Phase 4: visits 628, opportunities/[id] 548, notifications 500, leads 489, leads/[id] 464 lines of inline domain logic; 71/87 routes import db directly. The W2-A3 extraction template exists and is proven — but this is exactly the "big refactor" class the owner has excluded for now. **Tracked only; do not open the wave in Phase 8.** Incremental rule: any route touched for other reasons gets extracted opportunistically.
**Acceptance (when eventually done):** per-domain extraction reports with line-count before/after, contract tests unchanged, 884+ suite green.

### A10 — Coverage thresholds (P4-L13) — P3
No thresholds; tests live outside tsconfig include (Phase 4 P4-L13; Phase 5 gate §3). Add vitest coverage config with a floor set at today's real coverage (measure first, then pin), and pull tests under tsconfig discipline.
**Acceptance:** coverage report with thresholds committed; CI gate fails below floor (probe); tsc sees test files.

### A11 — scrypt constants wiring (ND-B7) — P3
`SCRYPT_N/R/P` (16384/8/1) are declared at `auth.ts:34–36` but never passed — the promisified signature takes no options, so Node's defaults are used: **correct-by-coincidence** with every comment claiming contract strength (verified still true this session; first registered in the Remaining Defects Register ND-B7). Pass the options explicitly and assert the constants in a unit test.
**Acceptance:** explicit `{N, r, p}` in both hash/verify paths; a unit test proving a hash produced with the constants verifies correctly; DUMMY_HASH contract intact.

### A12 — `X-Powered-By` suppression (ND-B9) — P3
`next.config.ts` sets nosniff + Referrer-Policy but not `poweredByHeader:false` (spot-check); ND-B9 registers the header as unsuppressed, and no Phase 5/6 evidence contradicts it. Verify at runtime on the twin (one curl), add the flag if present. Minutes of work; closes another registered P3.
**Acceptance:** curl -sI on twin shows no `X-Powered-By` (before/after transcript); build unchanged.

### A13 — Health-watch loop upgrade — P2
Four documented design notes (Monitoring acceptance §5, "no source change recommended" *this phase* — they are deliberate backlog, not non-issues): (1) the 5xx **error-rate recipe is not in the loop** (README §6 is a manual cron recipe — fold it in as an in-loop check with the >10 WARN / >50 CRIT law); (2) `curl -f` maps a 503-degraded health route to `availability` instead of `health_degraded` (same CRITICAL severity, less precise triage); (4) the **expiry scheduler has no positive heartbeat** (silent no-op by design — add an occasional `[sweeper]` heartbeat log line so "is it ticking" is observable). Item (3) (restart counter vs observed outage) is accepted behavior — both paths live-proven; no change. All changes are to the in-repo `deploy/monitoring/asas-health-watch.sh` + one optional log line in `expiry-scheduler.ts`; all live-fire-provable on the twin exactly as Phase 6 did.
**Acceptance:** twin live-fire receipts for `http_status`/`health_degraded` alert keys + a visible heartbeat line across a restart; `git diff` scoped to the two files; README §6 updated to describe the in-loop check.

---

## 3. Category B — Important CRM functionality gaps (daily sales operations)

| ID | Title | Pri | Biz | Sec | Data | UX | Maint | Perf | Cplx | Effort | Agent shape |
|---|---|---|---|---|---|---|---|---|---|---|---|
| B1 | Notification delivery engine — dry-run mode (P2 §7 contract) | **P0** | **High** | Med | Med | High | Med | Med | **High** | L | A4 Domain + A3 Security + A6 |
| B2 | Offer/commercial-proposal PDF generation — **Agent-proposed (new)** | P2 | High | Low | Med | High | Med | Low | Med | M–L | A5 UI/UX + A4 Domain |
| B3 | Reservation revival durable flow (R-13 new-row-per-booking) | P3 | Med | Low | **High** | Med | Med | Low | Med | M | A4 Domain |
| B4 | Export bundle extension (finance/payments + offers + paginated >5k) | P2 | Med | Low | **High** | Med | Low | Low | Low | M | A4 Domain |
| B5 | FIELD_REP positive-path activation & verification | P3 | Med | Med | Low | Med | Low | Low | Low | S | A4 + E2E pass |

### B1 — Notification delivery engine, dry-run mode — **P0**
The single biggest daily-operations gap: the three transactional lifelines of an Algerian agency — **visit reminders, reservation-expiry warnings, payment confirmations** — exist today only as in-app notification groups (P2 Notification Optimization: polling + TTL cache; SSE/WS evaluated and rejected with a documented revisit trigger). Outbound email/SMS has been **evaluated, decided, and fully designed** since Phase 2 (W5-1/W5-2, Agent 6A): Brevo primary / SES fallback for email; Infobip primary (conditional) / Twilio fallback ($0.273/SMS to DZ, LIVE-verified) for SMS — and the evaluation's **§7 is an implementation contract**: `SendRequest`/`DeliveryEvent`/`ProviderAdapter` types (with `providerId: 'dryrun'`), DeliveryRecord + ConsentRecord persistence design, templates-as-code (FR first, AR later), outbox retry (1m→5m→30m, max 3), webhook ingestion route, and a **test-mode table whose `local` mode is exactly a DryRunAdapter** ("persists DeliveryRecord, logs, sends nothing"). Live provider sends stay OWNER-gated (see E6) — but the engine, consent model, templates, retry, and dry-run receipts are all natively buildable and testable now, so the day credentials arrive is a configuration change, not a project.
**Acceptance:** schema migration (DeliveryRecord/ConsentRecord/WebhookEvent) + engine with DryRunAdapter active by default; unit/contract tests (idempotencyKey dedup, retry ladder, consent snapshot, zero PII in logs per §9); a seeded dry-run "visit reminder T-24h" visible end-to-end (DB record + audit + UI surface in Settings); no outbound network calls (asserted by test).

### B2 — Offer/commercial-proposal PDF generation — P2 — **Agent-proposed (new)**
Not contemplated in any phase doc (PDF appears only as document thumbnails/rasterization infra). Justification tied to CRM domain norms and existing surface: the Offer domain (W1-A1) is "the negotiable commercial proposal + provisional-unit-hold stage" — currently it exists only as data in the opportunity cockpit; a sales agent presenting a proposal needs a **printable/emailable PDF** (DZD formatting, FR/AR bilingual with RTL, expiry date, unit + price + terms). All ingredients exist natively: i18n tree, DZD formatters, documents module, poppler rasterization for previews, audit logging conventions, and the P2 §7 templates-as-code discipline. Scope conservatively: server-rendered offer sheet (HTML→PDF or print-view) + audited download. Flagged Agent-proposed because no phase doc commissions it.
**Acceptance:** generated offer PDF (FR + AR RTL) with byte-accurate amounts matching the Offer row; `OFFER_DOCUMENT_GENERATED`/download audit rows; VLM screenshot review of the AR PDF; unit tests on the template renderer.

### B3 — Reservation revival durable flow (R-13) — P3
Registered as deferred-with-design-direction (Remaining Work Register R-13): today's terminal-row **revival with full field reset + 409 guard** is the safe shipped state, but the durable end-state is a new-row-per-booking admin split-flow preserving history (migration #17 already removed the schema blocker). Matters once real agencies audit "how many times was this unit reserved". Data-integrity axis High, urgency Low.
**Acceptance:** migration + revival API producing a new ACTIVE row with full lineage; concurrency probes (revive vs revive, revive vs cancel); audit trail shows both rows' lifecycles.

### B4 — Export bundle extension — P2
`/api/export/bundle` (P7-4) delivers a one-click ZIP of **5 entity CSVs** (leads, opportunities, visits, tasks, reservations) capped at **5,000 rows/entity** with the route's own header noting "larger datasets need paginated exports (not in scope)" — and it **omits the financial ledger entirely** (payments, installments), offers, SAV, and the document index, despite reservations.csv carrying deal economics as "the data contract for the future ERP" (P19 alignment). For owner data-ownership and any future migration day, extend coverage (payments/installments CSV at minimum), document the cap, and add a paginated/streaming path or an explicit truncated-manifest flag beyond 5k.
**Acceptance:** bundle unzip round-trip with finance CSVs reconciling to the finance overview KPIs (Échéancier/Appelé/Encaissé/Reste — the Phase 6 census method); >5k-row synthetic test with correct manifest behavior; EXPORT_BUNDLE audit updated; agent-role 403 unchanged.

### B5 — FIELD_REP positive-path activation — P3
Security acceptance §7: the FIELD_REP positive path (leads visible through assigned projects; `canConfirmVisit` entitlement) is **code-verified only** — the twin had zero `ProjectAssignment` rows, so the negative case is live-proven but the positive case never ran. The operating model (05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/AGENCY_OPERATING_MODEL.md) depends on this role. Seed assignments on a twin, run the persona E2E, and fix whatever surfaces.
**Acceptance:** E2E transcript + screenshots of a FIELD_REP seeing exactly assigned-project leads and confirming an on-site visit; isolation probes unchanged (negative paths re-run green).

---

## 4. Category C — UX/UI improvements (polish, a11y, responsiveness)

The floor is already high: 44px touch targets on primary controls, RTL + dark mode + FR/EN/AR matrix with 0 console errors, 16 RHF/Zod dialogs. What remains is conformance + verification debt.

| ID | Title | Pri | Biz | Sec | Data | UX | Maint | Perf | Cplx | Effort | Agent shape |
|---|---|---|---|---|---|---|---|---|---|---|---|
| C1 | Dialog close-✕ hit area in the shared primitive (16×16 → ≥24px) | **P0** | Low | Low | Low | **High** | Low | Low | Low | S | A5 UI/UX |
| C2 | a11y axe + keyboard + screen-reader sweep (12 views) incl. EN view-by-view parity | P1 | Med | Med | Low | **High** | Med | Low | Med | M | A5 UI/UX + E2E |
| C3 | RTL/cosmetic pack: D-3 ellipsis side, D-4 `دج 0` order, `medianTitle` singular | P2 | Low | Low | Low | Med | Low | Low | Low | S | A5 UI/UX |
| C4 | Attention-card clamp affordance (D-5) | P3 | Low | Low | Low | Med | Low | Low | Low | S | A5 UI/UX |
| C5 | Finance table narrow-column ergonomics (D-6) | P3 | Med | Low | **Med** | Med | Low | Low | Low | S–M | A5 UI/UX |
| C6 | Coarse-pointer hit-testing verification (forced `pointer:coarse`) | P3 | Low | Low | Low | Med | Low | Low | Low | S | A5 + E2E |
| C7 | 390px overflow sweep across ALL views (extend the rect-scan beyond dialogs) | P2 | Med | Low | Med | High | Low | Low | Low | S | A5 + E2E |

### C1 — Shared dialog ✕ hit area — **P0**
The single **WCAG 2.2 SC 2.5.8 AA failure** measured in the app: the shared shadcn `ui/dialog.tsx` close ✕ is 16×16 px (P6 E2E §5 D-2; P5 UI/UX §2.2 exception E4, explicitly recorded as follow-up). One primitive change (`.crm-hit` or a padded hit area → ≥24px, ideally 44px on coarse pointers) lifts **every dialog at once** and finally removes the app's only AA conformance failure. Deliberately P0 because it is a ~half-session fix with a measured, published defect behind it.
**Acceptance:** measured boxes at 1280 and 390 for a sample of dialogs (✕ ≥24px); a11y snapshot unchanged (name still present); visual regression screenshots desktop+mobile+AR.

### C2 — a11y / keyboard / screen-reader sweep — P1
P6-T4 §8.5 states it plainly: "A11y axe audit / keyboard navigation / screen-reader flows were NOT in P6-T4 scope and were not run." P5 §5.3 adds that EN was spot-verified only on the audit journal, never swept view-by-view. Run agent-browser's axe audit across the 12 views × FR/AR, drive a full keyboard journey (login → lead → payment dialog → save), verify SR labels on icon-only controls, and sweep EN. Fix violations found (serious/critical first) or document waivers.
**Acceptance:** axe report per view with violation counts and dispositions; keyboard-journey transcript; zero-unmapped-i18n check in EN across views; fix screenshots for anything remediated.

### C3 — RTL/cosmetic pack — P2
Three documented cosmetic defects: **D-3** Latin-script lead names truncate with the ellipsis on the leading (right) side in RTL cells (VLM-noted, readable, mildly confusing); **D-4** zero amounts render `دج 0` (prefix) while non-zero render `13 مليون دج` (suffix) — a compact/empty-formatter inconsistency; and the P5-recorded **`pipeline.col.medianTitle`** "1 jours" (different key from the P4-L16 fix; confirmed no singular variant in `src/lib/i18n/domains/pipeline.ts` today). One small i18n/CSS pass.
**Acceptance:** AR screenshots (leads table with Latin name, pipeline empty stage, median column at n=1) before/after; i18n singular-form unit test; VLM re-review.

### C4 — Attention-card clamp affordance (D-5) — P3
`attention-strip.tsx:397` / `phased-attention.tsx:78` use `line-clamp-2` with `text-overflow:clip` — descriptions cut mid-word with no ellipsis affordance (P6 E2E §5 D-5). Add the affordance (or `line-clamp`'s native ellipsis + a title tooltip).
**Acceptance:** dashboard screenshots FR/AR showing the ellipsis; no layout shift at 390.

### C5 — Finance table ergonomics (D-6) — P3
DZD amounts wrap to two lines in the narrow MONTANT column and the ACTIONS column needs a 28px in-table scroll with no visible affordance until hover (P6 E2E §5 D-6; table scrolls by design, no data hidden). Data-adjacent UX: this is the money view. Column min-widths + a scroll-shadow affordance + tabular-nums / no-break amount formatting.
**Acceptance:** 1440 + 390 screenshots; amounts single-line at default widths (or documented accepted wrap); affordance visible when scrollable.

### C6 — Coarse-pointer hit-testing verification — P3
P5 §5.4: `.crm-hit` effective areas were **computed from CSS insets, never measured** — no forced `pointer:coarse` emulation was run. Re-run the Phase 5 measurement table with the media forced, closing the gap between the CSS law and observed behavior.
**Acceptance:** re-measured touch-target table (390, coarse forced) matching the ≥44px law; deviations logged with dispositions.

### C7 — All-views 390px overflow sweep — P2
P5 §5.5 checked overflow on only the two densest views; Phase 6's matrix covered leads/finance/pipeline/dashboard/journey partially. Combine with A1's rect-scan machinery to sweep **all 12 views** at 390 (FR + AR, light + dark), not just dialogs.
**Acceptance:** per-view rect-scan report, 0 clipped leaves outside designated scroll containers; any fix with before/after screenshots.

---

## 5. Category D — Future SaaS & portability requirements (LATER — per owner's no-external stance)

Kept honest and small: nothing here blocks native Phase 8 work except where noted; all of it exists to keep the eventual exit cheap.

| ID | Title | Pri | Biz | Sec | Data | UX | Maint | Perf | Cplx | Effort | Agent shape |
|---|---|---|---|---|---|---|---|---|---|---|---|
| D1 | PG parity: per-opportunity live-hold partial unique index (ND-B3) + comment truth | P3 | Low | **High** | Med | Low | Med | Low | Low | S | A2 Database |
| D2 | PG/Supabase RLS runtime verification (150 policies, structural-only) | P3 | Low | **High** | Med | Low | Low | Low | Med | M | A2 + A3 (needs owner PG) |
| D3 | Multi-tenant hardening audit for SaaS mode — **Agent-proposed (new)** | P3 | Med | **High** | Med | Low | Med | Low | **High** | L | A3 Security |
| D4 | Subscription/billing module — **Agent-proposed (new), someday** | P3 | High | Med | Med | Med | Med | Low | **High** | L | A4 Domain |
| D5 | Real-data migration rehearsal (18-step pipeline on synthetic corpus) | P2 | **High** | Med | **High** | Low | Med | Low | Med | M | A2 Database |
| D6 | Trigram/full-text search upgrade (PG variant; R-14) | P3 | Med | Low | Low | Med | Low | Med | Med | S–M | A4 Domain |
| D7 | Native concurrency/load smoke harness on the twin | P2 | Med | Low | **High** | Low | Med | **High** | Med | M | A6 Ops + A1 |

### D1 — PG live-hold index parity (ND-B3) — P3
The PG migration chain lacks the **per-opportunity** live-hold partial unique index while `schema.postgres.prisma:611–617` claims both deploy on PG (Remaining Defects Register ND-B3). One migration (0005) or a corrected comment. Cheap honesty fix that keeps the SQLite↔PG parity table true — do it whenever the PG files are next touched.
**Acceptance:** supabase/migrations/0005 present OR comment corrected; parity table updated; structural validation green.

### D2 — RLS runtime verification — P3 (owner-gated)
150 RLS policy statements shipped and structurally validated only — never executed against a live PG instance (R-08 / R-C2). Requires the owner's Supabase project (external). Keep queued; the policy corpus must be re-run the moment a PG instance exists anywhere.
**Acceptance:** runtime policy-probe matrix (cross-tenant denial per table) executed on a live PG; results filed.

### D3 — Multi-tenant hardening audit — P3 — **Agent-proposed (new)**
Org-scoped isolation is verified live (cross-org byte-identical 404s, Phase 6 gate C), but true SaaS readiness adds: per-tenant provisioning/onboarding, tenant-admin role boundaries, per-tenant observability, noisy-neighbor limits, and a decision on shared-DB+RLS vs schema-per-tenant. No phase doc commissions SaaS mode (the master prompt said "multi-tenant-ready" — Worklog Task 0) — hence the flag. A **paper threat-model + test-matrix deliverable first**, no code.
**Acceptance:** threat-model doc + isolation test matrix enumerating tenant-boundary abuse cases with current dispositions; owner decision recorded.

### D4 — Subscription/billing — P3, someday — **Agent-proposed (new)**
Nothing in any phase doc contemplates billing. Listed only so the category is complete and explicitly future. Do not build until the owner changes the business model.

### D5 — Real-data migration rehearsal — P2
`DATA_EXPORT_BLOCKED.md`: no real business data exists in this environment; the owner must identify the authoritative source and authorize a read-only export. The 18-step controlled pipeline (inventory → mapping → ID preservation → reconciliation → dry-run → rollback) is delivered but has only ever run as generation tooling. **Natively executable now:** rehearse the full pipeline against a synthetic corpus (including a deliberate failure/rollback leg), so the owner's real-data day is procedure-following, not discovery.
**Acceptance:** rehearsal report with reconciliation census queries, checksums, and a passed rollback leg on disposable DBs; runbook corrections (if any) filed.

### D6 — Trigram search — P3 (PG-gated)
Rejected on SQLite, deferred for PG (R-14). SQLite-side `LIKE`-based search is indexed and adequate at current scale. Keep queued with D1/D2.

### D7 — Native concurrency/load harness — P2
The standing residual: "load/stress at concurrency (unchanged from Phase 4/5: sequential probes only)" (Phase 5 §5.5, Phase 6 §5). Phase 6 proved the native method exists — the concurrent payment race (two parallel fires, exactly-one-wins) ran on the twin. Build a small scripted harness (N concurrent virtual users × golden-path mix: list, drawer open, payment write) against the production-mode twin, record p50/p95, error rate, and RSS. Staging-scale load remains owner-side (E7); this closes the *engineering* half natively.
**Acceptance:** harness script + Phase 8 report (p95, 0 unexpected 5xx, RSS within envelope, SQLite write-lock behavior under N writers); re-runnable in-sandbox.

---

## 6. Category E — External deployment blockers — **OWNER-side environment actions, NOT product defects**

Verified absent at Phase 6 close and unchanged (Executive Report §5; Monitoring acceptance §1). Exact, file-accurate procedures already delivered for every one. **No engineering work here — listing them only so they are never mistaken for app defects or silently dropped.**

| ID | Blocker | What the owner must provide | Prepared procedure (in repo) |
|---|---|---|---|
| E1 | **Docker daemon** | a Docker-enabled machine to build/run the image (Gates A/B container legs) | `Dockerfile`, `docker-compose.staging.yml` (twin-validated except the Docker legs) |
| E2 | **Staging host** | single-node host ≥8 GB RAM / 2 CPU / ≥20 G disk (measured basis: Turbopack build >2 GB, runtime 129–150 MB) | `deploy/README-STAGING.md` §C1 (build → up → health jq gate) |
| E3 | **Git remote** | private GitHub repo — **after** the `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` review (one dead secret blob + demo DB in history; never pushed, boundary intact) | `evidence/a4-ci/08` Part 2 owner package |
| E4 | **External monitoring** | uptime vantage (Uptime Kuma self-hosted recommended / commercial free tier / cron-on-another-box) + alert channel credentials for `ASAS_ALERT_CMD` (mail or webhook) | `evidence/a6-ops/08` §1–§3 (exact URL `https://<host>/api/health`, JSON contract, systemd unit file) |
| E5 | **Host scheduling + offsite** | systemd activation of `asas-backup.timer` + `asas-health-watch.service`; an offsite backup destination | `deploy/systemd/*`, `evidence/a6-ops/08` §3/§5, runbook §2–4 |
| E6 | **Email/SMS provider credentials** | Brevo (email primary) + Infobip (SMS primary, conditional on sandbox gate) or Twilio fallback ($0.273/SMS DZ, LIVE-verified); DNS admin for SPF/DKIM/DMARC; ANPDP declaration under law 18-07 (legal review) | `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/ASAS_CRM_P2_EMAIL_SMS_EVALUATION.md` §8 checklist + §10 order — unlocks live mode of B1 |
| E7 | **Staging-scale load test** | real concurrency on the staging host (the native D7 harness prepares the method) | D7 harness output + runbook kill-recovery procedure |
| E8 | **Real business-data source** | identify the authoritative source (production backup / legacy system) and authorize a read-only export — no real data exists in this environment | `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATA_MIGRATION_GUIDE.md` 18-step pipeline + D5 rehearsal |

Phase 6's own recommendation stands: **do NOT register a standing Z.ai cron watchdog for the sandbox twin** — arm the health-watch on the real staging host's systemd (Monitoring acceptance §9).

---

## 7. Top 10 — Recommended Phase 8 execution order

| # | Item | Why this position |
|---|---|---|
| 1 | **A1 — Dialog clipping sweep + rect-scan guard** | The only defect *class* with a proven silent-finance-clipping precedent (P6-D1b); method proven; prevents recurrence forever via the guard. Quick win, highest risk-reduction per hour. |
| 2 | **C1 — Shared dialog ✕ hit area** | Removes the app's single measured WCAG AA failure; one primitive, every dialog benefits; half-session. |
| 3 | **A4 — Temp-password entropy + force-change** | Cheap security hygiene on the credential path real users will actually receive; closes a published INFO residual. |
| 4 | **C2 — a11y axe + keyboard/SR + EN sweep** | The largest documented NOT-VERIFIED surface (P6-T4 §8.5, P5 §5.3); the Preview Panel is the acceptance surface — this is the quality proof for it. |
| 5 | **B1 — Notification delivery engine (dry-run)** | The biggest daily-ops functionality gap, fully pre-designed in docs (P2 §7); builds natively with zero external dependencies; converts E6 from "project" to "config" the day credentials arrive. The phase's flagship. |
| 6 | **A6 — WAL enablement + drill refresh** | Data-durability win carried since P0; small effort, must refresh backup/restore evidence on top. |
| 7 | **A2 + A3 + A11 + A12 — LOW-residual clearance pack** | One agent, one session: settings role-gate, CUID_RE, scrypt wiring, X-Powered-By — clears four documented residuals and two still-open ND-B register rows. |
| 8 | **A13 — Health-watch loop upgrade** | In-repo ops polish with twin live-fire proof available today (error-rate in-loop, `health_degraded` precision, sweeper heartbeat). |
| 9 | **C3 + C4 + C5 — RTL/cosmetic/finance polish pack** | Clears D-3/D-4/D-5/D-6 + `medianTitle`; visible quality movement on the money view and Arabic. |
| 10 | **D7 — Native concurrency/load smoke harness** | Closes the "sequential probes only" standing residual on the engineering side; produces the re-runnable method for the owner's staging-scale run (E7). |

**Rationale (one paragraph).** Phase 6 left no CRITICAL/HIGH defect, so Phase 8's highest-leverage native work is (a) eliminating the two defect *classes* that verification already caught once — silent mobile clipping (A1) and the AA hit-area failure (C1) — (b) paying down the largest honesty debts in the record — a11y/EN never swept (C2), concurrency never exercised (D7) — and (c) building the one capability whose absence the docs themselves flag as the operational gap: outbound notifications, whose complete design contract has existed since Phase 2 and whose dry-run mode needs no credentials (B1). Items 3, 6, 7, 8 are deliberate quick wins that clear the entire documented LOW residual register in roughly two sessions combined, leaving Phase 8's close in the house style: **a residual register with nothing left in categories A/C but the deliberately deferred big refactors.** Stretch candidates if capacity remains: B4 (export bundle finance extension) and B2 (offer PDF — Agent-proposed).

---

## 8. Do-NOT-do-yet list (honoring the owner's directive)

1. **No external deployment of any kind** — no Docker build/run, no staging host, no domain/DNS, no Vercel/Supabase (owner decision; E1–E5 stay owner-side).
2. **No Git remote / push** — and when it happens, `GIT_HISTORY_PURGE.md` review precedes it (E3).
3. **No live email/SMS sending** — zero credentials exist; B1 ships dry-run only (E6).
4. **No big-bang refactors** — the god-route extraction wave (P4-M05/A9) stays deferred; opportunistic extraction only when a route is touched for other reasons. No i18n re-architecture, no schema rewrites.
5. **No Postgres/Supabase migration** — parity work limited to keeping the PG files honest (D1) and the rehearsal pipeline warm (D5).
6. **No new product modules** — no billing/subscription (D4), no multi-tenant onboarding (D3 paper-only), no rewrites of working modules.
7. **No standing Z.ai cron/watchdog jobs** — per the Phase 6 recommendation (Monitoring acceptance §9); scheduled execution belongs on the future staging host.
8. **No money-law or payment-idempotency changes** — the hard gate is proven (replay 409, race exactly-one-wins, census arithmetic); Phase 8 may only add tests around it, never relax or rework it.
9. **No test removals/weakening** — the 884/884 → Phase 8 count must be monotone up, per house law.

---

## 9. Stats

| Category | Items | P0 | P1 | P2 | P3 | Owner-side |
|---|---|---|---|---|---|---|
| A — Engineering defects/debt | **13** | 1 | 2 | 4 | 6 | — |
| B — CRM functionality gaps | **5** | 1 | 0 | 2 | 2 | — |
| C — UX/UI improvements | **7** | 1 | 1 | 2 | 3 | — |
| D — Future SaaS/portability | **7** | 0 | 0 | 2 | 5 | 2 partially owner-gated (D2, D6) |
| E — External blockers | **8** | — | — | — | — | 8 (all) |
| **Total** | **40** | **3** | **3** | **10** | **16** | **8** |

Agent-proposed (new) items, explicitly flagged: **B2, D3, D4** — all other items trace to a Phase 4/5/6/P2/audit document section or a code spot-check performed this session.

---

## 10. Methodology note (how priorities were scored)

1. **Grounding rule first.** An item enters A/B/C only with a source: a Phase 5/6 residual-register row, a defect table entry (P6-D*, D-1…D-6, ND-B*, F-CI-2, P4-M05/L04/L13, R-06…R-17), a documented NOT-VERIFIED/limitation list (P6-T4 §8, P5 UI/UX §5, Security §6–7, Monitoring §5), or a verified code state (this session's spot-checks). Items without a doc trail are marked *Agent-proposed (new)* and justified against CRM domain norms (B2, D3, D4).
2. **Axes.** Each item scored High/Med/Low on seven axes: business impact (daily Algerian sales ops on the Preview Panel), security risk, data-integrity risk, UX, maintainability, performance, and complexity. Axis scores, not gut feel, drove priority.
3. **Priority mapping.** **P0** = a proven defect *class* or measured conformance failure with S/M effort (A1, C1), or the single biggest documented functionality gap with a pre-existing design contract and no external dependency (B1). **P1** = high axis scores with cheap-to-moderate effort, or durability wins long carried (A4, A6, C2). **P2** = documented LOW residuals and Medium-value gaps (A2/A3/A5/A13, B2/B4, C3/C7, D5/D7). **P3** = tracked debt deliberately deferred, cosmetic polish, or someday/future SaaS items (A7–A12, B3/B5, C4–C6, D1–D4/D6).
4. **Effort units:** S ≤ half session, M ≤ 1 session, L multi-session — calibrated to the observed Phase 6 agent session shapes.
5. **Category discipline.** E is strictly owner-side environment work with delivered procedures — never scored as product priority, never mixed into A–D. D honors the owner's no-external stance: everything there is either honesty-keeping (D1), rehearsal (D5), natively executable method-building (D7), or explicitly future (D2–D4, D6).
6. **Category-A honesty check.** Nothing in A is CRITICAL/HIGH today — that is the Phase 6 verdict, not this backlog's opinion. Category A therefore contains the documented LOW residuals and deferred debt, each now upgraded from "recorded, not fixed" to an executable item with an acceptance-evidence hint, per the house evidence-based style.

*This document contains no secrets, credentials, or customer data. Read-only task: no repository file other than this deliverable was created or modified.*
