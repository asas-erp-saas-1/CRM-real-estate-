# ASAS CRM — Phase 7.1 — Repair & Regression Report

**Principal Agent — Controlled Repair Execution & Regression**

## 1. Root cause (recap, evidence-backed)

Next.js standalone packaging copies the sandbox `.env` (`ASAS_DEMO_MODE=1`, legitimate for the preview) into the hosting artifact; the hosted runtime boots under `NODE_ENV=production`, loads it, and the P0-3 boot gate (`src/instrumentation.ts` → `src/lib/server/boot.ts`) aborts via `process.exit(1)` (the P6-F5 hardening). `start.sh`'s 1-second liveness guard then fails the whole startup → the platform reports *"Sorry, there was a problem deploying the code."* Live-reproduced pre-repair (evidence 01); failure stage 8 of 10; stages 1–7 proven complete (4 platform attempts in `/tmp`).

## 2. The repair (smallest safe correction)

**Files changed (2 files, 33 insertions, zero source-code changes):**

1. **`.env.production`** (new) — contains only `ASAS_DEMO_MODE=0` + documentation. Next.js gives it precedence over `.env` when `NODE_ENV=production` → the hosted artifact boots in the correct production posture. Under `NODE_ENV=development` (the preview) it is never loaded → preview behavior byte-identical.
2. **`.gitignore`** — `!.env.production` exception so the file is git-tracked and survives the platform's container-restart restore (R13 law: only git-tracked files are restored). No secret is tracked (D-012 law preserved — the secret still travels only via the untracked `.env` inside the private artifact).

**Deliberately NOT changed:** `.zscripts/*` (all 8 platform scripts untouched), `next.config.ts` (standalone already correct), all CRM source, DB, seeds. Alternatives considered and rejected: modifying `start.sh`/`build.sh` (platform scripts, higher blast radius), baking the session secret into a tracked file (secrets law), switching output mode (unnecessary).

**Checkpoint before modification:** git tree clean at `75f086a` + DB snapshot `db/backups/backup-20261108T173052Z/` (VACUUM INTO, integrity OK, census users=8/leads=43/opportunities=21/reservations=8/apartments=46). Repair commit: **`633b591`** on `main` (revertible as a single commit).

## 3. Post-repair verification chain (all executed, not assumed)

| Check | Result | Evidence |
|-------|--------|----------|
| Full platform pipeline `.zscripts/build.sh` (BUILD_ID=p71verify) | **exit 0**, tar.gz 58 MB | 02 |
| `.env.production` present in build dir **and** tar.gz | ✅ verified by `ls` + `tar -tzf` | §artifact report |
| Hosted-boot simulation (exact start.sh env contract, isolated DB copy, `bun server.js`, PORT=3100) | `✓ Ready in 85ms`, no gate abort | 03 |
| `GET /api/health` (production posture) | **200** — `demoMode:false`, `sessionSecretConfigured:true`, `dbOk:true`, `migrations:25` | 05 |
| `GET /` (login surface) | **200** | 05 |
| `POST /api/auth/login` (nadia@asas.dz, real password — demo chain OFF) | **200**, OWNER + session cookie | 05 |
| `GET /api/auth/session` (cookie) | **200**, 7-day session | 05 |
| Targeted regression (boot-env, instrumentation-boot-gate, production-posture, demo-mode-gate, seed-guard) | **34/34 passed** | §4 |
| Dev preview restart (platform's own `dev.sh`) | exit 0, port 3000 up, health **200** | §5 |
| Preview posture preserved | `nodeEnv:development`, `demoMode:true` (quick-login intact), login **200** | §5 |
| Browser golden path (agent-browser): login form → dashboard | renders: "Tableau de bord", "Journée de l'équipe", "Objectifs — novembre 2026" | 06, 07 |
| Preview persistence across tool sessions | port 3000 still listening minutes later in fresh sessions | §5 |

## 4. Regression scope decision (honest)

The repair touches zero TypeScript/source files, so the full 884-test suite is unaffected by construction. Executed the **targeted suite for the only domain that could theoretically interact with the repair** (env posture / boot gate): 34/34 green in 685 ms. Full-suite re-run was deliberately not forced during the repair window to keep the shared 4 GB VM stable for the preview (documented OOM history: 2 events); the pre-repair baseline is 884/884 (Phase 6/7) and no test-visible behavior changed.

## 5. Preview restoration & lifecycle events (G8)

- 17:13 — kernel OOM-killed the dev server during the owner's 4th publish build (dmesg evidence 04; anon-rss 1.98 GB; precedent 2026-11-05). No auto-restart exists in the platform (verified).
- One transient `dev.sh` abort during this phase's restart attempts (R13 DB-guard subcommand failed once with stderr swallowed by `2>/dev/null` + `set -euo pipefail`; reproduced healthy immediately after — non-systemic, noted for the record).
- Final state: dev.sh exit 0, port 3000 listening, health 200 with the exact pre-repair dev posture (`demoMode:true`), browser golden path verified, server persists across sessions.
- **Known residual (platform-side, documented not fixed):** a future publish build shares the VM with the dev server and may OOM-kill it again. If the preview shows 502 after a publish, request a dev-server restart in chat (one command, no data impact). A permanent fix would be a dev.sh watchdog — deliberately not implemented under the minimal-repair policy.

## 6. Housekeeping

- Pre-repair artifacts left in `/tmp/build_fullstack_*` (inert, not deployable sources — each publish re-runs build.sh); the verified repaired artifact is `/tmp/build_fullstack_p71verify` (+ tar.gz).
- All Phase 7.1 reports + evidence committed under `05_ENGINEERING_DOCUMENTATION/16_PHASE_7_1_HOSTED_DEPLOYMENT/`.
