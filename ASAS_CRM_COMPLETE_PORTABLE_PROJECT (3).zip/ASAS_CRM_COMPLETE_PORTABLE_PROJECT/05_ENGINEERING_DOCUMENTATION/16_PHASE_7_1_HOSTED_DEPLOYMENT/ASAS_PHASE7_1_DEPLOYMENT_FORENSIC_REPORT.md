# ASAS CRM — Phase 7.1 — Deployment Forensic Report

**Agent 1 — Z.ai Deployment Pipeline Forensics (READ-ONLY phase)**
**Date:** 2026-11-08 · **Workspace:** `/home/z/my-project` (canonical, Phase 7 verdict A) · **Git:** `75f086a` → repair `633b591`
**Symptom under investigation:** native Z.ai Publish/Deploy shows *"Sorry, there was a problem deploying the code. You can return to the generation page to try again."*

---

## 1. Executive finding

The native publish pipeline **builds and packages successfully** (stages 1–7 complete). The failure is at **stage 8 — startup script execution on the hosting runtime**: the packaged Next.js standalone server **aborts within ~1 second of start** because the artifact ships the sandbox's `ASAS_DEMO_MODE=1`, which the project's own P0-3 production boot gate treats as a fatal misconfiguration (`process.exit(1)`). The hosting health check therefore never sees a listening server and the platform reports the generic deployment failure.

Root cause **live-reproduced locally** from the actual platform-produced artifact (evidence `01-original-failure-reproduction-boot.log`):

```
Error: [asas] PRODUCTION BOOT ABORTED — unsafe configuration:
  [DEMO_MODE_PRODUCTION] ASAS_DEMO_MODE=1 is forbidden in production — the
  passwordless quick-login chain would be live on a public deployment. Set ASAS_DEMO_MODE=0.
    at n (.next/server/chunks/src_lib_server_boot_ts_bc1137b4._.js:1:1062)
EXIT CODE: 1
```

## 2. Failure-stage mapping (mission §2)

| # | Stage | Verdict | Evidence |
|---|-------|---------|----------|
| 1 | Deployment request initiation | ✅ passed | 4 build dirs exist in `/tmp` with platform `BUILD_ID`s |
| 2 | Source snapshot / packaging | ✅ passed | artifacts contain current source build |
| 3 | Build script discovery | ✅ passed | `.zscripts/build.sh` executed (platform contract) |
| 4 | Dependency installation | ✅ passed | `bun install` completed (build logs show later stages) |
| 5 | Production build | ✅ passed | `.next/standalone/server.js` generated; 3/4 attempts produced tar.gz |
| 6 | Deployment artifact creation | ✅ passed | `/tmp/build_fullstack_*.tar.gz` (59.6 MB latest) |
| 7 | Artifact upload / transfer | ⚠️ not observable from sandbox (no platform-side logs) — but irrelevant: even a perfectly uploaded artifact cannot boot (see stage 8) |
| 8 | **Startup script execution** | ❌ **FAILED** | `start.sh` → `bun server.js` → boot gate `process.exit(1)` within ~1 s; `start.sh` own guard (`sleep 1; kill -0`) then aborts with "Next.js 服务器启动失败" → exit 1 |
| 9 | Hosting runtime initialization | ❌ never reached | server dead |
| 10 | Health-check / readiness | ❌ never reached | nothing listening on app port |

## 3. Observed publish attempts (platform `BUILD_ID` artifacts in `/tmp`)

| BUILD_ID | Started | Outcome |
|----------|---------|---------|
| `1794153956` | 16:06 | build complete + tar.gz (59.2 MB) |
| `1794154467` | 16:14 | **empty dir — failed during install/build** (transient; concurrent Phase 7 regression activity; no OOM record at that time) |
| `1794155203` | 16:27 | build complete + tar.gz (59.3 MB) |
| `1794157977` | 17:13 | build complete + tar.gz (59.7 MB) — **during this attempt the kernel OOM-killed the running dev server** (see §5) |

All completed artifacts contain the latent boot-gate violation; every publish therefore failed identically at hosted startup.

## 4. Workspace deployment configuration inventory (verified, not assumed)

- `.zscripts/` exists and is **git-tracked**: `build.sh`, `start.sh`, `dev.sh`, `database-runtime-build.sh`, `python-runtime-build.sh`, `mini-services-{install,build,start}.sh` — all present and referenced scripts resolve.
- `next.config.ts`: `output: "standalone"` ✅ (the build.sh self-heal guard never needed to fire — server.js generated on every attempt).
- `package.json`: `build` → `next build`; `start` → `node .next/standalone/server.js` (dev convention; the hosting entry is `start.sh` → `bun server.js`).
- Lockfile: `bun.lock` present; `packageManager: bun@1.3.14`.
- `mini-services/`: empty (`.gitkeep` only) → packaging step correctly skips.
- `Caddyfile`: artifact copy routes `:81 → localhost:3000` with `XTransformPort` passthrough — matches gateway contract.
- `Dockerfile`/`docker-compose.staging.yml`/`deploy/`: Phase 5/6 staging assets — **not part of the Z.ai native pipeline** (inert in this context).
- `upload/`: platform-mounted, root-owned — user content, not pipeline config.
- No platform-side deployment logs are exposed inside the sandbox → **observability limitation**: stage-7 upload transfer cannot be confirmed from project side. It is moot for root-cause purposes because stage 8 is deterministically fatal (§1).

## 5. Corollary incident — dev server OOM during publish (G8 risk)

`dmesg` (kernel t=4306 s ≈ 17:13): `Out of memory: Killed process 12671 (next-server) anon-rss:1976900kB` — the running `next dev` (≈1.98 GB RSS) was OOM-killed **while the 4th publish build ran concurrently** (build ≈2–2.5 GB + dev ≈2 GB > 3.9 GB no-swap VM). Prior documented precedent: 2026-11-05 OOM (the `dev.sh` OOM guard comment). Consequences: the preview died at 17:13 and does **not** auto-restart (verified: stayed dead until restarted in this phase). This does not block the publish build itself (the kernel victim was the dev server, and the build completed), but the owner should expect the preview to be restarted after publish operations (restored to healthy in this phase; see Repair & Regression report §4).

## 6. Why preview worked while publish failed (mission §5)

- Preview = `next dev` with `NODE_ENV=development` → boot gate is a no-op outside production → demo quick-login legitimately available in the sandbox.
- Publish = standalone artifact booted with `NODE_ENV=production` → Next.js copies the sandbox `.env` into `next-service-dist/` and the standalone server **loads it at runtime** (proven: the abort cites the `.env` value) → gate fires.

Same codebase, different env posture — the gate is doing exactly what Phase 5 designed it to do (F-01 takeover vector); what was missing is a production posture override for the hosted artifact.

## 7. Evidence index

`05_ENGINEERING_DOCUMENTATION/16_PHASE_7_1_HOSTED_DEPLOYMENT/evidence/p71-deploy/`
- `01-original-failure-reproduction-boot.log` — pre-repair artifact boot: gate abort, exit 1
- `02-repaired-full-pipeline-build.log` — full `build.sh` run post-repair, exit 0
- `03-repaired-artifact-boot.log` — post-repair boot: `✓ Ready in 85ms`
- `04-oom-kill-devserver-dmesg.txt` — kernel OOM record (17:13, publish attempt 4)
- `05-health-login-smoke.txt` — post-repair health/login/session smoke (all 200)
