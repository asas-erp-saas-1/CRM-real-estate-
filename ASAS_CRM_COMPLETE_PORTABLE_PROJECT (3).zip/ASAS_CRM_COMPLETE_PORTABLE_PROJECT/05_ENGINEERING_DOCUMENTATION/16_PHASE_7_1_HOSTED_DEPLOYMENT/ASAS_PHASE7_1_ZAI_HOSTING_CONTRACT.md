# ASAS CRM — Phase 7.1 — Z.ai Hosting Contract

**Agent 3 — Build Script & Startup Contract (verified against the actual environment; nothing invented)**

The contract below is **derived from the platform's own scripts in this workspace** (`.zscripts/*`, git-tracked, platform-executed on Publish) and **verified empirically** by running the pipeline and artifact locally (evidence `02`/`03`/`05`).

## 1. Pipeline contract — what the platform runs on Publish

`.zscripts/build.sh` (executed in this sandbox, with platform-supplied `BUILD_ID`):

1. `cd /home/z/my-project`
2. `bun install`
3. `bun run build` → `next build` (NODE_ENV=production during build)
4. Guard: `.next/standalone/server.js` must exist (self-heals `output:"standalone"` into next.config if missing — never triggered here; our config already sets it)
5. mini-services build — skipped (directory empty)
6. Collect to `/tmp/build_fullstack_$BUILD_ID/`:
   - `.next/standalone/*` → `next-service-dist/`
   - `.next/static` → `next-service-dist/.next/static`
   - `public/` → `next-service-dist/public`
   - **Next.js itself additionally copies the sandbox `.env` into `next-service-dist/.env`** (and, post-repair, `.env.production`) — this is Next 16 standalone behavior, not a platform step
   - python runtime (`python-runtime-build.sh`) — no-op for this project (no Python sources)
   - `database-runtime-build.sh`: copies `db/` (incl. `custom.db`) → `$BUILD_DIR/db/`, then `DATABASE_URL=file:$BUILD_DIR/db/custom.db bun run db:push` against **the copy only** (never the original)
   - `Caddyfile` → `$BUILD_DIR/Caddyfile`
   - `start.sh` → `$BUILD_DIR/start.sh`
7. `tar -czf /tmp/build_fullstack_$BUILD_ID.tar.gz` (artifact ≈58–60 MB observed)

## 2. Runtime contract — what the host executes

`.zscripts/start.sh` in the hosting environment (artifact extracted at `/app`):

- Exports, before launching the app:
  - `NODE_ENV=production` (also hard-set inside standalone `server.js`)
  - `PORT="${PORT:-3000}"` — platform may supply the port; app binds it
  - `HOSTNAME="${HOSTNAME:-0.0.0.0}"` — binds all interfaces (health-check reachable)
  - `DATABASE_URL="${DATABASE_URL:-file:/app/db/custom.db}"` — packaged DB
- Launches `bun server.js &` from `next-service-dist/`, guards liveness after 1 s (`kill -0`), aborts the whole start on early death → **this is where the boot-gate exit(1) was surfaced as deployment failure**
- No mini-services (absent); finally `exec caddy run --config Caddyfile` (:81 → localhost:3000, with `XTransformPort` query passthrough)

**Environment variables NOT provided by the platform host:** `ASAS_SESSION_SECRET`, `ASAS_DEMO_MODE` (and anything else app-specific). There is no env-var configuration surface in the native hosting flow observed — the app-level env must therefore travel **inside the artifact via Next.js env files**, which is exactly what the repair uses.

## 3. Health-check surface

- App: `GET /api/health` → 200 JSON envelope (`status`, `dbOk`, `demoMode`, `sessionSecretConfigured`, …) — project-side contract, green post-repair.
- Platform: readiness is inferred from the server process staying up and the port accepting connections (Caddy :81 → :3000). No platform-specific endpoint requirement was found in any `.zscripts` script.

## 4. Contract implications that produced the defect (and the repair)

| Fact | Consequence |
|------|-------------|
| Standalone runtime loads `.env` files from `next-service-dist/` (proven) | Sandbox env posture ships with the artifact |
| `server.js` hard-sets `NODE_ENV='production'` | App production gates are ACTIVE on the host |
| No platform env-var mechanism | Production posture must be expressed via `.env.production` (Next.js precedence: `.env.production` > `.env` when NODE_ENV=production) |
| Dev preview runs `NODE_ENV=development` | `.env.production` is never loaded in the preview → zero preview impact |

## 5. Observability limitations (documented per mission §2)

- The platform exposes **no deployment logs** inside the sandbox — the only project-side traces are the `/tmp/build_fullstack_*` artifacts (which prove stages 1–6) and the reproduced startup behavior (stage 8). Stage 7 (upload) cannot be confirmed from inside; it is moot for the root cause because stage 8 fails deterministically even with a perfect upload.
- The platform's generic error message carries no stage code; the empty `build_fullstack_1794154467` dir (16:14) shows transient build-side failures produce the same message. One such transient (concurrent regression load) was observed; three other attempts completed packaging.
