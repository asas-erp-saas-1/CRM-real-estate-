# ASAS CRM — Phase 7.1 — Security Review

**Agent 6 — Security & Failure Review of the repair**

## 1. Change set under review (the entire repair)

| File | Change | Nature |
|------|--------|--------|
| `.env.production` (new, git-tracked) | `ASAS_DEMO_MODE=0` + documentation header | posture flag; **no secret** |
| `.gitignore` | `!.env.production` exception | persistence law (R13) |
| Commit `633b591` on `main` | the two files above | reversible via `git revert` |

**No other files were modified.** No CRM functionality, UI, workflow, dependency, or platform script was touched. No third-party patcher was downloaded or executed at any point.

## 2. Security findings

### 2.1 Secret exposure — ACCEPTABLE, documented
- `ASAS_SESSION_SECRET` (48-hex) remains only in the untracked `.env`, exactly as before the repair. `.env.production` deliberately contains **no secret** (D-012 law).
- The artifact tar.gz does embed `.env` (with the secret) — **this was already true before the repair** (Next.js standalone behavior, observed in all four platform attempts). The artifact is a private deployment package transferred to the owner's own hosting; the alternative (platform env-var injection) does not exist in the observed contract. Risk: unchanged by the repair; documented here as an inherent property of the native hosting model.
- Git history: `.env.production` adds zero secret material to VCS.

### 2.2 Demo-mode posture — IMPROVED
- Pre-repair: the hosted artifact would have booted (had the gate not existed) with the passwordless quick-login chain live — the F-01 takeover vector. The boot gate prevented this by refusing to start; the repair makes the artifact *actually* boot in the correct posture (`demoMode:false` verified in health output) rather than not at all.
- The dev preview keeps `ASAS_DEMO_MODE=1` (sandbox-only, by design; `.env.production` is never loaded under `NODE_ENV=development`).

### 2.3 Database safety — VERIFIED NON-DESTRUCTIVE
- Pre-repair checkpoint: VACUUM INTO snapshot with integrity check (`backup-20261108T173052Z`).
- Packaging writes only to the artifact copy (`db:push` targeted at `$BUILD_DIR/db/custom.db`).
- All runtime tests used `/tmp/p71-sim-db/custom.db` (a copy of the artifact copy). The original `db/custom.db` was never opened for write during Phase 7.1.
- Census before repair: users=8, leads=43, opportunities=21, reservations=8, apartments=46 (recorded in the backup manifest).

### 2.4 Startup / process behavior — NO NEW RISK
- `start.sh` unmodified. The repair introduces no background processes, no race conditions, no destructive startup steps. The only behavioral delta is env-file precedence inside the already-shipped Next runtime.

### 2.5 Stale artifacts / outdated code — MITIGATED BY DESIGN
- Old `/tmp/build_fullstack_*` artifacts (pre-repair) remain on disk — inert build outputs; they are NOT deployable sources for the platform (each publish re-runs `build.sh`). The next publish regenerates a fresh artifact containing `.env.production`. No cleanup was forced (read-only-forensics principle), but they can be purged opportunistically.
- The repaired artifact (`build_fullstack_p71verify`) was produced by the real pipeline from the current HEAD (`633b591`).

### 2.6 Preview integrity — PRESERVED
- Preview env chain untouched (`.env` unchanged; `dev.sh` R13 guards unchanged). Verified post-repair: dev server boots on :3000 with demo quick-login available (health + login smoke in the Repair & Regression report).
- Known platform-side hazard (documented, not introduced by us): concurrent publish builds can OOM-kill the dev server (two documented events). Mitigation for the owner: request a dev-server restart after publishing if the preview shows 502.

### 2.7 Blast-radius of a bad publish — CONTAINED
- If the next publish still fails, the failure is now *observably* platform-side (project-side stages are green end-to-end locally); nothing in the repair can corrupt the workspace, the preview, or the business data.

## 3. Verdict

**APPROVED.** The repair is minimal (2 files, 33 insertions), secret-free in VCS, non-destructive to data, preserves the preview posture, and strictly *increases* hosted security posture (demo chain provably OFF in production boots).
