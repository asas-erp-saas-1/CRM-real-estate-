# ASAS CRM — Phase 7.1 — Startup & Runtime Report

**Agents 3+5 — Startup Contract Execution & Independent Reproduction**

## 1. Pre-repair reproduction (the defect, proven)

Method: run the platform's own 4th artifact (`/tmp/build_fullstack_1794157977/next-service-dist`) under the exact `start.sh` env contract — `NODE_ENV=production PORT=3100 HOSTNAME=127.0.0.1 DATABASE_URL=file:<isolated copy of packaged db>` — exporting **no** app env vars (they must come from packaged files, as on the host).

Result (evidence 01): process died in <1 s —

```
Error: [asas] PRODUCTION BOOT ABORTED — unsafe configuration:
  [DEMO_MODE_PRODUCTION] ASAS_DEMO_MODE=1 is forbidden in production …
EXIT CODE: 1
```

This is the P6-F5-hardened gate (`src/instrumentation.ts`): Next 16's standalone bootstrap merely *catches and logs* `register()` rejections, so the explicit `process.exit(1)` is what actually kills the process — i.e., the Phase 6 fix is functioning exactly as designed; the artifact simply shipped a forbidden posture. On the host, `start.sh`'s own 1-second liveness guard then prints "Next.js 服务器启动失败" and exits non-zero → the platform surfaces the generic publish failure.

## 2. Post-repair reproduction (the fix, proven)

Same method, new artifact (`/tmp/build_fullstack_p71verify`, built by the real `build.sh` with `BUILD_ID=p71verify`, exit 0):

- Boot: `✓ Starting… ✓ Ready in 85ms` (evidence 03)
- `GET /api/health` → **200**: `{"status":"ok","dbOk":true,"dbLatencyMs":1,"migrations":25,"demoMode":false,"demoModeMisconfigured":false,"sessionSecretConfigured":true,"nodeEnv":"production","rssMb":158}`
- `GET /` → **200** (login surface renders)
- `POST /api/auth/login` (nadia@asas.dz / public demo password) → **200**, OWNER identity + session cookie — **real-password auth path works with the demo chain off**
- `GET /api/auth/session` (cookie) → **200**, 7-day session envelope

## 3. What was verified vs. not

Verified locally (stages the sandbox can reach): production build, artifact creation, artifact extraction-equivalent boot, port binding, health endpoint, DB initialization & migration state, login/session readiness — **all green**.

**Not verifiable from the sandbox (honest boundary):** the platform-side upload (stage 7) and the hosted FC warmup/health-check acceptance (stages 9–10). A local simulation is not proof of successful hosted deployment — the final proof must come from the owner's next native Publish attempt (see Final Deployment Gate).

## 4. Dev-server lifecycle incidents observed during the phase

- 17:13 — dev server OOM-killed by the kernel during the 4th publish build (dmesg evidence 04; anon-rss 1.98 GB; second documented occurrence after 2026-11-05).
- No auto-restart exists (verified: process stayed dead ~12 min until this phase relaunched it).
- Restore procedure used (matches the platform's own boot path): `setsid nohup bash .zscripts/dev.sh >> .zscripts/dev.log 2>&1 < /dev/null &` → bun install → R13 self-heal (env/DB guards) → `next dev` on :3000 → health check → mini-services (none).
- Recommendation for the owner: after any future Publish operation, if the preview panel shows a 502/gateway error, ask the chat to restart the dev server (the publish build shares the 4 GB VM with the dev server; the kernel may sacrifice the dev server to keep the build alive). A dev.sh auto-restart watchdog is a *possible* hardening but was deliberately **not** implemented in Phase 7.1 (minimal-repair policy; platform script).
