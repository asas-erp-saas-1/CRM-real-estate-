# ASAS CRM — Phase 7.1 — Build Artifact Report

**Agent 2 — Next.js Production Build & Artifact Engineering**

## 1. Build configuration (actual, inspected)

`next.config.ts`: `output: "standalone"`, `reactStrictMode: true`, sandbox-safe security headers (`X-Content-Type-Options`, `Referrer-Policy`), `allowedDevOrigins` (dev-only). No `distDir` override, no `output: "export"` — fully compatible with the Z.ai standalone+custom-server deployment model. `build.sh`'s self-heal guard for missing `output:"standalone"` never fired (server.js generated on every platform attempt and in the Phase 7.1 verification run).

## 2. Artifact structure (from `/tmp/build_fullstack_p71verify`, produced by the real `build.sh`)

```
build_fullstack_<ID>/
├── next-service-dist/           # Next.js standalone tree
│   ├── server.js                # 3247 B entrypoint (hard-sets NODE_ENV=production)
│   ├── .env                     # 136 B — copied by Next from workspace (sandbox posture!)
│   ├── .env.production          # NEW (repair) — ASAS_DEMO_MODE=0, precedence over .env
│   ├── .next/                   # server chunks + static assets
│   ├── public/
│   ├── node_modules/            # traced subset (16 top entries)
│   │   ├── @prisma/client ✓
│   │   └── .prisma/client/libquery_engine-debian-openssl-3.0.x.so.node ✓
│   ├── package.json
│   └── docs/ download/ scripts/ skills/   # traced inert payload (~50 MB; harmless)
├── db/custom.db                 # 1.1 MB copy + schema-synced via db:push (copy only)
├── Caddyfile                    # :81 → :3000 + XTransformPort passthrough
├── start.sh                     # hosting entrypoint (bun server.js)
└── mini-services-*              # skipped (no mini-services)
```

Artifact tar.gz: **58 MB** (`ls -lh` evidence 02). Runtime deps verified present: `@prisma/client`, generated client with the Debian/OpenSSL-3 query engine binary, `next` runtime chunks, static assets.

## 3. The contamination mechanism (root cause, artifact-side view)

Next.js 16 standalone copies the workspace `.env` into the artifact. The standalone `server.js` at runtime **loads env files from its own directory** (proven by the pre-repair reproduction: the boot-gate abort cited the `.env` value of `ASAS_DEMO_MODE=1`, while the sim shell exported neither `ASAS_DEMO_MODE` nor `ASAS_SESSION_SECRET`).

Env resolution on the host, in precedence order (process env first, then Next env files):
1. `start.sh` exports → `NODE_ENV`, `PORT`, `HOSTNAME`, `DATABASE_URL=file:/app/db/custom.db` (always win)
2. `next-service-dist/.env.production` → (post-repair) `ASAS_DEMO_MODE=0`
3. `next-service-dist/.env` → `ASAS_SESSION_SECRET` (48-hex, passes the ≥32 strength floor), `ASAS_DEMO_MODE=1` (now shadowed), `DATABASE_URL` (shadowed by process env)

Net hosted posture: production, demo OFF, secret present, packaged SQLite → boot gate passes (health evidence 05: `demoMode:false`, `sessionSecretConfigured:true`).

## 4. Runtime compatibility checks

- **Node/bun runtime:** `start.sh` uses `bun server.js`; the verification sim ran the identical command — booted `✓ Ready in 85ms`, RSS ≈158 MB.
- **Prisma + SQLite:** engine binary present and architecture-matched (linux x64, debian-openssl-3.0.x — same family as the sandbox that produced it); `db:push` during packaging keeps the copied schema in sync; health reports `dbOk:true, migrations:25`.
- **Startup command:** unchanged; no change to output mode was made (mission: do not blindly change Next output mode — not needed).

## 5. Artifact weight & inert payload (non-blocking, documented)

`docs/`, `download/`, `scripts/`, `skills/` are traced into the standalone tree (~50 MB of evidence PNGs and phase docs). Deterministically inert (never executed); left untouched per the minimal-repair policy. If the platform ever enforces a tighter artifact size limit, a follow-up could trim `outputFileTracingExcludes` — **not** done in Phase 7.1 (no evidence of a size rejection; all completed attempts packaged at ≈59 MB and the failure was proven to be startup-side).
