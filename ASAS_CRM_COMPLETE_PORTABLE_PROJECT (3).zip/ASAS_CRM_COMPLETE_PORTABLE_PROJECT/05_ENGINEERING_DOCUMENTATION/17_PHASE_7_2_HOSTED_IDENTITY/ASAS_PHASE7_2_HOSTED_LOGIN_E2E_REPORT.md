# ASAS — PHASE 7.2 — HOSTED LOGIN E2E REPORT

**Mission:** verify the authentication chain of the published-application code path end-to-end, including the owner setup flow, in the exact production posture the hosted runtime uses.
**Verdict:** **all executable tests pass.** The one test that cannot be executed from the sandbox is the literal click on the owner's own Z.ai Publish control and their personal login — owner-dependent by definition.

---

## 1. Test environment

Identical posture to the hosted runtime: `next build` standalone server, `NODE_ENV=production`, `ASAS_DEMO_MODE=0`, strong session secret, `DATABASE_URL=file:<isolated empty db>` (25 migrations, 0 users — the state the current published instance is in). No credential provided by the owner was used or requested; test identities below are disposable E2E fixtures in throwaway databases.

## 2. API-level E2E (isolated production server, port 3100)

| # | Test | Result |
|---|---|---|
| 1 | Login page/app loads | ✅ 200, login surface renders |
| 2 | Unauthenticated `/api/auth/session` advertises `bootstrapAvailable:true` on a zero-user DB | ✅ |
| 3 | Invalid credentials → generic error | ✅ 401 `INVALID_CREDENTIALS` "Email ou mot de passe incorrect" |
| 4 | Bootstrap with weak password | ✅ 422 `BOOTSTRAP_WEAK_PASSWORD` |
| 5 | Bootstrap with the public demo password | ✅ 422 `BOOTSTRAP_DEMO_PASSWORD` |
| 6 | Bootstrap with valid owner credentials | ✅ 200 — OWNER + org created, session cookie set |
| 7 | Session cookie persisted (server-side user resolution) | ✅ `/api/auth/session` returns the OWNER |
| 8 | **Valid owner credentials authenticate** (the failing operation on the current published app) | ✅ 200 + cookie |
| 9 | Authenticated dashboard route | ✅ 200 |
| 10 | Refresh preserves the session | ✅ (cookie survives; server-side revocation checks negative) |
| 11 | Logout invalidates the session | ✅ 200; subsequent request → 401 `NO_SESSION` |
| 12 | Revoked session cannot access protected routes | ✅ 401 |
| 13 | Unauthenticated requests cannot access protected CRM data | ✅ 401 `NO_SESSION` on `/api/leads` |
| 14 | Bootstrap once-only (rogue second attempt) | ✅ 404 `BOOTSTRAP_UNAVAILABLE` |
| 15 | Audit trail: `BOOTSTRAP_OWNER` recorded with email/role/org, **no password anywhere** | ✅ (log scan: 0 occurrences) |
| 16 | `POST /api/auth/bootstrap` in demo posture | ✅ 403 `BOOTSTRAP_DEMO_MODE` (dev preview unaffected) |

## 3. Browser-level E2E (agent-browser, same production server)

| Test | Result |
|---|---|
| First-run setup form renders (labels, required fields, disabled submit until valid) | ✅ |
| Fill name/email/password/confirm → submit | ✅ |
| **Owner lands directly in the CRM dashboard** (full shell: Tableau de bord, Prospects, Pipeline, …) | ✅ screenshot `evidence/p72-bootstrap-crm-landing.png` |
| Arabic RTL switch (ع) — full CRM flips, `dir="rtl"` | ✅ screenshot `evidence/p72-bootstrap-crm-arabic-rtl.png` |
| Console errors | ✅ none |
| Mobile 390px login surface | ✅ (mobile brand header + single language control — layout law verified on the overlay markup; same component family as the credential form previously verified) |
| Password visibility toggle / loading state / clear error handling | ✅ (show-hide button, spinner + disabled inputs while pending, inline + toast errors) |
| Dev preview (demo mode): login overlay + demo persona quick-login grid restored; quick-login lands in CRM | ✅ screenshot `evidence/p72-dev-preview-demo-restored.png` |

## 4. Tests NOT executable from this workspace

| Test | Blocker |
|---|---|
| Clicking the owner's Z.ai **Publish** control | owner-only platform UI; agents have no access |
| The owner's **personal** login on the published URL | requires the owner's credential (mission law: never request it); the published URL is also not exposed to the sandbox |
| Hosted-container restart data persistence | the hosted runtime's restart policy is platform-side; no hosted diagnostics are exposed to the workspace (observability boundary, documented) |

## 5. Owner actions required

Exactly two, in order: **(1)** click Publish again (ships the Phase 7.2 code + the
schema-only DB law), **(2)** complete the one-time owner setup form with the
owner's own email and a private ≥12-character password, then sign in.
