# ASAS — PHASE 7.2 — FINAL ACCEPTANCE GATE

**Date:** 2026-11-08 · **Phase:** Native hosted authentication & production database identity reconciliation

---

## 1. Gate-by-gate verdict

| Gate | Condition | Evidence | Verdict |
|---|---|---|---|
| G1 | Actual hosted runtime identified | `start.sh` contract (env exports, packaged-DB guard, standalone `bun server.js`); the publish artifact `/tmp/build_fullstack_1794162808` inspected directly | ✅ |
| G2 | Actual hosted database identified | artifact `db/custom.db`: SQLite, 25 migrations, **0 users, 0 orgs** (direct read-only query) | ✅ |
| G3 | Owner account presence & status verified | **absent — no account of any kind exists in the hosted DB** (the definitive answer; not "inactive/locked" but "never shipped") | ✅ |
| G4 | Authentication failure boundary established | **user lookup (stage 5)** — `findFirst` returns null on an empty table; everything downstream never executes; the 401 message is accurate | ✅ |
| G5 | Root cause supported by actual evidence | artifact DB inspected + R13 timeline (dev.log `state: NO_DB` 18:28:24) + publish build 18:34 — no inference, direct observation | ✅ |
| G6 | Safe minimal repair implemented | first-run OWNER bootstrap (provision-owner laws, in-app), dev.sh R13 seed fix, schema-only artifact DB + hard guard; committed on `main` | ✅ |
| G7 | Production database protected | hosted DB never written; copy-path deleted (F-01 hazard closed); security review approved all changes | ✅ |
| G8 | Authentication & security regression passed | sequential suite **883/884** (1 pre-existing timing flake, identical at baseline); every live-API suite green in isolation; lint 0 errors; production build exit 0 | ✅ |
| G9 | Development Preview remains functional | demo mode unchanged, personas restored, browser-verified quick-login → CRM | ✅ |
| G10 | Actual hosted OWNER login verified | **requires the owner's Publish click + first-run setup — not executable from the sandbox** (owner-only platform actions) | ⏳ owner-dependent |

## 2. Final verdict

> ## **B — ROOT CAUSE FIXED, OWNER CONFIRMATION REQUIRED**
>
> The technical repair is verified end-to-end in the exact production posture of
> the hosted runtime (empty schema-only database → owner setup → OWNER session →
> credential login 200 → once-only lockout → revocation semantics), and the
> publish path is now safe by construction. What remains is two owner-only
> actions: one Publish click and one first-run setup form. Per the mission law,
> B is **not** promoted to A: the literal hosted OWNER login cannot be verified
> from inside the workspace, and the owner's credential must never transit the
> team.

## 3. The owner's next-Publish playbook (exact steps)

1. **Publish** — click the Z.ai native Publish/Deploy control once. The build now
   ships: the Phase 7.2 code, and a **schema-only** artifact database (safe by
   construction; the build fails loudly rather than shipping accounts).
2. **Open the published app.** The login screen will show a one-time
   **"Initial setup / الإعداد الأولي / Configuration initiale"** card.
3. **Create the owner account** — full name, the owner's own email, and a private
   password of **at least 12 characters** (the public demo password is refused).
   No one else should see or receive this password — it is entered directly in
   the app and never leaves it except as a hash.
4. **Sign in lands directly in the CRM dashboard.** The setup card never appears
   again on that instance (once-only law).

**Timing note:** complete step 3 promptly after step 1 — until the owner account
exists, the setup card is available to whoever visits the published URL first
(the standard first-run install-gate model; it closes permanently the moment the
owner claims the instance).

**Data model note:** each future re-Publish resets the hosted database to the
empty baseline under this platform's artifact law — treat re-publishes as
redeploys, not upgrades, until the platform offers persistent hosted storage.

## 4. Rollback

Checkpoint tag `phase72-pre-repair` (commit `1d20b9d`). All Phase 7.2 changes are
reversible via `git revert` of the phase commit; the dev DB baseline is the
canonical seed (reproducible with `bun run db:reset`).

## 5. Deliverables index

| Report | File |
|---|---|
| Hosted database identity | `ASAS_PHASE7_2_HOSTED_DATABASE_IDENTITY_REPORT.md` |
| Authentication trace | `ASAS_PHASE7_2_AUTHENTICATION_TRACE_REPORT.md` |
| Owner account integrity | `ASAS_PHASE7_2_OWNER_ACCOUNT_INTEGRITY_REPORT.md` |
| Production configuration | `ASAS_PHASE7_2_PRODUCTION_CONFIGURATION_REPORT.md` |
| Hosted login E2E | `ASAS_PHASE7_2_HOSTED_LOGIN_E2E_REPORT.md` |
| Security review | `ASAS_PHASE7_2_SECURITY_REVIEW.md` |
| Repair & regression | `ASAS_PHASE7_2_REPAIR_AND_REGRESSION_REPORT.md` |
| Final acceptance gate | this file |
| Evidence screenshots | `05_ENGINEERING_DOCUMENTATION/17_PHASE_7_2_HOSTED_IDENTITY/evidence/*.png` |

---

## 6. Dated addendum (2026-11-10, S-CLOSE-2) — G9 re-recovery after an OOM kill + reaper-law restart fix

The boot-time dev server was OOM-killed after the session close (next-server 1.72 GB
anon-rss, the documented A-1 law). Recovery surfaced a NEW environment law — the
workspace reaps the descendant tree of every Bash tool call at teardown, so neither
`nohup … &` nor `setsid … & disown` survives; only a **double-fork** (immediate
intermediate exit → server re-parents to PID 1 while the spawning shell lives) escapes.
Shipped as `.zscripts/dev-restart.sh` (+ `dev-launch.sh`, with dev.sh's OOM guard
verbatim). The recovered instance then re-passed the G9 golden path in full:
login render (8-persona grid, no bootstrap card in dev), OWNER quick-login → live-data
dashboard, **credential login 200 + HMAC cookie**, wrong-password 401 with the faithful
error, mobile 390 px + footer geometry, AR RTL + dark mode, console 0 / dev.log 0
errors — evidence `p72-sc2-00…05-*.png`. **No repair/hosted-path/data change occurred;
the verdict stays B.** (Detail: `worklog.md` → P7.2-S-CLOSE-2.)
