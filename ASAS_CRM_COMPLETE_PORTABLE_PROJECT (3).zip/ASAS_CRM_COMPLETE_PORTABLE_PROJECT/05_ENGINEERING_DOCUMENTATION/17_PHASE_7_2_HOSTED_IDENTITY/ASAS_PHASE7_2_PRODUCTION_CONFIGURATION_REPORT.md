# ASAS — PHASE 7.2 — PRODUCTION CONFIGURATION REPORT

**Mission:** inspect the complete production authentication configuration.
**Verdict:** production posture is correctly enforced (Phase 7.1 fix intact); no configuration defect contributed to the login failure. One platform-law consequence is documented (artifact-baked database).

---

## 1. Configuration inventory (observed, secrets never printed)

| Item | Value / mechanism | Status |
|---|---|---|
| `.env.production` | tracked on purpose; contains **only** `ASAS_DEMO_MODE=0` (no secret, no DATABASE_URL) — header documents the Phase 7.1 root cause and the R13 law | ✅ intact, committed `633b591` |
| `ASAS_DEMO_MODE` (hosted) | `0` via `.env.production` precedence under `NODE_ENV=production`; boot gate aborts otherwise | ✅ demo chain off in production |
| `NODE_ENV` (hosted) | `export NODE_ENV=production` in `start.sh` before `bun server.js` | ✅ |
| `DATABASE_URL` (hosted) | real process env var `file:/app/db/custom.db` (start.sh) — takes precedence over any `.env` file copied into the artifact | ✅ path is correct; **the file was empty of users** (root cause, not a path defect) |
| `ASAS_SESSION_SECRET` (hosted) | supplied by the sandbox `.env` that Next copies into the standalone artifact; boot gate enforces ≥32 chars, rejects placeholders | ✅ passes the gate (hosted server boots) |
| Session cookie | httpOnly, `sameSite=lax`, `secure` in production, 7-day maxAge aligned with `SESSION_MAX_AGE_MS`; HMAC-signed; absolute expiry; server-side revocation | ✅ verified in E2E |
| Prisma client | SQLite engine in the standalone bundle; 25-migration chain present in the artifact DB | ✅ |
| Production startup | `start.sh`: env exports → packaged-DB existence guard → `bun server.js` (background) → Caddy foreground | ✅ functions as designed |
| Dev preview | `.env` with `ASAS_DEMO_MODE=1`, demo personas restored (seeded baseline) — **unchanged by Phase 7.2** | ✅ G9 evidence |
| Boot gate (`src/lib/server/boot.ts`) | session-secret strength + demo-mode-off assertions; **not weakened** by Phase 7.2 | ✅ unchanged |
| Demo seed guard | refuses under `NODE_ENV=production` without the explicit opt-in | ✅ unchanged |

## 2. Environment variable precedence (verified chain)

1. Process env (`start.sh` exports: `NODE_ENV`, `PORT`, `HOSTNAME`, `DATABASE_URL`) — highest.
2. `.env.production` (only under `NODE_ENV=production`) — `ASAS_DEMO_MODE=0` wins over the demo value in `.env`.
3. `.env` (copied into the artifact by the Next build) — supplies `ASAS_SESSION_SECRET`.

No unintended override was found. The hosted runtime does not silently load a
different configuration.

## 3. Platform law consequence (documented, not a defect)

The hosting model bakes the database **into the deploy artifact at build time**
(`database-runtime-build.sh`). Combined with the sandbox R13 wipe law, this made
"what gets published" depend on "what the dev DB contained at click-time" — the
root cause's upstream amplifier. Phase 7.2 closes this permanently: the artifact
DB is now **always a fresh schema-only database** (the dev DB carries
public-password demo personas and must never ship), and the hosted instance
receives its real OWNER via the in-app first-run bootstrap.

**Consequence for the owner to understand:** re-publishing resets the hosted
database to the empty baseline (business data created in the hosted app does not
survive a re-publish under this platform's artifact model). This is a platform
characteristic, disclosed here per the evidence-first law.

## 4. Owner actions required

None beyond the single re-Publish + first-run setup described in the final gate.
