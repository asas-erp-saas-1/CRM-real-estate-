# ASAS — PHASE 7.2 — AUTHENTICATION TRACE REPORT

**Mission:** trace the complete login path and establish the exact failure boundary.
**Verdict:** failure at **STAGE 5 — USER LOOKUP**. The generic error message is *accurate*: no account exists to match.

---

## 1. The traced path (frontend → backend → cookie)

| # | Stage | Implementation | Status on the published app |
|---|---|---|---|
| 1 | Login form input | `src/components/crm/login-overlay.tsx` (email + password, show/hide toggle, disabled-while-pending) | renders correctly |
| 2 | Client-side validation | required fields, submit gating | works |
| 3 | Email normalization | API route: `body.email.trim().toLowerCase()` (`src/app/api/auth/login/route.ts:132`) | works |
| 4 | Login API endpoint | `POST /api/auth/login` (credentials flow) | reached |
| 5 | **User lookup** | `db.user.findFirst({ where: { email, active: true } })` | **RETURNS NULL — zero users in the hosted DB** |
| 6 | Organization/tenant resolution | via `user.orgId` | never reached |
| 7 | Account status validation | `active: true` filter + lockout (`assertNotLocked`) | lockout window machinery works; status filter moot |
| 8 | Password hash verification | `verifyPassword` (scrypt N=16384/r=8/p=1, keylen 32, constant-time) against `DUMMY_HASH` for unknown emails (F-12 timing-oracle guard) | executed against DUMMY_HASH → false |
| 9 | Session creation | `signSession` HMAC-SHA256 cookie `asas_user` | never reached |
| 10 | Cookie generation | httpOnly, lax, `secure` in production, 7-day maxAge | never reached |
| 11 | Cookie delivery | `res.cookies.set` | never reached |
| 12 | Post-login navigation | toast + `queryClient.resetQueries()` → CRM shell | never reached |

## 2. The error the owner sees

```
401 {"error":"Email ou mot de passe incorrect","code":"INVALID_CREDENTIALS"}
```

Frontend mapping (`login-overlay.tsx`): `INVALID_CREDENTIALS` → localized
`auth.invalidCredentials` toast (5 s) + destructive Alert card. **The mapping is
correct — the server genuinely could not match the credential because the User
table is empty.** This is *not* a frontend mislabeling of a 500/network error
(mission category 10 is ruled out: during E2E verification of the same build,
server errors map to distinct messages and the 401 path is exercised only on
real lookup/verification failure).

## 3. Sanitized production-mode request/response (isolated reproduction)

Reproduced against the same code in production posture with an empty database
(the hosted state):

```
POST /api/auth/login  {"email":"<any>","password":"<any>"}
→ 401 INVALID_CREDENTIALS "Email ou mot de passe incorrect"   (≈45ms — scrypt burned on DUMMY_HASH)
```

Internal failure category: `USER_NOT_FOUND` → recorded as a login failure
(`recordFailure`, DB-backed 5/15-min window → 429 ACCOUNT_LOCKED after 5
attempts — the owner may have briefly hit this; it self-clears in 15 minutes).

## 4. Ruled-out differential diagnoses

| Hypothesis | Ruled out by |
|---|---|
| Wrong DB path in hosted runtime | `start.sh` exports `DATABASE_URL=file:/app/db/custom.db` (env var > .env files); artifact contains that file |
| Inactive/locked/archived account | no account exists at all |
| Password hash mismatch / algorithm incompatibility | no hash exists to mismatch; scrypt verifier unchanged since Phase 2 and verified in E2E |
| Email case-sensitivity | normalization is trim+lowercase both at seed and login |
| Env vars differing (demo mode etc.) | Phase 7.1 fix verified `ASAS_DEMO_MODE=0`; quick-login path is not what the owner used |
| Session cookie problem | failure precedes session creation entirely |
| Frontend error mistranslation | message is accurate; error taxonomy verified in E2E |

## 5. Owner actions required

None for the trace itself.
