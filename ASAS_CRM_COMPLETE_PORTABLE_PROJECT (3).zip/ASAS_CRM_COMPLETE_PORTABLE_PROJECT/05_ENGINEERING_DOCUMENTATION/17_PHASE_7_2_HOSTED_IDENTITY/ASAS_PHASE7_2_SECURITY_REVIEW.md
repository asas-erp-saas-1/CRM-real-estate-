# ASAS — PHASE 7.2 — SECURITY REVIEW

**Reviewer mandate:** independently review every proposed fix before execution; verify no secret exposure, no bypass, no destructive operation.
**Verdict:** **APPROVED** — all repairs implemented as reviewed; no production data was touched; no security control was weakened.

---

## 1. Review of each change (as implemented)

### 1.1 `POST /api/auth/bootstrap` + `bootstrapAvailable` signal + setup UI

| Concern | Review finding |
|---|---|
| Password exposure | ✅ password transits only the HTTPS/TLS request body → scrypt hash → DB. Never logged (verified: 0 occurrences in server logs), never audited (audit row carries email/name/role/org only), never echoed in responses, never in source beyond the constant `DEMO_PASSWORD` (pre-existing, public by design). |
| Password hash exposure | ✅ hash written once to `User.passwordHash`; no endpoint returns it; E2E responses confirmed hash-free. |
| Demo bypass reintroduced | ✅ none — the bootstrap is *credentials-only*; quick-login remains demo-mode-only and 403-fails in production. |
| Default public OWNER credentials | ✅ none — the public demo password is explicitly rejected (422), ≥12-char minimum enforced server-side *and* client-side. |
| Takeover race (someone claims the instance before the owner) | ⚠️→✅ inherent to any first-run install gate (WordPress-class). Mitigations implemented: server-driven availability (zero-user + demo-off only), write-transaction re-assertion (a racing pair serializes; the loser 404s), DB-backed rate limit (5/15 min per email), one-shot semantics (forever closed after the first success). Residual window is the interval between Publish and the owner's first visit — disclosed to the owner in the final report. |
| Enumeration oracle | ✅ bootstrap errors are posture/availability errors, not per-email lookups (the route never discloses whether an email exists — it creates or refuses on global state). |
| Second conflicting OWNER | ✅ impossible — once any user exists the route 404s forever (E2E-verified). |
| Session security | ✅ same cookie posture as login (httpOnly, lax, secure-in-prod, 7-day, HMAC-signed); issued via the same `signSession`. |
| Security boot gate | ✅ untouched — `boot.ts` still aborts production without a strong secret / with demo mode on. |

### 1.2 `dev.sh` R13 recovery (`db:deploy` → `db:deploy:demo`)

- ✅ Strictly a **dev-sandbox** script (never runs in the hosted artifact; the artifact uses `start.sh`).
- ✅ The seed is idempotent (only when the org has no users) and **refuses under `NODE_ENV=production`** (Phase 5 guard) — it cannot leak into any production posture.
- ✅ Restores the documented demo baseline the script always claimed to rebuild.

### 1.3 `database-runtime-build.sh` — artifact DB always schema-only + zero-user guard

- ✅ **Removes a latent F-01 takeover vector**: had the dev DB been seeded (as it now is after every R13 recovery), the old copy branch would have shipped demo personas — including a demo OWNER with the public password `asas1234` — to the public hosted runtime.
- ✅ The hard post-condition guard (artifact DB must report 0 users) fail-closes the build on any future leak reintroduction.
- ✅ No user data, no seeds, no migrations beyond the schema chain enter the artifact.

### 1.4 One-time dev DB reseed + baseline reset (`prisma migrate reset --force`)

- ✅ Applied to the **development database only** — which at that moment contained only today's re-seed and test-suite residue (the R13 wipe had already destroyed any prior content at 18:28, before Phase 7.2 began).
- ✅ The hosted artifact DB and the published instance were **never written to** — the hosted runtime is unreachable from the sandbox (no resets, no seeds, no deletes ever executed against it).
- ✅ No user records deleted (there were none), no organization relationships destroyed, no customer data touched (the pre-wipe DB's business rows were already gone before this phase; today's dev content was exclusively demo/test fixtures).

## 2. Production database safety rules — compliance audit

| Rule | Status |
|---|---|
| Never delete/reset the hosted production database | ✅ never touched |
| Never seed it | ✅ never touched |
| Never replace it with the dev database blindly | ✅ the opposite law now enforced (schema-only artifact) |
| Never copy dev DB over hosted without migration + approval | ✅ copy path deleted entirely |
| Never create a second conflicting OWNER | ✅ once-only law + E2E proof |
| Never change the owner's password | ✅ the owner sets their own; nobody else's credential exists |
| Never expose private customer data in diagnostics | ✅ all DB reports contain counts only; no PII, no hashes |
| Back up before authorized writes | ✅ the only writes were to disposable E2E databases and the dev baseline (whose prior content was today's demo fixtures) |
| Verify org/role relationships after account repair | ✅ E2E asserts OWNER + org resolution through `/api/auth/session` |
| Preserve the development Preview and its demo mode | ✅ demo mode ON, personas restored, quick-login verified in browser |

## 3. Secrets handled during Phase 7.2

- The sandbox `.env` session secret was read **only** for existence/strength checks (never printed; reports reference "strong secret present").
- E2E test secrets are disposable fixtures in throwaway databases, never valid on any real instance.
- No owner credential was requested, received, or processed at any point.

## 4. Residual risks (disclosed)

1. **First-run claim window** (above) — bounded by the owner acting promptly after Publish.
2. **Re-publish data reset** (platform law): the hosted DB resets to the schema-only baseline on every Publish; business data created in the hosted app does not survive re-publishes under the artifact model. Disclosed to the owner in the final report; not repairable application-side.
3. **Shared session secret** between sandbox and hosted artifact (Phase 7.1 posture, unchanged): the hosted instance's sessions are signed with the secret baked from the sandbox `.env`. Not a Phase 7.2 regression; noted for a future hardening pass (out of scope under the minimal-repair law).
