# ASAS — PHASE 7.2 — REPAIR AND REGRESSION REPORT

**Verdict:** minimal, evidence-supported repair implemented and verified; regression gates green (with two documented pre-existing environmental conditions).

---

## 1. Root cause → repair mapping

| Root cause element | Repair |
|---|---|
| Hosted artifact DB shipped with zero users (R13 wipe → migrate-only rebuild → packaged at 18:34) | **R1** in-app first-run OWNER bootstrap (`POST /api/auth/bootstrap`) + server-driven `bootstrapAvailable` signal + localized setup UI |
| dev.sh R13 recovery claims a seeded baseline but never seeds | **R2** `db:deploy` → `db:deploy:demo` (dev-sandbox only; seed is idempotent + production-refusing) |
| Publish path copies whatever the dev DB holds (today: empty; after R2: public-password demo personas — an F-01 hazard) | **R3** artifact DB is **always** a fresh schema-only database + hard zero-user post-condition guard (build fails loudly on violation) |
| Dev preview left without any loginable account | **R4** one-time canonical baseline restore (`prisma migrate reset --force` + seed) — dev DB only |

## 2. Code changes (commit on `main`, checkpoint tag `phase72-pre-repair` @ `1d20b9d`)

| File | Change |
|---|---|
| `src/app/api/auth/bootstrap/route.ts` | NEW — first-run OWNER provisioning route (provision-owner laws; 4 gates; transactional once-only; rate-limited; audited) |
| `src/lib/server/bootstrap.ts` | NEW — `bootstrapAvailable()` contract (extracted to honor the route-export contract) |
| `src/app/api/auth/session/route.ts` | unauthenticated production-posture response gains `bootstrapAvailable` |
| `src/components/crm/login-overlay.tsx` | `BootstrapForm` — one-time owner setup (name/email/password/confirm, show-hide, inline law feedback, AR/FR/EN, RTL) |
| `src/components/crm/crm-app.tsx` | passes the signal to the overlay |
| `src/lib/client/types.ts` | `Session.bootstrapAvailable?: boolean` |
| `src/lib/i18n/domains/auth.ts` | 17 new keys × 3 languages |
| `.zscripts/dev.sh` | R13 recovery seeds the demo baseline |
| `.zscripts/database-runtime-build.sh` | schema-only artifact DB + zero-user hard guard |

## 3. Database changes

- **Hosted/published database: none** (unreachable; never written).
- Dev database: restored to the canonical seeded demo baseline (was empty after the R13 wipe; contained no business data at any point this phase).
- Disposable E2E databases under `/tmp/p72-e2e/`: created/destroyed for verification only.

## 4. Tests executed

| Suite | Result |
|---|---|
| `bun run lint` | **0 errors** (42 pre-existing warnings, none in Phase 7.2 files) |
| `next build` (production, standalone) | **exit 0** (twice: initial + post-refactor; `/api/auth/bootstrap` in the route manifest) |
| Production-posture E2E (isolated empty DB, port 3100) | **16/16 API checks + browser flow green** (see the E2E report) |
| Browser E2E (agent-browser) | setup → CRM landing, AR RTL, console clean; dev demo login restored |
| Full vitest suite, **sequential** (`--maxWorkers=1`) | **883/884** — the 1 failure is a pre-existing `uptimeSec=0` timing flake in `tests/contract/health-envelope.test.ts` (file untouched by Phase 7.2; reproduces identically at the baseline checkpoint) |
| Isolated per-file runs of every live-API suite | session-governance 14/14 · permission-matrix 135/135 · fault-injection 35/35 · booking-semantics 5/5 · financial-atomicity 5/5 · offer-concurrency 8/8 · money-cap 7/7 · attribution 11/11 · public-capture 15/15 · document-security 15/15 · demo-isolation 5/5 · closure-value 3/3 · notification-optimization 5/5 · services-contract 10/10 · observability 9/9 · payment-idempotency 5/5 · lead-score 6/6 · route-export-contract 2/2 |
| Baseline comparison (checkpoint `1d20b9d`, changes stashed, same environment) | parallel full suite fails **34 tests** vs Phase 7.2's 14–28 — pre-existing environmental contention, Phase 7.2 strictly improves it |

## 5. Tests not executable (and why)

- **Parallel full-suite green run** — pre-existing sandbox condition: 12 workers + the dev server contend for the 4 GB no-swap budget and the single SQLite writer; the kernel OOM-reaper kills `next-server` mid-suite (dmesg: `Killed process … next-server … anon-rss:1728040kB`) and cross-file fixture races produce fast assertion failures. Reproduces **identically at the Phase 7.1 baseline** → not a Phase 7.2 regression. The sequential run (883/884) is the authoritative gate.
- The owner's literal Publish click + personal hosted login — owner-only actions (see the final gate).

## 6. Incident during verification (disclosed)

- The dev server was OOM-killed twice while sharing the box with production
  builds / the browser / parallel suites (the documented A-1 sandbox law). Each
  time it was restarted and re-verified; the final state has the dev server
  healthy on the seeded baseline (`GET / 200`, demoUsers populated).

## 7. Owner actions required

Two: re-Publish, then complete the one-time owner setup (see the final acceptance gate).
