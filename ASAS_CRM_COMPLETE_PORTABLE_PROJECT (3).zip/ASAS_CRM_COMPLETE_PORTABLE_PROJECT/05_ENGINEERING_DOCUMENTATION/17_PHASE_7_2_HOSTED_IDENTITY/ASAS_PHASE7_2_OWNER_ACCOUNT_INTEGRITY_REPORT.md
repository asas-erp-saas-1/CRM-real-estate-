# ASAS — PHASE 7.2 — OWNER ACCOUNT INTEGRITY REPORT

**Mission:** determine whether the owner's account exists in the hosted database, and prepare a secure recovery path.
**Verdict:** **no account of any kind exists in the hosted database** — the owner's account was never shipped to it. A secure in-app recovery path is implemented and verified.

---

## 1. Observed evidence

- The published artifact DB holds `USER_COUNT: 0` (see the database identity report) — there is no user record to inspect: no email, no role, no status, no hash.
- The development DB was also empty at publish time (R13 wipe at 18:28, rebuild at 18:28:24–26 with migrations only). Whatever accounts existed in the pre-wipe dev DB are **gone from the sandbox** — and were never copied to the artifact either (the publish happened after the wipe).
- The exact owner email is **not present in any accessible task context**. Per the mission law it was not guessed; no account was provisioned on the owner's behalf; no password was reset.
- `nadia@asas.dz` (Phase 7.1) exists **only** in that phase's disposable test database — a reference point, not the owner's identity.

## 2. Account model integrity (mechanism review — all verified healthy)

| Check | Result |
|---|---|
| User model fields (`email` unique, `role`, `active`, `passwordHash` scrypt, `orgId` FK) | consistent; login queries `email + active` |
| Email normalization | `trim().toLowerCase()` at every write & read path |
| Duplicate users | impossible post-wipe (zero users); `email @unique` enforces it going forward |
| OWNER role assignment | `role: "OWNER"` string, constants verified |
| Historical OWNER provisioning mechanism | `scripts/provision-owner.ts` — idempotent, once-only, ≥12-char password, rejects the public demo password, never echoes secrets. **Could not be used directly: the owner has no terminal, and we must not know their password.** |
| Demo seed accounts | re-established in the **dev DB only** (idempotent seed); production seed refusal guard active (`NODE_ENV=production` → exit 1, zero writes) |

## 3. The secure recovery procedure (implemented)

The sanctioned CLI's laws are now executable **by the owner, in the app**:

**First-run OWNER bootstrap — `POST /api/auth/bootstrap`** (new):
1. Available **only** while the database holds zero users **and** demo mode is off
   (server-driven; re-asserted inside the write transaction — race-safe).
2. The owner opens the published app → the login screen renders a one-time
   **"Initial setup / الإعداد الأولي / Configuration initiale"** form: full name,
   owner email, password (≥12 chars), confirm password.
3. Password laws ported verbatim from `provision-owner.ts`: minimum 12 characters;
   the public demo password (`asas1234`) is refused; the password is **never**
   echoed, logged, audited, or stored anywhere except its scrypt hash.
4. Creates exactly ONE organization + ONE OWNER user — nothing else.
5. Rate-limited by the same DB-backed sliding window as credential login
   (5 failures / 15 min → 429).
6. Audited as `BOOTSTRAP_OWNER` (email, name, role, org identity — no secrets).
7. Issues the session cookie on success — the owner lands directly in the CRM.

**Why this shape:** any agent-side provisioning would require the owner's
password to transit chat/logs (forbidden), or saddle the owner with a
placeholder identity we invented (forbidden). The bootstrap keeps the owner's
credential entirely in their hands — the exact requirement of mission §4/Agent 3.

## 4. Verified behavior (isolated production-posture E2E + browser)

- bootstrap signal advertised only on a zero-user production instance;
- weak password → `422 BOOTSTRAP_WEAK_PASSWORD`; demo password → `422 BOOTSTRAP_DEMO_PASSWORD`;
- valid submission → 200, OWNER + org created, session issued;
- **credential login with the newly chosen password → 200**;
- second bootstrap attempt (any identity) → `404 BOOTSTRAP_UNAVAILABLE` — once-only forever;
- browser: setup form → submit → CRM dashboard; Arabic RTL and console clean.

## 5. Owner actions required

One action: after the next Publish, **claim the instance** by completing the
one-time setup form with the owner's own email and chosen password (≥12 chars).
No password is to be shared with anyone, including the team.
