# ASAS — PHASE 7.2 — HOSTED DATABASE IDENTITY REPORT

**Mission:** establish which database the published Z.ai application actually uses, and whether it contains the owner's account.
**Date:** 2026-11-08 · **Verdict:** hosted artifact database identified and directly inspected — it contains **ZERO users**.

---

## 1. Observed evidence

### 1.1 The publish build artifact (primary evidence)

The native Publish mechanism's build ran at **2026-11-08 18:34 UTC** in this sandbox:

| Artifact | Path | Timestamp |
|---|---|---|
| Build directory | `/tmp/build_fullstack_1794162808/` | Nov 8 18:34 |
| Packaged tarball | `/tmp/build_fullstack_1794162808.tar.gz` (57 MB) | Nov 8 18:34 |
| Artifact database | `/tmp/build_fullstack_1794162808/db/custom.db` (774,144 bytes, mtime 18:28) | copied from dev DB |

**Direct read-only inspection of the artifact's own database** (Prisma, `mode` read via isolated client):

```
ARTIFACT_DB_USER_COUNT: 0
ARTIFACT_DB_ORG_COUNT: 0
ARTIFACT_DB_MIGRATIONS: 25 (full chain applied, 36 tables)
```

This is the database the hosted runtime boots against — `start.sh` exports
`DATABASE_URL=file:/app/db/custom.db` and its guard only checks **file existence**
(the file exists, schema-only), so the hosted server starts, renders the login
screen, and answers `401 INVALID_CREDENTIALS` to **every** credential because the
`User` table is empty.

### 1.2 The causal chain (timeline, all timestamps UTC)

| Time | Event | Evidence |
|---|---|---|
| 18:27–18:28 | Sandbox container restored (boot timeline) | `/tmp/boot-timeline.log` |
| 18:28:24 | dev.sh R13 guard: `state: NO_DB` → rebuild | `.zscripts/dev.log` lines 25–36 |
| 18:28:24–26 | `bun run db:deploy` — **migrations only, NO seed** | dev.log `[BUN] Rebuilding database: 20-migration chain + canonical seed…` (the echo claims a seed that never ran) |
| 18:34 | Owner clicks Publish → build.sh runs | `/tmp/build_fullstack_1794162808` mtime |
| 18:34 | `database-runtime-build.sh` copies the zero-user dev DB into the artifact | script logic + artifact DB mtime 18:28 (preserved by `cp -a`) |
| post-18:34 | Hosted app boots, login screen renders, owner credentials rejected | owner report (task §1) |

### 1.3 Database identity fingerprint (non-sensitive)

| Dimension | Development DB (`/home/z/my-project/db/custom.db`) | Published artifact DB |
|---|---|---|
| Provider | SQLite (`file:`) | SQLite (`file:`) |
| Location | sandbox workspace, git-**ignored** (`/db/` in .gitignore) | baked into the deploy tarball → `/app/db/custom.db` |
| Migrations | 25 | 25 |
| Users (at publish) | **0** | **0** |
| Organizations (at publish) | **0** | **0** |
| Integrity | schema-valid | schema-valid |
| Writable | yes | yes (SQLite file in artifact) |

**Key law discovered and confirmed:** the platform's R13 restore law — *only
git-tracked files survive container restores* — applies to the **sandbox dev
workspace**; the untracked `db/custom.db` is wiped on every restore. The hosted
database is a **build-time copy** of whatever the dev DB contained at the moment
the owner clicks Publish.

## 2. Verified root cause

**The published database is not a "different" database with different accounts —
it is a byte-copy of a development database that had just been wiped and rebuilt
empty.** The owner's account does not exist in it because **no account at all**
exists in it. (Category 3 of the mission's differential list: *"Database
initialization or migration created an empty database"* — combined with the R13
wipe, category 4's path divergence is also implicated as the upstream trigger.)

The `nadia@asas.dz` account from Phase 7.1 existed only in an **isolated test
database** used for that phase's verification — it was never in the dev DB and is
not in the hosted DB.

## 3. Code changes / database changes

None in this report's scope (forensics only). The repair is specified in
`ASAS_PHASE7_2_REPAIR_AND_REGRESSION_REPORT.md`.

## 4. Owner actions required

None for identification. The repair phase requires one re-Publish (see the final
acceptance gate).
