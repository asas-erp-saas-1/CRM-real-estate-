# UX FINDINGS (Phase 2 audit)

Full evidence + screenshots: `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/UX_UI_AUDIT.md`, `download/qa-p2/`.

## Verdicts (10 live checks, Sarah/MANAGER, 1440×900 FR)
PASS: lead triage (drawer density, activity add, debounce) · pipeline stage change (+ lost-reason dialog) · global search ⌘K (arrow-nav, deep-link, Escape) · bulk copilot error handling (graceful rows, no crash — gateway recovered) · mobile 390×844 (scrollWidth=390 on all views; table→cards; calendar day agenda) · RTL Arabic (full mirroring, latin digits, AR login overlay) · console sweep (zero errors, no hydration warnings).
FRICTION: task/visit creation works but no delete exists; import preview works but auto-mapping banner is a no-op; dialog Escape drops focus to body.

## Bug list (all P3 — polish queue)
- B1 no delete for tasks or visits (no undo for accidental creation)
- B2 dialog focus not restored to trigger on close (create-lead, 2×)
- B3 activities immutable (no delete/edit)
- B4 import auto-map no-op + misleading banner
- B5 raw bulk-copilot error labels ("Échec · network"), no per-row retry
- B6 no unit picker in visit scheduling
- B7 bulk selection unreachable on mobile
- B8 possible duplicate lead "Mohamed Larbaoui" ×2 (see RISK_REGISTER)

## Preserve (works well — do not regress)
Focus rings + aria-invalid/describedby validation in create-lead · instant ⌘K with grouped results · lost-reason dialog flow · debounced filters with page-reset · toast feedback + react-query auto-refresh · calendar day agenda on mobile · AR overlay completeness.

## Recommended order (with B-fixes into roadmap Phase 3)
B2 (a11y focus, small) → B1+B6 (task/visit delete + unit picker — closes the creation loop) → B5 (error label mapping) → B4 (remove or implement auto-map) → B3 (activity delete for own entries) → B7 (mobile bulk via long-press or selection mode toggle).
