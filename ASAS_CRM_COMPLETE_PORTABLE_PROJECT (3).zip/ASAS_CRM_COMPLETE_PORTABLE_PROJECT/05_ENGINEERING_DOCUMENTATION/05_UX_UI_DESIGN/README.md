# 05_UX_UI_DESIGN

**Purpose (EN):** Design system, user journeys, UX decision log, UI audits.
**الغرض:** نظام التصميم ورحلات المستخدم وقرارات تجربة الاستخدام.
**Documents:** 15 · **Renamed from:** `ux`

| # | File | Title | Bytes |
|---:|---|---|---:|
| 1 | `DESIGN_SYSTEM.md` | DESIGN SYSTEM — ASAS CRM | 22,586 |
| 2 | `PHASE_C_DESIGN_PROPOSALS.md` | PHASE C — DESIGN PROPOSALS COMPARISON PACKAGE (2026-10-21) | 21,774 |
| 3 | `PHASE_D_LIFECYCLE_COHERENCE.md` | PHASE D — CRM Lifecycle Coherence & UX/UI Re-Architecture (2026-10-24) | 53,138 |
| 4 | `UI_AUDIT.md` | UI AUDIT — Phase 6 Stage 1 (current-state) | 14,394 |
| 5 | `UI_QA.md` | AS CRM — UI QA Baseline & Interaction States Matrix | 3,954 |
| 6 | `UI_REDESIGN_AUDIT.md` | UI/UX REDESIGN AUDIT — 2026-10-21 (UX/UI Audit Track, evidence-first, non-destructive) | 23,170 |
| 7 | `USER_JOURNEYS.md` | USER JOURNEYS — ASAS CRM | 6,013 |
| 8 | `UX_DECISION_LOG.md` | UX DECISION LOG | 162,044 |
| 9 | `UX_FINDINGS.md` | UX FINDINGS (Phase 2 audit) | 1,935 |
| 10 | `UX_MASTER_PLAN.md` | UX MASTER PLAN — Phase 6 (UX/UI Engineering) | 23,420 |
| 11 | `UX_TRANSFORMATION_PLAN.md` | UX TRANSFORMATION PLAN — Premium Role-Aware Real-Estate CRM | 6,885 |
| 12 | `VISUAL_IMPROVEMENT_PLAN.md` | AS CRM — Visual Improvement Plan (Universal UI System) | 16,108 |
| 13 | `WAVE_2B_OWNER_DECISION_BRIEF.md` | WAVE 2B — LEAD INLINE EDITING: OWNER-DECISION BRIEF (2026-10-22) | 10,394 |
| 14 | `WAVE_3_OWNER_DECISION_REQUESTS.md` | WAVE 3 — OWNER DECISION REQUESTS: COMMISSION BASIS & CLOSURE ECONOMICS GATE (2026-10-23) | 12,972 |
| 15 | `WAVE_3_READINESS_REVIEW.md` | WAVE 3 — API EXTENSIONS: READINESS REVIEW (2026-10-22, proposals only) | 9,458 |

--- Part of `ASAS_CRM_COMPLETE_PORTABLE_PROJECT/05_ENGINEERING_DOCUMENTATION` — see root `README.md` for the master index.
