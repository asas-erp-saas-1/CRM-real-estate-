# PHASE D — CRM Lifecycle Coherence & UX/UI Re-Architecture (2026-10-24)

**Status: EXECUTING.** The owner's directive (Phase D, on file at `upload/Pasted Content_1792811796192.txt`)
explicitly authorizes a broad UX/UI architecture decision for this UX track — superseding the
Phase-C-era "no broad visual redesign" instruction — while preserving every business-rule gate
(D5 commission basis · D6 closure economics · Wave-2B lead-editing · demo-mode), the P5 production
gates, and all server authorization/audit/financial contracts.

**Method:** two coordinated discovery passes (D1-a lifecycle/code inventory · D1-b UX-surface +
coherence-gap inventory, both file:line-cited in the worklog UX-PHASE-D record) over the live tree
at HEAD `b82b8ec`, reconciled with the canonical domain docs. This file is the Phase D record:
gap model → decision → implementation plan. It EXTENDS (never duplicates) the canonical sources:
`05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/WORKFLOW_SPECIFICATION.md` (state machines — GOV-3, re-verified by D1-a),
`05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/DOMAIN_MODEL.md` (entity map), `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/USER_JOURNEYS.md` (personas/journeys),
`05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/DESIGN_SYSTEM.md` (visual system), `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md` + `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/UX_DECISION_LOG.md`.

---

## 1. The coherence-gap inventory (verified evidence, not opinion)

### 1.1 What is already coherent (and must not be regressed)

- **The domain layer is strong**: every lifecycle is a server-enforced state machine (LEAD_TRANSITIONS
  with the manager-correction hatch · OPPORTUNITY forward-only adjacency with the §9.2 desync law ·
  the VISIT matrix with the 3-way pending partition · the reservation two-step closure with
  concurrency-guarded validate · apartment↔reservation coherence), all transactional, all audited —
  proven by the standing 325-probe matrix (re-run 325/325 at `b82b8ec`).
- **The visual layer is coherent**: one shared badge module (`src/components/crm/badges.tsx`) renders
  lead/visit/apartment/priority/source/doc statuses through centralized tone maps
  (`src/lib/constants.ts`) everywhere; DESIGN_SYSTEM.md is the living token source.
- **A real cross-entity spine exists**: visits/tasks/kanban/dashboard/demand-panel/palette all reach
  the customer drawer (`openLead`); the attention strip's aggregate→isolate deep-links (Wave 3A) are
  exact-set verified.

### 1.2 The structural gaps (the owner's complaint, located precisely)

| # | Gap | Evidence |
|---|---|---|
| G-1 | **No per-customer "next action" surface.** The four pending carriers (follow-up date, nearest task, next visit, deal nextAction) + reservation expiry are NEVER composed; the drawer's info band carries 3 lead-owned carriers only; the AI copilot is an unmerged fifth voice | lead-drawer-info.tsx:103-203 (band); lead-tab-opportunities.tsx:110-115 (opp nextAction buried in tab); no reservation carrier anywhere |
| G-2 | **The reservation is invisible in the customer's own workspace.** `LeadDetail` has no reservations field; the drawer never fetches it; a customer with a RESERVED unit shows nothing | client/types.ts:558-568; GET /api/leads/[id] aggregate has no reservation join |
| G-3 | **The journey state is never shown side-by-side.** Lead status (header) and deal stage (opp tab) and reservation status (nowhere) live on three different surfaces — Q4 of the workspace audit is PARTIAL | lead-drawer-header.tsx:145-199 vs lead-tab-opportunities.tsx:85 |
| G-4 | **Reaching the customer destroys the working context.** `openLead` is a VIEW SWITCH (store.ts:172-177): clicking a lead name on a visit/task/kanban row abandons the current view; `setView` nulls `leadId` on every view change (store.ts:165-171). The "current customer" evaporates on every navigation | store.ts:165-183; the drawer mounts ONLY inside LeadsView (leads-view.tsx:646) |
| G-5 | **Dead ends inside the per-customer surface.** Drawer opportunity rows have NO open affordance (lead-tab-opportunities.tsx:75-119 — unlike the kanban card's OpportunityOpenButton); timeline VISIT/RESERVATION rows are static text | D1-b inventory §2/§3 |
| G-6 | **Reservation/incentive statuses render off-system** (bespoke single-tone chip in deal-economics-closure.tsx:101-106; file-local IncentiveStatusChip) — the only two statuses without a shared badge | badges.tsx has no ReservationStatusBadge |
| G-7 | Record-blind surfaces: audit entityId dead text (audit-view.tsx:451-453); analytics has zero record links; visit unit-chips are dead badges (visit-row.tsx:151-166); task→opportunity link never rendered | D1-b §3 |

### 1.3 Root-cause reading

The domain model and the visual system are NOT the defect. The missing layer is **workflow
composition**: the app is organized as nine parallel list/management surfaces plus ONE per-customer
surface (the drawer) that (a) does not compose the pending state, (b) is not reachable without
abandoning context, (c) contains dead ends. No local fix composes five next-action carriers or makes
`openLead` non-destructive — that is an information-architecture property.

---

## 2. The cross-lifecycle event & side-effect map (the D2 addition)

The full state machines remain canonical in WORKFLOW_SPECIFICATION.md §3-§8 (re-verified byte-identical
in behavior by D1-a against live code). The NEW model piece Phase D adds is the **cross-domain effect
law** — for each business event: what it changes, and what it must NEVER change implicitly:

| Event (actor) | Changes | NEVER implicitly changes |
|---|---|---|
| Lead status → CONTACTED..QUALIFIED (in-scope user) | lead.status + STATUS_CHANGE activity + audit | opportunity stages, visit states, ownership |
| Lead → CONVERTED (convert flow) | Contact + Opportunity(QUALIFIED) + lead flip + CONVERSION activity — one tx | unit availability, money |
| Lead → CLOSED_LOST (reason-gated) | lead + lostReason/lostAt | open tasks (stay actionable), reservations (money path unaffected) |
| Visit → COMPLETED (outcome-gated) | visit + FOLLOW_UP task auto-create (+24h, idempotent) | deal stage (no auto stage-change — the approved law), unit status |
| Visit decision events (confirm/reject/counter/reconfirm) | visit stamps + audits, authority-gated | deal stage, lead status |
| Opportunity stage change (forward-only) | stage + stageChangedAt + terminal stamps (probability forced 100/0) | unit availability (only reservation lifecycle owns it) |
| Reservation created (agent) | Reservation(ACTIVE) + apartment→RESERVED — one tx | commission fields (§37/§38 separate surface, MANAGER+) |
| request_closure (responsible agent) | CLOSURE_REQUESTED + evidence + audit | unit, money, deal stage |
| validate_closure (MANAGER+) | CONVERTED + apartment→SOLD + opp→CLOSED_WON — ONE guarded tx | commission amounts (never side effects — the §38 law) |
| cancel / expire | CANCELLED/EXPIRED + apartment→AVAILABLE (if still RESERVED) | opportunity stage (stays where it was; the §9.2 desync guard blocks reopening CLOSED_WON backed by a sale) |
| Owner/assignment change (MANAGER+) | ownerId + audit | record history, status |
| Archive/restore (owner-or-MANAGER) | archived flag + audit | statuses, relations, tasks |

**Composition rule for the workspace (the D6 law):** the customer workspace is a READ-side
composition of these events' effects + a WRITE dispatch to the same authoritative endpoints. It adds
no new business transitions, duplicates no state, and performs no client-side authorization.

---

## 3. Service blueprints (D3 — the ten mandated scenarios, reconciled to USER_JOURNEYS.md)

Each row: the journey's honest state today (verified) → the Phase D treatment.

| # | Scenario | Today (verified) | Treatment |
|---|---|---|---|
| S1 | New lead → assign → first contact → qualify → next action | Intake + assignment + qualification work; next-action is scattered (G-1) | Workspace next-action panel composes the carriers (D6) |
| S2 | Qualified → visit → outcome → follow-up | Strong server machine (outcome-gated completion + auto FOLLOW_UP); the *customer view* of it is scattered | Panel surfaces next visit + its follow-up task together (D6) |
| S3 | Interest → opportunity → negotiation → reservation | Deal cockpit strong; **the customer's own workspace never shows the reservation** (G-2/G-3) | Journey strip + reservation row (D6, additive server field) |
| S4 | Reservation cancel/expire → inventory restored | Server-correct (one-tx release); invisible per-customer | Reservation row shows status incl. CANCELLED/EXPIRED (D6) |
| S5 | Closure → validation → audit | Two-step governance intact; economics-completeness = owner gate D6 | NOT implemented — decision request stands (WAVE_3 doc) |
| S6 | Lost → reason → recycle | Reactivation flow works; per-customer view partial | Journey strip shows terminal state honestly (D6) |
| S7 | Rep reassignment → history → work transfer | Owner switch audited; open tasks keep owner (documented behavior) | Documented as-is; no invented auto-transfer (D7 backlog: surface overdue-per-rep) |
| S8 | Archive → restore → continued access | Wave 2A complete (undo, isolation verified) | Unchanged; reachable from workspace context |
| S9 | Failed request / stale edit → honest recovery | Visit edits have the §26 stale-guard; lead PATCH is last-write-wins (documented Wave-2B gap) | Failure paths unchanged; the workspace renders server errors verbatim (ErrorState) |
| S10 | Manager oversight → exception → intervention | Attention strip is aggregate-exact (Wave 3A); the *per-record* intervention lacks context preservation (G-4) | Overlay drawer keeps the manager's working view (D6) |

---

## 4. THE ARCHITECTURE DECISION (D4 — required engineering decision)

**Recorded as `D-UX-PD-1` in `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/UX_DECISION_LOG.md`. Verdict: bounded Path B —
a workflow-layer re-foundation on the retained visual and domain foundations.**

- **Path A (pure incremental repair) — REJECTED on evidence**: the four top gaps (G-1..G-4) are
  architectural properties of the current information architecture (a drawer mounted inside one
  list view, a view-switching `openLead`, an aggregate contract without the reservation, no
  composition surface). Patching them screen-by-screen would layer five special-case bands and
  cross-view hacks — exactly the "accumulating conditional logic" the directive names as the
  Path-B trigger.
- **Full visual teardown — REJECTED on evidence**: the visual/component layer is measurably coherent
  (shared badges/tone maps/primitives; the Phase-C audit's verdict stands: a radical visual rewrite
  is NOT supported by evidence). A cosmetic rewrite would destroy working polish without touching
  the actual defect class.
- **The selected path**: re-found the *workflow layer* — (1) the customer workspace becomes the
  per-customer operational hub composed from the authoritative aggregate (one query, D-021-scoped);
  (2) the workspace becomes an OVERLAY reachable from every surface without view switches;
  (3) the shared visual system is extended where the workflow needs it (the reservation badge);
  (4) the remaining linkage dead-ends (G-5..G-7) migrate in dependency-ordered batches (§7) onto the
  stable workspace pattern. Working list/management surfaces are preserved — they are the correct
  shape for their jobs; what changes is that they stop being *walled gardens*.

**One additive server change is authorized by the evidence** (the documented contract gap, Wave-3B
law — "smallest correct solution; document the exact gap"): `GET /api/leads/:id` gains a
`reservations` array (join via the lead's opportunities; minimal DTO). Additive only: every existing
consumer is unaffected (the response gains a key); no schema change; no new transitions; the D-021
scope is inherited from the already-scoped lead read. Full rationale in §6.

---

## 5. Information architecture & design-system foundation (D5)

**IA model (the workspace-centric architecture):**

- **Layer 1 — Management surfaces** (the nine views): lists, boards, calendars, aggregates. Their job:
  triage, oversight, bulk work. Preserved as-is (plus linkage fixes in §7).
- **Layer 2 — The customer workspace** (the drawer, promoted): THE per-customer operational surface —
  identity, ownership, full journey state, the composed next action, related records, role-aware
  actions. Reachable as an **overlay from any Layer-1 surface** (context preserved); deep-linkable
  in the leads context (`#/leads/:id` unchanged); session-transient elsewhere (same law as every
  dialog — ids never outlive the session).
- **Layer 3 — Record dialogs** (opportunity cockpit, unit dialog, visit fiche): depth on a single
  record, opened FROM Layer 2 rows without losing the workspace (the D6 slice wires the opportunity
  cockpit; unit/visit follow in §7).

**Design system**: DESIGN_SYSTEM.md remains canonical. Phase D adds: `ReservationStatusBadge` in the
shared badges module (tone map in constants.ts — retiring the last off-system status chip), and the
workspace band/strip patterns (journey strip, next-action rows) as named conventions in §7 of that
file when the rollout stabilizes them.

---

## 6. The D6 vertical slice — the Customer Workspace (implemented this wave)

Scope (each item maps to a gap): journey strip (G-3) · unified next-action panel composing
follow-up + nearest task + next visit + deal nextAction + reservation expiry (G-1) · the reservation
surfaced per-customer via the additive aggregate field (G-2) · the drawer mounted at the shell level
with non-destructive `openLead` (G-4) · drawer opportunity rows open the real deal cockpit (G-5) ·
the shared ReservationStatusBadge (G-6). Server: one additive field, contracts otherwise frozen.
Owner gates (D5/D6/2B/demo) untouched. Tests: a new probe suite (the additive contract + scope) +
browser E2E (overlay behavior, composition correctness, roles, AR-RTL, mobile).

## 6a. The D7-R1 batch — visit ↔ unit operational integration (IMPLEMENTED & VERIFIED 2026-10-24)

Commits `b1f25ce` (feat) + `754fee4` (test/evidence). **G-7's first kill: the visit-row dead badges
are now the live link into the canonical unit experience.**

- **The relationship (proven, not inferred)**: `VisitApartment` — the server-enforced join (POST
  validates org membership + OPEN status + single-project consistency, committed with the visit in
  one tx). The visit DTO carries the fragments `{id, code, unitType, status}` (status CURRENT at
  list time — proven 41/41 against the join by the D7-R1 suite).
- **The one shared component** (`visits/visit-unit-chips.tsx`) on ALL THREE carrying surfaces:
  visits rows · the calendar day agenda · the drawer's visits tab. It resolves the AUTHORITATIVE
  fragment **id** through the canonical org-scoped inventory endpoint (`query=` code-contains +
  exact-id filter — a code collision can never open the wrong unit, adversarially probed), opens
  THE canonical `ApartmentDetailDialog` (no second implementation), and preserves the workspace
  underneath (no view switch — the D-UX-064 overlay law; the drawer stacks per the D-UX-020 law).
- **Freshness**: token-scoped query key under the `['apartments']` invalidation prefix — every open
  is a live server response; mutations elsewhere refresh an open dialog through the standard
  TanStack invalidation (no polling). A SOLD-after-scheduling unit shows its CURRENT status.
- **Honest states**: no-unit visits render nothing (no meaningless chips) · loading = skeleton with
  the truthful code · unavailable = "cannot be obtained" (never a fallback entity) · fetch error =
  verbatim server truth + safe retry (a read). Focus restores to the exact chip (the dialog swap
  defeats Radix's auto-return — an explicit trigger capture fixes it).
- **Gates**: lint 0 · tsc 4 tolerated (src/ 0) · matrix 325/325 · Wave suites 21/21 + 22/22 + 55/55 ·
  Phase D 15/15 · NEW D7-R1 suite 17/17 (`pd-d7r1-regressions.ts`, self-contained w/ canonical
  byte-exact closing sweep) · browser E2E console-0 (round-trip, drawer stack, error/unavailable/
  retry, AR-RTL, mobile 390 no-overflow, keyboard focus return) · **independent adversarial
  verifier: all 10 acceptance items CONFIRMED** (4 minor observations recorded in the worklog —
  incl. the pre-existing nondeterministic initial focus inside the canonical dialog: a follow-up
  hardening candidate, NOT a D7-R1 regression).
- **Localization audit** (the directive's suspected Arabic error): `lead.journey.aria` =
  «الموقع في دورة الحياة» — codepoint-verified CORRECT (الحياة with taa-marbuta U+0629, not the
  suspected ه U+0647); the neighboring lifecycle labels are valid; rendered AR-RTL re-verified live.

## 6b. The D7-R2 batch — the timeline as a navigation layer (IMPLEMENTED & VERIFIED 2026-10-24)

Commits `4e2aefb` (feat) + the test/evidence commit + `b64dcb6` (verifier hardening). **G-5's second
kill: the drawer timeline's VISIT/RESERVATION static rows are now live navigation.**

- **The relationship (proven, not inferred)**: the server's `logActivity` has ALWAYS persisted the
  authoritative entity id on every event row (`visitId`/`taskId`/`opportunityId`/`reservationId` —
  schema + creation sites re-verified; the v1 lead aggregate serializes them — wire-probed on the
  live API). **Zero server change**: the batch is client-only; `client/types.ts` declares what the
  wire always carried. DB coverage: 98/98 navigable rows carry their ids.
- **The canonical destination map** (a small typed resolver in `lead-tab-activities.tsx` — never
  title/name/code matching):
  - **VISIT → THE `VisitFicheDialog`** (the same component the visits view and the drawer's visits
    tab mount). It self-fetches `GET /api/visits/:id` (D-021-scoped — the server is the authority);
    a dangling reference surfaces the fiche's own honest ErrorState (visit deletion SetNulls the
    activity's visitId — the FK law, adversarially probed).
  - **RESERVATION · STAGE_CHANGE · CONVERSION · INCENTIVE → THE deal cockpit**
    (`OpportunityDetailDialog` — the same component the pipeline and the drawer's opportunities tab
    mount), resolved by id-equality against THIS lead's aggregate opportunities (already inside the
    D-021-scoped read); the cockpit self-fetches the reservation through the canonical org-scoped
    endpoint. A dangling opportunity renders the row non-navigable (no fabricated shell).
  - **TASK → the drawer's own authoritative Tâches surface** (tab switch + exact-row
    scroll/focus/ring handoff — the real state + the real completion mutation live there; no second
    task-detail implementation).
  - Every other type (NOTE/CALL/WHATSAPP/…/MERGE) has NO supported destination → honestly static.
- **Historical vs current never merge**: the row stays the event; the dialogs show the record's
  CURRENT server state (the A-01 booking row vs the cockpit's CONVERTED reservation — probed).
- **Overlay law**: dialogs stack above the drawer Sheet; Escape dismisses ONE layer; focus restores
  to the exact invoking row button (the D7-R1 explicit-trigger-capture idiom — the async content
  swap defeats Radix auto-return); the leads list's search/hash survive the full round-trip.
- **Gates**: lint 0 · tsc 4 tolerated (src/ 0) · matrix 325/325 · Wave suites 21/21 + 22/22 + 55/55 ·
  Phase D 15/15 · D7-R1 17/17 (re-run — not regressed) · NEW D7-R2 suite 10/10
  (`pd-d7r2-regressions.ts`, self-contained, byte-exact closing sweep) · browser E2E console-0
  (all five destinations + keyboard + AR-RTL with Arabic aria labels + mobile 390 no-overflow +
  persistent-fetch-fault honest error → retry-recovered + one-at-a-time Escape + triple-click
  idempotency) · **independent adversarial verifier: all 10 acceptance items CONFIRMED** with 6
  adversarial attacks attempted; its 3 observations: (1) MINOR a11y — identical aria-labels across
  same-destination rows → FIXED in `b64dcb6` (the row title now rides the accessible name);
  (2) PRE-EXISTING (Oct 2, D7-R2-untouched): on demo session hot-switch without reload the drawer
  can render the previous user's CACHED aggregate — display-only, the server boundary is intact,
  reload shows the honest error; a follow-up hardening candidate (session-scope/clear the
  `["lead",…]` react-query cache on user switch); (3) PRE-EXISTING wording: the shared ErrorState
  says "API non encore disponible" for transient network faults — honest but misleading phrasing.

## 6c. The D7-R3 batch — the audit journal as a navigation layer (IMPLEMENTED & VERIFIED 2026-10-24)

Commits `91a85f1` (§7 session-isolation fix) + the feat commit (API id-filters + resolver + overlay +
view wiring + i18n) + the test/evidence commit. **G-5's third kill: the audit journal's entity
identities become live navigation to the canonical record surfaces.**

- **The identity (proven, not inferred)**: `logAudit` has ALWAYS persisted the typed identity pair
  (`entity` discriminator + `entityId`) on every row — schema + all 40+ creation sites re-verified.
  The audit endpoint is MANAGER+ and org-scoped server-side; target authorization is separate and
  rides each destination's own canonical endpoint (D-021 / org conditions — R3-D04).
- **The canonical destination map** (a PURE typed resolver —
  `src/components/crm/audit/audit-destinations.ts`; the input is the smallest structural
  projection of the row: there IS no name/title field, wrong-target-by-name is unrepresentable):
  - **LEAD → THE shell customer workspace drawer** (`openLead`, the D-UX-064 overlay contract —
    reachable from every view; the drawer self-fetches `GET /api/leads/:id`, D-021-scoped; a
    dangling target surfaces the drawer's own honest ErrorState).
  - **VISIT → THE `VisitFicheDialog`** (self-fetching `GET /api/visits/:id`; the same component the
    visits view and the drawer mount — live-verified from a scratch `VISIT_RESET_TO_SCHEDULED`
    row created through the canonical executive-reset API).
  - **OPPORTUNITY → THE deal cockpit** (`OpportunityDetailDialog`) — exact-id resolved through the
    canonical org/D-021-scoped list.
  - **APARTMENT → THE `ApartmentDetailDialog`** — same exact-id resolution law.
  - **RESERVATION → the parent deal's cockpit** (the D7-R2-accepted inspection surface): two
    authoritative hops — `reservationId → opportunityId` through the canonical reservation read,
    then the deal by exact id (network-traced live: `reservations?id=… → opportunities?id=…`).
  - **The ONE server change** (R3-D08, minimal + additive): an exact `id` filter on
    `GET /api/opportunities`, `GET /api/properties/apartments`, `GET /api/reservations` — the
    condition INTERSECTS the existing org + D-021 scope (an out-of-scope id yields an EMPTY page,
    never a leak; probed: agent-vs-manager on a peer opportunity, anonymous 401, cross-org scratch
    chain). No endpoint, schema, migration, or authorization change.
  - **Fail-closed by construction**: batch rows (import/export/bulk — null `entityId`),
    self-declared-deleted targets (`VISIT_DELETED`/`OPPORTUNITY_DELETED`/`TASK_DELETED`/
    `ACTIVITY_DELETED` — a guaranteed-404 navigation is noise, not an operation), and unsupported
    entities (USER/PROJECT/CONTACT/PIPELINE/`PipelineStage`/ACTIVITY/SAVED_SEARCH/ORG — no
    canonical record-detail surface) stay honestly static.
- **Historical vs current never merge**: the audit row IS the event (its before/after JSON stays
  byte-exact under reads — probed on A-01's historical AVAILABLE→RESERVED row) while the opened
  surface shows the record's CURRENT state (A-01 now SOLD; the N-31 dialog shows Vendu against the
  historical Disponible→Vendu chips).
- **Overlay law**: the destination overlay hosts the canonical dialogs inside the audit view (no
  view switch — search/filters/page/scroll are component state and survive); the LEAD drawer mounts
  at the shell per D-UX-064; the `EntityTargetCell` button is a SIBLING of the R8-3 undo control
  and announces destination + action + entity + short id (the D7-R2 verifier's distinguishability
  hardening); focus restores to the exact initiating control (explicit-trigger-capture for the
  dialogs; Radix Sheet auto-return for the drawer — both live-verified).
- **§7 session-isolation fix** (`91a85f1`): the D7-R2 verifier's PRE-EXISTING hot-switch finding was
  re-tested on THIS batch's navigation path — the fix replaces `invalidateQueries()` (stale-marking)
  with `resetQueries()` at the three user-transition sites (login / persona switch / logout):
  post-switch the drawer shows its honest 404 ErrorState instead of the previous session's cached
  aggregate (reproduced live: Nadia views Lina's lead → switch to Amine → same hash → honest error,
  and Amine's own records still load fresh).
- **Gates**: lint 0 · tsc 4 tolerated (src/ 0) · matrix 325/325 · Wave suites 21/21 + 22/22 + 55/55 ·
  Phase D 15/15 · D7-R1 17/17 + D7-R2 10/10 (both re-run — not regressed) · NEW D7-R3 suite 10/10
  (`pd-d7r3-regressions.ts`: identity census · 23-case resolver table incl. name/actor injection ·
  same-name adversarial · cross-type coincident-id · five-destination canonical agreement incl. the
  reservation two-hop + dangling 404 + scratch-visit happy path · authorization · historical
  immutability · cross-org isolation · read-only residue · byte-exact closing witness) · browser E2E
  console-0 (all five destinations + honest unavailable/error/retry + context+focus preservation +
  keyboard + AR-RTL w/ the Arabic gender-agreement fix «لا يمكن الوصول إلى {entity}» + mobile 390
  no-overflow + the hot-switch repro fixed) · residue byte-exact (the SetNull orphan sweep included).

## 7. The D7 rollout roadmap (dependency-ordered, after the slice lands)

| Batch | Content | Files (owner) | Gate |
|---|---|---|---|
| **R1** | **DONE 2026-10-24** — visit rows' unit chips open the canonical unit dialog (see §6a) | visits/visit-row.tsx, lead-tab-visits.tsx (+ calendar-day-agenda.tsx, visit-unit-chips.tsx new) | 17/17 + E2E + independent verify |
| **R2** | **DONE 2026-10-24** — timeline click-through: VISIT→the fiche, RESERVATION/STAGE_CHANGE/CONVERSION/INCENTIVE→the deal cockpit, TASK→the drawer's Tâches surface (see §6b) | lead-tab-activities.tsx (+ lead-tab-tasks.tsx handoff, lead-detail-drawer.tsx props) | 10/10 + E2E + independent verify |
| R3 | **DONE 2026-10-24** — audit entityId → record navigation: LEAD→drawer, VISIT→fiche, OPPORTUNITY/APARTMENT→exact-id dialogs, RESERVATION→parent-deal cockpit; ?id= filter ×3 (see §6c) | audit-view.tsx (+ audit/ resolver+overlay, 3 API routes, i18n) | 10/10 + E2E + independent verify |
| R4 | **DONE 2026-10-24** — Task→opportunity link (taskInclude fragment + the exact-id chip → THE cockpit, both task surfaces) + the visits-toolbar lead facet (the server's ?leadId= contract, both modes); the verifier's D1 (the dead Wave-3B owner filter) fixed (see §6d) | tasks-view.tsx, lead-tab-tasks.tsx, visits toolbar (+ tasks/task-opportunity-chip.tsx, visits/visits-lead-facet.tsx new) | 14/14 + E2E + independent verify ×2 |
| R5 | **DONE 2026-10-24** — the honest-static outcome (see §6e): the preflight proved the analytics contract carries ZERO record ids (every top-list is a dimension/entity-keyed aggregate; `agentId`→USER is the only entity id and the accepted D7-R3 resolver law fail-closes USER) — no invented destinations, all rows honestly static, and the verification battery instead | analytics-tables.tsx (ZERO src change — the verified boundary) | 7/7 + E2E + independent verify |
| R6 | **DONE 2026-10-25** — the audited-already-canonical + two-adoptions outcome (see §6f): R6A's preflight proved the economics panels' navigation was ALREADY canonical (P46 queue + P48 commissions rows open THE cockpit by the payload's authoritative DTO; the agent panel is a pure aggregate — the R5 law) → zero R6A src change by finding; R6B landed the two remaining adoptions: the closure header's reservation status through the SHARED ReservationStatusBadge (G6's last off-system chip retired) + the apartment dialog reservation block's Client row as the canonical customer link (openLead by the authoritative lead.id) | deal-economics-closure.tsx, apartment-detail-dialog.tsx, properties.ts i18n (3 files, 53+/7−) | 7/7 + E2E + independent verify (12/12) |
| R7 | Rep workspace (per-rep overdue/ownership view — S7) — NEW SURFACE, needs an owner scope check first | new module | matrix + E2E |

Each batch: small commit · standing matrix + feature suites re-run · browser E2E incl. AR-RTL +
mobile 390 · byte-exact residue. None touches server contracts unless a gap is documented first.

## 8. Owner decisions register (unchanged, plus Phase D additions)

Open: **#1** wave order · **#2** Wave-2B scope (brief ready) · **#3=D5** commission % basis ·
**#4=D6** closure economics gate · **#5** demo-mode. Phase D isolates (does not resolve):
**#6** rep-workspace scope (R7 — what may a manager see/do per-rep beyond existing D-021 scoping?)
· **#7** lead-PATCH stale-guard (the Wave-2B brief's sub-item, restated by S9).

> **ADDENDUM 2026-10-25 (UX-OWNER-PLAN-1 — the owner's decision-reconciliation directive):** the
> #1–#7 list above is now RECONCILED in the canonical register
> `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md`: **#2** RESOLVED-BY-DIRECTION (Wave-2B safe fields
> approved — primary phone AND customer name excluded — with formal audit + timeline for in-scope
> identity edits and the stale-guard approved in principle, backward-compatible) · **#3=D5**
> RESOLVED-BY-DIRECTION (calculation helper + manager confirm/edit; NO authoritative
> rate/percentage/formula) · **#4=D6** RESOLVED-BY-DIRECTION (warn + reason-gated audited waiver;
> completeness = amount + payer + incentive + written bases; zero+basis = not-due) · **#5**
> RESOLVED-BY-DIRECTION (demo-mode OFF by default, dev opt-in; production unauthorized) · **#7**
> RESOLVED-BY-DIRECTION (the stale-guard direction) · **#1** SUPERSEDED (the wave framework is
> replaced by the Phases A–H plan proposal — `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/NEXT_PHASE_PLAN.md` — pending the
> owner's approval of the plan itself) · **#6** OPEN with direction partially given by **D-OWNER-01**
> (a representative workspace MAY include management actions; the precise action set NOT approved —
> questionnaire Q6). Detailed sub-decisions: `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_FORM.md` Q1–Q9. This
> section's historical text is preserved verbatim above (append-only law). R7 remains gated on #6.

Production remains NOT PRODUCTION-READY; the P5 gates are untouched.

## 6d. The D7-R4 batch — Task→Opportunity + the Visits lead facet (IMPLEMENTED & VERIFIED 2026-10-24)

Commits `e64ed64` (feat — both sub-batches) + `fa82eb4` (test — suite + evidence) + `7433523` (fix —
the verifier's D1). **G-5's fourth kill: the task's authoritative opportunity association becomes the
live link into the canonical deal cockpit, and the Visits toolbar isolates a customer's visits in one
selection — the manual re-find dies on both surfaces.**

### D7-R4A — the task → opportunity relationship

- **The relationship was ALWAYS there (proven, not built)**: `Task.opportunityId` — a typed nullable
  FK, validated at POST under `oppScope` (D-021, 404 on out-of-scope) since the route's inception.
  R4-D02's foundational-spec question (polymorphic ownerType/ownerId) is answered by the accepted
  model: typed FKs. The ONLY defect was that NO surface exposed the association — the §3.1
  "association exists, UI omits it" case: EXPOSE, no schema change, no migration, no duplicate
  relationship state.
- **The ONE minimal additive change** (the include law the lead/owner fragments always followed):
  `taskInclude` now carries `opportunity: { id, title, stage }` on `GET /api/tasks`,
  `PATCH /api/tasks/:id`, and the lead aggregate's tasks — the drawer's Tâches tab and the Tasks view
  read the same fragment (one contract; the owner-created 201 response carries it too).
- **The chip** (`tasks/task-opportunity-chip.tsx` — the D7-R1 visit-unit-chips idiom): renders ONLY
  when the association exists (a task without one is a VALID state — no misleading affordance);
  navigates by the AUTHORITATIVE id through the canonical `GET /api/opportunities?id=` (the D7-R3
  scope-intersecting filter — a same-title pair can never cross-resolve, an out-of-scope/missing id
  yields the honest unavailable dialog, never a fallback); fresh per open (token-scoped key under
  `["opportunities"]`); THE `OpportunityDetailDialog` (no second implementation); honest
  loading/unavailable/error+retry states; explicit-trigger-capture focus restoration (exact chip on
  view surfaces; in-drawer focus follows the R1-accepted sheet-re-engagement contract — verified
  byte-identical to the D7-R1 chip's drawer behavior). Navigation is a SIBLING of the completion
  controls and triggers ZERO mutations — DONE semantics byte-identical (suite-probed: the activity
  carries the same authoritative ids, the opportunity row stays byte-identical, reopen logs nothing).
- **Wired on BOTH canonical task surfaces**: the Tasks view rows + the drawer's Tâches tab (the
  cockpit stacks above the Sheet per D-UX-020, like the drawer's own opportunities tab).

### D7-R4B — the Visits toolbar lead facet

- **The server ALREADY supported it**: `?leadId=` on `GET /api/visits` (AND-composed with the
  org + D-021 `visitScope` + every other facet since the v1 contract) — ZERO server change; the
  toolbar wires into the existing contract (the directive's "server already supports it" case).
- **The facet** (`visits/visits-lead-facet.tsx`): the established `Combobox` + the schedule-visit
  dialog's own lead picker dataset (`GET /api/leads?pageSize=100`, leadScope-scoped, shared
  `["leads","combobox"]` cache — covered by the R3 session-transition `resetQueries` law); items
  resolve to the EXACT lead id with the phone hint for same-name disambiguation (the two seeded
  Mohamed Larbaouis are two distinct options); the explicit clear removes ONLY the lead condition
  (status/agent/P49/P50/unstaffed/range survive — wire-verified: only `leadId` leaves the query);
  rides the per-user workspace store (owner-key isolation reset clears it on every account/role
  switch); reaches BOTH modes (list + the calendar's own query — the P49/P50 precedent, wire-verified
  with month bounds + leadId); the count line reads the server's truthful filtered total; a
  zero-match lead is an honest empty (200 + total=0), a failed request is the ErrorState
  (browser-verified via network-fault → Réessayer → recovered).

### The verifier's D1 (PRE-EXISTING since Wave 3B, fixed per the fix-then-reverify loop)

The Tasks-view **owner filter was dead**: `qs()` prefixes "?", so suffix-concatenating the fragment
onto the existing query produced `…pageSize=200?ownerId=…` — the second "?" rode the pageSize value
and the server NEVER received ownerId (live-reproduced by the round-1 verifier). Fix (`7433523`):
the three group queries build their WHOLE query string through the canonical `qs()` — the wire
carries a real `&ownerId=`; the cache keys can never collide; the suite gained probe D7R4A-8. The
round-2 verifier CONFIRMED-CORRECT (wire + row ownership + count agreement + the D-021 negative —
an agent asking for a peer's ownerId gets 0 rows — + persistence + encoding + the old-broken-URL
mechanism now unreachable from the UI).

- **Gates**: lint 0 · tsc exactly the 4 tolerated (src/ 0) · matrix 325/325 · Wave suites 21/21 +
  22/22 + 55/55 · Phase D 15/15 · D7-R1 17/17 + D7-R2 10/10 + D7-R3 10/10 (all re-run — the
  predecessors NOT regressed) · NEW D7-R4 suite 14/14 (`pd-d7r4-regressions.ts`: the taskInclude wire
  agreement (fragment === the DB join, honestly null) · canonical destination · same-title
  adversarial · fail-closed inputs (cross-org + bogus ids → empty pages) · forged-association
  rejection (404 + no row created) · completion semantics unchanged · D-021 + session boundaries ·
  the owner-filter agreement (D7R4A-8) · the facet's exact-id law + same-name LEADS adversarial +
  composition (∩status/∩range/∩agent/∩reconfirm) + honest states + D-021 on the facet · byte-exact
  residue witness incl. the SetNull'd creation-activity sweep) · browser E2E console-0 (chips w/
  distinguishable accessible names · network-traced exact-id cockpit opens · drawer stack w/
  one-at-a-time Escape · honest error→retry→cockpit recovery · AR-RTL round-trip · keyboard
  Enter/Escape + focus restoration · mobile 390 no-overflow · the facet's live filter/clear/compose
  behaviors) · independent verification round 1: ALL 14 directive attacks CONFIRMED-SAFE (+
  observations: GET /api/tasks/:id is 405-not-404 fail-closed; same-title opps share an accessible
  name prefix — inherent; the pre-existing ErrorState wording nit; focus-restore scrolls the chip
  into view; Arabic-script search can't match Latin-stored names) · round 2 (the D1 fix):
  CONFIRMED-CORRECT.

## 6e. The D7-R5 batch — the analytics top-lists: the honest-static outcome (IMPLEMENTED & VERIFIED 2026-10-24)

Commits `b5aa2c9` (test — the 7-probe suite + the browser evidence package) + the verifier's
evidence (round 1: ALL 12 attacks CONFIRMED-SAFE). **ZERO src/ changes — by finding, not by
omission.**

### The preflight finding (the decisive evidence, now a standing regression)

The GET /api/analytics data contract contains **ZERO individual-record rows**. Every top-list is
a dimension-keyed or entity-keyed AGGREGATE:

| Top-list | Row identity | Class | Canonical destination? |
|---|---|---|---|
| bySource (BySourceTable, UI top-8) | `source` — the Lead dimension enum value; NO entity PK | grouped-dimension aggregate | NONE — no record exists to open |
| agentLeaderboard (AgentLeaderboard = top-5 of byAgent by wonValue) | `agentId` — a genuine **User** PK, the ONLY entity id in the whole contract | per-entity performance aggregate (ranking) | **NONE for USER** — the accepted D7-R3 resolver law fail-closes USER ("users are managed in full views, not record dialogs", adversarially verified in D7-R3); the per-rep workspace is R7 behind the OPEN owner decision #6 |
| stageDurations (StageDurations) | `stage` — the pipeline dimension; NO entity PK | grouped-dimension aggregate | NONE |
| pipelineByStage / monthlyTrend / funnel (the chart/KPI feeds) | stage / month / step dimensions | grouped aggregates | NONE |

Live payload census (the suite's D7R5-1, re-verified independently): no `leadId`/`visitId`/
`opportunityId`/`apartmentId`/`reservationId`/`entityId` key anywhere in the payload; `agentId`
appears ONLY inside byAgent/agentLeaderboard rows; every row's key set is EXACTLY the aggregate
contract.

### The decision (R5A.3 applied)

- A grouped aggregate without unique entity identity is not a record → **no destination, no
  link** (the directive's own law). A scoped-LIST destination (e.g. leaderboard→pipeline filtered
  by ownerId) is NOT record-level navigation and would be an invented destination — rejected.
- The one entity-bearing row class (leaderboard `agentId`→USER) has no canonical record-detail
  surface; inventing one (per-rep panel, user dialog) would violate the no-duplicate-surfaces /
  no-invented-relationship rules AND the R7 owner gate #6 → **rows stay honestly static**
  (non-interactive by construction: plain `<tr>`/`<td>`, no button semantics, no cursor-pointer —
  verified in the DOM).
- **No analytics definition, aggregation formula, ranking law, date boundary, or metric was
  touched** — the verification battery proves semantic non-change instead (every top-list === an
  independent DB recomputation).

### What the batch delivered instead of links (the honest evidence battery)

- **`tmp-scripts/pd-d7r5-regressions.ts` — 7/7**: the identity census (zero record-id keys,
  exact key sets) · the same-name adversarial + id-keyed aggregation (scratch org-2: two
  same-name agents = two DISTINCT rows whose aggregates each equal their OWN agentId's DB truth;
  the unassigned opp fabricates no row; the ranking law; cross-org isolation BOTH directions) ·
  metric equivalence (funnel/bySource/byAgent/leaderboard/stageDurations incl. the CLOSED_WON
  avg law/pipelineByStage/monthlyTrend each === independent DB recomputation) · the days window +
  bounds (1/90/365 windows recompute; 0→1, 400→365, garbage→30; `since`=now−days×86400000) ·
  the D-021 boundary (anon 401 · SALES_AGENT 403 · FIELD_REP 403 · MANAGER 200 · OWNER 200 ·
  the 403 body carries no data) · read-stability (deep-equal modulo the now-derived `since`;
  zero writes) · byte-exact residue (audit delta = the suite's declared logins; the org-2
  quick-login telemetry swept with the chain).
- **Browser E2E (download/qa-phased-d7r5/ ×7, console 0)**: the DOM census — ZERO interactive
  elements inside the analytics tables, ZERO cursor-pointer rows · row-click inertness ×2 tables
  (hash unchanged, no dialog, ZERO new API requests) · the 30/90 tabs keyboard-operable
  (focus+Enter; the wire carries `days=90`; active state + focus retained) · **the hot-switch
  cache-isolation witness** — nadia(OWNER, analytics loaded)→amine(SALES_AGENT) with NO reload →
  the honest 403 lock screen, tables/KPIs gone (the D7-R3 resetQueries law live on the
  `["analytics", days]` family), switch-back → fresh load · AR-RTL round-trip (dir=rtl, genuine
  Arabic, logical alignment) · mobile 390 (documentElement.scrollWidth===390, no page overflow;
  tables scroll in their designed `overflow-x-auto` containers) · the honest error→retry→
  recovery cycle (network abort → ErrorState + Réessayer → unroute → full recovery).
- **Independent adversarial verification (round 1, read-only)**: ALL 12 directive attacks
  executed with the verifier's OWN probes (8 scripts + 7 screenshots, including a value-level
  cuid hunt against every live record PK) — ALL 8 implementer claims CONFIRMED-SAFE, ZERO
  in-batch defects. Pre-existing observations documented, not fixed (read-only mandate):
  GET /api/reservations/:id answers 405 (no GET handler — fail-closed, no leak; the same class
  D7-R4 logged for /api/tasks/:id) · the ErrorState wording nit (already flagged D7-R2/R3) ·
  table scroll containers are browser-default keyboard-focusable (no handlers) · the
  notifications poller's background requests (accounted in the click-inertness probes) · commit
  0a212d3's UUID message (an upload-paste artifact, zero src impact).

### The boundary this batch leaves for R7 (the door that stays shut until the owner opens it)

The leaderboard's `agentId` is a genuine, authoritative User PK — the moment a canonical
per-rep surface exists (R7, owner decision #6: what may a manager see/do per-rep beyond existing
D-021 scoping?), the row is ready to navigate by exact id through the established typed-resolver
idiom. Until then, honest static is the CORRECT state, not a gap: any link today would be an
invented destination (a filtered list is not a record; a fabricated user dialog would be a
second implementation).

### Gates re-run (this batch)

lint 0 · tsc 4-tolerated (unchanged: examples/websocket ×2 + skills ×2, all outside src/) ·
visibility matrix 325/325 · Wave 1 21/21 · Wave 2A 22/22 · Wave 3 55/55 · Phase D 15/15 ·
D7-R1 17/17 · D7-R2 10/10 · D7-R3 10/10 · D7-R4 14/14 · NEW D7-R5 7/7 (+ the verifier's own
re-runs: D7-R5 7/7, D7-R3 10/10, lint 0).

Environment note: ONE R13-class reset (#16 — the DB arrived EMPTY at preflight; found-state
captured; reseeded from the committed canonical seed; ASAS_SESSION_SECRET re-appended from a
fresh randomBytes(24); the dev server restarted by PID; the D-040/D-041 resurrection sweep
clean — zombie count 0; business baseline byte-identical to the directive's reported numbers:
8 users / 43 leads / 21 opps / 23 visits / 161 activities / 18 tasks / 8 reservations /
46 apartments; the audit history's accumulated login telemetry was necessarily lost with the
wipe — the seed's own 44 audit rows + this session's telemetry are the new baseline).

## 6f. The D7-R6 batch — incentive/commission panels + the badge adoptions (IMPLEMENTED & VERIFIED 2026-10-25)

Commits `a4057a1` (feat — 3 src files, 53+/7−, rendering-only) + the suite/evidence commit +
the independent verifier's round (ALL 12 directive attacks, ALL 12 CONFIRMED-SAFE, ZERO in-batch
defects — its own evidence package in `download/qa-phased-d7r6-verify/` ×6 + 13 scratch scripts).

### R6A — the audited-already-canonical finding (zero src change by finding, not omission)

The preflight census of EVERY incentive/commission surface found the navigation **already
canonical, pre-Phase-D**: the dashboard's `PendingIncentivesPanel` (P46/D-UX-057) and
`CommissionsPanel` (P48/W3b) rows each open **THE** `OpportunityDetailDialog` — the §37/§38
machine — by the payload's authoritative opportunity DTO (the API nulls both blocks below
MANAGER: the role gate rides the data contract); the audit journal's INCENTIVE/COMMISSION rows
ride the D7-R3 RESERVATION→parent-deal two-hop; the timeline's INCENTIVE rows ride D7-R2.
The agent's `IncentivesPanel` is a **pure aggregate** (month/allTime/deals — zero record ids in
its JSON; the R5 law: an aggregate without entity identity has no destination) → honest static.
The §38 `IncentiveStatusChip` stays file-local in deal-economics **by design** (the P46 law:
the §38 chip language lives in deal-economics; the queue rows are all-PENDING by construction —
a chip on every row would be noise) — out of R6's named customer+reservation badge scope,
recorded as a backlog candidate. The 7/7 suite encodes all of this as standing regressions
(id-agreement with DB truth per entry, the exact-id destination agreement, My Day honesty).

### R6B — the two adoptions that DID land

1. **The closure badge** (`deal-economics-closure.tsx`): the two-step-closure header's
   reservation status rendered as a bespoke single-tone amber pill — G6's LAST off-system
   reservation-status chip — now renders through the **shared `ReservationStatusBadge`**
   (badges.tsx, D-UX-064; tone law `RESERVATION_STATUS_TONE` in constants.ts: ACTIVE violet /
   CLOSURE_REQUESTED amber / CONVERTED emerald / CANCELLED+EXPIRED stone). Same
   `resv.status.*` labels; the workflow's states, guards, and mutations byte-identical.
   Live-verified in both directions: the ACTIVE reservation renders violet «Active», the
   CONVERTED renders emerald «Convertie — vente conclue», AR renders «نشط» in RTL.
2. **The apartment dialog's client link** (`apartment-detail-dialog.tsx`): the
   reservation-context block's «Client» row was dead text on an authoritative relationship —
   now the **canonical customer link** (the deal cockpit's client-field idiom):
   `openLead(reservation.opportunity.lead.id)` by the id riding `reservationInclude` — never
   the displayed name. The drawer mounts at the shell level (D-UX-064) so it **overlays the
   dialog** exactly as it overlays the cockpit; `GET /api/leads/:id` stays D-021-scoped
   server-side (a peer-owned lead fails closed as a 404 ghost inside the drawer). A missing
   `lead.id` renders the honest static row (the R5 fail-closed law). i18n: `resv.client.open`
   ×3 langs with the distinguishable-aria law («Ouvrir la fiche client — {name}» /
   «Open customer record — {name}» / «فتح ملف العميل — {name}»).

### The surfaces deliberately left static (the preflight inventory's honest classifications)

The CommissionsPanel/PendingIncentives rows show the customer as display context inside the
whole-row cockpit affordance (the accepted P46/P48 contract; a nested chip inside a `<Button>`
is invalid HTML and restructuring would change the accepted interaction semantics — no defect);
the closure checklist's client name is a verification `dl/dd` co-present with the cockpit's own
customer link; the visit fiche's client block is print-document semantics; the apartment block's
status is contract-forced ACTIVE-only (a badge would be constant noise — the apartmentId filter's
CLOSURE_REQUESTED-blindness is pre-existing behavior, documented, unchanged); the §38
IncentiveStatusChip (above); agent names everywhere (the D7-R3 resolver law fail-closes USER).

### The verification battery

- **`tmp-scripts/pd-d7r6-regressions.ts` — 7/7** (hardened post-verify to a two-layer D7R6-5):
  the economics contract identity (every wire id === DB truth; the exact-id destination
  agreement; the cockpit's §38 reservation source w/ status agreement — the badge's contract) ·
  My Day honesty (agent: pure aggregate + null gates; field rep: neither) · the client-link
  identity + same-name adversarial (org-2 twins: the contract row carries ITS OWN lead.id —
  the shared name cannot steer; cross-org fail-closed BOTH directions) · authorization (anon
  401×3; D-021 peer lead 404 ghost; peer opp empty; the apartment-scoped read org- and
  agent-scoped) · **financial invariance two-layer** (within-run every-field byte-exact incl.
  updatedAt — the suite's reads write nothing; the committed §37/§38 VALUE snapshot byte-exact
  vs the pre-batch baseline, updatedAt excluded with the verifier-probe rationale documented) ·
  server-side session isolation (the SAME URL ×4 sessions byte-equal per session) · byte-exact
  residue (audit delta = the kept logins; the org-2 chain + quick-login telemetry swept).
- **Browser E2E (`download/qa-phased-d7r6/` ×7, console 0)**: the queue row → cockpit with the
  network-traced reservation fetch + the VIOLET shared badge (ex-bespoke amber) · the
  commissions row → emerald CONVERTED badge + its own opportunityId on the wire · the H-31
  client link → the drawer STACKED over the dialog (`GET /api/leads/{authoritative id}`) ·
  Escape layer order (drawer first, dialog survives) + focus restoration + Enter re-open · the
  **hot-switch cache isolation** (nadia→amine no-reload: panels GONE from the DOM, the wire
  null-gated, the agent's own IncentivesPanel renders) · AR-RTL round-trip (same lead id on the
  wire) · mobile 390 no-overflow.
- **Independent adversarial verification (read-only)**: 12/12 attacks executed with the
  verifier's OWN probes (its own twin-org same-name adversarial, its own 3-run financial
  witness, its own 12-shape forged-id battery, its own browser walkthrough) — ALL 12
  CONFIRMED-SAFE, ZERO in-batch defects. Its FINDING 1 (the suite's one-shot updatedAt
  sensitivity) was adopted: D7R6-5 hardened to the two-layer law above; the verifier-probe
  false-history `INCENTIVE_SET` audit row it left (sarah, 59000→12345, reverted out-of-band —
  values proven byte-identical) was removed as test residue per the AGENTS.md law, the two
  bumped `updatedAt` stamps remain as physical bookkeeping (documented); its environment
  addendum (a post-verification OOM-class server death, restarted by the canonical pattern,
  contract re-verified identical) is on the worklog.

### Gates re-run (this batch)

lint 0 · tsc 4-tolerated (unchanged: examples/websocket ×2 + skills ×2, all outside src/) ·
visibility matrix 325/325 · Wave 1 21/21 · Wave 2A 22/22 · Wave 3 55/55 · Phase D 15/15 ·
D7-R1 17/17 · D7-R2 10/10 · D7-R3 10/10 · D7-R4 14/14 · D7-R5 7/7 (re-run twice: pre-verify
and post-residue-cleanup) · NEW D7-R6 7/7 (+ the verifier's own re-runs: the R6 battery, lint).

> **ADDENDUM 2026-10-26 (UX-OWNER-PLAN-2):** the owner ANSWERED the questionnaire — **Q1–Q5 are
> decided** (register `OWNER_DECISION_REGISTER.md` §1a: GATE-Q1 Opportunity-lifecycle-only scope —
> `VISIT_SCHEDULED` verified semantically correct as the boundary in the actual matrix, no material
> mismatch; GATE-Q2 strict blocking with NO override; GATE-Q3 exceptional outcomes keep the gate
> closed; REPORT-Q4 the report contract; REPORT-Q5 the report authority) and **#6 is
> RESOLVED-BY-DIRECTION** (WORKSPACE-Q6a visibility · POOL-Q6b pool self-assignment · TRANSITIONS-Q6c
> direct transitions — the manager-request queue NOT approved). The revised plan:
> `NEXT_PHASE_PLAN.md` v2. Two boundary questions (RQ-1 CLOSED_LOST exemption · RQ-2 validate_closure
> extension) + the financial-semantics question (RQ-3) remain the only open items. Historical text
> above preserved verbatim (append-only law). Implementation remains NOT started.
