# AS CRM — UI QA Baseline & Interaction States Matrix

> **Created:** Phase 9 close (P9.10, D-UX-035) — the regression fixture the
> VISUAL_IMPROVEMENT_PLAN §6.3 mandated. Owner hierarchy: this file is the
> QA baseline; decisions live in `UX_DECISION_LOG.md`; tokens in
> `DESIGN_SYSTEM.md` + `globals.css`.

---

## 1. Interaction states matrix (§6.3 — five states per interactive element)

Probe-verified on the live app (computed styles + CSS rule walks, 2026-10-08):

| Element | default | hover | focus-visible | active | disabled |
|---|---|---|---|---|---|
| Button (all variants) | variant fill | variant hover rule | `ring-ring/50` 3px + border-ring (P8-18 verified 2px emerald ring on nav) | **`scale(0.98)` press (P9.7, motion-safe)** | `opacity-50 pointer-events-none` |
| Lead table row | zebra tone-3 | tone-5 wash + inset bar 0.55 | outline-2 ring (inset -2px) | n/a (never scales — §6.1) | n/a |
| Tasks/visits list row | zebra tone-3 | tone-5 wash + `.crm-list-row-accent` inset bar (P9.4) | nested controls carry their own rings | n/a | busy → buttons disabled |
| Kanban card | card + shadow | border-primary/40 + bg-muted/40 | outline-2 ring (dnd shell) | drag: opacity-40 + grabbing cursor; drop: **FLIP glide 180ms (P9.7)** | n/a |
| Command palette item | — | cmdk highlight | cmdk highlight | Enter/Space selects | — |
| Select / menus | — | item hover | popper ring | opens on pointerdown (Radix) | — |
| Checkbox (row) | 16px visual + crm-hit ≥24px target | muted wash | ring | checked state | busy → disabled |

**Reduced motion:** ONE switch — `MotionConfig reducedMotion="user"` at the
providers root (P9.7). CSS press scale rides `motion-safe:`. Framer kanban
FLIP / badge crossfade / drawer fade are disabled for those users.

## 2. Keyboard surface (P9.5 + P9.8)

- `⌘K / Ctrl+K` — palette (recents + Créer commands when empty; search when typing)
- `j / k` — leads table row focus (guards: never in inputs/dialogs/menus)
- `Enter / Space` — open focused row (drawer + `#/leads/:id` deep link)
- `Escape` — closes topmost layer
- `Tab` — full DOM order; focus-visible ring everywhere (P8-18 sweep)

## 3. Regression sweep baseline (P9.10, 2026-10-08)

| Check | Method | Result |
|---|---|---|
| 9 views × light | errs counter + overflow probe | **0 errors, no overflow** |
| 9 views × AR RTL | dir/overflow/errs | **dir=rtl, 0 errs, no real overflow** |
| Mobile 390px | element-level rect walk (unclipped offenders) | **0 offenders** (naive scrollWidth probe shows phantom 2px — emulation subpixel, overridden) |
| Dark mode | attention-token parity probe | overdue band = dark attn-1 exactly (oklab 0.28 0.045 0.021 / 0.95) |
| lint / tsc | `bun run lint` / `tsc --noEmit` | **0 / 0 in src** |
| VLM captures | 8 runs this phase | **all PASS** (2 probe-overridden misreads: full-page scale, phantom overflow) |

## 4. Recurring probe lessons (apply before trusting any QA result)

1. Full-page VLM captures misread scale (13px vs 28px at 1280px zoom-out) —
   always scrollIntoView + closeup, or probe computed styles.
2. `scrollWidth > clientWidth` alone lies (phantom subpixel/scrollbar px) —
   walk element rects for UNCLIPPED offenders before declaring overflow.
3. Synthetic events don't trigger `:active`/`:hover` CSS — verify the compiled
   rule exists (`rule walk`) instead of simulating the press.
4. Synthetic drags need full pointer sequences (down → 12 moves → up) with
   real coordinates; count cards before/after + reload for DB persistence.
5. Turbopack can serve stale CSS after an OOM restart — if tokens probe empty
   but the file is right, `rm -rf .next` and restart.

## 5. Evidence archives

- `download/qa-p9/` — P9.1–P9.10 captures (tokens, typography, palette,
  kanban, sparklines, dark mode)
- `download/qa-p8/` — Phase 8 audit (24 captures) + research files
- VLM outputs: per-phase decision-log entries carry their verdicts
