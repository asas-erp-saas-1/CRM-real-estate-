# UX DECISION LOG

ADR-style record for deliberate UX decisions. Future agents MUST NOT casually
undo these — reversing one requires a superseding entry with new evidence.
Format: Problem · Evidence · Users affected · Options · Decision · Reason · Trade-offs.

Numbering: D-UX-NNN (sequenced). Related: engineering decisions in
`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md` (D-NNN); visual tokens ADR-007 (globals.css).

---

## D-UX-001 — KPI card: restraint redesign (hierarchy + calm) — Stage 3 / P6-1

**Problem:** All 10 dashboard KPI cards carried identical visual weight while 5-hue
pastel icon chips + top accent bars + corner glows + hover translate-lift competed
for attention ("flat hierarchy syndrome" + "rainbow dashboard" — VLM audit).
Labels mid-word-truncated in French ("Taux de conver…").

**Evidence:** VLM design review of `audit-02-dashboard-light.png` (glm-5v-turbo);
kpi-card.tsx `tone`/`accent` defs (5 hues × 2 rows); `truncate` on label/hint;
mandate §4 (avoid excessive shadows/gimmicks/decorative effects) + §11 (every metric
must drive an action) + §18 (animations communicate state, not decoration).

**Users affected:** Amine + Sarah (journey 1 morning triage — highest frequency).

**Options:** (a) keep colors, add bigger numbers; (b) accent-left borders on all
cards for tone identity; (c) neutral informational cards + attention hues reserved
for critical-only, wrapped labels, calm hover.

**Decision (c):**
- Icon chips: neutral `bg-muted text-muted-foreground` for informational KPIs;
  attention tint (amber/rose at 10% bg) ONLY on critical metrics (uncontacted,
  overdueTasks) — hue returns to meaning information.
- Remove corner glow + top accent bar (decoration). Critical cards get a 2px
  `border-inline-start` attention accent instead — the "primary vs secondary card
  style" the VLM review recommended.
- Labels wrap (2-line `line-clamp-2`, min-h reserved) — never mid-word truncate;
  hints keep single-line `truncate` + `title` (values, not semantic labels).
- Hover: border + background shift only. NO translate lift (moving targets under
  a scanning cursor = noise + layout jank on the grid).
- Number: 24px→22px (`text-crm-num-xl`), label 13px medium — rebalanced scale.
- Keep: count-up, critical pulse dot, live/period caption (genuine information),
  deep-links to tasks/visits, placeholderData behavior.

**Reason:** triage speed: the eye lands on the 2 attention cards first (what needs
action), then scans neutral performance; scanning noise reduced by removing 10
decorative color blocks; French labels fully legible.

**Trade-offs:** less color playfulness (accepted — enterprise calm); wrapped labels
reserve vertical space (2 lines max, min-height keeps grid rows aligned).

## D-UX-002 — Table headers stay uppercase micro — Stage 7 precedent

**Problem:** VLM review suggested title-case headers (readability at glance).

**Evidence:** `crm-th` 11px uppercase tracking-wide exists and is applied
consistently across ALL tables; Bloomberg/enterprise-FR convention; FR legibility
of short uppercase labels is fine at 11px with wide tracking.

**Decision:** KEEP uppercase 11px `text-crm-micro` headers. Column headers are
system metadata; human data (names) is what must dominate (which is the name-column
contrast fix A8, Stage 7).

**Reason:** consistency + density convention; changing casing across 9 views is
churn without measured user value. Revisit only with user feedback evidence.

## D-UX-003 — Dark card surface lift — 0.22 → 0.23 oklch

**Problem:** dark-mode card-vs-background contrast low → "card fade"/muddy grid
(VLM dark audit A11: bg 0.17 vs card 0.22 oklch = weak separation).

**Decision:** `--card: oklch(0.23 0.005 80)` (+ popover follows). One step, no more
— the warm-charcoal hierarchy must stay calm, not go high-contrast.
`--shadow-card` (dark) stays the single whisper shadow.

**Reason:** separation perceivable at a glance without breaking the calm dark
canvas; mandate §4 "subtle surfaces".

## D-UX-004 — Semantic type scale (`text-crm-*`) — Stage 1 foundation

**Problem:** 520 ad-hoc pixel sizes across crm/ (9 distinct: 8–15px) — no named
scale, hierarchy drift, review impossibility.

**Evidence:** `rg 'text-\[\d+px\]'` counts (A1); mandate §26 (design tokens, avoid
one-off styling) + §46 (typography consistency gate).

**Decision:** CSS custom utilities in globals.css: `text-crm-page` 15px semibold ·
`text-crm-section` 13px semibold · `text-crm-body` 13px · `text-crm-caption` 11px
muted · `text-crm-micro` 10px muted-upper-wide · `text-crm-num-xl` 22px semibold
tabular · `text-crm-num` 15px semibold tabular. Migration INCREMENTAL: new code +
touched surfaces only (mechanical map in DESIGN_SYSTEM §3). 8/9px forbidden in new
code (a11y floor 10px).

**Reason:** one vocabulary = consistent hierarchy + reviewable diffs; big-bang
replacement of 520 occurrences violates the smallest-correct-change law.

**Trade-offs:** coexistence period (two systems during staged migration) — bounded
by the stage program and lint-able in review.

## D-UX-005 — Dashboard hierarchy order (information architecture) — Stage 3

**Decision:** dashboard section order stays operational-first (existing):
attention KPIs row (live) → performance KPIs row (windowed) → Ma journée (2/3) +
targets/hot/funnel (1/3) → recent leads. This already implements mandate §11's
hierarchy (Critical actions → Today's work → Pipeline/performance → Recent →
analytics); D-UX-001 completes it by making the attention row VISUALLY primary.
No re-ordering churn.

## D-UX-006 — Leads table name contrast (semibold scan path) — Stage 4 start / P6-1

**Problem:** lead names (font-medium 13px) carried nearly identical visual weight to
their email/phone metadata — no clear scan path down the name column (VLM audit A8).

**Decision:** name → `font-semibold` (600) in both the table row and the mobile card;
email → `text-crm-caption`. Metadata stays muted — the name column becomes the
vertical scan anchor.

**Reason:** in a 25-row daily-use list, the eye should track the name column
vertically without row-slipping; weight contrast (600 vs 400) does this without
color or size changes.

**Trade-offs:** none measurable — single-step weight increase, palette untouched.

## D-UX-007 — Lead drawer: coherent workspace (next-action band + zero-tab-switch loop) — Stage 4 / P6-2

**Problem:** Journey 2 (rep response loop, ×50/day) required tab visits to assemble
context: recent activity lived behind « Historique », the follow-up was the 7th item
of the info grid, and logging an activity meant switching tabs (USER_JOURNEYS
friction inventory; mandate §13 record-detail = coherent workspace).

**Evidence:** USER_JOURNEYS.md journey 2 + friction table; code inspection
(lead-detail-drawer.tsx: nextFollowUp InfoItem mid-grid, Composer only in the
history tab); VLM audit "context assembly" observation; mandate §16 (50×/day —
every extra click is 50 clicks).

**Users affected:** Amine (daily ×50) + Sarah (coaching recalls).

**Options:** (a) restructure into a full detail PAGE (route-like workspace);
(b) add a summary strip + keep all actions in tabs; (c) next-action band under
the header + recent-activity preview + composer mounted on the default tab,
controlled tabs for deep focus links.

**Decision (c):**
- **Next-action band** (3 cells, `bg-muted/30`, micro labels + medium-weight
  values) directly under the drawer header: next follow-up (quick-set popover
  ELEVATED from the info grid), last contact (staleness), nearest OPEN task
  (click → focuses Tâches tab). Overdue = rose, only hue in the band.
- **Aperçu tab** now opens with: recent-activity preview (last 2 entries, SAME
  timeline visual language — TYPE_ICON/TYPE_DOT reused) + the quick-log Composer
  (the very component from « Historique », Radix unmounts inactive tabs so one
  instance exists at a time) before copilot/requirements. The see→understand→
  contact→record→schedule loop needs ZERO tab switches.
- Controlled tabs (`value/onValueChange`) so the band and preview can focus
  Tasks/History directly; header decorative gradient removed (DESIGN_SYSTEM §2);
  tab strip gets `overflow-x-auto` (6 tabs > 390px viewport); InfoItem migrated
  to the semantic scale (micro labels / body values).
- VLM re-review finding accepted: band values `font-medium` (500) vs info-grid
  values 400 — weight contrast encodes actionable-state vs static-fact. Rejected
  (with reasons logged in UI_AUDIT §C): Aperçu "does too much" (static data is
  in the grid ABOVE the tabs; ordering is journey-driven), composer ambiguity
  (same proven component as the timeline tab — a restyle would fork the system),
  copilot-card weight (deferred to Stage 8 detail/timeline work).

**Reason:** the drawer answers « what do I do next with this lead? » instantly;
context (recent activity), action (composer), and scheduling (follow-up popover)
are on ONE surface; deep links give progressive disclosure instead of upfront
density.

**Trade-offs:** +~56px vertical before tab content (accepted — scroll surface);
composer state resets across tab switches (ephemeral by design); nearest-task
cell shows only title+due (full list one click away — progressive disclosure).

## D-UX-008 — Pipeline kanban: next-action chip + hover restraint — Stage 5 / P6-3

**Problem:** A10 — the kanban next-action carried equal visual weight to
title/owner metadata (11px muted line), so Sarah's journey-3 scan for stalled
deals required reading every card. The card ALSO violated the D-UX-001 hover
law (`hover:-translate-y-0.5` lift + shadow + ring) — movement under a
scanning cursor.

**Evidence:** UI_AUDIT A10 + VLM pipeline audit (P6-1); USER_JOURNEYS journey 3
("kanban card = value + name + next-action dominant, metadata recessive");
DESIGN_SYSTEM §5 binding rule (touched surface = restraint applies).

**Users affected:** Sarah (daily pipeline hygiene) + Amine (own deals).

**Decision:**
- Next action becomes the card's **action chip**: own surface
  (`rounded-md px-1.5 py-1`), `font-medium`, neutral `bg-muted/60` when
  upcoming, `bg-amber-500/10 text-amber-700` ONLY when overdue (D-UX-001
  attention language). ArrowRight (auto-mirrored RTL via globals rule).
  Text = `text-xs` + `line-clamp-2` — action LABELS wrap, never mid-word
  truncate (§3; VLM re-review finding accepted).
- Card hover: `hover:border-primary/40 hover:bg-muted/40`, NO translate/shadow
  lift; `transition-colors` (dnd-kit's inline transform transition overrides
  the class at rest — hover shift is instant, accepted trade-off: still zero
  movement).
- Semantic scale migration on the body (name/value `text-crm-body` semibold,
  title/owner `text-crm-caption`); owner-avatar 8px→10px micro (a11y floor on
  touched surface); avatar size-4→size-5.
- Column headers anchored with `border-b border-border/60` (VLM finding
  accepted — "floaty" header row).
- One body component → kanban + drag overlay + mobile card all inherit.

**VLM re-review triage:** ACCEPTED chip truncation (→ line-clamp-2) + floaty
column headers (→ hairline). REJECTED with evidence: "missing probability bar"
(42 `[role=progressbar]` render — 216px wide; VLM misread), "owner contrast
fails AA" (muted-foreground ≈ 4.6:1 on white — passes), "overdue icon stays
grey" (svg = currentColor, inherits amber).

**Reason:** journey 3 scans for stalls; the chip is the only element whose
color+surface encode URGENCY, so amber = "act on this" reads at board distance;
value/name remain the identity row, metadata recessive.

**Trade-offs:** chip adds ~4px card height (wrapping may reach 2 lines);
instant (not eased) hover shift on kanban cards (dnd-kit inline transition
override); amber reserved strictly for overdue (upcoming actions stay neutral —
calmer board, attention stays scarce).

## D-UX-009 — Table zebra channels + row-state alpha ladder — Stage 7 / P6-4

**Problem:** A7 — high-density tables (leads, 25 rows) relied on 1px borders
only; the eye "slips" vertically while scanning a row horizontally. Also: row
state alphas (hover 60 / selected 50) had no headroom for a third state.

**Evidence:** VLM leads audit (P6-1, "no horizontal channels for row
tracking"); USER_JOURNEYS journey 2; Bloomberg/Stripe-style scan-channel
convention; first implementation at 30% alpha measured at RGB(251,250,249)
= 1.8% step — imperceptible (VLM re-review #1 "visually absent"; pixel-sampled).

**Users affected:** Amine + Sarah (every table scan).

**Decision:**
- **Zebra = opt-in primitive** `.crm-zebra` on `<table>`:
  `tbody tr:nth-child(even):not([data-selected]):not(:hover)` gets
  `color-mix(in oklab, var(--muted) 60%, transparent)` — RGB(247,246,244)
  ≈3% darker than white: the classic visible-but-calm band; `--muted` base →
  light AND dark correct automatically. Applied to the leads table (the
  audited surface); other tables adopt per-surface after their own evaluation.
- **Row-state alpha ladder** (light-mode perception): zebra 60 (≈3%) <
  selected 70 (≈3.8%) < hover 80 (≈4.4%) — a strict monotone ladder where the
  strongest state always wins visually; `:not(:hover)` + `:not([data-selected])`
  make zebra yield (no specificity fight).
- `crm-tr-hover` primitive: `hover:bg-muted/60` → `hover:bg-muted/80`
  (single-point global change; all tables keep ONE hover language).
- lead-row selected: `bg-muted/50` → `bg-muted/70`.

**Reason:** channels give peripheral vision a periodic rhythm → the eye locks
onto the correct row across 9 columns without vertical ruling lines; the
ladder guarantees state legibility on top of the channels.

**Trade-offs:** hover slightly stronger everywhere (4.4% vs 2.9% — deliberate,
needed for ladder headroom); even/odd visual asymmetry (accepted — the entire
point); Turbopack dev-cache staleness discovered during validation (same-rule
CSS edits not invalidated → `rm -rf .next` + restart protocol; documented in
worklog P6-4, watch for recurrence).

---

## D-UX-010 — Stage 6: tasks/visits operational-list anatomy + the twMerge custom-utility hazard — P6-5

**Context:** Stage 6 (activities/tasks/visits views). VLM audit of the BEFORE
state found: date/time buried in wrapped metadata (no vertical alignment); no
scan channels or hover on div-based rows; colored priority dots on EVERY row
(amber HIGH + slate NORMAL/LOW = hue noise diluting the attention language);
visits rows = wall of 3–4 labeled outline buttons; SCHEDULED visit badge used
`sky-*` (blue — ADR-007 palette violation); journey 1 promised
"complete/reschedule" but the tasks view had NO reschedule affordance.

**Users affected:** Amine (journey 1 triage + journey 2 loops), Sarah
(overdue-kept-near-0), all agents working today's visits.

**Decision:**
- **Div-row ladder** `.crm-list-row` (+ opt-in `.crm-list-zebra` container):
  hover 80 / zebra 60 via `color-mix(--muted)` — the D-UX-009 ladder ported
  to div-based lists; zebra uses `:nth-child(even of .crm-list-row)` so group
  headers never consume parity; unsupported engines degrade to no zebra.
- **Due-time fixed column (both views)** `w-[4.25rem] text-end`, tabular-nums,
  font-medium 13px time; **date line ALWAYS reserved** (invisible when today —
  group headers carry "today") so the time baseline is identical in every row;
  `formatDayMonth` (day + short month, no year — year is noise in a ~7-day
  operations window). Priority renders BEFORE the column so label-width
  variance can never shift the time anchor. Rose ONLY for overdue.
- **Priority restraint (PriorityBadge):** dot ONLY for HIGH (amber) /
  URGENT (rose + medium weight); LOW/NORMAL = plain muted text. The label
  always carries the meaning (never color-only).
- **Visits action hierarchy:** ONE labeled lifecycle primary per row
  (Confirmer for SCHEDULED, Terminer for CONFIRMED) + icon-only secondaries
  (aria-label + title). Everything stays one click — no hidden menus.
- **SCHEDULED visit tone:** `sky-*` → `violet-*` — same concept as pipeline
  stage VISIT_SCHEDULED (one hue language) and violet = the palette's
  windowed/future semantic.
- **Journey-1 postpone:** CalendarClock icon action on open task rows →
  PATCH `/api/tasks/:id {dueAt: tomorrow 09:00}` (existing frozen contract);
  honest feedback = toast + the row visibly leaves its group.
- **twMerge hazard fix (engineering, heals 6 sites):** custom `text-crm-*`
  utilities were classified by tailwind-merge as text-COLOR, so any `cn()`
  merging them with a Tailwind text color SILENTLY STRIPPED the size
  (measured: overdue time rendered 16px instead of 13px; sidebar active item
  16px since P6-1b; drawer chips since P6-2; done-task titles). Fixed in
  `utils.ts` via `extendTailwindMerge({ classGroups: { "font-size": [{ text:
  ["crm-page","crm-section","crm-body","crm-caption","crm-micro","crm-num",
  "crm-num-xl"] }] } })` — size + color now compose; size dedup preserved.

**Reason:** these two views are the daily execution surfaces (journey 1);
tabular integrity (time anchor), scan channels and one-label-per-row are the
same restraint language already proven on tables (D-UX-009) and kanban
(D-UX-008) — ported, not reinvented.

**Rejected VLM findings (with evidence):** "make row primary solid green"
(§7: ONE primary per SCREEN — the Planifier button; 20 solid row primaries =
the D-UX-001 wall); "time baseline slightly higher in first row" (measured
17px vs 16px = 16.5px line-height rounding, sub-pixel); "zebra resets at
headers" (VLM itself: standard enterprise pattern, acceptable).

**Trade-offs:** visits rows grow ~8px (reserved date line) for uniform
baselines; postpone is one-day-only (no free date picking — deliberate: the
deliberate path for custom dates stays the drawer/reschedule dialogs);
`text-crm-caption/micro` still SET color — combining them with state colors
remains forbidden (D-UX-008 chip-pattern rule; now also guarded by the
class-group registration which at least preserves the SIZE).

## D-UX-011 — Stage 8: activity-timeline day anatomy + copilot-card weight — P6-6

**Context:** Stage 8 (detail pages + timelines). The lead drawer's
"Historique" tab rendered up to 100 activities as ONE undifferentiated stream:
no day boundaries (finding "what happened yesterday" required parsing N
relative timestamps), type · actor · time metadata in a single homogeneous
grey run (the actor — often the key scan target — had no distinction), and
16px dots with 10px glyphs. The copilot card carried the deferred P6-2 VLM
finding (summary = primary content at under-weighted 12.5px), decorative
gradients (`bg-gradient-to-b/-br` — §2 violation), 9px badges (forbidden
size, D-UX-004), and a `sky-*` COLD badge (ADR-007). `TYPE_DOT.CALL` was the
timeline's only blue dot.

**Users affected:** Amine ×50/day (journey 2: reopen context on every call),
Sarah reviewing rep activity, anyone reading a converted lead's history
(Hocine: 9 entries across 5 weeks).

**Decision:**
- **Day-group chips:** at each calendar-day boundary a chip
  (`Aujourd'hui` / `Hier` / locale `formatDayMonth`) sits ON the rail — same
  negative-margin geometry as the dots, solid `bg-background` + hairline
  border masks the line (no z-index games). Local-time day keys
  (`dayKey`), never UTC. Activities render desc, so boundaries appear
  naturally; no reordering, no data change.
- **Metadata differentiation:** the ACTOR gets `font-medium
  text-foreground/75` inside the caption run — type and relative time stay
  muted. Horizontal scan now answers "who" pre-attentively.
- **System vs human entries:** `HUMAN_TYPES` (NOTE/CALL/WHATSAPP/EMAIL/SMS/
  MEETING/VISIT) keep `font-medium` foreground titles; system entries
  (status/stage changes, assignments, conversions, creations) drop to
  `font-normal text-foreground/80`. Automation noise de-emphasises without
  hiding; ONE timeline language (no special-cased rows).
- **Dot legibility:** dots 16→18px, glyphs 10→12px (the P6-1 micro floor
  respected; a modest bump, not a redesign).
- **CALL dot hue:** `bg-sky-500` → `bg-teal-600` — joins the live-human-
  contact family {VISIT teal-500, CALL teal-600, MEETING amber-500}; the
  glyph carries exact type, the hue the family. Last blue in the timeline
  surfaces. (Stage-11 sweep list shrinks by this + COLD.)
- **Copilot card:** gradients → flat `bg-primary/[0.03]` card + `[0.045]`
  CTA (§2); summary `text-crm-body font-medium` (THE deferred weight fix —
  the LLM assessment is primary content, clearly above rationale/caption);
  next-action title 13px semibold; rationale/talking-points/score-rationale
  caption; drafts body size; 9px badges → 10px literal (color-coupled chips
  keep literals — caption/micro tokens SET a muted color that fights state
  colors, D-UX-008 rule); COLD badge `sky-*` → `slate-*` (low temperature =
  the muted member of the rose/amber/slate temperature trio).
- **Composer/preview:** mode chips keep literal 12px (color-coupled selected
  state), input `text-crm-body`, compose label caption; delete affordance
  size-6→size-7 + `hover:bg-muted/60`.

**Reason:** journey 2's context-recovery loop (open drawer → understand →
act) bottoms out in this timeline; day anatomy + actor emphasis + human/
system weighting are scan structure, not decoration — the same restraint
language as D-UX-009/010 ported to the vertical list paradigm.

**Rejected VLM findings (re-review, with reasons):** "preview vs full
history UX split" (the deliberate D-UX-007 architecture: 2-item preview +
deep-link; journey-driven); "copilot actions missing from timeline"
(timeline entries are immutable records; actions belong to the copilot
payload); "'Copilote IA' repeated in title+type label" (uniform rendering =
the one-system law; special-casing one type is fork complexity for marginal
gain); "HOT badge outranks CONVERTED status" (temperature is assessment
data; the hue MEANS the temperature — D-UX-001 color-is-information); "no
collapse-back from history" (the tab strip is the standard pattern).

**Trade-offs:** day chips add ~28px per day boundary (net +~5% height on a
9-entry/5-week history — bought back by 2px-tighter dot rings); system
entries at /80 could theoretically hide a rare important system title (the
title still renders — weight/alpha only, never removal); CALL teal-600 vs
VISIT teal-500 distinction relies on the glyph (family-first semantics,
deliberate).

**Validation:** §E full protocol — lint 0 · tsc 0 src · GET / 200 · 9-view
sweep errs=0 · UI≡API (titles/actors/order match the aggregate: COPILOT →
RESERVATION → STAGE_CHANGE → …) · note round-trip (composer → timeline with
"Aujourd'hui" chip → delete dialog → gone, DB restored) · computed checks
(dots 18px/12px glyphs, actor 500 vs meta 400, system 400+/0.8 vs human
500/1.0, WHEN badge 10px, gradients none, COLD slate) · dark + 390px + AR
RTL ("اليوم" chip, mirrored rail) · VLM re-review 8/8 CONFIRMED · evidence
download/qa-p6/after-p6-6-{timeline,timeline-today,copilot}-{light,dark},
-mobile-390, -ar-rtl · DB residue zero (QA note + QA copilot activity
deleted; score/lastContactAt untouched).

## D-UX-012 — Stage 9: settings-surface calm (neutral chips, semantic scale, flat progress, a11y slider names) — P6-7

**Context:** Stage 9 (administration/settings — "lower density, calm").
The settings view shipped with Phase 5's R8-2/R10-4 features but carried the
exact defect family the KPI redesign retired in Stage 3 (D-UX-001): a 5-hue
rainbow of pastel icon chips (one per matching criterion: emerald/rose/teal/
violet/amber) PLUS differently-hued section-header chips (primary/amber/
emerald/teal/violet/emerald across six cards = 9 competing hues on screen);
brand emerald on non-interactive metadata (per-slider value chips + the
threshold chips, all `bg-primary/10 text-primary`); a forbidden
`shadow-[0_0_8px]` GLOW on the done progress bar + a `bg-gradient-to-r`
amber gradient on the warm bar (targets-section AND its dashboard twin
targets-panel — "same state machine" comment tied them); 400ms motion;
`shadow-lg` on the sticky save bar (§5 layered-shadow violation); 9px badges
(team "Vous", targets role chips — below the 10px a11y floor); the temp
password rendered as an emerald-tinted block; ~40 ad-hoc `text-[Npx]` strays;
16px card rhythm on a surface the density model calls "calm 24px". The R12
extraction program also queued team-section.tsx (580 lines) — Stage 9 touches
it, so extraction interleaved here.

**Decision (implemented, P6-7):**
1. **Icon chips = ONE neutral language** on informational settings surfaces:
   `bg-muted text-muted-foreground` for every size-6/size-7 chip (section
   headers, slider criteria, dialog title chips). `WeightDef.tone` deleted.
   Role-toned AVATARS stay (identity convention — ROLE_TONE mirrors the login
   overlay; a person's initials chip is data, not decoration).
2. **Value emphasis = weight, not hue**: slider/threshold value chips are
   `bg-muted` + `text-foreground` semibold (muted text when 0). The TOTAL
   badge keeps semantic emerald/amber — it is a STATE (100/100 ok vs ≠100
   needs normalize); the decorative Sparkles icon inside it was removed.
3. **Flat progress tones** (`done bg-emerald-500 / warm bg-amber-500 /
   cold bg-slate-400`) in targets-section AND dashboard targets-panel (the
   twin — one defect class, both healed); motion 400→200ms (§8 budget).
4. **Sticky save bar**: `shadow-lg` removed — border + `bg-background/95`
   + backdrop-blur (the blur-backed sticky pattern, functional readability
   over scrolling content — NOT decorative glass).
5. **Calm rhythm**: `space-y-4`→`space-y-6` (24px card rhythm per §4 settings
   row); slider rows `p-3`→`p-4`.
6. **Temp password neutralized**: `bg-muted` + border + Geist Mono +
   `text-foreground` semibold (a VALUE on a neutral surface; the amber
   security hint below keeps the one attention hue; copy-success Check =
   primary). dir=ltr Latin token preserved.
7. **Size floor + semantic scale**: 9px badges → 10px ("Vous" badge also
   neutral outline); `text-[13px]`→`text-crm-body`, `text-[11px]`/`text-[12px]`
   metadata→`text-crm-caption` where color-safe; color-coupled literals kept
   per the P6-6 rule (total badge, normalize banner/hint, amber password
   warning, active-state rose text, tinted active badges — each commented).
   CardTitle stays `text-sm font-semibold` (app-wide convention — forking it
   here would violate one-system).
8. **Slider a11y (found by DOM measurement, fixed at the wrapper):** shadcn
   Slider spread `aria-label` onto Root — it lands on an inert div while the
   focusable `role=slider` THUMB stays nameless (screen readers announce
   "slider, 35"). Wrapper now destructures `aria-label`/`aria-labelledby`
   onto each Thumb. Only settings-view consumes the wrapper (verified) —
   safe systemic fix, all 8 thumbs now named.

**Extraction (R12, interleaved per the touch-the-file rule):** team-section
580→~145-line composition root + 5 modules (`settings/team/{role-options,
temp-password-dialog, add-member-dialog, reset-password-alert, team-table}`)
— verbatim moves; mutations moved with their dialogs (prop-threading:
`onCreated`/`onDone`/`meId`/`canManage`); every module keeps "use client" +
provenance header + own useT(). Zero behavior change (tsc 0 · 7 rows render
· dialog smoke ×3 · mutation round-trips below).

**Rejected VLM findings (BEFORE review):** "toggle state inconsistent on
Karim's row" (it is the DISABLED self-row — server-enforced self-lockout
protection, tooltip present); "table header contrast" (crm-th convention,
A9 decision); "slider hint ragged alignment" (labels wrap per the truncation
rule). **Rejected residuals (AFTER re-review, with measurements):** "avatar
chips not neutral" (ROLE_TONE identity convention, pre-Phase-6 preserved
strength — the ICON chips are the ones D-UX-012 governs, DOM-verified
bg-muted); "icon vertical misalignment" (measured: chip/text/value centers
all Y=-696, exact); "total badge low contrast" (computed 5.27:1 — passes
WCAG AA 4.5:1); "missing card separator" (hairline borders + measured 24px
gaps — contradicts the VLM's own claim (e)).

**Trade-offs:** neutral chips lose the per-criterion color mnemonic (the
criterion NAME + icon glyph carry it — sliders are a low-frequency admin
surface where calm beats mnemonics); temp-password emerald loss reduces the
"success moment" glow (copy affordance + toast + amber hint carry it);
extracted dialogs re-invalidate the same query keys (3 invalidate paths —
identical behavior, negligible cost).

**Validation:** §E full protocol — lint 0 · tsc 0 src · GET / 200 · 9-view
sweep errs=0 · UI≡API: slider round-trip (budget 35→40 + location 25→20 via
KEYBOARD arrows on the thumb → dirty state → save → GET /api/settings shows
40/20 → restored 35/25 + re-saved → exact original) · target input
round-trip (5,000,000 typed → blur-save → API row appears → cleared → row
drops, orgTarget back to 0) · month nav round-trip (octobre→septembre→
octobre, API months exact) · dialogs: add-member open/Escape, reset-alert
open/Escape + ROLE_CEILING live-verified (karim ADMIN resetting OWNER Nadia
→ 403 — correct), Sarah MANAGER reset executed → temp-password dialog
measured (bg-muted lab 94.8, Geist Mono, foreground text, amber hint) ·
computed: 16 icon chips render 2 unique colors, card gaps 24px ×6, sticky
shadow none, slider rows p-4, thumbs carry 8 aria-labels · dark ×3 +
mobile-390 ×2 + AR RTL ×2 (الإعدادات, dir=rtl) screenshots · VLM re-review
5/6 claims CONFIRMED (6th = avatar misread, rejected with DOM evidence) ·
evidence download/qa-p6/{before,after}-p6-7-settings-* · DB residue zero
(Sarah's hash + passwordChangedAt restored EXACT-MATCH via script; 5 QA
audit entries deleted: 2×SETTINGS_UPDATED, 1×USER_PASSWORD_RESET, 1×
SALES_TARGET_SET, 1×SALES_TARGET_CLEARED — synthetic fully-reverted actions
only; LOGIN entries kept as routine).

## D-UX-013 — Stage 10: responsive/a11y/localization sweep (hit-area floor, bidi isolation, RTL glyphs, login i18n) — P6-8

**Context.** Stage 10 is the phase-closing sweep (UX_MASTER_PLAN row 10:
fr/en/ar × LTR/RTL × phone/tablet/laptop). Recon = DOM-measurement audit
across 9 views × 2 langs × 390/1280px + keyboard Tab walks (desktop +
mobile) + VLM bidi review. Strong baseline: 0 nameless interactive
elements, 0 horizontal overflow, 0 console errors, landmarks + focus rings
verified — Phase 1–9 already banked the naming/semantics work. Four real
defect classes remained, all fixed in this decision.

**(1) Hit-area floor — `.crm-hit` utility (globals.css).** Probe measured
the high-frequency controls BELOW the 44px mobile floor: task/lead
checkboxes 16×16, kanban + task-row lead links 18–20px tall, kanban open
buttons 24×24, row icon actions 32×32, settings switches 32×18, month nav
28×28, topbar icons 36×36. Fix = transparent `::before` overlay (standard
hit-area technique — pseudo-element boxes hit-test to their originating
element): +16px total any pointer (WCAG 2.5.8 AA ≥24px), +28px total on
`(pointer: coarse), (hover: none)` (≥44px floor for every ≥16px control).
Logical insets (RTL-safe); zero visual change (position:relative only).
Applied at 15 sites: shell topbar (menu/search/bell), tasks rows
(checkbox/lead chip/postpone), today-panel checkbox, leads table+card
checkboxes + select-all, WhatsApp row button, kanban lead link + open
button, visits row icon secondaries, drawer task checkbox, team-table
switch + reset, targets month nav. NOT applied to text inputs (WCAG
text-entry exemption) or full-size buttons. Verified by measurement:
elementFromPoint probes hit the control at ±12px outside its box, miss at
+22px (bound respected); visual boxes unchanged (36×36, 16×16).

**(2) Bidi isolation — `dir="ltr"` attribute for block/flex Latin runs.**
VLM-confirmed scrambling: leads-table emails (9/9 rows, desktop AR) and
audit ChangeChips (`karim@asas.dz -- :email`, ISO dates with jumping
colons — neutrals between Latin + Arabic bases). Phone spans were already
`.ltr-token`; the gaps were email (lead-row, drawer header) and the whole
audit diff-chip. Fix: `dir="ltr"` HTML attribute (spec-level bidi
isolation, NO display override — .ltr-token forces inline-block which
would break block-truncate spans and inline-flex chips). Rule codified:
`.ltr-token` for inline tokens; `dir="ltr"` for block/flex containers.
Post-fix: 0 ltr-gaps in all 9 views × AR (was 10); visual order measured
equal to DOM order (`email: — → karim@asas.dz`).

**(3) RTL glyph mirroring — 2 additions.** `Send` (5 surfaces: whatsapp
composer, activity composer, copilot drafts, overview quick actions) and
`LogOut` (sidebar user menu) were missing from the mirror list.
Both verified: computed `matrix(-1,0,0,1,0,0)` in AR. Bell badge position
switched physical→logical (`-right-0.5` → `-end-0.5`).

**(4) Login-surface i18n.** The language switcher lived only in the
sidebar (post-auth) — an Arabic-first user could not read the login form.
Fix: `LangSwitcher` segmented control (FR/EN/ع, aria-pressed, same
vocabulary as the sidebar's) — mobile/tablet in the brand header
(ms-auto), desktop absolute top-end. Second fix: `useDocumentLangSync`
moved to CrmApp BEFORE the auth gate — `<html dir/lang>` (+ the Arabic
font stack that keys on it) now applies on the login screen too (the
overlay's own dir wrapper was insufficient for body typography).
Round-trip verified: FR→"Se connecter", ع→"تسجيل الدخول", full AR login
journey → shell RTL.

**Legacy sub-10px retirement (3 sites):** sidebar role badge 9px→10px,
opportunity-dialog owner initials 8px→10px, bulk-bar initials 9px→10px
(DESIGN_SYSTEM floor: 10px).

**VLM findings REJECTED (with measurements):** audit-chip "FAIL" verdict —
the VLM misread the em-dash null-placeholder + arrow ("— →") as a
scrambled separator; computed style (dir:ltr, unicode-bidi:isolate), DOM
order and pixel order all match (`email: — → karim@asas.dz` = label,
empty-prev, arrow, new-value — the intended machine-diff reading). Phone
"misalignment" claim (leads AR) — phones were already isolated; alignment
is cell-level, not bidi.

**Trade-offs:** adjacent .crm-hit zones can overlap a few px in wrapped
rows (DOM-later wins — a tap at a zone edge lands on a sibling ACTION,
never dead space); `(hover: none)` in the media query also matches
touch-primary hybrids (desirable); hit expansion is invisible to
screenshots (verified by elementFromPoint physics, not pixels).

**Validation:** §E full protocol — lint 0 · tsc 0 src · GET / 200 ·
9-view sweep ×2 (fr + ar) at 390px: errs=0, overflow=0, nameless=0, ltr=0
· desktop AR ltr-sweep 0/0 (was 9 + 3) · keyboard Tab walk desktop +
mobile (rings via box-shadow, DOM order, mobile skips hidden sidebar) ·
hit-area elementFromPoint probes (±12 in / +22 out) · crm-hit computed
(::before "", inset −8px fine / −14px coarse emulation, visual box
unchanged) · LogOut + Send transforms mirrored in AR · login round-trip
fr↔ar + AR login journey · dark ×3 + mobile-390 ×3 + AR RTL ×4
screenshots · VLM AFTER: leads PASS, login PASS ×2, audit "FAIL" rejected
with 3-level measurement · evidence download/qa-p6/{before,after}-p6-8-* ·
DB residue zero (no data mutations; LOGIN/LOGIN_QUICK audit entries
routine). **OPS NOTE:** Turbopack persistent-cache staleness after a
mid-edit process death served pre-edit CSS — the R13 restart protocol's
`rm -rf .next` step is load-bearing for correctness, not just DB state.

## D-UX-014 — Stage 11: visual QA + consistency close-out (sky-* elimination, flat progress ring, AI-card twin, dead-tab-bar fix) — P6-9

**Context.** Final stage of the Phase 6 mandate. The sweep list inherited
from Stage 8 held three sky-* (blue — ADR-007 forbids blue/indigo) sites;
DOM grep found six. VLM BEFORE review (7 images) confirmed them and
surfaced two additional twin defects; agent-browser E2E surfaced a
functional bug hiding underneath one of them. R12 extraction program
closes with entity-documents.tsx (853 → 173-line composition root +
6 modules).

**Decisions (all follow the D-UX-010 "same concept, one hue language"
pattern):**

1. **LEAD_STATUS_TONE.NEW sky → slate** (constants.ts) — mirrors
   STAGE_TONE.NEW exactly (same string): "NEW = nothing has happened
   yet" reads as the cool neutral in BOTH lifecycle maps.
2. **STAGE_TONE.QUALIFIED + STAGE_CHIP.QUALIFIED sky → emerald**
   (badges.tsx + opportunity-detail-dialog.tsx) — mirrors
   LEAD_STATUS_TONE.QUALIFIED: qualification is the positive validation
   milestone in both maps. Emerald now also covers CONTRACT/CLOSED_WON
   (positive-family sharing, precedented: OPTION/RESERVATION share
   orange; position disambiguates on the kanban).
3. **Notification severity `info` sky → slate** (notifications-bell.tsx,
   icon-chip style + unread dot) — D-UX-008 COLD precedent ("low
   temperature = cool slate"): info = the quiet severity, urgent/warning
   keep rose/amber.
4. **Audit-view ENTITY_TONE.LEAD: removed from the map** — renders as
   the neutral outline (same fallback as PROJECT/CONTACT/PIPELINE).
   Leads are the audit log's most frequently touched entity; the most
   common chip carries no fill (restraint law §2 hue budget), categorical
   hues remain on rarer entities for scanability.
5. **Dashboard targets ring: gradient stroke → flat state tone**
   (targets-panel.tsx) — the D-UX-012 twin fix: the ring now mirrors the
   row state machine (≥100 emerald / 70–99 amber / <70 slate,
   dark-lifted) via `stroke="currentColor"` + tone class; the
   `<linearGradient id="asas-targets-ring">` defs are deleted. Same
   panel, same concept (progress %), ONE visual language.
6. **AnalysisCard gradient → flat primary tints** (entity-documents.tsx)
   — the D-UX-011 twin fix: `bg-gradient-to-b from-primary/[0.06]` →
   `bg-primary/[0.03]` body + `bg-primary/[0.05]` header strip, matching
   the codified lead-copilot-card convention ("NEVER gradients") that
   P6-6 applied to the first twin only.
7. **FUNCTIONAL FIX — lead-drawer tab bar `shrink-0`**
   (lead-detail-drawer.tsx): in the whole-sheet-scroll drawer
   (SheetContent `overflow-y-auto` + Tabs `flex-1 min-h-0`), the
   shrinkable tab-bar wrapper collapsed to 1px whenever the active tab's
   content exceeded the available height; the TabsList overflowed below
   it and TabsContent painted OVER the tab triggers, swallowing every
   click — the tabs were dead (verified: `elementFromPoint` at the tab
   center hit the overview facts grid; wrapper measured 1px). One class
   (`shrink-0`) restores the bar to 41px; tabs switch in LTR and RTL.
   Found because Stage 11's screenshot protocol tried to reach the
   documents tab.

**Retained (reviewed, documented):** the ASAS monogram's
`from-sidebar-primary to-primary` gradient (4 sites: sidebar, mobile
header, login ×2) — brand identity mark, not surface decoration; never
flagged in 11 stages of VLM review.

**VLM findings REJECTED (with measurements):** AFTER re-review called
the leads-table "Nouveau" chips "blue-50/blue-700" — computed styles:
bg lab(96.29 −0.85 −2.47), text lab(35.56 −1.75 −15.43) = slate-100 /
slate-600 with chroma roughly one-third of the BEFORE sky values
(bg −2.34 −4.13, text −9.11 −42.56); slate is the palette's cool
neutral (same family as "Normale", COLD, STAGE_TONE.NEW — all retained).
BEFORE-review misreads likewise rejected: primary CTA "vibrant blue" =
lab(37.39 −29.95 11.77) dark emerald; LB/AC avatar chips "cyan" =
teal-500/15 role identity (palette member); "en direct" dot = teal
live-contact family.

**Trade-offs:** QUALIFIED now shares emerald with CONTRACT/CLOSED_WON in
the opportunity map (acceptable: positive family + kanban position
disambiguates); audit LEAD chips lose their categorical tint (the
entity label text still identifies them; the quietest treatment for the
most common row); the info unread dot is now slate-500 — quiet by
design, the rose bell-count badge still signals unread volume.

**Validation:** §E full protocol — lint 0 · tsc 0 src · GET / 200 ·
DOM sky-sweep = 0 elements · 9-view sweep errs=0 · ring computed stroke
= amber-500 at 73% (state machine live) · gradientPresent=false ·
AnalysisCard computed bg = primary@3% / header@5% · E2E: Documents tab
switch (LTR + RTL), upload form render, preview dialog open (image
streams), validate action → "Validé" badge (mutation prop-threading
verified) · opp-dialog documents section (withHeader path) · dark ×2 +
mobile-390 ×2 + AR RTL ×3 screenshots · VLM AFTER: 5/6 PASS + 1
rejected with chroma measurement · evidence
download/qa-p6/stage11/{before,after}-* · DB residue zero (lead status +
lastContactAt restored, activity + audit + target + document + file
deleted; LOGIN entries routine per P6-7 precedent).

**R12 close-out:** entity-documents.tsx 853 → 173 (composition root at
the original import path — zero consumer changes) +
documents/{shared,analysis-card,doc-thumb,doc-preview-dialog,
document-row,upload-card}. Mutations moved WITH their state (upload
card self-contained; review mutations stay in the root, passed as
structural prop slices so cross-row pending states are preserved
verbatim). Extraction program complete: 5/5 monoliths retired
(dashboard, import flow, team-section, settings-view ride-alongs,
entity-documents).

## D-UX-015 — Phase 8 / P8-1: dashboard command-center re-tiering (attention strip + compact metric strip + actionable right rail) — P8.1+P8.5

**Date:** 2026-10-07 · **Phase:** 8 (Premium Enterprise UI/UX) · **Surfaces:** dashboard view only

**Context:** Phase 8 brief — the dashboard must be an operational command
center ("what requires my attention?" first), not KPI wallpaper. Reference
grammar extracted from 10 enterprise-CRM screenshots (Pipedrive-style
pipeline, record drawers, bento dashboards): two-tier metric hierarchy,
multi-dimensional status, actionable rows, restrained color, tabular
numbers. VLM gap analysis of the CURRENT dashboard (7 concrete gaps):
card soup (10 identical KPI cards), monochrome-red alert fatigue, dead
widgets (un-actionable rows), right-rail density imbalance, static
recent-leads table.

**Decision:**
1. **Attention strip (new tier 1):** the two genuinely critical live
   metrics — uncontacted leads (amber/warning) and overdue follow-ups
   (rose/danger) — graduate OUT of the KPI grid into a dedicated
   `AttentionStrip` band: micro section label ("À traiter en priorité"),
   tinted icon chips, `text-crm-num-xl` counts in the attention hue,
   `border-s-[3px]` accents, deep-link buttons (leads / tasks views).
   Zero-state renders a calm emerald all-clear line — the zone ALWAYS
   exists (predictability; never disappears).
2. **Compact context strip (tier 2):** the 8 remaining metrics render as
   ONE receding row (`grid-cols-2 sm:4 xl:8`): number first
   (`text-crm-num`), label + live/period dot beneath, NO icon chips, NO
   accent borders, p-3 padding. Card soup → 2 dominant + 8 receding.
   Count-up + deep-links (view field) preserved.
3. **Actionable right rail:** hot-opportunity rows are now buttons that
   open the lead record drawer (`openLead(opp.leadId)`, pipeline
   fallback); stage progress bars carry the domain STAGE LABEL
   (`stage.*` i18n) instead of being decorative; funnel + source
   performance merge into one `MovementPanel` with tabs (right rail no
   longer out-scrolls the hero column).
4. **Canonical row anatomy in "Ma journée":** task rows get the shared
   `TASK_TYPE_ICON` chip (extracted to badges.tsx — one glyph per task
   type app-wide; rose tint only when overdue) and clickable lead chips.
5. **tel: deep links** on recent-leads phone cells (E.164 href, aria
   "Appeler {name}", stopPropagation separates call-intent from
   open-record-intent).

**Rejected alternatives:** keeping the 10-card grid and only re-sizing
cards (hierarchy needs semantic separation, not size jitter); adding more
attention cells — expiring reservations, stalled opportunities (dashboard
API doesn't carry them; would require backend changes — deferred to P8.5
follow-up candidates); coloring hot-opp rows by stage (violates hue
budget — stage label text carries the meaning).

**Trade-offs:** the two graduated metrics no longer show the live/period
dot (both are live — the strip's section dot says so); "0 Suivis en
retard" renders greyed at 55% opacity when clean (keeps zone stable,
communicates calm); VLM dark-mode contrast critiques on pre-existing
tokens were measured against the P6-validated system and accepted as-is.

**Validation:** lint 0 · tsc 0 src · UI≡API probe (attention values =
API kpis — CAUGHT a real bug: strip indexed `kpis["overdue"]` instead of
`overdueTasks`, showed 0 vs API 7; fixed + re-probed) · E2E: attention
cell → #/leads, hot-opp row → #/leads/:id (drawer), tel: href
`tel:+213771123523` + aria · all-clear branch exercised via fetch stub +
range-tab refetch ("Tout est sous contrôle" renders; strip returns after
restore) · AR RTL geometric probes (funnel fills fill from inline-start
= right ✓; checkbox at inline-start ✓ — two VLM flags disproved as
misreads) · mobile-390 AR: attention cells stack, metrics wrap 2-per-row
· dark ×1 + FR ×2 + AR ×2 screenshots · VLM AFTER review: 9/10
hierarchy, <1.5 s attention identification, no visual defects · errs=0
throughout · evidence /tmp/p8/p81-* (archived to download/qa-p8/).

**Component births:** `dashboard/attention-strip.tsx` (AttentionStrip +
AttentionSkeleton); `TASK_TYPE_ICON` in badges.tsx. **Deaths:** none.
**Data contract:** unchanged (same /api/dashboard payload; no backend
changes).

## D-UX-016 — Phase 8 / P8-6: leads workspace — last-interaction column, tel: row parity, agent truncation — P8.6

**Date:** 2026-10-07 · **Phase:** 8 · **Surfaces:** leads list (desktop table + mobile card)

**Context:** P8 brief §13 — the lead workspace must surface "last interaction"
among the prominent scan dimensions (it was missing); VLM critique flagged
agent names wrapping to two lines (inflating row height) and phone affordance
weakness. Triage vs binding decisions: row height (h-10) and zebra already
match the density spec; priority-pill sameness is D-UX-010 deliberate
(restraint); the two search bars are different scopes (global ⌘K vs list
filter — HubSpot ships the same); "—" empty cells kept (ghost CTAs per row
would be noise). Three real gaps accepted.

**Decision:**
1. **"Dernier contact" column** (`field.lastContact` — key already existed ×3
   langs) between Agent and Prochain suivi: muted relativeTime, em-dash when
   never contacted; NO per-row hue (stale-lead triage belongs to the dashboard
   attention strip — one attention surface, not hue-per-row noise).
2. **tel: deep links** on phone cells in BOTH the table row and the mobile
   LeadCard (parity with D-UX-015 dashboard pattern): E.164 href,
   stopPropagation + stopPropagation-on-keydown (call intent ≠ open-record
   intent), aria "Appeler {name}", hover underline + focus ring.
3. **Agent cell truncation:** `max-w-32 truncate` + title tooltip — names stay
   one line; row height governed by the two-line name/email stack only.
4. Table min-width 980→1060px for the 11th column (table scrolls horizontally
   below that — existing pattern).

**Validation:** lint 0 · tsc 0 src · DOM probe (11 headers incl. Dernier
contact; tel href E.164; agent truncate computed) · UI≡API (row lastContactAt
null ↔ "—" rendered; owner name match) · AR RTL probe (column legible, dir
rtl) · mobile-390 (cards clean, tel links, no overflow — VLM PASS) · dark ×1
· errs=0 · evidence download/qa-p8/p86-*.

**Component births/deaths:** none — amendments to LeadRow/LeadCard/table
header only. Data contract unchanged (lastContactAt already in the payload).

## D-UX-017 — Phase 8 / P8-7: lead record drawer — identity contact links + next-task empty CTA — P8.7

**Date:** 2026-10-07 · **Phase:** 8 · **Surfaces:** lead detail drawer (identity block + next-action band)

**Context:** P8 brief §14/§16 — the record drawer is the operational command
center; "next action" must be visually obvious and every contact datum should
be a workflow trigger. VLM audit triage: status-quick-change already exists
(badge = DropdownMenu — misread as static); 1-item timeline = data state (NEW
lead); notes box is intentionally inline-editable rows-2 (D-UX-007 overview =
context-first). Two real gaps accepted.

**Decision:**
1. **Identity-block contact links:** the phone/email under the record title
   become `tel:`/`mailto:` deep links (hover underline + focus ring; Latin
   `dir="ltr"` isolation kept per D-UX-013). The header ACTION buttons (WhatsApp
   popover, call icon) remain for the richer flows — the identity links are the
   zero-friction triggers.
2. **Next-task empty state → CTA:** "Aucune tâche ouverte" (dead muted line)
   becomes a ghost-weight `＋ Planifier un suivi` button that focuses the Tasks
   tab (quick-add composer one keystroke away). Ghost styling: muted until
   hover — an actual open task must always outrank the CTA visually.

**Rejected:** lifecycle stepper in the drawer header (the lead STATUS select +
opportunity stage tracking already cover progression; a stepper for a 6-value
enum with terminal states is decorative — revisit at P8.9 pipeline stage);
collapsing notes (inline autosave textarea is the D-UX-007 pattern).

**Validation:** lint 0 · tsc 0 src · DOM probes (tel/mailto hrefs E.164+addr;
CTA present) · E2E: CTA click → Tasks tab active + composer visible · AR RTL
(CTA جدولة متابعة renders, dir=rtl) · errs=0 · evidence download/qa-p8/p87-*.
**i18n:** +1 key ×3 (`lead.detail.planTask`).

## D-UX-018 — Phase 8 / P8.9: pipeline kanban days-in-stage aging chips — P8.9

**Date:** 2026-10-07 · **Phase:** 8 · **Surfaces:** pipeline kanban cards (incl. drag overlay + mobile card — one body component)

**Context:** P8 brief §21 — the pipeline must answer "where are our
opportunities and which ones require attention?" VLM audit: count+value
column headers, identity/value/probability/owner/next-action chips all
present (P6 lineage); **days-in-stage was the missing scan dimension** (a
deal stuck 3 weeks in NEGOTIATION was invisible without opening it).

**Decision:**
1. **Schema:** `Opportunity.stageChangedAt DateTime?` — stamped server-side on
   every stage move (PATCH) and creation (POST). Migration
   `20261007120000_p8_9_schema_catchup_stage_changed_at` carries the P7-2
   db-push drift (SavedSearch redefinition — for fresh replays) + the new
   column + backfill `stageChangedAt = updatedAt`; the LIVE DB received only
   the safe subset via `db execute` (re-running the SavedSearch INSERT..SELECT
   would have reset TEAM visibility rows) + `migrate resolve --applied`
   bookkeeping (also resolved the R13-era missing 0_init/p4 records).
2. **Card chip:** days-in-stage in the owner footer — neutral `<7d`
   (bg-muted/60), amber `7–13d`, rose `≥14d`; terminal stages never age
   (closedAt facts carry them); fallback `stageChangedAt ?? createdAt` makes
   un-migrated rows still meaningful. Chip NEVER displaces the open-detail
   affordance (it shares the footer; ms-auto moves to the chip).
3. **Seed realism (§42 data realism):** oppDefs gained `stageDays` per deal
   (1–25d: fresh early-stage deals, aging negotiations, the stale 20d villa
   QUALIFIED, terminal 25d) — fresh installs demonstrate the full threshold
   ladder; live demo DB aligned to the same canonical values (13 opps + 8
   terminal coherence stamps — documented demo-data alignment, not test
   residue).

**Validation:** lint 0 · tsc 0 src · migration: 3 recorded, status up-to-date,
column + backfill verified · E2E: PATCH stage move → stageChangedAt = now
(stamp verified at DB level; chip ladder DOM-probed 16 neutral/6 amber/4 rose)
· Turbopack stale-module hazard found+resolved: after `prisma generate`, a dev
server restart alone still served the OLD client (PATCH → "Unknown argument
stageChangedAt" 500) — required kill-all + `rm -rf .next` + restart (extends
the AGENTS.md Turbopack stale-chunk note to the Prisma client) · AR RTL ×1 ·
VLM AFTER 4/4 PASS ("identifies the 125M DA stale villa deal in under a
second") · E2E residue: stage + stageChangedAt restored, 2 synthetic
STAGE_CHANGE activities + 2 audit rows deleted · errs=0 · evidence
download/qa-p8/p89-*.

## D-UX-019 — Phase 8 / P8.10: inventory scan-surface increments (delivery timing, orientation, SOLD recession, bar a11y)

**Date:** 2026-10-06 · **Phase:** 8 · **Surfaces:** properties view — project rail cards, apartment grid cards, InventoryBar

**Context:** P8 §53 audit-first round on the inventory surface. VLM critique
returned 11 findings; triage against code + DOM probes accepted 4 real gaps
and rejected 7 with evidence (see below). Data reality check first: orientation
= 46/46 units, deliveryDate = 4/4 projects — both scan dimensions have full
seed coverage but neither was surfaced on the scan layer.

**Decision (accepted):**
1. **Rail delivery timing (dead-text fix):** ProjectRailCard rendered the bare
   word "Livraison" with NO date — the truck glyph now carries the semantics
   and `formatMonthShortYear()` (NEW helper: month-short + year, latn digits
   in AR) answers "when can I close this deal?" at sales-planning precision
   (mai 2028 / nov. 2027…). Full dates stay in dialogs.
2. **Orientation on cards:** "soleil/exposition" is a primary Algerian buyer
   question — compass caps (N/NE/E/SE/S) joined surface·floor·bedrooms in the
   meta line; Latin caps are dir-neutral in RTL (same convention as R+ floors).
3. **SOLD recession:** sold cards go FLAT (shadow-none) + opacity-60, hover
   restores both — "elevation = active, flat = settled" is the readable
   physical metaphor. Opacity ALONE was VLM-tested imperceptible on the white
   surface (honest FAIL → iteration: added the shadow layer). Record access
   never removed (E2E: SOLD card → dialog opens).
4. **InventoryBar a11y:** role="img" had NO accessible name — one label now
   serves aria + title: "{n} disponibles, {n} réservés, {n} vendus sur {n} lots".

**Rejected VLM findings (documented rationale):** F2 "F3/F4/F5 = floor
ambiguity" — misread, that's the French unit-type convention (F3 = 3 pièces),
floor renders separately as R+N; F3 "rail/grid selection desync" — DISPROVED
by DOM probe (click villas → results 46→3, chips 3/1/1/1; the "green" element
was the Tous-les-projets primary button); F5 "filters need a grey container" —
whitespace-over-borders is the binding P6 language (leads view parity); F6
"number redundancy" — three counters carry three semantics (rail scope glance
/ scope health / filtered results — 46→3 proves divergence); F9 "price outlier
gold ribbon" — decorative (§4 restraint); F10 "Livraison misaligned" —
items-center in code, geometry verified post-fix; F11 "parking icon
inconsistent" — presence=feature pattern is deliberate, slashed-car = noise.

**Engineering fix (twMerge shadow group):** `cn("shadow-card","shadow-none")`
kept BOTH classes — the theme utility `shadow-card` was outside tailwind-merge's
shadow scale (same hazard class as the P6-5 text-crm-* bug). Registered in
`extendTailwindMerge` shadow group → state overrides deterministic. Side
effect audited: Card base cn("shadow-sm", className) now dedupes to shadow-card
everywhere (single class, computed = token value — verified on dashboard ×8
cards; shadow-sm vs shadow-card are near-identical elevations, visual parity
held, 9-view sweep errs=0).

**Validation:** lint 0 · tsc 0 src · DOM probes (aria "1 disponibles, 1
réservés, 1 vendus sur 3 lots"; rail dates ×4; orientation "N" in meta; 7
SOLD flat — computed boxShadow all-zero vs token on active) · E2E SOLD card →
"Lot A-01 / Vendu" dialog · AR RTL (ar-DZ months جوان/ماي, Arabic bar labels,
dir=rtl) · dark + mobile-390 screenshots · VLM AFTER 4/4 PASS (after one
honest FAIL iteration on the opacity signal) · 9-view sweep errs=0 · evidence
download/qa-p8/p810-*.

## D-UX-020 — Phase 8 / P8.11: matching surface — drill-down records + localization parity + fit-tier scores

**Date:** 2026-10-06 · **Phase:** 8 · **Surfaces:** lead drawer Aperçu tab (MatchCard), Progress primitive, matching API include

**Context:** P8 §53 audit of the matching engine results. VLM critique (8
findings, on a properly-scrolled capture — the first attempt saw only the
top of the drawer, a known capture artifact) triaged against code:

**Decision (accepted):**
1. **Drill-down (F3 + code-read):** the whole MatchCard now opens the
   ApartmentDetailDialog ON TOP of the drawer (role=button, tabIndex, Enter/
   Space, aria "Lot {code}") — record-centric: verify delivery/orientation/
   reserve BEFORE presenting. Présenter stopPropagation keeps both actions
   independent. `onUpdated` live-patches the selected record from admin
   quick-edits inside the dialog.
2. **Floor defect (F5):** `{RDC +{n}}` hardcoded French AND wrong for floor 0
   ("RDC +0") → inventory convention: `t("properties.floor.ground")` for 0,
   `R+{n}` otherwise (cross-surface parity, one convention).
3. **unitType parity (F6):** raw enum ("VILLA") → `t(properties.unitType.*)`
   with raw fallback — AR now renders فيل/Dوبلكس like the inventory grid.
4. **Orientation + delivery (F4):** joined the meta line (orientation was
   already in the payload — apartment include returns all scalars;
   deliveryDate added to matchInclude project select + client type —
   additive, no contract break).
5. **Fit-tier score tones (F7):** Progress gains an additive
   `indicatorClassName` prop; match bars: emerald ≥80, primary 50–79,
   muted <50 — the 100% villa pops, scan noise recedes. Color = fit
   semantics only.
6. **Optimistic PRESENTED flip:** the list was local runMatch state, so
   invalidating ["lead"] never refreshed the card — the toast said "done"
   while the button stayed "Présenter" until a re-run. onSuccess now patches
   local state through an `onPresented` callback.
7. **Hygiene:** the duplicated 13-line requirements payload (save + runMatch)
   extracted to one `reqPayload()`.

**Rejected (documented):** F1/F2 "engine returns type/budget mismatches as
top results" — the list IS score-ranked (V-01 100% first); fuzzy inclusion is
the engine's domain design (frozen per §32 non-goals: no business-logic
changes) and the score tones now communicate fit without touching the
algorithm; F8 "positive chips on low-score cards" — reasons are facts, the
card tone carries the verdict.

**Validation:** lint 0 · tsc 0 src · E2E: card click → "Lot V-01/Disponible"
dialog (4 layers); Enter-key opens it too; Présenter → toast + NO dialog
(stopPropagation); optimistic badge flips without re-run; floor probe: zero
"RDC +" remnants; emerald 1 / muted 19 bars match the score distribution ·
AR RTL (فيل، الطابق الأرضي، ماي 2028) · VLM AFTER 5/5 PASS · residue
cleaned (2 PropertyMatch reverted, 2 test activities deleted) · errs=0 ·
evidence download/qa-p8/p811-*.

## D-UX-021 — Phase 8 / P8.12: tasks/calendar scan surfaces + the fr-DZ 12-hour locale bug — P8.12

**Context:** §53 audit-first round on the tasks view + visits calendar (the
P6-5-evolved surfaces). VLM critiques (8 tasks findings, 7 calendar findings)
triaged against code with DOM probes — 6 accepted, 9 rejected with evidence.

**Accepted & implemented:**
1. **fr-DZ/ar-DZ 12-HOUR BUG (the round's real catch):** `Intl.DateTimeFormat`
   resolves BOTH `fr-DZ` and `ar-DZ` to a 12-hour cycle ("02:05 PM" / "02:05 م")
   — every `formatTime`/`formatDateTime` call in the product rendered 12h in FR
   and AR while hard-coded strings (postpone toasts) said 24h. The VLM flagged
   it twice (rejected once on the wrong assumption of 24h — the DOM probe
   `"frDZ":"02:05 PM"` proved it real). Fix: `hourCycle: "h23"` in both
   functions — the DZ business standard (24h, latn digits) across all three
   languages. Single-source: all time formatting flows through format.ts.
2. **Calendar day cells = temporal records (F1+F5):** cells carried only status
   dots (pixel hunt). Now each visited day renders a micro time line — earliest
   visit time + `+n` remainder (24h, tabular) — so the cell answers when/how
   many/status-mix WITHOUT a click. Dots stay a status sample (MAX_DOTS=3).
3. **Today = filled primary pill on the date number (F2, iterated twice):**
   tint+ring failed the VLM check twice at /0.06 and ring-/45..60 — signal
   below the perceptual floor (same hazard class as the P8-10 opacity FAIL).
   The universal calendar convention (filled pill, Google-style) passes
   immediately. Cell keeps a soft tint + ring as reinforcement; weekend
   shading strengthened muted/30 → /45.
4. **Legend above the fold (F3, honest FAIL):** the status legend existed but
   sat under the fold on laptop viewports (y=689 vs 577px) — an invisible key.
   Moved above the grid; each dot also self-explains via `title` tooltip
   (status — lead · time).
5. **Tasks group headers = bands (F5):** normal groups `bg-muted/70`
   (deliberately above the zebra row floor of muted/60) so rapid scrolling
   anchors on them; overdue keeps rose, done recedes.
6. **Filter reset (F7):** owner/type selects show the active value but nothing
   said "how do I get everything back" — ghost "Réinitialiser" button appears
   only while a filter is active, clears both.

**Rejected (documented):** tasks F1 (composer-to-list distance — invalidation
reflows the list, edge case = type filter hiding the new row); F2/F8 (reserved
line time columns are the documented P6-5 D-UX-010 pattern; `.crm-hit` already
floors the checkbox target); F4 (owner caption hierarchy is deliberate);
F6 (TASK_TYPE_ICON is the shared vocabulary with title tooltips); calendar
F4 ("Aujourd'hui" button exists); F6 (count sits next to the month title);
tasks F3 (global "+ Nouveau prospect" CTA inside Tasks — real platform gap,
DEFERRED to the visual improvement plan: per-context quick-create).

**Tooling hazard (AGENTS.md):** Radix Tabs Trigger ignores synthetic
pointerdown/click in agent-browser — activate via focus + Enter keydown.
Radix Select opens via the CLI's CDP-level `click` (not eval-dispatched
events).

**Validation:** lint 0 · tsc 0 src · E2E: reset-filter flow (pick owner →
button appears → click → "Tous — Responsable" + button gone); day-cell click →
agenda with 24h times; cells 8× "HH:MM +n", AM/PM count 0 (FR + AR);
today pill DOM-probed (`bg-primary` span); legend inViewport (y=205 < 577);
group header bands computed (rose overdue / muted/70 normal) · AR RTL
(متأخرة/اليوم/قادمة headers, RTL grid, 24h latn, pill) · dark capture ·
VLM: tasks 4/4 PASS, calendar iterated 4/4 PASS (C1 pill PASS after 2 honest
FAILs) · errs=0 · evidence download/qa-p8/p812-* (before/after×4/agenda/ar/
ar-dark/ar-tasks).

---

## D-UX-022 — Phase 8 / P8.13: management views (analytics + audit) scan increments — P8.13

**Date:** 2026-10-07 · **Surface:** analytics-view.tsx, audit-view.tsx · **Doctrine:** §53 audit-first (VLM critique → DOM-probe triage → incremental)

**Context:** the two manager/admin surfaces had never received a P8 scan pass.
Both were already data-complete (funnel/leaderboard/stage durations; server-side
search, undo, entity tones) — the round was about scent, semantics, and calm.

**Audit:** 2 VLM critiques (8 + 8 findings), 13 REJECTED with probe evidence,
5 ACCEPTED:

1. **Analytics range echo (F3):** the right side of the range row re-rendered
   the selected pill's text ("30 jours") — a read-only duplicate. Now states
   the COVERED period (`07 sept. – 06 oct.` via formatDayMonth, latn in AR) —
   information instead of duplication. Tooltip "Période couverte".
2. **Funnel conversion scent (F2+F5):** "100%" next to Convertis was
   ambiguous (real data — all 15 qualified converted in-window, but % of what?).
   Card gains a definition hint line ("Taux de conversion depuis l'étape
   précédente"); each % gains a math tooltip (`24 / 35 · 69%`); the % column
   bumps 10px→11px font-medium — the bottleneck signal was the recessive
   element of its own card.
3. **Pipeline-by-stage axis (F7):** XAxis tickCount 4 (compact-DZD tick
   clutter).
4. **Audit alert fatigue (F3):** LOGIN/LOGIN_QUICK carried the rose USER-entity
   tint — 15 of the 25 first-page rows were alarm-colored routine logins.
   AUTH_ACTIONS (LOGIN/LOGIN_QUICK/LOGOUT_QUICK) now render neutral slate;
   rose stays reserved for LEADS_IMPORT_UNDONE reversals. Same restraint law
   as D-UX-014 (LEAD dropped from the entity map).
5. **Entity-id tooltips (F4):** 8-char id fragments gain full-id `title`
   (desktop + mobile cards).

**Rejected (probe-evidenced):** funnel bar shape (VLM misread — data narrows
35→24→15→15→15→7→6→5, it IS a funnel); pipeline bars misaligned (FALSE —
zero baseline confirmed); active-nav weakness (FALSE — bold + accent icon);
KPI whitespace (FALSE — compact); audit two-search-bars (different scopes —
global ⌘K vs view filter, P8-6 documented); change-chips grouping (chips
already bordered/filled — restraint); actor repetition (forensic clarity —
actor filter exists precisely because rows mix); timestamp weight (already
muted); "Nouveau prospect" in audit header (shell-level global quick-create,
cross-view consistency); sticky-header separation (crm-table-sticky already
ships it).

**i18n:** +2 keys ×3 (`analytics.range.covered`, `analytics.funnel.hint`).

**Validation:** lint 0 · tsc 0 src · DOM probes (hint text, "07 sept. – 06 oct.",
`24 / 35 · 69%` title, tone distribution slate 15 / amber 6 / violet 4, rose 0,
full-id tooltip) · E2E nav + re-render · AR RTL (معدل التحويل من المرحلة
السابقة, 07 سبتمبر – 06 أكتوبر, dir=rtl, login badges neutral) · VLM AFTER:
analytics 4/4 PASS, audit 3/3 PASS, AR analytics PASS, AR audit PASS ·
errs=0 · R14 dev-server restart ×1 · evidence download/qa-p8/p813-* (8
captures).

---

## D-UX-023 — Phase 8 / P8.14: administration surface (settings) — audited at the bar — P8.14

**Date:** 2026-10-07 · **Surface:** settings-view.tsx (+ team/targets/export sections) · **Doctrine:** §53 audit-first

**Context:** the settings view already carries D-UX-012 lineage (neutral icon
chips, draft-state editor with dirty tracking, proportional normalization,
sticky calm action bar, role-gated visibility). The round was a verification
audit, not a redesign.

**Audit:** VLM critique (8 findings, 3 scroll-position captures) → 7 REJECTED:
- F1 "user list without header" — FALSE: TeamSection ships a full card header
  (Équipe & accès + count badge + Ajouter un membre); the capture was scroll-cut.
- F3 "section spacing too tight" — space-y-6 is the app-wide rhythm; settings
  density is deliberately low-medium (mandate §24).
- F4 "ghost edit icons" — the row's management controls are INLINE (role
  Select, active Switch); the single ghost KeyRound is the secondary
  destructive-ish action — D-UX-010 restraint, with title + aria-label.
- F5 "organisation card redundant" — 3-line context record; cheap, scannable.
- F6 "sticky bar obscures content" — the standard sticky-save pattern
  (bg-background/95 + backdrop-blur + border, D-UX-012 vetted).
- F7 "label/value same weight" — disproven in code: text-crm-caption muted
  labels vs font-medium values.
- F8 "Nouveau prospect CTA in settings" — shell-level global quick-create,
  consistent across views (documented P8-6/P8-13).

**Accepted (1):**
- **F2 targets empty-state dead-end:** "Aucun objectif défini" described the
  feature but not the interaction model. The caption now teaches it:
  "Aucun objectif défini — saisissez un montant mensuel par membre ci-dessous
  (vide = effacer)." ×3 langs. Copy-only change.

**Validation:** lint 0 · tsc 0 src · DOM probe (enriched caption + 7 per-member
inputs) · AR RTL (Arabic caption renders) · dark capture · VLM 2/2 PASS after
correcting the capture scroll position · errs=0 · evidence
download/qa-p8/p814-* (7 captures).

**Lesson (logged for future audits):** VLM scroll-cut captures produce
phantom "missing header" findings — always scrollIntoView the specific element
before screenshotting a section for critique.

---

## D-UX-024 — Phase 8 / P8.15: AI contextual UX — verify-before-action disclosure — P8.15

**Date:** 2026-10-07 · **Surface:** lead-copilot-card.tsx, bulk-copilot-dialog.tsx · **Doctrine:** AI output visually distinguishable from database facts (P8 mandate)

**Context:** the copilot surfaces already carried D-UX-011 lineage: primary-tint
family (bg-primary/[0.03] + border-primary/25 — the only primary-tinted cards
in the product), Bot iconography, generatedAt provenance, opt-in actions
(Apply score / Create task = explicit buttons; nothing auto-applies except the
bulk dialog's declared auto-apply switch).

**Audit:** live generation (COLD assessment for Réda Mokrani) + VLM critique
(6 findings) → 4 REJECTED with DOM probes:
- F1 "score looks like a DB fact" — the record SCORE field is the system of
  record; the AI's suggested score lives INSIDE the tinted card with an
  explicit Apply button and current-value comparison.
- F2 "no provenance" — disproven: "Généré · cette minute-ci" renders in the
  card header (capture was cut).
- F4 "opt-in unclear" — create-task/apply-score are explicit buttons; the
  copilot only writes an Activity log; DB mutations happen on click.
- F6 "score black box" — scoreRationale renders ("Justification · …").
- F5 thumbs-up/down feedback loop — genuine feature idea, product decision,
  deferred (documented).

**Accepted (1):**
- **F3 hallucination disclaimer:** an explicit verify-before-action line now
  closes the AI card (footer rule, 10px muted) and opens the bulk dialog
  (header footnote): "Analyse générée par IA — vérifiez les informations avant
  toute action." / "AI-generated assessment — verify the information before
  taking action." / "تحليل مُولّد بالذكاء الاصطناعي — تحقق من المعلومات قبل
  اتخاذ أي إجراء." The tint distinguishes; the disclosure disclaims.

**Validation:** lint 0 · tsc 0 src · DOM probe (disclaimer text in the tinted
card) · VLM PASS (after scrollIntoView correction — first capture missed the
card footer below the fold) · AR RTL (Arabic disclaimer renders, dir=rtl) ·
errs=0 · R14 restart ×1 mid-round · evidence download/qa-p8/p815-* (4
captures).

**Lesson:** VLM critique of drawers must scrollIntoView the target element —
fold-cut captures produce both phantom "missing" findings AND missed real
ones.

---

## D-UX-025 — Phase 8 / P8.16–P8.20: the four systematic sweeps + full visual QA — Phase 8 CLOSE

**Date:** 2026-10-07 · **Surfaces:** all · **Doctrine:** continuous gates (§54 P8.16–P8.20)

**P8.16 Responsive (verification, zero defects):** mobile 390 × 8 views + full-width lead sheet + 358px command palette + notifications popover — all overflowX=false, errs=0; tablet 768 × 5 views clean; desktop restored. One VLM claim (notifications clipped at right edge) DISPROVEN by exact geometry (card 0→340px, "Tout marquer" ends x=323 < 390 — ellipsis truncation misread as cut-off). The incremental mobile-first discipline of P6–P8 holds.

**P8.17 RTL/i18n (verification, zero defects):** i18n completeness 1049 keys ×3 languages, 0 missing (i18n-analyze). AR desktop sweep ×9 views — dir=rtl, no overflow, errs=0. Hardcoded-French scan ×8 views (22 telltale strings incl. Aucun/Terminer/jours/Rechercher) — ZERO leftovers. Lead drawer bidi isolation intact (email dir="ltr" attr, tel: href). VLM 3/3 PASS (drawer/dashboard/pipeline mirroring + no bidi corruption).

**P8.18 A11y (verification, zero defects):** accessible names 100% clean ×9 views (buttons/links/inputs/selects/checkboxes all labeled — one probe hit was Radix's aria-hidden native select, a non-defect). Landmarks main/header/nav/footer/aside present. WCAG AA contrast via canvas lab→sRGB conversion: muted-foreground 5.73:1, body 18.04:1. Keyboard: Tab reaches nav, 2px emerald focus-visible ring confirmed (first probe truncated the shadow string — read the FULL box-shadow before judging focus invisible). One h1 per view. aria-live polite on slider values, aria-busy on loading regions.

**P8.19 Performance (healthy):** steady-state API 15–70ms across endpoints (dashboard 33ms with ~12 aggregates); zero N+1 (Prisma IN-batched: LeadTag ×8 in one round-trip); notifications poll 60s / staleTime 30s; dev chunk 1.79MB (dev-mode inflation; single-route architecture = single chunk, accepted tradeoff).

**P8.20 Full visual QA:** final consolidated sweep ×9 views — errs=0, no overflow; VLM 4/4 PASS (dashboard/leads/pipeline/analytics) + overall verdict: "high professional enterprise quality… consistent design language… suitable for a real-estate business environment."

**Ops (this round):** R14 OOM root-caused — next-server killed at 1.4GB RSS while 3 stale agent-browser chrome instances (41 processes) ran concurrently; stale instances killed; set-viewport.ts now auto-discovers the live chrome debug port.

**Phase 8 status: COMPLETE (P8.1–P8.20).** Implementation rounds: D-UX-015 through D-UX-024 (10 decision entries); verification rounds: P8.16–P8.19 (zero code defects — the incremental discipline avoided retrofit debt). NEXT: Phase 9 per VISUAL_IMPROVEMENT_PLAN.md (P9.1–P9.10), awaiting user go-ahead.

---

## D-UX-026 — Phase 9 / P9.1: attention-tier + neutral-ladder token foundation

**Date:** 2026-10-08 · **Surfaces:** globals.css, tasks, visits, audit, dashboard attention strip, pipeline, badges · **Maps to:** G2 G3 (VISUAL_IMPROVEMENT_PLAN §2.2)

Five grades per attention tier as CSS vars — bg (50-grade wash) · strong (100-grade) · fg (600/700 text) · line (200-grade border) · accent (500-grade solid, usable with Tailwind opacity modifiers) — ×3 tiers: attn-1 danger rose (hue 25, warm), attn-2 warning amber (hue 70-75, accent = the brand --highlight), attn-3 info emerald (hue 160). Both modes defined with lightness flipped ~0.45→0.6+ (P8-10 perceptual-parity lesson honored). Neutral ladder tone-3/4/5 = the zebra/band/hover mixes the list-row classes invented ad hoc, now named (bg-tone-3/4/5); crm-zebra + crm-list-row read the tokens (one source). chart-6 warm stone added (6th categorical). Migration: tasks overdue band/chips/due-text/icon (6), visits NO_SHOW hint + cancel hover (2), audit undo hovers + dialog chip + confirm (4), attention-strip tone maps, pipeline aging chips + lost-reason + next-action, priority dots/URGENT text. Ops lesson: turbopack stale-CSS after OOM restart (watcher dies; touch doesn't revive it) → rm -rf .next is the fix. VLM 8/8 PASS (tasks overdue band 4/4 + dashboard attention 4/4).

## D-UX-027 — Phase 9 / P9.2: typography enforcement — the Stripe display-number move

**Date:** 2026-10-08 · **Surfaces:** globals.css num-xl, analytics, targets panel, import result, recent-leads, opportunity dialog, calendar, copilot · **Maps to:** G1 (§4)

text-crm-num-xl redefined 22px/600 → **28px/500** — bigger but lighter; premium = restraint at display sizes. formatDZDPair() added (value/unit split, locale-aware, never diverges from formatDZD). Analytics KPI cards adopt num-xl + caption-muted unit suffix ("M DA"/"jours" at 13px never shout at hero size); targets-panel hero achieves the same split with count-up motion preserved (two derived MotionValues); import step-result stats text-2xl/700 → num-xl. Record-name weight rule enforced: recent-leads names 500→600 (G1's evidence — leads-view parity). Opportunity-dialog amount → text-crm-num role; visits-calendar month title → text-crm-section ladder; copilot score font-bold→500 (+ its dots ride attn tokens — P9.1 completion). Skeletons resized to match. Verification: VLM 8/8 PASS — one full-page FAIL ("M DA same size") DISPROVEN by geometry probe (unit 13px vs number 28px computed) + centered closeup re-check PASS; the P8-16 scale-misread lesson applied (probe + closeup override full-page VLM).

## D-UX-028 — Phase 9 / P9.3: icon vocabulary registry

**Date:** 2026-10-08 · **Surfaces:** icon-vocabulary.tsx (new), search palette, 8 files (size migration) · **Maps to:** G2 G6 (§3)

icon-vocabulary.tsx = THE glyph contract: ENTITY_ICON (10 domain concepts — values record the canonical P4–P8 set: lead=Users, contact=UserRound, opportunity=Briefcase, project=Building2, developer=Building, apartment=Home, task=CheckSquare, visit=CalendarCheck, payment=Banknote, document=FileText) + re-exports of TASK_TYPE_ICON / ACTIVITY_TYPE_ICON / SOURCE_ICON (one import surface). Search palette rewired from 6 inline imports to ENTITY_ICON consumption. Size ladder enforced: caption floor size-3 → size-3.5 across 20 glyphs in 8 files — the ladder is now exactly 3.5 caption / 4 body / 5 hero; changes require a D-UX entry. Audits: empty states already wear domain glyphs at size-5 (no refresh needed); emoji scan of i18n domains = zero; family = 100% Lucide (zero mixing). VLM 4/4 PASS on the palette glyph system.

## D-UX-029 — Phase 9 / P9.4: row tactility + status ramps + in-row meters

**Date:** 2026-10-08 · **Surfaces:** globals.css, constants, lead-row, tasks/visits rows, drawer opportunity cards · **Maps to:** G4 G5 G2 (§2.2.3, §5.1, §5.2)

.crm-list-row-accent = DIV-row leading-edge affordance (G4): tasks/visits rows get the lead-row hover inset-bar — "record row" hover feedback (these rows host drill-downs; not a whole-row-click claim). Lead status NEW: slate → **pale-primary at 45% attn-3** (G2 — "Nouveau" reads fresh/active, "untouched, act on me"; clearly lighter than QUALIFIED's full emerald wash so the two never collide; lead lifecycle ≠ opportunity stage map so STAGE_TONE.NEW keeps slate — different enum, different surface). Budget micro-meter in leads rows (G5): **fixed 0–100M DA reference domain** (same position meaning on every page — never re-scales per view which would lie across pages); meter only when BOTH bounds exist (single-sided budgets stay text — "a meter only when the number HAS a domain range"); inline beside the label mirroring the score-column idiom; RTL-safe logical inset; 23 rows render it. Drawer opportunity cards gain the probability meter (h-1 bg-primary + aria progressbar — the pipeline idiom extended). Lead-row overdue text → attn-1-fg. VLM 4/4 PASS.

## D-UX-030 — Phase 9 / P9.5: context-aware primary actions + palette command surface

**Date:** 2026-10-08 · **Surfaces:** shell, search-command, store, drawer · **Maps to:** G6 (§6.2, §5.1)

ONE filled primary per view (G6): the global "+ prospect" demotes to outline on tasks/visits (where the view owns its primary — composer / schedule dialog); stays filled elsewhere (probe-verified both states). The empty palette becomes a command surface: **session recents** group (last 5 viewed leads — store.pushRecentLead fed by every successful drawer load, most-recent-first deduped capped 5, in-memory only so ids never outlive the session / org-scope safety) + **"Créer" group** (Nouveau prospect opens the shell dialog via onQuickCreateLead prop; Nouvelle tâche navigates to tasks from ANY view and focuses the quick-add composer via a 100ms×20 retry-focus — plain rAF fires before React mounts the view; the G6 dead-end killed). i18n +3 keys ×3. E2E: ⌘K → "Nouvelle tâche" → #/tasks + composer focused; VLM 4/4 PASS on the recents/actions surface.

## D-UX-031 — Phase 9 / P9.6: identity avatar tones

**Date:** 2026-10-08 · **Surfaces:** badges.tsx, pipeline kanban, drawer owner chip · **Maps to:** G5 (§5.2)

userTone(userId) = stable string-hash → one of six soft 500/15 identity washes (emerald/amber/violet/teal/orange/rose): **same owner = same hue on every surface**, scan identity without photos. Kanban owner avatars colorized (was uniform bg-muted) — VLM confirmed same-owner-same-color (Lina Boukhari green "LB", Amine Cherif orange "AC") + calm pastels 4/4 PASS; 42 avatars across 6+ hues verified. Drawer owner-switch chip leads with a size-4 initials avatar in the owner's identity tone (replaces the generic UserRound glyph — the cockpit's one-line-of-truth gains identity). **Targets panel deliberately KEEPS role tones** — role encodes function (management view), identity encodes person; two different systems, both intentional.

## D-UX-032 — Phase 9 / P9.7: motion catalog completion

**Date:** 2026-10-08 · **Surfaces:** ui/button, providers, badges, pipeline kanban, drawer · **Maps to:** §6.1

Press feedback on EVERY button variant: `motion-safe:active:scale-[0.98]` (100ms via transition-all; reduced-motion users exempt; NEVER on rows). **Kanban FLIP**: KanbanCard restructured as dnd-shell + motion.div visual card with `layoutId` — cross-column drops glide 180ms ease-out from the old viewport position, same-column reflows animate via plain `layout`; the dnd-kit shell keeps drag transform/measurements separate so framer and dnd never fight over the transform property; E2E drag verified with DB persistence (and demo data restored via PATCH). Badge status-swap crossfade generalized (CrossfadeLabel — 150ms key-remount fade on LeadStatusBadge + StageBadge; no exit animation so badges never collapse mid-swap). Drawer content fade-in: ONE motion wrapper (≤2 stagger items rule), 150ms opacity+4px rise, smooths lead-to-lead switches. **MotionConfig reducedMotion="user" at providers root** = ONE global switch for all framer animation (the plan's reduced-motion clause, wired once). States-matrix fixture → UI_QA.md (P9.10).

## D-UX-033 — Phase 9 / P9.8: keyboard navigation (j/k)

**Date:** 2026-10-08 · **Surfaces:** leads-view · **Maps to:** §6.2

Linear-style **j/k row navigation** on the leads table: focus moves row-to-row without the Tab detour through every control. Enter/Space keep the existing row contract (open the drawer — role=button semantics, a11y-clean; the plan's "Space select" variant deliberately NOT taken: changing Space's meaning would break the established row contract). Guards: never while typing (input/textarea/select/contenteditable), never inside dialogs/palette/menus/poppers; first j from outside lands on row 1, k from outside lands on the last row. Ships default-on (non-destructive, focus-only — the plan's "feature probe then default-on" collapsed to default-on since it cannot alter data). E2E: j→j→k moves focus TR-to-TR; Enter opens the drawer with the #/leads/:id deep link. ⌘⇧K command-only mode deferred (stretch — the palette already carries the command surface from P9.5).

## D-UX-034 — Phase 9 / P9.9: analytics chart pass

**Date:** 2026-10-08 · **Surfaces:** analytics-view · **Maps to:** G5 (§2.2.5)

CHART_CATEGORICAL exported — fixed-order 6-color ramp (emerald·amber·violet·rose·teal·warm-stone), rule: **same series = same color across every chart**; future categorical charts index by the category's position in its CANONICAL enum order, never by rank (a category never changes color between renders). KPI sparklines: pure-SVG 6-point trailing series (no chart lib) on the two KPIs that HAVE one — leads = amber chart-2, wonValue = emerald chart-1, matching the monthly trend chart exactly (sparkline ↔ chart read as one system); opps/pipeline/cycle have no trailing series → no sparkline (the meter-only-with-domain law from P9.4 applied to charts). KPI display numbers already landed in P9.2 (num-xl + unit split — stage overlap confirmed). VLM 4/4 PASS (subtle, series-colored, layout clean).

## D-UX-035 — Phase 9 / P9.10: full-platform visual QA + Phase 9 CLOSE

**Date:** 2026-10-08 · **Surfaces:** all · **Doctrine:** §8 validation gates (VISUAL_IMPROVEMENT_PLAN)

Consolidated verification sweep: 9 views × light — errs=0, no overflow, main landmark present. AR RTL ×9 views — dir=rtl, 0 errors, no real overflow. Mobile 390 (element-level check) — **0 unclipped offenders** on dashboard/leads/pipeline/tasks/settings; the naive scrollWidth>clientWidth probe shows a phantom 2px (zero offending elements found by rect walk — emulation subpixel artifact, probe-overridden, documented). Dark mode: attention-tier token parity probed (overdue band = oklab(0.28 0.045 0.021 / 0.95) = dark attn-1 exactly). lint 0 · tsc 0 src throughout. Eight VLM runs this phase, all PASS; two probe-overridden misreads (full-page scale + phantom overflow) — the verify-first discipline held. UI_QA.md created (interaction states matrix + regression baseline). **Phase 9 status: COMPLETE (P9.1–P9.10) — the VISUAL_IMPROVEMENT_PLAN is fully implemented.** The platform now composes from one token set (attention tiers + neutral ladder + chart ramp), one glyph contract, one type ladder with Stripe display numbers, one motion catalog behind a single reduced-motion switch, and a closed element vocabulary (essential §5.1 + secondary §5.2) — the "universal UI" as disciplined repetition, originality in the warm-paper/emerald identity.

## D-UX-036 — Phase 10 / V1.9: elevation ramp (multi-layer depth tokens)

**Date:** 2026-10-08 · **Surfaces:** all floating surfaces + kanban · **Commission:** V1.9 « Premium 2026 nouvelle génération »

Audit finding: only `--shadow-card` (single 1px layer) existed; popovers/dialogs/sheets rode shadcn defaults (`shadow-md`/`shadow-lg`) — no coherent depth ramp, no dark-mode-tuned layers. Decision: `--elev-1..4` token ramp, each level a two-layer pair (tight contact shadow + soft ambient) reading as ONE plane rising off the page: elev-1 = resting cards (≡ shadow-card, existing call sites untouched); elev-2 = dropdown/popover/select (+ notifications, tooltip surface family); elev-3 = dialog/palette/toast/dropdown sub-content; elev-4 = sheet/drawer (edge-hugging overlays get deepest ambient, no contact point). Dark mode: same layer structure, deeper opacity — perceptual parity by structure, not by number. Wired via `@theme inline` → `shadow-elev-*` utilities across popover/dropdown-menu/select/menubar/context-menu/dialog/sheet/toast (11 sites). Kanban cards gain the platform's only physical hover-lift: `whileHover={{y:-2}}` through framer's own transform system (never fights the P9.7 FLIP layoutId animation; MotionConfig reducedMotion="user" exempts reduced-motion users) + `hover:shadow-elev-2` deepening — cards lift, rows never move (D-UX-032 law upheld). Verified: popover computed box-shadow = both layers (4 TW composition layers + contact 0.05 + ambient 0.08); dark elev-3/4 probed at exact dark values; VLM pipeline 3/3 PASS ("crisp, elevated, neither flat nor heavy").

## D-UX-037 — Phase 10 / V1.9: version identity

**Date:** 2026-10-08 · **Surfaces:** sidebar, footer · **Commission:** V1.9

The footer still read « ASAS CRM v1.0 — © 2025 » — three major phases behind reality. Decision: bump to v1.9/© 2026 in all three languages (fr/en/ar), and the sidebar gains a quiet identity chip: mono `v1.9` badge riding the ASAS wordmark (`bg-white/10` on the dark rail, 9px font-medium tracking-wide — present, never shouting). Verified in-browser (chip textContent + footer string ×3 langs including AR) + VLM C1 PASS.

## D-UX-038 — Phase 10 / V1.9: per-user density control (compact/comfortable)

**Date:** 2026-10-08 · **Surfaces:** crm-td/crm-th tables, sidebar controls · **Commission:** V1.9 (the Phase 9 backlog product decision, now commissioned)

Salesforce-Cosmos-style density switch, shipped as a personal preference: store gains `density: "comfortable" | "compact"` (persisted in the existing asas-lang localStorage via partialize/merge with isDensity guard), synced to `<html data-density>` by `useDocumentDensitySync` (same pattern as the lang/dir sync). CSS: `.crm-td`/`.crm-th` heights ride `--crm-td-h`/`--crm-th-h` — comfortable = the P6 baseline (40/36px), compact = 36/32px (power-user scan mode). Toggle lives in the sidebar controls row next to lang/theme (Rows3/Rows4 icon metaphor — three visible rows vs four; aria-pressed carries state, title announces the switch direction). Scope honesty: table min-heights only — the leads table's 55px rows are content-driven (two-line name cell + wrapped phone cell), so compact shows on single-line surfaces (audit/analytics/recent-leads/dashboard tables: verified 36px/32px live, comfortable restores 40px). i18n ×3 keys ×3 langs. NOT done: per-surface density or list-row padding vars — deferred until a surface asks for them.

## D-UX-039 — Phase 10 / V1.9: skeleton shimmer sweep

**Date:** 2026-10-08 · **Surfaces:** Skeleton primitive (platform-wide) · **Commission:** V1.9

The breathing pulse (`animate-pulse`) retired for the 2026-gen directional shimmer: `.crm-shimmer` base rides `--muted` (neutral ladder — placeholders are quiet by law; the old `bg-accent` amber tint retired) with a `::after` gradient sweep (1.8s ease-in-out, `color-mix(card 70%)`), RTL-mirrored via `[dir=rtl]` animation-name swap, `prefers-reduced-motion` falls back to a calm 2.4s opacity breath — never motion. One primitive change upgrades every loading placeholder platform-wide (analytics KPIs/charts, notifications, leads, audit, dashboard, targets). Verified: computed animation `crm-shimmer-sweep 1.8s`, RTL variant live under dir=rtl.

## D-UX-040 — Phase 10 / V1.9: living KPIs — period-over-period deltas

**Date:** 2026-10-08 · **Surfaces:** /api/analytics, analytics KPI header · **Commission:** V1.9

The « is this going up or down? » question now answered in-line: API computes `prevPeriod` (same-length window immediately before the selected one) for leads/opps/wonValue; KPI cards render a delta chip on the label row — TrendingUp/TrendingDown glyph + capped % (±999), emerald attn-3 up / rose attn-1 down, tooltip « vs période précédente ». Data honesty laws applied: prev=0 → no chip (infinite % is noise); pipeline value + cycle time are live snapshots with no historical twin → no delta (meter-only-with-domain law); large seed-data deltas (600%/275%/999%) render correctly capped. Verified live: 3 chips, correct tiers, VLM analytics 3/3 PASS ("calm, well-aligned, clearly separated from the large numbers").

## D-UX-041 — Phase 10 / V1.9: palette polish — match highlight + kbd legend

**Date:** 2026-10-08 · **Surfaces:** command palette · **Commission:** V1.9

Two upgrades to the ⌘K surface: (1) matched-substring highlight — the matched characters glow with a soft amber wash (`bg-attn-2/70`, 600 weight) so the eye lands on WHY a row matched; accent-insensitive matching mirrors the server's ranking ("reda" highlights "Réda") via NFD diacritic folding with a per-character index walk mapping normalized indices back to ORIGINAL text indices (folding changes string length — naive slicing corrupts). Fuzzy/non-contiguous server matches highlight nothing — honest absence, never a wrong glow. Applied to lead/opportunity/project/developer/contact primary text. (2) kbd legend footer — ↑↓ Naviguer / ↵ Ouvrir / esc Fermer, the keyboard contract visible at the foot instead of documented. **Ops catch:** `\p{DiacriticMark}` (ES2024 property) crashed SSR on this Node — `Invalid property name`; fixed with the universally-supported `\p{M}` (Mark category, ES2018). Lesson: prefer oldest-supported Unicode property escapes; SSR regex support ≠ browser support. Verified: 1 mark on "Réda" with amber bg + 600 weight, legend 3 kbds, VLM 3/3 PASS ×2 modes.

## D-UX-042 — Phase 10 / V1.9: V1.9 CLOSE — verification + rejected alternative

**Date:** 2026-10-08 · **Surfaces:** all · **Commission:** V1.9

Consolidated verification: 9-view sweep — 0 console errors, 0 horizontal overflow, density comfortable restored; dark-mode elevation + shimmer parity probed; AR RTL (dir, footer v1.9 AR, shimmer RTL animation) probed; transient `formatDZDPair is not defined` in TargetsPanel root-caused as the stale-chunk trap (P9 lesson: full reload heals; import was present in source) — 0 errors after clean reload across the full sweep. VLM 15/15 criteria PASS across 5 captures (dark analytics/dashboard/pipeline/palette + light palette/dashboard/compact-audit). lint 0 · tsc 0 src. REJECTED: notification day-grouping (Aujourd'hui/Hier) — the notification model is live-computed reminders grouped by TYPE with relative timestamps, not an event feed; day groups would be a category error. **Phase 10 / V1.9 status: COMPLETE** — elevation ramp, version identity, density control, shimmer, living KPIs, palette polish — the 2026 nouvelle génération layer atop the P9 universal system.

## D-UX-043 — Phase 11 / P11: kanban column WIP limits (capacity signal, warn-never-block)

**Date:** 2026-10-08 · **Surfaces:** pipeline-view (kanban), PATCH /api/pipeline/stages/:id · **Commission:** Phase 11 candidate (backlog product decision — WIP limits)

The kanban answers « how much is sitting here? » but not « how much SHOULD sit here? ». Decision: `PipelineStage.wipLimit` (nullable int, 1..99 — null = unlimited, migration `20261007234744_p11_stage_wip_limit`) rendered as a **purely visual capacity signal** — the warn-never-block law: the board NEVER refuses a stage move; it warns with a toast naming the column and resulting count/limit, and the column shows the state. Chip semantics ride the attention ladder already established for next-action chips: neutral `n` under the limit, amber `n/limit` at capacity, rose `n/limit` over + a rose `ring-attn-1-line` on the whole column. ADMIN-only editor: Gauge-icon popover on each column header (mirrors the server's `requireUser("ADMIN")`; zod contract 1..99|null exactly), every change audit-logged (`PIPELINE_STAGE_WIP_LIMIT`, before/after values, ×3 langs). **Filters-suppression law**: while board filters are ON the limit display is suppressed — a filtered count read as capacity would lie (capacity is a board-level signal, not a search-result property); the over-limit drop toast obeys the same law. The full count/limit sentence lives in the column aria-label (chip itself aria-hidden — no double announcement); mobile stage rows get chip parity. API hardening verified: org scope = stage must belong to THIS org's default pipeline (foreign-tenant id → 404), SALES_AGENT PATCH → 403, wipLimit 0/100 → 422. E2E: limit 2 on « Qualifiée » → chip 3/2 rose + ring + AR aria « مؤهلة — 5 من 2 فرصة »; drag over-limit → toast « dépasse sa limite d'encours (5/2) » AND the move persists (warn-never-block proven end-to-end); « Retirer la limite » clears to baseline; audit rows before/after verified then residue-restored.

## D-UX-044 — Phase 11 / P11: visits calendar week view (scan surface, one cursor)

**Date:** 2026-10-08 · **Surfaces:** visits-calendar · **Commission:** Phase 11 candidate (backlog product decision — week view)

The month grid answers capacity; agents work in weeks. Decision: a month|week segmented control (`visits.calendar.viewAria` group) where **ONE cursor anchors both periods** — the cursor is just "a day we're looking at"; month view derives month bounds, week view its Monday-based week, so switching modes never jumps the display (landing on the week containing the 1st of the visible month is the honest consequence of the anchor, and « Aujourd'hui » returns to now). Week view = 7 day-agenda columns (`WeekDayColumn`, role=gridcell): time-sorted rows (time · status dot · lead, per-row tooltip) — **a scan surface, NOT an action surface**: the whole column selects the day and the SHARED day-agenda panel below carries all actions (confirm/complete/reschedule/cancel) — both views expose exactly the same verbs, zero action duplication. Today = the filled primary pill on the date number (the month-grid convention — tint/ring-only failed VLM twice at P8-12, the pill is the proven signal); weekend columns muted; `WeekSkeleton` mirrors the grid shape. The visible-period react-query params widen from month bounds to month-OR-week bounds (same `["visits", params]` key pattern → every visit mutation still invalidates all modes). Responsive from one component: `md:grid-cols-7` desktop / full-width stacked columns on mobile. i18n +8 keys ×3 langs (mode labels, viewAria, weekOf, prev/next week, empty states). E2E: toggle keeps Semaine pressed; navigation ±7 days; today pill on the 7th; **UI ≡ API parity** (7 columns 1,1,3,1,1,1,0 vs API by-day exact — a first-pass "2×" discrepancy was disproven as a recursive-textContent probe artifact); column click selects + agenda « Visites du 07 oct. 2026 » renders; AR RTL (شهر/أسبوع, dir=rtl, no overflow).

## D-UX-045 — Phase 35 / P35: the gradient-purge completion (D-UX-011's missed twins)

**Date:** 2026-10-12 · **Surfaces:** states.tsx (every empty state app-wide) · opportunity-detail-dialog header band · apartment-detail-dialog reservation panel · bulk-copilot-dialog chip + progress · deal-economics §37/§38 panels · **Commission:** the user's visual-identity round («为所有平台页面开发用户界面…最佳视觉识别…最新的技术、设计和交互方式»)

P6-6/P6-9 fixed the copilot-card twins (flat primary tints — D-UX-011) but five interior surfaces kept the pre-law language: the EmptyState icon tile (gradient + blur-md glow span), the opportunity dialog's header band (`bg-gradient-to-br from-primary/[0.07]`), the apartment reservation panel (emerald gradient + raw palette), the bulk-copilot Sparkles chip (`from-emerald-500 to-teal-600`) + progress bar (same), and deal-economics' entire raw emerald/amber vocabulary. The purge completes: every interior informational surface now speaks the flat-tint law — EmptyState = `bg-primary/10` + `ring-primary/15` (glow span deleted); opportunity header = the D-UX-011 header-strip spec verbatim (`bg-primary/[0.05]` + `border-primary/25`); apartment reservation = `border-attn-3-line bg-attn-3` + `bg-attn-3-strong` icon chip; bulk chip = `bg-attn-3-accent`, progress = flat `bg-primary`; deal-economics' INCENTIVE_TONE + 10 inline pairs migrate to the attn-tier tokens (same perceptual grade per mode, one source — the D-UX-026 law finally applied to the commission domain). VLM-verified on after-captures (flat/consistent ×3 surfaces). Law: **the twin rule is a sweep obligation** — when a visual law lands, the grep for the outlawed pattern is part of the landing (this class recurred because P6-9 fixed only the surfaces the VLM had photographed).

## D-UX-046 — Phase 35 / P35: quiet-chrome brand marks (flat logo tiles + rail de-glow)

**Date:** 2026-10-12 · **Surfaces:** sidebar NavLogo · BootSplash · LoginOverlay brand tiles ×2 · sidebar active rail · **Commission:** same as D-UX-045

The four `from-sidebar-primary to-primary` gradient logo tiles (sidebar, boot splash, login desktop, login mobile) flatten to `bg-primary` + the existing hairline ring — Linear-style quiet chrome; the mark carries the identity, the surface stays silent. The sidebar active-item rail loses its `shadow-[0_0_8px_rgba(51,156,109,0.7)]` glow (DESIGN_SYSTEM §5 "NO glows" — a violation that predates the token era and survived every audit because it sits in the theme-invariant sidebar, outside both mode token blocks). **Kept deliberately:** the login canvas's radial emerald/amber atmosphere + 44px grid — the ONE expressive brand surface in the product (Stripe's login pattern: identity lives at the threshold, quiet everywhere after). VLM-verified: flat marks + atmosphere present on the after-capture.

## D-UX-047 — Phase 35 / P35: scroll-driven sticky chrome (CSS scroll-driven animations, progressive enhancement)

**Date:** 2026-10-12 · **Surfaces:** shell topbar (all 9 views) · every `.crm-table-sticky` header (leads, audit) · globals.css · **Commission:** the directive's «最新的技术» — the 2026-gen native CSS primitive

The topbar and sticky table headers gain a whisper shadow ONLY while content scrolls under them — communicating layering the way Linear does, with zero JS, zero layout thrash, compositor-only: **CSS scroll-driven animations** (`animation-timeline: scroll(root)` for the document-scroller topbar, range 0→96px; `scroll(nearest)` for the sticky-th inside each table's own overflow wrapper, range 0→72px; keyframes animate box-shadow only — nothing moves, the surface gains weight). Progressive enhancement by construction: the entire block is `@supports (animation-timeline: scroll())`-gated AND `prefers-reduced-motion: no-preference`-gated, so engines without scroll timelines and reduced-motion users keep the exact pre-P35 resting chrome (border-b only). New token `--sticky-chrome-shadow` (light `0 1px 2px rgb(20 18 12/0.07)` · dark `0 1px 2px rgb(0 0 0/0.45)` — mode-scoped like every shadow). Live-verified at both scroll positions (computed box-shadow transparent at 0 → 0.07-grade at 400px, both surfaces). Law: **scroll-driven chrome is decoration-of-state, not motion** — the animation never touches transform/opacity of content, so it passes the §8 motion doctrine while adding the modern layering cue.

## D-UX-048 — Phase 35 / P35: sparkline anchors (area fill + baseline + end-dot)

**Date:** 2026-10-12 · **Surfaces:** analytics KPI sparklines · **Commission:** same as D-UX-045 (VLM gap: "floating lines without spatial reference")

The P9.9 bare polyline (0.6-opacity stroke only) read as decorative — no spatial reference. Three anchors land, all doctrine-safe: a **12%-opacity area fill** under the curve (volume without weight), a **hairline baseline** at the metric's floor (`var(--border)` — the shape now stands on something), and a **solid end-dot** (`r=1.9`, full series color, background-punched with a 0.75 `var(--background)` stroke — "this is now"). Stroke, color discipline, and size unchanged (64×18 viewBox). VLM-verified on the after-capture: area fill + end dot present, anchored not floating.

## D-UX-049 — Phase 36 / P36: at-rest chart legend (the dual-axis disclosure)

**Date:** 2026-10-14 · **Surfaces:** analytics MonthlyTrendChart · **Commission:** the user's repeated visual-identity directive (P36 evidence-gated round)

The 6-month ComposedChart encodes two series on dual axes (leads = amber bars/left axis, won value = emerald line/right axis — the documented color law the KPI sparklines also ride), but the mapping lived ONLY in the hover tooltip: at rest a dual-axis chart with two unlabeled series invites misreading (VLM audit: "the orange bar and green line overlap without clear legends… potential data misinterpretation" — verified against code: no `<Legend>`, no at-rest labels). Fix: two quiet legend chips under the card title — **glyph shape encodes series type** (amber `size-2` square = bar; emerald `h-[3px] w-3.5` rounded line = line), labels reuse existing keys (`dash.funnel.leads` / `analytics.kpi.wonValue` — key-neutral per FR26b). No borders, muted caption text, flex-wrap for mobile, auto-mirrors in RTL. VLM PASS: "LEGEND: yes — QUIET: yes". Law: **a color law that only the tooltip can recite is not a law** — any multi-series chart carries its mapping at rest.

## D-UX-050 — Phase 36 / P36: identity de-duplication (one version surface)

**Date:** 2026-10-14 · **Surfaces:** app footer (i18n `app.footer.left` ×3 langs) · **Commission:** same round (VLM: "the bottom status bar contains redundant information — 'ASAS CRM v1.9' appears twice")

The version string rendered TWICE on every screen: the sidebar's D-UX-037 version chip AND the footer's `ASAS CRM v1.9 — © 2026 …` prefix. Verified in code (sidebar-nav.tsx chip + shell.tsx footer key) — real redundancy, not a VLM misread. Fix: the footer drops the `ASAS CRM v1.9 — ` prefix in all three dictionaries (the copyright line stays); the sidebar chip is the single version surface (it already carries build identity next to the brand mark, D-UX-037's documented role). VLM PASS: "FOOTER-VERSION: no — SIDEBAR-CHIP: yes". Law: **identity information appears exactly once per screen** — a second rendering of the same fact is chrome noise (the quiet-chrome doctrine D-UX-046 applied to data).

## D-UX-051 — Phase 36 / P36: the truncation-disclosure sweep (P8-6 generalized to a law)

**Date:** 2026-10-14 · **Surfaces:** dashboard attention-strip / right-panels (hot opps) / economics-panels (commissions) / today-panel · pipeline kanban cards · leads rows (desktop + mobile) · **Commission:** same round (VLM ×3 surfaces: "aggressively truncated with no overflow indicators"; P8-6 had fixed ONE cell in isolation)

Truncation (`truncate`) without disclosure was a per-cell patch, never a law: P8-6 added `title` to the leads owner-cell in 2026-10-07 and the class kept recurring (attention hints, hot-opp titles/next-actions, commissions rows, today-panel names, pipeline card lead/owner names, leads name/email). The sweep lands the generalization: **every content-bearing truncating run carries its full text in `title`** (dynamic content gets the composed string — name · project; static i18n hints get the same translated sentence). Scope carve-out on record: static short label keys (funnel step labels, column headers, translated one-word labels) and numeric captions stay exempt — the law covers content the user cannot otherwise recover. Verified live in DOM across six surfaces (attention hints true, commissions 4/4 titled, pipeline `crm-hit` buttons titled, leads 6/6 name+email titled); the post-landing grep (the D-UX-045 twin-sweep obligation) confirmed the remainder is exactly the exempt class.

## D-UX-052 — Phase 37 / P37: the tel-token nowrap law (a phone number is atomic)

**Date:** 2026-10-15 · **Surfaces:** leads table rows + mobile cards · dashboard recent-leads table · apartment-demand panel · visit fiche dialog · lead-detail drawer · **Commission:** P37's VLM leads audit («multi-line telephone numbers cause inconsistent row heights») — live DOM proof: the tel anchor rendered 41px wide × 54px tall (3 wrapped lines) inside the auto-layout-squeezed 99px column.

The phone cell carried no wrap protection since P8-6 (b7a62a8): the tel anchor is a shrinkable flex item whose display string contains spaces, so the squeezed column wrapped «0771 12 35 23» onto 3 lines — the true cause of the 55px rows that P35's rejection record had misattributed to the two-line name cells. Fix: `whitespace-nowrap` on every text-bearing `tel:` anchor (6 surfaces; the drawer's icon-only call button is exempt — no text); the column then takes its natural min-content width and the table's documented overflow-x scroll handles narrow viewports. Law: **a phone number is an atomic token — it never wraps, in any surface, any mode, any width.** Live-verified: 50 anchors single-line (h=18, full width) · VLM PASS «PHONES: yes — BROKEN: 0 — ROWS: yes».

## D-UX-051 addendum — Phase 37 / P37: the completion sweep (the twin-sweep obligation applied to the law itself)

**Date:** 2026-10-15 · **Surfaces:** dashboard period caption (dashboard-view.tsx + right-panels.tsx MovementPanel) · inventory project cards (properties-view.tsx ×2 runs + apartment projectName)

The D-UX-045 twin-sweep law (when a visual law lands, the grep for the outlawed pattern is part of the landing) was applied to D-UX-051 itself — a live DOM sweep for untitled content-bearing truncating runs across all 9 views. Found and fixed: the dashboard's period caption (BOTH renderings — the header `p` and the MovementPanel's `rangeCaption` span — truncated «du 14 sept. 2026 au 14 oct. 20…» without title at 1440) and the inventory rail (project name + developer · district + apartment projectName). Post-fix sweep: **0 untitled content-bearing runs across all 9 views** (the P36 sweep's six surfaces had missed the dashboard caption + inventory rail — the class extends, the law unchanged).

## D-UX-053 — Phase 38 / P38: the control-state disclosure completion (the truncation-disclosure law extended to its own control-state class)

**Date:** 2026-10-15 · **Surfaces:** settings team-table role Select (×5 live triggers) · pipeline owner-filter SelectTrigger · tasks owner-filter SelectTrigger · pipeline kanban nextAction `line-clamp-2` · **Commission:** P38's mechanical twin-sweep (the D-UX-045 obligation) — the VLM's 22 claims ALL rejected on live DOM evidence; the sweep found what the VLM could not.

The twin-sweep (untitled truncating runs across all 9 views) found the law's third miss-class: **control-state truncation** — a Select's rendered value truncating inside its trigger with no at-rest disclosure. Seven live instances: the team-table role triggers («Représentant commercial» = 154px in a ~120px value span — 5 rows), the pipeline + tasks owner filters («Tous — Responsable» overflowing sm:w-44 by 6px). The dropdown discloses on interaction, but the at-rest display (the law's language since D-UX-049) truncated silently. Plus one latent mechanism: the kanban `line-clamp-2` nextAction span — zero clamps on seed data, but a line-clamp IS a truncation mechanism and the law covers its own mechanisms (the D-UX-045 precedent). Fix: `title` on all four surfaces — the team-table role gets the full label (self rows append the self-hint: «role — Vous ne pouvez pas…»), the owner filters get the current selection («Tous — Responsable» or the owner name), the nextAction span gets the composed action · date string. Key-neutral, data-neutral, visual-neutral (tooltips only). Post-fix live sweep: **0 untitled content-bearing truncating runs across all 9 views — now including control state.** Law: **any truncation discloses — record content, caption, or control state; the at-rest display never silently cuts what the user cannot otherwise recover.**

## D-UX-055 — Phase 42 / P42: the official identity kit (the typographic wordmark law — the mark carries uniqueness)

**Date:** 2026-10-18 (P42 landing + same-day completion round) · **Surfaces:** sidebar NavLogo · login BrandPanel + mobile login header · browser chrome (favicon · apple-touch · manifest · themeColor light/dark) · print/monochrome contexts (the mark is currentColor-driven) · **Commission:** the user's directive «Start working now on the official and professional model path by developing icons, fonts, and Lovo agency» — the identity audit found NO favicon/app icons at all, letter-A placeholder tiles as the only "logo", the legacy `public/logo.svg` unused, and the login atmosphere still v1 emerald.

*(Numbering note: D-UX-054 is intentionally unissued — P41's palette v2 «Prune & Sable» is a color-token revision recorded as ADR-007 rev2 in DESIGN_SYSTEM §2, not a UX-interaction decision.)*

**The decision set (the whole kit, one law-family):**

1. **The mark — geometric foundation monogram.** A stroke-built «A» standing on a plinth line: أساس ("foundation") made literal. 32-grid, 2.4 stroke, round caps — legible from favicon 16px to print. `currentColor`-driven so ONE component (`src/components/brand/asas-mark.tsx`: `AsasMark` bare · `AsasMarkTile` tile · `AsasWordmark` · `AsasLockup`) serves every context: light tile, dark sidebar, monochrome print. The plinth is wider than the feet span — the foundation read survives any scale.
2. **THE WORDMARK LAW (the core ruling):** the wordmark is TYPOGRAPHIC — Geist 600, `tracking-tight`, riding the mark. **No display font is ever downloaded for identity purposes: the mark carries uniqueness, the wordmark stays type-system-pure.** Rejected alternative: a display typeface for «ASAS» (download weight on every first paint, offline fragility — the sandbox/login paths that must work with no network — licensing surface, and a second voice competing with the semantic scale for exactly zero informational gain). The font system was already professional and binding before P42 (Geist Sans fr/en + self-hosted Noto Sans Arabic with 1.7 leading + `tabular-nums` on ALL data values + the D-UX-004 semantic scale); the identity kit completes it instead of replacing it.
3. **Browser-chrome assets.** `src/app/icon.svg` (auto-linked favicon) · `src/app/apple-icon.tsx` (ImageResponse PNG 180, satori SVG geometry — no font payload) · `src/app/manifest.ts` (name/theme `#6b4485`/bg `#FBFAF8`/icons) · `viewport.themeColor` (light `#6b4485` / dark `#936fad`). The browser tab, the OS taskbar, and the install surface now speak v2 aubergine.
4. **Maskable variant (completion round).** Full-bleed aubergine tile — NO rounded corners, NO transparency (the OS masks circle/squircle itself) — monogram scaled to 80% and optically centered: half-diagonal ≈ 11.3 < 12.8 = 0.4×32 (the 80% safe zone). `public/brand/asas-maskable-icon.svg` + manifest `purpose:"maskable"`. Law: **a maskable icon never carries content outside the safe zone; the tile is the mask's business, the mark is ours.**
5. **512 raster route (completion round).** `/icon-512` (plain route handler, ImageResponse 512×512, geometry mirrors apple-icon) — Chrome's install criterion wants a ≥192px PNG and Firefox/Safari do not rasterize manifest SVGs. The manifest icon set is now: SVG any + PNG 512 any + SVG maskable + PNG 180 any.

**Wiring:** sidebar NavLogo → `AsasMarkTile` + `AsasWordmark` (v2.0 chip) · login BrandPanel → tile 44 + wordmark, mobile login header → tile 36 · login atmosphere emerald → aubergine `rgba(167,127,197,.22)` · footer version v2.0 · `public/logo.svg` replaced with the official tile · `public/brand/asas-brand-sheet.svg` = the single reference asset (mark variants incl. maskable + safe-zone dashes, lockup geometry, color chips).

**Validation (P42 + completion):** lint 0 · tsc src 0 · matrix **192/192** · icon routes 200 (`icon.svg` svg · `apple-icon` png · `manifest.webmanifest` json · `/icon-512` png · maskable svg 200) · live-DOM injection verified (theme-color ×2 + manifest + icon + apple-touch-icon) · VLM QA login + sidebar **PASS** («reads clearly as an A on a plinth», sharp, aligned, consistent) · the MARK SVG rendered in the live DOM. Offline-safety by construction: no font download, no network dependency at any identity surface.

## D-UX-055 addendum — Phase 44 / P44: the completion sweep (the twin-sweep obligation applied to the kit's own retirement claim)

**Date:** 2026-10-18 · **Surfaces:** the BootSplash (crm-app.tsx) — the session-bootstrap splash · **Commission:** P44's mechanical grep sweep (the D-UX-045 obligation): P42 claimed «every letter-A placeholder retired» but never grepped for the pattern.

The twin-sweep found the claim's one miss: the **BootSplash** still rendered the letter-«A» text tile (the R7 auth-gate splash, visible while the session query bootstraps). Fixed: `<AsasMarkTile size={40} className="rounded-xl" />` — the official foundation monogram, the same component the login and sidebar carry; the stale "flat emerald mark" comment retired with it (the tile had been `bg-primary` since P41 — the comment, not the code, was the v1 leftover). Law (the D-UX-045 twin-sweep, applied to identity): **a retirement claim is gated by its grep — `font-bold text-primary-foreground` tiles, letter-text brand marks, and every sibling of a replaced placeholder get swept when the replacement lands.** Post-fix grep: zero letter-A tiles remain in the tree.

P44's §53 record (4 VLM audits → 19 claims → **0 ACCEPTED / 19 REJECTED**, each with live DOM measurement): the emerald "brand-accent bullets" (zero green-axis elements beyond the legal set: 1.8M DA positive finance · Contacté status badge · teal movement chip — lab()-parsed computed colors, the rgb() regex misses Chrome's modern notation); the "AGENT column cut" (the documented table-scroll law); the analytics "missing right-axis labels" (all 10 ticks render, visible=true — the VLM confused chart orientation); "bottom cards misaligned" (identical top=266 headerTop=291, pixel-equal); the mobile "Confirmé green violation" (a visit STATUS badge — the textbook legal semantic); the "touch targets < 40px" (the .crm-hit law: ::before inset −14px → 16×16 glyph = 44×44 hit, 36×36 = 64×64 — measured live); the "name truncation" (FOUT transient: sw>cw only during font load; 0 clipping at 390/900/1024/1100/1280/1366/1440).

## D-UX-056 — Phase 45 / P45: the keyboard focus contract (focus never falls to body; every modal restores; the shell carries a skip link)

**Date:** 2026-10-18 · **Surfaces:** `ui/dialog.tsx` · `ui/sheet.tsx` · `ui/alert-dialog.tsx` · `crm/search-command.tsx` (the palette) · `crm/shell.tsx` (skip link + main landmark) · i18n `shell.skipToContent` ×3 · **Commission:** the user's standing directive («Go to next Phase a right track» → «Continue») landed on the first dedicated **keyboard-navigation audit** — the mandatory a11y dimension never systematically swept (P36–P44 audited visual/touch identity; the keyboard lane had only incidental coverage).

**The audit (live, agent-browser):** tab-order trace on the shell (9 sidebar nav → 3 language toggles → 4 topbar controls → content — **19 Tab presses before the first content control, no skip link**) · cmdk palette focus trap + restore · lead-drawer (Sheet) open/close via the REAL keyboard path (row `tabIndex=0` + Enter) · the nested merge AlertDialog cycle (Escape path AND action path) · dropdown native restore · kanban cards (dnd-kit `KeyboardSensor` + `sortableKeyboardCoordinates` + explicit open buttons — already compliant) · login landmarks (NAV/HEADER/MAIN present). **Four verified defects, each with a live focus/blur instrumentation receipt:**

1. **The Sheet primitive had NO focus restore at all** — the B2 mechanism (dialog.tsx's controlled-open capture/restore) was never ported: the lead drawer (the platform's main workspace) exiled keyboard users to `<body>` on every close.
2. **The AlertDialog primitive had NO focus restore — the worst case:** alerts open from buttons INSIDE other open dialogs (merge confirm, bulk confirms, document deletes); on close, focus dropped to `<body>` OUTSIDE the still-open parent — **a live focus-trap breach** (screen readers fall silent; the visual focus indicator is lost; Tab walks the aria-hidden background).
3. **The palette's `autoFocus` raced the B2 capture:** React handles the `autoFocus` attribute imperatively at commitMount (mutation phase) — BEFORE the DialogContent ref callback captures the focus owner — so the capture saw the palette's own input (inside the node) and the restore was silently skipped. The create-lead dialog (no autoFocus; Radix's default onOpenAutoFocus focuses in an effect AFTER the capture) restored correctly — the differential that pinned the root cause.
4. **The action path's disconnected-opener class:** when an alert's confirm triggers a content reset (merge → back-to-list), the captured opener unmounts mid-flight; restore-to-disconnected must not fall to `<body>` while a parent layer is still open.

**The landing (one law-family, three primitives + one shell affordance):**

- **The B2 law ported to Sheet and AlertDialog** (capture at content-attach via ref callback — runs before any effect can blur the opener; restore on close with `isConnected` guard; caller `onCloseAutoFocus` composes via destructured first-call).
- **The disconnected-opener fallback (all three primitives):** if the captured owner unmounted, focus the **topmost other open layer's first focusable** (`[data-state=open][data-slot=sheet-content|dialog-content]`, self-excluded) — never `<body>` while a parent modal holds the trap. Live-verified on the merge action path: focus lands on the parent dialog's «Fermer» with `trapHolds: true`.
- **The palette fix:** `autoFocus` REMOVED from `CommandInput` — Radix's default `onOpenAutoFocus` still focuses the input (first focusable) but in an effect AFTER the capture; identical open behavior, restore now works (live: focus→blur→focus on the trigger, input still focused on open).
- **The skip link (D-UX-056's shell affordance):** first tabbable element of the shell — `sr-only` until focused, then a quiet fixed chip (`start-3` logical — right-anchored in RTL, verified). `onClick` does `preventDefault` + programmatic focus on `main#main-content` (`tabIndex=-1`) — **never `location.hash`**: the app's hash router (`parseHash`) would read `#main-content` as an unknown view and pull the user back to dashboard (live-caught on the first implementation — the href stays for screen-reader semantics, the route side effect does not ship).

**THE LAW: focus is a contract — every modal surface restores its opener on close (or the topmost open layer when the opener is gone), and the shell's first tab stop is the content itself. A keyboard user is never stranded on `<body>` behind an open trap, and never pays the nav tax to reach content.**

**Validation:** live DOM receipts for every path (skip link FR/AR/dark/mobile-390 — first Tab = the link, Enter = `MAIN#main-content`, hash + view unchanged; palette trigger focus→blur→focus; lead row Enter → drawer → Escape → `TR` row restored; mobile nav Sheet → «Menu» button restored; merge alert Escape → «Fusionner» inside the open parent; merge alert ACTION → parent's «Fermer», `trapHolds: true`) · matrix **192/192 ×3 AFTER** · lint 0 · tsc full-repo 4 tolerated (examples/skills, src 0) · 9-view FR sweep console 0 · mobile 390 `scrollWidth` exactly 390 (the D-035 clip law holds — the fixed-position skip chip escapes it by construction) · residue baseline byte-exact **8/43/21/23/161/46/3/8/4/18** · evidence `download/qa-p45/` (5 captures: skip link light-FR / dark-AR / mobile-390 / mobile-light / kanban card keyboard focus ring).

## D-UX-057 — Phase 46 / P46 (W1): the decision-backlog surface law (a complete machine is not a complete workflow)

**Date:** 2026-10-18 · **Surfaces:** `api/dashboard` (pendingIncentives block + kpis.pendingIncentiveDecisions) · `api/notifications` (INCENTIVES_PENDING group) · `views/dashboard/attention-strip.tsx` (4th cell) · `views/dashboard/pending-incentives-panel.tsx` (the queue, NEW) · `dashboard-view.tsx` (rail wiring) · i18n dash.pending.* + dash.kpi.pendingDecisions(.hint) + notif.INCENTIVES_PENDING(.desc) ×3 · **Commission:** the OWNER-UI audit's finding F1 (P46-R) — the §38 approval machine (P29/D-037) was complete and live-verified, but its decision backlog was INVISIBLE: 3 PENDING incentives (436 500 DA) awaited MANAGER+ decisions with no attention cell, no bell group, no queue — discoverable only by opening every opportunity dialog by hand.

**THE LAW (the audit's own conclusion, now a design law): a complete machine is not a complete workflow.** Every decision-awaiting state needs a surface that AGGREGATES it — the machinery this codebase builds is never the gap; the waypoint layer above it is (the same pattern as P34's never-wired surfaces, one abstraction level up). The §38 queue follows the unstaffedVisits architecture (P20-C): a MANAGER+ KPI computed server-side (null below MANAGER — the role gate rides the data contract), surfaced through the existing three-tier signal system:

1. **The attention cell (4th, amber attn-2):** `kpis.pendingIncentiveDecisions` — the strip's grid graduates to 4 columns at lg (the 3-cell banner span retired); a decision backlog is attention, never good-news emerald (the D-UX-015 money-tone law extended to PENDING money — a commitment awaiting a human decision).
2. **The queue (management right rail, FIRST — work before summaries):** rows carry amount (num-xl total + per-row tabular, amber-tiered) · deal title · agent · project · unit code, each with the truncation-disclosure `title` (D-UX-051); **the open-deal affordance carries the FULL deal DTO in the dashboard payload** — the row click opens the existing OpportunityDetailDialog → DealEconomicsSection directly: zero new API surface, zero new mutation surface (a read/waypoint layer only; decisions still land through the audited PATCH, whose save.onSuccess invalidates ["dashboard"] so the queue self-refreshes while the dialog stays open on its live copy).
3. **The bell group (MANAGER+ only):** warning severity, `view: "dashboard"` — items keep leadId so an item click opens the prospect drawer.

**The same-page waypoint:** the attention cell's deep-link contract gains `"dashboard"` — the click `scrollIntoView`s the queue (`#pending-incentives-queue`, scroll-mt-24) instead of navigating away from the cockpit the user is reading (live: top=146px after scroll). The cell is the target's persistent zero-signal (muted 0 = all-clear at the strip level).

**The queue empty law:** a WORKING surface renders only when work exists (`count > 0 → null`). A permanent "nothing to decide" card is noise on every manager dashboard — the strip already owns the persistent signal (§7 zone-predictability applies to the STRIP, not to every working panel; the same split as HotOpportunities vs the attention cells).

**Validation:** matrix **195/195 ×3 AFTER** (FR31a KPI=3 + payload w/ deal DTOs + total 436 500 · FR31b null below MANAGER · FR31c bell group MANAGER+ only) · live OWNER walk: 4th cell rendered → queue 3 rows (H-31 290 000 · B-01 59 000 · A-01 87 500 w/ agent names via the in-memory agentId join) → row click → dialog + §38 machine (Approuvée/Rejetée edges offered; closed WITHOUT deciding — the seed's PENDING trio preserved) → attention cell click → queue scrolled into view → bell group w/ 3 items → agent scope: all three surfaces absent (My Day + Mes incentives only) · AR RTL (قرارات بانتظارك, dir=rtl) · dark · mobile 390 `scrollWidth` exactly 390 · console 0 everywhere · residue baseline byte-exact 8/43/21/23/161/46/3/8/4/18 · evidence `download/qa-p46/` ×5 captures.

## D-UX-058 — Phase 47 / P47 (W2): the R5 legacy-holds decision surface (present the decision, never make it)

**Date:** 2026-10-18 · **Surfaces:** `api/properties/apartments` (the orphanHolds derived filter) · `api/properties/apartments/[id]` (the W2 RBAC hardening) · `crm/properties/orphan-holds-card.tsx` (the card, NEW) · `views/properties-view.tsx` (top wiring) · `crm/properties/apartment-detail-dialog.tsx` (the legacy marker) · i18n properties.orphans.* + resv.legacy.* ×3 · **Commission:** the continuation plan's W2 — the audit's F2 finding: the R5 legacy holds (7 units held with ZERO reservation rows) had both capabilities live (release via the status editor, backfill via P24 reverse-matching) but NO aggregate surface, and the per-dialog «Aucune réservation active» line read as a data inconsistency, not a pending decision.

**THE REGISTER LAW (RISK_REGISTER R5, re-affirmed): the surface PRESENTS the decision, it never makes it.** Release-vs-backfill stays the product owner's call; the 7 seeded holds remain untouched unless the owner acts (live-verified: the release confirm was exercised on its CANCEL path; the golden release path runs on a scratch orphan in the matrix, never on the seed).

**The landing:**

1. **The derived filter** (`?orphanHolds=1`): held status (RESERVED/OPTIONED) ∧ no ACTIVE reservation — derived ONLY, no schema change; a unit whose hold outlived an EXPIRED/CANCELLED reservation is the same decision-awaiting class. The filter is a convenience on shared inventory state, NOT an authorization boundary (any role sees statuses in the grid; the card's MANAGER+ render follows the ACTING capability).
2. **The card** (Inventory view, top): quiet amber attn-2 (the same decision-awaiting semantics as the P46 queue), renders only when holds exist (the D-UX-057 empty law); rows = unit code · project · price (compact tabular) · the inventory's own ApartmentStatusBadge (one visual language for the same state) + two affordances: «Libérer» (AlertDialog confirm → the EXISTING audited PATCH → AVAILABLE; RESERVED→AVAILABLE needs no force — only SOLD does — and the P4 coherence guard passes by construction: nothing active to desync) and «Ouvrir» (the apartment dialog — the P24 demand panel IS the backfill path). R5's law rides the confirm copy: the action is explicit, consequence-named, audited.
3. **The legacy marker** (per-dialog, MANAGER+): the bare «Aucune réservation active» line on a held-no-active unit is REPLACED by «Hold hérité — décision propriétaire : libérer ou requalifier» + the two-path hint — the state now reads as a DECISION, not a bug. Non-managers keep the plain line (they cannot act).
4. **The W2 RBAC hardening (live-caught while wiring the release affordance):** PATCH /api/properties/apartments/:id was gated ONLY by the UI's canEdit — bare `requireUser()` server-side; an agent could PATCH status/price directly («UI hiding is never authorization», mandate §24). Fixed: `requireUser("MANAGER")` + FR32c (agent → 403 FORBIDDEN_ROLE, live-proven).

**Validation:** matrix **200/200 ×3 AFTER** (FR32a the exact 7 units A-21/A-31/B-11/H-12/H-21/N-11/V-03 · FR32b H-31 EXCLUDED — the ACTIVE-backed hold, the predicate's negative case · FR32c agent PATCH 403 · FR32d the release golden path on a scratch orphan: surfaced at 8 → PATCH 200 → AVAILABLE → APARTMENT_STATUS_CHANGED audit → back to 7 → exact-restore residue · FR32d-b the 7 legacy holds untouched) · live OWNER walk (card 7 rows w/ prices + status badges → Ouvrir → legacy marker + «3 prospect(s) correspondant(s)» → Libérer → AlertDialog «Libérer le lot A-21 ?» captured → CANCEL, the seed preserved) · agent scope (Amine): NO card, the plain resv.none line, no marker · AR RTL (حجوزات موروثة — قرار المالك) · dark · mobile 390 scrollWidth exactly 390 · console 0 (fresh browser session — the one mid-round console entry was a browser-side HMR replay phantom from the edit window: disk file valid by Bun transpiler + tsc + eslint + the server log showing zero parse errors + the UI rendering; killed by a fresh session) · residue baseline byte-exact 8/43/21/23/161/46/3/8/4/18 · evidence `download/qa-p47/` ×6.

## D-UX-059 — Phase 48 / P48 (W3): the compact-panel law + the money-row affordance (the CommissionsPanel completion)

**Date:** 2026-10-18 · **Surfaces:** `api/dashboard` (the commissions block: range-windowed + full deal DTOs) · `views/dashboard/economics-panels.tsx` (the panel) · i18n commissions.title/empty/openDeal ×3 · **Commission:** the continuation plan's W3 — the audit's F3 finding: the panel was month-locked (the API used monthStart/monthEnd regardless of the dashboard range selector that drives KPIs/funnel/sourcePerformance) and its entries carried no open-deal affordance.

**The landing:**

1. **The range follows the selector (W3a):** the commissions query windows on the SAME rangeStart as the KPIs (all = all-time); the payload echoes the range key and the panel's chip renders it with the selector's own label vocabulary (`dash.range.*`) — the chip is the API's truth, never a client guess. The title drops the «du mois» qualifier («Commissions» — the chip carries the period); the empty copy generalizes to «sur la période». (The INCENTIVES panel stays month-locked BY its own semantic — «Ce mois / Cumul» is the rep's ledger vocabulary, not a selector artifact.)
2. **The money-row affordance (W3b):** every entry carries the FULL deal DTO (the same contract as the P46 queue) and the row is a button that opens the existing OpportunityDetailDialog → DealEconomicsSection — the §37/§38 surfaces are one click from the money row. Zero new API surface, zero new mutation surface.
3. **THE COMPACT-PANEL LAW (W3c, decided):** `take: 6` stays — the rail panel is CONTEXT, not a ledger. The full per-deal economics live in the opportunity dialogs, now one click away per row; a see-all list view would be a ledger surface (analytics/ERP territory), not a cockpit rail. The law generalizes: **a rail panel summarizes and routes; it never becomes the system of record.**

**Validation:** matrix **203/203 ×3 AFTER** (FR33a ?range=all → echo "all" + 6 entries w/ full DTOs + total 2 224 000 · FR33a-b ?range=7d → echo "7d" + 2 entries — the window genuinely follows · FR33b entries ≤ 6 both windows — the compact law) · live OWNER walk (default 30d → chip «30 jours»; switch to 7 jours → chip follows + 2 rows; row click → the Mustapha dialog + «Économie du deal»; switch to Tout → chip «Tout») · console 0 · lint 0 · tsc src 0 · residue baseline byte-exact 8/43/21/23/161/46/3/8/4/18 · evidence `download/qa-p48/` ×3.

## D-UX-060 — Phase 49 / P49: the agent-side decision-backlog surface («Reconfirmations en attente» — the D-UX-057 law applied where the decision lives)

**Date:** 2026-10-18 · **Surfaces:** `api/dashboard` (`kpis.visitsAwaitingReconfirm` — the attention strip's first AGENT-side cell) · `api/notifications` (the VISITS_RECONFIRM group) · `api/visits` (the derived `?awaitingReconfirm=1` filter) · `views/dashboard/attention-strip.tsx` (5th cell, dynamic 4-vs-5 grid) · `views/visits-view.tsx` (the filter chip) · i18n dash.kpi.reconfirmations(.hint) + notif.VISITS_RECONFIRM(.desc) + visits.filter.reconfirm(.hint) ×3 · **Commission:** the post-plan polish/QA round's audit lens — the P46-R method (find decision-awaiting states with no aggregating surface) extended to the NON-owner personas found the exact F1 pattern agent-side: the P20-A counter-proposal machine is complete (flag + «Client reconfirmé» action, matrix FR13–16 since P20), but the WAITING state lived only as amber row hints — the today/tomorrow bell groups cannot carry it (a counter moves the slot DAYS out), and the agent had to scan the visits list for chips. The seeded Samira visit sat 4 days out, invisible to its agent (Lina) on every aggregated surface.

**The landing:**

1. **The scope IS the authority (the data contract carries D-026 verbatim):** SALES_AGENT → their OWN backlog (`agentId = user.id` — deliberately NOT the visitScope pool clause: an agent cannot reconfirm a pool visit, so a pool count would surface work they cannot do); MANAGER+ → org-wide count (rank holds the backup authority, and a stalled-customer-loop is org attention); FIELD_REP → null (they countered — the customer loop is the agent's decision; row hints stay informational, the aggregate would be noise for a decision they cannot make). Null hides the cell: never a silent zero, never a client role check.
2. **The waypoint triplet (one per tier):** the attention cell (amber attn-2, PhoneCall — the act is a call; deep-links to the visits view = the act surface) · the bell group (warning tier, items carry leadId for the prospect drawer; the group label carries lead + project so the item names the CONTEXT) · the derived filter chip («À reconfirm» — a toggle, not a Select option: a derived state is not a status value; the status enum stays honest and the predicate composes with it). Together they close the loop: aggregate → isolate → act, with the existing reconfirm PATCH as the only mutation surface.
3. **THE AGENT-SIDE LAW (D-UX-057's extension, now stated in full):** a decision-awaiting state needs an aggregating surface AT EVERY AUTHORITY LEVEL THAT OWNS THE DECISION — the owner's backlog (F1: incentives → MANAGER+), the steward's backlog (F2: legacy holds → OWNER), and the worker's backlog (this round: reconfirmations → the follow-up agent). The aggregation scope must equal the decision authority exactly — never wider (noise for actors who cannot decide), never narrower (a hidden queue is an undone queue).
4. **The grid graduates again:** the dynamic strip grid (2→3→4 columns by live cell count) gains the 5-column case (`lg:grid-cols-5` when all five cells are live — the manager's full cockpit: uncontacted · overdue · unstaffed · incentives · reconfirmations; computed-verified 5 × 188.8px, no orphan wrap).

**Validation:** matrix **213/213 ×3 consecutive AFTER** (203→213: FR34a the agent's own KPI=1 — the seeded counter · FR34b manager org-wide=1 · FR34c field-rep null · FR34d agent-A zero-not-null · FR34e/e-b the bell group present-with-item / absent-for-the-rep · FR34f/f-b the derived filter isolates exactly the seeded row / 0 rows for the other agent · **FR34g the golden path on a scratch visit — the aggregate tracks the machine end-to-end: POST → counter (KPI 1→2) → reconfirm (KPI 2→1) → severance-first exact-restore** · FR34g-b residue: visits 23→23, the seeded counter untouched) · live walk (Lina: cell «1 À reconfirm» → click → visits view → chip → exactly «1 visit(s)» with the «Client reconfirmé» act surface; the golden confirm itself was matrix-proven on the scratch — the seed preserved · bell «1 reconfirmation(s) client en attente — Samira Khelifi · Hydra Heights» · Mounia: NO cell, the informational row hint only · Sarah: the full 5-cell strip) · AR RTL (بانتظار إعادة التأكيد, dir=rtl, cell + chip) · dark · mobile 390 (1-col stack, scrollWidth exactly 390) · console 0 at every step · lint 0 · tsc src 0 · residue baseline byte-exact 8/43/21/23/161/46/3/8/4/18 (audit append-only telemetry) · evidence `download/qa-p49/` ×5.

## D-UX-061 — Phase 50 / P50: the FIELD_REP's decision-backlog surface («Décisions terrain en attente» — the D-UX-057 law's last persona class)

**Date:** 2026-10-18 · **Surfaces:** `api/dashboard` (`kpis.visitsAwaitingFieldDecision` — the attention strip's 6th cell, the first FIELD_REP-side one) · `api/notifications` (the VISITS_FIELD_DECISION group) · `api/visits` (the derived `?fieldDecision=1` filter) · `views/dashboard/attention-strip.tsx` (6th cell, the 6-cell grid tier) · `views/visits-view.tsx` (the second filter chip) · i18n dash.kpi.fieldDecisions(.hint) + notif.VISITS_FIELD_DECISION(.desc) + visits.filter.fieldDecision(.hint) ×3 · **Commission:** the post-plan polish/QA track's named next candidate — the FIELD_REP-perspective workflow audit, the P46-R method's last un-audited persona class. Walking Mounia's world found the F1 pattern at the FIELD tier: the P18/P20 field-decision machine is complete (CONFIRM/REJECT/COUNTER, the canConfirmVisit authority, matrix FR1–16), but the WAITING state had no aggregating surface — the bell's today/tomorrow groups cannot carry a proposal DAYS out (the P49 structural limitation) and do not distinguish a pending proposal from an agreed slot even when they carry it; «todayVisits/upcomingVisits» blur SCHEDULED with CONFIRMED. The seeded Sofiane proposal sat 3 days out, invisible to Mounia on every aggregated surface; Riadh's Rachid proposal 2 days out likewise.

**The landing:**

1. **The scope IS the authority (D-UX-060 applied at the field tier):** FIELD_REP → their OWN backlog (visits on projects assigned to THEM — the live assignment predicate, `canConfirmVisit`'s exact basis, never a stale role check); MANAGER+ → org-wide but ONLY on projects WITH an eligible rep — the unstaffed exception (§17.3) keeps its own cell, so the two counts never overlap; SALES_AGENT → null (no authority — the field decision is not theirs; their loop is the P49 reconfirmation surface). Null hides the cell: never a silent zero, never a client role check.
2. **THE 3-WAY PARTITION of the pending-visit space (this round's law):** unstaffed (no eligible rep — the §17.3 exception cell) · awaiting FIELD decision (FIELD_PENDING ∧ ¬countered — this round) · awaiting the CUSTOMER (countered — the P49 cell). The three predicates are disjoint by construction: a countered visit's ball is with the customer (surfacing it to the rep as "their" backlog would be noise for a decision they already made), and once the customer agrees the visit REJOINS the field backlog automatically (the flag clears, status stays SCHEDULED).
3. **The waypoint triplet (the P49 pattern, verbatim):** the attention cell (amber attn-2, MapPin — the terrain identity; deep-links to the visits view) · the bell group (warning tier, items carry leadId for the prospect drawer, the label carries lead · project, the timestamp names the slot distance — «DANS 3 JOURS», exactly what today/tomorrow groups cannot say) · the derived filter chip («À décider», a toggle not a Select option; the predicate composes with BOTH the P49 chip and the status filter). Aggregate → isolate → act, with the existing CONFIRM/REJECT/COUNTER PATCHes as the only mutation surfaces — zero new write paths.
4. **The grid's 6-cell tier:** `lg:grid-cols-3 2xl:grid-cols-6` (MANAGER+ with all six cells live): 3×2 from lg at ≈323px/cell (computed-verified — every label fits without triggering the D-UX-051 truncation disclosure), graduating to 6-across at 2xl (≥1536px ≈ 200px — the P49 188.8px band). Six-across at plain xl was computed and REJECTED: 155px/cell would gut the labels — the tier is chosen by measurement, not by symmetry with the 5-column rung.

**Validation:** matrix **225/225 ×3 consecutive AFTER** (213→225: FR35a the rep's own KPI=1 — the seeded Sofiane proposal, the countered Samira EXCLUDED by the ¬countered term · FR35a-b rep-B KPI=2 (Rym + Rachid) · FR35b manager org-wide-on-staffed=3 (the §17.3 partition) · FR35c agent null · FR35e/e-b/e-c the bell group present-with-item (label «Sofiane Menad · Hydra Heights») / absent-for-the-agent / org-3-for-the-manager · FR35f/f-b/f-c the derived filter isolates exactly the seeded row with viewerCanConfirm / both of rep-B's / the agent's scope lens with countered excluded · **FR35g the golden path on a scratch visit — the aggregate tracks the machine end-to-end: lina POSTs on her own lead + mounia's project → KPI 1→2 → mounia CONFIRMS on site (her authority) → KPI 2→1 → severance-first exact-restore** · FR35g-b residue: visits 23→23, both seeded proposals untouched) · live walk (Mounia: cell «1 Décisions terrain» → bell «1 proposition(s) de visite à décider — Sofiane Menad · Hydra Heights — DANS 3 JOURS» → chip «À décider» → exactly «1 visite(s)» with the CONFIRM/REJECT/COUNTER act surfaces — the seed preserved, the golden confirm matrix-proven on the scratch · Riadh: cell «2» · Sarah: the full 6-cell strip at 3×2/323px · Lina: NO cell — the null gate, her P49 cell intact) · AR RTL (قرارات ميدانية cell + بانتظار القرار chip, dir=rtl, the chip isolates «1 زيارة» in Arabic) · dark (cell renders on the dark token, computed-verified) · mobile 390 (3-cell 1-col stack, scrollWidth exactly 390) · console 0 (fresh session — one mid-round HMR replay phantom diagnosed and dispatched per the P49 tooling lesson) · lint 0 · tsc src 0 · residue baseline byte-exact 8/43/21/23/161/46/3/8/4/18 (audit append-only telemetry).

## D-UX-062 — Phase 51 / P51: the Tailwind v4 outline-var poisoning law (focus-visible styling must survive the base `outline-none`; tabpanels are focus targets, not decorations)

**Date:** 2026-10-18 · **Surfaces:** `views/pipeline-view.tsx` (KanbanCard wrapper) · `ui/tabs.tsx` (TabsContent primitive — 10 instances across My Day, the dashboard right rail, the lead drawer) · **Commission:** the polish/QA track's named next candidate — the keyboard-a11y second wave, extending P45's focus contract (D-UX-056) into the dimensions the first wave never systematically swept: focus VISIBILITY on every custom hit-target class, not just focus RESTORE on the modal primitives.

**The audit (live, agent-browser, the P46-R method applied to the keyboard lane):** full Tab walks with computed-style instrumentation (outline style/width/color/offset + full box-shadow + `:focus-visible` match + `--tw-outline-style` resolution) across dashboard, prospects, pipeline, visits (list + calendar), login, dark, AR RTL, mobile 390. The negative results are the audit's own quality: sidebar nav, topbar, attention cells (all six), the P49/P50 decision chips («À reconfirm»/«À décider» — 3px rings), the §20 field-decision buttons, TR lead rows (`.crm-tr-hover:focus-visible` — the @property initial-value keeps it honest), the range selector, the visits toggles, the WIP gauge buttons (UA outline), the login persona buttons (UA outline), the skip link — ALL verified visible. The tooling lessons en route: (1) a static class sweep without global-CSS knowledge produces false negatives (the TR rings live in globals.css, not class lists); (2) box-shadow truncation hides ring entries (the 4th `--tw-ring-shadow` slot renders AFTER three transparent prefixes); (3) the browser's sequential focus navigation starting point survives `blur()` — only a reload resets the walk (three inconsistent traces before the lesson); (4) Tailwind v4 emits utilities only when used — `outline-solid` was absent from the compiled CSS until the fix referenced it.

**Two verified defects, one root mechanism:**

1. **K1 — every Kanban card's keyboard focus ring was SILENTLY invisible.** The wrapper carried `outline-none focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-ring` — width, color, and offset all computed correctly under focus, but the STYLE resolved to `none`: v4's `.outline-none` sets `--tw-outline-style: none` ON THE ELEMENT, and `.outline-2`'s `outline-style: var(--tw-outline-style)` reads the poisoned value (the `@property` initial-value `solid` only applies when nothing else sets the custom property). The live receipt: `:focus-visible=true, outline=none/2px/lab(ring)/-2px, --tw-outline-style=none`. The dnd-kit KeyboardSensor makes every card a Tab stop (drag is keyboard-operable) — the platform's flagship interactive surface was focus-blind.
2. **K2 — the TabsContent primitive stripped the outline with NO replacement (10 instances).** Radix hardcodes `tabIndex={0}` on every tabpanel (the ARIA reading pattern: Tab enters the panel so AT users can read it), which makes each panel a REAL focus target; the primitive's bare `flex-1 outline-none` meant focus landed blind on the My Day panel, the dashboard right-rail panels, and the lead drawer's tabs (the platform's main workspace). Live receipt on the My Day panel: `role=tabpanel, outline=none, boxShadow=none`.

**THE LAW: a focus indicator that computes but never renders is not a focus indicator.** In Tailwind v4, any element carrying a base `outline-none`/`outline-hidden` MUST pair its `focus-visible:outline-*` utilities with `focus-visible:outline-solid` (the variant rule re-sets `--tw-outline-style: solid` under the pseudo-class — specificity AND rule order both win) — otherwise the ring is a silent no-op. And a tabpanel is a focus target, not a decoration: Radix puts it in the tab sequence on purpose, so the primitive owes it the same contract every button gets.

**The landing (two sites, one law):** (1) the KanbanCard wrapper gains `focus-visible:outline-solid` (unpoisons the var in the focus state) + `rounded-lg` (modern engines draw outlines along border-radius — the ring hugs the card's visual shape instead of a sharp rectangle around it; the wrapper itself draws nothing); (2) the TabsContent primitive gains the full companion set `focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-[-2px] focus-visible:outline-ring` — one line in the primitive, all 10 instances covered, the inset-offset language matching `.crm-tr-hover:focus-visible` (the row/card ring family). The ring shows only while the panel itself holds focus and yields as soon as Tab moves into its content.

**Validation:** live receipts after the fix — the kanban card `outline=solid/2px/lab(52.2…)/-2px` with `--tw-outline-style=solid` (light: lab 50.03 token) · the My Day tabpanel `outline=solid/2px` · the lead drawer's active tabpanel `solid/2px` · dark (the dark token ring) · AR RTL (`dir=rtl`, solid/2px) · the compiled CSS now emits both `.outline-solid` and `.focus-visible\:outline-solid:focus-visible` (verified live in the stylesheet) · **matrix 225/225 ×3 consecutive AFTER (zero regression — a pure CSS/UI-primitive change, no API surface touched)** · lint 0 · tsc src 0 (4 tolerated examples/skills) · console 0 (fresh session, zero errors/warnings) · mobile 390 scrollWidth exactly 390 · residue baseline byte-exact 8/43/21/23/161/46/3/8/4/18 (audit append-only LOGIN telemetry) · evidence `download/qa-p51/` ×9 (the two ring receipts in light + dark, the tabpanel receipt, the post-recovery E2E re-scan set, mobile-390). Environment this round: the R25 full-recovery signature at open (secret gone + DB rebuilt via db push without seed — an interrupted automated recovery), restored by the documented recipe (secret → .env · rm + migrate deploy ×11 · generate · seed → baseline byte-exact · subshell-detach restart); one R14-class server death mid-audit (warm restart, zero residue).

## D-UX-063 — Phase 52 / P52: the heading-outline completion (a panel is a section; a section title is a heading; the outline maps REGIONS, not RECORDS)

**Date:** 2026-10-18 · **Surfaces:** `ui/card.tsx` (the CardTitle primitive — 28 instances healed across the dashboard rails, the analytics charts, the settings sections, team/export) · `views/pipeline-view.tsx` (the 7 kanban column headers) · `views/visits-view.tsx` (the day-group headings, h2→h3 normalized) · `economics-panels.tsx` ×2 + `pending-incentives-panel.tsx` + `properties/field-team-panel.tsx` + `properties/orphan-holds-card.tsx` + `lead-activity-preview.tsx` (the six `text-crm-section` span/p titles) · **Commission:** the polish/QA track's LAST remaining named candidate — per-view polish under v2 identity (the console-0 re-scan and the keyboard-a11y second wave closed at P51).

**The audit (live, agent-browser, DOM-measurement per the §53 gold standard):** a per-view probe walked all 9 views as the OWNER measuring card paddings, grid gaps, radius inventory, sub-10px text (0 everywhere), transition coverage, and heading structure. The polish invariants held (no small text, no off-scale radius, the mixed paddings classify as the shadcn Card pattern; the pipeline "noTransition:42" finding dissolved under inspection — the flagged nodes were dnd-kit's non-visual wrappers, the visual card carries full `transition-[…] duration-150` + the framer hover-lift). **THE headline finding: 7 of 9 views had ZERO headings inside `<main>`** — the heading outline (the most common AT navigation mode: the `H` key in every screen reader) found only the topbar h1 per view. Every panel title in the app rendered as a non-heading: `CardTitle` was a stock `<div>` (28 uses), the six `text-crm-section` titles were `<span>`/`<p>`, the pipeline column labels were `<span>` inside `aria-label`'d sections (region nav worked; heading nav didn't). The only real headings in the entire app were the visits day-groups (h2) and the tasks groups (h3) — an inconsistency (the same construct at two levels) that doubled as the exception proving the gap.

**THE LAW: a view's sections are its AT navigation map — every section title is a heading; the view title is the h1; and item titles inside record grids stay non-headings (the outline maps REGIONS, not RECORDS).** A panel that AT users cannot jump to is a panel they must TAB through content-by-content to discover — the same "complete machine ≠ complete workflow" class as D-UX-057, on the structural-semantics axis: the visual panel existed; the navigable panel didn't. And 46 apartment cards each becoming an h3 would have been the counter-mistake — a heading outline that floods is a heading outline nobody uses; record grids carry their navigation through their own rows (D-UX-062's focus rings) and table semantics (`th`), not through the heading lane.

**The landing (pure semantic markup — same classes, zero visual delta, zero API surface):** (1) **CardTitle: `<div>` → `<h3>`** — one primitive line, 28 panel titles join the outline (the shadcn classic default restored; h3 matches the app's shipped section-group pattern; dialogs keep Radix's DialogTitle h2 — the lead drawer now nests correctly: h2 drawer title → h3 «Activité récente» preview); (2) the pipeline column labels → `<h3>` (7 columns — heading nav now reaches every kanban stage); (3) the six `text-crm-section` span/p titles → `<h3>` (incentives, commissions, pending-decisions, field-team, orphan-holds, activity-preview); (4) the visits day-groups h2 → h3 — normalizing the app's section headings to ONE level: a flat, predictable outline (h1 view title → h3 sections) instead of the shipped h2/h3 mix.

**Validation:** live heading-outline receipts after the fix — dashboard 7 h3 («Journée de l'équipe», «Décisions en attente», «Commissions», «Opportunités chaudes», «Mouvement commercial», «Volume d'activité», «Prospects récents») · pipeline 10 (every stage) · visits 2 (day groups) · tasks 3 (En retard / Aujourd'hui / À venir) · properties 2 (Holds hérités + Équipe terrain w/ selected project) · analytics 6 · settings 6 · the lead drawer nesting (h2 «Réda Mokrani» → h3 «Activité récente») · leads/audit = 0 by design (table views; `th` semantics carry them) · dark (7 h3 on the dark token) · AR RTL (`dir=rtl`, all 7 Arabic panel titles) · mobile 390 (scrollWidth EXACTLY 390, 7 h3) · console 0 (fresh session, HMR noise only) · **matrix 225/225 ×3 consecutive AFTER (zero regression — pure markup semantics, no API surface, no text changes)** · lint 0 · tsc src 0 (4 tolerated examples/skills) · residue baseline byte-exact 8/43/21/23/161/46/3/8/4/18 (audit 127 = append-only LOGIN telemetry across matrix ×3 + persona switches, the documented class) · evidence `download/qa-p52/` ×8 (pre/post dashboard, pipeline, settings, dark, AR, mobile-390, the drawer). The h1→h3 level skip is the accepted trade (documented): presence for AT navigation over strict-level purity, matching the shipped tasks-view pattern — the alternative (h2 panels) would have conflicted with Radix's DialogTitle h2 and broken the drawer nesting.

## D-UX-064 — Phase D / D4: the workflow-layer re-foundation (bounded Path B — the customer workspace as the coherence layer on the retained visual/domain foundations)

**Date:** 2026-10-24 · **Track:** Phase D (the owner's lifecycle-coherence directive — explicitly authorizes the broad-redesign evaluation for the UX track) · **Surfaces:** the whole IA · **Evidence base:** the D1-a/D1-b discovery inventories (file:line-cited, in `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/PHASE_D_LIFECYCLE_COHERENCE.md` §1) over HEAD `b82b8ec`.

**The decision (a required engineering decision, not a preference):** after modeling the seven lifecycles, the entity graph, the event/side-effect map, and the ten service blueprints, the evidence splits three ways — (1) the DOMAIN layer is strong (server-enforced state machines, transactional, audited — the 325-matrix proof); (2) the VISUAL layer is coherent (shared badges/tone maps/primitives — the Phase-C audit verdict stands); (3) the WORKFLOW layer is structurally deficient: the four pending carriers are never composed per-customer (G-1), the reservation is invisible in the customer's own workspace (G-2), the journey state never shows side-by-side (G-3), and reaching the customer destroys the working context — `openLead` is a view switch, the drawer mounts inside one list view (G-4). Path A (pure incremental) is rejected because no local fix composes five carriers or un-walls the drawer — that is an IA property, and patching it per-screen is exactly the "accumulating special cases" trigger. A visual teardown is rejected on the Phase-C audit evidence. **The selected path: re-found the workflow layer** — the customer workspace becomes the per-customer operational hub (an overlay reachable from every surface without context loss), composed from the ONE authoritative D-021-scoped aggregate, extended by exactly one additive server field (the per-lead reservations join — the documented contract gap), with the remaining linkage dead-ends migrating in dependency-ordered batches (PHASE_D doc §7) onto the stable pattern.

**The law: the visual system and the domain machines were never the defect — the missing layer was workflow composition; re-found the composition, retain the proven foundations.** Full evidence, the event/side-effect map, and the rollout roadmap: `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/PHASE_D_LIFECYCLE_COHERENCE.md`.

## D-UX-065 — UX-S: the palette becomes the lifecycle's front door (SAV + collections join ⌘K; deep-links land ANSWER-FIRST)

**Date:** 2026-10-31 · **Surfaces:** `api/search/route.ts` (two scoped result groups) · `search-command.tsx` (two palette row families) · `icon-vocabulary.tsx` (registry: `sav`, `installment`) · `store.ts` (`financeFocus` token) · `finance-view.tsx` (arrival contract) · `search.ts` i18n ×3 · **Commission:** the UX-L close's documented future work item ("SAV palette deep-links have the store hook ready but the palette search itself stays lead/inventory-scoped").

**The gap:** the global palette answered in six voices — leads, opportunities, projects, apartments, developers, contacts — but the two workspaces Phase D added (the SAV cockpit, the collections échéancier) were UNREACHABLE from it. The store's `openSavCase` token existed with NO producer (armed, never fired); searching "Sofiane" found the man but not his broken sink or his late 5.8M DA. Recalling a SAV case meant already knowing it existed and walking #/sav by hand; recalling a client's money meant #/finance + manual re-search — the exact dead-end class the Phase C Wave 1 palette work killed for inventory ("search Hydra, click, land on an unfiltered list, re-find by hand").

**The law: the palette's answer set must span every machine a record lives in — and every answer lands ANSWER-FIRST (the cockpit open, the client's rows isolated), never on an unfiltered waystation.** Two scoping corollaries, both mirroring their view's own gating so a palette row can never offer a destination its nav hides: SAV rows serve EVERY role through `savScope` AND-composition (the SAV view's own law); installment rows serve MANAGER+ only (the finance view IS the gated collections workspace — a below-MANAGER row would deep-link straight into the 403 lock screen). And the row carries the record's URGENCY, not just its name: the SAV row wears the table's own status badge + amber SLA tint; the installment row wears amount + due date with the overdue tint.

**The landing:** (1) server — `savCases` matches every way a case is recalled (the org-wide human reference `SAV-3` via a seq parse of the query · title · reported description · client name, AND-composed with `savScope`, reportedAt-desc) and `installments` matches client · contract ref · unit code · label (AND-composed with `installmentScope`, the finance route's own ordering law verbatim — dueAt asc, what is late first); (2) rows — two palette families with matched-substring glow, mono `SAV-{seq}`, the shared `SavStatusBadge`, `formatDZD` compact amounts, `relativeTime` SLAs, responsive trailing chips (name/code hide under `sm:`/`md:` — mobile rows stay lean); (3) deep-links — the SAV row fires the store's `openSavCase` (cockpit ALREADY OPEN on arrival, the previously-dormant token's first producer), the installment row fires the new `financeFocus` transient token (the `pipelineFocus` mount-initializer pattern — read once via `useState(() => getState()…)`, consumed on unmount, both the raw input AND the debounced mirror seeded so the first paint shows the isolated rows with no 300ms full-échéancier flash); (4) registry — `sav: Wrench` and `installment: Banknote` join `ENTITY_ICON` (the glyphs their nav entries already wear — one vocabulary, this log entry is the recorded decision).

**Validation:** curl — "SAV-3" → the exact elevator case; "Menad" → lead + SAV-1 + all 5 échéances ordered late-first; amine (SALES_AGENT) and mounia (FIELD_REP) → SAV rows scoped, installments EMPTY (the gate holds at the API). Browser E2E (`download/qa-ux-palette/` ×13): palette groups render (Prospects · Opportunités · Contacts · SAV · Échéances) · SAV row click → `#/sav` cockpit open · installment row click → `#/finance` search pre-seeded "Sofiane Menad", exactly his 5 rows · "SAV-3" → cockpit open · AR RTL (dir=rtl, «خدمات ما بعد البيع» / «الأقساط» headings, Arabic relative times + amounts + «مفتوح» badge, RTL deep-link live) · mobile 390 (scrollWidth 390 == innerWidth, responsive row slimming, deep-link works) · dark · role-gate live (amine: SAV group only, zero échéance rows) · console 0 · lint 0 · tsc 0.
