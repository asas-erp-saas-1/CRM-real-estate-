# UI/UX REDESIGN AUDIT — 2026-10-21 (UX/UI Audit Track, evidence-first, non-destructive)

**Mandate:** the UX/UI Audit Track — establish exactly what must change, for whom, why, and in
what implementation order BEFORE any radical UI redesign. This is an audit + design-specification
deliverable, NOT a visual rewrite. The engineering roadmap (`MASTER_ENGINEERING_ROADMAP.md`, G5
era, P4 tier) stays active and untouched; this track owns `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/` + evidence folders only.

**Evidence base (all captured this session, 2026-10-21):**
- `download/qa-uxa/` — 30 live captures (agent-browser, 1440×900 + 390×844, FR/AR, light/dark, 5 roles)
- `download/qa-uxa/vlm-*.json` — 5 VLM design reviews (glm-5v-turbo: dashboard, leads, pipeline, deal-economics, AR-RTL)
- DOM measurements for every VLM claim (the project convention: VLM findings are input, not truth)
- Existing test evidence cited where this session did NOT re-execute (matrix 325/325 standing, prior round receipts)

**Repo state at audit time:** `main` @ 16f19cd (G5-P4-4 round 6), worktree clean, dev server port
3000 HTTP 200, DB baseline verified seeded (8 users / 43 leads / 21 opps / 8 resv / 23 visits /
46 apts / 18 tasks / 161 activities). Zero console errors (`window.__errs === 0`) across ALL 30 captures.

---

## 1. Executive findings

1. **The application is a mature, heavily-engineered enterprise CRM UI** — 14 completed UX phases
   (P6 restraint program → P8 premium enterprise → P9 universal system → V1.9 → P11–P13 → P35–P50
   polish waves), 59 logged UX decisions (D-UX-001..059), a codified design system
   (`DESIGN_SYSTEM.md`) with token/type/action laws, and standing validation gates (matrix 325/325,
   lint 0, tsc 0 in src). **A "radical visual rewrite" is not supported by the evidence.** The
   foundation — hierarchy, density, RTL, a11y, states, error recovery — measured clean on every
   surface inspected this session.
2. **No P0 findings.** Zero security/data-integrity/critical-workflow blockers surfaced: RBAC nav
   gating verified live for all 5 roles; SALES_AGENT data isolation verified (14 leads, 100 %
   own, 0 other-agent rows); every destructive/money action is validation-gated (disabled submits
   observed on closure-evidence, reservation, and form dialogs).
3. **A small set of genuine, measured defects** (all P2/P3) — concentrated on the **deal-economics
   money surface** (action-hierarchy deviation + unformatted money input) and **two truncation-
   disclosure gaps** on the dashboard attention strip. Every other VLM-raised claim was rejected
   with DOM measurement (§5.3).
4. **The correct redesign program is targeted refinement + spec hardening, not reskinning**:
   enforce the existing design-system laws on the surfaces that drift (§6), design the missing
   patterns (money input), and produce high-fidelity passes on the 6 representative screens
   (§7) — all inside the existing token/type system (ADR-007 rev2 "Prune & Sable", aubergine).
5. **Concurrency & environment:** the audit ran non-destructively (renders + gated dialogs only,
   no mutations submitted; mutation coverage rides the standing matrix + prior round receipts).
   No files outside `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/` + evidence folders were touched.

---

## 2. Page & role inventory (verified live this session)

### 2.1 Views (9 + login — the ONLY route is `/`; client-side view routing via zustand)

| View | Purpose | Primary roles | Verified evidence (this session) |
|---|---|---|---|
| Login overlay | Auth + demo quick-login + lang switcher | all | 29-login-overlay.png (8 demo users, FR/EN/ع, password gate) |
| Dashboard | Triage: attention strip (7 cells), 8-metric context strip, journée panel, pending-decisions queue, commissions, movement | all (role-scoped content) | 01, 20, 22, 24, 26, 27 (light/dark/AR/agent/field-rep/owner) |
| Leads | List + filters + saved searches + dedup + import/export + drawer workspace | SALES_AGENT+, FIELD_REP hidden | 02, 03, 21 (isolation), 16, 17 (dialogs) |
| Pipeline | Kanban + drag moves + opportunity dialog + deal economics | SALES_AGENT+, FIELD_REP hidden | 04, 05, 12, 13, 30 |
| Visits | List + calendar (month/week) + P18/P20 decision lifecycle | all | 06, 15, 23 (field-rep powers) |
| Tasks | List + complete/postpone inline | all | 07 |
| Properties (Inventaire) | Apartment inventory + detail + demand matching + reserve | all | 08, 18, 19, 14 (matching) |
| Analytics | MANAGER+ KPIs/funnel/charts (D-021 gate + 403 lock) | MANAGER+ | 09 |
| Audit | Journal, searchable, human-readable | MANAGER+ | 10 |
| Settings | Team, org, export | MANAGER+ | 11, 28 (ADMIN team table, 8 rows) |

### 2.2 Roles (derived from `src/lib/constants.ts` ROLES + live nav verification)

| Role | Nav observed (live) | Data scope observed | Evidence |
|---|---|---|---|
| OWNER (Nadia) | all 9 views | org + pending-incentives queue + commissions rail | 26, 27 |
| ADMIN (Karim) | all 9 views | org + team management | 28 |
| MANAGER (Sarah) | all 9 views | org scope (25+ lead rows, all visits 23) | 01–19 |
| SALES_AGENT (Amine) | 6 views (no Analytique/Audit/Paramètres) | own+pool only: 14 leads, 100 % Amine-owned, 0 other-agent | 20, 21 |
| FIELD_REP (Mounia) | 4 views (no Prospects/Pipeline — P18/D-025) | project-assigned visits with confirm-on-place powers | 22, 23 |

Server-side authorization is the enforcement layer (D-021 visibility primitive, scoped 404s);
the nav hiding is presentation only — verified consistent with the ROLE_DATA_VISIBILITY_MATRIX.

---

## 3. Workflow maps (the 13-segment journey + exceptional states)

Legend: ✅ = rendered + interacted live this session · 📚 = existing verified evidence cited
(matrix 325/325 standing + prior round receipts) · no segment was invented.

| # | Segment | Entry → screens | Role | States observed | Evidence |
|---|---|---|---|---|---|
| 1 | Lead capture | Topbar/toolbar «Nouveau prospect» → dialog (name*/phone*/source*/priority/agent/budget/type/location/notes) | MANAGER+ (agent select), agents self | validation-gated submit (disabled until valid), WhatsApp-default checkbox | ✅ 16 |
| 2 | CSV import | Leads toolbar → 4-step wizard (map→preview→dedupe) | MANAGER+ | preview, undo, duplicate chips | 📚 qa-p2d + P5-5 extraction receipts; toolbar button verified ✅ |
| 3 | Deduplication | «Doublons probables (2)» → pair dialog → merge/dismiss (MANAGER+-gated, transactional) | MANAGER+ | pair diff, explainable scan | ✅ 17 (render), 📚 matrix DUP probes |
| 4 | Assignment | Drawer header «Changer le responsable» · create-dialog agent select | MANAGER+ | — | ✅ 03 (control present), 📚 prior E2E |
| 5 | Qualification | Drawer status dropdown (legal edges + corrections group) | agents + MANAGER corrections | lost-reason dialog, CorrectionReasonDialog (G5-P3-7 hatch) | ✅ 03 (control), 📚 round-2 E2E (correction round-trip + audit row) |
| 6 | Property matching | Drawer «Trouver des biens» → match cards (fit-tier, «Présenter») · apartment detail demand panel | agents | 18 match cards, present-flip | ✅ 14, 18 |
| 7 | Appointments | «Planifier une visite» (apartment / visits / drawer) → ONE store-driven dialog (project, units, prefill) | agents | prefill, unit multi-select | ✅ 18/19 (buttons), 📚 P28/P31 one-source law receipts |
| 8 | Visits | Visits view: list groups (Aujourd'hui/Demain/semaine) + calendar month/week | all | loading/empty branches; fiche dialog | ✅ 06, 15, 23 |
| 9 | Visit decision lifecycle | Row actions: Confirmer sur place / Refuser la proposition / Proposer un autre créneau + Terminer / Replanifier / Annuler + fiche | assigned FIELD_REP or MANAGER+ (D-025) | awaiting-customer-reconfirm, proposals, rejected w/ reason | ✅ 06, 23 (MANAGER + FIELD_REP both); 📚 matrix FR44 family |
| 10 | Follow-up | Drawer next-action band (quick-set) + composer (Note/Appel/WhatsApp/Email + §12.4 outcome select) · tasks view (complete/postpone) | agents | outcome chips, overdue rose | ✅ 03, 07 |
| 11 | Negotiation | Pipeline kanban (cards: value/name/next-action/days-in-stage) + opportunity dialog (value/probability/dates/docs) | agents + MANAGER | WIP limits, stage dialogs, lost-reason | ✅ 04, 05 |
| 12 | Reservation | Apartment «Réserver» → dialog (opportunity/montant/acompte/expiry) | MANAGER+ money gate | disabled submit until valid; double-booking guarded | ✅ 19 (render + gating), 📚 matrix F-06/FR44 rollback + concurrency |
| 13 | Authorized sale closure (two-step) | Deal dialog «Préparer la clôture» → evidence-gated request → second manager validates | requesting manager → validating manager | evidence textbox + disabled «Envoyer la demande»; reject w/ mandatory motif | ✅ 13 (render + gating, NOT submitted), 📚 round-5 full round-trip |
| 14 | After-sale (D-025: deal economics is the only money) | Dashboard «Décisions en attente» queue → deal dialog §38 machine (Approuver/Rejeter/Payer) + INCENTIVE timeline rows | MANAGER+ decisions, agent read-only incentive card | PENDING→APPROVED/REJECTED→PAID; decidedBy/paidOn stamps | ✅ 01 (queue), 12 (§37/§38 render), 📚 P29/P46 receipts |
| — | Lost leads | Drawer status → CLOSED_LOST w/ reason dialog | agents | reason mandatory | 📚 P6/P2d receipts |
| — | Cancelled/expired reservations | Deal dialog «Annuler la réservation» (gated); expiry dates render | MANAGER+ | disabled while closure pending; atomic rollback | ✅ 12 (control + gating), 📚 FR44c |
| — | Reopened / corrected | REACTIVATED status + corrections group w/ reason → LEAD_STATUS_CORRECTED audit row | MANAGER+ | audited corrections | 📚 G5-P3-7 + round-2 hatch E2E |
| — | Rejected requests | visits Refuser (w/ reason), closure Rejeter (mandatory motif) | MANAGER+/FIELD_REP | reasons recorded | ✅ 06/23 (actions), 📚 round-5 |
| — | Failed operations | toast errors w/ actionable messages; error boundary + recovery | all | human-language errors | 📚 qa-p3 + states.tsx; zero console errors this session |
| — | Unauthorized access | 403 lock screen (analytics pattern, D-021); nav hidden; scoped 404s byte-identical | below-rank | — | ✅ nav gating ×5 roles; 📚 P12-4 lock-screen E2E |

**Honest scope statement:** this session verified renders, gating, role scoping, and the full nav
surface live; deep mutation round-trips were NOT re-executed (non-destructive mandate) — they
ride the standing matrix (325/325) and per-round receipts, which is existing, not new, evidence.

---

## 4. UX by role & data scope — findings

- **Navigation correctness: verified for all 5 roles** (§2.2). No role sees actions it cannot
  perform; the FIELD_REP life (agenda + inventory) matches the P18 operating model.
- **Agent isolation is real, not cosmetic:** Amine's leads table = 14 rows, 100 % own
  (measured), while Sarah sees the org's 43. The dashboard scope captions (`dash.myDay` vs
  `team`) exist (P12-4).
- **Manager/owner visibility:** pending-decisions queue (3 rows, 436 500 DA), commissions panel
  with range selector, analytics org funnel — all render for MANAGER+ and were absent for the
  agent (measured via nav + prior P46 receipts).
- **No presentation-vs-security confusion found:** hiding never replaces server auth (D-021
  scoped 404s; analytics MANAGER+-gated API + 403 lock screen). No security defect surfaced.
- **Role-specific dashboard content differs correctly** (attention cells, queue, commissions
  panels suppressed below MANAGER — verified live by role switching).

---

## 5. Prioritized defect register (every severity justified by measurement)

### 5.1 P0 — security / data-integrity / critical blockers

**None found.** (Zero console errors ×30 captures; all money/destructive actions gated; RBAC +
isolation verified live; standing gates green at audit time.)

### 5.2 P1 — major usability problems affecting essential work

**None confirmed on inspected surfaces.** The daily-rep golden paths (triage → lead response →
visit decisions → pipeline hygiene) measured clean: two-tier dashboard hierarchy, D-UX-007
drawer workspace, D-UX-010 list ladders, D-UX-008 kanban cards, full decision vocabularies.

### 5.3 P2 — consistency / efficiency / system deviations (CONFIRMED by measurement)

| ID | Defect | Location | Measurement | Fix direction | Engineering dependency |
|---|---|---|---|---|---|
| UXA-1 | **Deal-dialog action hierarchy deviates from DESIGN_SYSTEM §7** — «Préparer la clôture» (the lifecycle primary), «Annuler la réservation» (destructive), «Enregistrer» (save) ALL render `outline`; no solid primary on the money screen; destructive not rose-distinguished | deal-economics dialog (12/30) | computed classes: all 3 = outline variant | one solid primary per dialog state; destructive → rose text/icon per §7; save = primary when dirty | pure presentation (deal-economics-closure.tsx + -manager.tsx, UX-track-owned after coordination) |
| UXA-2 | **Money input unformatted** — header shows `58 000 000 DA`, the Valeur spinbutton holds raw `58000000` (cognitive mismatch + typo risk on the highest-stakes field) | deal dialog, reserve dialog, opportunity dialog | input type=number value="58000000" | formatted money-input pattern (display-grouped, parse-on-submit — no API change) | presentation + small client util; zod contract unchanged |
| UXA-3 | **Attention-strip hint truncation without title** — 2 cells' hint labels visually clip with no `title` (D-UX-051 law violation; accessible names DO carry full text, so a11y is intact — sighted hover/tap disclosure missing) | dashboard attention cells 3 («Sans représentant terrain…») & 7 («Doublons à fusionner…») | scrollWidth > clientWidth, title=null | add title attrs (the D-UX-051 mechanical fix, 2 sites) | trivial, presentation-only |
| UXA-4 | **Deal-dialog info-block alignment** — «Mise à jour / Créé le» label/value pairs misaligned vs left labels (VLM claim, weak measurement — visual inspection of 30 confirms mild raggedness) | deal dialog meta block | screenshot 30 | align via grid label/value template | trivial |

### 5.4 P3 — polish / lower-impact

| ID | Item | Evidence | Verdict |
|---|---|---|---|
| UXA-5 | Commissions rail bottom whitespace vs left column (rail heights differ naturally) | 01 (unmeasured) | candidate for the dashboard rail pass |
| UXA-6 | «Motif» placeholder very light gray in closure form | 12 | placeholder contrast is a nice-to-have (WCAG applies to values); optional lift |
| UXA-7 | Sidebar overdue badge feels cramped at 1440 | VLM only (01) | subjective; keep unless the nav pass touches it |
| UXA-8 | Login «Mot de passe oublié ?» behavior untested this session | 29 | verify in Phase A QA; no evidence of defect |

### 5.5 VLM claims REJECTED with measurement (recorded to prevent re-litigation)

| Claim | Measurement verdict |
|---|---|
| "Severe truncation 'il y a 11 heures'" | full text renders; 0 clipped cells in that column (scrollWidth ≤ clientWidth) |
| "Budget column meaningless grey dashes" | range separator «–» + documented null em-dash placeholder (P6-8 convention) |
| "KPI row ragged/misaligned vs attention grid" | both tiers share x=256 origin, 12px gap rhythm (two-tier D-UX-015 by design) |
| "Journée metadata bolder than task titles" | title 600/13px vs meta 400–500/11px (D-UX-010 holds) |
| "Pending-queue truncation impossible to distinguish" | clipped BUT title attrs present (D-UX-051 compliant) |
| "Chart dates French under AR" | SVG axis labels measured Arabic («21 سبتمبر») — G5-P4-5 fix works |
| "Arabic-Indic numerals ٢٠٢٦" | 0 Arabic-Indic nodes, 62 Latin-digit nodes (project convention: Latin digits, DZ standard) |
| "Urgente priority color-only" | the label renders as text; the dot is the D-UX-010 High/URGENT-only accent |
| "Excessive toolbar→table gap" | 37px total (12px margin + card padding) — standard rhythm |
| "Duplicate Nouveau prospect buttons" | deliberate P9-5 context-aware CTA pattern (D-UX-030) — reviewed, kept |

### 5.6 Duplicated patterns → shared-component candidates

- The deal-economics money fields (commission/incentive/amount) and the reserve-dialog money
  fields hand-roll layout separately → one `MoneyField` presentation (rides UXA-2).
- Attention-cell hint truncation → the D-UX-051 titled-truncate utility covers it mechanically
  (UXA-3 is a compliance miss, not a missing primitive).
- No other duplication found — the component-reuse law (§11) visibly holds (badges, states,
  list rows, timeline all shared).

---

## 6. Proposed design-system specification (delta on DESIGN_SYSTEM.md — do NOT fork it)

The redesign must COMPLY with the existing system (ADR-007 rev2 tokens, semantic type scale,
§7 conventions) and extend it with the missing patterns:

1. **Dialog action-hierarchy law (hardening §7):** every record dialog declares exactly one
   solid primary for its current state; destructive actions render rose text/icon outline
   (never neutral outline); save buttons promote to primary only when dirty. Acceptance:
   DOM sweep across all dialogs — 0 dialogs with >1 solid primary or neutral destructive.
2. **Money-input pattern (new primitive):** `MoneyField` — grouped display (fr-DZ spacing),
   suffix «DA», tabular-nums, parse-to-number on submit; existing zod contracts unchanged.
   Acceptance: deal/reserve/opportunity dialogs render formatted values; submitted payloads
   byte-identical to today's (matrix money probes unchanged).
3. **Truncation-disclosure compliance sweep (existing law):** extend the D-UX-051 grep
   obligation to the attention-strip hints (UXA-3 class). Acceptance: 0 clipped content-bearing
   runs without title across all 9 views (the P37 sweep re-run).
4. **Representative-screen high-fidelity passes (§7 below)** stay inside the token system; any
   new visual idea must earn a D-UX entry with measurement before adoption.

---

## 7. Representative screens for the high-fidelity design phase (priority order)

1. **Main dashboard** (manager + agent variants) — the morning surface; carries UXA-3/5.
2. **Leads list + lead drawer** — the 50×/day rep workspace (already D-UX-007/011-strong; pass
   targets micro-hierarchy only).
3. **Deal economics (reservation + closure)** — the money screen; carries UXA-1/2/4 — the
   highest-defect-density surface found.
4. **Property inventory + matching** — the agent's product knowledge surface.
5. **Visits (list + calendar)** — the field-rep/manager coordination surface.
6. **Role-specific navigation + mobile** — nav rail variants + 390 layouts (currently clean;
   pass is verification + polish).

No broad redesign is authorized or needed for: settings, audit, analytics (all measured calm
and consistent; the VLM reviews raised nothing confirmed there).

---

## 8. Dependencies on engineering work

| Dependency | Status | Impact |
|---|---|---|
| Deal-economics module split (round 5) | DONE | UXA-1/2 land in the extracted `-closure`/`-manager` modules — clean ownership |
| properties-view 607L (next census target) | PENDING (G5-P4-4 opportunistic) | inventory/matching pass (screen 4) should follow the split, not precede it |
| Money contracts (§37/§38, zod) | FROZEN | UXA-2 is presentation-only by law — never touch the ladder/locks |
| P5 deployment gates | BLOCKED (owner) | out of UX scope; no dependency |
| Matrix 325/325 | standing | any Phase-A fix re-runs the 5-gate validation + the affected probes |

**Track ownership (per mandate §7):** engineering track = `src/**` + roadmap; UX track =
`05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/**` + `download/qa-uxa/**`. Phase-A code fixes (§9) land ONLY after a coordination
check (git HEAD + worktree clean) and in their own commits, never mixed with engineering-tier
refactors. No shared-file simultaneous edits: UXA-1/2 files (deal-economics-*) are UX-track;
properties-view stays engineering-track until its split lands.

---

## 9. Phased implementation sequence (with acceptance criteria)

| Phase | Scope | Acceptance criteria |
|---|---|---|
| **A. Defect fixes** (UX track, ~1 session) | UXA-1..4 + D-UX-051 sweep | lint 0 · tsc 0 src · matrix 325/325 unchanged · browser E2E console-0 on deal/leads/dashboard × FR/AR × light/dark × 390 · VLM re-review of deal dialog confirms hierarchy · screenshots archived qa-uxa/after-* |
| **B. Money-input pattern** | `MoneyField` + adoption on 3 dialogs | formatted render · submitted payload byte-identical (money matrix probes PASS unchanged) · RTL + tabular-nums verified |
| **C. Representative-screen passes** (6 screens, one per session) | high-fidelity refinement inside the token system | per-screen D-UX entry w/ measurement · before/after captures × light/dark/AR/390 · zero console errors · journeys re-walked |
| **D. Systemization** | dialog action-hierarchy DOM sweep + compliance laws into DESIGN_SYSTEM.md | automated sweep 0 violations · law documented |

Sequencing rationale: A/B close measured defects first (small, verifiable, unblock the design
phase), C rides the engineering decomposition order (deal-economics is split NOW; properties
rides its future split), D banks the laws so drift cannot recur.

---

## 10. Explicit unresolved questions & limitations

1. **"Radical redesign" scope vs the codified system** — the evidence supports targeted
   refinement; a wholesale visual reset would discard 59 measured UX decisions and re-incur
   known-defect classes (sky-* chips, rainbow icons, truncation…). **This needs an owner
   decision** before Phase C beyond the 6 representative screens.
2. **Arabic micro-copy human review** — standing owner decision (pre-existing; the MSA audit
   fixed machine-detectable issues; human review remains open).
3. **Mutation flows not re-executed this session** (non-destructive mandate) — closure
   round-trip, reservation create, visit confirm ride existing evidence; Phase A QA will
   re-execute the affected golden paths only.
4. **VLM residuals** — UXA-5/6/7/8 are unmeasured or subjective; recorded as P3 candidates,
   not facts.
5. **Perceived performance** — no instrumentation this session (dev-mode server); prior
   evidence (P8-16: 15–70ms, no N+1) stands; production perf rides the P5 gate.

## 11. The single highest-value next action

**Execute Phase A (UXA-1..4) — the deal-dialog action hierarchy + money-input formatting +
attention-strip title disclosure.**

Evidence: the money surface is where all four CONFIRMED P2 defects concentrate (12/13/30 +
measurements in §5.3); it is the highest-stakes screen in the product (§37/§38 commercial
trust), it was just decomposed into clean UX-track-ownable modules (round 5), and the fixes
are presentation-only with frozen contracts.

Dependencies: coordination check (HEAD + clean tree) before edits; 5-gate validation after;
no engineering-track file touched. This follows the existing roadmap (G5-P4-4 continues
opportunistically in parallel) — it does not replace it.
