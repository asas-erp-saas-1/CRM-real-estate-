# WAVE 3 — API EXTENSIONS: READINESS REVIEW (2026-10-22, proposals only)

**Status: PROPOSALS ONLY — no implementation.** This review satisfies the Wave-2A acceptance
closure §C: dependencies, affected files, security/privacy risks, test requirements, and conflicts
with ongoing engineering work for each Wave-3 candidate in
`05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/PHASE_C_DESIGN_PROPOSALS.md`. Every Wave-3 item is an **API extension** ([A] or [A+C]) —
under the standing Phase-C gating law each requires its named owner decision before any code
(decision #1 wave approval for all; #3 for the % basis model; #4 for the closure gate). Verified
against HEAD `8dcc8f9` (worktree clean).

---

## 1. Attention-cell & KPI isolation facets (Screen 1, proposal 1)

- **Defect being addressed:** 5 of 7 attention cells + KPI deep-links land on UNFILTERED views
  (`attention-strip.tsx:189-201`, `kpi-card.tsx:131`); the leads filter model has no
  `uncontacted` / `lastContactBefore` / date-window facet at all (`leads/filters.tsx:19-27`), so
  the aggregate number can never be reproduced manually.
- **Dependencies:** owner decision #1. New GET /api/leads facets (or a dedicated facets endpoint);
  the `duplicatesToken` store pattern to extend to leads/tasks/visits tokens
  (`src/lib/client/store.ts:155-166`).
- **Affected files:** `api/leads/route.ts` (facets + validation), `api/dashboard/route.ts` (cell
  definitions ↔ facet parity), `attention-strip.tsx`, `kpi-card.tsx`, `leads-view.tsx`,
  `leads/filters.tsx`, `store.ts`. All are UX-track-touched or UX-owned surfaces.
- **Security/privacy:** every new facet MUST compose with the D-021 scope predicate server-side
  (an agent isolating "uncontacted" must never see foreign leads); date-window facets must not
  leak cross-agent counts. Validation: zod + SORT_FIELDS-style allow-lists; no raw client
  predicates.
- **Tests:** new facet probes in an additive Wave-3 suite (agent vs manager scope on every facet —
  the W2-R4 pattern), count-parity probes (cell number === isolated list total), matrix re-run.
- **Conflicts:** low — leads-view.tsx is the UX track's surface (Wave 1 + 2A both landed there);
  no engineering-track work queued on it.

## 2. % basis → auto-computed commission amount (Screen 3, proposal 1 — owner decision #3)

- **Defect:** the manager hand-types the commission amount AND a free-text basis on the
  highest-stakes screen while the deal price sits in the same dialog
  (`deal-economics-manager.tsx`); "nothing is auto-calculated" is doctrine but the money math is
  left to the user's head.
- **Dependencies:** owner decision #3 (auto-compute with override vs manual + validation). The
  economics write path rides `PATCH /api/reservations/[id]` with the §37/§38 trust ladder in
  `src/lib/server/reservation-economics.ts` (206L, G5-P4-4 round-3 extraction).
- **Affected files:** `api/reservations/[id]/route.ts`, `lib/server/reservation-economics.ts`,
  `deal-economics-form-state.ts` (138L), `deal-economics-manager.tsx` (314L),
  `deal-economics.tsx` (orchestrator). Possible additive schema field for the stored basis %
  (an **S**-class change → separate owner approval; alternatives: reuse the existing basis text
  field with a structured prefix — the server echoes the derivation for the audit trail either way).
- **Security/privacy:** the derivation MUST be server-computed (never trust a client-computed
  money value); D-025 manager-only economics writes preserved; the audited-rebase law (§37/§38)
  must record the basis % in the audit payload; lock semantics unchanged.
- **Tests:** money-write matrix probes (basis % + price → amount round-trip, override path, rebase
  escalation), F-06 rollback probe extension, agent-403 probe on the new field, Wave-3 suite.
- **Conflicts:** **medium-high** — these are the round-5 freshly decomposed modules; the
  form-state-hook / manager-presentation / closure-module boundaries must be respected (extend,
  not re-merge). Coordinate with the engineering track before touching
  `reservation-economics.ts`.

## 3. Commission & incentive portfolio totals (Screen 3, proposal 2)

- **Defect:** zero expected/earned/received commission sums anywhere; no payout ledger; no
  commission analytics (verified absent from `/api/analytics`) — management has no portfolio view
  of its own revenue.
- **Dependencies:** owner decision #1; the analytics route extension
  (`api/analytics/route.ts`); client surfaces are the round-4 decomposed analytics modules
  (`analytics-view.tsx` 194L + `analytics-kpi.tsx` 186L + `analytics-charts.tsx` 270L +
  `analytics-tables.tsx` 193L) and/or a dashboard rail.
- **Affected files:** `api/analytics/route.ts` (aggregates: sums by trust state, payout ledger),
  the four analytics modules, possibly `dashboard-view.tsx` + a rail component.
- **Security/privacy:** financial aggregates are management-level data — the endpoint(s) must be
  role-gated (MANAGER+ for org totals; agents receive only own-incentive sums — the D-025 split);
  orgId scoping on every aggregate; no per-agent earnings exposed to peers.
- **Tests:** role-matrix probes (agent 403/limited vs manager full), aggregate-correctness probes
  against seeded §37/§38 states, matrix re-run + Wave-3 suite.
- **Conflicts:** low-medium — the analytics modules are stable post-round-4; additive aggregates
  fit the existing decomposition (a new kpi/tables section, not a re-merge).

## 4. Closure-economics gate (Screen 3, proposal 3 — owner decision #4)

- **Defect:** `validate_closure` proceeds forever with EMPTY commission fields — no reminder, no
  incomplete-economics flag; silent revenue leakage by design.
- **Dependencies:** owner decision #4 (**hard block vs warning banner** — a governance-semantics
  choice, not a technical one). The closure flow lives in
  `lib/server/reservation-lifecycle.ts` (354L) + `api/reservations/[id]/route.ts`; the client
  surface is `deal-economics-closure.tsx` (271L).
- **Affected files:** `lib/server/reservation-lifecycle.ts` (the gate at `validate_closure`),
  `deal-economics-closure.tsx` (the incomplete-economics state), possibly
  `deal-economics-manager.tsx` (the "enter economics now" CTA).
- **Security/privacy:** the two-manager closure governance must remain intact — the gate must not
  become a single-manager bypass; the gate decision (blocked/waived) must be audited; 422 shape
  for the hard-block variant documented in the contract.
- **Tests:** lifecycle round-trip probes (closure WITH and WITHOUT economics, both variants),
  the §44 tx-rollback probes re-run, audit-payload probes, Wave-3 suite.
- **Conflicts:** medium — `reservation-lifecycle.ts` is a round-3 extraction with dense matrix
  coverage; any gate change extends the covered state machine (additive states, no re-architecture).

## 5. Unit table view + sortable columns (Screen 4, proposal 1)

- **Defect:** full unit facts = 3-4 clicks deep (project → building tab → card → dialog); NO
  table view; NO sort control at all; `GET /api/properties/apartments` hardcodes
  `orderBy: [buildingId asc, code asc]` (`api/properties/apartments/route.ts:81`) — no `?sort=`
  support.
- **Dependencies:** owner decision #1; the apartments route gains a sort/dir allow-list (the
  leads SORT_FIELDS pattern); client: a new unit-table view component + the sort headers.
- **Affected files:** `api/properties/apartments/route.ts`, **`properties-view.tsx` (607L — the
  recorded NEXT census target of the engineering track's G5-P4-4)**, a new table component,
  `client/types.ts` (the API-contract mirror, deliberately monolithic — additive fields only).
- **Security/privacy:** low — inventory is org-scoped, not per-agent; the sort allow-list must be
  server-side (no raw orderBy injection); orgId scoping unchanged.
- **Tests:** sort-contract probes (every sortable column × direction × pagination interplay), the
  W2-R6-style page≠universe checks, E2E parity + AR-RTL/mobile 390.
- **Conflicts:** **HIGH — the headline conflict of Wave 3.** `properties-view.tsx` is queued for
  decomposition by the engineering track; the UX track's unit-table work would touch the same
  file. Per the standing shared-file coordination law: **decomposition first, feature second**
  (or an explicit ownership hand-off for the wave, with the census re-measured after). This item
  should be sequenced LAST within Wave 3 for exactly this reason.

---

## Cross-cutting readiness notes (all five items)

1. **Every item changes an API contract** → each needs its named owner decision + the
   contract-freeze discipline lifted only for that item; the standing matrix (325) must be
   extended additively and every Wave-3 wave-suite reported separately (the Wave-1/Wave-2
   convention).
2. **Gates unchanged:** lint 0 · tsc exactly 4 tolerated · matrix + additive suites · entity
   baseline byte-exact · console-0 · AR-RTL + mobile 390 on every new surface.
3. **Recommended order within Wave 3 (if approved):** #1 (attention facets — pure UX-track
   surfaces, lowest conflict) → #3 (portfolio totals — additive analytics) → #2 (% basis —
   coordinate with round-5 modules) → #4 (closure gate — governance decision) → #5 (unit table —
   AFTER the properties-view decomposition lands).
4. **No visual redesign** rides with Wave 3 (Wave 4 material); all new surfaces stay inside the
   existing token system.
