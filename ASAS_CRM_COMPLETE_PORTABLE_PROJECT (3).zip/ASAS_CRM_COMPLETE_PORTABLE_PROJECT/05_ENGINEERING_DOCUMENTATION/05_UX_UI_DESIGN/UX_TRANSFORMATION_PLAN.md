# UX TRANSFORMATION PLAN — Premium Role-Aware Real-Estate CRM

**Status: Phase 12 program of record (user mandate: "Premium CRM UX/UI + Role-Based Product
Transformation").** This plan is the evidence-based map from the mandate's 58 sections to the
product's actual state. It consolidates — it does not duplicate — the existing UX suite
(`UX_MASTER_PLAN.md` phases 6–11, `DESIGN_SYSTEM.md`, `USER_JOURNEYS.md`, `UI_QA.md`).

---

## 1. Current state (forensic audit, 2026-10-08 — evidence-linked)

The platform entered this mandate already carrying **five completed UX programs**:
Phase 6 (48-§ premium-workspace mandate), Phase 8 (60-§ premium enterprise UI — drawer
cockpit, kanban aging, inventory radar, matching drill-down, calendar temporal cells),
Phase 9 (universal token system — attention tiers, neutral ladder, type ladder, glyph
contract, motion catalog, keyboard layer), V1.9 (elevation ramp, density control, shimmer,
living KPI deltas), Phase 11 (WIP limits, week view).

**What the audit found genuinely missing** — the mandate's true core:

| # | Gap | Evidence |
|---|---|---|
| G-VIS | No record-level data visibility: a SALES_AGENT sees every lead/task/visit/opportunity/activity/document in the org; detail routes are org-scoped (intra-org IDOR) | `GET /api/leads` where = `{orgId}` only; `leads/[id]` findFirst `{id, orgId}` |
| G-DASH | One global dashboard for every role: agents see org-wide uncontacted/overdue/pipeline-value/ targets | `api/dashboard` computes org-scoped for all callers |
| G-ANALYTICS | `/api/analytics` has no role gate — agents see global revenue/funnel/conversion | `requireUser()` with no minimum |
| G-SEARCH | Global search leaks other agents' records (names/phones) into autocomplete | `api/search` org-scoped only |
| G-AI | Copilot reachable on any lead id (org-scoped findFirst) | `leads/[id]/copilot` |
| G-DOCS | Document list org-wide — agents see other agents' client documents | `api/documents` |
| G-NAV | Analytics view exposed to all roles in the sidebar | `sidebar-nav.tsx` ops section |
| G-DOCS-MODEL | No AUTHORIZATION_MODEL / ROLE_DATA_VISIBILITY_MATRIX / UX_TRANSFORMATION_PLAN documents | docs/ tree |

**What the audit found already at the bar** (do not redo — mandate §57):
role-rank RBAC on management routes, tenant isolation, premium visual system (§10–§12),
shell + palette + kbd layer (§13/§16/§26), drawer record-centric UX (§17/§18), operational
pipeline (§19), tasks/visits workspaces (§20/§21), next-action chips (§22), property cards +
matching drill-down (§23/§24), tables (§25), responsive/RTL/a11y/i18n fr/en/ar (§26–§33
swept zero-defect in P8.16–P8.20 + P9.10), AI disclosure UX (§34), empty/error/loading
states (`crm/states.tsx`), UX writing discipline (§30).

## 2. Root cause

The product was built org-shared (legitimate for a 5-person single-agency demo), and the UX
programs layered premium *presentation* over that shared model. The notifications route —
the newest, most carefully engineered surface — already ships the correct predicate
(`isManager ? {} : { OR: [{ ownerId: me }, { ownerId: null }] }`). The model existed; it was
never generalized. Phase 12 generalizes it into one server-side primitive and lets the UI
inherit the consequences.

## 3. Target state

« A premium, calm, role-aware real-estate operating system » where:

- **Agent** opens the dashboard → *My Day*: own overdue follow-ups, today's visits, hot
  opportunities, recent prospects — nothing that isn't theirs or the pool's. Their leads
  table, pipeline, tasks, visits, search, AI — all silently scoped. Analytics/audit/settings
  absent from their navigation.
- **Manager/Admin/Owner** → the team cockpit as today (org-wide), with the same premium shell.
- **Everyone** → identical premium visual language (P6–P11 system), but the *information*
  answers "what should I work on now", not "what exists in the database".

## 4. Design principles (binding for this phase)

1. **UI reflects permissions; the server enforces them** (mandate §6) — no client-side-only gates.
2. **Invisible security** (§36) — the agent experience gains calm, loses nothing legitimate.
3. **No visual redesign** — the P9/V1.9 system is the system; this phase changes *data scope
   and role adaptation*, not the design language.
4. **404, never 403-with-details** for foreign records — existence is not leaked (§15).
5. **One primitive, 55 routes** — `src/lib/server/visibility.ts` is the only place the
   predicate lives.
6. **Preserve working journeys** (§41) — filters, saved searches, bulk ops, import/export,
   WIP limits, week view keep functioning inside their scope.

## 5. Program (Phase 12 increments)

| Stage | Scope | Validation gate | Status |
|---|---|---|---|
| 12-a | This plan + `AUTHORIZATION_MODEL.md` + `ROLE_DATA_VISIBILITY_MATRIX.md` + D-021 | docs reviewed vs code | ✅ DONE |
| 12-b | `visibility.ts` primitive (scope builders + seesAllRecords) | tsc/lint | ✅ DONE |
| 12-c | Apply to all routes: lists, details, mutations, search, dashboard, analytics gate, pipeline counts, bulk, duplicates, matching, AI endpoints | visibility matrix script (§40 tests) | ✅ DONE — **40/40 PASS; caught + fixed a real search leak (scope-OR overwritten by route-OR — composition law added to AUTHORIZATION_MODEL §7)** |
| 12-d | Role-aware dashboard API (agent scope + nulls + scope echo) | curl as amine vs sarah | ✅ DONE — scope echo + funnel/sourcePerformance/targets null + uncomputed for agents |
| 12-e | Frontend role adaptation: nav gating (analytics MANAGER+), agent dashboard captions (i18n ×3), owner-filter suppression for agents | browser E2E both roles, AR + dark | ✅ DONE — My Day captions FR/EN/AR, analytics 403 lock screen, MovementPanel hidden, owner filter self-only |
| 12-f | Full validation: guard matrix + lint/tsc + E2E + residue audit | 5-gate protocol | ✅ DONE — 40/40 · lint 0 · tsc 0 src · E2E both roles + AR RTL + mobile 390 · zero residue |
| 12-g | Docs (MASTER_STATE, roadmap, UX_MASTER_PLAN) + worklog + commit | — | ✅ DONE |

## 6. Screen priorities after 12 (unchanged from mandate §48 order)

Phase A (audit) and B (model) are this document + the security pair. Phase C (design system)
and D (shell) already exist. Phase E (agent workspace) = 12-d/e. Phases F–L (record
workspaces, real estate, manager, admin, AI, responsive/RTL, QA) exist from P6–P11 — they
are *re-verified* under scoped data rather than rebuilt.

## 7. Out of scope (deliberate)

- Teams/multi-team hierarchy (single agency — matrix models manager = org).
- Per-field permissions, ABAC, row-level Postgres RLS (RLS-readiness documented instead).
- New visual identity work (P9/V1.9 own that surface).
- Contacts standalone CRUD, telephony/email-sending (existing product-scope decisions).
