# UX MASTER PLAN — Phase 6 (UX/UI Engineering)

**Authoritative plan for the premium UX engineering phase.** Born from the Phase 6 mandate
(48 sections) on top of the Phase 2 UX audit (B1–B7 closed Phase 4) and the Phase 5
operating system. This file = WHAT we are building and in WHICH order.
How we style: `DESIGN_SYSTEM.md`. Why we decided: `UX_DECISION_LOG.md`.
Current findings: `UI_AUDIT.md`. Who we build for: `USER_JOURNEYS.md`.

---

## 1. Phase objective

Transform ASAS from "a correct CRM UI" into a **premium daily operating workspace**:
calm, fast, predictable, comfortable for hours-long daily use by Algiers sales teams.
NOT a cosmetic reskin — an interface engineering program that reduces:

| Reduce | Optimize |
|---|---|
| cognitive load · navigation friction · clicks · visual fatigue | speed · clarity · comfort · predictability · focus |
| information overload · repetitive actions · ambiguity | "where am I / what needs attention / what can I do" answered instantly |
| accidental destructive actions · context switching | operational priority first (never vanity metrics) |

Mandate references: §2 objective · §3 philosophy (enterprise density × human comfort) ·
§4 visual direction (precision, not effects) · §47 the standard.

## 2. Non-goals (hard rules)

- NO new frameworks/libraries; shadcn/ui + Tailwind tokens only (AGENTS.md).
- NO business-logic changes: lifecycle, RBAC, financial rules, API contracts, validation
  are frozen (§32). UI is a client of the domain.
- NO visual gimmicks: gradients, glassmorphism, moving cards, decorative animations (§4).
- NO big-bang rewrite: controlled stages, validate + visually inspect + document each (§38/§44).
- NO duplicate components (Button/PrimaryButton/…) — reuse + compose (§27).
- NO blue/indigo; palette stays emerald/teal/amber/rose/violet on warm neutrals (ADR-007).

## 3. Stage program (mandate §38 — controlled stages)

Each stage: **implement → validate (5 gates + visual QA) → inspect visually → fix → document.**

| Stage | Scope | Status | Evidence |
|---|---|---|---|
| 1 | Design foundation: audit, semantic type scale + density tokens, 05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/ suite | **DONE (P6-1)** | UI_AUDIT.md, DESIGN_SYSTEM.md |
| 2 | Application shell: nav density, topbar hierarchy, footer | First slice DONE (P6-1b: shell + sidebar semantic migration); rest rides with later stages | |
| 3 | Dashboard: operational-first hierarchy, KPI restraint | **DONE (P6-1 — D-UX-001/003/005)** | after-kpi-{light,dark}.png |
| 4 | Lead workflows: list readability, drawer workspace, quick create | **CORE DONE (P6-1b name contrast + P6-2 drawer coherent workspace D-UX-007)**; quick-create polish deferred | after-p6-2-drawer-*.png |
| 5 | Pipeline/opportunity/deal workflows (kanban cards, stage moves) | **DONE (P6-3 — D-UX-008: next-action chip, amber overdue, hover restraint, column header anchor)** | after-p6-2-pipeline-cards-*.png |
| 6 | Activities/tasks/visits views | **DONE (P6-5 — D-UX-010: div-row ladder, reserved-line time columns, priority restraint, one-label visit actions, postpone, SCHEDULED violet, twMerge fix)** | after-p6-5-{tasks,visits}-{light,dark,mobile-390,ar-rtl}.png |
| 7 | Search/filtering/tables: zebra rows, name contrast, saved views | **DONE (P6-1b name contrast + P6-4 zebra channels D-UX-009; saved searches pre-existed; div-row ladder ported to lists P6-5)** — other tables adopt zebra per-surface in later stages | after-p6-3-leads-zebra-*.png |
| 8 | Detail pages + timelines (activity history readability) | **DONE (P6-6 — D-UX-011: day-group chips on the rail, actor emphasis, system-vs-human title weighting, 18px dots, copilot summary weight + flat tints + ≥10px badges + COLD slate, CALL dot teal-600)** | after-p6-6-{timeline,copilot}-*.png |
| 9 | Administration/settings (lower density, calm) | **DONE (P6-7 — D-UX-012: one neutral icon-chip language, weight-not-hue value chips, flat progress tones + dashboard twin, 24px rhythm, shadow-free sticky bar, ≥10px badges, neutral temp-password, slider-thumb aria names; team-section extracted 580→145+5 modules)** | after-p6-7-settings-{light,dark,mobile-390,ar-rtl}.png |
| 10 | Responsive/a11y/localization sweep (fr/en/ar × LTR/RTL × phone/tablet/laptop/large) | **DONE (P6-8 — D-UX-013: hit-area floor .crm-hit ×15 sites [≥24px AA / ≥44px touch, zero visual change], bidi isolation dir=ltr [leads emails, drawer email, audit diff-chips — 10 gaps → 0], Send+LogOut RTL mirrors, bell badge logical side, login LangSwitcher + html-dir sync pre-auth-gate, 3 legacy sub-10px retired)** | after-p6-8-{leads,audit}-ar-email-bidi, login-ar-langswitch-{desktop,mobile}, drawer-ar-send-mirrored, tasks-ar-mobile-390, {leads,audit}-ar-dark |
| 11 | Visual QA + consistency pass (all screens, long/empty/error states) | **DONE (P6-9 — D-UX-014: sky-* eliminated ×6 [NEW→slate, QUALIFIED→emerald ×2, info→slate ×2, audit LEAD→neutral outline], targets ring gradient→flat state tone, AnalysisCard gradient→flat primary tints [D-UX-011 twin], lead-drawer dead-tab-bar shrink-0 fix; entity-documents 853→173+6 modules — R12 complete)** | download/qa-p6/stage11/{before,after}-* |

Priority within the phase follows **user frequency** (§16/§33): the sales rep's
dashboard → leads list → lead drawer → pipeline get engineering attention first.

## 4. Stage-1 deliverables (this cycle)

1. **Audit**: code inspection + agent-browser screenshots (light/dark × 4 views) +
   VLM design review → `UI_AUDIT.md` (current-state, evidence-linked).
2. **Semantic type scale**: named utilities replacing the 520 ad-hoc `text-[Npx]`
   occurrences (9 different sizes found: 8–15px) → `DESIGN_SYSTEM.md` §Typography +
   token layer in `globals.css`. Migration is **incremental** (named scale for new +
   high-visibility surfaces; ad-hoc sizes retired per-stage, never big-bang).
3. **KPI card restraint redesign** (Stage 3 head-start — highest-visibility surface):
   fix label truncation, unify icon treatment, primary/secondary hierarchy, remove
   decorative corner glow + hover lift → `UX_DECISION_LOG.md` D-UX-001.
4. Master-state/roadmap/AGENTS.md reconciliation + worklog P6-1.

## 5. Definition of done per stage (mandate §46)

Visual: hierarchy · typography · spacing · alignment · consistency · calmness.
Interaction: navigation · forms · actions · feedback · error recovery.
Operational: speed · repetitive-workflow efficiency · keyboard · table · search · filtering.
Technical: responsive · accessible · performant · real data.
Product: reflects real workflows · respects permissions/domain · invents no behavior.

A stage is NOT done because it compiles — browser-verified (agent-browser + `window.__errs`=0)
and, where judgment is needed, VLM-re-reviewed against its own audit findings.

## 6. Frequency classification (drives prominence — mandate §33/§16)

- **Frequent** (immediate access): open lead, call/WhatsApp, log activity, quick follow-up,
  status move, search, create lead, dashboard triage.
- **Occasional** (discoverable, secondary): assignment, bulk ops, import/export, saved searches.
- **Rare** (available, not cluttering): targets, audit journal, org settings, password.
- **Dangerous** (deliberate): delete (AlertDialog), archive, ownership transfer, bulk changes.

## 7. Stage sequencing rationale

Shell (2) precedes views because every view inherits its density frame.
Dashboard (3) precedes leads (4) because it is the morning landing surface and the
VLM audit found its highest-impact defects. Tables (7) after workflows (4–6) because
row/channel styling must fit the final interaction patterns. Stage 10–11 close the
phase because a11y/RTL/visual QA are most valuable against a stable UI.

---

# Phase 8 — Premium Enterprise UI/UX (P8.x program)

**Brief source:** P8 mandate (60 sections) — transform ASAS into a world-class
real-estate operating workstation: CONTEXT FIRST, record-centric, calm + fast
+ dense + clear + predictable + premium + human. Reference grammar (10
enterprise-CRM screenshots, VLM-analyzed, D-UX-015 context): dark rail + light
canvas + white surfaces; TWO-TIER metric hierarchy (attention dominant, context
receding); multi-dimensional status; actionable everything; tabular numerals;
icon-label muted / value strong; color = meaning only; whitespace over borders.

## P8 stage program (implementation order per mandate §54)

| Stage | Scope | Status |
|---|---|---|
| P8.1 | Design-system foundation: attention/context metric tiers, shared TASK_TYPE_ICON, tel: pattern | **DONE (P8-1)** |
| P8.2 | Application shell refinement (topbar density, keyboard hints — largely pre-existing from P6/P7) | pre-existing ✓ |
| P8.3 | Navigation stability (active states, grouping — pre-existing) | pre-existing ✓ |
| P8.4 | Global search / command system (⌘K, grouped results — pre-existing) | pre-existing ✓ |
| P8.5 | Dashboard command center (attention-first re-tiering) | **DONE (P8-1, merged with P8.1)** |
| P8.6 | Lead workspace (list density, filter bar) | NEXT |
| P8.7 | Lead record workspace (identity contact links + next-task empty CTA — D-UX-017) | **DONE (P8-7)** |
| P8.8 | Activity timeline depth (already D-UX-011 — verified complete during P8-7 audit: day groups, type icons/dots, actor runs) | **VERIFIED (pre-existing)** |
| P8.9 | Pipeline workspace (days-in-stage aging chips + server-stamped stageChangedAt — D-UX-018) | **DONE (P8-9)** |
| P8.10 | Projects/buildings/apartments pages | **DONE (D-UX-019: rail delivery dates, orientation scan dimension, SOLD flat+fade recession, InventoryBar a11y label, twMerge shadow-group fix)** |
| P8.11 | Property matching UX | **DONE (D-UX-020: match cards = drill-down records w/ apartment dialog, RdC/R+N floor fix, localized unitType, orientation+delivery meta, fit-tier score tones, optimistic PRESENTED flip)** |
| P8.12 | Tasks/calendar/activities | **DONE (D-UX-021: fr-DZ/ar-DZ 12-hour locale bug fixed via hourCycle h23, calendar cells = temporal records (time + count micro-line), today = filled primary pill (2 honest VLM FAILs → universal convention), legend above fold + per-dot tooltips, tasks group bands, filter reset)** |
| P8.13 | Management views (analytics/audit) | **DONE (D-UX-022: covered-period range row, funnel conversion hint + math tooltips, axis de-clutter, LOGIN rows neutral-not-rose (alert-fatigue law), full-id tooltips; 13 VLM claims rejected with probe evidence)** |
| P8.14 | Administration | **DONE (D-UX-023: audited at the bar — 7/8 VLM claims rejected with evidence; targets empty-state teaches the inline-input model, copy-only ×3 langs)** |
| P8.15 | AI contextual UX | **DONE (D-UX-024: verify-before-action disclosure on copilot card + bulk dialog ×3 langs; tint + Bot + provenance + opt-in verified pre-existing — 4 VLM claims disproven by DOM probes)** |
| P8.16–P8.20 | Responsive / RTL / a11y / perf / full visual QA | **ALL DONE (D-UX-025: responsive 390/768/1280 zero defects · RTL/i18n 1049 keys ×3 + 9 AR views zero leftovers · a11y names/landmarks/contrast 5.73:1/focus-ring/h1 all pass · perf 15–70ms no-N+1 · final visual QA VLM 4/4 + errs=0 ×9 views) — PHASE 8 COMPLETE** |

## P8-1 scope delivered (D-UX-015 — see UX_DECISION_LOG)

Attention strip (critical tier, all-clear zero-state, deep-links) · compact
8-metric context strip (card soup retired) · actionable hot-opportunity rows
(lead-drawer deep-link + stage labels) · MovementPanel (funnel+sources tabs,
density rebalance) · canonical Ma-journée row anatomy (shared type icons,
clickable lead chips) · tel: deep links · i18n ×3 · full validation
(UI≡API — caught+fixed one real kpi-key bug; E2E; AR/dark/mobile; VLM 9/10).

## P8 continuation protocol

When the user sends «Continue» (or the cron cycle picks P8 work): read
MASTER_ENGINEERING_STATE §Phase-8 queue → pick the highest-value stage from
the table above (P8.9 next unless bugs surface (P8.8 timeline verified as already D-UX-011-complete during the P8-7 drawer audit)) → audit current surface →
design → implement → validate per §E protocol → append D-UX-016+ → update
this table. NEVER redesign blindly (mandate §53): audit → map → incremental.

## Phase 9 (proposed) — Universal UI system wave

User-commissioned visual improvement plan (full-platform 24-capture audit +
online research vs Lightning 2 / Stripe / Linear / HubSpot / Attio grammar):
**`VISUAL_IMPROVEMENT_PLAN.md`** — colors (neutral ladder + attention tiers +
status ramps + chart palette), icons (Lucide registry + stroke rules),
typography (Geist enforcement + tabular/mono numerals), information display
(essential/secondary element sets), React interactions (micro-interaction
catalog + keyboard/cmdk). 10 gated stages P9.1–P9.10, each §53-compliant and
independently shippable.

## Phase 9 stage table — ALL DONE (2026-10-08) — PHASE 9 COMPLETE

| Stage | Scope | Status |
|---|---|---|
| P9.1 | Token foundation: attention tiers ×3 (bg/strong/fg/line/accent) + neutral ladder tone-3/4/5 + chart-6 as CSS vars; migration of the scattered inline classes | **DONE (D-UX-026)** |
| P9.2 | Typography enforcement: num-xl Stripe move 28px/500, formatDZDPair unit split, weight/color audit, record-name 600 rule | **DONE (D-UX-027)** |
| P9.3 | Icon vocabulary registry: ENTITY_ICON contract, palette rewiring, size ladder 3.5/4/5 enforced | **DONE (D-UX-028)** |
| P9.4 | Row tactility + status ramps: .crm-list-row-accent, NEW pale-primary, budget micro-meter, drawer probability meter | **DONE (D-UX-029)** |
| P9.5 | Context-aware primary actions: CTA demotion rule, palette recents + Créer commands, composer focus | **DONE (D-UX-030)** |
| P9.6 | Avatar chips: userTone identity hash on kanban + drawer owner chip | **DONE (D-UX-031)** |
| P9.7 | Motion catalog: button press, kanban FLIP (layoutId), badge crossfade, drawer fade-in, MotionConfig reducedMotion | **DONE (D-UX-032)** |
| P9.8 | Keyboard navigation: j/k on leads table (Enter/Space contract preserved) | **DONE (D-UX-033)** |
| P9.9 | Analytics chart pass: CHART_CATEGORICAL fixed-order ramp, KPI sparklines series-colored | **DONE (D-UX-034)** |
| P9.10 | Full-platform visual QA + UI_QA.md baseline + docs | **DONE (D-UX-035: 9 views × light errs=0 · AR RTL ×9 clean · mobile 390 element-level 0 offenders (2px phantom probe-overridden) · dark token parity probed · lint 0 tsc 0 · 8 VLM runs all PASS)** |

The VISUAL_IMPROVEMENT_PLAN is fully implemented. Out-of-scope product
decisions remain in backlog (WIP limits, week view, per-user density
preference). Standing: R5/R6 owner decisions, Arabic micro-copy human
review, R3 test harness.

## Phase 10 — V1.9 « Premium 2026 nouvelle génération » (user-commissioned)

User commission: upgrade the platform to **V1.9 — premium UX professionnel /
UI premium 2026 nouvelle génération**. §53 discipline holds: audit-first,
token/contract-first, incremental, verify per stage. Audit findings (2026-10):

1. **Elevation** — only `--shadow-card` (single 1px layer) exists; floating
   surfaces ride shadcn defaults (`shadow-md`/`shadow-lg`) — no coherent
   depth ramp, no dark-mode-tuned layers.
2. **Version identity** — footer still reads « ASAS CRM v1.0 — © 2025 ».
3. **Density** — per-user density preference (Phase 9 backlog item) absent.
4. **Skeletons** — platform-wide `animate-pulse` (breathing blocks); the 2026
   premium idiom is a directional shimmer sweep.
5. **Living KPIs** — analytics KPIs show the window value + sparkline but no
   period-over-period delta (the « is this going up or down? » question).
6. **Notifications** — type-grouped live reminders; day-grouping audited and
   REJECTED (model = live-computed reminders, not an event feed). Kept.
7. **Palette** — no matched-substring highlight, no kbd legend.

| Stage | Scope | Status |
|---|---|---|
| V19-1 | Elevation ramp: `--elev-1..4` multi-layer tokens (light+dark) → `shadow-elev-*` utilities wired into popover/dropdown/dialog/sheet/palette + kanban hover-lift | **DONE (D-UX-036)** |
| V19-2 | Version identity: footer v1.9/© 2026 ×3 langs + sidebar version chip | **DONE (D-UX-037)** |
| V19-3 | Density control: persisted `density` store field, `data-density` on `<html>`, `--crm-td-h`/`--crm-th-h` row-height vars, sidebar footer toggle | **DONE (D-UX-038)** |
| V19-4 | Skeleton shimmer sweep (`.crm-shimmer`, RTL-aware, reduced-motion fallback) — one primitive change upgrades every skeleton | **DONE (D-UX-039)** |
| V19-5 | KPI deltas: analytics API `prevPeriod` (leads/opps/wonValue over the previous window) + ▲/▼ attn-tier chips | **DONE (D-UX-040)** |
| V19-6 | Notifications grouping — audited, REJECTED (live-reminder model; day groups inapplicable). No change | **N/A (D-UX-042)** |
| V19-7 | Palette: matched-substring highlight (accent-insensitive) + kbd legend footer | **DONE (D-UX-041)** |
| V19-8 | Full QA (lint/tsc/browser × light+dark+RTL, VLM 15/15) + docs + worklog + version close | **DONE (D-UX-042) — V1.9 COMPLETE** |

## Phase 11 — backlog product decisions (WIP limits + week view)

Two of the four Phase-10-candidate product decisions landed (user sign-off
implicit in the continued « Continue » mandate; both were pre-listed backlog
items from the Phase 9/10 close):

| Stage | Scope | Status |
|---|---|---|
| P11-1 | Kanban WIP limits: `PipelineStage.wipLimit` (1..99/null) + PATCH /api/pipeline/stages/:id (ADMIN, audited) + count/limit chips (attention ladder) + over-limit ring/toast — **warn-never-block** + filters-suppression law | **DONE (D-UX-043)** |
| P11-2 | Visits calendar week view: month\|week toggle, one shared cursor, 7 scan-surface day columns (shared day-agenda carries actions), today pill, week navigation, UI≡API parity | **DONE (D-UX-044)** |
| P11-3 (P12-1) | `atLeastRole` null-safe widening + the 3 documented client RBAC drift sites aligned to the server's rank gates (targets/team/settings) — Medium debt item CLOSED | **DONE (engineering, worklog P11-CLOSE)** |

Remaining Phase-10 candidates (user input still needed): R5/R6 owner data
decisions, Arabic micro-copy human review, R3 test harness (environment-gated).

## Phase 12 — Premium Role-Based Transformation (record-level data visibility)

User mandate ("Premium CRM UX/UI + Role-Based Product Transformation"): the
platform's most important problem was that UI hid what the server still served —
a SALES_AGENT could read every lead/task/visit/opportunity/activity/document in
the org through the API. Program of record: `UX_TRANSFORMATION_PLAN.md`;
binding model: `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/AUTHORIZATION_MODEL.md` + `ROLE_DATA_VISIBILITY_MATRIX.md` (D-021).

| Stage | Scope | Status |
|---|---|---|
| P12-1 (12-a/b) | Forensic audit of all 55 route files → OWN+POOL model (below MANAGER = own + unassigned pool + shared inventory/roster; MANAGER+ = ORG) → `src/lib/server/visibility.ts` — ONE primitive (scope builders, `seesAllRecords`, `assertLeadVisible`) | **DONE (D-021)** |
| P12-2 (12-c) | Enforcement across 32 route files: list conditions, scoped detail 404s (byte-identical to ghosts), POST-reference guards, bulk scope, duplicates existence-only, matching/copilot scope-first, analytics MANAGER+ gate — **the §40 matrix caught a real search leak (scope-OR overwritten by route-OR; fixed via AND-composition — law in AUTHORIZATION_MODEL §7)** | **DONE — matrix 40/40** |
| P12-3 (12-d) | Role-aware dashboard API: `scope:"own"\|"org"` echo, agent KPIs/agenda computed inside own+pool, funnel/sourcePerformance/targets null AND uncomputed for agents | **DONE** |
| P12-4 (12-e) | Frontend follows permissions: analytics nav minRole MANAGER, analytics 403 lock screen (audit-view pattern), My Day captions (`dash.myDay` agent / `dash.myDay.team` manager; `dash.recentLeads.own` ×3 langs), MovementPanel/TargetsPanel hidden on null, owner-filter suppression (agents see self only) | **DONE — E2E both roles, AR, mobile** |
| P12-5 (12-f/g) | 5-gate validation (matrix 40/40 · lint 0 · tsc 0 src · browser E2E amine+sarah FR/AR · zero residue) + docs + clean commits | **DONE — PHASE 12 COMPLETE** |

Remaining candidates (user input needed): R5/R6 owner data decisions, Arabic
micro-copy human review, R3 test harness (environment-gated), deployment prep.

## Phase 13 — Finance / Collections domain (ASAS mandate §7 Phase 7)

User mandate ("ASAS — AUTONOMOUS ENTERPRISE UI/UX ENGINEERING", 41 §): the
lifecycle tail (Contract → Payment Schedule → Calls For Funds → Delivery) was
entirely absent — the biggest genuine gap the mandate's forensic audit found.
Program of record: `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/ASAS_UI_UX_TRANSFORMATION.md`;
binding laws: D-022 (DECISION_LOG) + AUTHORIZATION_MODEL §3.3/§3.4.

| Stage | Scope | Status |
|---|---|---|
| P13-0 | Forensic audits (P13-0-a frontend / P13-0-b backend — Explore agents): 9 views + nav registry + dashboard anatomy + palette; 25 models + 57 route files + visibility primitive + seed structure; gap table mandate-vs-repo → finance = greenfield | **DONE** |
| P13-1 | Program doc `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/ASAS_UI_UX_TRANSFORMATION.md` (mandate §7 deliverable — current architecture, gap analysis, D-022 laws, roadmap) | **DONE** |
| P13-2 | Data model: `Installment` + `Payment` (migration `p13_finance_installments`), constants vocabularies (INSTALLMENT_KINDS/STATUSES, SETTLEMENT_METHODS), `installmentScope` primitive, PAYMENT activity type (18th) | **DONE** |
| P13-3 | API surface: `/api/finance/installments` (GET scoped list w/ buckets+search, POST MANAGER+), `/api/finance/installments/[id]` (PATCH lifecycle — PAID-direct 422), `/api/finance/payments` (POST tx — stamps PAID at coverage), `/api/finance/overview` (MANAGER+ KPIs + byProject), dashboard `finance` block, reservations CONVERTED starter-schedule | **DONE** |
| P13-4 | Collections workspace UI: `finance` view (attention tier overdue/dueSoon + all-clear, context metric row, bucket chips + search + count, zebra table + mobile transformed list, record-payment/detail/add dialogs), nav (Opérations, minRole MANAGER, Banknote glyph), dashboard third attention card (lg:grid-cols-3), 403 lock screen | **DONE** |
| P13-5 | i18n: `domains/finance.ts` (~75 keys ×3 langs) + enums/installment+settlement + audit.action ×5 + audit.entity.INSTALLMENT + nav.finance | **DONE** |
| P13-6 | Seed: `seedPaymentSchedules` (37 lines / 9 encaissements / 9 PAYMENT activities — overdue ×3 incl. 1 partial, dueSoon ×3, VSP schedules on all 7 won deals + ACTIVE deposit line) + standalone backfill runner | **DONE** |
| P13-7 | Validation: matrix extended **52/52 PASS** (F1–F11 finance probes + cleanup); browser E2E both roles (payment records + settles + live KPI update, call-for-funds, agent 403 lock + no nav + no card); AR RTL; mobile 390; VLM 13/13 (caught + fixed the 3-card orphan row); residue restored EXACTLY | **DONE — PHASE 13 COMPLETE** |

Next candidates (user input needed — unchanged): R5/R6 owner data decisions,
Arabic micro-copy human review, R3 test harness (environment-gated), SAV domain
(mandate §10 lifecycle tail — currently out of scope), deployment prep.
