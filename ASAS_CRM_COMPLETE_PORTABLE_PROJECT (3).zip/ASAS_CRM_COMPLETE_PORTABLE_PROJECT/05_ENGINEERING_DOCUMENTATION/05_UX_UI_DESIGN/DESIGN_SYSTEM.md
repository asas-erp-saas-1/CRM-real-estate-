# DESIGN SYSTEM — ASAS CRM

**Authoritative visual + interaction language.** Any UI change must comply with this
file. Tokens live in `src/app/globals.css` (`:root` / `.dark` blocks + `@theme inline`
mappings). Components: `src/components/ui/*` (shadcn — never re-implement) +
`src/components/crm/*` (composed app components). Decisions & rationale:
`UX_DECISION_LOG.md`. Audit state: `UI_AUDIT.md`.

---

## 1. Visual principles (mandate §3/§4/§47 — binding)

1. **Precision over effects** — the interface feels expensive because it is exact:
   alignment, rhythm, restraint. Not because of shadows/glows/gradients.
2. **Enterprise density × human comfort** — dense where data lives (tables, lists),
   calm where decisions happen (dashboard triage, forms, settings).
3. **Color is information, not decoration** — hue appears when it MEANS something
   (status, attention, semantics). Informational surfaces stay neutral.
4. **One system everywhere** — same spacing rhythm, same type scale, same radii,
   same border weights across all 9 views.
5. **Motion communicates state** — fast (≤200ms), subtle, purposeful only.

## 2. Color tokens (ADR-007 — **rev2 / P41: "Prune & Sable" identity**)

> **P41 identity shift (v1 → v2):** brand hue moved **emerald → aubergine**
> (`oklch(… 310)`). v1 conflated the brand hue with the semantic success tier
> (both emerald); v2 separates them: aubergine is BRAND-only (actions, focus,
> active nav, logo, chart series 1), emerald is SEMANTIC-only (positive
> status, tier-3 info, won/positive finance). Neutrals stay warm sand; amber
> highlight unchanged. Aubergine is the only hue range that is non-blue
> (project rule), visibly distinct from v1, and free of collision with the
> semantic rose 25 / amber 70-75 / emerald 160 tiers.

| Token | Light | Dark | Meaning |
|---|---|---|---|
| `--background` | warm paper oklch(0.985 0.003 85) | warm charcoal oklch(0.17 0.005 80) | app canvas |
| `--card` | white | oklch(0.23 0.005 80) (lifted Stage 1: 0.22→0.23, D-UX-003) | surface |
| `--primary` | deep aubergine oklch(0.46 0.11 310) | oklch(0.6 0.1 310) | brand + primary actions (v2) |
| `--highlight` | amber oklch(0.72 0.15 70) | same | highlights ONLY (never fills) |
| `--destructive` | rose | rose (dark lifted) | destructive semantics |
| chart-1..6 | **aubergine**/amber/**emerald**/rose/teal/stone | lifted variants | data-viz series (chart-3 violet retired — would collide with brand 310) |
| sidebar-* | theme-invariant dark charcoal; `--sidebar-primary` aubergine oklch(0.66 0.11 310) | same | nav rail (always dark) |

**Hue budget per screen (rule of restraint):** neutral surfaces dominate; ONE brand
hue (**aubergine**) for primary action; attention hues (amber/rose) only for genuine
attention states; emerald for positive/success semantics; teal for visits.
A row of mixed-colored decorative chips is a defect (see D-UX-001).

**Forbidden:** blue/indigo (project rule), neon saturation, gradients as decoration,
glassmorphism, large shadows, >3 attention hues visible at once.

## 3. Typography (Stage 1 semantic scale — D-UX-004; brand lockup D-UX-055)

Geist Sans (fr/en) · Noto Sans Arabic (ar, with 1.7 leading). Tabular numerals
(`tabular-nums`) on ALL data values (tables, KPIs, money, dates in lists).

**Official wordmark (D-UX-055, P42):** TYPOGRAPHIC — `AsasWordmark` = Geist
600, `tracking-tight`, riding the geometric mark (`AsasMark`), never a
second display font. The mark carries uniqueness; the wordmark stays
type-system-pure (no font download, offline-safe). Lockup component:
`src/components/brand/asas-mark.tsx` (`AsasMark` · `AsasMarkTile` ·
`AsasWordmark` · `AsasLockup`); static assets: `public/logo.svg`,
`src/app/icon.svg`, `src/app/apple-icon.tsx`, `public/brand/asas-brand-sheet.svg`.

| Utility | Size/line | Role (use for) |
|---|---|---|
| `text-crm-page` | 15px/1.33 semibold | view title (topbar h1) |
| `text-crm-section` | 13px/1.4 semibold | panel/card headers |
| `text-crm-body` | 13px/1.4 | body text, table cells, buttons |
| `text-crm-caption` | 11px/1.45 muted | secondary metadata, hints, timestamps |
| `text-crm-micro` | 10px/1.4 muted uppercase tracking-wide | section labels, badge text, footer |
| `text-crm-num-xl` | 22px/1 semibold tabular | KPI hero values |
| `text-crm-num` | 15px/1.3 semibold tabular | inline numbers, list row money |

Implementation: CSS custom utilities in `globals.css` (`@utility text-crm-*`).
**twMerge registration (D-UX-010):** custom `text-crm-*` are registered as
font-size class-group members in `src/lib/utils.ts` (`extendTailwindMerge`) —
size survives cn()-merging with state text colors; size dedup preserved
(later wins). Without this, tailwind-merge classified unknown `text-crm-*` as
text-COLOR and silently stripped the size when a color merged in.
**Migration rule:** new code MUST use the semantic scale; existing 520 ad-hoc
`text-[Npx]` are retired per-stage as surfaces are touched (no big-bang rewrite).
`text-[13px]`→`text-crm-body`, `text-[11px]`→`text-crm-caption`, `text-[10px]`→`text-crm-micro`
are the mechanical mappings; verify hierarchy intent, not just pixel equality.
Legacy sizes 8/9px are forbidden in new code (a11y floor: 10px uppercase micro).

**Truncation rule:** labels never mid-word-truncate — use `line-clamp-2` (with
reserved min-height when rows must align) or `truncate` + `title` attr for
single-line values (names, emails). Data values truncate; descriptive labels wrap.

## 4. Spacing & density model (mandate §34)

| Context | Frame padding | Grid gap | Card padding |
|---|---|---|---|
| View content (`main`) | px-3/py-4 mobile → lg:px-8 | — | — |
| Dashboard grid | — | 12px (gap-3) | 16px (p-4) |
| Lists/tables (dense) | — | — | cell px-3, row h-10 |
| Record detail / drawer | — | 12–16px | 16–24px |
| Forms (focused) | — | 16px fields | 24px dialog |
| Settings (calm) | — | 24px | 24px |

Vertical rhythm between major view blocks: `space-y-4` (16px) — never arbitrary
mixed 12/16/20px in one column. Panel header → content: 12px (pb-3 pattern).

## 5. Surfaces, borders, radii, shadows

- Radius scale: controls 6px (`rounded-md`), cards/surfaces 8px (`rounded-lg`
  = `--radius`), pills `rounded-full`. No mixed radii in one container.
- Borders: `--border` (hairline). Dark mode uses alpha borders (white/12%).
- Card shadow: `--shadow-card` = single 1px/2px whisper (`0 1px 2px rgb(20 18 12/0.04)`
  light, `0 1px 2px rgb(0 0 0/0.35)` dark). NO layered shadows, NO glows.
- **Hover = border/bg shift, never movement** (no translate lifts — D-UX-001).
- Sticky table headers: `crm-table-sticky` (blur-backed).
- **Scroll-driven sticky chrome (P35 / D-UX-047):** the topbar (`.crm-chrome-doc`)
  and every `.crm-table-sticky thead th` gain the `--sticky-chrome-shadow` whisper
  ONLY while content scrolls under them — CSS scroll-driven animations
  (`scroll(root)` 0→96px document · `scroll(nearest)` 0→72px inner), box-shadow
  only, `@supports`-gated + `prefers-reduced-motion`-gated (engines without
  scroll timelines keep the border-b-only resting chrome). Decoration-of-state,
  never motion — §8 doctrine intact.
- **Interior surfaces are flat-tint-only (P35 / D-UX-045 — the twin sweep law):**
  gradients/glow spans are gone from every informational surface (empty states,
  dialog header bands, reservation/commission panels, bulk-copilot chip +
  progress). The ONE expressive exception: the login canvas's radial atmosphere
  (D-UX-046) — identity lives at the threshold, quiet everywhere after.
- Brand marks (logo tiles sidebar/boot/login): flat `bg-primary` + hairline
  ring (D-UX-046 quiet chrome). Sidebar active rail: flat emerald bar, no glow.
- **One version surface (P36 / D-UX-050):** build identity renders exactly once
  per screen — the sidebar's D-UX-037 version chip. The footer carries the
  copyright line only (the `ASAS CRM v1.9 — ` prefix was deleted from
  `app.footer.left` ×3 langs).
- **Multi-series charts carry their mapping at rest (P36 / D-UX-049):** a color
  law only the tooltip can recite is not a law. The MonthlyTrendChart legend =
  two quiet chips whose GLYPH encodes series type (amber square = bar series ·
  emerald line = line series), labels reuse existing i18n keys (key-neutral).
- **Truncation disclosure (P36 / D-UX-051 — P8-6 generalized):** every
  content-bearing truncating run carries its full text in `title` (dynamic
  content: the composed string; static hints: the same sentence). Exempt:
  static short label keys and numeric captions — the law covers content the
  user cannot otherwise recover. (P37 completion: the dashboard period caption
  ×2 renderings + the inventory rail joined the titled set; live sweep = 0
  untitled content-bearing runs across all 9 views.)
- **Tel tokens never wrap (P37 / D-UX-052):** a phone number is an atomic
  token — every text-bearing `tel:` anchor carries `whitespace-nowrap`
  (leads rows + mobile cards, dashboard recent-leads, demand panel, visit
  fiche, lead drawer). The icon-only call button is exempt (no text). Squeezed
  layouts take the column's natural width and scroll (the overflow-x law),
  never mangle the number onto multiple lines.
- **Control-state disclosure (P38 / D-UX-053 — the D-UX-051 law extended to
  its own control-state class):** a Select/filter trigger whose rendered value
  truncates carries the full current selection in `title` (team-table role
  triggers — self rows append the self-hint; pipeline + tasks owner filters;
  the kanban `line-clamp-2` nextAction gets the composed action · date — a
  line-clamp is a truncation mechanism and the law covers its own mechanisms).
  Any truncation discloses — record content, caption, or control state.

## 6. Icons

Lucide only, `size-4` (16px) standard / `size-3.5` in dense chips. Icon chips
(status containers): **neutral by default** — `bg-muted text-muted-foreground`;
semantic tint ONLY for attention states (`bg-rose-500/10 text-rose-600` …).
Directional icons mirror in RTL (existing `[dir=rtl]` rules — keep the class list
in sync when adding new directional glyphs; current list: chevron-left/right,
arrow-left/right, chevron-first/last, arrow-left/right-to-line, reply, undo-2,
**send**, **log-out** — P6-8 additions).

## 7. Core component conventions

| Pattern | Convention |
|---|---|
| Primary action | one per screen, emerald solid, `text-crm-body`, icon size-4 |
| Secondary actions | `outline`/`ghost` variants — never compete with primary |
| Destructive | rose text/icon + AlertDialog confirm (irreversible only) |
| Status badges | pill, 10px micro uppercase, tinted 10–15% bg + stroked text; ONE system (dot = source/type, pill = status) |
| Tables | `crm-th/crm-td` primitives, sticky header, row hover `bg-muted/80`, clickable-row inset accent (`crm-tr-accent`), zebra opt-in via `crm-zebra` on `<table>` (D-UX-009 ladder: zebra 60 < selected 70 < hover 80 — zebra yields to row states via `:not(:hover):not([data-selected])`) |
| Dialogs | focus restore to trigger (B2 closed), Escape closes, max 1 nesting level |
| Record drawer (D-UX-007) | header (identity + status/owner/contact actions) → **next-action band** (3 cells: follow-up quick-set · last contact · nearest open task; `bg-muted/30`, micro labels, `font-medium` values, rose ONLY for overdue, cells may deep-focus a tab) → info grid (static facts, 400 values) → tabs. Default tab = context-first: activity preview (timeline's own TYPE_ICON/TYPE_DOT) + quick-log Composer + assistance + forms. Tab strip `overflow-x-auto` under 6 tabs. NO gradients on drawer surfaces. |
| Kanban card (D-UX-008) | identity row (name + value, `text-crm-body` semibold) → title caption → probability hairline bar → **next-action chip** (`rounded-md px-1.5 py-1`, `bg-muted/60` upcoming / `bg-amber-500/10 text-amber-700` overdue ONLY, medium weight, `text-xs line-clamp-2` — labels wrap, never truncate) → owner caption. Hover = `border-primary/40` + `bg-muted/40`, NO lift. Column headers `border-b` anchored. ONE body component feeds kanban + drag overlay + mobile card. |
| Operational list row (D-UX-010 — tasks/visits/today rows) | `[checkbox] [type icon] TITLE 600 + muted meta` → attributes → **fixed-width time column** (`w-[4.25rem] text-end`, 13px medium tabular time; date line ALWAYS reserved — painted `formatDayMonth` when not today, `invisible` when today — rose ONLY overdue; attributes BEFORE the column so label-width variance never shifts the anchor) → actions. Rows = `.crm-list-row` (hover 80) inside `.crm-list-zebra` (alt 60 via `:nth-child(even of .crm-list-row)` — group headers never consume parity; zebra opt-in per surface). Visit rows: ONE labeled lifecycle primary + icon-only secondaries (aria-label + title). Priority dot ONLY High/URGent — the label carries the meaning. |
| Activity timeline (D-UX-011) | vertical rail (`border-s` + `ps-5`) with 18px dots (12px glyphs, `ring-4 ring-background` punch-out) on it; **day-group chips** at calendar-day boundaries (`Aujourd'hui`/`Hier`/locale date — chip sits ON the rail via the same negative-margin geometry, solid `bg-background` + hairline border masks the line; local-time keys); entry = title (`text-crm-body` — `font-medium` HUMAN types [NOTE/CALL/WHATSAPP/EMAIL/SMS/MEETING/VISIT], `font-normal text-foreground/80` system types) + caption run `type · ACTOR(font-medium foreground/75) · relativeTime` + optional caption body. Dot hue = semantic family (stone artifacts · slate workflow · amber milestones · emerald outreach · violet written/async · **teal live human contact {VISIT 500, CALL 600}** · primary deal milestones). |
| AI assessment card (D-UX-011) | flat `bg-primary/[0.03]` (+ `[0.045]` CTA state — NEVER gradients) + `border-primary/25`; header strip `bg-primary/[0.05]`; **summary = `text-crm-body font-medium` (primary content)**; section titles semibold caption; rationale/talking points caption; drafts body; badges ≥10px literal on color-coupled chips; temperature trio rose/amber/**slate** (COLD — no blue). Applies to BOTH twins (lead-copilot-card AND entity-documents AnalysisCard — D-UX-014 twin fix). |
| Settings surface (D-UX-012) | ONE neutral icon-chip language (`bg-muted text-muted-foreground` — every section/slider/dialog chip; role-toned AVATARS stay: identity data); value emphasis = weight (`bg-muted` chip + `text-foreground` semibold), NEVER brand hue; state badges (total ok/warn, active on/off) keep semantic tints; 24px card rhythm (`space-y-6`) + p-4 control rows; sticky save bar = border + `bg-background/95` + backdrop-blur (NO layered shadow); progress = flat tones (emerald/amber/slate, no glow/gradient, 200ms); one-time secrets (temp password) = neutral `bg-muted` mono value + ONE amber attention hint; slider a11y names go on the THUMB (wrapper forwards aria-label). |
| Progress ring (D-UX-014) | dashboard targets org-ring = flat state tone via `stroke="currentColor"` + tone class (≥100 emerald / 70–99 amber / <70 slate, dark-lifted) — the SAME done/warm/cold machine as the rows; NO gradient strokes anywhere (defs deleted); track = `text-muted`. |
| Attention strip (D-UX-015, P8) | dashboard tier-1: micro section label + 2 critical cells (uncontacted amber / overdueTasks rose) — tinted icon chip `size-10`, `text-crm-num-xl` count in the attention hue, `border-s-[3px]` accent, deep-link Button; clean metric renders `opacity-55`; ZERO-state = single emerald all-clear card (the zone NEVER disappears). kpi keys are the RAW API keys (`uncontacted`, `overdueTasks` — P8-1 caught a `kpis["overdue"]` index bug; probe UI≡API when touching). |
| Compact metric strip (D-UX-015, P8) | dashboard tier-2: 8 receding context metrics, ONE row (`grid-cols-2 sm:4 xl:8`), `p-3` cards — number first (`text-crm-num`), label + live/period dot beneath (violet window / emerald live), NO icon chips, NO accents; deep-link only where a workspace exists (`view` field). Attention metrics NEVER duplicate here. |
| Hot-opportunity row (D-UX-015, P8) | whole row = button → `openLead(leadId)` (pipeline fallback); title+value → stage bar (inline-start fill) + `stage.*` LABEL (w-24 caption, truncate+title) → next-action caption. Stage label text over stage coloring (hue budget). |
| Movement panel (D-UX-015, P8) | funnel + source-performance share ONE card via Tabs (period caption in header); funnel bars fill from inline-start (RTL-correct), `color-mix` emerald intensity ramp. |
| tel: deep link (D-UX-015, P8) | phone values in activity tails render `<a href="tel:{E.164}">` + `stopsPropagation` (call-intent ≠ open-record-intent) + aria "Appeler {name}"; `.ltr-token` isolation kept. |
| Shared TASK_TYPE_ICON (D-UX-015, P8) | task-type→glyph map lives in `badges.tsx` (tasks view + Ma journée import it) — one glyph per type app-wide; chip `size-7 rounded-md bg-muted`, rose tint ONLY when overdue (D-UX-001). |
| Audit entity chips (D-UX-014) | categorical tints on RARE entities only (APARTMENT amber, OPPORTUNITY/ACTIVITY violet, RESERVATION emerald, TASK slate, VISIT teal, USER rose); the MOST FREQUENT entity (LEAD) renders neutral outline — same fallback as unmapped entities (PROJECT/CONTACT/PIPELINE); undone rows keep the rose override. |
| Notification severity (D-UX-014) | urgent rose / warning amber / info **slate** (icon-chip style + unread dot) — info = the quiet severity (COLD precedent); the bell count badge stays rose. |
| Lifecycle chip hues (D-UX-014) | NEW = slate in BOTH maps (lead status + opportunity stage — same concept one language); QUALIFIED = emerald in BOTH maps; blue-family (sky/indigo/blue) chips are ELIMINATED app-wide (DOM sweep 0). |
| Drawer tab bars (D-UX-014) | tab-bar wrappers inside `overflow-y-auto` sheet/dialog flex columns MUST carry `shrink-0` — a shrinkable wrapper collapses to ~1px when content exceeds available height and the panel paints over the dead triggers (the lead-drawer bug class). |
| Loading | skeletons shaped like content; `placeholderData` to avoid flash on refetch |
| Empty states | what/why/next-action + CTA button (never bare "No data") |
| Errors | human language + retry; technical detail to dev log only |
| Toasts | sonner; success on mutation, error w/ actionable message |

## 8. Interaction & motion

- Transitions ≤200ms, ease-out, opacity/color/border only.
- `animate-pulse` reserved for genuinely live data indicators (footer DB dot, live KPI caption).
- Count-up on KPI numbers (existing) — keep, it communicates data arrival.
- Focus: visible ring on all interactive elements (`focus-visible:ring-2 ring-ring/50`).
- Keyboard: ⌘K search, arrow-nav in command palette, tab order follows DOM order,
  tables get focus-visible row outline.

## 9. RTL / i18n rules

**Key location (P7-1):** i18n dictionaries live in `src/lib/i18n/domains/*.ts`
(18 domain modules — common/enums/leads/matching/copilot/documents/visits/audit/
dashboard/properties/settings/auth/pipeline/analytics/tasks/notifications/search/
import-export). Each module holds fr/en/ar side-by-side; add new keys to ALL
THREE langs in the matching domain file. A module-load duplicate-key guard plus
the `@/lib/i18n` re-export surface keep consumers unchanged. Never hardcode
user-facing strings in components.

Logical properties only (`ps-`/`pe-`/`ms-`/`me-`/`start-`/`end-`) — never `ml-/mr-/pl-/pr-`
in NEW code. **P7-3: the `src/components/ui/` primitives the app renders are
logicalized too** (toast/dialog/alert-dialog/select/dropdown-menu/table/sheet:
`end-4` close buttons, `pe-8 ps-2` select items with `end-2` indicators,
`text-start` table heads/dialog headers, `sm:end-0` toast viewport). Any newly
added stock shadcn primitive must get the same treatment before first RTL use.
**Radix direction context (P7-3):** `Providers` mounts
`<DirectionProvider dir={dir}>` — without it, portaled Select/menu poppers
hard-code `dir="ltr"` and lay out wrongly in Arabic. Keep it. Sonner `Toaster`
gets `dir={dir}` (mirrored close button + swipe) — keep that too. Stock
sr-only labels must not be hardcoded English: dialog/sheet close use
`useT()("action.close")`. Latin tokens (phones, emails) get `.ltr-token` isolation — and
**block/flex containers carrying Latin runs use the `dir="ltr"` HTML attribute
instead** (spec-level bidi isolation, no display override — `.ltr-token` forces
inline-block and would break block-truncate spans / inline-flex chips; D-UX-013).
Arabic view switches font stack + 1.7 leading automatically. Test AR on every
Stage-10 sweep. Sidebar is always LTR-ordered logically (sections in same order,
mirrored physically). Login surface carries its own LangSwitcher (D-UX-013) —
`<html dir/lang>` sync runs BEFORE the auth gate (CrmApp), so the Arabic font
stack applies pre-login too.

## 10. Responsive & a11y floors

- Mobile-first breakpoints (sm/md/lg/xl); tables → cards below `md` (existing pattern).
- **Hit-area floor (D-UX-013):** small interactive controls in dense rows/cards
  get `.crm-hit` (globals.css) — visual size unchanged, effective pointer target
  +16px (≥24px WCAG 2.5.8 AA) and +28px on `(pointer: coarse), (hover: none)`
  (≥44px mobile floor). Apply to icon-only actions, inline record links, row
  checkboxes/switches. NOT to text inputs (WCAG text-entry exemption) or
  full-size buttons.
- Touch targets ≥44px on mobile controls (checkbox cells get generous hit areas —
  delivered via `.crm-hit`).
- Text floor 10px (uppercase micro only); body 13px.
- Every icon-only button has `aria-label`; every image has alt; semantic landmarks
  (`main/header/nav/footer` — already in shell).
- `prefers-reduced-motion`: framer respects it via its API — keep transitions subtle
  enough that this is a courtesy, not a dependency.

## 11. Component reuse law (mandate §27)

Before creating ANY component: search `src/components/ui/*` + `src/components/crm/*`
for an existing one. Semantic distinction only (no Button/PrimaryButton/ActionButton
family). Compose: KPI card, panel-title, states, badges are the shared vocabulary.
A new component needs a UX_DECISION_LOG entry if it introduces a NEW pattern.

## 12. Visual QA checklist (per surface, mandate §29/§30)

0 records · 1 record · page-full · long names · missing values · very long notes ·
light + dark · fr + ar · 1440 + 390 widths · `window.__errs` === 0 · UI ≡ API values.
Archive evidence to `download/qa-p6/` (or qa-p<phase>) with before/after naming.
