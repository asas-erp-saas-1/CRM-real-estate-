# WAVE 2B — LEAD INLINE EDITING: OWNER-DECISION BRIEF (2026-10-22)

**Status: BLOCKED — no implementation until the owner explicitly approves each decision below.**
This brief is decision-support only. Nothing in it changes any contract, schema, or authorization
semantics. It consolidates the server-side inspection recorded in worklog `UX-PHASE-C-W2` §Wave-2B
and re-verified against the committed tree at HEAD `8dcc8f9` (worktree clean).

---

## Verified current behavior (the facts every decision rides on)

| Surface | Verified fact (file:line at HEAD) |
|---|---|
| PATCH accepted fields | `fullName`(trim 1-160) · `email`(≤200) · `secondaryPhone`(≤40) · `whatsapp`(≤40) · `status` · `correctionReason` · `ownerId` · `priority` · `score`(0-100) · `lostReason` · `notes`(≤5000) · `nextFollowUpAt` · `budgetMin/Max` · `propertyType` · `desiredLocation` · `archived` — `src/app/api/leads/[id]/route.ts:90-111` |
| Primary phone | **NOT accepted by PATCH** — deliberately immutable; canonical E.164; `@@unique([orgId, phone])` is the person-identity/dedup key (`prisma/schema.prisma:146,198`). The only path to a corrected phone today is duplicate-then-merge |
| Phone validation (create path only) | `normalizePhone()` (DZ + international → E.164, `src/lib/phone.ts:22`) + same-org duplicate detection on phone OR email before insert (`api/leads/route.ts:140-143`) |
| RBAC on PATCH | D-021 scope (404 no-leak) · owner-change MANAGER-gated 403 · archive owner-or-MANAGER 403 · status adjacency matrix + MANAGER `correctionReason` hatch · **every other field is open to any in-scope user today** — the UI simply never exposes them (`[id]/route.ts:120-199`) |
| Audit trail | status → Activity + AuditLog (`LEAD_STATUS_CHANGED` / `LEAD_STATUS_CORRECTED`) · owner → `LEAD_ASSIGNED` · **all other fields (name/email/phones/notes/priority/score/budgets/…) write ZERO audit + ZERO activity rows** · archived-only changes also silent (probe W2-R5c) |
| Concurrency | **NO stale-guard — last-write-wins** (`[id]/route.ts` has no `expectedUpdatedAt`). Contrast: visits PATCH takes optional `expectedUpdatedAt` → 409 `VISIT_STALE` (`api/visits/[id]/route.ts:148,164-165`). `Lead.updatedAt @updatedAt` exists — the token source is available |
| Failed-save UX today | the drawer toasts the server error verbatim; no field-level rollback disclosure |

**Correction to the Phase-C proposals doc:** it states "phone/name need a small schema addition"
(proposals Screen 2, proposal 2). This is half-right: `fullName` is **already accepted** by the
PATCH contract; only the **phone** would need contract work (validation + uniqueness semantics),
and even phone needs **no schema change** — the column and unique index already exist.

---

## DECISION D1 — Which lead fields become editable?

| Option | Content | Risk | Compatibility | 
|---|---|---|---|
| **A** | Non-identity set only: email, secondaryPhone, whatsapp, priority, score, notes, budgetMin/Max, propertyType, desiredLocation, nextFollowUpAt | Lowest. The P0 complaint ("cannot correct a phone number") remains solvable only via duplicate-then-merge | Zero contract/schema change — server-ready today |
| **B** | A + `fullName` | Low-medium. Name edits are currently **invisible in the trail** (see D3) — shipping B without D3 creates silent identity mutation | Zero contract change (already accepted) |
| **C** | B + primary `phone` | Highest. Phone is the dedup/identity key: a change re-keys the person, can create/destroy duplicate pairs, and interacts with merge + CONVERTED locks | Contract extension + validation + uniqueness semantics (D2); no schema change needed |

**Recommendation:** **B** (with D3 audit + D4 stale-guard). C only if the owner explicitly accepts
the identity-event costs in D2/D3 — otherwise phone stays immutable and corrections keep riding the
existing duplicate-then-merge flow (which already has merge preview + optimistic concurrency).

---

## DECISION D2 — Phone/name validation and uniqueness constraints

- **Name:** trim + 1-160 length cap already enforced server-side (zod). No uniqueness (correct —
  person identity is the phone). No further rules needed.
- **Phone (only if D1-C is approved):**
  - *Options:* (i) free-form like `secondaryPhone` today (≤40, no normalization — **not
    recommended**: breaks the E.164 invariant the whole phone stack assumes); (ii) full identity
    event — `normalizePhone()` mandatory on PATCH, invalid → 422 `INVALID_PHONE` (create-path
    parity), org-duplicate → 409/422 `LEAD_DUPLICATE_PHONE` carrying the conflicting lead id,
    `phoneRaw` re-captured alongside, `whatsapp` left untouched when explicitly set.
  - *Risks of (ii):* duplicate-pair engine must re-evaluate pairs on phone change; CONVERTED leads
    should lock phone edits (identity frozen post-conversion); dedup dismissals keyed on the old
    pair become stale.
  - *Compatibility:* additive validation on an existing field — no schema change; a phone-PATCH
    path does not exist today, so no caller breaks.
- **Recommendation:** if phone becomes editable, adopt (ii) and gate it **owner-of-record or
  MANAGER+ with a reason** (same gate family as `archived`) — a phone change is a re-identification
  of the person, not a routine edit.

---

## DECISION D3 — Required audit events for identity and other field changes

| Option | Trail behavior | Risk |
|---|---|---|
| **A** | Silent (today's law) — zero rows for every non-status/owner field | Governance regression the moment inline editing ships: name/email/phone edits invisible |
| **B** | Activity timeline entry only for identity fields (fullName/phone/email/secondaryPhone/whatsapp) with before/after in `meta` | Reps see edits in the drawer timeline; auditors do not get AuditLog rows |
| **C** | Activity + AuditLog `LEAD_PROFILE_CHANGED` (entityId set, before/after payload, transactional per the F-06 law) for identity fields; routine fields (notes/priority/score/budgets/location/type) stay silent or get a light Activity entry | One audit row per identity edit — bounded volume; no contract change (new action string only) |

**Recommendation:** **C for identity fields** (mirrors the `LEAD_STATUS_CHANGED`/`LEAD_ASSIGNED`
pattern already transactional in the same route); owner's call on whether routine fields get the
light B entry. The audit infrastructure (`logActivity`/`logAudit` inside the existing
`$transaction`) already supports this with zero new plumbing.

---

## DECISION D4 — Optimistic concurrency protection (stale-update guard)

| Option | Behavior | Risk / compatibility |
|---|---|---|
| **A** | None (today) — last-write-wins | Concurrent drawer edits silently clobber each other; on the 50×/day leads surface this is a realistic data-loss class |
| **B** | Optional `expectedUpdatedAt` → 409 `LEAD_STALE` (the visits §26 pattern: `api/visits/[id]/route.ts:148,164-165`) | Additive optional field — **backward-compatible**: callers that omit it (bulk-undo, copilot, mobile) behave exactly as today; the drawer opts in with its loaded `lead.updatedAt`. UX cost: a "modified by someone else — reload and retry" conflict state must be designed |
| **C** | Mandatory token on every PATCH | Breaking change — every caller must be updated; rejected unless the owner wants hard synchronization |

**Recommendation:** **B**, wired into the drawer's save path when Wave 2B is implemented, with a
dedicated conflict/reload state in the drawer UI. `Lead.updatedAt @updatedAt` already exists —
no schema change. Test additions if approved: matrix probes for 409-on-stale + 200-on-fresh +
no-token-passthrough.

---

## What Wave 2B implementation would require AFTER approval (preview, not started)

- Client: pencil-to-edit affordances in `lead-drawer-info.tsx` (+ the drawer's dead
  `body.priority` toast branch comes alive), field-level dirty state, failed-save disclosure.
- Server (only if D2/D3/D4 approved beyond "no change"): the corresponding validation/audit/guard
  additions inside the existing PATCH transaction.
- Tests: Wave-2B probe suite (additive, reported separately — the Wave-1/Wave-2 convention) +
  standing matrix re-run + drawer E2E incl. conflict path (if D4-B) + AR-RTL/mobile parity.
- Every option above that touches the PATCH contract is an **API change requiring the owner's
  separate approval** per the standing Phase-C gating law.

---

## ADDENDUM — the owner's approved direction (2026-10-25, UX-OWNER-PLAN-1)

The owner's decision-reconciliation directive resolved the brief's decision frame:

- **D1 → APPROVED-DIRECTION: the option-A field set ONLY** — email, secondaryPhone, whatsapp,
  priority, score, notes, budgetMin/budgetMax, propertyType, desiredLocation, nextFollowUpAt
  (all verified accepted by the PATCH zod contract, `src/app/api/leads/[id]/route.ts:125-146`).
  **`fullName` (option B) and the primary `phone` (option C) are EXCLUDED — name and phone remain
  outside the inline-editing scope.** D2's phone-validation work is therefore NOT needed (phone
  stays immutable; corrections keep riding duplicate-then-merge).
- **D3 → APPROVED-DIRECTION (partial):** identity-field changes allowed within the scope (email,
  secondaryPhone, whatsapp) MUST generate the formal audit record + timeline entry with before/after
  values. The per-field distinction for routine fields (the A/B/C granularity of the original D3)
  remains an open detail — questionnaire Q-file references it in the implementation spec (Phase D of
  `NEXT_PHASE_PLAN.md`), default recommendation: the D3-C pattern for identity fields.
- **D4 → APPROVED-DIRECTION: the option-B guard in principle** — an OPTIONAL expected-version token,
  backward-compatible for callers that omit it, with a clear conflict/reload experience when stale.
  Error-code/UX details are engineering-specifiable (409 `LEAD_STALE` recommended, the visits §26
  pattern + the Prisma official OCC pattern).

Status: the brief's BLOCKED banner is lifted to APPROVED-DIRECTION at the decision level; the
implementation spec (Phase D of `NEXT_PHASE_PLAN.md`) still requires no further owner input beyond
the recorded direction. Historical text above preserved verbatim (append-only law). The canonical
register: `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md`.
