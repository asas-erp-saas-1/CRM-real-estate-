# USER JOURNEYS — ASAS CRM

> **GOV-3 pointer (2026-10-19):** the consolidated workflow state diagrams now live in
> `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/WORKFLOW_SPECIFICATION.md` (the source of truth); this file keeps the UX persona
> framing. Factual drift fixed at the same stamp: the seeded org has **8 users** (6 sales/management
> + 2 field reps), and the targets panel was removed (D-025 — finance → ERP).

**Who uses ASAS and what they actually do.** Derived from the domain model
(`05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/DOMAIN_MODEL.md`), RBAC roles, seeded org structure (8 users) and
the Phase-2 audit workflows. Every UX stage must be justified against one of
these journeys (mandate §5/§16). Frequency = daily reps → prominence budget
(DESIGN_SYSTEM §6).

---

## Personas

| Persona | Role(s) in system | Session shape | Success metric |
|---|---|---|---|
| **Amine — sales rep** | SALES_AGENT | Opens CRM every morning, works leads all day in short bursts (between calls/visits); 50+ repeated micro-workflows daily | leads contacted, follow-ups kept, no missed visit |
| **Sarah — sales manager** | MANAGER | Morning pipeline review, assignments, weekly targets, coaching (audit trail) | team throughput, overdue kept near 0, forecast |
| **Karim — admin/director** | ADMIN/OWNER | Periodic: users, settings, data quality (import/audit), analytics | system trust, data hygiene |
| **Nadia — owner/director** | OWNER | Occasional analytics + high-level dashboard | pipeline + won revenue visibility |

Demo login surface (quick user switcher in sidebar) exists for role-verified QA —
use amine (agent view: no admin nav) and sarah (manager view) in UX validation.

## Journey 1 — Morning triage (Amine/Sarah, DAILY, highest frequency)

Dashboard → scan attention (uncontacted, overdue, today's tasks/visits) → click
overdue KPI → tasks view filtered → complete/reschedule → back to dashboard →
today panel: visit list → open visit context.

**UX requirements:** critical-first hierarchy (A6), KPI→view deep-links (exist),
today-panel tabs, zero ambiguity about what is urgent. Everything above the fold.
"Complete/reschedule" now runs IN the tasks view (P6-5 D-UX-010: checkbox +
CalendarClock postpone → tomorrow 09:00, existing PATCH contract) — no drawer
round-trip for the two daily micro-actions.

## Journey 2 — Lead response loop (Amine, DAILY ×many, THE core workflow)

New lead appears (assigned or unassigned queue) → open lead drawer → understand
context in seconds (source, budget, requirements, history) → call/WhatsApp →
log activity (+ outcome) → schedule follow-up → status moves forward.

**UX requirements:** drawer = coherent workspace (identity, status, owner, next
action, recent activity visible together — mandate §13); WhatsApp deep-link at
thumb; activity logging minimal fields; follow-up quick-create prefilled. Repeated
50×/day → every extra click is 50 clicks (mandate §16).

## Journey 3 — Pipeline hygiene (Sarah, daily/weekly)

Pipeline kanban → scan stalled opportunities (next action overdue) → stage-move
with facts (lost reason / closed-won data) → reassign if needed → check team
targets panel.

**UX requirements:** kanban card = value + name + next-action dominant, metadata
recessive (A10); terminal-stage dialogs clear; drag or menu stage moves.

## Journey 4 — Data intake (Sarah/Karim, weekly)

CSV export from source (Facebook/Ouedkniss) → import wizard (map → preview →
dedupe) → assign queue → correct duplicates.

**UX requirements:** 4-step wizard state clarity (extracted P5-5, verified);
undo safety; auto-map transparency; bulk assign afterwards.

## Journey 5 — Client history recall (Amine/Sarah, several×/day)

Before calling: open lead → timeline "what happened, when, who" → last outcome +
next commitment visible without scrolling the whole history.

**UX requirements:** timeline event types distinguishable without color-only cues
(mandate §14); notes/calls/status changes visually distinct; recency dominant.

## Journey 6 — Administration (Karim/Nadia, occasional)

Users & roles → org settings → audit journal for integrity questions.

**UX requirements:** calm low density; dangerous ops deliberate (ROLE_CEILING,
LAST_OWNER guards are invisible safety — UI must make consequences explicit);
audit journal searchable + human-readable.

---

## Friction inventory (from journeys × current UI — feeds stages)

| Friction | Journey | Stage |
|---|---|---|
| Dashboard: all KPIs equal weight → triage requires reading every card | 1 | 3 |
| Truncated KPI labels → re-read to decode | 1 | 3 |
| Rainbow icon chips → scanning noise | 1 | 3 |
| Lead drawer: context assembly requires tab visits (overview/activities) | 2 | 4 — **CLOSED P6-2** (D-UX-007: next-action band + activity preview + composer on the default tab, zero tab switches) |
| Table scan-slip in long lists (no channels) | 2/5 | 7 — **CLOSED P6-4 tables + P6-5 lists** (D-UX-009 zebra ladder; D-UX-010 div-row ladder + reserved-line time columns on tasks/visits) |
| Kanban next-action under-weighted | 3 | 5 — **CLOSED P6-3** (D-UX-008: action chip w/ amber overdue tint; hover lift removed) |
| Tasks/visits views: due time buried in metadata; reschedule missing; 3–4 labeled buttons per visit row | 1 | 6 — **CLOSED P6-5** (D-UX-010: time columns, postpone, one-label action hierarchy) |
| Timeline history: undifferentiated stream (no day boundaries, actor invisible in grey run); copilot summary under-weighted | 2 | 8 — **CLOSED P6-6** (D-UX-011: day-group chips, actor emphasis, system-vs-human weighting, copilot primary-content weight) |
| Timeline density + event-type cues | 5 | 8 |

## Non-journeys (explicitly out of UX scope)

Companies/teams (single-agency individuals market), in-app messaging/telephony
(WhatsApp deep-links are the cultural channel), push notifications (in-app only).
Do not design surfaces for them.
