# WAVE 3 — OWNER DECISION REQUESTS: COMMISSION BASIS & CLOSURE ECONOMICS GATE (2026-10-23)

**Status: BOTH BLOCKED — no implementation until the owner explicitly approves each decision below.**
This document is decision-support only (the Wave-2B brief convention, decisions D1–D4; these are D5–D6).
Nothing here changes any contract, schema, or financial semantics. Verified against HEAD `c86d6cb`
(worktree clean) after Wave 3A/3B landed. Per the standing law: *an existing code path is NOT proof
that the underlying financial rule has owner approval* — both current behaviors below predate any
recorded owner decision on their semantics.

---

## DECISION D5 — Commission calculation basis (the % derivation)

### Verified current behavior (file:line at HEAD)

| Surface | Verified fact |
|---|---|
| The §37/§38 law | **Amounts are manager-entered with a RECORDED free-text basis** — the trust machine's own header: "every amount carries a RECORDED calculation basis (never an invented rate/formula — amounts are manager-entered)" (`src/lib/server/reservation-trust.ts:7-8`); the schema repeats it: "no invented rates/formulas — §38's explicit law" (`prisma/schema.prisma:599-601`) |
| The manager UI | The amount input pairs with a basis input whose placeholder **asks HOW it was computed; "nothing is auto-calculated" is doctrine** (`deal-economics-manager.tsx:12-13`). The deal price (`reservation.amount`, nullable) sits in the same dialog — the manager hand-derives every amount |
| The basis fields | `commissionBasis` / `incentiveBasis` — free text ≤500, recorded in the §37/§38 audit payloads; NO structured rate, NO percentage anywhere in the schema |
| The verified ladder | EXPECTED → EARNED → RECEIVED with separate verified columns (never overwriting the agreed estimate); locked rows change only through the audited explicit rebase (`commissionBasis` rides the rebase audit) |
| Consequence today | The readiness review's BLOCKER finding stands: the highest-stakes screen demands hand-typed amounts + free-text basis with **zero % derivation from `reservation.amount`** — arithmetic errors are invisible, and no aggregate can later reconstruct "what rate was applied" |

### The decision

| Option | Content | Financial consequence | Compatibility |
|---|---|---|---|
| **A — authoritative % of the deal price** | The server computes `commissionAmount = rate × reservation.amount` (one canonical path in `reservation-trust.ts`); the manager enters (or overrides within a policy band) the RATE; the basis string becomes a structured `{rate}×{amount}` derivation echoed into the audit trail | Removes arithmetic error entirely; the rate becomes queryable/aggregatable; **changes §38's explicit "no invented rates/formulas" law** — the amount stops being the manager's statement and becomes the system's computation | Schema: additive structured basis (or reuse the text field with a structured prefix). Contract: the PATCH body gains an optional `commissionRate`; the rebase law must define whether a rate change auto-rebases (audited). The client cannot override the authoritative result (D-025 write gate unchanged) |
| **B — % helper, manual stays authoritative** | The UI suggests `rate × amount` as a prefill; the manager confirms/edits; the server stores what it is told (today's law, plus a recorded rate when used) | Arithmetic help without changing the trust law; errors remain possible (the helper is advisory); the rate is recorded only when the manager used it | Smallest change: client-side helper + an optional structured rate echo in the basis. No server trust-machine change; no contract change |
| **C — status quo** | Manual amounts + free-text basis (today) | The BLOCKER finding remains open: silent arithmetic-error class on the money surface | None |

**Recommendation:** **B first, A only with an explicit policy decision.** B delivers the error-reduction
without touching the §37/§38 trust laws; A is a governance change (the system becomes the rate's
source of truth — including what happens to historical rows and whether rate changes trigger the
audited rebase) that should not ride in through a UI wave. **C is not recommended** (the audit's
BLOCKER finding is real).

**Open sub-decision if A:** the canonical rate policy (fixed org rate? per-source DEVELOPER vs CLIENT
rates? per-project?), the override band, and whether historical amounts get re-derived or stay as
recorded facts.

---

## DECISION D6 — The deal-closure economics gate

### Verified current behavior (file:line at HEAD)

| Surface | Verified fact |
|---|---|
| The closure gate today | `validate_closure` converts reservation→CONVERTED + apartment→SOLD + opportunity→CLOSED_WON in ONE guarded transaction with **ZERO economics-completeness check** — `commissionAmount`/`agentIncentive` may both be null and the sale closes anyway (`reservation-lifecycle.ts:165-204`; the readiness review: "silent revenue leakage by design") |
| The two-step governance | The agent PREPARES (`request_closure`, evidence-gated) → a MANAGER VALIDATES (409-safe, idempotent, audited `SALE_VALIDATED`); rejection returns ACTIVE (reason-gated) — the two-manager closure governance the gate must NOT weaken |
| The economics surface | §37/§38 writes are a SEPARATE MANAGER+ surface (`reservation-economics.ts`) — the schema's own comment: "monetary writes are NEVER side effects — economics stay the separate §37/§38 MANAGER+ surface" (`prisma/schema.prisma:578-582`) |
| The client today | The closure dialog (`deal-economics-closure.tsx`) requests/validates with no incomplete-economics state; a manager can validate a sale whose commission fields were never entered, with no reminder, no flag, no audit trace of the omission |
| What is NOT missing | Authorization (MANAGER+ on validate), transactionality (F-06 proven — FR44a), audit (SALE_VALIDATED + APARTMENT_STATUS_CHANGED), concurrency (409-safe) — only the **economics-completeness rule** is absent |

### The decision

| Option | Content | Financial consequence | Compatibility |
|---|---|---|---|
| **A — hard block** | `validate_closure` rejects with 422 `INCOMPLETE_ECONOMICS` while `commissionAmount` (and/or `agentIncentive`) is null; the client surfaces an actionable "enter economics now" path; the UI is NOT the only enforcement layer (the server rejects) | Zero silent leakage post-adoption; **changes the closure contract** — every existing workflow that closes without economics (including any integration/scripted path) starts receiving 422s; historical CONVERTED rows with null economics are unaffected (the gate is forward-only) | Contract: a NEW 422 code + the exact required-fields list in the error payload; the lifecycle state machine gains a precondition (additive — no re-architecture); regression probes for both permitted and rejected transitions + the FR44 rollback set re-run |
| **B — warning + audited waive** | The validate UI warns when economics are incomplete; closing anyway requires an explicit waive (reason-gated, audited `SALE_VALIDATED` carrying `economicsWaived: true`) | Leakage becomes VISIBLE and attributed but not prevented; the org keeps closure speed for edge cases (e.g. commission terms pending with the developer) | Smaller contract change: an optional `waiveEconomics: true + reason` on the PATCH; the audit payload gains the waive fact; no hard failure for existing callers |
| **C — status quo** | No gate (today) | Silent leakage continues unmeasured | None |

**Recommendation:** **B**, then measure. The readiness review names this "a governance-semantics
choice, not a technical one": hard-blocking the org's ONLY sale-closure path on optional-pending
commission terms (developer contracts often settle rates later) risks stalling real closings — the
waive path keeps the flow while making every omission an explicit, audited management act. If the
waive rate turns out high after a period, **A** becomes the evidence-backed follow-up.

**Open sub-decision either way:** exactly WHICH fields constitute "complete economics"
(commissionAmount only? + commissionFrom? + agentIncentive? + the basis strings?), and whether the
agent's `request_closure` step also warns (the earlier the flag, the cheaper the fix).

---

## What implementation would require AFTER approval (preview, not started)

- **D5-B:** a prefill helper in `deal-economics-form-state.ts` (the round-5 extracted state machine)
  + an optional structured rate echo in the basis write; Wave-3-suite probes for the recorded rate
  round-trip + the D-025 agent-403 unchanged.
- **D5-A:** the canonical derivation inside `reservation-trust.ts` (server-authoritative), the rebase
  interaction defined, money-write matrix probes extended (rate × price → amount round-trip, override
  band, rebase escalation), F-06 rollback probe extension.
- **D6-A/B:** the gate inside `reservation-lifecycle.ts`'s `validate_closure` (the authoritative
  server path) + the actionable client state in `deal-economics-closure.tsx`; probes for permitted
  AND rejected transitions incl. unauthorized attempts; the FR44a-d rollback set re-run.
- Both touch the round-3/round-5 freshly decomposed modules — extend, never re-merge (the
  decomposition-first law).

**Owner decisions now open (cumulative):** #1 wave approvals/order · #2 Wave 2B scope (brief ready) ·
**#3 = D5 (this doc)** · **#4 = D6 (this doc)** · #5 demo-mode policy.

---

## ADDENDUM — the owner's approved directions (2026-10-25, UX-OWNER-PLAN-1)

The owner's decision-reconciliation directive resolved this document's two decisions at the
DIRECTION level (the canonical register: `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md`):

- **D5 → APPROVED-DIRECTION: option B's family** — a calculation helper with the manager able to
  confirm or edit the suggested result. **No authoritative commission percentage, rate table,
  calculation basis, or universal formula is approved** — the §37/§38 trust law stands (amounts
  remain manager statements with recorded bases). A commercial estimate stays distinct from an
  authoritative payable amount; accounting/payment/ERP remain outside the CRM. Remaining
  sub-decisions (input contract, rate optionality, suggested-vs-confirmed persistence, logging,
  visibility) = questionnaire **Q7** (`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_FORM.md`); the concrete
  proposal = `NEXT_PHASE_PLAN.md` §4.
- **D6 → APPROVED-DIRECTION: option B** — warn when required closure economics are incomplete, with
  an explicit, reason-gated, audited waiver. Completeness = commission amount + commission payer +
  representative incentive + written bases (`commissionBasis`/`incentiveBasis`, field names verified
  `prisma/schema.prisma:597-608`). An incentive not due = **recorded zero + written explanation**
  (zero is never proof of payment — paid remains the INCENTIVE_PAID status + paidAt). Remaining
  sub-decisions (exact validation/waiver semantics; whether request_closure also warns; the
  zero/not-applicable/waived/paid representations in the current schema) = questionnaire **Q8**;
  the concrete proposal = `NEXT_PHASE_PLAN.md` §5.

Historical text above preserved verbatim (append-only law). Implementation remains NOT started.

---

## ADDENDUM — the owner's D5/D6 detail answers (2026-10-26, UX-OWNER-PLAN-2)

The owner answered Q7 and Q8 (canonical record: `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md` §1a):

- **D5-DETAIL-Q7 (approved):** rate + calculation base = optional manual inputs; the result is a
  transient calculation suggestion, NOT automatically persisted; the manager confirms or edits the
  final amount; NO default rate, authoritative rate table, or unapproved formula; the basis is
  recorded when the amount is confirmed (existing canonical audit paths verified sufficient —
  COMMISSION_SET/INCENTIVE_SET carry before/after + decidedBy stamps); financial visibility
  restrictions preserved. The concrete design: `NEXT_PHASE_PLAN.md` v2 §4.
- **D6-DETAIL-Q8 (approved mechanism):** `request_closure` warns; `validate_closure` rejects with
  422 `INCOMPLETE_ECONOMICS` + an explicit missing-field list; an authorized manager may waive via
  `waiveEconomics` + a mandatory reason; the waiver is auditable (actor, time, reason, missing items);
  transaction safety, closure governance, idempotency, and trust constraints preserved. **One
  semantic remains OPEN (RQ-3):** zero vs not-applicable vs waived vs paid — the owner explicitly
  forbade assuming zero ≡ NA ≡ not-payable or waiver ≡ payment; the plan keeps ONLY the approved
  zero+written-explanation = not-due representation and returns the narrow question. The concrete
  design: `NEXT_PHASE_PLAN.md` v2 §5.

Historical text above preserved verbatim (append-only law). Implementation remains NOT started.
