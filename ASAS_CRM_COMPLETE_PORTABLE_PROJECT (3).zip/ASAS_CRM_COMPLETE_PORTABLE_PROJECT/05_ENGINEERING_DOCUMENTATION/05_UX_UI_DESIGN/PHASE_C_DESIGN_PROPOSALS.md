# PHASE C — DESIGN PROPOSALS COMPARISON PACKAGE (2026-10-21)

**ACCEPTANCE CLOSURE UPDATE (2026-10-22, closure session):** Wave 2A acceptance closure executed
and verified (worklog `UX-PHASE-C-W2C` + `download/qa-phasec-w2-closure/`): commits `3e9a551` +
`452d5a5` present at clean HEAD, the 22-probe suite re-run from the committed state **22/22 PASS**,
the undo's honest partial-failure reporting live-proven end-to-end (own lead restored / pool lead
refused — VLM-confirmed toast "1 restauré(s), 1 refusé(s) (droits insuffisants)"), the
pool-lead/manager restore limitation and the bulk status/assign-on-archived behavior documented
(authorization semantics unchanged), the entity baseline byte-exact, and scheduled job 470474
verified system-disabled at exec limits with zero executions. **Wave 2B now has its owner-decision
brief: `WAVE_2B_OWNER_DECISION_BRIEF.md`** (decisions D1-D4, each with options/risks/compatibility/
recommendation — still BLOCKED pending owner approval). **Wave 3 now has its readiness review:
`WAVE_3_READINESS_REVIEW.md`** (dependencies, affected files, security/privacy risks, test
requirements, engineering conflicts — proposals only).

**IMPLEMENTATION STATUS UPDATE (2026-10-22, Wave 2A session):** **Wave 2A is now IMPLEMENTED and
verified** (commits 3e9a551 + 452d5a5 — see worklog `UX-PHASE-C-W2` and `download/qa-phasec-w2/`):
the archive workflow completion (archived-records view toggle on the server's `archived=true`
contract, row-level + bulk restore gated owner-or-MANAGER, the GENUINE undo on the archive toast —
per-lead PATCH restores, honest partial-failure reporting, selection cleared on record-universe
switch), the hide-closed board toggle (the server's existing `open=true` filter wired; closed
columns leave and return with their records — filter-only hiding, nothing destroyed), the board
`total` wiring (the server's truthful count finally read; the KPI count exact past the 200-row cap
with hide-closed on; an amber truncation disclosure when `data.length < total` — live-proven with a
226-row fixture). **Wave 2B (L3 lead inline editing) remains BLOCKED** on owner decision #2 — its
server-side inspection is now DOCUMENTED in worklog `UX-PHASE-C-W2` §Wave-2B (fields accepted by
PATCH /api/leads/[id], validation rules, RBAC/ownership gates, audit expectations, the missing
conflict-guard vs the visits stale-guard pattern) so the owner decision can be made against facts.

**IMPLEMENTATION STATUS UPDATE (2026-10-21, later session):** **Wave 1 is now IMPLEMENTED and
verified** (commit 4fcb9fc + the test/evidence commit — see worklog `UX-PHASE-C-W1` and
`download/qa-phasec/`): workspace-state persistence (L2), the real task completion/reopen (L4), the
calendar P49/P50 wiring (L5), the create-opportunity terminal-stage contract block (L6), the
`onUpdated` live-patch wiring, sortable leads headers on the server-supported columns (incl. the
latent `nextFollowUp`→`nextFollowUpAt` sort bug found during implementation), the filter-popover text
debounce, the palette deep-link tokens, the calendar day-click prefill, and the demo-badge gating.
The L1 reserve-form fix was already landed by Phase A and re-verified. **Waves 2–4 remain
PROPOSALS ONLY** — each still requires its named owner decision before code (see the list at the
end of this document). L3 (lead inline editing) is Wave 2, gated on owner decision #2.

**Mandate:** UX Audit Validation & Phase A Execution §6 — "After Phase A, prepare a compact
comparison package for the six representative screens… For each screen, distinguish: existing
behavior that should remain · confirmed usability defects · visual inconsistencies · opportunities
for meaningful workflow improvement · proposed design changes that require owner approval."

**Status of this document (Waves 2–4):** PROPOSALS ONLY. Wave 1 is implemented (see the status
update above). Nothing in Waves 2–4 below is authorized for code changes without a separate owner
review of each proposal and its dependencies (mandate §6, final clause).

**Evidence base — stronger than the original audit's:**
1. `UI_REDESIGN_AUDIT.md` (commit b86e89e) — the surface/render-level audit: 30 captures,
   5 VLM reviews, DOM measurements. Its verdict ("mature, heavily-polished; radical rewrite
   NOT supported") graded the **presentation layer**.
2. **Phase A execution (this session)** — live interaction testing on top of the renders,
   plus three parallel code-level UX audits (worklog Task IDs 8-a/8-b/8-c) reading every view
   module end-to-end. Verdict: the presentation layer is genuinely strong (token discipline,
   RTL, a11y, states, truncation laws — all real), but the **workflow layer underneath it is
   thin**: ~45 code-cited defects, of which **6 were re-verified live this session** (below).
3. **The owner's standing position** — "impractical, outdated, incomplete" — is now
   evidence-backed at the interaction level, not just perception. The original audit's
   conclusion is *correct about paint and incomplete about plumbing*.

**Live-verified this session (agent-browser, interactive, non-destructive):**

| # | Finding | Live evidence | Where |
|---|---|---|---|
| L1 | Reserve-form cross-unit money contamination + dead price prefill | Lot N-01's typed `12 500 000` re-appeared in Lot N-02's reserve form; prefill initializer ran with `apartment=null` | properties-view.tsx:601 — **FIXED this session** (canonical key-remount) |
| L2 | View-switch / Back wipes the workspace | search `Merabet` (1 row) → Dashboard → back: 25 rows, empty search | leads-view.tsx:105-113, crm-app.tsx:81 |
| L3 | Lead identity immutable after creation | drawer exposes zero edit affordances for phone/email/name/source/priority (live DOM query: `editables: []`); server PATCH already accepts them | lead-drawer-info.tsx:207-225 |
| L4 | Fake done-task checkbox | click → zero network requests (handler is `() => {}`) | tasks-view.tsx:572-574 |
| L5 | Dead calendar filter toggles | P49 toggle in calendar mode fires the hidden list query (`awaitingReconfirm=1`) but the visible calendar's params never change | visits-view.tsx:275-288 |
| L6 | Create-opportunity terminal-stage dead path | stage «Perdue» selectable → submit → raw 422 toast "closedAt est requis…", form has no closedAt/lostReason fields | create-opportunity-dialog.tsx:198-203 |

---

## How to read the six screens

Each screen gets five sections (mandate §6). "KEEP" lists what the evidence says genuinely
works and should survive any redesign. "DEFECTS" are confirmed (live or code-cited
file:line). "PROPOSALS" are the design changes requiring owner approval, each tagged with
its engineering dependency and effort class (C = client-only · A = API change · S = schema).

---

## SCREEN 1 — Main dashboard (manager + agent variants)

**KEEP (evidence-backed):** the two-tier information hierarchy (attention strip → context
metrics) is the right morning-cockpit architecture; the 7-cell role-gated attention model
(data-contract gating, not client role checks); the journée panel as the rep's work queue;
skeletons + `placeholderData` anti-flash; the all-clear zero state; KPI count-up.

**CONFIRMED DEFECTS (P1, live + code):**
- Attention cells navigate but never isolate: 5 of 7 cells land on an UNFILTERED view
  (attention-strip.tsx:189-201). "Uncontacted: 12" opens a blank leads list — the filter
  model has no uncontacted/date facet to even reproduce the number manually (filters.tsx:19-27).
  The codebase's own "aggregate → isolate → act" doctrine is implemented for 2 cells only.
- KPI deep-links drop all context (kpi-card.tsx:131) — card number and landed list never
  reconcile.
- Dashboard range is not persisted nor shareable (resets to 30d every remount).
- Hard silent caps: hot opps `slice(0,4)`, source performance `slice(0,6)`, recent leads
  `slice(0,8)` with no "show more".
- The sidebar overdue badge fetches the FULL dashboard payload under a MISMATCHED query key
  (sidebar-nav.tsx:97-105 vs dashboard-view.tsx:55) — a second complete JSON transfer for
  one integer.
- Zero-value attention cells still occupy the strip (5 of 7 saying "0" remain clickable).

**VISUAL INCONSISTENCIES:** commissions-rail vs left-column height rhythm (UXA-5, P3,
unmeasured); activity chart sums all outreach types into one line (no type breakdown).

**WORKFLOW OPPORTUNITIES (proposals, owner approval):**
1. **Isolation tokens for every attention cell & KPI** — extend the existing
   `duplicatesToken` store pattern (store.ts:155-166) to leads/tasks/visits; requires new
   API facets (`uncontacted`, `lastContactBefore`, date windows). [A + C · high value]
2. **Clickable activity chart** — day-spike → filtered activity list. [A + C]
3. **Range persistence + URL sync.** [C]
4. **"Show all" affordances + sidebar badge fix** (query-key alignment or dedicated
   lightweight endpoint). [C / A]

---

## SCREEN 2 — Leads list + lead drawer (the 50×/day workspace)

**KEEP:** the saved-searches system (server-persisted, team-shareable — ahead of many SaaS);
debounced search; the j/k keyboard row navigation; bulk bar (assign/status/archive);
CSV export honoring filters; the dedup pair dialog (explainable rules, merge preview,
optimistic concurrency); WhatsApp/call per-row with auto activity logging; the drawer's
next-action band (quick-set follow-up, nearest-task CTA).

**CONFIRMED DEFECTS (P0/P1, live + code):**
- **P0 — workspace amnesia** (L2 above): filters/search/sort/page are component-local; any
  view switch or browser Back wipes them. Happens dozens of times/day.
- **P0 — no post-create lead editing** (L3 above): phone/email/name/source/priority are
  display-only in the UI; the ONLY path to correct a phone number is duplicate-then-merge.
  The server PATCH already accepts these fields ([id]/route.ts:101-109) — the feature is
  half-built, front-end missing; the `body.priority` toast branch is dead code.
- P1 — no column-header sorting; sort direction hard-wired (leads-view.tsx:200) — the
  triage-scan columns (lastContact, score) are unsortable.
- P1 — filter popover text facets fire a query PER KEYSTROKE (no debounce —
  filters.tsx:179-206).
- P1 — archived leads unreachable: API supports `archived=` (route.ts:82-83), UI never
  sends it; archive has no undo.
- P1 — drawer tab resets on every lead switch (`key={leadId}` remounts inner state); no
  next/prev lead navigation inside the drawer; j/k suppressed while sheet open — no
  keyboard processing loop exists.
- P2 — page size frozen at 25 (server accepts 100); no page numbers; no "clear filters"
  in the no-results dead end; native `<select>`s inside the filter popover (inconsistent
  with shadcn Selects everywhere else).
- P2 — two budgets can silently diverge (lead.budget vs requirements[0].budget in adjacent
  drawer sections); notes blur-save with no dirty indicator.
- Create dialog: duplicate rows are INERT (cannot click through to the existing lead);
  no "Save & new"; no default owner = me.

**VISUAL INCONSISTENCIES:** none material — the table/row/chip system holds.

**WORKFLOW OPPORTUNITIES (proposals, owner approval):**
1. **Lift list state to store/URL** (durable workspace). [C · highest single ROI in the
   product per the 8-a audit]
2. **Inline edit surface in the drawer** for identity fields (pencil-to-edit on the info
   grid; phone/name need a small schema addition, source/priority/budget server-ready).
   [C + S(name/phone) · closes the P0]
3. **Sortable column headers + direction toggle** (API already takes sort/dir). [C]
4. **Drawer next/prev + persistent tab + docked split-pane option** on ≥lg. [C]
5. **Archive toggle + undo toast**; debounce filter inputs; "Save & new" + clickable
   duplicate rows in create. [C]

---

## SCREEN 3 — Deal economics (reservation + closure) — the money screen

**KEEP:** the two-step closure state machine itself (evidence-gated request → second-manager
validation — correct governance); §37/§38 trust ladders with forward-only edges, locks and
audited rebase; the D-025 agent/manager visibility split; reservation documents; the
MoneyField + action-hierarchy fixes landed THIS session (UXA-1/2 — grouped money display,
one solid primary per state, rose destructive).

**CONFIRMED DEFECTS (BLOCKER→P1, code + live):**
- **BLOCKER (8-b) — zero value derivation:** the manager hand-types the commission amount
  AND a free-text "basis" explanation while the deal price sits in the same dialog
  ("nothing is auto-calculated" is doctrine, deal-economics-manager.tsx:14). A
  `% basis → computed amount` is trivially derivable; today the manager does arithmetic in
  their head on the highest-stakes screen.
- **BLOCKER — no totals anywhere:** no expected/earned/received commission sums across
  deals, no incentive payout ledger, no commission analytics (verified absent from
  /api/analytics). Management has no portfolio view of its own revenue.
- HIGH — closure and economics are unlinked: `validate_closure` proceeds with EMPTY
  commission fields forever — no reminder, no incomplete-economics flag. Silent revenue
  leakage by design.
- HIGH — the board truncates at 200 deals (server cap) while the summary bar's
  open/weighted/total math runs over the truncated array — the money numbers lie at scale
  (pipeline-view.tsx:47-50,126-131).
- HIGH — winning a deal is a 422-first dead end for agents (raw toast; the real
  `validate_closure` path is never surfaced at the failure point).
- MED — the money form is up to 11 conditional inputs (cognitive load of a tax form for
  what is usually "2.5% of 58M"); validation is a silently-disabled save button with no
  inline error text; evidence (1000 chars) is reviewed as one truncated line.

**VISUAL INCONSISTENCIES:** none remaining post-Phase-A on this surface (the 4 confirmed
P2s are fixed; UXA-4 measured clean).

**WORKFLOW OPPORTUNITIES (proposals, owner approval):**
1. **% basis field + auto-computed amount with editable override** (server echoes the
   derivation for the audit trail). [A + C · directly addresses the BLOCKER]
2. **Commission & incentive portfolio view** (analytics tab or dashboard rail: sums by
   trust state, payout ledger). [A + C]
3. **Closure gate: "economics entered or explicitly waived"** on validate_closure. [A]
4. **Board `total` wiring + truncation warning; hide-closed toggle + restore action**
   (server filters already exist, unwired). [C]
5. **Money stepper redesign:** EXPECTED→EARNED→RECEIVED as a visual timeline instead of
   conditionally-appearing inputs. [C]

---

## SCREEN 4 — Property inventory + matching

**KEEP:** the orphan-holds owner-decision queue (good pattern); the demand panel's fit-tier
match cards with reason chips; field-team assignment panel; inventory bars on project cards;
the reserve/visit lifecycle wiring from the lot itself.

**CONFIRMED DEFECTS:**
- ~~CRITICAL — stale reserve-form state across units~~ **FIXED this session (L1)** —
  canonical key-remount; price prefill now works; cross-unit contamination gone
  (live-verified).
- HIGH — `onUpdated` live-patch prop exists but is unwired by both callers
  (properties-view.tsx:601-604, orphan-holds-card.tsx:375) — status/price edits leave the
  open dialog rendering STALE data.
- HIGH — drill depth: full unit facts = project → building tab → card → dialog (3-4
  clicks); no table view, NO sort control at all, no surface/bedrooms/floor filters, price
  filters are raw number inputs (40 lines from the MoneyField that exists).
- MED — reserve picker fetches opportunities unpaginated (client-side stage filter —
  silently misses deals past page 1); flat mode hard-caps 200; demand-panel reason chips
  cap at 4 with untranslated raw-enum fallback; unassign has NO confirm while releasing a
  hold does (inverted safety asymmetry).

**VISUAL INCONSISTENCIES:** price-filter inputs vs MoneyField styling 40 lines apart.

**WORKFLOW OPPORTUNITIES (proposals, owner approval):**
1. **Unit table view** with sortable columns + saved layout (apartments API needs `?sort=`).
   [A + C]
2. **Wire `onUpdated`** (2 call sites — stale-data class killed). [C · trivial]
3. **Availability timeline per building/project** (expiry countdowns surfaced at rail
   level — data already in schema). [C]
4. **Property print sheet** (clone the visit-fiche pattern) + WhatsApp share of a unit.
   [C]
5. **Map/gallery views** — Phase-D material (needs media/geo foundations). [S + C]

---

## SCREEN 5 — Visits (list + calendar)

**KEEP:** the decision vocabulary (confirm-on-place / refuse / counter-propose with reasons,
viewer-CanConfirm derivations — genuinely strong); the P49/P50 isolation toggles IN LIST
MODE; the printable fiche; keyed lifecycle dialogs; stale-guard `expectedUpdatedAt` on every
PATCH.

**CONFIRMED DEFECTS:**
- HIGH — **dead toggles in calendar mode** (L5 above): P49/P50 buttons render and re-style
  as active but the calendar query never receives them.
- HIGH — scheduling is a blind 7-field form: no agent-conflict/availability check, no slot
  suggestions, lead combobox caps at 100 with no server search (can't find lead #101),
  unit picker caps 20/100, default slot today+2@11:00 hardcoded.
- MED — no drag-to-reschedule; clicking an empty calendar day does not prefill the schedule
  form with that date; calendar rows are a 260-line near-twin of VisitRow (already
  diverging in button styling).
- LOW — confirm dialog silently defaults time to 11:00 when cleared.

**VISUAL INCONSISTENCIES:** the calendar-row vs list-row twin drift (button styles).

**WORKFLOW OPPORTUNITIES (proposals, owner approval):**
1. **Pass P49/P50 into the calendar query** (params builder exists — 2-line fix class).
   [C · trivial]
2. **Day-click → prefilled schedule form** (date you're staring at pre-fills). [C]
3. **Agent availability probe** (conflict badge on slots — `GET /api/visits?agentId&from&to`
   exists). [C]
4. **Drag-to-reschedule** (PATCH exists; needs DnD wiring). [C]
5. **WhatsApp visit confirmation to the client + .ics export** (templates exist for
   outreach; needs a visit-confirmation template + ics lib). [A + C]

---

## SCREEN 6 — Role navigation + mobile

**KEEP:** the role-gated nav (verified ×5 roles); hash routing; density toggle; the login
overlay's multi-language pre-auth switcher; mobile card layouts (scrollWidth exactly 390 —
no horizontal overflow, re-verified this session on the money dialog).

**CONFIRMED DEFECTS:**
- P1 — command palette dead-ends for 3 of 6 entity types: projects/apartments/developers
  collapse to `setView("properties")` with NO selection (search-command.tsx:315-366) —
  search "Hydra", click, land on an unfiltered list, re-find by hand.
- P2 — one-click user impersonation in the production shell (no-password
  `POST /api/auth/login {userId}` — a dev fixture shipping in the product surface;
  demo password badge rendered on the login card with no demo-mode gate).
- P2 — no keyboard nav for views (no g+letter / n-for-new); browser Back never restores
  workspace state (single-route zustand, see L2).
- P2 — deal/opportunity URLs don't exist (hash covers view + leadId only) — unshareable
  deals in a sales org.

**WORKFLOW OPPORTUNITIES (proposals, owner approval):**
1. **Palette deep-link tokens** for all entities (pattern exists). [C]
2. **Gate demo/quick-login behind ASAS_DEMO_MODE** (env exists, server already fail-closes
   quick-login when disabled — the login overlay just never hides the grid). [C]
3. **URL state for views + selections** (shareable workspace). [C]

---

## Implementation sequencing recommendation (for the owner's decision)

The 8-a/8-b/8-c audits converge on one sequencing law: **fix the interaction fundamentals
before any visual pass.** Concretely:

- **Wave 1 (client-only, no API):** workspace-state persistence (L2), sortable headers,
  filter debounces, `onUpdated` wiring, calendar toggle fix, day-click prefill, palette
  tokens, demo-mode gating. Highest ROI-per-effort in the entire package; nothing here
  touches contracts.
- **Wave 2 (half-built features — finish them):** lead inline editing (server ready),
  archive toggle + undo, hide-closed board + restore, board `total` wiring.
- **Wave 3 (API extensions):** attention-cell isolation facets, % basis derivation,
  commission portfolio totals, closure-economics gate, unit table sort.
- **Wave 4 (visual/high-fidelity):** the six-screen design passes inside the existing token
  system — NOW meaningful because the workflows underneath will actually support them.

**The honest bottom line for the owner:** the original audit was right that the paint is
good and wrong to stop there. What makes the product FEEL impractical is not its visuals —
it is six verifiable interaction fundamentals (workspace amnesia, immutable records, dead
controls, blind scheduling, un-derived money, un-isolated metrics) that no amount of visual
refinement can compensate for. Waves 1-2 above are mostly client-side, carry no contract
risk, and would move the product from "polished shell" to "practical instrument". Phase C's
high-fidelity visual passes should ride AFTER those waves, not before.

**Unresolved owner decisions required before Phase C code:**
1. Approve/reject each Wave (1-4) and their order.
2. The lead-editing scope (which identity fields become editable; phone/name schema add).
3. The % basis derivation model (auto-compute with override vs keep manual + validation).
4. The closure-economics gate (hard block vs warning banner on validate_closure).
5. Demo-mode gating policy (hide quick-login entirely in production?).
