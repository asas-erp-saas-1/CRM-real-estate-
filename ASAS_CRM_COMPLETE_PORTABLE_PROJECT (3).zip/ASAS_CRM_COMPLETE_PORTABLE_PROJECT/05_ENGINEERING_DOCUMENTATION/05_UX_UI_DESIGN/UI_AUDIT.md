# UI AUDIT — Phase 6 Stage 1 (current-state)

**Evidence base (2026-10-04, karim/ADMIN, 1440×900 FR, light+dark):**
`download/qa-p6/audit-0{1..5}-*.png` · VLM design review (glm-5v-turbo) ×3 ·
code inspection (`src/components/crm/**`, `globals.css`) · prior Phase-2 audit
(`UX_FINDINGS.md` — B1–B7 all closed Phase 4; kept as history).

Verdict up front: **the foundation is strong** — coherent ADR-007 token system
(warm neutrals, emerald primary, theme-invariant charcoal sidebar), real RTL
mirroring, dense table primitives, sticky headers, loading/empty/error states,
zero console errors. Phase 6 is therefore a **restraint + rhythm + hierarchy**
program, not a rescue.

**Stage progress:** A1–A6 + A11 landed P6-1 (D-UX-001..004) · A8 landed P6-1b
(D-UX-006) · journey-2 drawer friction closed P6-2 (D-UX-007) · A10 landed
P6-3 (D-UX-008) · **A7 landed P6-4 (D-UX-009 — zebra channels + state ladder)** —
ALL audit findings closed · Stage 8 landed P6-6 (D-UX-011 — timeline day anatomy + copilot weight) · Stage 6 landed P6-5 (D-UX-010 — div-row ladder +
time columns + action hierarchy on tasks/visits; SCHEDULED sky→violet palette
compliance; twMerge custom-utility hazard found + systemically fixed) ·
Stage 9 landed P6-7 (D-UX-012 — settings calm: neutral chips, flat progress
tones + twin fix, 24px rhythm, slider-thumb a11y names, team-section
extraction) · Stage 10 landed P6-8 (D-UX-013 — hit-area floor .crm-hit ×15
sites, bidi isolation dir=ltr for email/audit-chips, Send+LogOut RTL mirrors,
bell badge logical side, login LangSwitcher + html-dir sync pre-auth-gate,
3 legacy sub-10px retired).

---

## A. Code-level findings

| # | Finding | Evidence | Severity | Stage |
|---|---|---|---|---|
| A1 | **No named type scale** — 520 ad-hoc `text-[Npx]` across crm/: 13px×210, 11px×155, 10px×82, 12px×62, 9px×6, 15px×5, 8px×2 (9 distinct sizes) | `rg text-[..px]` counts | High | 1 |
| A2 | KPI card label/hint `truncate` → **mid-word cuts** in French ("Taux de conver…") — reads as a dev placeholder, breaks semantics | kpi-card.tsx L203-204 + screenshot | High | 3 |
| A3 | KPI card = **5-hue rainbow per row** (amber/rose/teal/violet/emerald pastel icon chips + top accent bars + corner glows) × 2 rows = 10 competing colors | kpi-card.tsx `tone`/`accent` defs | High | 3 |
| A4 | KPI card: 4 text sizes in one card (24px number, 13px label, 11px hint, 10px caption) — number-to-label imbalance; labels "afterthought" | VLM audit + code | Medium | 3 |
| A5 | Decorative elements violating mandate §4: corner `blur-xl` glow, hover `-translate-y-0.5` lift (moving targets), pulse dots on non-critical live caption | kpi-card.tsx L183-188, L234 | Medium | 3 |
| A6 | Flat KPI hierarchy: all 10 cards identical visual weight; critical-action cards (Suivis en retard, Non contactés) not visually prioritized vs informational (Gains, Taux) | VLM audit | High | 3 |
| A7 | Table rows separated by 1px border only — eye "slipping" risk in high-density scan (no channel guidance) | VLM leads audit + crm-td | Medium | **DONE P6-4 (D-UX-009)** |
| A8 | Name column in leads table lacks weight contrast vs email/phone metadata | VLM leads audit | Medium | 7 |
| A9 | All-caps 11px column headers (`NOM`, `TÉLÉPHONE`) — VLM suggests title-case; **kept uppercase** (dense-enterprise convention, consistent, FR-legible) — see D-UX-002 | VLM leads audit | Decision | — |
| A10 | Kanban "next action" equal visual weight to address/type metadata | VLM pipeline audit | Medium | **DONE P6-3 (D-UX-008)** |
| A11 | Dark mode: card-vs-background contrast low → "card fade"/muddy grid (bg 0.17 vs card 0.22 in oklch ≈ only 5 steps) | VLM dark audit + tokens | Medium | 1–11 scope |

## B. Strengths to preserve (do NOT regress)

- Dark charcoal sidebar rail (theme-invariant) with sectioned nav, overdue badge,
  role-filtered items, user card with session switcher — calm and professional.
- Sticky topbar with view icon + title + subtitle, ⌘K search trigger, notifications,
  quick create — correct IA (mandate §35: never "where am I?").
- Footer status bar pinned via `mt-auto` in `min-h-screen flex` (layout rule) + DB health dot.
- Dense table primitives (`crm-th`/`crm-td`/sticky/scroll-fade), clickable-row inset
  accent bar with selected state, focus-visible outlines.
- `states.tsx` loading/empty/error + react-query placeholders; toasts; AlertDialog confirms.
- RTL: logical properties, directional icon mirroring, `.ltr-token` isolation, Arabic font stack.
- i18n completeness (3 dicts), tabular-nums for data.

## C. VLM review digest (full transcripts: session P6-1)

1. **Dashboard light**: flat hierarchy syndrome (all KPI equal weight); rainbow icon
   pastels; number/label scale imbalance; truncated labels; weak range-tab active state.
2. **Leads**: no horizontal "channels" (zebra) for row tracking; name contrast weak;
   status-badge saturation competes with primary button; checkbox hit areas small.
3. **Pipeline + dark**: next-action under-weighted on cards; dark card-vs-bg contrast
   low; badge system inconsistency (text chips vs dots vs pills across views);
   kanban column headers improvable.
4. **Lead drawer (P6-2 post-change re-review, glm-5v-turbo)**: accepted finding —
   band values needed weight distinction vs info-grid values (fixed: 500 vs 400,
   D-UX-007). REJECTED with reasons: "Aperçu does too much" (static facts live in
   the grid ABOVE the tabs; ordering is journey-driven, mandate §13/§16);
   "composer ambiguity" (it is the SAME proven timeline component — restyling
   would fork the one-system law); "phone looks raw" (deliberate DZ display format
   + mono `.ltr-token`); "notes vs budget imbalance" (textarea rows=2 by design,
   values truncate). Deferred: copilot-card visual weight → Stage 8 queue.
5. **Pipeline cards (P6-3 post-change re-review, glm-5v-turbo)**: accepted —
   chip truncation (→ line-clamp-2) + floaty column headers (→ border-b
   hairline). REJECTED with evidence: "probability bar missing" (42
   `[role=progressbar]` render at 216px — VLM misread the 4px bar); "owner
   metadata fails AA" (muted-foreground ≈ 4.6:1 on white — passes); "overdue
   icon stays grey" (svg = currentColor, inherits amber-700).
6. **Tasks + visits views (P6-5 BEFORE review, glm-5v-turbo)**: accepted —
   date/time buried in wrapped metadata (→ fixed-width reserved-line time
   columns); priority dots on every row (→ HIGH/URGENT only); 3–4 labeled
   buttons per visit row (→ one labeled primary + icon secondaries);
   SCHEDULED=sky blue (→ violet, palette compliance). REJECTED: "remove green
   Confirmée fill" (status tint IS the one badge system §7); "icon needs hover
   affordance" (informational, aria-hidden); "codes into subtitle" (mono
   .ltr-token chips are the inventory convention); "bigger group headers"
   (micro-label convention D-UX-002/A9).
7. **Tasks + visits AFTER re-review (P6-5, glm-5v-turbo)**: all 6 claims
   verified CORRECT (time column, zebra, priority dots, one-label hierarchy,
   violet badges, 600 titles); verdict "ABOVE THE BAR" vs typical enterprise
   lists. Residual findings rejected with evidence: "solid row primary"
   (violates ONE-primary-per-screen §7); "first-row time 1px higher"
   (measured 17 vs 16 = 16.5px line-height rounding); "zebra resets at
   headers" (VLM itself: standard pattern, acceptable).

8. **Timeline + copilot card (P6-6 BEFORE review, glm-5v-turbo)**: accepted —
   temporal anchors absent (no day grouping — finding "yesterday" requires
   parsing N relative timestamps); metadata homogeneity (type · actor · time in
   one undifferentiated grey run); dot/glyph legibility at 16/10px; copilot CTA
   weight imbalance; cramped vertical rhythm (partial — gap-y 0.5→1, mt 0.5→1).
   Rejected: composer send-button size (32px = matches input h-8);
   score-bar contrast (track deliberately quiet, numeric label + aria present);
   empty-state hint (copy already sets expectations); status badge size
   (app-wide STATUS_BADGE convention, not this surface's to fork).

9. **Timeline + copilot AFTER re-review (P6-6, glm-5v-turbo)**: 8/8 specific
   changes CONFIRMED (day chips, actor emphasis, system-vs-human, dot size,
   summary weight, no gradients, ≥10px badges, overall calm). Residual findings
   rejected with reasons: preview/history split (deliberate D-UX-007
   architecture); copilot actions not in timeline (immutable records vs
   payload actions); "Copilote IA" title+type repetition (one-system uniform
   rendering); HOT badge vs CONVERTED (temperature = data, hue means it);
   no collapse-back (tab strip is the pattern). Full ADR: D-UX-011.

10. **Settings surfaces (P6-7 BEFORE review, glm-5v-turbo)**: accepted —
    icon-chip color noise (5-hue rainbow on sliders + 9 hues screen-wide);
    brand color on metadata value chips/total badge; "Vous" badge brightness
    (and 9px size found in code); sticky save-bar weight/shadow-lg. Rejected:
    toggle inconsistency on self row (disabled = self-lockout protection);
    header contrast (crm-th convention, A9); hint ragged wrap (labels wrap by
    rule). Code-found beyond VLM: progress-bar glow + gradient (settings AND
    dashboard twin), 400ms motion, 9px role badges, ad-hoc text strays,
    16px rhythm on a 24px-cal surface, nameless slider thumbs (a11y).

11. **Settings AFTER re-review (P6-7, glm-5v-turbo)**: 5/6 claims CONFIRMED
    (neutral value chips, Vous badge, shadow-free sticky bar, 24px rhythm,
    semantic hierarchy). The INCORRECT verdict on "icon chips" misread
    role-toned AVATARS (identity convention) — DOM measurement: 16 icon chips
    render exactly 2 unique colors (muted + row tint). Residuals rejected
    with measurements: avatar colors (identity), toggle self-row (security),
    icon alignment (centers exactly equal, Y=-696), total badge contrast
    (computed 5.27:1 = AA pass), card separators (hairline + 24px gaps).

## D. Stage-1 scope decision (mandate §44: smallest correct increments)

This cycle fixes the **foundation + highest-visibility surface**:
semantic type tokens (A1) → KPI card restraint redesign (A2–A6: truncation, hierarchy,
unified icon treatment, calm hover, primary/secondary distinction) → dark-card lift
token refinement (A11 — one oklch step). A7/A8/A10 land in their stage (7/5) per the
stage program. A9 is settled as a logged decision (keep uppercase headers).

## E. Validation protocol for every UX change

1. `bun run lint` + `bunx tsc --noEmit` (0 errors src/).
2. Dev server: `GET /` 200, no new dev.log errors.
3. agent-browser E2E on the changed surface + cross-view smoke (9-view sweep when
   shell-level): render, interact, `window.__errs` === 0.
4. **UI ≡ API**: rendered values equal `curl` values (no data-flow regressions).
5. VLM re-review of the changed surface against this audit's own findings.
6. Light + dark screenshots archived to `download/qa-p6/` (before/after naming).

12. **Stage 10 BEFORE (P6-8)**: DOM-measurement recon (9 views × fr/ar ×
    390/1280 + Tab walks) — the a11y baseline was already strong (0
    nameless interactives, 0 overflow, landmarks, focus rings, DOM-order
    tab sequence; Phase 1–9 naming work banked). Defects found by
    measurement: touch targets 16–36px on high-frequency controls
    (checkboxes 16×16, lead links 18–20px, kanban open 24×24, icon actions
    32×32, switches 32×18, month nav 28×28, topbar 36×36); 10 visible
    Latin tokens without isolation in AR (9 leads-table emails + audit
    diff-chips — VLM quoted `karim@asas.dz -- :email`, ISO dates with
    jumping colons); Send + LogOut unmirrored in RTL; bell badge physical
    `-right`; login surface offered no language switch; 3 legacy sub-10px
    text sites.

13. **Stage 10 AFTER re-review (P6-8, glm-5v-turbo)**: leads AR **PASS**
    (emails "clean single LTR tokens... no longer broken up or scrambled");
    login AR desktop + mobile **PASS** (switcher visible, ع active emerald,
    RTL labels/icons correct, no clipping/contrast). Audit view "FAIL"
    verdict REJECTED with 3-level measurement: computed style
    (dir:ltr + unicode-bidi:isolate on 124 chips), DOM order, and pixel
    order all match (`email: — → karim@asas.dz`) — the VLM misread the
    em-dash null-placeholder + arrow as a scrambled separator. Hit-area
    expansion verified by elementFromPoint physics (±12px probes in, +22px
    out) — invisible to screenshots by design.

14. **Stage 11 BEFORE review (P6-9, z-ai vision)**: 7 images. Confirmed
    all six sky-* sites (VLM quoted "Nouveau" ×9 leads chips, the
    "Qualifié" dialog chip + 15% box, 3 info notification dots + icon
    chip, audit "Document déposé"/"Statut du prospect modifié" chips)
    plus the targets ring gradient stroke and — via code inspection
    against the codified D-UX-011 convention — the AnalysisCard
    `bg-gradient-to-b from-primary/[0.06]` twin that P6-6 had fixed only
    in lead-copilot-card. Rejected with lab measurements: primary CTA
    "vibrant blue" (lab 37.4 −29.9 11.8 = dark emerald), teal role
    avatars, teal live dot, muted grays. E2E to reach the documents tab
    exposed a functional defect: the drawer tab bar measured 1px tall
    (flex-shrink collapse) with TabsContent painting over the dead
    triggers — `elementFromPoint` hit the overview facts grid at the
    Documents tab's center.

15. **Stage 11 AFTER re-review (P6-9)**: 5/6 PASS — ring "single flat
    Amber... no gradient"; notifications icons/dots "neutral
    gray/slate... no blue"; "Qualifiée" badge + 15% box "pale green...
    correctly uses the brand green"; audit LEAD badges "neutral outline
    badges... no filled background"; analysis card "flat pale green/mint
    tint... no gradient fade". The leads-table "FAIL" (chips called
    "blue-50/blue-700") REJECTED with computed chroma: bg lab(96.29
    −0.85 −2.47) / text lab(35.56 −1.75 −15.43) = slate-100/slate-600
    at roughly one-third the BEFORE sky chroma (−2.34 −4.13 /
    −9.11 −42.56) — the known slate-as-cool-neutral misread. Functional
    fix verified: tab wrapper 1px → 41px, Documents tab switches in LTR
    and RTL, upload form + preview dialog + validate mutation all
    reachable. DOM sky-sweep across the live app: 0 elements.
