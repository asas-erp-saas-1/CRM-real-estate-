# AS CRM — Visual Improvement Plan (Universal UI System)

> **Status:** IMPLEMENTED — Phase 9 complete (P9.1–P9.10, 2026-10-08).
> Decisions D-UX-026 → D-UX-035 in `UX_DECISION_LOG.md`; QA baseline in
> `UI_QA.md`; stage table in `UX_MASTER_PLAN.md`.
> **Method:** 24 screenshot captures of every platform surface (FR/AR, light/dark,
> mobile/desktop — `download/qa-p8/audit/01..24-*.png`) → VLM gap analysis against
> the §51 reference grammar (Salesforce Lightning 2 / HubSpot / Linear / Stripe —
> design language only, never copies) → online research (Lightning 2 "Cosmos"
> refresh, Stripe token/typography analysis, Linear gray-ladder discipline,
> Attio, design-token & cmdk patterns) → this plan.
> **Doctrine:** §53 — NO blind redesign. Every change below maps to an evidenced
> gap, lands incrementally, and ships behind the existing quality gates
> (lint/tsc/E2E/VLM/AR-RTL/dark/mobile). Nothing breaks to look different.
> **Owner doc hierarchy:** this plan feeds `UX_MASTER_PLAN.md` (stage table),
> decisions land in `UX_DECISION_LOG.md` as D-UX-02x, evidence in `download/qa-p8/`.

---

## 1. Where we stand (evidence-backed)

The platform is functionally complete and visually coherent (warm-paper neutrals,
deep-emerald primary, OKLCH tokens, Geist type, CRM type ladder, zebra lists,
sticky group bands, status-tone badge families). The 24-capture audit + VLM gap
pass against the premium reference bar surfaced six recurring themes:

| # | Gap (VLM + audit evidence) | Surfaces | Severity |
|---|---|---|---|
| G1 | **Typographic hierarchy leaks** — names and metadata carry near-identical weight; mixed uppercase micro-labels vs field values ("PROCHAIN SUIVI" vs values) | dashboard, leads, drawer | high |
| G2 | **Status/attention semantics under-used** — some indicators read monochromatic ("Nouveau", "Normale"); semantic ramps exist but aren't applied everywhere a state exists | leads, dashboard, pipeline | high |
| G3 | **Vertical rhythm drift** — toolbar→table, card→header paddings vary by surface; no enforced 4/8px baseline audit | all list surfaces | med |
| G4 | **Row tactility flat** — hover exists (`.crm-list-row:hover`) but no elevation/leading-edge affordance on non-lead rows; selection states vary | tasks, visits, audit | med |
| G5 | **In-row data visualization sparse** — budget strings ("13M DA – 17M DA") stay text; no in-row meters/sparkline for pipeline health | leads, pipeline, analytics | med |
| G6 | **Primary-action prominence** — "Nouveau prospect" competes with filters; per-context quick-create missing (global lead CTA inside Tasks view — D-UX-021 deferred finding) | tasks, visits, inventory | med |

Rejected-as-wrong VLM claims (verification-first discipline): leads rows DO
hover (`crm-list-row:hover` — muted wash); LeadStatusBadge IS a tone family;
priority "Normale" is deliberately neutral (priority ≠ status). The plan fixes
the *system*, not phantom bugs.

---

## 2. Colors — refine the identity, don't replace it

**Principle (Lightning 2 / Stripe):** neutrals carry 90% of the surface;
semantic color is *information*, never decoration. One primary. One attention
amber. Status ramps only where a state exists.

### 2.1 Keep (the identity)
- Warm paper background `oklch(0.985 0.003 85)` + near-black warm foreground —
  our differentiator vs every blue/gray template; **do not touch**.
- Deep emerald primary (0.45/0.09/160 light, 0.55 dark) — brand carrier.
- Amber highlight (0.72/0.15/70) restricted to highlights.
- Rose destructive, emerald success, amber warning, violet rescheduled —
  the existing status vocabulary.

### 2.2 Refine (token-level, small diffs)
1. **Neutral ladder consolidation** — audit all `muted` usages into a 5-step
   named ladder (`--tone-1..5`: page→card→band→row→hover) so surfaces stop
   hand-picking `/30 /40 /45 /60 /70` opacities (G3). Ship as CSS vars +
   documented mapping; components migrate one surface per PR.
2. **Attention tiers become tokens** — `--attn-1` (destructive/overdue rose),
   `--attn-2` (warning amber), `--attn-3` (info primary) with fixed fg/bg/line
   per tier per mode. Today's scattered `rose-50/95`, `rose-100`, `rose-600`
   inline classes consolidate (overdue band, aging chips, NO_SHOW rows, audit
   diff chips — one source).
3. **Status badge ramp completion** — every enum with a UI state gets a tone:
   lead status (Nouveau gets the pale-primary treatment, not generic gray),
   visit status (exists), task priority (Normale stays neutral by design,
   Haute=rose, Moyenne=amber-outline), opportunity stage probability ramp
   (exists on pipeline; extend to drawer opportunity cards).
4. **Dark-mode parity pass** — each new token defined in BOTH modes with the
   oklch lightness flipped ~0.45→0.6; VLM-verified side-by-side (the P8-10
   lesson: verify perceptually, not just "defined").
5. **Chart palette (analytics)** — 6-color categorical ramp derived from the
   brand hues (emerald, amber, violet, rose, teal, stone) with a fixed order so
   "same series = same color" across every chart (predictability).

### 2.3 Explicitly NOT doing
- No new brand hues, no gradients, no glassmorphism, no blue/indigo anywhere,
  no per-surface ad-hoc tints (whitespace-over-borders language stays).

---

## 3. Icons — one family, one weight, one vocabulary

**Research:** every credible system (Lightning, Lucide-based shadcn ecosystems)
says: pick one set and commit; consistency beats novelty.

1. **Family:** stay 100% Lucide (already ~95% of the app). Zero mixing.
2. **Stroke discipline:** default `1.75` (current de-facto via size classes) —
   formalize: `size-3.5 = caption glyphs`, `size-4 = body/controls`,
   `size-5 = empty-state/hero`. No other sizes without a D-UX decision.
3. **Per-domain vocabulary registry** (extends the existing shared
   `TASK_TYPE_ICON` pattern): one exported `Record<Enum, LucideIcon>` per domain
   — task types (exists), activity types (exists), visit status actions, entity
   glyphs (lead=User, project=Building, unit=DoorOpen, payment=Banknote,
   document=FileText) — consumed by nav, palette, timeline, and empty states so
   the same concept always wears the same glyph (G2, G6).
4. **Icon+label rule:** icons never travel alone except established idioms
   (row action buttons) — aria-label mandatory (already enforced; keep).
5. **Emoji ban:** replace any residual decorative emoji in copy (FR/AR micro
   copy audit) with Lucide glyphs.

---

## 4. Typography — trust the ladder, enforce it

**Research:** Stripe = one typeface, tight scale, light display weights;
Lightning 2 = bold-when-scannable; Linear = micro-caps section labels +
tabular numerals. We already run Geist Sans/Mono + Noto Sans Arabic (AR) and a
CRM ladder (`text-crm-page/section/body/caption/micro`, `num`, `num-xl`).

1. **Font: KEEP Geist** (Sans + Mono). It is Inter-class (x-height, tabular
   figures, variable weights), already loaded via next/font with zero layout
   shift, and pairs with Noto Sans Arabic for AR. No font swap — swapping is
   template thinking; the *enforcement* is what we're missing.
2. **Enforcement layer (G1):** a one-time audit + lint-style rule —
   page titles = `text-crm-page` 600; record names = 600 body; metadata =
   `caption` muted; micro-labels = `micro` uppercase tracking-wide muted.
   The VLM finding (names ≈ metadata weight) dies here: the fix is weight +
   color discipline, not new sizes.
3. **Numerals:** every numeric cell (amounts, scores, counts, times, areas)
   gets `tabular-nums` + Geist Mono for IDs/codes (Lot codes, phone numbers) —
   mixed usage today; normalize. Amounts keep the existing DZD formatter.
4. **Display numbers (metrics):** `num-xl` gains the Stripe move — weight 500
   (not 700) at 28–32px with a caption unit suffix ("M DA" smaller, muted) —
   premium = restraint at display sizes.
5. **AR parity:** Noto Sans Arabic's ladder maps 1:1 (already wired via
   `--font-arabic-stack`); verify AR micro-labels keep uppercase=none (Arabic
   has no case — current behavior correct, document it).

---

## 5. Information display — the universal patterns

**Density doctrine (§24) stays:** dashboard medium, tables high, detail
medium-high, forms focused, settings low. The patterns below are the *universal
element set* — every surface composes from these, nothing bespoke.

### 5.1 Essential elements (every page MUST answer these — CONTEXT FIRST)
| Element | Pattern (current → target) |
|---|---|
| Identity strip | view title + count chip (exists) → + last-refresh timestamp on stale-able data |
| Primary action | ONE filled primary per view, context-aware (G6: Tasks view's composer IS the primary; the global "+ prospect" demotes to outline there) |
| Filter/search row | unified select chips + reset affordance (D-UX-021 pattern generalized) |
| Record rows | zebra + hover wash + leading-edge affordance for clickable rows (extend the lead-row inset-bar to tasks/visits rows — G4) |
| Status column | tone-badged, icon-optional, consistent ramp (G2) |
| Numeric column | tabular, end/Start-aligned per direction, formatter-owned |
| Empty/loading/error | existing `states.tsx` trio everywhere (verify 100% coverage in P9 sweep) |
| Sticky context | group bands (D-UX-021) on any grouped list; sticky header on tables |

### 5.2 Secondary elements (earned by state, not default)
- In-row meters (G5): budget-fit mini-bar in leads budget cells; probability
  meter on drawer opportunity cards (exists on pipeline only); score rings on
  matching (exists). Rule: a meter only when the number HAS a domain range.
- Avatar clusters: owner initials (colored by stable hash of user id) on rows
  and kanban cards — adds scan identity without photos.
- Row expansion: activity preview inline (lead-activity-preview pattern) —
  never a page navigation for one fact.
- Bulk-selection bar: leads only (exists) — do NOT generalize until a second
  surface earns it.
- Sparklines (analytics only): 12-point trailing series on KPI cards.

### 5.3 Record-centric detail (the drawer stays the cockpit)
- Header: name (600) + status badge + owner chip + score meter — one line of
  truth before any scroll.
- Section anatomy: micro-caps label (muted) → content (body) → meta (caption);
  12px internal rhythm; divider only between semantic groups (G3).
- Tab bar: icon+label tabs (existing), sticky within drawer scroll.
- The next-action band (D-UX-016/017) stays the visual anchor — the single
  most important element on the surface; primary-tinted, never de-emphasized.

### 5.4 Calendar/kanban
- Calendar cells are temporal records (D-UX-021 shipped): keep time+count
  micro-line; today = filled pill (universal convention).
- Kanban: header = count + value (exists) + aging chips (exists); cards gain
  avatar chip (5.2); WIP-limit warning when a column exceeds a configurable
  threshold (attention tier 2) — defer to P9.4 pending product decision.

---

## 6. React interactions — calm, fast, predictable

**Research:** premium motion = 150–200ms ease-out, transform/opacity only,
`prefers-reduced-motion` honored (already wired via `useReducedMotion`).

### 6.1 Micro-interaction catalog (the only allowed set)
| Interaction | Spec |
|---|---|
| Row hover | bg wash 120ms + leading-edge bar slide-in 150ms (clickable rows only) |
| Press | scale(0.98) on primary/secondary buttons, 100ms — never on rows |
| Focus | ring-2 ring-ring/50 (exists) — ensure visible on every interactive (a11y gate) |
| Drawer | slide+fade 220ms cubic-bezier(0.2,0,0,1) — current sheet default; add content fade-in stagger ≤2 items max |
| Dialog | scale 0.98→1 + fade 150ms (Radix default; keep) |
| Optimistic flips | badge/status swaps crossfade 150ms (D-UX-020 pattern generalized) |
| List reorder | FLIP layout animation on kanban move (framer `layout` — exists on some surfaces; complete it) |
| Toast | existing sonner richColors; add swipe-dismiss affordance in RTL direction parity |
| Skeletons | existing shimmer; standardize to row-shaped on every list surface |

### 6.2 Keyboard & command surface
- Cmd/Ctrl+K palette (exists): add recent-records section (last 5 viewed
  leads/units — store already tracks openLead) + per-context commands so the
  palette in Tasks view offers "Nouvelle tâche" (kills G6's dead-end properly).
- `j/k` row navigation + `Enter` open + `Space` select on leads table (Linear
  idiom; behind a feature probe, then default-on).
- `Escape` closes topmost layer (exists); `⌘⇧K` opens palette in command-only
  mode (stretch).

### 6.3 Interaction states matrix
Every interactive element ships 5 states: default/hover/focus-visible/active/
disabled. One audit PR renders the matrix for the component library (screenshots
per state per mode) — becomes the UI_QA.md regression fixture.

---

## 7. Implementation roadmap (incremental, gated, reversible)

Each stage = one PR-sized wave, §53 order (audit→map→reuse→implement→verify),
lint/tsc/E2E/VLM/AR/dark/mobile gates, D-UX-02x decision entries.

| Stage | Scope | Maps to | Est. |
|---|---|---|---|
| **P9.1 Token foundation** | neutral ladder + attention tiers + chart palette as CSS vars; component migration: tasks, visits, audit lists first | G2 G3 | 1 wave |
| **P9.2 Typography enforcement** | weight/color audit all surfaces; tabular+mono numerals; num-xl restraint | G1 | 1 wave |
| **P9.3 Icon vocabulary registry** | per-domain glyph maps; size/stroke rules; empty-state icon refresh | G2 G6 | 1 wave |
| **P9.4 Row tactility + status ramps** | leading-edge affordance generalization; lead-status/visit/priority ramp completion; in-row meters (budget bar, drawer probability) | G4 G5 G2 | 1–2 waves |
| **P9.5 Context-aware primary actions** | per-view primary + palette recent-records + contextual commands | G6 | 1 wave |
| **P9.6 Avatar chips + identity** | owner initials (stable hash colors) on rows/kanban/drawer | G5 | 1 wave |
| **P9.7 Motion catalog completion** | press/hover/crossfade/FLIP per 6.1; interaction-states matrix fixtures → UI_QA.md | G4 polish | 1 wave |
| **P9.8 Keyboard navigation** | j/k/Enter/Space on leads; palette command modes | 6.2 | 1 wave |
| **P9.9 Analytics chart pass** | categorical ramp, sparklines, KPI display numbers | G5 | 1 wave |
| **P9.10 Full-platform visual QA** | 24-capture re-run ×3 modes, VLM scorecard vs this plan's targets, UI_QA.md baseline | all | 1 wave |

**Out of scope (product decisions, not visual):** WIP limits, week view,
per-user density preference (Lightning-style compact/comfortable switch) —
listed for backlog, need user input.

---

## 8. Validation gates (per stage)

1. lint 0 · tsc 0 src · no console errors (agent-browser sweep).
2. E2E golden path per touched surface (existing probe scripts).
3. VLM pass ≥4/5 checks on after-captures (before/after pairs archived).
4. AR RTL: geometry probe + no AM/PM meridiem + font-stack check.
5. Dark mode: token parity VLM check (the P8-10 opacity lesson).
6. Mobile 390px: no horizontal scroll, hit-areas ≥44px (crm-hit).
7. §52 ten questions answered for each changed surface.
8. Zero functional regressions — visual waves never alter API/schema/contracts.

---

## 9. What "universal UI" means here

Not a template — a **closed composition system**: every surface answers the
same six CONTEXT-FIRST questions using the same essential elements (§5.1),
dresses them in the same token set (§2–4), moves with the same interaction
catalog (§6), and reserves the same secondary vocabulary for earned states
(§5.2). Originality lives in the warm-paper/emerald identity and the
real-estate domain glyphs; everything else is disciplined repetition — which is
exactly what Salesforce, Stripe, and Linear actually do.

---

*Prepared from the October 2026 full-platform audit. Evidence:
`download/qa-p8/audit/` (24 captures), `download/qa-p8/research/` (8 research
files), VLM gap analyses (dashboard/leads/drawer). Implementation begins on
user go-ahead — start with P9.1.*
