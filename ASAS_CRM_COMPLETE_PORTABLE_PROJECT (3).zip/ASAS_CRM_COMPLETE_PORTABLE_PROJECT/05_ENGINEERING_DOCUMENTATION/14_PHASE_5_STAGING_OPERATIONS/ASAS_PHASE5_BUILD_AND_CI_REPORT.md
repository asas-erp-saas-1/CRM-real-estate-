# ASAS Phase 5 — Build & CI Report (C1 preparation, P4-M06 analysis)

**Task:** P5-W2-A1 — deployment architecture, build & CI package.
**Agent:** 1 (implementation engineer). **Date:** 2026-11-07.
**Baseline:** 772/772 tests · Phase 4 verdict ACCEPT WITH CONDITIONS.
**Scope:** CI workflow verification (read-only), `reactStrictMode` risk
assessment (report-only — next.config.ts is Principal-owned), the C1
BLOCKED statement + exact external execution procedure, and the deployment
artifact set (`Dockerfile`, `.dockerignore`, `docker-compose.staging.yml`,
`.env.staging.example`, `deploy/README-STAGING.md`).
**No build, no docker build/run, no server boot, no CI run, no git write
happened in this session** — every BLOCKED statement below is literal.

---

## 1. CI step verification (`.github/workflows/ci.yml` — READ-ONLY audit)

The workflow was re-read step-by-step against the required gate set. The
rejected-claims log (Phase 4 §5: the "mangled branches" claim was REJECTED —
file is clean) is confirmed again: `on: push/pull_request: branches: [main]`
is intact.

| Required gate | ci.yml coverage (job → step) | Verdict |
|---|---|---|
| Dependency install, frozen lockfile | `static-gates` → "Install dependencies (lockfile)" `bun install --frozen-lockfile`; identical steps in `database-gates` + `test-gates` | ✅ COVERED (all three jobs; Bun pinned 1.3.14 via `oven-sh/setup-bun@v2`, matching `packageManager` + `bun.lock`) |
| Prisma generate | `static-gates` + `test-gates` → "Generate Prisma client" `bunx prisma generate` | ✅ COVERED explicitly; `database-gates` relies on bun's trusted-deps postinstall during `bun install` (verified behavior — see §1.1) |
| Lint | `static-gates` → "Lint" `bun run lint` | ✅ COVERED |
| TypeScript validation | `static-gates` → "Typecheck" `bun run typecheck` (`tsc --noEmit`) | ✅ COVERED (and `next build` itself typechecks — strict flags are ON, see §4) |
| Migration validation (deploy + status on isolated DB) | `database-gates` → "Apply SQLite migration chain to a fresh isolated database" `bunx prisma migrate deploy` (DATABASE_URL `file:./db/ci-check.db`) + "Verify migration bookkeeping is up to date" `bunx prisma migrate status` + synthetic seed + `scripts/validate-seed.py` | ✅ COVERED — and the exact command pattern was **reproduced locally this session** on a throwaway DB (25/25 applied, status "up to date"; evidence 01 §B) |
| Full automated tests vs live server on isolated DB | `test-gates` → "Apply migrations…"/"Seed…" (isolated `ci-test.db`) → "Boot the dev server (demo mode ON — explicit isolated test context)" with health poll + `jq -e '.dbOk == true'` → "Run the full Vitest suite" `bun run test` | ✅ COVERED (demo mode ON is the sanctioned isolated-test posture; the suite fails when the server is unreachable — no-skip law) |
| Demo-mode-off negative probes | `test-gates` → "Demo-mode-OFF negative probes (production security posture)": server relaunched with `ASAS_DEMO_MODE=0` → health `jq -e '.demoMode == false'` → quick-login POST expects **403 + code `DEMO_MODE_DISABLED`** → session listing `jq -e '.demoUsers | length == 0'` | ✅ COVERED (this is the C3 contract pre-encoded; identical to the runbook §2d probe) |
| Production build as explicit acceptance gate | `static-gates` → "Production build" `bun run build` | ✅ COVERED as a required step of a required job (its failure fails the workflow) |
| Trigger hygiene | `on: push/pull_request, branches: [main]` | ✅ CLEAN (Phase 4 rejection of the "mangled trigger" claim re-confirmed) |

**Gaps found: NONE requiring an edit.** Observations (documented, deliberately
not acted on — no defect):

1. **CI builds but does not BOOT the standalone artifact.** No
   `node .next/standalone/server.js` + health step exists in the workflow.
   This is a coverage observation, not a defect: the 772-test baseline is
   dev-server-based by documented design, and Phase 4 assigned the
   boot+health leg of C1 to the **staging host entry gate** (the workflow
   header states its scope honestly). If the Principal later wants CI to
   smoke-boot the artifact, the addition is small (build → `node
   .next/standalone/server.js &` → health probe → teardown); it was not made
   here because the brief authorizes edits only for REAL defects.
2. `database-gates` has no explicit `prisma generate` step — it depends on
   bun running prisma's trusted postinstall during `bun install`. Verified
   behavior in this environment (the local `bun install`-based flow generates
   the client), and the seed step's `PrismaClient` import would fail loudly
   if it ever broke — not silent. Noted for awareness only.
3. No dependency-install caching (`actions/cache` for bun) — a runner-minutes
   optimization, not a correctness gap.

**Verdict: the workflow is the sanctioned external execution vehicle for
C1's build leg, as-is.**

### 1.1 Empirical path-resolution check (why the isolated-DB steps are consistent)

A latent ambiguity exists in Prisma + SQLite: where does a RELATIVE
`file:./…` URL resolve — schema directory or CWD? This matters because the
workflow uses `file:./db/ci-check.db` / `file:./db/ci-test.db`. Probed live
this session (throwaway files, dev DB untouched — evidence 01 §A):

- **CLI**: `DATABASE_URL=file:./probe-rel-cli.db bunx prisma migrate status`
  → P1003 with the file at CWD; connects when the file is at
  `prisma/probe-rel-cli.db` ⇒ **CLI resolves relative to the schema
  directory**.
- **Runtime**: `PrismaClient` + relative URL ⇒ the engine created
  `prisma/probe-rel-rt.db` and answered `SELECT 1` ⇒ **runtime resolves
  relative to the schema directory too**.
- **Full CI pattern reproduced**: `DATABASE_URL=file:./probe-cidir/ci-probe.db
  bunx prisma migrate deploy` → created `prisma/probe-cidir/ci-probe.db`
  (nested directory auto-created), applied **25/25 migrations**; `migrate
  status` → "Database schema is up to date!".

⇒ All CI steps that share one env value hit the SAME file; the pattern is
functional end-to-end. Consequence carried into the deployment design:
**`.env.staging.example` uses an ABSOLUTE container path**
(`file:/app/db/custom.db`) — the dev `.env` already uses the absolute form,
so this is the proven convention, and it removes the ambiguity entirely for
CLI, engine, and backup runner alike.

---

## 2. Condition C1 — status and exact external execution procedure

**C1 (first-ever production build + standalone boot + `/api/health` PASS) is
BLOCKED in this sandbox, honestly and completely:**

- `bun run build` / `next build` is FORBIDDEN here by the standing environment
  rule (AGENTS.md). No build of any kind ran in this session.
- No docker daemon exists in the sandbox — the image was never built or run.
- **No git remote exists** (`git remote -v` empty, re-verified this session) —
  the CI workflow has NEVER executed anywhere, on GitHub or elsewhere.

Nothing below has been executed; it is the precise procedure, prepared for
external execution:

### 2.1 CI execution path (when a remote exists — preconditions: GIT_HISTORY_PURGE D-013 first)

1. Owner completes `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` **before** creating
   any remote (the standing gate order; a purge-after-push leaks
   server-side reflogs).
2. Create the GitHub remote, push `main`. `.github/workflows/ci.yml`
   activates on push automatically — no GitHub UI configuration is required
   beyond repo creation.
3. **Expected CI evidence for C1's build leg:** a green Actions run on `main`
   whose `static-gates` job shows the "Production build" step log ending
   with the Next.js route-summary table and exit code 0 — the first-ever
   `next build` receipt. (The same run also proves: frozen-lockfile install,
   prisma generate, lint, typecheck, the isolated-DB migration chain
   deploy+status+seed, the 772-test suite, and the demo-mode-off negative
   probes.)
4. The CI run alone does NOT close C1 — the boot+health leg runs on the
   staging host (2.2). CI never boots the standalone artifact (§1
   observation 1).

### 2.2 Staging-host execution path (the authoritative C1 gate — verbatim from deploy/README-STAGING.md §2)

```bash
# (a) prepare — once
git clone <repo-url> asas-crm && cd asas-crm
cp .env.staging.example .env.staging
openssl rand -hex 32                     # → ASAS_SESSION_SECRET value
$EDITOR .env.staging                     # paste secret; keep ASAS_DEMO_MODE=0

# (b) PART 1 — first-ever production build
docker compose -f docker-compose.staging.yml build

# (c) PART 2 — standalone boot (entrypoint = node .next/standalone/server.js)
docker compose -f docker-compose.staging.yml up -d
docker compose -f docker-compose.staging.yml ps        # → (healthy)

# (d) PART 3 — health gate (C1 PASS criteria)
curl -fsS http://127.0.0.1:3000/api/health | tee /tmp/c1-health.json | jq .
jq -e '.dbOk == true and .demoMode == false' /tmp/c1-health.json
```

**C1 is satisfied when:** the build exits 0, the container reaches
`healthy`, and the final `jq -e` exits 0. Receipts to record: the build log
+ `/tmp/c1-health.json` (which also carries `migrations: 25`, `rssMb`,
`uptimeSec`, `nodeEnv`). Optional same-session C3 probes (quick-login 403
`DEMO_MODE_DISABLED`, `demoUsers` empty) are in README-STAGING.md §2d.

The Docker build and the CI build execute the SAME command (`bun run build`)
on the SAME toolchain (Bun 1.3.14, frozen lockfile) — whichever runs first
delivers the first-ever build; the other becomes a reproducibility
confirmation. The staging entry gate is complete only with the boot+health
leg.

---

## 3. Deployment artifact set (produced this session)

| Artifact | Purpose |
|---|---|
| `Dockerfile` | 2-stage image: `oven/bun:1.3.14` builder (frozen install → prisma generate → **`bun run build`**) → `node:22-bookworm-slim` runtime (standalone at the exact `start` path, static assets copied per the Next standalone contract, bun binary for ops scripts, `/app/.next/standalone/db → /app/db` DOCS_DIR bridge symlink, non-root, HEALTHCHECK on `/api/health`) |
| `.dockerignore` | context law: no `db/`, no `.env*`, no `.z-ai-config`, no `.git`, no local `.next`/`node_modules`, no docs/tests weight — verified against tsconfig `include` |
| `docker-compose.staging.yml` | single service `asas-crm`: `restart: unless-stopped`, `mem_limit: 4g` (measured-RSS justification inline), `127.0.0.1:3000:3000`, `env_file: .env.staging` + NODE_ENV/PORT/HOSTNAME, volume `asas-data:/app/db`, healthcheck (30s/5s/3×/60s start_period, all values justified inline), capped json-file logging |
| `.env.staging.example` | all runtime vars with placeholders + policy comments: NODE_ENV, absolute-in-volume DATABASE_URL, ASAS_SESSION_SECRET (generation + rotation warning), ASAS_DEMO_MODE=0 (fail-fast warning), seed guard documented as NEVER, ASAS_BACKUP_KEEP, AI-provider contract |
| `deploy/README-STAGING.md` | reproducible runbook: prerequisites (≥8 GB host, measured justification), C1 entry gate (§2 above), first boot (migrate → `db:owner` — never demo seed — → health), backup scheduling (references `deploy/systemd/`), restore/upgrade/rollback, monitoring + kill-recovery test, troubleshooting, honest limitations |

Design decision record: `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_STAGING_ARCHITECTURE.md`.
Documentation updates: `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md` (hosting-decision
warning header — C2), `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/PRODUCTION_READINESS.md` (P4-M07
stale rows refreshed).

**One reporting item (outside this agent's file ownership):** committing
`.env.staging.example` requires adding `!.env.staging.example` to
`.gitignore` — the existing `.env*` ignore rule (with only `!.env.example`
negated) currently swallows it. `.gitignore` is not in this agent's owned
file set, so this is reported for the Principal, not edited. Until then the
template exists on disk but would not be tracked by git.

---

## 4. `reactStrictMode` (P4-M06) — risk assessment and recommendation (REPORT ONLY)

**Finding recap:** `next.config.ts:11` sets `reactStrictMode: false`, which
contradicts a P0-era report claiming a flip to `true`. The Phase 4 audit
asked for either the flip or a documented deliberate-off. next.config.ts is
Principal-owned — this section is the decision input, not an edit.

### 4.1 What the flag actually does (and does NOT do)

- React StrictMode double-invokes **render functions and effect
  mount/unmount cycles in DEVELOPMENT ONLY** — mount → unmount → remount —
  to surface missing cleanup and non-idempotent effects. It has **zero
  effect on production build output or production runtime behavior**.
  Therefore: **the flag is irrelevant to condition C1, the staging
  deployment, and every production artifact this package produces.** This is
  a dev-tooling decision only.
- The codebase's `globalThis` singletons are all **SERVER-side**
  (`src/lib/server/expiry-scheduler.ts`, `obs.ts`,
  `notification-cache.ts`, `src/lib/db.ts`) and exist for Turbopack HMR
  chunk-duplication hardening — server modules are evaluated once per
  process and are **not touched by React StrictMode at all**. The P4-M06
  "config-integrity discrepancy" is about report accuracy, not about these
  singletons being at risk from the flag.

### 4.2 Codebase survey (what double-mounting would actually exercise)

Surveyed all 52 `useEffect` sites + every timer/listener registration in
client code (`src/app`, `src/components`, `src/lib/client`, `src/hooks`);

| Pattern class | Sites | Strict-mode exposure | Assessment |
|---|---|---|---|
| `addEventListener` without matching cleanup | **0 of 3** listener sites — `store.ts:175` (hashchange), `leads-view.tsx:108` (keydown), `search-command.tsx:154` (keydown) all `return () => removeEventListener(...)` | double-mount → register/unregister/register — net one listener | ✅ safe |
| Debounce timers | `use-debounced.ts`, `sav-view.tsx:61`, `finance-view.tsx:82`, `search-command.tsx:160`, `journey-view` (same idiom) — all `return () => clearTimeout(id)` | remount clears the timer before it can double-fire | ✅ safe |
| Animation timers | `use-count-up.ts` — framer `controls.stop()` in cleanup | safe | ✅ safe |
| Fire-and-forget `setTimeout` without cleanup | `temp-password-dialog.tsx:39`, `lead-copilot-card.tsx:173` (`setCopied(false)` resets), `search-command.tsx:49/52` (focus retry), `lead-tab-tasks.tsx:84` (has cleanup) | worst case: an extra idempotent state reset / focus retry after remount | ✅ harmless |
| Async fetch in effect | `login-overlay.tsx:195` uses an `alive` flag; all data fetching goes through react-query | double-mount → react-query dedupe/cancel semantics | ✅ safe |
| **Mutations fired from effects** (the genuinely dangerous class — double-fire POST/PATCH) | **0 sites** (`useEffect` bodies containing `useMutation`/`api.post|patch|delete`: grep-verified none) | none | ✅ the class is absent |
| Module-level side effects in client code | none found outside components | n/a | ✅ safe |

### 4.3 Risk assessment

**Flipping `reactStrictMode: false → true` is LOW risk for this codebase.**
The effect corpus is cleanup-disciplined (the three listener sites, every
debounce, the count-up animation); the dangerous mutation-in-effect class
does not exist; react-query absorbs double-mount fetching; the un-cleaned
timers are idempotent state resets. The server-side `globalThis` singletons
that the deliberate-off reasoning sometimes gets associated with are
unaffected by the flag entirely.

**What the flip would buy:** the dev-time double-render safety net the P0
report claimed existed — catching future cleanup regressions (a new
listener/timer without cleanup would visibly misbehave in dev instead of
silently leaking in production), plus config-integrity restoration (the
tree would match the historical report).

**What the flip would cost:** one dev-session validation sweep (console
zero-check across the 12 views, the 5-gate protocol per
TEST_STRATEGY/AGENTS) — and nothing at build/deploy time (§4.1). The known
Turbopack dev quirks (stale CSS/module items, AGENTS.md) are unrelated to
the flag and unaffected by it.

### 4.4 Recommendation

**Flip to `true` in a controlled session (NOT during the C1/staging
bring-up), then re-run the dev sweep.** Rationale: the codebase survey shows
no realistic breakage class, the historical report accuracy is restored, and
the cost is one validation sweep. It is deliberately NOT urgent: it changes
nothing about the deployment package or C1, and mixing a dev-tooling flag
change into the first-ever build event would confound any triage. Sequenced
recommendation: C1/C2/C3 staging gate first → then the strict-mode flip as
its own small change with its own sweep (and a worklog + decision-log entry).
If the Principal instead prefers deliberate-off, the honest documentation is:
"reactStrictMode deliberately false since P6-era sandbox stability; the
codebase survey (this report §4.2) found no cleanup debt that strict mode
would catch today; revisit when client effect code grows."

---

## 5. Evidence index (`05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/evidence/a1-deploy/`)

| File | Content |
|---|---|
| `01-ci-step-verification.txt` | step-by-step ci.yml audit vs the required gate set + the live Prisma relative-path resolution probes (CLI + runtime) + the full CI `migrate deploy` pattern reproduced on a throwaway DB (25/25, status up-to-date) |
| `02-dockerfile-lint.txt` | hadolint unavailable in the sandbox (verified) → structured manual review checklist against Dockerfile best practices (pinning, non-root, healthcheck, layer order, no secrets) with per-item verdicts |
| `03-compose-config-validation.txt` | `docker compose config` unavailable (no docker CLI — verified) → `python3`+PyYAML 6.0.3 `safe_load` parse of `docker-compose.staging.yml` AND `.github/workflows/ci.yml`, plus a semantic assertion pass (keys the deployment depends on) |
| `04-standalone-paths-verification.txt` | the standalone-output contract verified against the repo: `output:"standalone"` (next.config.ts), `start` script path, the installed Next 16.1.3 server.js template (`process.chdir(__dirname)`, PORT/HOSTNAME reads — quoted), static-assets copy requirement, DOCS_DIR/DATABASE_URL/backup.sh path algebra in the container |

---

## 6. Honest limitations

1. **C1 remains BLOCKED** (build forbidden here; no docker; no git remote).
   This report PREPARES the gate; it does not claim any part of it ran.
2. The CI verification is a static read + local reproduction of the
   database-gates command pattern; the workflow itself has still never run
   on GitHub Actions.
3. The `reactStrictMode` assessment is code-survey-based (grep + read of the
   effect corpus), not an executed dev-mode double-render sweep — by the
   same sandbox rules that forbid booting servers for experiments here.
4. The Dockerfile is contract-verified (evidence 04), never built; the first
   `docker build` is C1's part 1 and may still surface environmental facts
   (e.g. bun `--production` install behavior, prisma engine download) that
   no static analysis can fully predict.

*No secrets, database URLs, or credentials appear in this document or its
evidence files.*
