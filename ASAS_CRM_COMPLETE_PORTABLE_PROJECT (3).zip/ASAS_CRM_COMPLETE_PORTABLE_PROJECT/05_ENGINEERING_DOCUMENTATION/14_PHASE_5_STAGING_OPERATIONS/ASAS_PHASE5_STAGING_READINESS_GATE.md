# ASAS CRM — Phase 5: Staging Readiness Gate — FINAL VERDICT

**Gate authority:** Principal Engineering Lead, Phase 5
**Date:** 2026-11-07 · **Evidence basis:** six-agent implementation waves (A1–A6 incl. two completion passes) + Principal integration, central script control, full regression, and live browser verification — all recorded under `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/` (this session).
**Decision rule:** verdict from evidence; a passing unit test is never presented as proof of a production build or live deployment; environment-blocked gates are marked BLOCKED, never PASSED.

---

## 1. Gate-by-gate outcomes (C1–C8)

| Gate | Outcome | Key evidence |
|---|---|---|
| **C1 — Production build + standalone boot + health** | **BLOCKED** (environment) — `next build` is forbidden in this sandbox; no git remote exists so CI has never executed anywhere. Prepared, not faked: multi-stage `Dockerfile` whose build stage is the sanctioned first-build site; `ci.yml` verified gate-complete (8/8 gates incl. production build as acceptance step); exact external procedure in `deploy/README-STAGING.md` §C1 (build → up → `jq -e '.dbOk==true and .demoMode==false'`). | `evidence/a1-deploy/01–04` |
| **C2 — Hosting model** | **PASS** — single-node Linux VPS/Docker decision recorded as ADR with the four single-instance mechanisms cited (scheduler, process-local rate limits, in-memory obs/cache, SQLite+documents); persistent-volume design survives restart AND replacement; `VERCEL_SETUP.md` reframed; `PRODUCTION_READINESS.md` refreshed (7 stale rows). Compose: `mem_limit 4g` (measured-RSS justification), `restart: unless-stopped`, healthcheck 30s/5s/3×/60s, `asas-data:/app/db` volume. | `ASAS_PHASE5_STAGING_ARCHITECTURE.md`, `evidence/a1-deploy/02–03` |
| **C3 — Production posture** | **PASS at module/script level; runtime boot rides C1** — fail-fast proven in isolated child processes: missing secret → exit 1; production+demo → exit 1 `DEMO_MODE_PRODUCTION`; clean production posture → `BOOT_OK violations=[]`; secure cookie config code-verified; demo-off default; no ephemeral-secret dependency. 13 automated tests + 10 evidence transcripts. | `evidence/a3-security/01–03, 09` |
| **C4 — Seed safety** | **PASS** — migrations plant zero users (proven on fresh disposable DB); production seed refuses (exit 1, zero writes) without the loud explicit opt-in; dev/CI seed intact; `db:deploy` no longer seeds; sanctioned `db:owner` provisioning refuses the public demo password; second run refuses (idempotent). | `evidence/a3-security/04–08, 10` |
| **C5 — Backup readiness** | **PASS** — first-run bootstrap defect reproduced → fixed → live first-ever backup PASS (consistent VACUUM INTO, manifest, sha256; source sha256 unchanged); restore drill PASS (manifest/sha256/integrity/census; original untouched); retention dry-run recognizes the real backup; systemd timer/service templates + offsite procedure delivered (activation = owner action, honestly declared). | `evidence/a2-backup/01–06` |
| **C6 — Operational floor** | **PASS as prepared operational package** — memory supervision anchored to measured evidence (steady 2.0–2.5 GB, kills at 2.31/2.55 GB → 4g limit + WARN 3500/CRIT 4000 MB); restart policy + healthcheck wired in compose; monitoring/alerting design (8 concern classes, concrete grep/jq recipes, alert-channel placeholders); health-watch template delivered with its alert-dispatch defect found in review and fixed; kill-recovery test procedure documented. **No external watchdog/monitor is claimed active — none is.** | runbook §1–3, `evidence/a6-ops/01–05` |
| **C7 — Retention safety** | **PASS** — strict compact-stamp parser implemented; 26 tests incl. all 7 mandated interlock cases; **live probe: `freshBackupFound: true`** from a real 4-minute-old backup (the previously-NaN path). `--confirm-purge` never executed against real data. | `evidence/a2-backup/04–05` |
| **C8 — Financial ceiling** | **PASS** — one authoritative `MAX_MONEY_DZD` (1e10) in `src/lib/money.ts`; the 100× installments bug fixed; CSV import bypass closed; private twins removed across API/UI; 19 boundary/overflow tests; live at-cap rejection. | `evidence/a4-finance/01–02` |

**Gate summary: 6 PASS · 1 PASS-module-level (runtime leg = C1) · 1 BLOCKED (C1, external).** No gate was invented as passed; no CRITICAL or HIGH application defect remains (see §3).

---

## 2. Full regression (Principal-run, post-integration)

| Check | Phase 4 baseline | Phase 5 result |
|---|---|---|
| TypeScript | 0 errors | **0 errors** |
| Lint | 0 errors / 41 warnings | **0 errors / 41 warnings** |
| Full Vitest suite | 772/772 (44 files) | **879/879 (51 files) — +107, 0 removed, 0 skipped** (reconciliation table in the Implementation Matrix §5) |
| Migration status | 25/25 up to date | **25/25 up to date** (no new migrations this phase — by design) |
| Health endpoint | ok / dbOk / 25 / demoMode:true | **ok / dbOk / 25 / demoMode:true / rssMb ~2.3 GB steady** |
| Browser E2E (post-StrictMode flip) | — | **login → dashboard → pipeline → AR RTL: 0 console errors/warnings; heading H1→H2; scrollWidth ≤ viewport; screenshots `evidence/principal/01–04`** |
| Original DB integrity | census exact | **census exact + sha256-stable across all destructive-adjacent operations; both mid-session incidents repaired and re-verified** |

---

## 3. Residual register (honest)

**Open deferred (documented, non-blocking for staging):** P4-M05 god-route extraction · P4-L04 lockout-DoS redesign · P4-L13 coverage thresholds · WAL enablement (engine bug range) · lint-warning ratchet.
**Environment-blocked (owner actions):** C1 build/CI execution · remote CI (needs git remote) · external watchdog/monitoring wiring · backup scheduling activation · offsite copy execution · email/SMS credentials.
**Incidents:** two disclosed agent test-pollution events on the demo DB, both repaired same-session and re-verified by the Principal (payments/census/audit counts match seed); three dev-server OOM kills under concurrent agent load — the documented P4-H01 class, now addressed by design for staging.

---

## 4. FINAL VERDICT

# B — STAGING PACKAGE READY, EXTERNAL GATE BLOCKED

**Rationale.** Every condition that can be satisfied by engineering work inside this repository has been satisfied with code, tests, and live evidence: the two code-level defects that gated destructive operations are fixed and live-verified (C7 retention, C8 money law); the deployment footgun is structurally closed (C4); backups bootstrap, verify, restore, and schedule-by-template (C5); the operational floor is designed, measured, and templated (C6); the hosting model is decided and packaged reproducibly (C2); production posture gates are proven at the only level this environment permits (C3). The full regression is stronger than the Phase 4 baseline (879/879, +107 tests, zero removals), the original database is provably intact, and the post-StrictMode application is browser-verified clean in three languages. **What remains is exactly one class of work: execution that this sandbox is forbidden to perform** — the first-ever production build, the standalone boot, and the external operational wiring (CI remote, watchdog, scheduling, offsite). Those are not engineering unknowns; they are prepared procedures with exact commands. Per the decision rule, a gate that cannot be executed here is BLOCKED, not PASSED — therefore verdict **B**, not **A**.

**Why not the other verdicts:**
- *A — STAGING READY:* would require actual build + standalone boot + health evidence from the staging host. None exists; claiming it would be fabrication.
- *C — CONDITIONALLY READY:* would imply remaining in-repo engineering conditions; there are none — only external execution.
- *D — NOT READY:* would require a critical security/data-integrity/operational defect; none exists, and the Phase 4 conditional-acceptance defects (M01–M04, M10, L01/L02/L05/L06/L07/L08/L16, M06/M07) are closed with evidence.

**Exact remaining owner actions (in order):**
1. Provision the single-node host (≥8 GB RAM recommended per measured profile; ≥4 GB container limit is the floor) and clone the repository.
2. `cp .env.staging.example .env.staging`, set `ASAS_SESSION_SECRET` (`openssl rand -hex 32`), keep `ASAS_DEMO_MODE=0`.
3. Execute the C1 gate verbatim: `docker compose -f docker-compose.staging.yml build` → `up -d` → health `jq` assertion (procedure: `deploy/README-STAGING.md`).
4. `bun run db:deploy` (migrations only) → `bun run db:owner` (real owner credentials) — **never** demo seed on staging.
5. Activate the backup timer (`deploy/systemd/`), wire the health-watch alert channel (`deploy/monitoring/`), and run the first restore drill + kill-recovery test on the staging host.
6. When a git remote exists (after the documented history-purge review): push and let CI execute the full gate chain remotely.

**This verdict authorizes staging entry preparation only. It is not a production deployment authorization. Staging must be operated (monitored, backed up, drilled) before any production-release review.**

---

## 5. Honest limitations of this phase (NOT VERIFIED list)

1. **Production build / standalone boot / production-mode runtime** — environment-forbidden (C1); never fabricated.
2. **Remote CI execution** — no git remote exists; workflow verified on disk only.
3. **Docker image build/run** — no docker daemon in this sandbox; Dockerfile/compose are review- and parse-validated artifacts only.
4. **External monitoring/alerting, backup scheduling, offsite copies** — templates and procedures only; nothing activated (no credentials, by rule).
5. **Load/stress at scale** — unchanged from Phase 4 (sequential probes; no concurrent harness).
6. **Email/SMS delivery** — BLOCKED (zero credentials), evaluation-only.
7. **Algerian data-protection legal compliance** — out of software scope; requires legal review.

*No secrets, database URLs, or credentials appear in this document.*
