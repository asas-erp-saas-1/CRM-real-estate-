# ASAS Phase 5 — Security & Seed Policy (C3 + C4 / P4-M03)

**Task:** P5-W1-A3 — production posture verification (C3), demo-seed deployment
footgun elimination (C4 / P4-M03), sanctioned initial-owner provisioning.
**Agent:** 3 (implementation engineer). **Date:** 2026-11-07.
**Baseline:** 772/772 tests (Phase 4 verdict: ACCEPT WITH CONDITIONS).
No real credential appears anywhere in this document or its evidence files;
test secrets are obviously-fake temporary values, redacted as
`<redacted-test-secret>` / `<redacted-test-owner-password>`.

---

## 0. Honest scope statement (what is and is NOT proven here)

A true Next.js production server boot (`next build` + `next start`) requires
`next build`, which is **FORBIDDEN in this sandbox** — audit condition **C1 is
BLOCKED here** and will be marked as such by the Principal. The production
posture in this document is therefore **MODULE-LEVEL and SCRIPT-LEVEL**:

- the boot gate (`assertProductionEnvironment`) is exercised in **isolated child
  processes** whose code replicates **exactly** the `nodejs` branch of
  `src/instrumentation.ts` `register()` (import `./lib/server/boot` →
  `assertProductionEnvironment(process.env)`) — the same call every real
  `next start` performs before serving traffic;
- the seed and provisioning scripts are executed for real (bun runs TypeScript
  natively) against **disposable `/tmp` databases**.

No successful production *server* boot is claimed or fabricated. What is
claimed: the configuration gates that would abort such a boot, and the seed
guard, behave exactly as specified — verified in isolation, with exit codes.

---

## 1. C3 — production posture verification results

Environment under test: `NODE_ENV=production` + `ASAS_DEMO_MODE=0` (+ a
temporary obviously-fake `ASAS_SESSION_SECRET` where required), isolated child
processes with an empty environment (`env -i` / controlled env, cwd outside the
project so Bun's `.env` auto-loading cannot leak the sandbox config in).

| # | Check | Result | Evidence |
|---|---|---|---|
| 1 | Missing `ASAS_SESSION_SECRET` → production startup **fails fast** (`SESSION_SECRET_MISSING`, exit 1) | **PASS** | `evidence/a3-security/01-boot-failfast-missing-secret.txt` |
| 2 | `NODE_ENV=production` + `ASAS_DEMO_MODE=1` → **REJECTED** (fail-fast throw `DEMO_MODE_PRODUCTION`, exit 1 — not a warning) | **PASS** (pre-existing P0-3 behavior, verified) | `evidence/a3-security/02-boot-failfast-demo-mode.txt` |
| 3 | Clean production env (strong secret + demo off) → gates **PASS at module level** (`BOOT_OK violations=[]`) | **PASS** | `evidence/a3-security/03-boot-clean-production.txt` |
| 4 | Demo mode **OFF BY DEFAULT** (unset passes the production gate) | **PASS** | `tests/unit/production-posture.test.ts` case 4 + `tests/unit/boot-env.test.ts` (evidence 09) |
| 5 | No production startup depends on an **ephemeral/placeholder secret** (placeholder refused: `SESSION_SECRET_PLACEHOLDER`) | **PASS** | `tests/unit/production-posture.test.ts` case 5 (evidence 09) |
| 6 | Secure cookie configuration in production (`secure: NODE_ENV === "production"`) | **PASS** (code-verified, §4) | `src/app/api/auth/login/route.ts:36-41` |
| 7 | Health contract observable (`demoModeMisconfigured`, `sessionSecretConfigured`) | **PASS** | `tests/unit/demo-mode-gate.test.ts` 7/7 (evidence 09); `src/app/api/health/route.ts:57-62` |
| 8 | Full production **runtime** server boot | **BLOCKED** — requires `next build` (condition C1); module-level only in this sandbox | §0 above |

On check 2: the brief asked to *implement* the production demo-mode rejection
**if** the current code only warned. It does not only warn —
`src/lib/server/boot.ts:57-64` emits the `DEMO_MODE_PRODUCTION` violation and
`assertProductionEnvironment` (boot.ts:70-79) **throws**, which crashes
`register()` in `src/instrumentation.ts:10-12` and aborts the server start. No
code change was needed; this task *verified* it in isolation (evidence 02) and
added permanent module-level regression tests
(`tests/unit/production-posture.test.ts`, 6 cases incl. child-process exit
codes).

---

## 2. C4 / P4-M03 — the seed policy

### 2.1 The problem (as found)

`package.json` defined `db:deploy` as `prisma migrate deploy && prisma db seed`
while `prisma/seed.ts` planted an OWNER + 7 demo personas whose password
(`asas1234`) is **displayed on the login overlay** — and nothing gated the seed
path in production. An operator following the documented deploy script on a
real server would create a production OWNER with a publicly-known password.

### 2.2 The fix, as implemented

1. **`prisma/seed.ts` production guard (the core change).** At the top of the
   `import.meta.main` block — **before `main()`, before any Prisma write,
   before even a lazy connection is opened** — the seed now evaluates the pure
   function `demoSeedProductionRefusal(process.env)` (seed.ts:798-825):
   - `NODE_ENV=production` **and** `ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION` ≠
     strictly `"1"` → print a **loud refusal** (naming the opt-in variable and
     the sanctioned `scripts/provision-owner.ts` alternative) and
     `process.exit(1)` — **zero database writes** (evidence 05: user count 0
     before AND after; evidence: the target DB file is not even created when
     absent).
   - The opt-in is **strict `"1"` only** — `"true"`/`"yes"`/`"on"`/`"0"`/`""`
     are all refused (unit-tested): no accidentally-truthy environment can
     bypass the guard, and **no normal deployment command ever sets this
     variable**.
   - Development/test seeding is **untouched** (guard returns `null`), so CI's
     `bun run db:seed` with NODE_ENV unset keeps working (evidence 06: 8 users
     seeded on a disposable DB; evidence 10a: the exact `prisma db seed` CLI
     path end-to-end, exit 0, 8 users). Even when the seed is invoked through
     the Prisma CLI (`prisma db seed` — the second step of the old
     `db:deploy`), the production refusal still fires with exit 1 and zero
     writes (evidence 10b).
2. **`scripts/provision-owner.ts` (new, the sanctioned owner path).** See §3.2.
3. **Migrations never plant accounts** — verified, not assumed: a fresh
   `bunx prisma migrate deploy` on a `/tmp` DB creates **0 users, 0 orgs**
   (evidence 04).

### 2.3 The FOUR distinct deployment operations (operators must never conflate these)

| Operation | What it does | Exact command | Production-safe? |
|---|---|---|---|
| **(a) Migrations** | Applies the schema chain; creates **zero accounts** | `bun run db:migrate` (= `prisma migrate deploy`) | ✅ Yes — the only step a production deploy runs (evidence 04) |
| **(b) Initial owner creation** | Creates org + exactly **one OWNER** with an operator-chosen password (never the public demo password) | `bun run scripts/provision-owner.ts --email ops@example.dz --name 'Ops Owner' --password-stdin` (env fallbacks `OWNER_EMAIL`/`OWNER_NAME`/`OWNER_PASSWORD`; exit 0 success · 1 misuse/conflict · 2 env missing) | ✅ Yes — this is THE production account path (evidence 08) |
| **(c) Development/demo seed** | Plants the full Algiers demo workspace (8 users, public password shown on the login overlay) | `bun run db:seed` (NODE_ENV unset or development) | ❌ Dev/test only — **refuses in production** (evidence 05/06) |
| **(d) Production account provisioning** | Real staff accounts, created by the OWNER through the app's user management after first login | In-app UI (post-(b)); the owner credential never appears in any repo/env artifact | ✅ Yes |

The only sanctioned way demo data can ever reach a `NODE_ENV=production`
database is the explicit, deliberate env override:
`ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION=1 bun run db:seed` (evidence 07) — a
variable no deploy tooling sets, whose name states its consequence, and which
accepts only the literal value `1`.

### 2.4 Required `package.json` split (Principal action — package.json is not editable by this agent)

Current line (package.json:17):

```json
"db:deploy": "prisma migrate deploy && prisma db seed",
```

**Recommended replacement lines** (migrate-only default; demo seed becomes an
explicit, separately-named operation; owner provisioning gets its own entry):

```json
"db:deploy": "prisma migrate deploy",
"db:deploy:demo": "prisma migrate deploy && prisma db seed",
"db:owner": "bun run scripts/provision-owner.ts",
```

Rationale: with the seed guard in place, `db:deploy` in production would now
fail loudly at the seed step (exit 1) even after migrations succeeded —
correct but confusing mid-deploy. Splitting makes the *production* deploy
command migrate-only by construction, while `db:deploy:demo` remains the
one-command setup for dev/demo/CI sandboxes (NODE_ENV unset → guard passes).
Also recommended (optional): document `ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION` in
`.env.example` with an explicit "never set this on a real deployment" warning.

---

## 3. Deliverables

### 3.1 Code

| File | Change |
|---|---|
| `prisma/seed.ts` | Added `demoSeedProductionRefusal()` (pure, exported) + guard wiring before `main()`; exported `DEMO_PASSWORD` and `hashPassword` for reuse. No seeding logic touched. |
| `scripts/provision-owner.ts` | **NEW** — sanctioned initial-OWNER CLI (§3.2). |
| `src/lib/server/boot.ts`, `src/instrumentation.ts` | **Unchanged** — the P0-3 fail-fast already implements the C3 rejection contract; verified instead (a real gap was looked for and not found; no change justified). |
| `tests/unit/seed-guard.test.ts` | **NEW** — 7 tests: guard matrix + process-level refusal (`bun prisma/seed.ts` under production → exit 1, DB file never created). |
| `tests/unit/production-posture.test.ts` | **NEW** — 6 child-process boot-posture probes (§1) replicating `instrumentation.ts` exactly, isolated from the project `.env`. |
| `tests/unit/boot-env.test.ts`, `tests/unit/demo-mode-gate.test.ts`, `tests/security/demo-isolation.test.ts` | **Unmodified** — existing coverage already complete for the pure gate matrix; re-run green (evidence 09). |

### 3.2 `scripts/provision-owner.ts` contract

- **Idempotent:** refuses (exit 1) if ANY OWNER exists anywhere in the target
  DB, or the email is taken — nothing written on refusal (evidence 08f).
- **Password hygiene:** refuses the public demo password `asas1234` (exit 1)
  and passwords < 12 chars; supports `--password-stdin` (preferred),
  `--password`, or `OWNER_PASSWORD`; the password is **never logged** —
  verified by grep on the success output (evidence 08d).
- **Same hashing as the seed:** imports `hashPassword` from `prisma/seed.ts`
  (scrypt, 16-byte random salt, 32-byte key, NFKC, `scrypt:<salt>:<hash>` —
  the exact convention `src/lib/server/auth.ts:57-61` verifies). Evidence 08e:
  the stored hash **fails** verification against `asas1234` and **passes**
  against the real (redacted) test password.
- **Org handling:** creates the org only when none exists (honoring
  `--org-name`/`--org-slug`), else attaches the OWNER to the oldest org.
- **Exit codes:** `0` success · `1` misuse/conflict · `2` `DATABASE_URL`
  missing/empty.

### 3.3 Tests (targeted run — evidence 09)

`bunx vitest run tests/unit/boot-env.test.ts tests/unit/demo-mode-gate.test.ts
tests/unit/seed-guard.test.ts tests/unit/production-posture.test.ts
tests/security/demo-isolation.test.ts`

(Plus the script-level CI-path verification in evidence 10.)

- `tests/unit/boot-env.test.ts` — **11/11** (pre-existing, re-run green)
- `tests/unit/demo-mode-gate.test.ts` — **7/7** (pre-existing, re-run green)
- `tests/unit/seed-guard.test.ts` — **7/7** (new)
- `tests/unit/production-posture.test.ts` — **6/6** (new)
- `tests/security/demo-isolation.test.ts` — **BLOCKED in this session**: its
  mandatory preflight throws when the dev server is unreachable, and
  `http://127.0.0.1:3000` has **no listener** in this sandbox (verified by
  curl + socket inspection). The suite is unmodified by this task and the
  failure occurs at collection, before any test executes — an
  environment outage, not a regression (this agent may not start `bun run dev`
  per the mission safety rules). Re-run it when the dev server is back.

New test names (for the record): seed-guard — "production without the opt-in
is refused", "the refusal is LOUD", "production WITH the deliberate opt-in …
is allowed", "loose opt-in spellings are NOT accepted", "development / test /
unset NODE_ENV are never gated", "exports the opt-in variable name and the
public demo password", "exits 1, prints the loud refusal, and writes NOTHING";
production-posture — "production with NO session secret is ABORTED",
"production REFUSES demo mode", "clean production posture PASSES at module
level", "demo mode is OFF BY DEFAULT", "production refuses the .env.example
placeholder secret", "development boots are untouched".

---

## 4. Session-secret & secure-cookie governance (code-verified)

- **Secret binding:** `src/lib/server/session.ts:32-40` — `SESSION_SECRET`
  binds **once at module load** from `process.env.ASAS_SESSION_SECRET`. The
  fallback is an **ephemeral per-process random secret with a loud
  `console.warn`** — acceptable only for local/test. In production the boot
  gate makes this fallback unreachable: missing (boot.ts:37-44), placeholder
  (boot.ts:45-49, the `.env.example` template values incl.
  `replace-me-openssl-rand-hex-32`), or < 32-char (boot.ts:50-55) secrets all
  **abort startup**. Evidence 01/02 + production-posture cases 1/5.
- **Rotation model:** the secret is a deployment environment variable
  (generate with `openssl rand -hex 32`); rotating it invalidates all
  `asas_user` cookies (HMAC-SHA256 over `userId.issuedAt`, session.ts:49) —
  users simply log in again. Never commit, never log, never reuse a value that
  was ever shared (`.env.example:1-3` policy pointer).
- **Cookie hardening:** `src/app/api/auth/login/route.ts:36-41` —
  `httpOnly: true`, `sameSite: "lax"`, `path: "/"`,
  `secure: process.env.NODE_ENV === "production"`, `maxAge: 7d` aligned with
  the server-side absolute `SESSION_MAX_AGE_MS` (session.ts:42). Plain-HTTP
  local development is unaffected (`secure` is production-scoped);
  same-origin CSRF enforcement (`assertSameOrigin`) remains the
  transport-independent layer.
- **Health observability:** `src/app/api/health/route.ts:57-62` reports
  `demoMode`, `demoModeMisconfigured`, `sessionSecretConfigured` (presence
  only — never the value). Production release checks:
  `health.demoMode === false` **and** `health.sessionSecretConfigured === true`.

---

## 5. Evidence index (`05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/evidence/a3-security/`)

| File | One-line summary |
|---|---|
| `01-boot-failfast-missing-secret.txt` | Production boot probe with no `ASAS_SESSION_SECRET` → exit 1, `SESSION_SECRET_MISSING` (isolated `env -i` child). |
| `02-boot-failfast-demo-mode.txt` | `NODE_ENV=production` + `ASAS_DEMO_MODE=1` (temp secret) → exit 1, `DEMO_MODE_PRODUCTION` — a rejection, not a warning. |
| `03-boot-clean-production.txt` | Clean production env → exit 0, `BOOT_OK violations=[]`; module-level health-contract mapping. |
| `04-migrate-only-zero-users.txt` | Fresh `/tmp` DB + `bunx prisma migrate deploy` (NODE_ENV unset) → migrations apply, **0 users / 0 orgs / 0 owners**. |
| `05-seed-refused-production-zero-users.txt` | Same DB + `NODE_ENV=production` seed → exit 1 loud refusal, counts unchanged at 0 (zero writes). |
| `06-seed-dev-works.txt` | NODE_ENV unset + seed on fresh `/tmp` DB → 8 users, 1 OWNER (CI's `bun run db:seed` shape intact). |
| `07-seed-explicit-optin.txt` | `ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION=1` → seed runs in production env (8 users); loose spelling `=true` refused (exit 1). |
| `08-provision-owner.txt` | Full `provision-owner` sequence: exit 2 (no DB), demo-password & weak-password refusals, happy path (1 OWNER, password never printed, hash fails `asas1234` verification), second run exit 1 conflict, dev DB untouched. |
| `09-vitest-targeted.txt` | Targeted vitest transcripts: 4 unit files 31/31 green; `demo-isolation` BLOCKED on the down dev server (documented, not a regression). |
| `10-prisma-cli-seed-paths.txt` | The exact CI command (`bun run db:seed` → `prisma db seed`, NODE_ENV unset) works end-to-end (exit 0, 8 users); the same Prisma-CLI command under NODE_ENV=production refuses (exit 1, zero writes). |

All disposable databases live under `/tmp/a3-evidence-work/`; the shared dev
database `db/custom.db` was never written by this task (verified — evidence
08g).

---

## 6. Residual risks / next actions

1. **C1 (BLOCKED here):** the full production *runtime* boot (`next build` +
   `next start`) must still be exercised once in an environment where building
   is allowed, re-running the §1 matrix against a real listening server
   (expect identical results — the gate is the same code path).
2. **Principal:** apply the `package.json` `db:deploy` split (§2.4) and
   optionally document `ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION` in `.env.example`.
3. **Re-run `tests/security/demo-isolation.test.ts`** once the dev server on
   :3000 is back up (it is a mandatory live-server suite, unmodified here).
4. `ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION` is intentionally an unsafe-by-design
   escape hatch for staging demos of the demo dataset itself; it is loud,
   strict-`"1"`, and documented here as the ONLY production seed bypass.
