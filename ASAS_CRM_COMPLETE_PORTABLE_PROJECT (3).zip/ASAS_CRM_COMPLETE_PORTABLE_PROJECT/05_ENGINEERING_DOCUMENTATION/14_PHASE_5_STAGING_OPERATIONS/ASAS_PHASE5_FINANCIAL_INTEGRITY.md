# ASAS Phase 5 — Financial Integrity (Agent 4, Task P5-W1-A4)

**Scope:** audit condition **C8** + findings **P4-M04**, **P4-L01 (P3-F3)**, **P4-L02**
**Verdict target:** resolve ACCEPT WITH CONDITIONS → the money law is single-sourced and boundary-tested, the direct-booking trail tells the truth, payment creation is idempotent against replayed submissions.
**Status:** IMPLEMENTED — the full targeted regression (15 suites / 290 tests, unit + security + contract, against the RUNNING dev server) is GREEN.

---

## 1. Money-law single-sourcing (C8 / P4-M04)

### 1.1 The decision

The authoritative home of the DZD money ceiling is **`src/lib/money.ts`** (NEW,
isomorphic — a bare constant, zero imports, importable from server code, the
client bundle and unit tests alike). `src/lib/server/validation.ts` re-exports
it as `MAX_MONEY_DZD` so every server site keeps the one established import
path; the UI imports `@/lib/money` directly (a `"use client"` component cannot
import the server validation module — it pulls `next/headers` + `@/lib/db`).
The ceiling VALUE is unchanged: **10_000_000_000 DZD (10 milliards)** — no
business reason exists to change it, per the Phase 5 verdict.

### 1.2 Site inventory (every grep hit audited — full transcript in
`evidence/a4-finance/01-money-cap-site-inventory.txt`)

| # | Site | Before | After | Test |
|---|------|--------|-------|------|
| 1 | `src/lib/money.ts` | — (NEW) | the authoritative constant | unit money-cap (identity ×2) |
| 2 | `src/lib/server/validation.ts:109` | local `export const MAX_MONEY_DZD = 10_000_000_000` | re-export from `@/lib/money` (import sites unchanged) | unit money-cap + validation |
| 3 | `src/app/api/finance/installments/route.ts:36` | **`.max(1e12)` — 100× the money law (THE bug)** | `.max(MAX_MONEY_DZD, "Montant hors limites")` | security money-cap TEST 1–2 |
| 4 | `src/app/api/finance/installments/[id]/route.ts:21` | **`.max(1e12)` — 100× (sibling bug)** | `.max(MAX_MONEY_DZD, "Montant hors limites")` | security money-cap TEST 3 |
| 5 | `src/lib/server/csv.ts:205` (`parseBudget`) | **`value > 1e12` — CSV import bypass (rows commit straight to DB)** | `value > MAX_MONEY_DZD` (import from `@/lib/money`) | unit money-cap + security money-cap TEST 6 |
| 6 | `src/app/api/targets/route.ts:33` | private `const MAX_AMOUNT_DZD = 10_000_000_000` twin | import `MAX_MONEY_DZD` (twin deleted) | security money-cap TEST 5 |
| 7 | `src/components/crm/settings/targets-section.tsx:49` | private `const MAX_AMOUNT_DZD = 10_000_000_000` twin (CLIENT) | `import { MAX_MONEY_DZD } from "@/lib/money"` (minimal diff — Agent 5 owns broader UI work) | defense-in-depth (server re-checks) |
| 8 | `src/app/api/reservations/[id]/route.ts:49` | inlined `.max(10_000_000_000, …)` literal | `.max(MAX_MONEY_DZD, "Montant trop élevé")` | security money-cap TEST 6 (reservations row) |
| 9 | `src/app/api/finance/payments/route.ts:24` | already `MAX_MONEY_DZD` (DB-12, prior wave) | unchanged — regression-guarded | security money-cap TEST 4 |
| 10 | `src/app/api/opportunities/[id]/route.ts` | uses `optionalMoney` (grep hit = comment) | unchanged — no private copy existed | existing suites |
| 11 | `src/components/crm/money-field.tsx:17` | comment mentions the number only | untouched (no code, not an owned file) | — |

After the fix, `rg '1e10|1e12|MAX_MONEY|MAX_AMOUNT_DZD' src/` shows the ONLY
remaining numeric literal at `src/lib/money.ts:18` (+ comments); every
enforcement site imports the constant.

### 1.3 Boundary laws proven

- **Max passes:** `optionalMoney` accepts exactly 10_000_000_000; `parseBudget`
  returns it; the installments/payments/targets/reservations routes pass the
  at-cap value through zod to their next guard (404 ghost-parent probes —
  zero DB writes).
- **Max + 1 rejected:** unit (optionalMoney, parseBudget) + every route.
- **1e12 rejected:** unit + every route (this was the installments/CSV hole).
- **Negative rejected:** unit + routes (pre-existing law, re-proven).
- **CSV row with 1e12 rejected:** `parseBudget` → `null` → `INVALID_BUDGET`
  row error (unit); live preview shows `summary.errors = 2` for 1e12 and
  max+1 rows and `valid: 1` for the at-cap row (security money-cap TEST 6).
- **Preserved valid amounts:** ordinary budgets (18M, "18M", "1800k", "18.5M DA")
  parse byte-identically; zero stays legal for optionalMoney.

**Deliberate behavior change:** CSV budget cells in (1e10, 1e12) previously
imported; they are now rejected as `INVALID_BUDGET`. That is the point of the
fix (the import path may no longer bypass the money law); the API path
(`optionalMoney`) always refused them.

---

## 2. Direct-booking semantics — documented contract (P4-L01 / P3-F3)

**The domain contract (verified against the code, then the fix chosen):**

The concept table in `src/lib/server/financial-semantics.ts` defines
`Opportunity.value` as the pipeline **ESTIMATE** and `Reservation.amount` as
the **AGREED contractual price**; the doctrine is explicit that there is
deliberately no synchronization between them while the deal is open, and the
ONE sanctioned alignment (`alignWonDealValue`) fires at the moment the deal
becomes CLOSED_WON. The sibling booking path (offer conversion) already
followed that contract — its stage row claims no value. A hold is also not
yet a sale (holds get cancelled/expired — nothing would restore an
overwritten estimate), and the closure security suite
(`tests/security/closure-value-consistency.test.ts`) encodes the contract as
asserted behavior.

**Therefore the defect was the TRAIL LYING, not the data failing to copy:**
the direct variant's `OPPORTUNITY_STAGE_CHANGED` row wrote
`after.value = reservation.amount` while the column was never written.

**The fix (smallest consistent):** the row now records the opportunity's
ACTUAL value on both sides plus the agreed price under its own key —
constructed through the NEW pure helper `bookingValueFacts()` in
`financial-semantics.ts` (the single sanctioned construction, per the DOM-03
pattern):

```ts
before: { stage: deal.stage, value: facts.value }            // the estimate
after:  { stage: "RESERVATION", value: facts.value,           // UNCHANGED estimate
          amount: facts.amount, booking: true }               // the agreed price
```

Booking still writes NO `Opportunity.value`. The brief's alternative
("align the value at booking") was considered and **rejected** on the code
evidence — the brief itself directed "verify against code, then confirm or
adjust"; the full derivation with citations lives in
`evidence/a4-finance/03-booking-semantics-decision.md`.

**Consequences:** closure behavior is byte-identical (the alignment still
fires exactly once, with its own audit row); offer conversion is
byte-identical; revenue attribution is untouched by construction (booking
never writes value — existing won deals cannot drift, and future won deals
still get value = agreed via the closure alignment); the `reservations-post`
fault still rolls back the reservation, apartment flip, stage advance and
trail — with the estimate provably untouched (`Opportunity.value` is never in
the transaction's write set).

---

## 3. Payment idempotency (P4-L02)

**Mechanism:** inside `recordPayment`'s existing `$transaction`, BEFORE any
money moves, the same fresh `tx.payment.findMany` re-read the balance
decision uses now also feeds a probable-duplicate scan (`findRecentDuplicatePayment`,
pure + exported). A match on the **business fingerprint** —
`recordedById + amount + method + reference + notes` (installment implicit;
`paidAt` deliberately excluded: the route stamps it server-side, and a
re-submit differing only in paidAt is exactly the near-duplicate to block) —
created within **`DUPLICATE_PAYMENT_WINDOW_MS = 60_000`** throws
**`409 DUPLICATE_PAYMENT`** with `details = { existingPaymentId, recordedAt }`.
Amount comparison is EXACT (a replay is byte-identical; any distinct amount
is a legitimate separate payment).

**Concurrency:** SQLite + Prisma interactive transactions serialize on the
write lock at `BEGIN` (verified empirically on a DB copy — a racing
transaction's first read observes the winner's committed row), so two
identical concurrent submissions land exactly one payment; the loser answers
409 naming the winner's id. No migration, no new column — existing Payment
columns only.

**Backward compatibility:** the F-06 atomicity law is untouched (payment +
installment stamp + audit + activity still commit together — the §41
`payments-post` fault site sits after the writes as before, and the gate
never swallows it: the fault probes carry distinct notes). Existing suites'
marker probes stay fingerprint-distinct. Legitimate separate payments within
the window (different amount / notes / actor / reference) still succeed; the
payable/over-collection/immutable-history laws are unchanged.

Full design: `evidence/a4-finance/05-idempotency-design.md`.

---

## 4. Attribution invariance proof

- `Opportunity.value` enters exactly three write paths: the opportunities
  POST/PATCH (explicit, audited B4), and `alignWonDealValue` at closure/
  manager-correction (audited `OPPORTUNITY_VALUE_CHANGED`). The booking path
  (`bookUnitInTx`) writes only `stage`/`stageChangedAt` — before AND after
  this change (grep-verifiable: the only `tx.opportunity.update` in the
  booking core carries `data: { stage, stageChangedAt }`).
- Hence existing won-deal revenue (the audited 236,200,000 DZD) cannot change:
  `tests/security/booking-semantics.test.ts` TEST 5 snapshots every
  pre-existing CLOSED_WON (id, value) before the suite and re-asserts each
  after the bookings/closures the suite performs; TEST 2 proves the closure
  alignment still lands value = agreed for a NEWLY won deal (12M estimate →
  15M agreed → won card 15M, one `OPPORTUNITY_VALUE_CHANGED` row with
  before/after).

---

## 5. Files

**Created:** `src/lib/money.ts`; `tests/unit/money-cap.test.ts`;
`tests/security/money-cap.test.ts`; `tests/security/payment-idempotency.test.ts`;
`tests/security/booking-semantics.test.ts`;
`05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/evidence/a4-finance/*` (7 files + this doc's parent).

**Modified:** `src/lib/server/validation.ts` (re-export),
`src/app/api/finance/installments/route.ts`, `src/app/api/finance/installments/[id]/route.ts`
(the 100× bug), `src/app/api/targets/route.ts`,
`src/components/crm/settings/targets-section.tsx` (constant swap only),
`src/app/api/reservations/[id]/route.ts`, `src/lib/server/csv.ts` (CSV cap),
`src/lib/server/financial-semantics.ts` (`bookingValueFacts` + the booking
trail law + the decision record), `src/lib/services/reservations.ts` (the
truthful audit row + `BookingOpportunity.value`), `src/lib/services/payments.ts`
(idempotency gate), `tests/unit/financial-semantics.test.ts` (+4),
`tests/unit/services-payments.test.ts` (+8).

**Untouched by design:** `src/app/api/finance/payments/route.ts` (already
fixed by DB-12 — regression-guarded only); `src/app/api/opportunities/[id]/route.ts`
(already `optionalMoney`); `prisma/**`, `scripts/**`, `package.json`, `.env`,
`next.config.ts`, retention/boot (never opened for write).

---

## 6. Test evidence (full targeted regression — GREEN)

**First wave (01:25Z):** unit suites green; the live-server suites were
BLOCKED at collection — the dev server was down throughout that window
(`evidence/a4-finance/server-down-preflight.txt`; noted, retried after 60s
and polled repeatedly — NOT restarted by this agent; the no-silent-skip law
behaved as designed).

**Retry wave (01:44Z — the server came back up externally):** the FULL
targeted regression ran against the live server. All 15 suites green.

| Suite | Result |
|---|---|
| `tests/unit/validation.test.ts` | ✓ 14 (unchanged) |
| `tests/unit/money-cap.test.ts` | ✓ **12 (new)** |
| `tests/unit/financial-semantics.test.ts` | ✓ **12 (+4)** |
| `tests/unit/services-payments.test.ts` | ✓ **19 (+8)** |
| `tests/unit/services-reservations.test.ts` | ✓ 10 (unchanged) |
| `tests/security/money-cap.test.ts` | ✓ **7 (new)** |
| `tests/security/payment-idempotency.test.ts` | ✓ **5 (new)** |
| `tests/security/booking-semantics.test.ts` | ✓ **5 (new)** |
| `tests/security/financial-atomicity.test.ts` | ✓ 5 (unchanged) |
| `tests/security/closure-value-consistency.test.ts` | ✓ 3 (unchanged) |
| `tests/security/offer-concurrency.test.ts` | ✓ 8 (unchanged) |
| `tests/security/fault-injection.test.ts` | ✓ 35 (unchanged — booking audit + payments gate paths re-proven) |
| `tests/contract/api.test.ts` | ✓ 10 (unchanged) |
| `tests/contract/services-contract.test.ts` | ✓ 10 (unchanged — payments contract) |
| `tests/security/permission-matrix.test.ts` | ✓ 135 (unchanged — booking path) |
| **TOTAL** | **15 files / 290 tests / 0 failures** |

Transcripts: `02-money-cap-boundary-tests.txt` (unit + live),
`04-booking-semantics-tests.txt`, `06-idempotency-tests.txt`,
`07-targeted-regression.txt` (the full run + a zero-residue DB check).

**Incident during the retry wave (disclosed):** the money-cap suite's FIRST
live run had two unstable probes — (a) the targets zero-write assertion
assumed month `2026-11` was empty (the seed legitimately carries 3 rows →
false failure; fixed with a before/after snapshot), and (b) the reservations
at-cap probe sent `commissionAmount: 1e10` ALONE, relying on the probe row's
commission state — on the seed's ACTIVE reservation (source already set) the
PATCH **committed** (HTTP 200), writing `commissionAmount=1e10` plus one
`COMMISSION_SET` audit row. Repaired immediately via Prisma (the documented
seed value `1160000` restored, `prisma/seed.ts:697`; the single spurious
audit row deleted) and the probe hardened to `{commissionAmount: 1e10,
commissionFrom: null}` — the §37 pairing law now refuses it deterministically
on ANY row state, before any write. All subsequent runs green, zero residue
(`07-targeted-regression.txt`).

---

## 7. Honest limitations

1. **First-wave live coverage was blocked by the dev-server outage** — the
   retry wave (this document's final state) ran the COMPLETE targeted
   regression against the live server: 15 suites / 290 tests green, with a
   marker-scoped zero-residue DB check after the run. The DB-pollution
   incident the first live money-cap run caused is disclosed in §6 (repaired
   + probe hardened).
2. **The duplicate window is time-based, not a persisted idempotency key.**
   A deliberate second collection with an identical fingerprint inside 60s
   is refused (conservative; the 409 names the blocking row). Outside the
   window the same fingerprint is accepted. A client-supplied idempotency
   token would be stronger but requires a schema change (out of bounds —
   `prisma/**` is not this agent's to edit).
3. **False-negative surface:** two different ACTORS submitting the same
   fingerprint within the window both land (by design — the actor is part of
   the fingerprint). Two rapid legit payments identical in every field but
   paidAt are refused until the window elapses or a field differs.
4. **`before.value` on the booking stage row is a NEW key** (the row
   previously carried `value` only in `after`): additive payload change, no
   consumer asserts the old shape; the audit viewer renders generic JSON.
5. **Booking-time value alignment was explicitly REJECTED** (see §2) — if
   the Principal's business position is that a direct booking must supersede
   the estimate, that is a domain-law change requiring an update to the
   financial-semantics concept table, the closure suite, and an un-align
   path for cancelled holds — a deliberate follow-up, not this wave's
   smallest fix.
