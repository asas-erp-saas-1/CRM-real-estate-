# ASAS CRM — Phase 5 / W1-A2: Database, Backup, Recovery & Retention

> **Provenance.** Agent 2 (Task `P5-W1-A2`) of the Phase 5 mission "Database, Backups,
> Recovery & Retention". This document resolves Phase 4 audit conditions **C5** (backup
> bootstrap defect + full backup/recovery/scheduling/offsite procedure) and **C7**
> (retention apply-gate timestamp defect), plus findings **P4-M01**, **P4-M02**, **P4-M10**.
> Every claim below is backed by an evidence transcript under
> `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/evidence/a2-backup/` (this session, sandbox `node v24.22.2`).

---

## 1. The backup command (unchanged contract, now bootstrappable)

```bash
bun run db:backup          # npm alias for: bash scripts/backup.sh
```

One command produces a **self-verifying backup set** in `db/backups/backup-<UTC-stamp>/`:

| Artifact | What it is |
|---|---|
| `db-<ts>.sqlite` | The database snapshot, produced by **`VACUUM INTO`** on a **read-only** source connection — page-consistent by construction, never a live file-copy (the project law: the live `db/custom.db` runs in delete-journal mode under the dev server, so a byte-copy can capture torn pages; VACUUM INTO asks SQLite itself to write a fresh self-contained file instead). |
| `docs-<ts>.tar.gz` | Tarball of `db/docs/` (plain files — no consistency protocol applies). |
| `manifest.json` | `runId`, compact UTC `ts` (`YYYYMMDDTHHMMSSZ`), `integrity` (verdict of `PRAGMA integrity_check` run **on the snapshot**), `census` (row counts of the six business tables), `files[]` (name + `sha256` + `bytes` per artifact), `keep`. |

**Failure semantics (unchanged):** any failed step exits non-zero — *a backup without
verified integrity is a failure, never a shipped artifact*. Retention runs as part of the
backup: keep the newest `ASAS_BACKUP_KEEP` (default 14), never delete anything younger
than 1 h. Only `backup-<stamp>` **directories** are managed; legacy `custom-*.db`
file-copies and everything else under `db/backups/` are never touched.

## 2. First-run bootstrap — the P4-M02 defect, fix, and evidence (condition C5)

**The defect (verified live, reproduced before fixing).** `scripts/backup.sh` mkdir'd only
`db/docs`; `scripts/lib/backup-run.mjs` created the backup target directory with
`mkdir(backupDir, { recursive: false })` (the same-second collision law). On a pristine
checkout **`db/backups/` does not exist**, so the *first-ever* `bun run db:backup` failed
with ENOENT before any snapshot work — the repo was in exactly that state at mission start
(`ls db/backups/` → "No such file or directory").

**The fix (smallest safe correction, both layers belt-and-braces):**

1. `scripts/backup.sh` now: `mkdir -p db/docs db/backups` — the parent namespace is
   bootstrapped by the entrypoint (bash semantics, preserving the one-command UX).
2. `scripts/lib/backup-run.mjs` now explicitly `mkdir(backupsRoot, { recursive: true })`
   **before** the inner `mkdir(backupDir, { recursive: false })` — the runner is safe even
   when invoked directly. The **inner directory creation stays NON-RECURSIVE**: an EEXIST
   there still means a concurrent run chose the same second and fails loudly (SQLite also
   refuses `VACUUM INTO` onto an existing file). The parent contains no per-run state, so
   recursive parent creation cannot mask a collision.

**Preserved invariants (nothing else changed):** VACUUM INTO consistency reasoning, SHA-256
manifest verification, integrity checks on the snapshot, the 1 h age guard, all restore
interlocks. No raw filesystem copies were introduced anywhere.

**Evidence:**

| File | Result |
|---|---|
| `evidence/a2-backup/01-first-run-defect-repro.txt` | Pre-fix reproduction in the isolated workspace `/tmp/asas-p5-a2`: `[backup] FAILED — ENOENT: no such file or directory, mkdir '…/db/backups/backup-20261107T010130Z'`, **exit 1**, `db/backups/` still absent afterwards. |
| `evidence/a2-backup/02-first-run-fixed.txt` | Same pristine workspace, fixed scripts: first-ever backup **exit 0**, `BACKUP OK → db/backups/backup-20261107T010157Z`, `integrity ok — PRAGMA integrity_check run ON THE SNAPSHOT`, census `users=8 leads=43 opportunities=21 reservations=8 apartments=46 documents=0`, manifest written; source DB sha256 **unchanged** (`f17deb10…ba8b`). |
| `evidence/a2-backup/03-live-backup.txt` | Post-fix **real** first-ever backup from the repo root: **exit 0**, artifact `db/backups/backup-20261107T010208Z/` (snapshot 1,064,960 bytes, docs tarball 108 bytes), integrity ok, census recorded, `retention kept=1 deleted=0`. `sha256 db/custom.db` **before = after = `f17deb1011be329f9db8546465b60521def54e60f7669ba48a2d16ccfd16ba8b`** — the live DB is untouched by a backup, by construction and by measurement. |

## 3. Manifest verification (what a backup must prove)

`manifest.json` is validated by `validateManifest()` (pure, vitest-covered in
`tests/unit/backup-manifest.test.ts`, 67 tests): `runId` non-empty; `ts` a compact UTC
stamp; `integrity` exactly `"ok"`; the six canonical census keys as non-negative integers;
**exactly** the two stamped artifacts whose stamps equal `manifest.ts`, each with a
64-lowercase-hex `sha256` and non-negative `bytes`; `keep` an integer ≥ 1. Restore-time
verification (`verifyFileEntry`) recomputes sha256 + size **of the files on disk** and any
mismatch is a fatal error naming both values. A census comparison (`compareCensus`) demands
the freshly-counted rows equal the manifest census exactly — count drift, missing keys and
extra keys (schema drift) are all differences.

## 4. Restore procedure + this session's drill PASS (condition C5)

```bash
# DRILL (recommended, non-destructive — writes ONLY under db/restore-drills/):
bash scripts/restore.sh --drill db/backups/backup-<ts>
# npm equivalent (picks the newest backup automatically):
bun run db:restore:drill

# LIVE RESTORE (destructive: overwrites db/custom.db + db/docs/) — requires BOTH flags:
bash scripts/restore.sh db/backups/backup-<ts> --confirm-restore --i-understand-this-overwrites-the-live-db
```

The drill restores the snapshot + docs tarball into `db/restore-drills/<ts>/`, re-verifies
integrity **on the restored copy**, and demands the census match the manifest
byte-for-manifest before printing `PASS`. The live path takes a VACUUM INTO **safety
snapshot of the current DB first**, replaces `db/custom.db` atomically (copy to a temp name
beside the target, then rename), re-extracts `db/docs/`, and re-verifies integrity + census
on the live file; the dev server must be restarted afterwards (it holds the replaced file's
old inode). Exit codes: `0` verified success · `1` verification failure · `2` interlock
refusal.

**This session's drill (evidence `06-restore-drill.txt`), against the live backup
`backup-20261107T010208Z`:**

```
[restore:drill] artifacts verified — sha256 + size match the manifest (db-…sqlite, docs-…tar.gz)
[restore:drill] restored db/restore-drills/20261107T010647Z/custom.db (byte-identical to the snapshot, sha256 80ed0fb60542e850…)
[restore:drill] integrity ok — PRAGMA integrity_check on the RESTORED copy
[restore:drill] census   users=8 leads=43 opportunities=21 reservations=8 apartments=46 documents=0 — MATCHES MANIFEST (…identical…)
[restore:drill] original db/custom.db — NOT TOUCHED (drill mode writes only under db/restore-drills/)
[restore:drill] PASS — drill restore verified end-to-end; live DB untouched
```

Exit code `0`; `sha256 db/custom.db` before = after the drill =
`f17deb1011be329f9db8546465b60521def54e60f7669ba48a2d16ccfd16ba8b`. The P4-I08
"explicit positional double-appends the path" quirk did **not** reproduce in this session —
the positional form resolved correctly (see §10 Honest limitations).

## 5. Retention policy + the apply-gate fix (P4-M01, condition C7)

**The policy (unchanged, `src/lib/server/retention.ts`):**

| Class | Horizon | Action |
|---|---|---|
| PROTECTED | forever | KEEP — financial/legal/commercial traceability; deletion WHERE-clauses exclude these rows **by construction** |
| OPERATIONAL | 730 d | ARCHIVE_THEN_DELETE (JSONL archive first) |
| DIAGNOSTIC | 90 d | DELETE (auth noise: `LOGIN_FAILED`, `LOGIN_LOCKED`, `LOGIN_QUICK`, `LOGOUT`; LoginFailure bookkeeping shares the horizon) |

Operator CLI only — never an API route, no background automation:

```bash
bun run retention:dry                    # the report (always safe, zero writes)
bun run retention:apply --confirm-purge  # the guarded destructive step
```

**The defect (P4-M01).** The apply-gate (`findFreshBackup`) read a backup's freshness from
the manifest `ts` field with `Date.parse()`. Manifests carry the **compact** stamp
`YYYYMMDDTHHMMSSZ` (e.g. `"20261106T185536Z"` — the format `formatStamp()` in
`scripts/lib/backup-logic.mts` emits); `Date.parse()` answers **NaN** on that basic-ISO
shape (verified: `Date.parse("20261106T185536Z")` → `NaN` in `node v24.22.2`). Result: no
real backup could ever satisfy the 15-minute freshness gate — the destructive apply was
**inert / fail-closed by bug**, and the old unit fixtures used ISO-8601 strings, masking
the defect from the suite.

**The fix.** New exported pure parser `parseManifestStamp(ts)`:

- exactly 16 chars — digits at positions 0–7 and 9–14, `'T'` at index 8, `'Z'` at index 15;
- constructs the instant via `Date.UTC(...)` from the explicit components;
- **round-trips** the constructed Date back to its UTC components and rejects ANY drift —
  `Date.UTC` silently rolls out-of-range fields over (month 13 → next January, Feb 30 →
  Mar 2, hour 24 → next day), so a rollover means the stamp was never a real instant;
- returns epoch-ms or `null`; `findFreshBackup` treats `null` exactly like an unreadable
  manifest ("not a backup we can trust" — the gate stays closed). No safeguard was
  weakened: the gate logic, 15-minute window, archive-first invariant and typed
  `--confirm-purge` confirmation are untouched.

**Test coverage (real vitest tests, `tests/unit/retention.test.ts`, production-format
fixtures built by the real emitter `formatStamp`):**

1. Fresh valid backup **authorizes** the expected operation — `retentionApply` runs the
   archive-first → delete sequence, reports the authorizing `runId`.
2. **Expired** backup does NOT authorize the unsafe operation — `REFUSED` before any DB call.
3. **Corrupt** manifest is rejected (unparseable JSON — fail-closed, zero DB calls).
4. **Missing** backup is rejected (no manifest / no backups dir).
5. **Invalid timestamp** is rejected (the old ISO shape, short stamps, month 13 / Feb 30 /
   hour 24 rollover traps — all refuse).
6. **Dry-run produces zero writes** — no `deleteMany` on any model, no JSONL archives.
7. **Existing interlocks remain fail-closed** — the original no-fresh-backup refusal test
   is retained verbatim and still passes, plus corrupt/invalid-evidence refusal variants.

Plus regression tests specific to the defect class: the old ISO fixture format is now
**rejected** by the parser (the mask that hid P4-M01 is forbidden); the parser round-trips
the real emitter `formatStamp(d) === parseManifestStamp` for every instant; the gate age
boundary (exactly 15 min authorizes, 1 s past refuses).

**Runs:** `bunx vitest run tests/unit/retention.test.ts tests/unit/backup-manifest.test.ts`
→ **93/93 green** (26 retention — 12 pre-existing retained + 14 new — and 67
backup-manifest untouched). Evidence: `04-retention-tests.txt`.

**Live probe (evidence `05-retention-dryrun-live.txt`):** `bun run scripts/retention.ts`
(dry-run, NO confirm flag) against the real backup from §2 — the previously-NaN path now
answers:

```json
"applyGuard": {
  "freshBackupFound": true,
  "backupAgeMinutes": 4,
  "backupRunId": "0ed076cb67ee4e4da60d7b46896b4e37",
  "requirement": "bun run db:backup (a verified backup younger than 15 minutes is mandatory before --apply)"
}
```

## 6. Scheduled backup configuration (systemd templates — NOT activated here)

Deployment artifacts (templates only; no cron, no timers were created or enabled in this
sandbox, per the mission safety rules):

- `deploy/systemd/asas-backup.service` — `Type=oneshot` run of `bash scripts/backup.sh`
  as a dedicated service user from an install prefix (`/opt/asas`), with
  `ConditionPathIsDirectory` / `ConditionPathExists` / `ConditionPathIsReadWrite` guards,
  `ASAS_BACKUP_KEEP` environment, journalled transcript, hardening
  (`NoNewPrivileges`, `ProtectSystem=strict`, `ReadWritePaths=/opt/asas/db`), and a
  README-header install runbook.
- `deploy/systemd/asas-backup.timer` — `OnCalendar=*-*-* 02:30:00` (daily),
  `Persistent=true` (missed-at-schedule backups run at boot — no silent gaps),
  `WantedBy=timers.target`, plus a weekly operator checklist (backups present, every
  manifest `integrity: ok`, periodic drill, offsite copy).

Install steps are in the file headers (copy to `/etc/systemd/system/`, `daemon-reload`,
`enable --now asas-backup.timer`). **Activation is an owner action** — deliberately not
performed in this sandbox. Both templates pass `systemd-analyze verify` (systemd 257 —
exit 0, zero warnings): they are syntactically valid units, merely not installed here.

## 7. Offsite backup procedure (design — not executed, no credentials)

**Goal:** survive host-level loss (disk, ransomware, site) with RPO ≤ 24 h and RTO < 1 h.

**Design (rsync over SSH, placeholder host):**

```bash
# 1. ON THE OFFSITE HOST (backup.example.net) — prepare, once:
#    a dedicated low-privilege account whose only right is write access to
#    /srv/asas-offsite/ (no shell commands beyond the forced rsync command):
sudo useradd --system --create-home --home-dir /srv/asas-offsite asas-offsite
sudo install -d -o asas-offsite -g asas-offsite -m 700 /srv/asas-offsite

# 2. ON THE APP HOST — after each scheduled backup (chained to the systemd unit
#    or run manually), push ONLY complete verified backup dirs:
OFFSITE=asas-offsite@backup.example.net:/srv/asas-offsite
rsync -a --delete-during \
      --include='backup-*/***' --exclude='*' \
      /opt/asas/db/backups/ "$OFFSITE/daily/"
#    (never rsync a half-written dir: the manifest is written LAST by the
#     runner, and the --include pattern copies only backup-*/ trees; a dir
#     without manifest.json is never considered restorable anyway)

# 3. OFFSITE ROTATION (on the offsite host, e.g. via its own systemd timer):
#    keep 14 daily + 8 weekly (Sunday) + 6 monthly snapshots:
#      daily/  ← rsync target            (prune to 14 newest backup-*/ dirs)
#      weekly/ ← copy of the Sunday daily (prune to 8)
#      monthly/← copy of the 1st-of-month daily (prune to 6)
#    Pruning uses the same law as the local guard: sort by stamp name,
#    keep newest N, never touch anything younger than 24 h offsite.

# 4. OFFSITE VERIFICATION (the receipt that makes the copy real):
#    on the offsite host, for the newest dir:
sqlite3 db-<ts>.sqlite 'PRAGMA integrity_check;'        # must print ok
sha256sum db-<ts>.sqlite docs-<ts>.tar.gz               # must equal manifest.json
#    plus a quarterly restore DRILL on a scratch machine:
#      bash scripts/restore.sh --drill <dir> → expect the PASS line.

# 5. MONITORING: alert when the newest offsite backup-<stamp> is > 36 h old
#    (missed schedule or broken ssh path) — e.g. a systemd timer checking
#    `find /srv/asas-offsite/daily -maxdepth 1 -name 'backup-*' -mmin -2160`.
```

**Notes:** SSH auth is by restricted key (`command="rsync --server …"` forced-command
prefix, `no-pty`, `from=` scoping) — keys are provisioned by the operator, never stored in
the repo. The `sqlite3` CLI in step 4 may be replaced by `node -e` + `node:sqlite` on
hosts without it. No part of this procedure was executed in this sandbox.

## 8. Recovery verification evidence table (this session)

| # | Verification | Evidence file | Verdict |
|---|---|---|---|
| 1 | Pre-fix first-run ENOENT reproduction (isolated workspace) | `01-first-run-defect-repro.txt` | REPRODUCED (exit 1, ENOENT) |
| 2 | Post-fix first-ever backup (isolated workspace) | `02-first-run-fixed.txt` | PASS (exit 0, integrity ok, source untouched) |
| 3 | Post-fix first-ever backup (real repo, live DB) | `03-live-backup.txt` | PASS (exit 0; live DB sha256 before = after) |
| 4 | Targeted unit suites (retention + backup-manifest) | `04-retention-tests.txt` | PASS 93/93 |
| 5 | Live retention dry-run gate probe (fresh real backup recognized) | `05-retention-dryrun-live.txt` | PASS (`freshBackupFound: true`, runId + age 4 min) |
| 6 | Restore drill on the live backup | `06-restore-drill.txt` | PASS (manifest verified, sha256 verified, integrity ok, census matches, original untouched) |

`db/custom.db` sha256 **before the whole mission**:
`f17deb1011be329f9db8546465b60521def54e60f7669ba48a2d16ccfd16ba8b` —
**after every operation in this session** (backup, dry-run, drill):
`f17deb1011be329f9db8546465b60521def54e60f7669ba48a2d16ccfd16ba8b` — identical.

## 9. P4-M10 — retiring the unsafe `db:snapshot` alias (Principal action)

`package.json` currently defines:

```json
"db:snapshot": "mkdir -p db/backups && cp db/custom.db \"db/backups/custom-$(date +%Y%m%d-%H%M%S).db\" && echo \"snapshot → db/backups/\" && ls -1t db/backups/ | head -3",
```

This is a **raw file-copy of the live DB** — exactly what the project's own consistency
law forbids (torn-page risk on a journal-active database; no integrity check; no manifest;
the copies are invisible to retention, which only manages `backup-*/` directories).

**Verified this session:** the approved backup implementation is a drop-in safe substitute
with the same user-visible outcome (a timestamped backup artifact under `db/backups/` +
a listing, exit 0 — evidence 03), plus verified integrity, SHA-256 manifest and retention.

**Recommended replacement line for the Principal to apply in `package.json`:**

```json
"db:snapshot": "bash scripts/backup.sh",
```

The raw-cp behavior must be **retired** (deleted, not kept alongside) — any continued use
of `cp` against the live `db/custom.db` violates the backup consistency law. (Agent 2 does
not own `package.json`; this is the documented hand-off.)

## 10. Honest limitations

- **Scheduling is NOT activated anywhere.** The systemd service/timer are templates under
  `deploy/systemd/`; no cron job, timer or background automation was created or enabled in
  this sandbox. Activation is an owner action (runbook in the unit headers).
- **Offsite backup is design-only** (§7): not executed, no credentials exist in any file,
  the host is a placeholder.
- **P4-I08 did not reproduce in this session:** `bash scripts/restore.sh --drill
  db/backups/backup-20261107T010208Z` (explicit positional, the same form
  `db:restore:drill` computes) resolved correctly and exited 0. If a host ever observes the
  double-append refusal (exit 2), the documented fallback is the npm form
  (`bun run db:restore:drill`) — the interlock refusal is safe by design.
- The live retention apply (`--confirm-purge`) was **never** executed against real data
  (mission safety rule); the apply-gate was verified via unit tests + the dry-run probe,
  which exercises the same `findFreshBackup` path.
- The full 772-test suite was not re-run by this agent (mission rule: targeted vitest
  only); the two targeted files are green (93/93) and no file outside the owned set was
  modified.
- Backup artifacts (`db/backups/`, `db/restore-drills/`) are git-ignored (verified in the
  P1 deliverable); the sandbox keeps the session's real backup on disk for the Principal's
  inspection.
