# ASAS Phase 5 — Staging Hosting Architecture (condition C2 / P4-H02)

**Task:** P5-W2-A1 — deployment architecture, build & CI package.
**Agent:** 1 (implementation engineer). **Date:** 2026-11-07.
**Decision recorded:** single-node Linux VPS + Docker + persistent storage is
the sanctioned Phase 5 staging hosting model (Principal decision, implementing
Phase 4 condition C2 / finding P4-H02). **No serverless migration this phase.**
**Baseline:** 772/772 tests · Phase 4 verdict ACCEPT WITH CONDITIONS.
Nothing in this document was executed in the sandbox (no docker daemon, no
build — standing rules); this is the architecture decision record plus the
on-disk deployment package whose first execution is condition C1.

---

## 0. Artifacts this decision produces

| Artifact | Role |
|---|---|
| `Dockerfile` | multi-stage image: Bun 1.3.14 builder (install → prisma generate → **`bun run build`** — where the first-ever production build executes) → Node 22 runtime (standalone server + ops tooling), non-root, HEALTHCHECK on `/api/health` |
| `.dockerignore` | build-context law: no `db/`, no `.env*`, no `.git`, no local `.next`/`node_modules` — a database or secret can never enter an image |
| `docker-compose.staging.yml` | the single-node deployment: restart policy, `mem_limit: 4g`, loopback-only port publish, `.env.staging` env_file, named volume `asas-data:/app/db`, healthcheck, capped json-file logging |
| `.env.staging.example` | every runtime variable with placeholder + policy comments (DATABASE_URL absolute-in-volume, session-secret generation/rotation, demo-mode fail-fast, seed guard) |
| `deploy/README-STAGING.md` | the reproducible runbook: prerequisites → **C1 entry gate (verbatim)** → first boot (migrate → `db:owner` → health) → backups → restore → upgrade → rollback → monitoring → troubleshooting |
| `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md` | reframed: hosting-decision warning header + the four incompatibilities; Vercel content retained as the "if you must" path |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/PRODUCTION_READINESS.md` | P4-M07 stale rows refreshed against verified reality |

---

## 1. The four single-instance mechanisms and why single-node satisfies them

Phase 4 (P4-H02, verified by code read) established that this application is
**single-instance by design in four load-bearing places**. A single long-lived
container with persistent storage satisfies every one of them *by
construction* — no rework, no behavior change:

| # | Mechanism (file citation) | Serverless failure mode | Single-node behavior |
|---|---|---|---|
| 1 | **In-process expiry scheduler** — `src/lib/server/expiry-scheduler.ts:36` starts a 60 s `setInterval` sweeper at server boot, anchored on `globalThis`, imported from `src/instrumentation.ts` (ENG-07: sweeps tick from server START) | scale-to-zero / archived instances → sweeps silently stop; past-due holds keep locking apartments (the D9 regression) | one process, always running under `restart: unless-stopped`; the sweeper ticks from boot; the lazy sweep on GET /api/notifications remains the idempotent backstop after any restart |
| 2 | **Process-local rate limits** — `src/lib/server/lead-capture.ts` (capture token/IP sliding windows in module-level `Map`s), login lockout window state in `src/lib/server/auth.ts` (rows in DB, window in memory) | per-instance budgets multiply (N instances = N× the intended limit) | one process = exactly one budget; restart resets are the documented, accepted trade-off (P4-L03) |
| 3 | **In-process observability + cache** — `src/lib/server/obs.ts` (per-route ring buffers, `globalThis`-anchored), `src/lib/server/notification-cache.ts` (scoped TTL cache, `globalThis`-anchored) | metrics/cache reset per instance and per cold start → no operational truth | one process = one contiguous metrics truth since boot; restart resets are documented (P4-L12) and health/uptimeSec covers the restart forensics |
| 4 | **SQLite + local document storage** — Prisma `provider = "sqlite"` (`prisma/schema.prisma`), DB at `db/custom.db`, uploads at `DOCS_DIR = <cwd>/db/docs` (`src/lib/server/documents.ts:19`) | read-only filesystem except ephemeral `/tmp` ≤500 MB → no database, no uploads at all | the named volume `asas-data:/app/db` puts DB + documents + backups on persistent host storage that survives restarts AND container replacement |

**The decision consequence:** every mechanism above keeps its documented
single-instance law (D-002 observability posture, over-engineering ban — no
Redis, no cron service, no metrics sink introduced). What changes is only
*where the single process runs* (a container) and *where its state lives* (a
volume). The alternative (Vercel) is a rework project, not a configuration:
scheduler → external cron; rate limits → shared store; obs/cache → external
sink + policy; storage → PostgreSQL + object storage. That path remains
documented (VERCEL_SETUP.md) but is **not** the Phase 5 model.

## 2. Persistent-storage design

```
staging host
└── docker engine
    └── container asas-crm  (image asas-crm:staging, non-root `node`)
        ├── /app/.next/standalone/server.js   ← ENTRYPOINT: node .next/standalone/server.js
        │     (server.js chdirs here at boot — verified Next 16.1.3 template)
        │     ├── .next/static/  ┐ copied in by the Dockerfile (standalone
        │     ├── public/        ┘ does NOT trace these — Next.js contract)
        │     └── db -> /app/db  (symlink: DOCS_DIR = <cwd>/db/docs lands on the volume)
        ├── /app/node_modules   ← production tree: prisma CLI + @prisma/client
        ├── /app/prisma         ← schema + 25 migrations (migrate deploy in-image)
        ├── /app/scripts        ← backup.sh / restore.sh (+ node runners)
        └── /app/db             ← named volume asas-data  ★ ALL durable state ★
              ├── custom.db (+ -wal/-shm)   SQLite database
              ├── docs/                      uploaded document binaries
              ├── backups/backup-<ts>/       VACUUM INTO snapshots + verified manifests
              └── restore-drills/            non-destructive drill output
```

**What survives restart and what survives replacement — the same set (by
design):** the volume holds the database, the uploaded documents, the backup
history and the drill output. The image is stateless and disposable: a new
image tag (upgrade or rollback) mounts the same volume and serves the same
data. Nothing durable ever lives in a container layer.

**Path-correctness verification (evidence 04):**
- `DATABASE_URL` is an **absolute** container path (`file:/app/db/custom.db`,
  `.env.staging.example`) — unambiguous for both the prisma CLI and the query
  engine; the dev `.env` already uses the absolute form (`file:/home/z/.../db/custom.db`),
  so this is the proven pattern, not a new one.
- `scripts/backup.sh` does `cd "$(dirname "$0")/.."` (= `/app` in the image)
  and bootstraps `db/docs` + `db/backups` — i.e. the volume; the runner
  snapshots the `DATABASE_URL` DB and tars `db/docs` — the volume.
- `documents.ts` computes `DOCS_DIR` from `process.cwd()`; the standalone
  server chdirs to `/app/.next/standalone`, so the Dockerfile creates the
  `/app/.next/standalone/db → /app/db` symlink — the one bridging step that
  keeps upload writes on the volume (verified against the installed Next
  16.1.3 `server.js` template containing `process.chdir(__dirname)`).
- Volume ownership: `/app/db` is pre-created `node:node` in the image, so the
  named volume inherits non-root ownership at first mount (docker's
  volume-initialization copy) — the classic root-owned-volume EACCES trap is
  pre-empted.

**Why ONE volume:** a single `asas-data` volume guarantees "back up the
database" and "back up the documents" can never silently diverge (they are one
`VACUUM INTO` + one tarball in one verified manifest — the existing backup
tooling's contract). Splitting (docs on cheap storage, backups on dedicated
media) is a documented future option, not a Phase 5 need.

## 3. Memory sizing (measured evidence)

| Fact | Source |
|---|---|
| Dev-server steady RSS ~2.0–2.5 GB (health `rssMb:2031` post-restart; `rssMb:2535` observed) | Phase 4 audit, live health probes |
| OOM kill at **2.55 GB** anon-RSS (`Out of memory: Killed process 1898 (next-server)`, `anon-rss 2,551,908 kB`) on a 4 GB host — while a concurrent ~1.3 GB bun workload ran | Phase 4 audit, P4-H01 (witnessed by 5 agents) |
| Production standalone RSS | **UNMEASURED** — `next start` class is typically leaner than Turbopack dev, but no honest number exists before C1 |

**Container limit `mem_limit: 4g`:** measured dev-class ceiling (2.55 GB) +
~1.4 GB headroom, deliberately conservative *pending the first production
reading*; the limit plus `restart: unless-stopped` converts the P4-H01
"OOM-kill with no auto-restart" incident class into a bounded, self-healing
event. **Host ≥ 8 GB** (audit recommendation, treated as sizing guidance with
the measured evidence attached, not a universal requirement): the container
limit, the docker daemon, and any reverse proxy must fit the host; a 4 GB
host re-creates the observed kill. **Re-sizing procedure after C1:** read
`rssMb` from `/api/health` under real load for a few days → set the limit to
≈1.5–2× steady-state (runbook §8).

## 4. Restart & health policy

- **Restart:** `restart: unless-stopped` — crash, OOM, and host reboot all
  self-heal; deliberate `docker compose down` stays down (ops intent wins).
  This is the watchdog Phase 4 found missing (P4-H01: "no auto-restart
  watchdog fired").
- **Health:** docker HEALTHCHECK + compose healthcheck probe the app's own
  contract `GET /api/health` → `dbOk === true` (pure `node fetch` — the slim
  runtime image ships no curl/wget). Interval 30 s / timeout 5 s / retries 3 /
  **start_period 60 s** (generous: standalone boot + route loading + P0-3 boot
  gate + first DB probe on cold disk; failures inside start_period never count
  toward the retry budget). Three consecutive failures ≈ 90 s of real
  unhealthiness — one bad probe never flaps the container.
- **The P0-3 boot gate rides along:** every container start re-runs
  `assertProductionEnvironment` (via instrumentation) — a placeholder session
  secret or `ASAS_DEMO_MODE=1` crashes the boot *by design*; the deployment
  cannot silently start misconfigured.
- **Expiry-scheduler continuity:** the in-process sweeper restarts with the
  process; sweeps missed during downtime run lazily on the first
  GET /api/notifications / reservations / offers (idempotent,
  status-preconditioned — no double-close risk, per the domain audit).

## 5. Build & image architecture

Two stages (full reasoning inline in the `Dockerfile`):

1. **builder** (`oven/bun:1.3.14` — pinned to `packageManager` + `bun.lock` +
   the CI's Bun version): `bun install --frozen-lockfile` → `bunx prisma
   generate` → `bun run build`. **This is where condition C1's first-ever
   production build executes** (staging host / CI runner — never the sandbox).
   Dependencies are installed before source is copied (layer caching), prisma/
   precedes install (bun's trusted postinstall generates the client).
2. **runtime** (`node:22-bookworm-slim`): Node runs the standalone server
   exactly per the `start` contract (`node .next/standalone/server.js` — the
   tree is kept at the same repo-relative path). The bun binary is copied in
   (no curl|sh) so the image is ops-complete: `bunx prisma migrate deploy`
   (first boot / upgrades), `bun run db:owner` (initial OWNER provisioning),
   `bash scripts/backup.sh` (node runner — Node 22 has the `node:sqlite`
   engine the backup scripts verified in this very sandbox). A production
   `node_modules` tree provides the prisma CLI + client (prisma is a runtime
   dependency of this project — the P4-L15 wart becomes the enabler).
   Static assets (`.next/static`, `public/`) are copied **into** the
   standalone tree — the documented Next.js standalone contract (they are not
   traced), verified in evidence 04. Non-root `USER node`, `EXPOSE 3000`,
   `ENV NODE_ENV=production PORT=3000 HOSTNAME=0.0.0.0` (PORT/HOSTNAME are the
   two env vars the standalone server template reads).

## 6. Condition C1 — the external entry gate

C1 is **BLOCKED in this sandbox** by two standing environment facts: `next
build` is forbidden here, and no docker daemon / git remote exists. The
sanctioned execution vehicle is therefore external, in this order:

1. **CI build leg** (when a git remote exists): `.github/workflows/ci.yml`
   `static-gates → Production build` step runs `bun run build` on
   ubuntu-latest — the green step log is the first C1 evidence artifact.
   Verified step-by-step in evidence 01; the workflow is clean (`branches:
   [main]`) and requires no edit.
2. **Staging host full gate** (the authoritative C1 procedure — verbatim in
   `deploy/README-STAGING.md` §2): `docker compose -f
   docker-compose.staging.yml build` → `up -d` → `curl -fsS
   http://127.0.0.1:3000/api/health | jq -e '.dbOk == true and .demoMode ==
   false'` → record the build log + health JSON as the C1 receipts (plus the
   C3 quick-login refusal probe).

Expected CI evidence once a remote exists: (a) a green "Production build"
step log in the Actions run; (b) from the staging host, the standalone boot +
`/api/health` JSON showing `dbOk:true`, `demoMode:false`, `nodeEnv:"production"`,
`migrations:25`. CI itself does not boot the artifact (the 772-test suite
boots a dev server by design) — the boot+health leg is the staging host's,
which is exactly how the Phase 4 gate was phrased.

## 7. Security posture of the package

- **No secrets in any artifact:** `.env.staging` (git-ignored via `.env*`) is
  the only secret carrier, loaded at runtime via compose `env_file`; the
  Dockerfile/compose/example contain placeholders + generation commands only.
  `.dockerignore` keeps `.env*` and `.z-ai-config` out of the build context
  entirely.
- **No database in the image:** `db/` is dockerignored unconditionally — the
  image is stateless by construction; the PII-bearing SQLite file exists only
  on the volume.
- **Non-root container** (`USER node`), loopback-only port publish (the
  TLS-less app is not internet-facing by default; the documented Caddy edge
  owns TLS + body limits), capped logs, `restart` policy, and the P0-3 boot
  gate on every start.
- **Demo-mode law carried into deployment:** `.env.staging.example` ships
  `ASAS_DEMO_MODE=0` with the fail-fast explanation; the seed guard
  (`ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION` unset) plus the runbook's
  `db:owner`-only provisioning implement condition C4 on this path.

## 8. Known limitations (honest register)

1. **Nothing executed:** no docker build/run, no server boot, no CI run
   happened in this sandbox — the package is correct-on-disk, verified by
   contract analysis (evidence 01–04) and parse validation. First execution
   is C1 itself.
2. **Production RSS unmeasured** — sizing derived from dev-server
   measurements; re-size after C1 (§3).
3. **`bun install --production` layer behavior** (prisma engine download,
   trusted postinstalls) is documented from bun/Debian contracts, not
   observed — the build log at C1 is the confirmation.
4. **`.env.staging.example` is currently git-ignored** by the `.env*` rule —
   committing the template requires the Principal-owned one-line negation
   `!.env.staging.example` in `.gitignore` (outside this agent's file
   ownership; reported, not edited).
5. **Single point of failure is the model:** one container, one host — the
   documented trade-off that buys compatibility with all four single-instance
   mechanisms. HA/multi-instance is explicitly out of scope for Phase 5.
