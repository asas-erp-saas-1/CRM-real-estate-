# P5-W1-A4 — Payment idempotency design (P4-L02)

Date: 2026-11-07 · Agent: A4 (financial integrity) · Status: DESIGNED + IMPLEMENTED

## The finding

`recordPayment` (`src/lib/services/payments.ts`) let a replayed submission
(double-click / double-submit below the remaining balance) create a second
`Payment` row — only `EXCEEDS_REMAINING` capped totals, so identical
submissions that each fit the balance both landed.

## The mechanism (pre-approved design, refined with justification)

**Where:** INSIDE the payment-creation `$transaction`, BEFORE any money
moves, riding the SAME fresh `tx.payment.findMany` re-read the balance
decision already performed (zero extra queries; the select grew the
fingerprint columns).

**Fingerprint — the business payload a replay repeats verbatim:**

```
(installmentId — implicit, the query scope)
recordedById  = user.id
amount        = body.amount          (EXACT comparison — see below)
method        = body.method
reference     = body.reference ?? null
notes         = body.notes ?? null
```

`paidAt` is deliberately EXCLUDED: the route defaults it to server `now`
when absent, so two replays carry different stamps — fingerprinting on it
would defeat detection; and a re-submission differing ONLY in `paidAt` is
exactly the near-duplicate row this law exists to prevent. Including
`reference`/`notes` (a refinement of the brief's "same amount, same actor"
sketch, with justification): the seeded test probes and the operator's
deliberate follow-up payments carry distinct markers/notes — identical
notes+reference+amount+method+actor+line within the window is the
double-click signature and nothing else in practice.

**Window:** `DUPLICATE_PAYMENT_WINDOW_MS = 60_000` (a double-click lands
well inside a minute; outside the window the same fingerprint is accepted
again — a legitimate repeated collection).

**Refusal:** `409 DUPLICATE_PAYMENT` with
`details = { existingPaymentId, recordedAt }` — the replayed request can
never silently create a second Payment; the operator sees exactly which row
blocked them. The refusal happens pre-write and leaves no audit/activity
trail (guard semantics — consistent with INSTALLMENT_NOT_CALLED and
EXCEEDS_REMAINING).

**Amount comparison is EXACT (`===`), not epsilon-based:** a replay is
byte-identical; any distinct amount (even a centime apart) is a legitimate
separate submission that must succeed. The 0.01 DZD `MONEY_EPSILON` belongs
to the BALANCE law (REAL-sum drift), not to identity.

## Concurrency guarantee (why "exactly one" holds)

SQLite + Prisma interactive transactions serialize on the write lock at
`BEGIN` (verified empirically on a DB copy: two concurrent
read→sleep→write transactions ran fully serialized — the second's first read
observed the first's committed row). A racing replay therefore blocks at its
`BEGIN`, then re-reads the winner's committed payment and refuses with 409.
`tests/security/payment-idempotency.test.ts` TEST 3 proves it over the live
API: two identical `Promise.all` submissions → exactly one 201 + one 409
`DUPLICATE_PAYMENT` (details.existingPaymentId = the winner's id) + exactly
ONE Payment row.

No new Prisma migration and no new column: the gate uses existing Payment
columns (`installmentId`, `recordedById`, `amount`, `method`, `reference`,
`notes`, `createdAt`) only.

## Backward compatibility

- The payment create + installment stamp + `PAYMENT_RECORDED` audit +
  `PAYMENT` activity still commit in ONE transaction (F-06 unchanged) —
  re-proven by `tests/security/financial-atomicity.test.ts` TEST 2 and the
  new TEST 4 (the `payments-post` fault channel still 500s and rolls
  everything back; the gate never swallows the fault because the fault
  probe's fingerprint is fresh).
- Existing suites' probes stay distinct by their markers
  (`P0-5-PROBE` vs `P0-5-FAULT` vs `P1-SVC-PAY` …): none collides with
  another fingerprint, so no existing green test flips.
- Legitimate separate payments within the window still succeed (different
  amount / notes / actor / reference): TEST 2.
- The immutable-history law is untouched: on a PAID line the payable gate
  still fires first (409 INSTALLMENT_ALREADY_PAID — TEST 5).

## Guarantees summary

| Scenario | Result |
|---|---|
| Replay identical payload < 60s | 409 DUPLICATE_PAYMENT + existingPaymentId; exactly 1 row |
| Two concurrent identical payloads | one 201 + one 409; exactly 1 row |
| Same line, different amount/notes/actor/reference < 60s | 201 (legitimate) |
| Identical payload ≥ 61s later | 201 (window elapsed) |
| Fault-injected create | 500 FAULT_INJECTED; full rollback (gate passed, fault fired) |
| Over-collection / settled line | pre-existing laws unchanged (422 EXCEEDS_REMAINING / 409 INSTALLMENT_ALREADY_PAID) |

## Test evidence

- Pure law: `tests/unit/services-payments.test.ts` —
  `findRecentDuplicatePayment` describe block (window constant, match,
  every distinguishing field, null-normalization, 59s/61s boundary, paidAt
  exclusion, empty history).
- Live law: `tests/security/payment-idempotency.test.ts` TEST 1–5
  (sequential replay, legitimate separations, concurrent race, fault
  channel, PAID stamp + immutability).
