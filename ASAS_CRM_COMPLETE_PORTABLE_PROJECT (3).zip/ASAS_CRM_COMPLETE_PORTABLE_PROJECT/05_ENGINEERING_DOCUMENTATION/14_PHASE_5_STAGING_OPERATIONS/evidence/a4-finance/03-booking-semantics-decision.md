# P5-W1-A4 — Booking-semantics decision (P4-L01 / P3-F3)

Date: 2026-11-07 · Agent: A4 (financial integrity) · Status: DECIDED + IMPLEMENTED

## The finding

Phase 4 flagged (`src/lib/services/reservations.ts`, the direct variant's
stage-advance audit row — was line ~609):

```ts
after: variant === "direct"
  ? { stage: "RESERVATION", value: reservation.amount, booking: true }   // ← the lie
  : { stage: "RESERVATION", booking: true, offerId: input.offerId },
```

The direct-booking trail wrote `after.value = reservation.amount` — the
reservation's AGREED price presented as the opportunity's `value` — while
`Opportunity.value` was never written by the booking (the stage update at
`tx.opportunity.update` writes only `stage`/`stageChangedAt`). Trail and data
disagreed. This is DOM-03 finding (2), flagged in
`src/lib/server/financial-semantics.ts` and left to the file's owner.

## The domain contract (verified against the code — citations)

The authoritative concept table in `src/lib/server/financial-semantics.ts`
(§THE CONCEPT TABLE) defines three DIFFERENT money concepts:

| Concept        | Field              | Meaning |
|----------------|--------------------|---------|
| Pipeline ESTIMATE | `Opportunity.value`   | Pre-deal DZD estimate; human/lifecycle-set; NOT the contract |
| AGREED PRICE   | `Reservation.amount` | The agreed contractual price of the hold; "the truth for the money path" |
| Deal ECONOMICS | §37/§38 commission/incentive family | The agency's margin, never the deal price |

The same file's doctrine (verbatim): *"There is deliberately NO silent
synchronization between them at any stage. The ONE sanctioned alignment
(below) happens at the moment the deal becomes CLOSED_WON"* — i.e.
`alignWonDealValue`, called by `validate_closure`
(`src/lib/server/reservation-lifecycle.ts:299`) and by the manager
CLOSED_WON correction path (`src/app/api/opportunities/[id]/route.ts`).
While a deal is OPEN, estimate ≠ agreed is legitimate commercial reality
(the negotiated price vs the pipeline's working number).

Three further code facts pinned the contract:

1. **The sibling booking path agrees.** Offer conversion
   (`src/lib/server/offer-lifecycle.ts` → the SAME `bookUnitInTx` core)
   writes `after: { stage, booking, offerId }` — NO value claim, NO value
   write. The offer path is the reference shape for what a booking trail
   may state; only the direct variant's row lied.
2. **A hold is not yet a sale.** The two-step closure
   (request_closure → validate_closure) exists precisely because holds get
   CANCELLED/EXPIRED; `findClosurePriceSource` deliberately treats
   CANCELLED/EXPIRED rows as non-price-sources. A booking-time value write
   would leave the estimate permanently replaced by a DEAD hold's price —
   no path would restore it (a new inconsistency class).
3. **The closure security suite encodes the contract.**
   `tests/security/closure-value-consistency.test.ts` TEST 1 asserts the
   CLOSURE-time alignment row (before 12M → after 15M at validate_closure);
   TEST 3 asserts ZERO `OPPORTUNITY_VALUE_CHANGED` rows for a booked deal
   whose value is set explicitly at closure. A booking-time alignment
   would make TEST 1's alignment a no-op and TEST 3's zero-count fail —
   the suite (not editable by this agent) is the contract's enforcement.

## The decision

**The trail tells the truth; the data does not mimic the trail's old lie.**

Direct booking keeps writing NO `Opportunity.value` (the estimate stands
while the deal is open — the documented law), and the
`OPPORTUNITY_STAGE_CHANGED` audit row now records the opportunity's ACTUAL
value on both sides plus the agreed price under its own honest key:

```ts
before: { stage: deal.stage, value: facts.value },            // the estimate
after:  { stage: "RESERVATION", value: facts.value,            // UNCHANGED estimate
          amount: facts.amount, booking: true }                // the agreed price
```

where `facts = bookingValueFacts(opportunity, reservation)` — a NEW pure
helper in `src/lib/server/financial-semantics.ts`, the single sanctioned
construction of that row's money pair (the DOM-03 pattern: closure-adjacent
writers go through the semantics home; no route re-declares the rule).

### Why this is the smallest consistent fix

- One audit-row construction changes; zero data-path changes; zero changes
  to closure, offer conversion, or the manager correction path.
- The estimate/agreed distinction stays intact end-to-end: the estimate is
  set by humans, the agreed price by booking, the alignment happens once at
  closure — each with its own audit semantics.
- Revenue attribution math is untouched BY CONSTRUCTION (booking never
  writes value; every won deal's value still comes from the seed convention,
  an explicit manager edit, or the closure alignment).
- The brief's alternative ("align the value at booking because the
  reservation supersedes the estimate") was considered and rejected on the
  code evidence above — the brief itself directed: *"verify against code,
  then confirm or adjust."* The verification adjusted it.

### What the rollback law means under this decision

The `reservations-post` §41 fault site already sat after ALL shared writes;
since booking writes no value, "fault reverts BOTH reservation and
opportunity" reduces to: the reservation, apartment flip, stage advance and
trail all revert AND the opportunity's value is provably untouched
(`tests/security/booking-semantics.test.ts` TEST 4 asserts exactly this,
including zero audit rows and the estimate intact).

## Test evidence

- Pure law: `tests/unit/financial-semantics.test.ts` —
  `bookingValueFacts` describe block (estimate stands / agreed price rides
  `amount` / null estimate stays null / equal values agree).
- Live law: `tests/security/booking-semantics.test.ts` —
  TEST 1 truthful row + no value write; TEST 2 closure alignment unchanged;
  TEST 3 offer conversion byte-identical (no `value`/`amount` keys, no
  alignment); TEST 4 fault rollback incl. value untouched; TEST 5
  attribution invariance (pre-existing won deals unchanged + the new won
  deal carries the agreed price).
