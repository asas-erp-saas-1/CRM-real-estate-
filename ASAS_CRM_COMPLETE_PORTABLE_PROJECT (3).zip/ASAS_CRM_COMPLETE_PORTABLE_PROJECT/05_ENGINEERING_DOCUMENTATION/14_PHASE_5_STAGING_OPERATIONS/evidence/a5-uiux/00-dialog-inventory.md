# P5-W2-A5 — Dialog inventory (P3-F5 form-standardization scope)

**Mission:** every dialog-bearing component under `src/components/crm/**` was read and
classified. Migration criterion (from the Phase 1 / W4-A6b reference law —
`create-lead-dialog.tsx` + the five capture dialogs): a dialog is **migrated**
when it owns form fields **with field-level validation logic** (required rules,
length/format contracts, cross-field rules) worth surfacing as per-field inline
messages. A dialog is **legitimately excluded** when it is display/confirm-only,
or when its "validation" is a structural/disabled-gate with no field semantics
(server owns the contract), or when it is not a dialog form at all (inline
composers/panels).

**Legend:** validation style — `manual` = useState + submit-time guards;
`disabled-gate` = button disabled until structurally valid (no error messages);
`live-derive` = per-keystroke derived validity with inline messages.

## 1. Already on the RHF/Zod standard (Phase 1 / W4-A6b — untouched here)

| # | File | Schema factory (exported, tested in `tests/unit/form-schema.test.ts`) |
|---|------|------------------------------------------------------------------------|
| 1 | `create-lead-dialog.tsx` | inline `useMemo` schema (the reference) |
| 2 | `pipeline/create-opportunity-dialog.tsx` | `createOpportunitySchema(t)` |
| 3 | `visits/schedule-visit-dialog.tsx` | `scheduleVisitSchema(t)` |
| 4 | `views/sav/sav-create-dialog.tsx` | `savCreateSchema(t)` |
| 5 | `views/finance/add-installment-dialog.tsx` | `addInstallmentSchema(t)` |
| 6 | `views/finance/record-payment-dialog.tsx` | `recordPaymentSchema(remaining, t)` |

## 2. Migrated in THIS wave (P5-W2-A5)

| # | File / dialog | Fields | Before | After |
|---|---------------|--------|--------|-------|
| 7 | `settings/team/add-member-dialog.tsx` — Add member | name (≥2) · email (regex) · role | `manual` — single shared error line under the form | RHF + `addMemberSchema(t)` — per-field messages on submit, same limits/messages |
| 8 | `change-password-dialog.tsx` — Change password | current · new (≥8) · confirm (match) | `live-derive` + disabled submit | RHF + `changePasswordSchema(t)` — same live hints (strength/mismatch) kept via `useWatch`, Zod owns the submit contract |
| 9 | `pipeline/reason-dialog.tsx` — ReasonDialog (lost / correction / lost+correction) | lostReasonCode (required in lost modes) · lostReason detail (optional) · correctionReason (required in correction modes) | `disabled-gate` | RHF + `reasonDialogSchema(mode, t)` — prefill re-seed kept, per-field messages |
| 10 | `lead-drawer-header.tsx` — Contact editor dialog | email (optional, regex) · secondaryPhone (optional, phone) · whatsapp (optional, phone) | `live-derive` (aria-invalid + inline msg) | RHF + `leadContactSchema(t)` — same messages, submit-normalization preserved |
| 11 | `visits/visit-dialogs.tsx` — CompleteVisitDialog | outcome (required) · interest (required) · reportNotes (≥ VISIT_REPORT_NOTES_MIN) · notes (optional) · followUp | `manual` (formValid gate + count hint) | RHF + `completeVisitSchema(t)` — same min-length + required contracts |
| 12 | `visits/visit-dialogs.tsx` — VisitReportDialog | interest (required) · reportNotes (≥ min) | `manual` (formValid gate + count hint) | RHF + `visitReportSchema(t)` |
| 13 | `visits/visit-dialogs.tsx` — RejectVisitDialog | reason (trim ≥ 3) | `disabled-gate` (min 3) | RHF + `rejectVisitSchema(t)` — same 3-char minimum |
| 14 | `visits/visit-dialogs.tsx` — RescheduleVisitDialog | date (required) · time | `disabled-gate` | RHF + `visitSlotSchema(t)` |
| 15 | `visits/visit-dialogs.tsx` — ProposeAlternativeDialog | date (required) · time | `disabled-gate` | RHF + `visitSlotSchema(t)` (shared with #14) |
| 16 | `visits/visit-dialogs.tsx` — ConfirmVisitDialog | fixDate (switch) · date+time (required when fixDate) | `disabled-gate` (conditional) | RHF + `confirmVisitSchema(t)` — same conditional requirement |

## 3. Legitimately EXCLUDED (with reasons)

| File / surface | Why excluded |
|----------------|--------------|
| `pipeline/gate-dialog.tsx` | Zero inputs — checklist display + Rester/Avancer actions. Nothing to validate. |
| `visits/visit-dialogs.tsx` — NoShowVisitDialog, CancelVisitDialog, ResetVisitConfirmationDialog | AlertDialog confirmations — zero inputs. |
| `views/finance/installment-detail-dialog.tsx` | Pure display (installment facts + linked rows). |
| `documents/doc-preview-dialog.tsx` | Pure display (document preview). |
| `settings/team/temp-password-dialog.tsx` | One-time password DISPLAY + copy button — no inputs. |
| `visits/visit-fiche-dialog.tsx` | Pure display (the visit fiche sheet the field rep prints/reads). |
| `import-leads-dialog.tsx` (4-step CSV wizard) | Server-side parsing/validation is the declared single source of truth; the only client gates are structural (mapping coverage, `valid === 0`). RHF would duplicate a contract the server owns by design. |
| `bulk-copilot-dialog.tsx` | Review/apply surface (row selection, AI retries, auto-apply switch) — no field validation. |
| `duplicates-dialog.tsx` | Survivor selection is structural (older-record default, card pick — not user-validated); the merge note is OPTIONAL (no rule). Confirm-gated mutations. |
| `views/sav/sav-detail-dialog.tsx` | Display-first detail dialog; the resolve flow is a progressive-disclosure inline panel with a single disabled-gate textarea (`resolution` non-empty). No field-level semantics to mirror. |
| `pipeline/opportunity-detail-dialog.tsx` | Read/edit split cockpit (P2.5). Edit draft's only client law is `nextActionMissing` (disabled-save guard, server 422 + teaching toast own the contract). Migrating would restructure the read/edit split for no field-level gain. |
| `properties/apartment-detail-dialog.tsx` | Inventory drill-down (display-first); the reserve panel's rules (`!reserveOpp \|\| !amount`) mirror the server contract as disabled-gates; price edit same pattern. |
| `pipeline/opportunity-offers.tsx` (offer create form) | Every field optional (amount may be empty → null); server owns the offer contract. Its cancel-reason dialog is a single required field (confirm-style). |
| `saved-searches.tsx` (save-current dialog) | Single name field with disabled-gate (no field-level validation logic); share switch is a preference, not a rule. |
| `lead-drawer-header.tsx` — lost-reason dialog | Single required textarea, destructive confirm-style (disabled-gate). The contact editor in the same file IS migrated (#10). |
| `lead-tab-tasks.tsx` / `lead-tab-activities.tsx` | Inline composers/quick-actions inside drawer tabs (not dialog forms); disabled-gate on structural fields; AlertDialogs are confirmations. |
| `search-command.tsx`, `shell.tsx`, `lead-detail-drawer.tsx`, `audit/audit-target-overlay.tsx`, `properties/orphan-holds-card.tsx`, `tasks/task-opportunity-chip.tsx`, `settings/team/reset-password-alert.tsx`, `views/leads/bulk-bar.tsx`, `visit-unit-chips.tsx` | Command palette / chrome / drawers / pure AlertDialog confirmations — no form fields. |

**Count: 10 form migrations across 5 files; 6 dialogs already on the standard; every other DialogContent-bearing surface inventoried and excluded with a reason.**
