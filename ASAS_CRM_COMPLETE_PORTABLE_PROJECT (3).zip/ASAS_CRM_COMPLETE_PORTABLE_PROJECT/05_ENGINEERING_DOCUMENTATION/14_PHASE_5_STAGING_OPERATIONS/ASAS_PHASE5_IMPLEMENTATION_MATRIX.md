# ASAS CRM — Phase 5: Implementation Matrix

**Authority:** Principal Engineering Lead, Phase 5
**Date:** 2026-11-07 · **Repo:** HEAD pre-commit `9c3920f` + Phase 5 working tree (main, no git remote)
**Method:** six specialized agents (A1–A6, two completion passes) with isolated file ownership + Principal integration, central `package.json` control, and full-regression validation. Every status below is evidence-backed; nothing is self-certified by an agent.

**Status vocabulary (strict):** `IMPLEMENTED` (code on disk, reviewed) · `INTEGRATED` (wired into the app/scripts by the Principal) · `TESTED` (automated tests green this session) · `RUNTIME VERIFIED` (live behavior observed this session) · `BLOCKED` (environment/external gate — honestly declared) · `NOT IMPLEMENTED` (deferred with reason) · `REJECTED` (principal veto).

**Full-regression baseline vs result:** Phase 4 baseline **772/772 (44 files)** → Phase 5 result **879/879 (51 files)** — **+107 tests, 0 removed, 0 skipped**. TypeScript 0 errors · Lint 0 errors / 41 warnings (count unchanged from Phase 4). Browser E2E post-StrictMode: 0 console errors/warnings · RTL live · no overflow at 1280.

---

## 1. Staging conditions C1–C8

| # | Condition (Phase 4) | Status | Source files changed | Tests added | Test evidence | Runtime verification | Remaining blocker | Principal acceptance |
|---|---|---|---|---|---|---|---|---|
| **C1** | First-ever production build + standalone boot + health PASS | **BLOCKED** (environment — `next build` forbidden in this sandbox by explicit rule; no git remote so CI never executed) | `Dockerfile` (build stage = the sanctioned build site) · `.github/workflows/ci.yml` verified gate-complete (not edited — clean) | — | CI step-verification matrix: `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/evidence/a1-deploy/01-ci-step-verification.txt` (all 8 gates covered) | NONE — never fabricated; compose/Dockerfile/YAML parse-validated (`evidence/a1-deploy/02–04`) | Requires the staging host (or a remote + CI): exact procedure in `deploy/README-STAGING.md` §C1 (build → up → health jq gate) | **ACCEPTED as BLOCKED** — external gate, prepared precisely |
| **C2** | Hosting-model decision recorded + docs updated | **IMPLEMENTED + INTEGRATED** | `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_STAGING_ARCHITECTURE.md` (ADR) · `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md` (reframed w/ the 4 incompatibilities) · `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/PRODUCTION_READINESS.md` (7 stale rows fixed) · `Dockerfile` · `docker-compose.staging.yml` · `.env.staging.example` · `.dockerignore` · `deploy/README-STAGING.md` | — | YAML parse + 22/22 semantic assertions (`evidence/a1-deploy/03`) · Dockerfile 10-point review (`02`) | Dockerfile/compose on-disk artifacts only (no docker daemon here — honestly declared) | None for the decision itself; C1 for artifact execution | **ACCEPTED** — single-node VPS/Docker decision recorded with the four single-instance mechanisms cited |
| **C3** | Production posture boot test (NODE_ENV=production, ASAS_DEMO_MODE=0, real secret, secure cookies, no demo users) | **TESTED** (module/script level) — full runtime boot **BLOCKED** (depends on C1) | `scripts/provision-owner.ts` (new) · `tests/unit/production-posture.test.ts` (new) · `tests/unit/seed-guard.test.ts` (new) | 13 (6 posture + 7 seed-guard) | 31/31 targeted (`evidence/a3-security/09-vitest-targeted.txt`) | Child-process probes on disposable DBs: missing secret → exit 1 `SESSION_SECRET_MISSING`; production+demo=1 → exit 1 `DEMO_MODE_PRODUCTION` (fail-fast already wired, verified not assumed); clean prod posture → `BOOT_OK violations=[]` (`evidence/a3-security/01–03`) | Full production-mode server boot requires C1 build | **ACCEPTED as TESTED/BLOCKED** — posture gates proven; runtime boot rides the C1 gate |
| **C4** | Seed safety — production migrations must never plant demo users w/ public password | **IMPLEMENTED + INTEGRATED + TESTED + RUNTIME VERIFIED** | `prisma/seed.ts` (production refusal guard) · `package.json` (**Principal**: `db:deploy` = migrate only; new `db:deploy:demo`, `db:owner`) · `.env.example` (guard documented) | 7 (seed-guard) | `evidence/a3-security/09` + `10-prisma-cli-seed-paths.txt` | Fresh `migrate deploy` on disposable DB → **0 users/0 orgs** (`04`); production seed → refusal exit 1, zero writes (`05`); dev seed still works — 8 users (`06`, `10`); explicit loud opt-in only (`07`); `db:owner` provisions a real owner, refuses the demo password, idempotent (`08`) | None | **ACCEPTED** — footgun structurally closed |
| **C5** | Backup readiness — first-run, manifest, restore drill, scheduling, offsite | **IMPLEMENTED + INTEGRATED + RUNTIME VERIFIED** | `scripts/backup.sh` (mkdir -p bootstrap) · `scripts/lib/backup-run.mjs` (recursive parent, collision law preserved) · `deploy/systemd/asas-backup.{service,timer}` (templates) · `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_DATABASE_BACKUP_RECOVERY.md` | +14 retention (see C7) | `evidence/a2-backup/01–06` | Defect reproduced (ENOENT exit 1) → fixed → **live first-run backup PASS** (`backup-20261107T010208Z`, source sha256 unchanged) → **restore drill PASS** (manifest+sha256+integrity+census; original untouched) → live retention dry-run recognized the fresh backup | Scheduling/offsite activation = owner action on the staging host (templates provided; honestly not activated here) | **ACCEPTED** — with activation as a documented owner step |
| **C6** | Operational floor — memory supervision, restart, monitoring, health checks, alerting | **IMPLEMENTED** (design + templates + compose wiring; activation external) | `docker-compose.staging.yml` (mem_limit 4g, restart unless-stopped, healthcheck 30s/5s/3×/60s start_period) · `deploy/monitoring/asas-health-watch.sh` + `README.md` (alert $0→$1/stdin defect found in review and **fixed by the Principal**) · `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_OPERATIONS_RUNBOOK.md` (8 sections) | — (operations design; the health-route code change is under C7's sibling L08) | `evidence/a6-ops/01–05` (live 404/health envelope proof, perf baseline, memory evidence w/ dmesg OOM verbatim, template review) | Health contract live-verified byte-stable; 46 health polls → 0 log spam; measured envelopes (steady 2.0–2.5 GB RSS, kills at 2.31/2.55 GB) anchor the 4g limit + WARN/CRIT thresholds | External watchdog/uptime monitor/alert channel = owner action (no credentials exist here — none invented) | **ACCEPTED** — operational floor prepared; activation external |
| **C7** | Retention apply-gate timestamp fix + interlocks | **IMPLEMENTED + TESTED + RUNTIME VERIFIED** | `src/lib/server/retention.ts` (strict `parseManifestStamp()`) · `tests/unit/retention.test.ts` (production-format fixtures) | +14 (26 total; all 7 mandated cases: fresh authorizes, expired refuses, corrupt/missing/invalid rejected, dry-run zero writes, interlocks fail-closed) | 93/93 retention+manifest (`evidence/a2-backup/04-retention-tests.txt`) | **Live dry-run probe: `freshBackupFound: true`** with the real backup, age 4 min (`05-retention-dryrun-live.txt`) — the previously-NaN gate now authorizes from real manifests; `--confirm-purge` never run against real data (by rule) | None | **ACCEPTED** |
| **C8** | One authoritative money limit across API/UI/CSV | **IMPLEMENTED + TESTED + RUNTIME VERIFIED** | `src/lib/money.ts` (new authoritative `MAX_MONEY_DZD`) · `src/lib/server/validation.ts` (re-export) · installments routes (**1e12→law — the 100× bug**) · `csv.ts` (import bypass closed) · `targets/route.ts`, `targets-section.tsx`, `reservations/[id]/route.ts` (private twins removed) | 19 (12 unit + 7 security boundary/overflow/CSV) + regression guards | `evidence/a4-finance/01–02` | Live at-cap probes rejected server-side; post-fix grep: the only literal lives in `src/lib/money.ts:18` | None (ceiling unchanged 1e10 — no business reason to change) | **ACCEPTED** |

---

## 2. P3 carry-forward register (never commissioned — now resolved or explicitly dispositioned)

| P3 item | Status | Evidence |
|---|---|---|
| F1 login-lockout coverage | CLOSED in P2 (re-verified in 879/879) | session-governance suite |
| **F2 money-cap asymmetry** | **CLOSED** (= C8) | this matrix §1 |
| **F3 direct-booking audit semantics** | **IMPLEMENTED + TESTED** — `bookingValueFacts()` in `src/lib/server/financial-semantics.ts`; audit `after.value` now records the opportunity's ACTUAL unchanged estimate + the agreed price under its own key; open-deal estimate law preserved (no second alignment site; cancelled holds would orphan an overwritten estimate) | `evidence/a4-finance/03–04` · 5 new booking-semantics tests · financial-semantics 8→12 |
| **F4 touch-target sweep** | **IMPLEMENTED + RUNTIME VERIFIED (browser)** — topbar/nav/dialog/dashboard/pipeline primary controls ≥44px (measured 44×44, 89×44, 308×44); compact exceptions E1–E5 documented; 390px overflow check PASS (scrollWidth=390) | `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_UI_UX_ACCEPTANCE.md` §2 + `evidence/a5-uiux/05-touch-targets.txt` |
| **F5 12 un-migrated dialogs** | **IMPLEMENTED + TESTED** — 10 migrated this wave (add-member, change-password, reason, contact-editor, 5 visit dialogs), 6 already standard from P1 → **16 on RHF/Zod**; 13 legitimately excluded with per-dialog reasons (display/confirm-only, server-owned contracts, structural gates) | full inventory `evidence/a5-uiux/00-dialog-inventory.md` · form-schema 24→53 tests · browser validation evidence 06/07/15 |
| WAL enablement | **BLOCKED** (documented) — installed engine SQLite 3.46.0 remains in the WAL-reset bug range | carried from Phase 4, unchanged |
| Remote CI execution | **BLOCKED** (no git remote exists) — workflow verified gate-complete on disk | `evidence/a1-deploy/01` |
| Production bundle budget | **BLOCKED** (no build possible) — rides C1 | C1 row |
| Scheduler/watchdog external verification | Scheduler lazy-resume verified live (sweep resumes on next read); watchdog = C6 templates | runbook §1–2 |
| Email/SMS integration | **BLOCKED** (zero credentials — by design) | carried from P2 evaluation |

---

## 3. Phase 4 findings disposition (all IDs)

| Finding | Disposition |
|---|---|
| P4-H01 OOM class | **ADDRESSED** — memory supervision design + 4g compose limit + restart policy + runbook kill-recovery procedure; measured evidence anchored (dmesg verbatim). The class itself is environment-shaped; in staging it is supervised. |
| P4-H02 Vercel incompatibility | **CLOSED via C2** — single-node decision recorded; Vercel path documented as requires-rework. |
| P4-H03 never-built artifact | **= C1 BLOCKED** — build site + procedure prepared. |
| P4-M01 retention parse | **CLOSED** (C7). |
| P4-M02 backup bootstrap | **CLOSED** (C5). |
| P4-M03 seed footgun | **CLOSED** (C4). |
| P4-M04 money-cap | **CLOSED** (C8). |
| P4-M05 god-routes/service-extraction coverage | **NOT IMPLEMENTED — deferred** (maintainability debt, known-shaped, not a security/integrity defect; queued behind staging entry). |
| P4-M06 reactStrictMode | **CLOSED** — flipped ON (`next.config.ts`) after Agent 1's LOW-risk assessment; **verified live by the Principal post-flip**: full suite 879/879 + browser golden path with 0 console errors/warnings (dashboard, pipeline, AR RTL) — `evidence/principal/01–04`. |
| P4-M07 stale readiness doc | **CLOSED** — 7 rows rewritten with citations. |
| P4-M08 backup cadence/offsite | **CLOSED as design+templates** (activation = owner action). |
| P4-M09 monitoring consumer | **CLOSED as design+templates** (activation = owner action; alert-channel defect found in review and fixed by Principal). |
| P4-M10 unsafe db:snapshot | **CLOSED** — alias now `bash scripts/backup.sh` (VACUUM INTO path; raw cp retired by Principal in package.json). |
| P4-L01 booking audit | **CLOSED** (= P3-F3). |
| P4-L02 payment idempotency | **CLOSED** — in-transaction duplicate fingerprint (actor+amount+method+reference+notes, 60s window) → 409 `DUPLICATE_PAYMENT` with existing id; concurrency test proves exactly-one-wins; no migration. |
| P4-L03 process-local rate limits | Documented (single-instance law, runbook §5). |
| P4-L04 per-email lockout DoS | **NOT IMPLEMENTED — deferred** (LOW; requires lockout-policy redesign). |
| P4-L05 heading skip | **CLOSED** — panel titles h2; live DOM proof H1→H2. |
| P4-L06 touch targets | **CLOSED** (= F4). |
| P4-L07 audit i18n keys | **CLOSED** — 3 keys ×3 languages; browser proof: audit view renders translated, 0 warnings. |
| P4-L08 health/404 envelope | **CLOSED** — catch-all emits envelope+structured line (byte-identical body); health logs state-changes only (46 polls → 0 spam); 10 new contract tests. |
| P4-L09 cold-window budget | **Documented** (runbook §6 — warm-up window is expected, not an incident). |
| P4-L10 dev.log single-writer | Environment hygiene — unchanged (dev-only). |
| P4-L11 lint drift 41 | Unchanged count, 0 errors (ratchet deferred). |
| P4-L12 restart resets | **Documented** (runbook §5: metrics/cache/rate-limits reset; lockout DB-backed survives; lazy-resume backstop). |
| P4-L13 coverage thresholds | Deferred (LOW). |
| P4-L14 type-only layering import | Deferred (LOW). |
| P4-L15 dep hygiene | Deferred (LOW). |
| P4-L16 "1 jours" | **CLOSED** — `daysTitle.singular`. |
| P4-L17 Float money | Platform limit, owner-gated (unchanged). |

---

## 4. Principal integration record

- **Central control exercised:** `package.json` (`db:deploy` split, `db:deploy:demo`, `db:owner`, `db:snapshot` → safe backup) · `.gitignore` (`!.env.staging.example`) · `next.config.ts` (StrictMode flip + verification) · `deploy/monitoring/asas-health-watch.sh` (alert $0→$1/stdin dispatch fix) · `.env.example` (seed-guard documentation).
- **Diffs reviewed:** every agent file inspected (`git diff --stat`, 700+ insertions wave 1; wave 2 artifacts). No unexpected generated files; no user work overwritten; no secrets entered (grep-verified: no secret values in any committed file; test secrets redacted in evidence).
- **Incidents (both disclosed by the agents, repaired, Principal-verified):**
  1. A4 live probe pollution (commissionAmount 1e10 + 1 audit row on the demo DB) → repaired to seed values; **Principal re-verified**: commissionAmount=1160000, COMMISSION_SET=7, census intact.
  2. A5 QA accidental payment POST (5.8M DZD) → fully reverted in one transaction; **Principal re-verified**: payments=8, installments=14 (census matches seed).
- **Dev-server OOM events during execution** (3× kernel kills at ~2.3–2.55 GB RSS under concurrent agent load): each documented in agent evidence; the final instance is healthy (rssMb ~2310 steady, health ok). This is the P4-H01 class live in this 4 GB sandbox — precisely the environment the staging memory-supervision design addresses.
- **Original database untouched by destructive tests:** `db/custom.db` sha256 verified unchanged across backup/restore-drill/retention-dry-run (A2 evidence); migration/status checks read-only; disposable DBs under `/tmp` for all destructive tests.

## 5. Test-count reconciliation (mandatory disclosure)

| File | Before → After |
|---|---|
| retention.test.ts | 12 → 26 (+14) |
| form-schema.test.ts | 24 → 53 (+29) |
| financial-semantics.test.ts | 8 → 12 (+4) |
| services-payments.test.ts | 11 → 19 (+8) |
| NEW money-cap.test.ts (unit) | +12 |
| NEW money-cap.test.ts (security) | +7 |
| NEW booking-semantics.test.ts | +5 |
| NEW payment-idempotency.test.ts | +5 |
| NEW health-envelope.test.ts | +10 |
| NEW seed-guard.test.ts | +7 |
| NEW production-posture.test.ts | +6 |
| **Total** | **772 → 879 (+107, 0 removed, 0 skipped)** |

*No secrets, database URLs, or credentials appear in this document.*
