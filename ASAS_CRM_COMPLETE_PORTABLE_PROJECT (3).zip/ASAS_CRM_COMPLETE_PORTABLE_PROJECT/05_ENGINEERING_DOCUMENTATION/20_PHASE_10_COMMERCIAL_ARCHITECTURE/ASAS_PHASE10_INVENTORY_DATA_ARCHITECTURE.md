# ASAS CRM — Phase 10 — Inventory Data Architecture (A1)

## The property hierarchy (verified against the live schema)

```
Developer (org-scoped, AR alias)
└─ Project (developer FK; city/district/address; status; deliveryDate)
   └─ Building (project FK, cascade; name; floors)
      └─ Apartment (org-scoped; unique [orgId, buildingId, code])
```

- **One authoritative status field** (`Apartment.status`) — no competing field introduced (§5-A2 law).
- Every query respects **org isolation** (`orgId` on every tenant-owned row + scoped `findFirst` in every route).
- `Document` (polymorphic entityType/entityId, secure disk storage, VALIDATED status) covers project/building/unit images, plans and commercial documents — no second file architecture.

## Unit specification model (A1 §D)

| Field | Type | Unknown semantics |
|---|---|---|
| code, unitType, rooms, bedrooms, surface, floorNumber, orientation, parking, price, status, paymentPlan, notes | pre-existing | price/surface non-null positive (guards) |
| **bathrooms** | Int? | null = explicit unknown — never defaulted to a fake 1 |
| **totalSurface** | Float? | null = unknown (surface = interior area) |
| **balcony / terrace** | Boolean? | null = unknown |
| **view** | Enum? (SEA/CITY/GARDEN/STREET/MOUNTAIN/PARK) | null = unknown |
| **finishing** | Enum? (ROUGH/PARTIAL/FULL/LUXURY) | null = unknown |
| **deliveryStatus** | Enum? (NOT_STARTED/UNDER_CONSTRUCTION/READY/DELIVERED) | null = unknown |
| **parkingPrice** | Float? | null = unpriced |
| **priceUpdatedAt** | DateTime? | the pricing date (stamped on every price change) |
| **availabilityVerifiedAt** | DateTime? | the freshness anchor |
| **statusReason** | String? | the last transition's recorded motive |

**Law**: a missing value is EXPLICIT unknown — never converted into a fabricated value (§5-D). The matching engine never scores unknown specs; the quality view surfaces them as actionable issues; the UI displays « Non renseigné ».

## The event streams (A2)

- `UnitAvailabilityEvent` — append-only: orgId, apartmentId, fromStatus, toStatus, actorId (null = system sweep), reason, source (MANUAL | OFFER | RESERVATION | SWEEPER | IMPORT), createdAt. Indexes `[orgId, apartmentId, createdAt]` + `[orgId, createdAt]`.
- `UnitPriceEvent` — append-only: previousPrice, newPrice, actorId, reason, source (MANUAL | IMPORT).
- **Ordinary users never rewrite history**: no update/delete surface exists for either table.
- Every lifecycle status flip rides the SAME transaction as its event (the F-06 fold law) — instrumented at every site: offer activate/cancel/convert/unit-change, offer expiry sweeper, reservation booking/closure/cancel, reservation expiry sweeper, manual console transitions, imports.

## Data integrity enforcement (A1 §E)

- Unique unit codes within `[orgId, buildingId, code]` (pre-existing DB constraint) + duplicate-code-within-project surfaced by the quality view (codes repeating across buildings of one project).
- Valid project-unit relations: FK cascade + in-tx re-reads (booking core re-reads availability inside the transaction).
- Valid area/price values: route guards (INVALID_PRICE / INVALID_SURFACE in PATCH + import validation; price > 0 enforced).
- Valid status transitions: `MANUAL_APARTMENT_TRANSITIONS` law + `FORBIDDEN_APARTMENT_TRANSITIONS` (SOLD guard) + live-hold guards.
- Organization ownership: orgId on all new tables + org-scoped queries everywhere.
- Consistent references: offer snapshots freeze the unit's pricing at creation — later unit changes never rewrite them (Journey G).

## Controlled CSV import (A5 §E)

`POST /api/inventory/import` — two-phase (preview/commit):
1. Upload CSV → parse (600KB / 2000-row caps) → header auto-map (FR/EN/AR-tolerant aliases)
2. Validate every row: required project/building/code/type/price/surface; enum coercion with alias tolerance; booleans (oui/non/true/false/0/1); in-file duplicate detection; existing-unit duplicate detection (**never overwritten — the row is refused**); structure resolution (project must exist; building must exist unless `allowCreateBuilding`)
3. Preview returns row-level errors + detected mapping
4. Commit is **all-or-nothing** (any error refuses the whole import — no partial inventory gaps) + one transaction + `INVENTORY_IMPORTED` audit with the created ids + availability events (source IMPORT) per unit + freshness + price anchors stamped

## Developer/promoter confidentiality

Developers carry contact/legal identity + notes only — no confidential promoter-agreement data exists in the model (documented decision: nothing secret to leak; FIELD_REP sees the same developer identity as everyone, and the sales/field surfaces never expose margins or internal costs — those live exclusively on Reservation economics, gated MANAGER+).
