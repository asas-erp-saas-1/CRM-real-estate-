# ASAS CRM — Phase 10 — Inventory UX/UI Acceptance (A6)

Method: interactive browser verification (agent-browser) against the live preview — not source inspection. Evidence in `05_ENGINEERING_DOCUMENTATION/20_PHASE_10_COMMERCIAL_ARCHITECTURE/evidence/` (original close) and `evidence/p10-continuation/` (continuation round).

## The continuation round (2026-11-10) — the import wizard (D1 closure)

| Surface | Evidence | Verified behaviors |
|---|---|---|
| The trigger (MANAGER+) | `p10-continuation/01` | "Importer des lots" in the control-center header — renders for OWNER (used live); SALES_AGENT sees the dashboard with ZERO triggers (capture 13, live RBAC) |
| Wizard step 1 — Fichier | `02` | Dropzone (role=button, keyboard-operable, the sr-only input OUTSIDE the interactive role per the W4.1 law) + template download (FR headers, values that pass the alias coercion) |
| Wizard step 2 — Colonnes | `03`, `05` | File summary chip + auto-mapped badge (the server's detectedMapping); editable column→field selects (22-field closed vocabulary; the 6 required fields marked « requis »); the incomplete warning gates Continue |
| Wizard step 3 — Aperçu | `04`, `06` | Summary chips (valid/errors) + the row-error table (row/field/message) + truncatedErrors disclosure + the allowCreateBuilding decision (checkbox + hint) + the unit sample (server-parsed values, compact DZD) — **the ERROR path: commit disabled while errors stand (the all-or-nothing law visible)** |
| Wizard step 4 — Résultat | `07` | Created count + the honest no-undo disclosure (every unit carries an IMPORT availability event; nothing overwritten) + "Voir l'inventaire" |
| Trilingual | `08`, `14` | AR RTL (dir=rtl, Arabic labels) + EN labels verified live; FR = the full journey |
| Mobile 390 | `09`, `10` | scrollWidth=390 (no overflow); the wizard usable on mobile |
| Dark mode | `11` | The console + surfaces in dark |
| Persistence + cleanup | `12` | DB round-trip verified (2 units + 2 IMPORT events + audit) → QA fixtures removed → census byte-identical (46/35; quality 219/46) |

Console/page errors: zero across all continuation journeys.

## The console surfaces (original close)

| Surface | Evidence | Verified behaviors |
|---|---|---|
| Inventory dashboard (all roles) | `p10-01`, `p10-16` | Real DB metrics (46 units, 35 available, 7 sold, stale/unknown freshness counts, 30-day price/availability changes, pending discounts, live offers, active reservations); compact metric strip; loading skeleton |
| Data quality (MANAGER+) | `p10-01` | 216 issues on 46 lots with category chips + row-level detail; nothing auto-modified; empty-state law |
| Apartment dialog — specs | `p10-02` | New fields (bathrooms, totalSurface, balcony/terrace, view, finishing, parkingPrice) with honest « Non renseigné » for unknowns; spec editor (PATCH) |
| Apartment dialog — availability | `p10-03` | Freshness chip + relative time; verify action; transition dialog offering ONLY the legal targets (from AVAILABLE: Bloqué/Indisponible/Retiré — SOLD never offered); reason recorded; live status patch |
| History | `p10-03` (collapsible) | Availability + price event streams with actor/reason/source labels |
| Matching tab | `p10-05` | Ranked results with score chips + translated reason chips; run/rerun; NO_REQUIREMENT hint |
| Unit comparison | `p10-06` | Side-by-side table (price, parking, status, surfaces, rooms/baths, floor, view, finishing, balcony/terrace, freshness) + the stale warning rendering |
| Offer creation | `p10-07` | Itemized pricing preview (base from unit, options editor, discount with live % + lane hint, gross/final lines, snapshot note); activation deferred behind approval |
| Approval flow | `p10-08`, `p10-09` | PENDING_APPROVAL state; approve/reject reason dialogs; the 5.08% MANAGER refusal (403 surfaced) then OWNER approval |
| Presentation | `p10-11` | Document layout: agency, client, unit, project/developer, itemized pricing, validity, rep contact, version note, « not a contract » disclaimer; print button |
| Revision | `p10-12` chain | v2 created with fresh pricing; v1 « Remplacée par la version 2 » |

## Role experiences (§5-A6 A–D)

- **OWNER/ADMIN**: full console (metrics + quality + transitions + price + approvals above manager lane) — verified as Nadia.
- **MANAGER**: operational console + the manager-lane approvals — verified as Sarah (including the lane refusal at 5.08%).
- **SALES_AGENT**: matching workspace + proposal creation with discount requests + own-offer actions (offer surfaces per the D-021 scope; the approval buttons appear only with `offers.approve`).
- **FIELD_REP**: sees inventory read floors only (properties.view); no pricing-policy, no approvals, no confidential costs anywhere on offer/proposal surfaces (no such fields exist there).

## Localization + responsiveness (§15)

- **AR RTL**: `p10-13` — dir=rtl, « مركز مراقبة المخزون », Arabic chips/labels, real numbers (35/46) — verified.
- **Mobile 390px**: `p10-14` (AR) / `p10-15` (FR) — no horizontal overflow (`scrollWidth = 390`), responsive metric grids.
- **Desktop 1440**: `p10-16`.
- i18n parity: 10/10 domains green (the module-load guard + `i18n.test.ts`) — all new keys in FR/EN/AR.

## Console output during the whole verification

Zero page errors · zero console errors · zero 500s in dev.log.

## Design-system conformance

Existing ASAS identity throughout (chips, cards, dialogs, tone law); no second branding; shadcn/ui primitives only; tone palette emerald/sky/amber/stone/teal/violet/rose (no indigo/blue); long lists under max-h + scroll; primary actions visually clear (approve = primary, reject = outline destructive); the inventory metric strip deliberately compact (no metric walls).
