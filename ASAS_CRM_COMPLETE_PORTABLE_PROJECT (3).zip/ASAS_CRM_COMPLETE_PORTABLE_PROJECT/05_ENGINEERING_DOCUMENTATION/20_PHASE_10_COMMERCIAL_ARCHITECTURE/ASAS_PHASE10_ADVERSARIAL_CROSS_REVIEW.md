# ASAS CRM — Phase 10 — Adversarial Cross-Review (Continuation Round)

The Principal-led continuation ran the six-agent discovery, resolved the
challenges, then approved the architecture before any TODO execution (the
governance order: discovery → cross-review → architecture gate → backlog →
implementation → verification).

## The challenges (each ≥2 per the §12 mandate, resolved by the Principal)

### Challenge 1 — Reuse the leads-import wizard components directly? (A6 vs A2/A5)

- **A6's case**: consistency and zero duplication demand reusing `import/*`.
- **A2/A5's case**: the leads wizard carries leads-specific steps
  (defaultOwner/defaultSource selects, the undo flow with its auditId) that
  are meaningless for units; the inventory contract has different semantics
  (allowCreateBuilding, no undo endpoint).
- **Principal ruling**: build a dedicated wizard in the properties family
  MIRRORING the interaction model (same stepper, same visual language, same
  4-step rhythm) while consuming the inventory contract. The leads wizard
  stays untouched. **Validated by**: both wizards working independently in
  the 963/963 round + the live journeys.

### Challenge 2 — Offer an undo for the inventory import? (A2 vs A5)

- **A2's case**: leads import has one-click undo; symmetry suggests one.
- **A5's case**: a new endpoint expands the verified API surface; the import
  is all-or-nothing + audited (created ids recorded); units can be withdrawn
  through the console.
- **Principal ruling**: NO undo endpoint (no API change). The result step
  discloses the semantics honestly instead. **Validated by**: the DB
  round-trip (events + audit) and the documented distinction (AD-C9).

### Challenge 3 — Where does the trigger live? (A3 vs A6)

- **A3's case**: the control-center strip is the MANAGER+ surface — the
  button belongs there.
- **A6's case**: the dashboard is all-role-visible; adding an action inside
  it risks privilege signaling.
- **Principal ruling**: the button renders conditionally inside the
  InventoryDashboard header via `sessionCan` — the client mirror of the
  server gate (the API refuses everyone else anyway). **Validated live**:
  SALES_AGENT sees the dashboard with zero triggers (capture 13).

### Challenge 4 — Baseline the 9 new dialog-rect findings or fix them? (A6 vs the schedule)

- **The temptation**: raise the ratchet baselines and move on (5 minutes).
- **A6's case**: the scan's own law says FIX debt and LOWER the baseline —
  baselining away fresh regressions is exactly how the Phase 10 close shipped
  them unnoticed.
- **Principal ruling**: FIX all 9 children with `min-w-0` (6 in
  opportunity-offers, 3 + the Row root in apartment-detail-dialog), LOWER the
  ratchet truthfully. **Validated by**: scan exit 0 (0 regressions).

### Challenge 5 — Is the "API-ready" import actually finished? (A6 vs the original gate)

- **The original gate's position**: D1 disclosed as remaining UI work (the
  API verified at round-trip level).
- **A6's challenge**: "a capability without its usable interface is not the
  required experience" (the master prompt's own law: no placeholder
  interactions presented as complete capabilities).
- **Principal ruling**: D1 is REAL remaining work — this round closes it
  with the full wizard + browser-verified journey + trilingual + mobile +
  dark + RBAC evidence. **Validated by**: the 14-capture evidence pack.

## The architecture approval gate (§13 — the 24 items, continuation state)

1. Current-state architecture — VERIFIED (§1 of CURRENT_STATE_DISCOVERY).
2. Target domain model — unchanged (no schema change; AD-C3).
3. Required database changes — NONE (additive UI only; census preserved).
4. Role-permission matrix — extended by usage, not definition (the inventory.import lane live-verified).
5–16. The lifecycle/pricing/matching/proposal/hold/API/search items — unchanged from verdict A; re-verified by 963/963.
17. File/media architecture — untouched.
18. API architecture — untouched (AD-C3).
19. Search/filtering — untouched.
20. UX screen map — +1 surface (the wizard).
21. Mobile workflows — verified at 390px (scrollWidth=390).
22. Security test strategy — legacy adversarial suites green in the 963/963 run.
23. Migration strategy — N/A this round (no migration).
24. Performance strategy — unchanged; the wizard adds one bounded dialog surface.

**Approved**: the continuation backlog (C-1..C-10) executed immediately
after this gate — no TODOs were created before it, and no code was written
before the approval (the §3 governance held).
