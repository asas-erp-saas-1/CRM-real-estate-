# ASAS CRM — Phase 10 — Property Matching Specification (A3)

## The engine (deterministic — deliberately no AI/ML, §5-A3)

`src/lib/server/matching.ts` — the single implementation (no duplicate, §14): weighted scoring with org-tunable weights (Settings, `matching.weights`), deterministic truncation (price asc, id tiebreaker, take 500), top-20 persistence with atomic replacement + preserved PRESENTED rows.

## Customer requirements (Requirement — lead-anchored)

Structured fields (all optional, never free-text-only): budgetMin/Max, propertyType, surfaceMin/Max, district, floorMin/Max, parking, bedroomsMin, payment, purpose, timeframe + **Phase 10 enrichment**: bathroomsMin, wantsBalcony, wantsTerrace, view, finishing, **hardFilters** (JSON array of must-have dimension keys).

### The hard/soft distinction (§5-A3-B/C)

`hardFilters` keys (closed vocabulary, `MATCH_HARD_FILTER_KEYS`): budgetMax, propertyType, surfaceMin, parking, bedroomsMin, district, bathroomsMin, balcony, terrace, view, finishing.

- **Hard (must-have)**: the dimension ELIMINATES (reason `hard:<dimension>`; score 0). Unknown spec values on a hard dimension also eliminate (`hard:<dimension>-unknown`) — a must-have can never be confirmed on unknown data.
- **Soft (nice-to-have)**: weighted scoring (unchanged legacy behavior when hardFilters is null — zero regression for every existing requirement).

## Opportunity-context execution (Journey C)

`POST /api/matching/opportunities/:id/match` — D-021-scoped (the deal must be visible): resolves the deal's lead → requirement → `computeLeadMatches` (the SAME core) → returns ranked matches with parsed reasons + per-unit freshness. The UI surface: the opportunity detail's « Biens correspondants » tab.

## Scoring & explanation — see MATCHING_SCORING_AND_EXPLANATION.md (the dedicated weights/explanation document).

## Ranking, filtering, comparison (§5-A3-E/F)

- Results respect `OPEN_APARTMENT_STATUSES` (AVAILABLE only — unavailable/unauthorized units excluded by construction; org-scoped queries).
- Freshness disclosure: every scored result carries `freshness:VERIFIED|RECENT|STALE|UNKNOWN` in its reasons + the read model exposes the classification — stale units never hide behind a confident score.
- Comparison: `GET /api/matching/compare?ids=` (2–4 units) — full side-by-side specs (browser-verified with the freshness warning rendering).
- Linking units to an opportunity: the pre-existing PropertyMatch lifecycle (SUGGESTED → PRESENTED → ACCEPTED/REJECTED — the customer feedback record) + offer creation on the matched unit (Journey D).

## Matching history (§5-A3-F)

PropertyMatch rows persist (score, reasons, status) with atomic top-20 replacement; PRESENTED facts are preserved as history; re-runs are idempotent upserts (no duplicate rows — the unique `[requirementId, apartmentId]` constraint).

## Journey C — browser-verified

Rep opens opportunity → Matching tab → « Lancer le matching » → ranked candidates (90%, 59% chips + reason chips « Dans le budget ») → comparison selection → side-by-side table with freshness disclosure. Evidence: `p10-05-matching-results.png` + `p10-06-unit-comparison.png`.
