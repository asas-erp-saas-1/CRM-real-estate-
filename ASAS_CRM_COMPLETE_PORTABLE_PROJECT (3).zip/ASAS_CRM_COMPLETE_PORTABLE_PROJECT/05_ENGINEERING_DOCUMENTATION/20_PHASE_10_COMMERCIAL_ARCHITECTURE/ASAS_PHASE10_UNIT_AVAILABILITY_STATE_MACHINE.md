# ASAS CRM — Phase 10 — Unit Availability State Machine (A2)

## The state vocabulary (mapped, not duplicated — §5-A2)

| Phase 10 concept | Implemented as | Note |
|---|---|---|
| AVAILABLE | `AVAILABLE` | reusable |
| OPTIONED / HELD | `OPTIONED` | the Offer live-hold mirror |
| RESERVED | `RESERVED` | the Reservation live-hold mirror |
| SOLD | `SOLD` | set ONLY by reservation convert |
| UNAVAILABLE | `UNAVAILABLE` | reusable |
| WITHDRAWN | `OFF_MARKET` (+ `BLOCKED` for administrative blocks) | mapped — existing convention documented |
| DRAFT | — | units are born AVAILABLE; construction-stage meaning lives on `Project.status` |

**One authoritative status field, two writer classes:**
1. The lifecycles (offer/reservation/sweeper) — guarded, evented, in-tx.
2. The console (MANAGER+) — validated through `transitionApartmentStatus` (the explicit law table below).

## The manual transition law (`MANUAL_APARTMENT_TRANSITIONS`)

```
AVAILABLE   → BLOCKED | UNAVAILABLE | OFF_MARKET
BLOCKED     → AVAILABLE | UNAVAILABLE | OFF_MARKET
UNAVAILABLE → AVAILABLE | BLOCKED | OFF_MARKET
OFF_MARKET  → AVAILABLE | BLOCKED | UNAVAILABLE
OPTIONED    → (none — the live offer owns the status)
RESERVED    → (none — the live reservation owns the status)
SOLD        → (none — the administrative exception is the existing force=true PATCH path, audit-gated)
```

Guards (in order): 404 ghost-identical → NOOP self-transition → inherited SOLD guard (FORBIDDEN_TRANSITION) → live-hold law (TRANSITION_NOT_ALLOWED with the precise hint: « annulez ou laissez expirer l'offre/la réservation »).

A valid transition = status + statusReason + freshness re-anchor + **UnitAvailabilityEvent (source MANUAL)** + audit row — ONE transaction.

## Double-booking protection (§5-C — unchanged, strengthened by events)

- Partial unique indexes (raw SQL, pre-existing): `Offer_apartment_live_hold_uq` / `Offer_opportunity_live_hold_uq` / `Reservation_apartment_live_hold_uq` / `Reservation_opportunity_live_hold_uq` — WHERE status IN (live set). SQLite serializes writes: two conflicting holds cannot commit. P2002 → precise 409s.
- In-tx guards first (precise codes): ALREADY_RESERVED / UNIT_OPTIONED / UNIT_NOT_HOLDABLE / OPPORTUNITY_ALREADY_OPTIONED / OPPORTUNITY_ALREADY_BOOKED.
- Concurrency-proven by the offer/reservation concurrency suites (offer-concurrency.test.ts, booking-semantics) — all green in the 963/963 run.
- **Never frontend-only**: every check above is server-side; the UI merely reflects it.

## Temporary hold lifecycle (§5-B)

The Offer ACTIVE/CONFIRMED **is** the temporary hold (unit → OPTIONED):
- Required: expiresAt (future) at activation — a null/past clock on a live hold is impossible (EXPIRY_REQUIRED / EXPIRES_AT_PAST).
- A hold NEVER silently becomes a reservation: convert is an explicit MANAGER+ action that creates the Reservation in ONE transaction.
- Expiry sweeper (`expiry.ts`, lazy + scheduled): ACTIVE/CONFIRMED past expiresAt → EXPIRED + guarded release (OPTIONED → AVAILABLE only when the unit still mirrors the hold and no live reservation took over) + SWEEPER availability event. **An expired hold cannot remain active indefinitely.**

## Freshness policy (§5-D)

`availabilityVerifiedAt` + org policy (OrgSetting `inventory.freshness`: verifiedDays 7 / staleDays 30 defaults, OWNER-tunable):

| Level | Meaning | UI |
|---|---|---|
| VERIFIED | verified ≤ 7d | emerald chip |
| RECENT | ≤ 30d | sky chip |
| STALE | > 30d | amber chip + warning line |
| UNKNOWN | never verified | stone chip + warning line |

- Manual transitions re-anchor freshness (the actor verified it by acting).
- The verify action re-anchors WITHOUT a transition (distinct surface).
- Matching results carry the freshness classification (reason `freshness:X` + the match read model) — **a stale unit is never presented as confidently available** (browser-verified: the comparison dialog shows the stale warning).

## Availability history (§5-E — append-only)

Every meaningful change leaves a `UnitAvailabilityEvent` (actor, previous state, new state, reason, source). The history surface (`GET apartments/:id/history`) joins actor names, classifies freshness, and caps at the latest 100 per stream. History lives from the migration forward (the pre-Phase-10 past stays in AuditLog — the authoritative pre-existing trail, unchanged).

## Journey B — browser-verified

Authorized user (MANAGER) → requested AVAILABLE→BLOCKED with motive → server validated → event + actor + reason recorded → updated availability visible → transition back performed → the complete trail queryable. Evidence: `05_ENGINEERING_DOCUMENTATION/20_PHASE_10_COMMERCIAL_ARCHITECTURE/evidence/p10-03-availability-transition.png` + the event log excerpt in TEST_EVIDENCE.
