# ASAS CRM — Phase 10 — Commercial Offer Architecture (A4)

## Three distinct concepts, three distinct mechanisms (§5-A4 law)

| Concept | Mechanism | Lifecycle |
|---|---|---|
| Unit asking price | `Apartment.price` (+ parkingPrice, priceUpdatedAt, UnitPriceEvent) | price console / import |
| Commercial offer | `Offer` + the frozen itemized snapshot | the extended offer state machine |
| Temporary hold | Offer ACTIVE/CONFIRMED ↔ `Apartment.status=OPTIONED` | the pre-existing live-hold machinery (unchanged) |

The Offer model was EXTENDED (migration #28) — no duplicate Proposal model, no second state system.

## The extended state machine

```
DRAFT ──submit_approval──▶ PENDING_APPROVAL ──approve_discount──▶ APPROVED
  ▲                             │                                    │
  │◀────────reject_discount─────┘                                    │
  │                                                                  ├──activate──▶ ACTIVE ──confirm──▶ CONFIRMED ──convert──▶ CONVERTED
  │                                                                  │                │                     │
  └── (cancel from any live/prep state — manager, reason-gated) ─────┘                │                     │
                                                            reject_customer ──▶ REJECTED        (terminal)
                                                                                    (terminal)     EXPIRED (sweeper)
```

- **PENDING_APPROVAL**: the discount gate — no hold, unit untouched.
- **APPROVED**: cleared to present.
- **ACTIVE**: the hold + the presentation moment (`presentedAt` stamped — Phase 10 maps PRESENTED here).
- **CONFIRMED**: client commitment (`confirmedAt` — maps ACCEPTED).
- **REJECTED** (new terminal): the customer's NO — recorded by the responsible rep (`customerResponse`, note, respondedAt), hold released.
- EXPIRED: sweeper-only. CANCELLED: manager-only, reason REQUIRED.

Editability law: DRAFT/ACTIVE patchable; PENDING_APPROVAL (a decision pends), APPROVED (the cleared document — revise instead), and all terminal states refuse a PATCH (422 OFFER_NOT_EDITABLE).

## The frozen price snapshot (Journey G law)

At creation (and at every revision) against a unit, the offer freezes: `basePrice` (the unit's price), `parkingPrice`, serialized `additionalOptions` [{label, amount}], then composes `discountAmount`, `discountPercent`, `finalTotal`. A later unit price change NEVER rewrites them (browser-verified: v1 kept 12.15M after the revision created v2 at 12.5M). The proposal route additionally discloses the unit's CURRENT price so the reader sees the drift honestly.

The `amount` law: an EXPLICIT amount stays the negotiated headline (the historical contract — the reservation books at it; regression-caught and fixed by the offer-concurrency suite); the itemized finalTotal takes over only when the caller relied on the unit's pricing.

## Versioning (supersede, never overwrite)

`POST /api/offers/:id/revise` — a NEW row (version+1, fresh snapshot of the unit's CURRENT terms) + the old row stamped `supersededById`/`supersededAt` (+ CANCELLED « Remplacée par la version N » when it was live, its hold released in the SAME transaction — the one-live-offer law holds). Revisable from ACTIVE/APPROVED/REJECTED/EXPIRED. The version chain is readable on the proposal document (« Version 1 de 1 », the chain list).

## The customer response (Journey E)

`POST /api/offers/:id/respond` `{response: "REJECTED", note?}` — ACTIVE → REJECTED terminal, hold released, response recorded. The YES path is the existing confirm action. Every presentation stamps `presentedAt` (activation) — the proposal version remains unchanged after presentation (only cancel/reject/expire/convert close it).

## The proposal document (§5-A4-E)

`GET /api/offers/:id/proposal` + the print-ready presentation dialog: agency identity, client, unit specs (unknowns omitted), project + developer, **itemized pricing** (base + parking + options − discount = total), validity (expiry; expired chip), terms, representative contact, version chain, and the muted disclaimer « Document commercial — ne constitue pas un contrat signé ». AR/FR/EN + RTL (browser-verified: `p10-11-proposal-presentation.png`).

**Output/sharing (§5-A4-F)**: print-ready view + window.print() with print CSS (implemented). PDF generation as a rendered file is NOT verified in this environment — disclosed limitation (the print path produces the PDF through the browser). No WhatsApp/email/SMS delivery is claimed (no configured integration — the existing WhatsApp deep-links remain the only sharing primitive).

## Proposal history (§5-A4-G)

Draft/approval/presentation/response/expiry/cancellation/revision trails: AuditLog rows (OFFER_CREATED / ACTIVATED / CONFIRMED / CONVERTED / CANCELLED / EXPIRED / DISCOUNT_SUBMITTED / DISCOUNT_APPROVED / DISCOUNT_REJECTED / REJECTED_BY_CUSTOMER / REVISED — all in-tx with their mutations, F-06) + Activity timeline rows + the version chain. **A presented proposal is never silently overwritten** (revision is explicit and chain-linked).
