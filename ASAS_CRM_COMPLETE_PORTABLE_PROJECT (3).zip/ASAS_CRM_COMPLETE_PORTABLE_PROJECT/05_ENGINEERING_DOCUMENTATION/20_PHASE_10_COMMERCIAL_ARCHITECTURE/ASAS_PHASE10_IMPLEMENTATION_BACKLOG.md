# ASAS CRM — Phase 10 — Implementation Backlog (Continuation Round)

Created ONLY after the six-agent discovery and the Principal architecture
gate (the §14 order). Every TODO carries its priority, files, dependencies,
acceptance criteria, and verification method. This is the round's truthful
register — no inflating, no splitting coherent features, no duplicating
verified functionality.

| ID | Priority | Title | Files | Status |
|---|---|---|---|---|
| C-1 | P1 | Client contract types for the import preview/commit | `src/lib/client/types.ts` | ✅ DONE |
| C-2 | P1 | Full wizard i18n key set (FR/EN/AR, ~57 keys) | `src/lib/i18n/domains/inventory.ts` | ✅ DONE (parity 10/10) |
| C-3 | P1 | The Import Units wizard — 4 steps, all-or-nothing law, honest no-undo | `src/components/crm/properties/import-units-dialog.tsx` (new) | ✅ DONE |
| C-4 | P1 | MANAGER+ trigger in the control-center header | `src/components/crm/properties/inventory-dashboard.tsx` | ✅ DONE (RBAC live-verified) |
| C-5 | P1 | Engineering gates: lint + typecheck | — | ✅ DONE (0 errors / 0 errors) |
| C-6 | P1 | Browser acceptance: full journey + AR RTL + EN + mobile 390 + dark + RBAC | `evidence/p10-continuation/` | ✅ DONE (14 captures, 0 console errors) |
| C-7 | P1 | Dialog-rect scan guard: fix the 9 latent debts + lower the ratchet | `opportunity-offers.tsx`, `apartment-detail-dialog.tsx`, `scripts/dialog-rect-scan.mjs` | ✅ DONE (exit 0) |
| C-8 | P1 | The definitive sequential regression | — | ✅ DONE (963/963) |
| C-9 | P2 | Documentation: §19's 17-deliverable contract | `05_ENGINEERING_DOCUMENTATION/20_PHASE_10_COMMERCIAL_ARCHITECTURE/` | ✅ DONE (README index + 5 new docs + updates) |
| C-10 | P2 | Round close: commit + watchdog + verdict | repo + scheduler | ✅ DONE |

## Acceptance criteria → evidence (per TODO)

- **C-1/C-3**: the wizard consumes the typed contract; requests observed in
  dev.log; the preview table renders server-parsed values (F3/70 m²/14M DA —
  captures 06).
- **C-4**: OWNER sees + uses the trigger (captures 01–07); SALES_AGENT sees
  the dashboard with zero triggers (capture 13); the server gate
  pre-existing and unchanged.
- **C-5**: lint 0 errors (the same 40 pre-existing warnings as the Phase 10
  gate — zero new); typecheck exit 0.
- **C-6**: FR full journey — the ERROR CSV path (2 row errors listed, commit
  disabled, "0 valide(s)" pre-fix → "1 valide(s)" post-fix) then the CLEAN
  CSV path ("2 valide(s)", commit enabled, result step, DB round-trip: 2
  units + 2 IMPORT events + audit); AR RTL (dir=rtl, Arabic labels); EN
  labels; mobile 390 (scrollWidth=390, dialog usable); dark mode; zero
  console/page errors across all journeys.
- **C-7**: scan summary "29 clean, 6 with known baseline debt, 0
  REGRESSION(S)" — exit 0; the ratchet register documents the fix.
- **C-8**: `bunx vitest run --no-file-parallelism` — **59/59 files, 963/963
  tests** against the freshly restarted live server.
- **QA cleanup**: the 2 QA units + events + audit removed; census restored
  byte-identical (46; 35/1/1/1/1/7; integrity ok) — the live dashboard shows
  46/35, the quality panel 219/46 (capture 12).

## The carry-forward register (post-round, truthful)

- PDF export of the presentation: the print-ready view is the delivered
  path (no external channel claimed) — unchanged.
- Production build: house law (typecheck+lint representation).
- Remaining known-baseline dialog debts: 6 files under the scan guard
  (lowered ratchet; the guard runs exit-0).
- In-process redeem limiter: documented flake class (fresh server between
  back-to-back full suites).
- P9-D25: accepted documented risk (unchanged).
