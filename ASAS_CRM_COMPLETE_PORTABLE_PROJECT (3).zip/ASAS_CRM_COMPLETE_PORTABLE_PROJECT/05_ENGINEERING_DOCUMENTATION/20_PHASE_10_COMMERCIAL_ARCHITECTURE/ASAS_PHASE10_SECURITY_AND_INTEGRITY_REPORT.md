# ASAS CRM — Phase 10 — Security & Integrity Report

## Authorization (backend-enforced, never hidden buttons)

New permissions born WITH their live gates (the Phase 8 behavioral law): `inventory.change_availability` (availability transitions, MANAGER+), `inventory.change_price` (price + verify, MANAGER+), `inventory.quality.view` (quality, MANAGER+), `inventory.import` (import, MANAGER+), `offers.approve` (discount decisions, MANAGER+ rank floor + the lane authority check). Catalog integrity guards green (role templates closed under the catalog; tier monotonicity). The permission-matrix suite passed unchanged (963/963).

**The lane law verified LIVE in the browser**: a MANAGER's approval of a 5.08% discount → 403 DISCOUNT_ABOVE_MANAGER_AUTHORITY (« Approbation propriétaire requise »); the OWNER's approval of the same → 200. A rep cannot approve anything (rank floor); a manager cannot widen their own authority (structural).

## Org isolation / IDOR

Every new route composes the D-021 scoped lookups (`offerScope`/`oppScope`/orgId-scoped `findFirst`): foreign ids resolve ghost-identical 404s. The proposal/history/compare/matching/import/dashboard/quality routes all org-scoped. Cross-org leakage surfaces (search, autocomplete, exports, dashboards, attachments, direct URLs) unchanged and covered by the green adversarial suites (demo-isolation, permission-matrix, document-security, phase8-identity).

## Double-booking / financial integrity

- Partial unique live-hold indexes + in-tx guards (unchanged) — the offer/reservation concurrency suites green.
- Snapshot law: proposals freeze their pricing; unit price changes never rewrite them (Journey G browser-verified).
- Money: cents composition; negative/over-gross discounts refused; the negotiated-amount booking contract preserved (the regression the offer-concurrency suite caught was fixed and re-verified).
- Discount approval: full decision trail (requester, approver, motive, timestamps, before/after pricing).

## Confidentiality

No commission/margin/acquisition-cost field exists on any offer/proposal/matching/inventory surface (grep-verified; the §37/§38 economics stay on the MANAGER+ reservation surfaces). FIELD_REP read floors unchanged. No confidential promoter-agreement data in the model (documented decision).

## Mass assignment / forged identifiers

All bodies pass strict zod schemas with closed enums (`APARTMENT_STATUSES`, `UNIT_*`, `MATCH_HARD_FILTER_KEYS`, payment plans); unknown keys are dropped at validation. Status changes are action-routed (never a free-form `status` write); forged actor/org ids impossible (the session-derived orgId + scoped lookups). The phase8-identity forged-cookie/quick-login suites green.

## Import safety

All-or-nothing commit (no partial writes), never-overwrite duplicate law, structure resolution by NAME within the org (foreign ids impossible), bounded size/rows, formula-sigil CSV safety inherited from the house parser, audited with created ids.

## Adversarial coverage summary (§13 targets)

The mandatory adversarial table is carried by the pre-existing suites (all green in the 963/963 definitive run) + the Phase 10 additions: discount escalation (lane law — browser-verified), unauthorized approval (rank floor), proposal version manipulation (revision is explicit; historical rows immutable — terminal + not editable), price snapshot inconsistency (Journey G), expired hold reuse (sweeper + guards), concurrent holds (partial unique indexes), duplicate proposals (one-live-offer-per-deal law + P2002 backstop).

## Residuals (disclosed, non-blocking)

1. PDF as a generated file is unverified in this environment — the print-ready view is the delivered path (disclosed in the offer architecture doc).
2. The in-process redeem limiter window (5 min) makes back-to-back full-suite runs trip the token-budget tests — methodology artifact, documented; a fresh server run is green (verified).
3. `statusReason` keeps the last motive (cosmetic history field); the full trail lives in the event stream + AuditLog.
