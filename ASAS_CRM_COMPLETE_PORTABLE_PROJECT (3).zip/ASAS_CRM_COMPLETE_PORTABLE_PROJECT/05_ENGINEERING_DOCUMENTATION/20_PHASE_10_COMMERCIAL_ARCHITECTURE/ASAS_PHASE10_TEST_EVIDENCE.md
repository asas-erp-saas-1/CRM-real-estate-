# ASAS CRM — Phase 10 — Test Evidence

## The continuation round (2026-11-10 — the D1 closure + adversarial re-verification)

```
bunx vitest run --no-file-parallelism   (against the freshly restarted live server)
Test Files  59 passed (59)
     Tests  963 passed (963)
```

**Zero tests removed; zero assertions weakened.** The i18n parity suite
(10/10) now also guards the ~57 continuation wizard keys ×3 languages.

### The continuation's regression-caught-and-fixed (the process did its job — again)

1. **`validRows` display-integrity defect** — caught LIVE by the round's
   adversarial browser QA (not by a suite): the preview's valid-row count
   subtracted error ENTRIES, so a single row with two field errors
   undercounted the batch ("Importer 0 lot(s)" while one row was valid).
   Fixed to distinct error ROWS; re-verified live ("2 valide(s)" / "Importer
   2 lot(s)" on the clean CSV).
2. **Dialog-rect scan guard re-run (skipped at the original close)** —
   found the Phase 10 commit (fdcb99c) had shipped **+5 unguarded dialog
   grid children beyond the frozen baselines** (opportunity-offers +1,
   apartment-detail-dialog +4). All 9 offending children FIXED with
   `min-w-0` (not baselined away); the ratchet lowered
   (opportunity-offers removed from the registry; apartment-detail-dialog
   4→2). Scan now: **exit 0 — 29 clean, 6 with known baseline debt,
   0 REGRESSION(S)**.

### The continuation's browser evidence (agent-browser, live preview)

| Capture | Journey |
|---|---|
| `p10-continuation/01` | Inventory console + the NEW "Importer des lots" trigger (OWNER) |
| `02`–`07` | **The full wizard journey (FR)**: dropzone → mapping (auto-detected) → the ERROR path (row errors listed, commit disabled — the all-or-nothing law visible) → the CLEAN path ("2 valide(s)") → commit → result step |
| `08` | AR RTL (dir=rtl, Arabic labels) |
| `09`–`10` | Mobile 390 (scrollWidth=390 — no overflow; the wizard usable) |
| `11` | Dark mode |
| `12` | Post-cleanup census restoration (46/35; quality 219/46 — byte-identical) |
| `13` | **RBAC live**: SALES_AGENT sees the dashboard with ZERO import triggers |
| `14` | EN labels |

Console/page errors: **zero** across all journeys. Dev-log 500s: **zero**.

### The continuation's database evidence

The import QA round-trip through the REAL API: 2 units created (statusReason
"Import CSV", org-scoped) + 2 `UnitAvailabilityEvent` rows (NONE→AVAILABLE,
source IMPORT, reason carries the fileName) + the INVENTORY_IMPORTED audit
(createdCount 2 + the unit ids) — all verified by direct queries, then
**removed per the cleanup law**: census re-verified byte-identical (46;
35/1/1/1/1/7) with `PRAGMA integrity_check` ok. Zero residue.

### Methodology incidents (disclosed)

- The dev server was OOM-killed twice mid-round (the documented 2026-11-10
  class — test run + browser + server on the 4 GB VM); recovered twice via
  the p7.2 reaper-proof restart (double-fork → PID 1, health 200,
  migrations 28). The definitive 963/963 run executed against the freshly
  restarted server, per the sequential-discipline law.
- The first baseline attempt (before the restart) had 23 live-contract
  suites fail on reachability — environmental, not code (the server was
  already dead pre-run); the definitive post-restart run is green.

---

## The original definitive regression run (Phase 10 close)

```
bunx vitest run --no-file-parallelism
Test Files  59 passed (59)
     Tests  963 passed (963)
```

**963 = the Phase 9 baseline (932) + 31 Phase 10 tests. Zero tests removed; zero assertions weakened.** Every evolution of a pinned assertion is a documented spec extension (below).

### The sequential-discipline law

Parallel full-suite runs (57 workers + dev server) OOM-killed the dev server on this sandbox — the live-contract suites then failed on reachability, and one security-suite teardown left synthetic residue (recovered; census restored). The definitive runs therefore use `--no-file-parallelism` (the same resource discipline the Phase 9 gate documented). The 963/963 result is from a single clean sequential run against a freshly started server.

## New Phase 10 test files

| File | Tests | Coverage |
|---|---|---|
| `tests/unit/offer-pricing.test.ts` | 12 | Cents composition (+ drift determinism), gross/final/discount-percent math, DISCOUNT_EXCEEDS_GROSS/INVALID_DISCOUNT refusals, the three policy lanes (SELF/MANAGER/OWNER), **a manager cannot clear an exceptional discount**, a rep never approves, the options codec round-trip + corrupt-safety + zod refusal |
| `tests/unit/inventory-laws.test.ts` | 15 | Freshness classification boundaries (7/30-day edges, null=UNKNOWN, string anchors), the manual transition law (live-hold mirrors + SOLD admit NO console transition; market states never reach SOLD; the inherited SOLD guard), the closed event-source vocabulary, parseHardFilters (null/corrupt/unknown-key dropping, 11-key vocabulary), hard elimination per dimension **including unknown-spec elimination**, soft-vs-hard budget parity (legacy byte-parity), the preference bucket (bonuses, unknown-never-scores, clamping) |

## Evolved pins (spec extensions — stronger, not weaker)

- `offer-lifecycle.test.ts`: the partition test now covers DRAFT + PENDING_APPROVAL + APPROVED + live + terminal(REJECTED) = OFFER_STATUSES; authority test asserts the 4 new actions' managerOnly flags + the reject_discount mandatory reason; activate legality from APPROVED; cancel legality from the preparation states; submit/approve/reject/customer-decline edge laws; PENDING_APPROVAL/APPROVED refuse a PATCH. 
- `tests/contract/api.test.ts` + `observability.test.ts`: the migration pin 27 → **28** (the chain grew by exactly one migration — the truthful bookkeeping the test exists to assert).
- `health-envelope.test.ts`: the `uptimeSec > 0` boundary flake (a mocked poll inside the first second floors to 0) fixed to `>= 0` + an upper bound — the field-presence remains the pin; the boundary was never a behavior check.

## Regression-caught-and-fixed (the suites did their job)

`offer-concurrency.test.ts:452` caught a REAL Phase 10 regression at integration time: the itemized path had overridden the explicit negotiated `amount` (reservation booked 16.8M instead of 7.77M). Fixed to the amount law (explicit amount = the negotiated headline; finalTotal only when relying on unit pricing) — the suite re-verified green.

## Browser evidence (agent-browser, live preview)

| Capture | Journey |
|---|---|
| `p10-01` inventory console (metrics + quality) | A5 dashboard — real numbers |
| `p10-02` apartment dialog specs + availability | A1 spec fields (« Non renseigné ») + A2 freshness |
| `p10-03` availability transition | **Journey B** (AVAILABLE→BLOCKED, motive recorded, event + actor in the stream) |
| `p10-05` matching tab + results | **Journey C** (ranked + explained + freshness) |
| `p10-06` unit comparison | C comparison + the stale warning |
| `p10-07` offer creation (itemized preview, 5.1% + lane hint) | **Journey D** create + snapshot |
| `p10-08` PENDING_APPROVAL | D approval gate |
| `p10-09` discount approved | D **OWNER-lane approval after the live MANAGER 403** (the lane law verified adversarially in the browser) |
| `p10-10` offer ACTIVE (presented) | **Journey E** activation + hold |
| `p10-11` proposal presentation | E document (itemized, validity, disclaimer, version) |
| `p10-12` revision + cleanup | **Journey G** (v2 fresh pricing; v1 preserved + « Remplacée par la version 2 ») |
| `p10-13/14/15/16` | AR RTL (dir=rtl) · mobile 390 AR/FR (no overflow — scrollWidth=390) · desktop |

Console/page errors: **zero** across the entire verification. Dev-log 500s: **zero**.

## Database integrity evidence

Census before == after the migration == after all testing + browser verification (46 apartments; statuses byte-identical 35/1/1/1/1/7); `PRAGMA integrity_check` ok; the 2 browser-test offers consciously remain as CANCELLED history rows (their motives record the cleanup); 93 availability + 2 price events = the new audit streams working (lifecycle, sweeper, console, import sources all observed in the stream).
