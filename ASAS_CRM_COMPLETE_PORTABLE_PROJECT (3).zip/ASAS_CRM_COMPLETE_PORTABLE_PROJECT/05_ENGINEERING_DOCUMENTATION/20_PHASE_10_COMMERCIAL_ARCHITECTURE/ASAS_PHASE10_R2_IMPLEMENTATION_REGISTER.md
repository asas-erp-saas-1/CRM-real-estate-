# ASAS CRM — Phase 10 — Round 2 Implementation Register

The §14 backlog for this continuation round (created ONLY after the R2
six-agent re-audit + the architecture gate:
`ASAS_PHASE10_R2_ARCHITECTURE_DECISIONS.md`). Every TODO carried its
priority, files, and acceptance criteria; all items below are DONE and
verified — the register is the truthful record.

| ID | Priority | Title | Files | Status |
|---|---|---|---|---|
| R2-1 | P0 | Record lifecycle: `recordStatus` + `verifiedById` + Building unique (migration 29, default APPROVED — zero behavior change for live inventory/import) | `prisma/schema.prisma`, `prisma/migrations/20261110020000_p10_r2_record_lifecycle_authoring/` | ✅ DONE (46/46 APPROVED post-migration; integrity ok) |
| R2-2 | P0 | The authoring surface: 4 creation services + routes (developers/projects/buildings/apartments) — org-scoped, duplicate-guarded, event-anchored, audited in-tx | `src/lib/server/property-authoring.ts` (new), `api/properties/{developers,projects,buildings}/route.ts`, `api/properties/apartments/route.ts` (POST) | ✅ DONE (live API smoke: full chain 201s; dupes 409; money caps 422) |
| R2-3 | P0 | Record-status transition route + law table | `api/properties/apartments/[id]/record-status/route.ts` (new), `constants.ts` (APARTMENT_RECORD_TRANSITIONS) | ✅ DONE (browser + API: full law table incl. terminal ARCHIVED, illegal edge 422) |
| R2-4 | P0 | Catalog boundary: floor roles see APPROVED only (server-side, no opt-out); MANAGER+ explicit recordStatus filter | `api/properties/apartments/route.ts`, `matching.ts` (scan), `matching/compare/route.ts` | ✅ DONE (WITHDRAWN unit invisible to SALES_AGENT — browser-verified) |
| R2-5 | P1 | Money-cap closure: MAX_MONEY_DZD on price POST + PATCH + itemized composition + option lines | price route, PATCH route, `offer-pricing.ts`, apartments POST | ✅ DONE (1e15 → 422 on both surfaces) |
| R2-6 | P1 | Amount-lane closure: client amount below frozen finalTotal = undeclared discount → 422 AMOUNT_BELOW_POLICY_FLOOR (create + PATCH; revise was already safe) | `offer-pricing.ts` (assertAmountNotBelowFinalTotal), `offer-lifecycle.ts` (create + edit paths) | ✅ DONE (regression payloads aligned to the corrected law — subjects intact, zero assertions weakened) |
| R2-7 | P1 | Verification responsibility + audit fold: verifiedById persisted; verify leaves an audit row; availability/price audits commit INSIDE the service tx | `inventory-events.ts`, verify/price/availability routes | ✅ DONE |
| R2-8 | P1 | Policy configuration surface: discount lanes + freshness windows join OrgSettings (optional PUT keys — backward compatible) + settings UI card | `settings.ts`, settings route, `settings/policies-section.tsx` (new) | ✅ DONE (PUT full-shape 200; out-of-bounds 422; UI live) |
| R2-9 | P1 | The staged ADD PROPERTY wizard (spec §6): adaptive 4-type routing, type-conditional specs, money-capped commercial step, review + dual submit (DRAFT / submit-for-review), success with next action | `properties/add-property-dialog.tsx` (new) + dashboard trigger | ✅ DONE (browser E2E: full journey → PENDING_REVIEW → approve → withdraw) |
| R2-10 | P1 | Unit media closure: EntityDocuments mounted for APARTMENT (collapsible) + record-status badge + lifecycle action cluster in the detail dialog; micro-badges in table/cards | `apartment-detail-dialog.tsx`, `unit-table.tsx`, `apartment-card.tsx`, `badges.tsx` | ✅ DONE |
| R2-11 | P1 | Inventory UX: inline search (existing `query` param) + load-more past the 100-row cap | `inventory-filters.tsx`, `properties-view.tsx`, `workspace-store.ts` | ✅ DONE (search "A-1" → 3 units, browser-verified) |
| R2-12 | P1 | Import provenance + hygiene: initial-price UnitPriceEvent on import (previousPrice=0 convention); building scan org-scoped | `inventory/import/route.ts` | ✅ DONE |
| R2-13 | P1 | i18n: +90 keys ×3 (inventory domain) + 16 keys ×3 (settings domain) — parity enforced | `i18n/domains/inventory.ts`, `settings.ts` | ✅ DONE (module-load guard green; AR RTL browser-verified) |

## Acceptance evidence (per gate)

- **Regression**: 963/963 tests, 59/59 files (definitive sequential run against
  the live server). Five test files realigned to the corrected amount law
  (payloads documented in-place; the race/rollback/authority subjects are
  unchanged); migration pins 28→29.
- **Typecheck / lint**: 0 errors / 40 warnings (exact pre-existing baseline).
- **Browser E2E** (`evidence/p10-r2/`, 13 captures): OWNER full journey
  (wizard → submit PENDING_REVIEW → detail console → approve → withdraw),
  DB round-trip (events + anchors + audit rows), SALES_AGENT catalog boundary
  (WITHDRAWN invisible), inline search, settings policies, mobile 390
  (scrollWidth=390), AR RTL (dir=rtl lang=ar), final OWNER dashboard — zero
  console/page errors.
- **Security probes (live)**: 1e15 price → 422 on both mutation surfaces;
  WITHDRAWN→APPROVED → 422 RECORD_TRANSITION_NOT_ALLOWED; catalog filter
  enforced server-side.
- **Data preservation**: backup taken before any change
  (`db/backups/backup-20261110T021350Z`); migration additive-only; QA fixture
  (QA-R2-01 + events + audits + the failed-run's orphan reservation) removed
  after verification; census byte-identical (46; 35/1/1/1/1/7; integrity ok);
  demo preview preserved (demoMode true, 29 migrations, health 200).
