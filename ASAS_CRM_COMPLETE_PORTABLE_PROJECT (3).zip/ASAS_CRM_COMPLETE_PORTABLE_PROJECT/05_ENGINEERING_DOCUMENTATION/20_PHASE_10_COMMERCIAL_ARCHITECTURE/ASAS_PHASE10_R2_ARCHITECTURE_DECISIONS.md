# ASAS CRM — Phase 10 — Round 2 Architecture Decisions (Continuation)

**Round directive**: the owner re-issued the full Phase 10 task book
("BEGIN PHASE 10 CONTINUATION"). Per §3, this round re-ran the six-agent
discovery in MODE A (read-only) against the ACTUAL running system, then
produced this decision register before any code change (the §12/§13 gate).

## The six-agent re-audit verdict (2026-11-10, evidence-backed)

Engine layers VERIFIED STRONG (preserve, no rework):
- Offer snapshot law + version chain (`offer-lifecycle.ts` — frozen pricing,
  supersede chain, IMMUTABLE on ACTIVE presented offers).
- Hold/reservation concurrency (partial unique live-hold indexes + in-tx
  re-reads + P2002 → 409 mapping, race-tested).
- IDOR / mass-assignment / org-scope discipline (org-scoped findFirst on every
  audited `[id]` route; zod strips unknown keys; orgId from session only).
- Documents security (realpath containment, content sniffing, gated download).
- Freshness engine (classifyFreshness + disclosure in matching/compare/quality).
- Discount approval lanes (SELF/MANAGER/OWNER, structural manager ceiling).
- i18n/RTL (pre-hydration dir switch, logical CSS, ar-DZ latn digits).

Real gaps found (this round's mandate — file:line evidence in the agent
reports, `ASAS_PHASE10_SIX_AGENT_FINDINGS.md`):
1. **No interactive property authoring** — no POST for developers/projects/
   buildings/units; CSV import is the only path; projects cannot be created
   at all (the empty state even instructs creating one, with no affordance).
   Spec §6 "ADD PROPERTY" staged wizard: absent. DoD #7 fails.
2. **No record-status lifecycle** — publishing/approval status conflated with
   commercial availability; SALES_AGENT sees never-verified units as if
   approved. Spec §4-Agent2-A + DoD #9.
3. **Money-cap bypass** — `POST apartments/:id/price` and PATCH accept prices
   above MAX_MONEY_DZD (1e15 commits); offer option lines unbounded.
4. **Discount-lane bypass via `amount`** — client `amount` below the frozen
   `finalTotal` books without any approval event (`offer-lifecycle.ts:433`).
5. **Unit media dead-end** — 35/46 units flagged NO_IMAGES with zero UI upload
   path (EntityDocuments never mounted for APARTMENT). Spec §7 detail priority
   starts with the image.
6. **Unconfigurable policies** — `offer.discount.policy` +
   `inventory.freshness` have no write surface (settings PUT covers only 4
   unrelated keys); the documented "Owner tunes via Settings" is false.
7. **Verification actor dropped** — verify endpoint persists no verifiedById,
   no audit row; price/availability route audits commit OUTSIDE their tx.
8. **Import building scan org-unscoped**; `Building` lacks
   `@@unique([projectId, name])`; import writes NO initial-price event
   (UnitPriceEvent = 0 rows — provenance machinery runs on empty anchors).
9. **UX**: no inline inventory search (API `query` param unexposed), flat
   list caps at 100 with no load-more, no record-status surface anywhere.

## Round 2 decisions (the Principal's register)

**AD-R2-1 — Record-status lifecycle, separate from availability.**
New `Apartment.recordStatus` (DRAFT | PENDING_REVIEW | APPROVED | REJECTED |
WITHDRAWN | ARCHIVED), default **APPROVED** (the 46 live units keep today's
behavior; import keeps creating verified rows — import is MANAGER+-gated and
fully row-validated). Server law table (DRAFT→PENDING_REVIEW/ARCHIVED;
PENDING_REVIEW→APPROVED/REJECTED/WITHDRAWN; APPROVED→WITHDRAWN/ARCHIVED;
REJECTED→DRAFT; WITHDRAWN→PENDING_REVIEW; ARCHIVED terminal) — new route
`POST /api/properties/apartments/:id/record-status`, `properties.manage`
(MANAGER+ — the app's existing authority floor for inventory ops; the catalog
law "role sets mirror live enforcement" is preserved with ZERO catalog churn).
Catalog boundary at the DATA layer: SALES_AGENT/FIELD_REP unit queries and the
matching scan hard-filter `recordStatus: "APPROVED"` server-side (no opt-out).
Every transition audited (RECORD_STATUS_CHANGED, before/after/reason).

**AD-R2-2 — The authoring surface (creation APIs + wizard).**
Four new POSTs (developers/projects/buildings/apartments), all
`properties.manage`, org-scoped, zod-strict, audited in-tx, org-uniqueness
on names (409 + code), `@@unique([projectId, name])` on Building. Unit
creation writes BOTH event anchors (availability from NONE; price with
previousPrice=0 — documented convention: "no prior price existed") and stamps
availabilityVerifiedAt (a creation IS a verification act — the import law).
The UI is a staged wizard (spec §6): type choice → identity → location →
type-conditional specs → commercial → media hand-off → review+submit →
success with next action. Draft vs submit-for-review per the record lifecycle.

**AD-R2-3 — Money-cap closure.** MAX_MONEY_DZD on price POST/PATCH +
parkingPrice + offer itemized composition (server-side ApiError
MONEY_CAP_EXCEEDED in computeItemizedPricing — single choke point).

**AD-R2-4 — Amount-lane closure.** In create/revise/PATCH-amount paths: a
client `amount` below the frozen `finalTotal` is an UNDECLARED discount —
compute its implicit percent and route it through the SAME policy lanes;
above the caller's lane → 422 AMOUNT_BELOW_POLICY_FLOOR (the declared
discount path remains the only approval-bearing route). Amount ≥ finalTotal
is untouched (the historical contract).

**AD-R2-5 — Verification responsibility + audit fold.** `verifiedById` on
Apartment; verify writes it + an AUDITED event; availability/price route
audits fold INTO the service transaction (the F-06 law, closing the
crash-window gap).

**AD-R2-6 — Policy configuration surface.** `offer.discount.policy` +
`inventory.freshness` join the OrgSettings contract (optional keys on PUT —
zero break for existing callers; reader merges defaults; upsert-only-when-
present). Exposed in the settings UI under a "commercial policies" group.

**AD-R2-7 — Inventory UX completion.** Inline search wired to the existing
`query` param; load-more past the 100-row cap; record-status badges (shown
when ≠ APPROVED — APPROVED is the norm, not noise) + transition actions in
the detail dialog; EntityDocuments mounted for APARTMENT (media closure);
unit media also reachable post-creation from the wizard's success step.

**AD-R2-8 — Import provenance + hygiene.** Import writes the initial-price
UnitPriceEvent (source IMPORT); building scan org-scoped via
`project: { orgId }`.

**Deferred (documented, not silently dropped):** property-sourcing intake
(Agent 3's P0 — designed, next round's first item), field discrepancy intake,
requirement wilaya/commune/project criteria, matching hard-filter test suite,
developer dossier fields (RCC/address/status), price-event currency column,
record-status on Project/Developer. Each is registered in the backlog with
its evidence.

## Authority

This register closes MODE A. Cross-review challenges from the six agents were
resolved by the Principal (the resolution notes live in the findings doc).
MODE B (implementation) is authorized in backlog order P0 → P1.
