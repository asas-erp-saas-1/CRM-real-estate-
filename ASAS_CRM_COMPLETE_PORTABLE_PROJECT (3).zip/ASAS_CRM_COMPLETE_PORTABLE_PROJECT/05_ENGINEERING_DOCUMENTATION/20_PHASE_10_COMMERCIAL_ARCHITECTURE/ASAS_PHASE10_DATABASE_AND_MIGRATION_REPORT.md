# ASAS CRM — Phase 10 — Database & Migration Report

## Migration #28 — `20261109200000_p10_inventory_offer_engine`

**Additive-only** (the §10 law): 26 `ALTER TABLE … ADD COLUMN` (all nullable — explicit unknown), 2 new tables, 6 new indexes. No column dropped/retyped; no data rewritten; no partial-index work (the live-hold backstops untouched).

### Safety protocol executed (in order)

1. **Verified backup BEFORE any change**: `db/backups/backup-20261109T200342Z/` — VACUUM INTO snapshot, `PRAGMA integrity_check` OK on the snapshot, manifest + sha256 + census recorded.
2. **Isolated-copy migration test**: snapshot copied to `/tmp/p10-mig-test/test.db` → `prisma migrate deploy` against the copy → census IDENTICAL for all 13 existing tables (8 users, 1 org, 3 developers, 4 projects, 6 buildings, 46 apartments, 3 offers, 8 reservations, 14 requirements, 3 matches, 21 opportunities, 43 leads, 0 documents) + new tables present at 0 + `offer.version=1` default verified + integrity OK.
3. **Production deploy**: `prisma migrate deploy` → 28/28 applied, status clean.
4. **Post-deploy verification**: census identical (46/4/… — the exact pre-migration numbers), `PRAGMA integrity_check` ok, dev server healthy (health 200, dbOk, migrations: 28, demo mode preserved).
5. **Rollback path**: restore `backup-20261109T200342Z` (documented; no destructive path exists in the migration itself).

### Final state census (after all development + browser verification)

46 apartments (AVAILABLE:35, BLOCKED:1, OFF_MARKET:1, OPTIONED:1, RESERVED:1, SOLD:7 — **byte-identical to the pre-Phase-10 distribution**), 4 projects, 3 developers, 5 offers (1 ACTIVE + 1 CONVERTED + 1 DRAFT pre-existing + 2 browser-test offers, both CANCELLED with recorded motives — history by design), 8 reservations, 93 availability events + 2 price events (the new append-only streams: lifecycle instrumentation + console actions + imports), 21 opportunities, 43 leads.

### Incidents handled

- **Test residue** (a synthetic `P1-SCORE-DOM03-*` project with 3 units): left by a security-suite teardown that failed during an OOM-interrupted parallel run. Removed through a marker-targeted script (never touching owner data); census restored to 46/4. Disclosed in TEST_EVIDENCE.
- **Dev-server OOM kills** during parallel full-suite runs (57 workers + server): recovered by restart; the sequential-discipline law (`--no-file-parallelism`) adopted for definitive runs — the same methodology incident class the Phase 9 gate documented.

### Pre-existing migrations

All 27 prior migrations preserved verbatim; `prisma migrate status` clean; the raw-SQL partial unique indexes remain deploy-only law (untouched).
