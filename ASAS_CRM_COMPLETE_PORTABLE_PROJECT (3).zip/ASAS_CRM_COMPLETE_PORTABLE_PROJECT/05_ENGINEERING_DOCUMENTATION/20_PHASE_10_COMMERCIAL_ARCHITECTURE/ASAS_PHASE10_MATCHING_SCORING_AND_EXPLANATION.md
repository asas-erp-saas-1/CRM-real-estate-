# ASAS CRM — Phase 10 — Matching Scoring & Explanation (A3 §D)

## The core weight table (pre-existing, org-tunable via Settings)

| Dimension | Weight | Full | Partial | Miss |
|---|---|---|---|---|
| Budget | 35 | within range | ×0.6 within +10% over · ×0.4 under min | 0 |
| Location | 25 | district/name exact | ×0.3 same city | 0 |
| Surface | 15 | within range | ×0.5 within +15% over | 0 |
| Property type | 15 | exact | ×0.4 adjacent (±1 in type order) | 0 |
| Parking | 10 | has | — | 0 |
| Bedrooms | gate | — | hard miss → score ×0.5 | — |
| Floor range | soft penalty | — | reasons only | — |

**Phase 10 preference bonus bucket** (documented, capped): balcony +3 · terrace +3 · view match +2 · finishing match +2 · bathroomsMin satisfied +2. Unknown specs NEVER score (missing ≠ matched — the no-fabrication law). The composed score clamps at 0–100 (`clampScore` at every exit).

## Hard-filter elimination (Phase 10)

Dimensions listed in `Requirement.hardFilters` eliminate BEFORE any scoring: the result is `{score: 0, reasons: ["hard:<dimension>"]}` (or `hard:<dimension>-unknown` when the unit's spec is unknown). Default: no hard filters → legacy scoring byte-for-byte.

## Weight-selection disclosure (§5-A3-D)

- The 35/25/15/15/10 core predates Phase 10 (master prompt §15, org-tunable since R5) — preserved unchanged.
- The Phase 10 bucket (3/3/2/2/2) is capped so the bonus can lift a perfect core match to 100 but never dominate a dimension-level miss: it models "nice-to-have" exactly (§5-A3-C).
- Thresholds: ≥80 emerald / 50–79 sky / <50 stone (chip tones).

## The explanation contract (why a unit matches)

Reasons are machine strings persisted in `PropertyMatch.reasons` (JSON) and translated at display (matching i18n domain — FR/EN/AR). Example row (browser-verified):

> **N-02 — 90%** · « Dans le budget » · « Localisation exacte » · « Type exact » · « Parking » · « Fraîcheur : vérifiée »

A hard miss reads: **« Critère indispensable non satisfait — budget max »** (destructive-tone chip).

**No false precision (§5-A3-D law)**: the score is a compatibility CLASSIFICATION (0–100 weighted), not a probability of sale; the UI shows the percentage chip + dimension reasons, never "93% chance" claims. The dimensions a unit misses are always visible as chips (budget-close, parking-miss, floor-under…).

## Freshness in the explanation

Every surviving result carries `freshness:VERIFIED|RECENT|STALE|UNKNOWN`; the UI renders the freshness chip + (STALE/UNKNOWN) the warning « Disponibilité non vérifiée depuis longtemps — confirmez avant de présenter ce lot » — browser-verified in the comparison dialog.

## Test coverage

`tests/unit/matching.test.ts` (16, pre-existing, all green) + `tests/unit/inventory-laws.test.ts` (Phase 10: parseHardFilters closed vocabulary; hard elimination per dimension incl. unknown-spec elimination; soft-bucket bonuses; clamping; legacy no-hard-filter byte-parity).
