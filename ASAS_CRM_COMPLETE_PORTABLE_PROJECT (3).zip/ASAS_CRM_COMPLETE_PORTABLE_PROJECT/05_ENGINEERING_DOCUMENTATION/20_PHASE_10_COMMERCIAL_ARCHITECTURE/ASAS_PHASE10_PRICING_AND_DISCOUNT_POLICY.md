# ASAS CRM — Phase 10 — Pricing & Discount Policy (A4 §B/D + §8)

## The monetary semantics (§8 — preserved, never mixed)

Unit asking price (`Apartment.price`) · negotiated proposal price (`Offer.amount` / `finalTotal`) · reservation amount · payment amount · commission (Reservation §37) · agent incentive (§38) — **distinct values, distinct surfaces, never mixed**. No commission/margin field rides any offer/proposal/matching surface (the FIELD_REP/sales visibility laws unchanged).

## Itemized calculation (money-safe)

`computeItemizedPricing` composes in **integer cents** (floats only at the persistence boundary — the house Float-DZD law unchanged, drift-free composition):
```
gross      = base + parking + Σ options
finalTotal = gross − discount        (a discount > gross → 422 DISCOUNT_EXCEEDS_GROSS; negative → INVALID_DISCOUNT)
discountPercent = round(discount/gross × 10000)/100
```
Validation: non-negative prices/options, positive unit price, ≤ 20 options per offer, labels ≤ 120 chars. DZD formatting through the house formatter in all three locales (AR/FR/EN — browser-verified displays « 12 800 000 DA »).

## The discount policy (OrgSetting `offer.discount.policy`)

| Lane | Threshold (default) | Who may approve |
|---|---|---|
| SELF | ≤ agentMaxPercent (**0** — documented safe default: every discount is an approval event) | no approval needed |
| MANAGER | ≤ managerMaxPercent (**5**) | MANAGER+ |
| OWNER | above managerMaxPercent | ADMIN/OWNER only |

- Owner-tunable through the audited Settings surface; defaults documented, **not invented business numbers**.
- Structural law (§5-A4-D): a SALES_AGENT never approves (rank floor MANAGER+ on the decision routes); **a MANAGER cannot clear an exceptional discount** — `assertCanApproveDiscount` refuses with 403 DISCOUNT_ABOVE_MANAGER_AUTHORITY. Browser-verified live: a 5.08% request was refused to the MANAGER with the precise message and cleared by the OWNER (`p10-08`/`p10-09`).
- Every decision records: requested discount (amount + percent), requesting user, approving user, timestamps, **mandatory motive** (422 REASON_REQUIRED), before/after pricing (the audit before/after snapshots).
- An edited discount on a DRAFT re-enters the gate from zero (approval stamps reset).

## Approval workflow (Journey D — browser-verified end-to-end)

Create with discount → **PENDING_APPROVAL** (activation deferred — the hold is NEVER taken behind an undecided discount) → decision (approve → APPROVED / reject → DRAFT for revision, both motive-gated) → activate (presentedAt + hold) → confirm/convert. The activation guard refuses a DRAFT carrying an unapproved discount (422 DISCOUNT_APPROVAL_REQUIRED).

## Financial integrity validation (§8 checklist)

Non-negative ✓ (route guards) · valid discounts ✓ (lane law + caps) · correct totals ✓ (cents composition + tests) · currency ✓ (DZD only; no exchange rates invented) · price history ✓ (UnitPriceEvent) · reservation-amount consistency ✓ (amount = the negotiated headline; the regression caught by offer-concurrency was fixed to preserve exactly this) · discount authorization ✓ (lane law, browser-verified) · snapshot persistence ✓ (Journey G browser-verified).

Confidential financial fields (commission, margin, acquisition cost) never appear on offer/proposal/matching surfaces — gated to the reservation-economics MANAGER+ surfaces exactly as before (permission-matrix + demo-isolation suites green).
