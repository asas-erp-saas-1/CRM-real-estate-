# ASAS CRM — Phase 10 — Real Estate Domain Audit

**Principal**: what already exists (verified in schema + code), what is missing against the Phase 10 mandate, and the reuse-vs-build decision for every concept. Law: *no duplicate models because naming differs* (§10).

## 1. Concept-by-concept existence mapping

| Phase 10 concept | Existing model / mechanism | Verdict |
|---|---|---|
| Developer / promoter | `Developer` (org-scoped, AR alias, contacts, notes) | **EXISTS — reuse** |
| Commercialization agreements | — (out of scope of stored data; `Developer.notes` carries free text) | NOT BUILT (confidentiality: no secret data to protect) — documented decision |
| Project | `Project` (developer FK, city/district/address, status, deliveryDate, description, AR alias) | **EXISTS — reuse** |
| Building / block / phase | `Building` (project FK, floors) | **EXISTS — reuse** |
| Unit | `Apartment` (code, unitType, rooms, bedrooms, surface, floorNumber, orientation, parking, price, status, paymentPlan, notes; unique [orgId, buildingId, code]) | **EXISTS — EXTEND** (spec fields below) |
| Unit availability lifecycle | `Apartment.status` + offer/reservation lifecycles mutate it in-tx + `FORBIDDEN_APARTMENT_TRANSITIONS` guard on PATCH | **EXISTS — EXTEND** (explicit transition table + events) |
| Availability history | AuditLog rows (APARTMENT_STATUS_CHANGED) only | **MISSING → build `UnitAvailabilityEvent`** |
| Price history | AuditLog rows (PRICE_CHANGED) only | **MISSING → build `UnitPriceEvent`** |
| Availability freshness | — | **MISSING → `availabilityVerifiedAt` + freshness policy** |
| Customer requirement profile | `Requirement` (lead-anchored: budget, type, surface, district, floor, parking, bedrooms, payment, purpose, timeframe) | **EXISTS — EXTEND** (bathrooms, balcony/terrace, view, finishing, hard/soft flags) |
| Property match record | `PropertyMatch` (score, reasons JSON, SUGGESTED/PRESENTED/ACCEPTED/REJECTED, unique [requirementId, apartmentId]) | **EXISTS — reuse** |
| Commercial offer / proposal | `Offer` (DRAFT→ACTIVE→CONFIRMED→CONVERTED; hold + expiry + cross-guards + partial unique indexes) | **EXISTS — EXTEND** (snapshot, versions, discount approval, REJECTED) |
| Temporary unit option / hold | Offer ACTIVE/CONFIRMED *is* the hold (`Apartment.status = OPTIONED`, DB-enforced) | **EXISTS — reuse** (a hold never silently becomes a reservation: convert is an explicit MANAGER+ action) |
| Discount approval | — | **MISSING → offer columns + policy in OrgSetting** |
| Price snapshot / itemized pricing | `Offer.amount` single value only | **MISSING → itemized snapshot columns** |
| Proposal versioning | — | **MISSING → version + supersededById chain** |
| Reservation | `Reservation` (live-hold uniqueness, two-step closure, economics) | **EXISTS — reuse unchanged** |
| Unit/project images & docs | `Document` (entityType LEAD/OPPORTUNITY/RESERVATION/APARTMENT/PROJECT/VISIT; secure disk storage `db/docs`) | **EXISTS — reuse** |
| Inventory CSV import | Leads import infra exists (csv.ts, dry-run/undo patterns) — nothing for units | **MISSING → controlled import** |

## 2. State vocabulary mapping (§5-A2 "map to actual existing values")

| Phase 10 proposed state | Existing `Apartment.status` value | Decision |
|---|---|---|
| DRAFT | — (units are born AVAILABLE; project-level status exists on `Project`) | NOT added — no duplicate concept; `Project.status` covers construction-stage meaning |
| AVAILABLE | `AVAILABLE` | reuse |
| OPTIONED / HELD | `OPTIONED` (the Offer hold mirror) | reuse |
| RESERVED | `RESERVED` (the Reservation mirror) | reuse |
| SOLD | `SOLD` (set by reservation convert; cannot silently return — FORBIDDEN_TRANSITIONS) | reuse |
| UNAVAILABLE | `UNAVAILABLE` | reuse |
| WITHDRAWN | `OFF_MARKET` (+ `BLOCKED` for administrative blocks) | **mapped, NOT renamed** (existing convention documented) |

One authoritative status field — `Apartment.status`. No competing field is introduced (§5-A2 law).

## 3. Offer lifecycle mapping (§5-A4 "map or adapt to existing conventions")

| Phase 10 proposed state | Existing | Decision |
|---|---|---|
| DRAFT | DRAFT | reuse |
| PENDING_APPROVAL | — | **add** (discount approval gate before presentation) |
| APPROVED | — | **add** (discount approved, ready to activate/present) |
| PRESENTED | ACTIVE (takes the hold; the live offer) | **mapped to ACTIVE + `presentedAt` stamp** |
| ACCEPTED | CONFIRMED (`confirmedAt`) | reuse |
| REJECTED | — | **add** (terminal: customer declined — recorded by the agent) |
| EXPIRED | EXPIRED (sweeper-only) | reuse |
| CANCELLED | CANCELLED (reason-gated, releases hold) | reuse |

Three distinct concepts preserved (§5-A4): unit asking price = `Apartment.price`; commercial offer = `Offer` (+ snapshot); temporary hold = Offer ACTIVE/CONFIRMED ↔ `Apartment.status=OPTIONED`. No concept is duplicated.

## 4. Gaps that Phase 10 must build (the work list)

1. **Unit spec enrichment** (A1): `bathrooms`, `totalSurface`, `balcony`, `terrace`, `view`, `finishing`, `deliveryStatus`, `parkingPrice` — all nullable, explicit unknown, never fabricated.
2. **Inventory events** (A2): `UnitAvailabilityEvent` + `UnitPriceEvent` tables; explicit transition law; actor/reason/source on every event.
3. **Freshness** (A2): `availabilityVerifiedAt` + configurable staleness policy + UI disclosure (verified / recent / stale / unknown).
4. **Matching upgrades** (A3): hard-vs-soft filter distinction on requirements; opportunity-context execution (existing engine reused); side-by-side comparison; freshness disclosure on results.
5. **Commercial offer engine** (A4): itemized price snapshot (base + parking + options − discount = total), discount policy (OrgSetting) + threshold-gated approval workflow, versioning via supersede chain, REJECTED terminal state, presentation view.
6. **Inventory console** (A5): real metrics dashboard, data-quality view, availability/price management UX, controlled CSV import.
7. **Permission catalog extension** (§6): `inventory.change_availability`, `inventory.change_price`, `inventory.import`, `offers.approve` — each wired to a live server gate at birth (the Phase 8 behavioral law).

## 5. Migration safety plan (§10)

1. ✅ Verified backup (`backup-20261109T200342Z`, integrity-checked).
2. Migration tested on an isolated DB copy first (`prisma migrate deploy` against a copy via `DATABASE_URL` override).
3. Census before/after must be identical for all existing tables (additive-only migration).
4. `PRAGMA integrity_check` after deploy; dev-server health + migration status verified.
5. Rollback = restore snapshot (documented; no destructive path exists in the migration).
