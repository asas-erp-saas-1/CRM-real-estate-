# ASAS CRM — Phase 10 — Round 2 Six-Agent Re-Audit Findings

**Round**: 2026-11-10 (MODE A, read-only, zero code changes during discovery).
The owner re-issued the full Phase 10 task book; per §3/§4 the six agents
re-audited the ACTUAL running system before this round's plan.

## Method

Six parallel discovery agents (1-a Domain/DB · 1-b Lifecycle/Pricing · 1-c
Roles/Workflow · 1-d Matching/Commercial · 1-e API Security · 1-f UX/QA), each
independently reading the live code, the live database (read-only), and — for
1-f — the live browser. Full evidence in the agents' reports (consolidated
below with file:line citations).

## Verified strong (preserve — no rework)

| Layer | Verdict | Anchor evidence |
|---|---|---|
| Offer snapshot law + versioning | STRONG | offer-lifecycle.ts:404–470 (frozen pricing), 1466–1597 (supersede chain), 636–651 (ACTIVE immutable) |
| Hold/reservation concurrency | STRONG | live-hold partial unique indexes + in-tx re-reads + P2002→409; race-tested |
| IDOR / org-scope / mass-assignment | STRONG | org-scoped findFirst on every audited [id] route; zod strips unknown keys; orgId session-only |
| Documents security | STRONG | realpath containment, content sniffing, gated downloads |
| Freshness engine | STRONG | classifyFreshness + disclosure in matching/compare/quality/dashboard |
| Discount approval lanes | STRONG (one bypass — closed this round) | offer-pricing.ts:150–181 |
| Matching determinism + hard/soft split | STRONG | matching.ts:104–260 |
| i18n/RTL/mobile | STRONG | pre-hydration dir switch; 390px verified clean |

## The gaps (drove this round's scope)

1. **P0 — No interactive property authoring.** No POST for developers/projects/
   buildings/units; CSV import the only path; projects uncreatable at all; the
   spec §6 staged wizard absent; the empty state even instructs creating a
   project with no affordance (properties.ts:55).
2. **P0 — No record-status lifecycle.** Publishing/approval conflated with
   availability; SALES_AGENT sees never-verified units as approved
   (apartments/route.ts requireUser-only). DoD #9 unmet.
3. **P1 — Money-cap bypass.** POST price + PATCH accept 1e15 (route.ts:16,
   :44/:105); offer option lines unbounded (offer-pricing.ts:65);
   money-cap.test.ts probes none of these.
4. **P1 — Discount-lane bypass via amount.** Client amount below frozen
   finalTotal books with zero approval events (offer-lifecycle.ts:433,
   PATCH :667); convert books the reservation at it (:1355).
5. **P1 — Unit media dead-end.** 35/46 units NO_IMAGES with zero upload UI
   (EntityDocuments never mounted for APARTMENT; detail-dialog.tsx:688).
6. **P1 — Unconfigurable policies.** offer.discount.policy +
   inventory.freshness have NO write surface (settings.ts:57–74 covers only 4
   unrelated keys; the "Owner tunes via Settings" comment was false).
7. **P1 — Verification actor dropped + audit outside tx.** verify persists no
   verifiedById/audit (inventory-events.ts:307–321); availability/price route
   audits commit after their service tx (F-06 violation class).
8. **P2 — Import provenance + hygiene.** No initial-price UnitPriceEvent on
   import (stream = 0 rows); building scan org-unscoped (:411); Building lacks
   @@unique([projectId, name]).
9. **P2 — UX.** No inline search (API query param unexposed); flat list caps
   at 100 with no load-more; no record-status surface; detail dialog has no
   media/documents; quality panel default-open pushes grid below fold.

## Cross-review challenges resolved (the Principal's register)

- 1-d challenged 1-c's OWNER-only approve gate → resolved: MANAGER+
  (properties.manage) keeps the app's authority floor unchanged (the catalog
  law "role sets mirror live enforcement"); the DATA boundary
  (recordStatus=APPROVED for floor roles) is the security contract.
- 1-e challenged the always-reject amount rule vs "preserve financial
  semantics" → resolved: the below-finalTotal amount IS the escalation hole
  (the task book's own adversarial list: "Discount escalation"); the
  negotiated-headline semantic is preserved at ≥ finalTotal and via the
  declared-discount path (full approval + audit). Regression payloads aligned
  to the corrected law; zero assertions weakened (the race/rollback/authority
  subjects are intact — the payloads ride the computed finalTotal).
- 1-f challenged wizard scope (media step) → resolved: media upload lives on
  the created unit's detail (EntityDocuments APARTMENT) rather than a wizard
  step requiring a not-yet-existing entityId; the wizard's success step hands
  off to it.

## Deferred (registered, not silently dropped)

Property-sourcing intake (Agent 3's P0 — designed, next round's first item);
field discrepancy intake; requirement wilaya/commune/project criteria;
matching hard-filter test suite; developer dossier fields (RCC/address);
price-event currency column; record-status on Project/Developer; PDF export
(carry-forward, unchanged); the 6-file dialog-debt ratchet (unchanged).
