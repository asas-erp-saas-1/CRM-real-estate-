# ASAS CRM — Phase 10 — Architecture Decisions

**The original close's decisions** are documented across the domain-specific
documents (see `README.md` for the full map). This register records the
decision laws that shaped the Phase 10 architecture, then the nine decisions
of the **continuation round** (2026-11-10) that closed the disclosed gap D1.

## A. The original Phase 10 decision laws (summarized — sources linked)

| # | Decision | Source |
|---|---|---|
| A1 | One authoritative unit-status vocabulary (APARTMENT_STATUSES) — no duplicate status enums; availability is a state machine with append-only events | UNIT_AVAILABILITY_STATE_MACHINE.md |
| A2 | Unit availability ≠ construction/delivery status (UNIT_DELIVERY_STATUSES kept independent) | UNIT_AVAILABILITY_STATE_MACHINE.md |
| A3 | Pricing in cents integers; frozen itemized offer snapshots; revision supersedes, never rewrites | PRICING_AND_DISCOUNT_POLICY.md, COMMERCIAL_OFFER_ARCHITECTURE.md |
| A4 | Discount authority = permission lanes (SELF/MANAGER/OWNER) from the owner-configured policy; every approval audited | PRICING_AND_DISCOUNT_POLICY.md |
| A5 | Deterministic explainable matching: hard requirements eliminate, soft preferences rank; unknown never scores | MATCHING_SCORING_AND_EXPLANATION.md |
| A6 | Five new permissions (inventory.change_availability / change_price / quality.view / import + offer lanes) born with live server gates | SECURITY_AND_INTEGRITY_REPORT.md |
| A7 | Controlled CSV import: preview dry-run → all-or-nothing commit; duplicate = row refused (never overwrite); IMPORT availability events in the creation transaction | INVENTORY_DATA_ARCHITECTURE.md |
| A8 | Additive migration #28 only; census byte-identical before/after | DATABASE_AND_MIGRATION_REPORT.md |

## B. The continuation-round decisions (2026-11-10)

Each decision: why needed, what existed, what changed, validation method.

### AD-C1 — The import wizard mirrors the leads-import interaction model

- **Why**: D1 (the disclosed remaining UI) required a professional file-picker
  experience; the leads wizard is the house's proven 4-step CSV pattern.
- **Existed**: `/api/inventory/import` (preview/commit) + i18n keys + the
  `inventory.import` permission — but zero UI.
- **Changed**: `properties/import-units-dialog.tsx` — same stepper rhythm,
  same visual language, inventory-specific semantics (the 22-field mapping
  vocabulary, the 6 required fields, the allowCreateBuilding decision, the
  no-undo honest disclosure).
- **Validation**: the full browser journey (error path + happy path + i18n ×3).

### AD-C2 — The trigger lives in the InventoryDashboard header, permission-gated

- **Why**: the control-center strip is the MANAGER+ operational surface; every
  role sees the metrics (properties.view parity) but only import holders act.
- **Changed**: the button renders only for `sessionCan(inventory.import)`
  holders — the client mirror of the server gate (the API refuses everyone
  else regardless of what the UI shows).
- **Validation**: live RBAC browser check — SALES_AGENT sees the dashboard,
  zero import triggers (capture 13).

### AD-C3 — No new API surface

- **Why**: the API was already verified (executed round-trip at Phase 10
  close); the gap was UI-only.
- **Changed**: nothing on the contract; the dialog consumes
  `POST /api/inventory/import {action: preview|commit}` as-is.
- **Validation**: the wizard's requests observed in dev.log during the
  browser journey; 963/963 regression with the dialog live.

### AD-C4 — The commit button obeys the all-or-nothing law visibly

- **Why**: any row error refuses the WHOLE import server-side; the UI must
  not offer a dead action.
- **Changed**: the commit is disabled while `errorCount > 0` and its label
  states the valid-row count (post AD-C5 correction).
- **Validation**: the error-CSV journey — the button read "Importer 0/2
  lot(s)" and stayed disabled with the two row errors displayed (capture 04).

### AD-C5 — `validRows` counts ROWS, not error entries (the display-integrity fix)

- **Why**: adversarial browser QA caught the defect — one row with two field
  errors made `validRows = parsed.length − rowErrors.length` undercount
  (labeled "Importer 0 lot(s)" while one row was valid).
- **Changed**: `validRows = parsed.length − distinctErrorRows` (3 lines in the
  route's preview response; happy path byte-identical).
- **Validation**: re-run — the clean CSV preview showed "2 valide(s)" and the
  button "Importer 2 lot(s)".

### AD-C6 — Full i18n parity for the wizard (FR/EN/AR, ~57 new keys)

- **Why**: the house trilingual law (parity test guards the key sets).
- **Validation**: i18n suite 10/10 + AR RTL browser (dir=rtl, Arabic labels)
  + EN labels browser-verified.

### AD-C7 — The dialog-rect scan debt is FIXED, not baselined away

- **Why**: re-running the scan guard (skipped at the Phase 10 close) found the
  Phase 10 commit (fdcb99c) had silently introduced +5 unguarded grid children
  beyond the frozen baselines.
- **Changed**: `min-w-0` added to all 9 offending children (6 in
  opportunity-offers, 3 in apartment-detail-dialog + the Row component root);
  the ratchet baselines lowered truthfully (opportunity-offers removed from
  the registry; apartment-detail-dialog 4→2).
- **Validation**: scan exit 0 — "29 clean, 6 with known baseline debt,
  0 REGRESSION(S)".

### AD-C8 — QA fixtures are removed, the census restored byte-identical

- **Why**: the Phase 10 import-QA cleanup law — synthetic rows never stay as
  demo inventory.
- **Changed**: the 2 QA units + their IMPORT events + the INVENTORY_IMPORTED
  audit row removed after verification.
- **Validation**: census 46 (35/1/1/1/1/7) byte-identical to the documented
  state; `PRAGMA integrity_check` ok; the live dashboard shows 46/35 and the
  quality panel 219/46 again (capture 12).

### AD-C9 — No undo action in the inventory wizard (an honest distinction)

- **Why**: the leads import has an undo endpoint; the inventory import does
  not — its safety net is the all-or-nothing transaction + the audited
  created-ids; withdrawing a unit goes through the unit console.
- **Changed**: nothing API-side; the result step discloses the semantics
  ("every created unit carries an availability event (source Import); no
  existing unit was overwritten").
- **Validation**: the result step content + the DB round-trip (events + audit
  verified before cleanup).

## Decision states

All decisions above: `ANSWERED_BY_CODEBASE_EVIDENCE` (the existing surfaces
inspected) or `DECISION_BY_PRINCIPAL_ARCHITECT` (AD-C1..C9) — no question was
left silently ignored.
