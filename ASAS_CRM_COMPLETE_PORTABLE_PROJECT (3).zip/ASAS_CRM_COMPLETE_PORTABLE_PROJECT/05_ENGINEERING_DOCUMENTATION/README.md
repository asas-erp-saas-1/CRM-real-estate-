# ASAS CRM — Engineering Documentation (v2 professional structure)

**313 documents across 23 numbered sections.** Reorganized 2026-11-17 — every directory is numbered in project-chronological order, indexed by a per-directory `README.md`, and fully recorded in `RENAME_REGISTRY.md`.

## Master index

| # | Section | Purpose | Docs |
|---:|---|---|---:|
| 01 | [00_PROJECT_GOVERNANCE](./00_PROJECT_GOVERNANCE/README.md) | Living engineering governance: master state, roadmap, plan, decision log, risk register, technical debt, test strategy. | 24 |
| 02 | [01_SYSTEM_ARCHITECTURE](./01_SYSTEM_ARCHITECTURE/README.md) | System and solution architecture of the platform. | 2 |
| 03 | [02_DOMAIN_MODEL](./02_DOMAIN_MODEL/README.md) | Real-estate CRM domain model, agency operating model, workflow specification. | 3 |
| 04 | [03_DATABASE_ENGINEERING](./03_DATABASE_ENGINEERING/README.md) | Database architecture, migrations, Supabase setup, data dictionary. | 5 |
| 05 | [04_SECURITY_MODEL](./04_SECURITY_MODEL/README.md) | Authorization model, RLS, security hardening, secrets and git-purge policy. | 5 |
| 06 | [05_UX_UI_DESIGN](./05_UX_UI_DESIGN/README.md) | Design system, user journeys, UX decision log, UI audits. | 15 |
| 07 | [06_FORENSIC_AUDITS](./06_FORENSIC_AUDITS/README.md) | Phase 2 forensic audit evidence — read-only records. | 74 |
| 08 | [07_HANDOFF_AND_OPERATIONS](./07_HANDOFF_AND_OPERATIONS/README.md) | Handoff, operations, environment, QA and research records. | 7 |
| 09 | [08_PHASE_2_ENGINEERING_AUDIT](./08_PHASE_2_ENGINEERING_AUDIT/README.md) | Phase 2 engineering audit record. | 1 |
| 10 | [09_P0_FOUNDATION_HARDENING](./09_P0_FOUNDATION_HARDENING/README.md) | P0 hardening wave: DB reconstruction, SQLite reliability, production security, demo isolation, financial atomicity. | 10 |
| 11 | [10_P1_DOMAIN_SERVICES](./10_P1_DOMAIN_SERVICES/README.md) | P1 wave: domain services, offer options, capture tokens, scoring, security automation. | 9 |
| 12 | [11_P2_PLATFORM_RELIABILITY](./11_P2_PLATFORM_RELIABILITY/README.md) | P2 wave: retention, observability, performance, sessions, rate limiting. | 10 |
| 13 | [12_P4_PRODUCTION_ACCEPTANCE](./12_P4_PRODUCTION_ACCEPTANCE/README.md) | P4 production acceptance reports. | 10 |
| 14 | [13_P4_FORENSIC_AUDITS](./13_P4_FORENSIC_AUDITS/README.md) | P4 forensic audit wave: entry assessment to staging readiness gate. | 10 |
| 15 | [14_PHASE_5_STAGING_OPERATIONS](./14_PHASE_5_STAGING_OPERATIONS/README.md) | Phase 5: staging, backup/recovery, financial integrity, operations runbook. | 13 |
| 16 | [15_PHASE_6_CI_DELIVERY](./15_PHASE_6_CI_DELIVERY/README.md) | Phase 6: CI/CD, E2E acceptance, database persistence, final readiness gate. | 13 |
| 17 | [16_PHASE_7_1_HOSTED_DEPLOYMENT](./16_PHASE_7_1_HOSTED_DEPLOYMENT/README.md) | Phase 7.1: hosted deployment, build artifacts, repair and regression. | 15 |
| 18 | [17_PHASE_7_2_HOSTED_IDENTITY](./17_PHASE_7_2_HOSTED_IDENTITY/README.md) | Phase 7.2: hosted identity, authentication trace, owner account integrity. | 9 |
| 19 | [18_PHASE_8_AUTHENTICATION_ARCHITECTURE](./18_PHASE_8_AUTHENTICATION_ARCHITECTURE/README.md) | Phase 8: authentication architecture, data-access security, field-visit experience. | 11 |
| 20 | [19_PHASE_9_CROSS_ROLE_OPERATIONS](./19_PHASE_9_CROSS_ROLE_OPERATIONS/README.md) | Phase 9: cross-role integration, dashboards, field operations, defect register. | 12 |
| 21 | [20_PHASE_10_COMMERCIAL_ARCHITECTURE](./20_PHASE_10_COMMERCIAL_ARCHITECTURE/README.md) | Phase 10: matching, scoring, inventory, commercial offer architecture. | 22 |
| 22 | [21_PHASE_11_LEAD_ACQUISITION](./21_PHASE_11_LEAD_ACQUISITION/README.md) | Phase 11: lead acquisition, routing, deduplication, deployment repair. | 15 |
| 23 | [22_PHASE_12_FINAL_ACCEPTANCE](./22_PHASE_12_FINAL_ACCEPTANCE/README.md) | Phase 12: final acceptance, accessibility, browser evidence, design system, deployment blocker status. | 18 |

## Recommended reading order (current-state orientation)

1. `00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_STATE.md` — **where we are** (authoritative)
2. `00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_ROADMAP.md` — **what's next**
3. `00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_PLAN.md` — **how we work** (gates, rules)
4. `00_PROJECT_GOVERNANCE/PRODUCTION_READINESS.md` — deployment-readiness matrix
5. `01_SYSTEM_ARCHITECTURE/SYSTEM_ARCHITECTURE.md` — how the system is built
6. `02_DOMAIN_MODEL/DOMAIN_MODEL.md` — entities, lifecycles, state machines
7. `03_DATABASE_ENGINEERING/DATABASE_ARCHITECTURE.md` — schema and migrations
8. `04_SECURITY_MODEL/SECURITY_HARDENING.md` — security state + checklist
9. `22_PHASE_12_FINAL_ACCEPTANCE/` — latest acceptance state

## Path legend (old → new)

Historical references inside documents now resolve through these canonical mappings:

| Old path (repo-era) | New canonical path |
|---|---|
| `docs/architecture/…` | `05_ENGINEERING_DOCUMENTATION/01_SYSTEM_ARCHITECTURE/…` |
| `docs/domain/…` | `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/…` |
| `docs/database/…` | `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/…` |
| `docs/security/…` | `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/…` |
| `docs/ux/…` | `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/…` |
| `docs/audits/…` | `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/…` |
| `docs/engineering/…` | `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/…` |
| `docs/handoff/…` | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/…` |
| `docs/operations/…` | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/…` |
| `docs/qa/…` | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/…` |
| `docs/research/…` | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/…` |
| `docs/p0/…` | `05_ENGINEERING_DOCUMENTATION/09_P0_FOUNDATION_HARDENING/…` |
| `docs/p1/…` | `05_ENGINEERING_DOCUMENTATION/10_P1_DOMAIN_SERVICES/…` |
| `docs/p2/…` | `05_ENGINEERING_DOCUMENTATION/11_P2_PLATFORM_RELIABILITY/…` |
| `docs/p4/…` | `05_ENGINEERING_DOCUMENTATION/12_P4_PRODUCTION_ACCEPTANCE/…` |
| `docs/phase4/…` | `05_ENGINEERING_DOCUMENTATION/13_P4_FORENSIC_AUDITS/…` |
| `docs/phase5/…` | `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/…` |
| `docs/phase6/…` | `05_ENGINEERING_DOCUMENTATION/15_PHASE_6_CI_DELIVERY/…` |
| `docs/phase7/…` | `05_ENGINEERING_DOCUMENTATION/16_PHASE_7_1_HOSTED_DEPLOYMENT/…` |
| `docs/phase7-2/…` | `05_ENGINEERING_DOCUMENTATION/17_PHASE_7_2_HOSTED_IDENTITY/…` |
| `docs/phase8/…` | `05_ENGINEERING_DOCUMENTATION/18_PHASE_8_AUTHENTICATION_ARCHITECTURE/…` |
| `docs/phase9/…` | `05_ENGINEERING_DOCUMENTATION/19_PHASE_9_CROSS_ROLE_OPERATIONS/…` |
| `docs/phase10/…` | `05_ENGINEERING_DOCUMENTATION/20_PHASE_10_COMMERCIAL_ARCHITECTURE/…` |
| `docs/phase11/…` | `05_ENGINEERING_DOCUMENTATION/21_PHASE_11_LEAD_ACQUISITION/…` |
| `docs/phase12/…` | `05_ENGINEERING_DOCUMENTATION/22_PHASE_12_FINAL_ACCEPTANCE/…` |

Full file-level ledger: `RENAME_REGISTRY.md`. Arabic index: `INDEX_AR.md`.

## Conventions

- Section directories: `NN_NAME` (00–22, chronological).
- Every section has a `README.md` with a numbered table (# / file / title / bytes).
- Titles are extracted from each document's first heading — names are never invented.
