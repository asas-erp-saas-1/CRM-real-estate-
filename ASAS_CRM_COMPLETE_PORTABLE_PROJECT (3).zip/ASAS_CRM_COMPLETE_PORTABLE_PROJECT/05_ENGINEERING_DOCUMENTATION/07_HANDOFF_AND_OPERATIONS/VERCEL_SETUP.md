# VERCEL SETUP

> ## ⚠️ HOSTING DECISION (Phase 5 / condition C2 — 2026-11-07)
>
> **The sanctioned Phase 5 hosting model is a single-node Linux VPS with
> Docker and persistent storage — NOT Vercel.** Vercel (or any serverless
> platform) is **incompatible with this codebase as-is**, a fact verified by
> the Phase 4 audit (P4-H02, HIGH) and recorded in
> `05_ENGINEERING_DOCUMENTATION/14_PHASE_5_STAGING_OPERATIONS/ASAS_PHASE5_STAGING_ARCHITECTURE.md`. Vercel remains possible
> ONLY after reworking **all four** verified single-instance mechanisms:
>
> 1. **In-process expiry scheduler** — `src/lib/server/expiry-scheduler.ts:36`
>    starts a `setInterval` sweeper at server boot (via
>    `src/instrumentation.ts`). On Vercel, instances are archived after 48 h
>    idle and scale to zero — expiry sweeps would silently stop (the exact
>    D9 regression this scheduler was built to fix). Rework: external cron
>    (e.g. Vercel Cron or the documented systemd end-state) calling the sweep
>    endpoints.
> 2. **Process-local rate limits** — `src/lib/server/lead-capture.ts`
>    (capture token/IP sliding windows in in-memory `Map`s) and the login
>    lockout window state in `src/lib/server/auth.ts` (failure rows are in
>    the DB, the window state is in-memory). Up to ~30,000 concurrent
>    function instances on Vercel means one budget **per instance** — the
>    limits multiply into nothing. Rework: shared store (Redis-class).
> 3. **In-process observability + cache** — `src/lib/server/obs.ts` (metrics
>    ring buffers) and `src/lib/server/notification-cache.ts` (scoped TTL
>    cache) are process-local by documented design ("single-instance law").
>    On serverless they reset per instance and per cold start. Rework: define
>    which metrics/cache survive (external metrics sink, cache policy).
> 4. **SQLite + local document storage** — the database is a file
>    (`db/custom.db`, Prisma `provider = "sqlite"`) and uploads live on the
>    local filesystem (`src/lib/server/documents.ts`,
>    `DOCS_DIR = <cwd>/db/docs`). Vercel's filesystem is read-only except
>    `/tmp` (≤500 MB, ephemeral) — this alone requires the Supabase
>    PostgreSQL migration AND a storage adapter (§4 below).
>
> Only §4 of this document (document storage) was previously documented as a
>    Vercel caveat — the other three incompatibilities were undocumented until
>    the Phase 4 audit. **Do not choose Vercel expecting configuration to
>    bridge this; it is rework.** The single-node path needs none of it:
> `Dockerfile`, `docker-compose.staging.yml`, `.env.staging.example`, and
> `deploy/README-STAGING.md` are the sanctioned deployment package.
>
> **Everything below this notice is retained unchanged as the "if you must
> go serverless anyway" path** — it is accurate for that reworked future
> (PostgreSQL + Supabase Storage + external cron), and for the Supabase
> database migration that any multi-instance future will eventually need.

This document walks the repository owner through deploying ASAS CRM on
Vercel from the imported GitHub repository: project import, build
configuration, the per-environment variable matrix, and the honest
deployment-time caveats (document storage, AI provider). The database must
already exist — complete `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` first.

## 1. Import the repository

1. Vercel dashboard → **Add New… → Project** → **Import** the private
   GitHub repository created by `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/GITHUB_IMPORT.md`.
2. Framework detection identifies **Next.js** automatically — accept it.
3. Leave the defaults: Build Command `next build`, no output-directory
   override.

**Standalone output note**: `next.config.ts` sets `output: "standalone"`
(this exists for self-hosted `node .next/standalone/server.js` — the
sanctioned single-node Docker deployment and the `bun run start` script).
Vercel handles Next.js builds itself and ignores that flag's self-hosting
semantics; no change is needed for Vercel, and removing it would break the
sanctioned self-hosted deploy path.

CI note: `.github/workflows/ci.yml` runs the static + SQLite database gates
on every PR independently of Vercel — CI activates automatically once the
repo is on GitHub.

## 2. Environment variable matrix

Vercel exposes three environments (Development, Preview, Production).
Configure them in **Project Settings → Environment Variables**, server-only
(no `NEXT_PUBLIC_*` variables exist in this project):

| Variable | Development | Preview | Production |
|---|---|---|---|
| `DATABASE_URL` | your dev Supabase project (Session Pooler URL) | **a SEPARATE preview Supabase project** | the production Supabase project (Session Pooler URL) |
| `ASAS_SESSION_SECRET` | dev value | **distinct value** (any preview URL is public to the team) | **distinct strong value** — `openssl rand -hex 32` |
| `ASAS_DEMO_MODE` | `1` (demo login convenience) or `0` | `0` | **`0` — mandatory** |

The two load-bearing laws:

- **Preview must never touch production data.** Create a separate Supabase
  project for Preview (and another for Development if you keep dev data),
  run the migration chain + seed there, and point Preview's `DATABASE_URL`
  at it. A preview deployment is auto-generated for EVERY pull request and
  its URL is shared with everyone who can see the repo — a preview pointed
  at the production database is a data-integrity incident waiting to happen.
- **`ASAS_DEMO_MODE=0` everywhere except an explicit demo project.** Demo
  mode enables passwordless `{userId}` logins for the seeded roster — a
  documented account-takeover vector when combined with reachable data
  (`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md` §7). If you want a public demo, make
  it a dedicated project with its own throwaway database.

Connection format and pooler guidance:
`05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md` § "`DATABASE_URL` provider matrix".

## 3. Build and deploy

- First deploy: Vercel detects the `bun.lock` file and runs `bun install` +
  `next build`. The repository has **no `postinstall` hook** wiring Prisma
  client generation into the build — be explicit and set the Build Command
  to:

  ```bash
  bunx prisma generate && next build
  ```

  (Without generated client code, data routes fail at runtime with Prisma
  client initialization errors.)
- Verify the deployment: log in with a real (rotated-password) account,
  exercise a list view and a detail view, then check **Logs** for clean
  request traces.

## 4. Document storage caveat (read before promising uploads)

Document binaries are stored on the **local filesystem** (`db/docs/` —
`src/lib/server/documents.ts`, `DOCS_DIR = <cwd>/db/docs`). **Vercel's
filesystem is ephemeral**: uploaded files will disappear when the serverless
instance recycles, and they were never visible across instances to begin
with. The documents module (upload, preview, analysis metadata) still
executes and the database rows persist — only the binary storage is
non-durable.

Production fix (NOT implemented — documented next work item): adopt
**Supabase Storage** — create a bucket, write storage policies, and replace
the filesystem calls in `documents.ts` (`writeDocFile`/`readDocFile`/
`deleteDocFile`) with a storage adapter. The path-containment guard and
filename sanitization already isolate the storage seam, so the adapter is a
contained change. Until then, treat document upload as
demo/evaluation-only on Vercel.

## 5. Deployment troubleshooting

| Symptom | Cause / fix |
|---|---|
| AI copilot / document analysis return `503 AI_PROVIDER_UNAVAILABLE` | **Expected off-platform** — the `.z-ai-config` file does not exist on Vercel. The rest of the CRM is fully functional; the AI features are optional Z.ai-bound enhancements. Nothing to configure. |
| Cannot log in, or only the persona grid appears | `ASAS_DEMO_MODE` unset/`1` on a production URL (set `0`), or the seeded roster was loaded and you are using a stale demo password — rotate passwords per the security checklist. |
| `P1001` / database unreachable | `DATABASE_URL` wrong or pointing at the direct connection from serverless — use the **Session Pooler** URL. |
| `Prepared statement … does not exist` / transaction errors on pooler | Serverless + transaction-mode pooling mismatch — use the **Session Pooler** URL and check the pooler guidance in `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` §7 + §10. |
| Data looks stale/wrong after a PR deploy | Preview and Production share a database — split them per §2 immediately. |
| Uploads vanish after a while | The ephemeral-filesystem caveat (§4) — expected until Supabase Storage adoption. |
| Deploy succeeds but pages 500 on data routes | Prisma client/schema mismatch — the repository must be on the PostgreSQL variant (`prisma/schema.postgres.prisma` copied over `prisma/schema.prisma`) when `DATABASE_URL` is PostgreSQL. |

## 6. After the first deploy

Run the owner validation checklist (`05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/HANDOFF_CHECKLIST.md`
step E): auth, role behavior, AR RTL + FR/EN, core CRM workflows, visit
reports, reservations, privacy spot-checks, logs and error handling.
