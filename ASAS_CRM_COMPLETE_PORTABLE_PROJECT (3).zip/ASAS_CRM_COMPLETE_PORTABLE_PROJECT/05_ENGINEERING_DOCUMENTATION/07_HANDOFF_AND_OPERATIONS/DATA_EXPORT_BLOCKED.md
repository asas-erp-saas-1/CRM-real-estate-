# DATA EXPORT — BLOCKED REPORT

This report states, for the record, that the requested real-business-data
migration could not be performed, why, and what is required to unblock it.
It exists so the handoff makes no implicit claim of data completeness.

## What was requested

Migration of the owner's REAL business data (leads, clients, deals,
visits, reservations, inventory, history) into the delivered ASAS CRM
package — i.e. a production deployment carrying the agency's actual records
rather than the synthetic demo roster.

## Why it is blocked

**No verified authoritative business-data source exists in the packaging
environment.** Verified facts:

- `db/custom.db` — the only candidate database in the tree — is **EMPTY**:
  26 tables, **0 rows** total (verified by table-by-table count). It also
  carries no `_prisma_migrations` bookkeeping, so `prisma migrate status`
  reports the entire 13-migration chain as unapplied — it is not a valid
  migration-chain state and never held the demo roster at any recent point.
- The other database files present are not authoritative sources either:
  `db/test-environment.db` is the seeded SYNTHETIC demo workspace (the
  source from which `supabase/seed.sql` was generated), and
  `db/backups/…` is a snapshot of the empty development database.
- No production backup, export file, or pre-wipe database exists anywhere
  in the environment.

Migrating "real data" from here would mean fabricating it — which the
migration rules explicitly forbid (`05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATA_MIGRATION_GUIDE.md`
§ Rules: never invent values, never fabricate visit reports or attribution).

## The exact required next step

The owner must:

1. **Identify the authoritative business-data source** — e.g. a production
   database backup, the pre-wipe database, or the legacy system of record.
2. **Authorize a read-only export** of that source (snapshot + checksum)
   and make it available to the migration operator.

From there, the 18-step controlled pipeline in
`05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATA_MIGRATION_GUIDE.md` (inventory → counts → field mapping
→ ID preservation → dependency-aware import → validation → reconciliation →
dry-run → test-target execution → post-import checks → rollback strategy)
is the operating procedure.

## What IS provided instead

| Artifact | Content |
|---|---|
| `prisma/seed.ts` / `supabase/seed.sql` | The canonical **synthetic** demo roster — 511 rows, 100% fictional personas (fake `+213` phones, `@asas.dz` users, scrypt hashes of the documented demo password), including a coherent won-deal history |
| `scripts/generate-seed-sql.ts` | The SQL-generation tooling pattern for a controlled import (FK-safe order, original ids, SQL-literal escaping) |
| `scripts/validate-seed.py` | The structural validator (parse + FK closure + emission order + canonical counts) — wired into CI |
| `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATA_MIGRATION_GUIDE.md` | The full 18-step pipeline specification + reconciliation census queries |

Bottom line: the system, its schema, its synthetic demo data and the
migration tooling are delivered and validated to the extent possible; the
real data itself never existed in this environment and must come from the
owner.
