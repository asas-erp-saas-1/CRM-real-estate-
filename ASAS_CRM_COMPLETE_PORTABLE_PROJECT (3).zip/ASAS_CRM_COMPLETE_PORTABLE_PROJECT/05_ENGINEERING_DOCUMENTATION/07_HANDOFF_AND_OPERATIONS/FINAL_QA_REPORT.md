# FINAL QA REPORT — Z.ai Exit Handoff (Phase H)

**Package:** `ASAS_CRM_SOURCE_HANDOFF_2026-10-30.zip` · **Date:** 2026-10-30
**Source:** branch `main`, the handoff-phase commits (H2 `ae9357f` → H7 final).
**Method:** first-hand execution of every gate listed below in the Z.ai
packaging environment, plus a full clean-room validation of the extracted ZIP.
This report follows the PASS / FAIL / BLOCKED / NOT RUN discipline — nothing
is claimed that was not run.

## 1. Test matrix

| Test | Result | Command & evidence |
|---|---|---|
| Lint (development tree) | **PASS** | `bun run lint` → 0 errors (post-H2: tsconfig tightened to `src`+`prisma`; the 6 previously tolerated non-src errors are excluded by scope, src/ itself clean) |
| Typecheck (development tree) | **PASS** | `bun run typecheck` (`tsc --noEmit`) → 0 errors; `typescript.ignoreBuildErrors` removed from next.config.ts after the clean result |
| Production build | **NOT RUN** | `bun run build` is forbidden in the Z.ai sandbox (binding AGENTS.md law). Typecheck + lint are the verified static gates; first build happens in the owner's Vercel import (see 05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md) |
| Unit/integration — Phase C battery | **PASS 80/80** | `DATABASE_URL="file:…/db/test-environment.db" bun tmp-scripts/phase-c-probe.ts` on a freshly migrated+seeded disposable test DB (visit-report contract, all three closure paths, D-021 negative probes, residue byte-exact) |
| DB migrations — SQLite chain | **PASS** | Fresh disposable file: `migrate deploy` → "All migrations have been successfully applied" (13/13, `_prisma_migrations` bookkeeping created); `migrate status` → "Database schema is up to date!" |
| DB seed — canonical roster | **PASS** | `bun run db:seed` (idempotent) → census 8 users / 43 leads / 21 opps / 23 visits / 8 reservations / 161 activities / 46 apartments |
| DB migrations — PostgreSQL chain | **BLOCKED (runtime) / PASS (structural)** | No Docker/PostgreSQL exists in the packaging environment → live execution NOT RUN. Structural validation: `0001` DDL is Prisma-engine-generated (`prisma migrate diff --from-empty --to-schema-datamodel prisma/schema.postgres.prisma`); `0002` CHECK vocabularies mechanically derived from `src/lib/constants.ts`; `0003` RLS generated per-table with the same org predicate; `supabase/seed.sql` validated by `scripts/validate-seed.py` → 0 parse / 0 FK / 0 order violations, canonical counts MATCH. First live PG run happens in the owner's Supabase project (05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md §9 documents this status honestly) |
| RLS / privacy tests | **PASS (app layer) / NOT RUN (DB layer)** | App layer: the Phase C battery's D-021 section — cross-org 404 byte-identical to ghosts, peer out-of-scope 404, unassigned FIELD_REP 404, cross-org list 0 rows. DB layer: RLS policies are structurally shipped but not runtime-tested (no PG — same block as above) |
| E2E — browser (development tree) | **PASS** | agent-browser on the test-env server: login (manager) → dashboard (role panels render) → leads (43 results, table/filters/sort) → visits → pipeline kanban → AR RTL (`dir=rtl`, genuine Arabic labels) → 390px mobile (`scrollWidth 390 == innerWidth 390`, no overflow) → console error count 0. Screenshots: `download/qa-handoff/` (2 captures, dev tree) |
| E2E — browser (clean room) | **PASS** | See §2 — the extracted ZIP boots, serves, authenticates (password login), and returns live data (`/api/leads` total 43) from its own freshly migrated+seeded database |
| Clean-room dependency install | **PASS** | `bun install` in the extracted tree → 527 packages in 4.5s; spot-checked installed versions match `bun.lock` (`@prisma/client` 6.19.2, `prisma` 6.19.2, `next` 16.1.3) |
| Clean-room lint + typecheck | **PASS** | Both gates re-run inside the extracted tree → 0 errors each |
| Secret scan (package) | **PASS** | Full-text scan of the staged package for `sk-…` keys, private-key blocks, session-secret value patterns, real DB URLs: only hits are documented benign placeholders (`.env.example` `replace-me-*`; a `postgres:postgres@127.0.0.1` local-dev example in SUPABASE_SETUP.md). No real credentials in the package |
| Sensitive-data scan (package) | **PASS** | No `.env`, no `db/` files, no `tool-results/`, no local databases in the ZIP (staged from `git archive` with the QA-artifact exclusions) |
| ZIP integrity | **PASS** | `unzip -t` → OK; 730 files, 8,863,942 bytes uncompressed; SHA-256 in the companion `.sha256` file |
| Git-history safety | **REPORTED — not shippable** | The repository history contains an old real session-secret value and a pre-purge demo database (documented in `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md`). The handoff is therefore a clean source snapshot WITHOUT `.git`; preserving history requires the owner-gated purge first |

## 2. Clean-room validation record (mandate §16)

Executed against the extracted ZIP in `/home/z/asas-cleanroom/asas-crm`
(separate directory, outside the repository):

1. Extraction + inventory — 730 files, required-files check 24/24 present.
2. `bun install` — lockfile respected (see matrix).
3. `cp .env.example .env` + secret generated — sufficient; no `.env.local`
   or undocumented file needed.
4. `bunx prisma generate` — client generated from the extracted schema.
5. Migrations + seed → canonical census (see matrix) with 13/13 migration
   bookkeeping.
6. Lint + typecheck → 0 / 0.
7. Boot check: the extracted tree's dev server (single-instance port-3000
   swap window) → `/` 200, password login as `sarah@asas.dz` → MANAGER
   session, `/api/leads` → 43 records with real names. Demo-mode surfaces
   correctly OFF with `ASAS_DEMO_MODE=0` from the template (an implicit
   verification of the demo gate itself).
8. No hidden Z.ai dependencies: `src/` scan found zero hardcoded
   `localhost:PORT` fetches, zero `XTransformPort`, zero sandbox-absolute
   paths; the only platform-bound surface is the optional AI provider
   (documented: 503 `AI_PROVIDER_UNAVAILABLE` without `.z-ai-config`).

**Environment-var precedence incident (disclosed honestly).** The first
clean-room attempt relied on the clean room's own `.env` for
`DATABASE_URL` — but the packaging sandbox exports `DATABASE_URL` globally,
and real env vars override `.env` files, so `bun run db:seed` seeded the
roster into the **protected `db/custom.db`** (the migration deploy itself
refused harmlessly: schema-not-empty P3005, no writes). Detected within
minutes by checksum comparison; the protected DB was restored **byte-exact**
from the pre-phase GATE-1 snapshot (`sha256 6f4b10a8…` before and after;
0 users; 524,288 bytes) and re-verified twice since (including after the
final server restore). The clean-room was then re-run with per-command
`DATABASE_URL` overrides (the §4.2 discipline) — all green. Root cause +
the precedence warning are documented in
`05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md` ("Precedence note") so the same
class of accident cannot silently recur.

## 3. Protected-database attestation

- `db/custom.db` (protected): restored byte-exact to its pre-phase state
  (current 26-table schema, 0 rows, no migration bookkeeping) — verified by
  SHA-256 against the GATE-1 snapshot after the incident, after the
  clean-room re-run, and after the final project-server restore.
- `db/test-environment.db` (disposable, git-ignored): recreated this phase
  via the owner-approved Option B/Path D recipe (fresh file → `migrate
  deploy` ×13 → `db:seed`), used for the battery + browser QA, retained for
  future authorized verification windows.
- No hosted/remote database was ever contacted. No deployment, no remote
  push, no scheduler change (see §5).

## 4. Standing boundary checks (re-verified this phase)

- CLOSED_LOST exemption: untouched (battery B-section re-run green).
- Visit-report contract on every `CLOSED_WON` writer: re-verified by the
  80/80 battery (three writers, in-transaction gating).
- D-021 / roles / org scope: battery C-section green.
- No financial model, no lifecycle semantics, no RBAC change: the H2 code
  diff touches only the two AI routes (availability guard), configs, and
  packaging files — zero business-logic edits.

## 5. Not performed (by authorization boundary)

- No remote GitHub push; no hosted Supabase connection or migration; no
  Vercel deployment; no environment-variable changes on any hosted platform;
  no Git history rewrite (the purge remains owner-gated); no real-customer
  data export (BLOCKED — see `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/DATA_EXPORT_BLOCKED.md`).

## 6. Verdict

The package is **verified as a self-contained, installable, bootable,
migratable, seedable ASAS CRM source tree** (SQLite local path fully proven;
PostgreSQL path structurally validated, runtime live-execution honestly
deferred to the owner's Supabase project). Remaining known limitations are
recorded in `HANDOFF_MANIFEST.json` → `knownBlockers` and
`05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/HANDOFF_CHECKLIST.md`.
