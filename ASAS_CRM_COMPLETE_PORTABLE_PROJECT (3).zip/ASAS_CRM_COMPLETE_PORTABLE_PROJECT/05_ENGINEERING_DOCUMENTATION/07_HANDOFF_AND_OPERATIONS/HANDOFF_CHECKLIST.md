# HANDOFF CHECKLIST — OWNER VALIDATION

This checklist is the owner's actionable post-extraction sequence: take the
delivered source ZIP through GitHub, Supabase and Vercel, then validate the
system runs independently of the environment that produced it. Every item
states the exact verification action. Work top to bottom; do not skip the
step-E validation even if everything "obviously works".

## Step A — Download, verify, extract

- [ ] Download the source ZIP and its checksum.
- [ ] `shasum -a 256 <zip>` — matches the delivered checksum.
- [ ] `unzip <zip> -d asas-crm && cd asas-crm`
- [ ] Tree inspection: `src/`, `prisma/`, `supabase/`, `docs/`, `scripts/`,
      `.github/workflows/ci.yml`, `package.json`, `bun.lock` present; NO
      `.env`, NO `db/*.db`, NO `.git`, NO `node_modules`.
      → full walkthrough: `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/GITHUB_IMPORT.md` §1–3

## Step B — GitHub import

- [ ] Empty PRIVATE repository created (no license — owner decision pending).
- [ ] `git init && git add . && git commit -m "chore: import ASAS CRM source snapshot (handoff)" && git branch -M main && git remote add origin … && git push -u origin main`
- [ ] `git status` clean; `.env`/`db/` never tracked (`.gitignore` covers them).
- [ ] CI green on `main` (first run: install + generate + lint + typecheck +
      SQLite migrate + seed + `validate-seed.py`).
- [ ] `main` protected; PR flow enabled per `CONTRIBUTING.md`.
      → `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/GITHUB_IMPORT.md` §4–9

## Step C — Supabase prepare

- [ ] Supabase project created; database password stored.
- [ ] `supabase/migrations/0001 → 0002 → 0003` applied in order (CLI
      `supabase db push`, or SQL-editor paste in order).
- [ ] Schema verified: 26 public tables · RLS enabled on all of them ·
      `Reservation_apartmentId_active_key` index exists · `User_role_domain`
      CHECK exists (queries in the setup doc §4).
- [ ] Seed loaded (`supabase/seed.sql` or the Prisma path) and the census
      matches (511 rows; e.g. `User`=8, `Lead`=43, `Activity`=161).
- [ ] Prisma provider switched: `cp prisma/schema.postgres.prisma prisma/schema.prisma`.
- [ ] `DATABASE_URL` set to the Session Pooler URL; `bunx prisma generate` run.
      → `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md`

## Step D — Vercel connect

- [ ] Project imported from GitHub; framework detected as Next.js.
- [ ] Build command set to `bunx prisma generate && next build`.
- [ ] Environment matrix per environment: `DATABASE_URL` (Preview points at a
      SEPARATE Supabase project — never production data),
      `ASAS_SESSION_SECRET` distinct per environment,
      `ASAS_DEMO_MODE=0` everywhere except an explicit demo project.
- [ ] First deploy succeeds; deployment logs clean.
      → `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md`

## Step E — Validate the independent system

Authentication & access:

- [ ] Login works with a seeded account (e.g. `sarah@asas.dz` / `asas1234`);
      logout clears the session.
- [ ] Wrong password → identical 401 for existing and non-existing email.
- [ ] Password change invalidates the old session (re-login required).
- [ ] `ASAS_DEMO_MODE=0` verified: persona quick-login grid hidden,
      `/api/auth/session` returns `demoUsers: []`.

Database connectivity & roles:

- [ ] Dashboard, leads, pipeline, visits, tasks, properties, analytics,
      audit, settings all load data (DB connectivity per role).
- [ ] SALES_AGENT (amine@asas.dz) sees own + unassigned leads only; another
      agent's lead id → 404 (not 403, not data).
- [ ] FIELD_REP (mounia@asas.dz) sees project-scoped visits/leads.
- [ ] MANAGER/OWNER see org-wide data + management surfaces (analytics,
      audit, targets); ADMIN user management reachable.
- [ ] `/api/analytics` as SALES_AGENT → 403.

Languages & RTL:

- [ ] FR default; switch to EN and AR; AR renders full RTL (sidebar right,
      logical properties, no clipped labels); persisted across reload.

Core CRM workflows:

- [ ] Create a lead → appears in the leads list with correct org scoping.
- [ ] Schedule a visit → notification/dashboard surfaces update.
- [ ] Visit report flow: complete a visit with interest level + notes.
- [ ] Pipeline: move an opportunity through stages; CLOSED_WON without a
      qualifying visit report is blocked (422); with one, it succeeds.
- [ ] Reservations: reserve an apartment; the same apartment cannot be
      re-reserved while ACTIVE (409); cancel/expired frees it.
- [ ] Search palette (⌘K) returns scoped results only.
- [ ] CSV export download opens cleanly in a spreadsheet.

Privacy:

- [ ] Two agent accounts: agent A's data never appears in agent B's lists,
      search, dashboard or counts.
- [ ] Direct API access to a foreign record id returns 404 byte-identical
      to a random id (curl or browser devtools with the session cookie).

Logs & error handling:

- [ ] Vercel function logs show clean request traces (no Prisma client
      errors, no RLS denials on app queries).
- [ ] A deliberate bad route (e.g. `/api/leads/nonexistent-id`) returns the
      standard error envelope, not a stack trace.
- [ ] Error boundary renders (trilingual) if a view throws — check console
      for the one-way digest reference.

## Known limitations (accepted at handoff — not silently broken)

| Limitation | Status | Reference |
|---|---|---|
| Document binaries stored on the local filesystem (`db/docs/`) | **Does not survive on Vercel** — Supabase Storage adoption (bucket + policies + `documents.ts` storage adapter) is the documented next work item, NOT implemented | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md` §4 |
| AI features (lead copilot, document analysis) | Off-platform they return `503 AI_PROVIDER_UNAVAILABLE` (expected — `.z-ai-config` file-based config, no env vars); the rest of the CRM is fully functional | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md` § "AI provider" |
| PostgreSQL migration chain runtime validation | **Structurally validated only** (engine-generated DDL + FK-closure/order/counts validator on the seed); no live PostgreSQL was available in the packaging environment — step C IS the runtime validation | `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` §9 |
| Real business-data migration | **BLOCKED** — no authoritative source in the packaging environment; pipeline + tooling provided | `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/DATA_EXPORT_BLOCKED.md` · `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/DATA_MIGRATION_GUIDE.md` |
| Demo password `asas1234` | Intentionally public in the synthetic seed (D-007) — rotate before real users arrive | `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md` §7–8 |
| Original git history | Contains historical secrets — the clean-source import path avoids it; preserving history requires the owner-gated purge first | `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` |
