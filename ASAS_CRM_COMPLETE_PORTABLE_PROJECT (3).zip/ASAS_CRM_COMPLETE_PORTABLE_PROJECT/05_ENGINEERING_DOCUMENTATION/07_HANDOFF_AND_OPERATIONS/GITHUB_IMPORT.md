# GITHUB IMPORT

This document walks the repository owner from the delivered source ZIP to a
private GitHub repository with CI active. The handoff package is a **clean
source snapshot without `.git`** — importing it starts a fresh history, which
sidesteps the secrets-in-history problem described in §5.

## 1. Verify the ZIP checksum

```bash
shasum -a 256 <the-delivered-zip-file>.zip
```

Compare the output against the checksum delivered alongside the package (in
the delivery message or its checksum file). Do not proceed on a mismatch —
re-download instead.

## 2. Extract

```bash
unzip <the-delivered-zip-file>.zip -d asas-crm
cd asas-crm
```

## 3. Inspect the tree

Sanity-check the snapshot before it becomes a repository:

```bash
ls                     # expect: src/ prisma/ supabase/ docs/ scripts/ package.json bun.lock …
ls src/lib/server      # 21 domain modules
ls supabase/migrations # 20261030000001_init.sql 20261030000002_business_constraints.sql 20261030000003_rls_policies.sql
ls .github/workflows   # ci.yml
```

Confirm the tree contains **no** `.env`, no `db/*.db` files, no
`node_modules/` and no `.git/` — the source ZIP ships without any of them
(the `.gitignore` rules below would exclude them from tracking anyway, but
the snapshot should be clean on disk too).

## 4. Create the GitHub repository

Create an **empty private repository** on GitHub (no README, no license, no
`.gitignore` — the snapshot provides all three):

- Why **private**: the code is proprietary — the owner has selected **no
  license** ("all rights reserved"); do not add a license file without an
  explicit owner decision.
- Why safe: the source tree itself contains no secrets (`.env.example` is
  the redacted placeholder; the seed data is synthetic). The historical
  secrets live only in the OLD development history, which this import does
  not carry.
- Secret-scanning caveat: GitHub secret scanning/push protection runs
  automatically on **public** repos only; a private repo on a Free personal
  account gets neither (verified in
  `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/PLATFORM_HANDOFF_RESEARCH.md` §5). The compensating
  controls are the `.gitignore` (§6) and the rotation policy in
  `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/SECURITY_AND_RLS.md` §8. Under a Team/Enterprise
  organization, enable Secret Protection + push protection before the first
  push.

## 5. Import (git CLI)

From inside the extracted directory:

```bash
git init
git add .
git commit -m "chore: import ASAS CRM source snapshot (handoff)"
git branch -M main
git remote add origin git@github.com:<owner>/<repo>.git
git push -u origin main
```

Alternative: **GitHub Desktop** → Add Existing Repository → select the
folder (it offers to initialize) → Publish → keep **Private** checked.

## 6. What the `.gitignore` already covers

The shipped `.gitignore` excludes (verified content):

- `.env*` — except the tracked `.env.example` template
- `/db/` — the SQLite databases, document binaries, backups (PII + scrypt hashes)
- `node_modules`, `/.next/`, `/out/`, `/build`, `.vercel`
- `/tool-results/`, `.zscripts/*.pid`, `.z-ai-config`, logs (`dev.log`, `*.log`)

So the first `git add .` will not pick up any local databases or secrets you
create while testing. Verify with `git status` before committing if unsure.

## 7. Git history note (read before importing the OLD history)

The **original development history is NOT part of this package** — by
design. That history still contains secret-bearing objects (a committed
session-secret value and an old demo database with scrypt hashes —
`05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md`). Rules:

- The clean-snapshot import above is the recommended path: fresh history,
  zero inherited secrets.
- If preserving the original commit history matters to the owner, the
  owner-gated purge documented in `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` must
  be executed on the old repository FIRST, and the purged history validated
  (`git log --all -- .env db/custom.db | wc -l` → 0) BEFORE the first push
  to any remote. Pushing first and force-purging afterwards is NOT
  sufficient (server-side reflogs retain the objects).

## 8. Branch strategy

Recommended (matches `CONTRIBUTING.md`):

- `main` protected: require pull requests, require status checks
  (the `ci` workflow), no direct pushes.
- Feature work on short-lived branches (`app/…`, `db/…`, `docs/…`),
  conventional commits, one logical change per commit.
- Schema-change discipline on PRs: `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md`
  (edit `prisma/schema.prisma` → SQLite migration → regenerate the Postgres
  variant → extend the supabase chain with a NEW migration).

## 9. CI activates automatically

`.github/workflows/ci.yml` runs on every PR and push to `main`:

- **static-gates** — `bun install --frozen-lockfile`, `bunx prisma generate`,
  `bun run lint`, `bun run typecheck`.
- **database-gates** — applies the SQLite migration chain to a fresh
  `db/ci-check.db`, seeds the synthetic roster, and runs
  `python3 scripts/validate-seed.py supabase/seed.sql`.

Expect the first run to go green on `main` — if it does not, capture the
log; do not weaken the gates to make it pass (the workflow header states
what it honestly covers and what it does not claim).

## 10. Next steps

- `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` — the production database
- `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/VERCEL_SETUP.md` — application hosting
- `05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/HANDOFF_CHECKLIST.md` — the full owner validation sequence
