# RESEARCH LOG

Standards-informed reasoning used for Phase 2 decisions. Sources consulted (primary/official preferred). Recorded per the mandate §10: question → finding → source → how it shaped the decision.

## R-1 — Stateless signed-cookie sessions
**Question**: How to fix a raw-userId cookie without adopting a session table?
**Finding**: HMAC-signed value tokens are the standard stateless pattern; OWASP Session Management Cheat Sheet recommends server-side state for revocation needs — our revocation requirement is only password-change, solvable by embedding issued-at and comparing a `passwordChangedAt` stamp. Constant-time comparison (timingSafeEqual) for MAC verification is standard practice (node:crypto docs; OWASP Cryptographic Storage).
**Decision impact**: D-006 (cookie format `${userId}.${issuedAt}.${hmac}` + passwordChangedAt check).
**Source**: OWASP Session Management Cheat Sheet; Node.js crypto API docs (timingSafeEqual, createHmac).

## R-2 — SameSite=Lax and CSRF
**Question**: Is sameSite=lax + JSON-only parsing adequate CSRF protection for cookie-auth API routes?
**Finding**: Lax withholds cookies on cross-site POST (only top-level GET navigations carry it); combined with the app rejecting non-JSON bodies (415/400 INVALID_JSON verified live), classic HTML-form CSRF is blocked. Residual: top-level GET navigations are side-effect-free in this API (all mutations are POST/PATCH/DELETE). Origin/Referer checking remains the recommended defense-in-depth for production.
**Decision impact**: accepted posture + Ph3 Origin-check hardening item.
**Source**: MDN Set-Cookie SameSize documentation; OWASP CSRF Prevention Cheat Sheet.

## R-3 — SQLite + Prisma: partial unique indexes
**Question**: Can we keep a uniqueness constraint that only applies to ACTIVE reservations?
**Finding**: Prisma does not support partial indexes in the schema DSL (long-standing feature gap, documented in Prisma issues); SQLite itself supports partial indexes but only via raw DDL outside Prisma management. Correct long-term home: PostgreSQL partial unique index.
**Decision impact**: D-008 (drop the unique index, enforce in the interactive transaction — SQLite single-writer serializes the check-then-create; partial index documented as the PostgreSQL target).
**Source**: Prisma docs (indexes/constraints) + Prisma GitHub issue tracker on partial index support; SQLite partial index docs.

## R-4 — scrypt parameters
**Question**: Are N=16384, r=8, p=1 acceptable?
**Finding**: These are the OWASP-recommended interactive-login scrypt parameters (≥16384/8/1); per-user random salt + timing-safe compare both present. No change needed.
**Source**: OWASP Password Storage Cheat Sheet.

## R-5 — Prisma migrations on an existing push-managed SQLite DB
**Question**: How to adopt migrations without rebuilding the database?
**Finding**: Official flow: `prisma migrate diff --from-empty --to-schema-datamodel` to generate a baseline SQL, commit as `migrations/0_init/migration.sql`, then `prisma migrate resolve --applied 0_init` marks the live DB as already at that state. Subsequent changes flow through `migrate dev`. `db push --accept-data-loss` remains the documented dev-sandbox escape hatch but must never be the production path.
**Decision impact**: Roadmap Ph1-2 exact steps.
**Source**: Prisma official docs — "Baselining an existing production database".

## R-6 — Reservation expiry patterns in CRMs
**Question**: Sweeper vs cron?
**Finding**: Common practice: scheduled job for exactness; lazy/on-read transition acceptable for single-instance systems where a poll surface exists (our notification bell). Chosen lazy pattern must be idempotent + audited — implemented accordingly.
**Decision impact**: D-009.
**Source**: general engineering practice (time-based state transitions); no single canonical source — judgment call, documented in DECISION_LOG.
