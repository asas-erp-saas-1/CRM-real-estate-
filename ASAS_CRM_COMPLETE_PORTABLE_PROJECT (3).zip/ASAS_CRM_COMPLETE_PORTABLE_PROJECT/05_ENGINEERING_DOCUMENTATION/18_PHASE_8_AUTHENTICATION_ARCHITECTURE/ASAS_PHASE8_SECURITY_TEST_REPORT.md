# ASAS CRM — Phase 8 — Security Test Report

**Suites**: `tests/security/permission-matrix.test.ts` (135 rows — the historical matrix) ·
`tests/security/phase8-identity.test.ts` (17 rows — NEW, the Phase 8 boundary suite) · the
full security family re-run. **Full sequential regression: 903/903 (54 files).**

---

## The new adversarial suite — `phase8-identity.test.ts`

| Group | Rows | What is pinned |
|---|---|---|
| P8/A — OWNER persona | 3 | 11 management surfaces 200 (finance/analytics/audit/metrics/targets/settings/users/export/dashboard/journey-stats); invite-mode creation (NO temp password, one-time token, hash-at-rest DB truth, raw token nowhere at rest); roster pendingActivation + no credential columns over the wire |
| P8/B — ROLE_CEILING | 4 | ADMIN×(mint OWNER / PATCH OWNER role / deactivate OWNER / temp-reset OWNER / code-reset OWNER) → 403 ROLE_CEILING + zero minted tokens; MANAGER+AGENT×(create user / reset) → 403 FORBIDDEN_ROLE; OWNER self-guards (SELF_ROLE_CHANGE / SELF_DEACTIVATION) |
| P8/C — token laws | 7 | anonymous invite redemption (password armed, hash ≠ password, token consumed, passwordChangedAt set, login 200 with the chosen password); replay dead; garbage → generic envelope; DB-crafted expired token dead; **cross-org binding** (org-B token × org-A account → 400); weak/demo 422s consume nothing (valid redemption still succeeds); inactive-account re-arm blocked |
| P8/D — scope echoes | 2 | dashboard `scope:"own"` for the agent vs `"org"` for MANAGER/OWNER; below-MANAGER roster carries no emails |
| P8/E — spray bound | 1 | the next failed redemption after 5 token-class failures → 429 TOKEN_RATE_LIMITED |

**Bugs the suite found & fixed (before any user could hit them):**
1. The redeem schema's `min(12)` shadowed `BOOTSTRAP_DEMO_PASSWORD` (the demo password is 8
   chars — the refusal was dead code). Fix: policy checks in the route body, demo-first
   precedence.
2. Redemption rate limiting initially counted successful redemptions against the budget.
   Fix: failures-only accounting (token-class 400s) — the login limiter's law.

## Historical matrix — re-verified unchanged (135/135)

Anon 401s (~28 surfaces incl. forged cookie) · RBAC floors 403s · bidirectional org
isolation 404-ghosts (leads/opps/offers/reservations/tasks/visits/sav/documents/matching) ·
D-021 record visibility (agent×peer, fieldrep×agent-lead) · assignment authority ·
unauthorized state transitions · positive controls · ghost-identity envelope equality.

## Live E2E probes (curl, this session)

invite→activate→login 200 · reset-code mint (30-min window) → redeem → **old password dead** ·
replay → 400 · garbage token → 400 generic · ADMIN×OWNER code-reset → 403.

## Cross-boundary coverage vs the mandate §13

Direct API requests ✓ · IDOR ✓ · mass assignment ✓ (public-capture whitelist + ownerId
guards) · cross-organization ✓ · forged role payloads ✓ · session revocation ✓
(session-governance) · disabled accounts ✓ (deactivated login + token re-arm) ·
search/autocomplete leakage ✓ (scope-composed search audit) · counts/dashboard aggregation ✓
(scope echoes) · export restrictions ✓ · notification leakage ✓ (role-aware cache keys +
scope composition — audited, unchanged).

## Residual / disclosed

- Visit photo upload deferred (documents model has no VISIT entity) — follow-up scope.
- Redeem spray limiter is in-process (single-instance deployment; PostgreSQL port note in
  code). Re-run caveat for the test file documented in its header.

## Regression discipline

The catalog migration was verified at every step: permission-matrix 135/135 immediately
after the 25-route conversion; full suite 903/903 after all changes (sequential law,
fresh server); typecheck clean; `bun run lint` 0 errors (42 pre-existing warnings).
