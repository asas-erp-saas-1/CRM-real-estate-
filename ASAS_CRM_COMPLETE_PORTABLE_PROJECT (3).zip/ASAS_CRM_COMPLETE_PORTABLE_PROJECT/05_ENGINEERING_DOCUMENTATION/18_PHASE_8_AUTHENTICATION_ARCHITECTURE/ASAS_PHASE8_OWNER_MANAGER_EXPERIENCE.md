# ASAS CRM — Phase 8 — Owner & Manager Experience

## OWNER (nadia@asas.dz — rank 100)

**Workspace**: full organizational control. Nav (browser-verified): Tableau de bord · Parcours
client · Prospects · Pipeline · Visites · Tâches · Inventaire · Finance · SAV · Analytique ·
Audit · Paramètres — all 12 surfaces, org-scoped data (`scope:"org"` asserted).

**Dashboard** (role-aware service, D-021): organization-wide KPIs, funnel, source performance,
commissions, pending incentives, unstaffed visits, pending duplicates, overdue operational
alerts.

**Employees & permissions** (Settings → Équipe, browser-verified end-to-end):
- Invite a new employee (name/email/role + provisioning choice): **invitation code
  (recommended)** — the employee sets their own password — or classic temp password.
  The one-time code dialog (browser-verified): full token with copy button, 72h expiry,
  "shown ONCE / transmit out-of-band" warnings, redemption path instructions.
- **Pending activation** state (amber badge) for invited-but-not-yet-activated accounts, with
  a re-issue-code action (reset-password in code mode).
- Secure account recovery: mint a 30-min one-time reset code for any employee (ADMIN ceiling:
  codes for OWNER accounts can only be minted by an OWNER).
- Role assignment with **impact confirmation** (AlertDialog: dynamic role label, immediate
  permission consequences, audited) before the PATCH fires.
- Activate/deactivate; last-active-OWNER protection; self-management guards; full audit trail
  (role changes carry before/after in the same transaction as the write).
- Session tools: change own password; revoke sessions.

**Owner-only powers (enforced + tested)**: minting OWNER accounts, managing OWNER accounts,
minting OWNER recovery codes, granting OWNER rank — 403 ROLE_CEILING for everyone else,
including ADMIN.

**Cannot**: read passwords/hashes (asserted — the roster never carries credential columns),
session secrets, or authentication tokens.

## MANAGER (sarah@asas.dz — rank 70)

**Workspace**: team performance and operational control. Nav (browser-verified): 11 views —
everything except the FIELD_REP-exclusive Terrain workspace. Org-scoped operational data.

**Dashboard** (verified): team sales performance, active leads, lead distribution, opportunity
pipeline, stage conversion, upcoming/completed visits, visit no-shows, representative
activity, follow-up delays, reservations awaiting action, unstaffed visits, operational
bottlenecks — the management KPI set, `scope:"org"`.

**Operational authority**: assign/reassign leads, opportunities, visits; supervise pipeline
stage corrections; manage operational property data and project assignments; reservations
oversight (validate/reject/cancel); payments recording; finance overview; analytics; audit
view; settings management; lead import/dedupe/export; capture-token management.

**Cannot (server-enforced, tested)**: create/manage users or mint invites/codes (403
FORBIDDEN_ROLE — verified for MANAGER and SALES_AGENT); grant roles; access
metrics/targets-management/pipeline-stage management (ADMIN+ floors); touch OWNER accounts;
see anything below their org (cross-org → 404-ghost).

## Verification evidence

- Browser: OWNER full nav + finance + dark mode + EN + session-refresh persistence
  (`evidence/p8-owner-*.png`); MANAGER nav + AR RTL dashboard
  (`evidence/p8-manager-dashboard-ar-rtl.png`).
- API: phase8-identity P8/A (11 OWNER surfaces 200), P8/B (ceiling + self guards + below-rank
  403s), P8/D (scope echoes).
- Team-management UI E2E by the A3 agent: invite → code dialog → pending badge →
  role-confirmation → audit trail (USER_CREATED → USER_INVITED → USER_UPDATED), Arabic RTL.
