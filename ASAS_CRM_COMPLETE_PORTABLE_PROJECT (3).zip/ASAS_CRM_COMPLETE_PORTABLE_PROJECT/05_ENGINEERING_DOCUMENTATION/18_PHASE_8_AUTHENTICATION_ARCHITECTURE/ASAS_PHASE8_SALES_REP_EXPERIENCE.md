# ASAS CRM — Phase 8 — Sales Representative Experience

**Persona**: amine@asas.dz (SALES_AGENT — the mandate's SALES_REP, mapped to the existing
identifier). **World**: personally assigned commercial work + the shared intake pool + the
approved catalogue. (browser-verified 2026-11-09)

## The workspace (browser-verified)

Nav (EN session, exact labels): **My day** · Customer Journey · **My leads** · **My
pipeline** · **My visits** · **My tasks** (overdue badge) · Inventory · After-sales —
the A4 role-aware framing (`labelKeyByRole` in the view registry). In FR: Ma journée · Mes
prospects · Mon pipeline · Mes visites · Mes tâches. The data was already own-scoped
server-side; the labels now say so.

**NO management surfaces**: Finance / Analytics / Audit / Settings never render in the nav
(permission-driven), and a deep link to `#/finance` renders the honest restricted-access card
(screenshot `evidence/p8-agent-finance-lock.png`) while the API answers 403 FORBIDDEN_ROLE.

## My day (the dashboard's own scope — `scope:"own"` asserted live)

Role-aware snapshot (D-021 service): my leads (new / awaiting contact), my active
opportunities, follow-ups due today, overdue follow-ups, my scheduled visits, my conversion
metrics, my incentives (SALES_AGENT-only surface), my latest activities. Management surfaces
(funnel, source performance, commissions, unstaffed visits) are **null** for this role — not
hidden, not computed.

## The daily loop

- **Contact lead / add follow-up / record touches** — lead drawer (existing, scoped).
- **Create leads** (✅), update permitted fields, record preferences, convert qualified leads
  per lifecycle rules, request reassignment, record lost reasons.
- **My pipeline** — own+pool opportunities through the oppScope; stage moves on own deals per
  the transition law (protected corrections are MANAGER+).
- **Schedule visits** on own work (assertLeadVisible guards the referenced lead).
- **Submit reservation requests** (request path); approval is MANAGER+ (tested).
- **Property matching** — the approved catalogue: projects, units, areas, availability,
  public prices, photos (internal acquisition costs / margins are not in the agent's world).
- **My tasks** with overdue badge; **After-sales** intake in scope.

## Boundaries (server-enforced, tested)

- Peer agents' private leads/tasks/opps → 404 (byte-identical to nonexistent ids).
- Cannot reassign (ownerId moves = MANAGER — 403 verified), cannot alter financial
  verification, cannot access management APIs (finance/analytics/audit/users/export — 403s
  pinned), roster shows names+roles only (emails stripped — F-14, asserted live).

## Verification evidence

Browser (Principal): nav labels EN; mobile 390px no-overflow
(`evidence/p8-agent-mobile-390.png`); finance deep-link lock screen; logout→login flow.
API: permission-matrix (agent 403/404 rows), phase8-identity P8/D (scope:"own", roster
minimization).
