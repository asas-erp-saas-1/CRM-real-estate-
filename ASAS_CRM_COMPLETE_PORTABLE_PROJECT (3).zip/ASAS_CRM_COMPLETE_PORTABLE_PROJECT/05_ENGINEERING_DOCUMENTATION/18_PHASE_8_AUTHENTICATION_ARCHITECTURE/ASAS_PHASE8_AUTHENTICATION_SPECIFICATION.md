# ASAS CRM — Phase 8 — Authentication Specification

**Scope**: login, session, password policy, recovery, invitation, activation, auditing.
**Law**: the existing custom auth stack was inspected first and **preserved** (mandate §3.A);
Phase 8 added the invitation/recovery lifecycle on top of it.

---

## 1. Login

| Property | Implementation | Verified by |
|---|---|---|
| Email normalization | trim + lowercase at every credential path | login route, users POST |
| Password verification | scrypt (N=16384, r=8, p=1, 32-byte), constant-time | `src/lib/server/auth.ts` (unchanged) |
| Show/hide password | eye toggle, aria-label, both login + activation forms | browser (A6) |
| Submit/loading state | disabled-while-pending, duplicate-submission prevented | browser |
| Lockout | 5 failures / 15 min **DB-backed** (survives restarts) → 429 ACCOUNT_LOCKED | session-governance suite |
| Generic failure | 401 INVALID_CREDENTIALS (timing-safe dummy-hash arm) | permission-matrix |
| Distinct error states | invalid · locked · network · server(5xx) · expired-session (i18n ×3) | browser (A6) |
| No account enumeration | identical envelope for unknown email / wrong password | live E2E |
| Languages | FR / EN / AR (ع) switcher on the overlay; RTL flips the split panel | browser |
| Autocomplete / a11y | `autocomplete="email"/current-password"`, aria labels, Enter submit, 44px targets | browser (A6) |

## 2. Session (unchanged, re-verified)

HMAC-SHA256-signed cookie `asas_user = userId.issuedAtMs.hmac`:
- **HttpOnly**; **Secure** in production; **SameSite=Lax**; 7-day absolute expiry
  (`SESSION_MAX_AGE_MS`) enforced at verification, cookie maxAge in sync.
- Tamper-proof (constant-time hex compare); forged/raw cookies → null → 401 NO_SESSION.
- Invalidated by: `passwordChangedAt` (reset ⇒ every prior session dies), revoke-all
  watermark, exact-pair logout revocation (replayed logged-out cookies fail).
- Production boot gate: `NODE_ENV=production` without `ASAS_SESSION_SECRET` or with
  `ASAS_DEMO_MODE=1` crashes at startup (P0-3 law — demo quick-login is dev-sandbox only).
- The client **never** supplies role/permissions — identity always resolves server-side from
  the verified session (`getCurrentUser`).
- CSRF: same-origin enforcement on every authed route + pre-auth mutations (login, redeem).

## 3. Password policy

- Hashing: Node scrypt (no external dependency), salted, NFKC-normalized, serialized
  `scrypt:salt:hash`. **No migration** of existing hashes (mandate: "Do not blindly migrate").
- Activation/reset redemption floor: **12 characters** (the bootstrap law), demo password
  refused with a distinct code (`BOOTSTRAP_DEMO_PASSWORD` — precedence over the length floor;
  a schema-level floor would shadow it: found by the adversarial suite and fixed).
- Passwords/hashes are never logged, never audited, never echoed.

## 4. Recovery (owner-controlled — email is NOT configured)

Honest posture: the login screen's forgot-password panel states that recovery is
owner-controlled; no email is ever pretended to be sent.

1. OWNER/ADMIN → `POST /api/users/:id/reset-password { mode:"code" }` → one-time RESET code
   (30 min, sha256 at rest) returned **once** for out-of-band transmission (WhatsApp/in
   person). ADMIN cannot mint codes for OWNER accounts (ROLE_CEILING — tested).
2. Employee → login screen → "I have an activation or recovery code" → redeems with a
   self-chosen password (`POST /api/auth/redeem-token`).
3. Redemption (single transaction): consume token → write password → bump
   `passwordChangedAt` (all prior sessions die) → audit `USER_PASSWORD_RESET_REDEEMED`.
4. The classic temp-password mode remains available (`mode:"temp"`, unchanged contract).

## 5. First-login invitation

`POST /api/users { mode:"invite" }` (OWNER/ADMIN): account created **without a password** +
single-use INVITE token (72h, org+user bound, hashed at rest) returned once. The employee
activates via the same redemption surface (audit: USER_CREATED → USER_INVITED →
USER_ACTIVATED). Invalidated after use; expired tokens answer the generic INVALID_TOKEN
envelope. The management table shows **pending activation** until redeemed.

## 6. Redemption endpoint security (`POST /api/auth/redeem-token`, public)

- 400 INVALID_TOKEN — one generic envelope for unknown / used / expired / cross-org /
  inactive-account (no existence oracle — verified by the adversarial suite).
- 422 BOOTSTRAP_WEAK_PASSWORD / BOOTSTRAP_DEMO_PASSWORD — policy rejections.
- 429 TOKEN_RATE_LIMITED — per-IP spray bound (5 token-class failures / 5 min; successes and
  422s never count — the login limiter's law).
- No session established on redemption (no session-fixation surface) — the holder then signs
  in through the normal login path.
- Same-origin enforced (pre-auth CSRF family).

## 7. Authentication event auditing

LOGIN · LOGIN failures/lockout · LOGOUT · PASSWORD_CHANGED · SESSIONS_REVOKED ·
BOOTSTRAP_OWNER · USER_CREATED · USER_INVITED · USER_ACTIVATED · USER_RESET_REQUESTED ·
USER_PASSWORD_RESET(_REDEEMED) · USER_UPDATED (role changes with before/after). Every
mutation+audit pair commits as ONE transaction (the F-06 house law). No credential material
ever enters the audit trail.

## 8. Verification index

- `tests/security/session-governance.test.ts` — cookie semantics, revocation, lockout.
- `tests/security/phase8-identity.test.ts` (17 tests) — token lifecycle end-to-end incl.
  replay, expiry, cross-org, inactive-account, rate limit, ROLE_CEILING on code-mode reset.
- Live E2E (curl): invite→activate→login ✓ · reset→redeem→old-password-dead ✓ · replay ✓.
- Browser (A6 agent + Principal): full activation success path in the UI with a real
  ADMIN-minted code, prefilled email, auto-return to login.
