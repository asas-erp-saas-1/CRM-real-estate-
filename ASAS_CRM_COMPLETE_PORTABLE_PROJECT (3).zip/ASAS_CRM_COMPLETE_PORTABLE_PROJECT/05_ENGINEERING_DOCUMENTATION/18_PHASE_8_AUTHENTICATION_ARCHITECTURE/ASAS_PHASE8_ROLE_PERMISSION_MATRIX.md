# ASAS CRM — Phase 8 — Role Permission Matrix

**Authority**: `src/lib/permissions.ts` — the typed catalog (40 permissions × 5 roles).
**Law**: every permission's role set exactly mirrors the live server gates (zero-regression
migration, 135/135 permission-matrix rows green throughout). "Denied" = **backend-enforced**,
never merely hidden UI.

Legend: ✅ granted · ❌ denied (server) · ~ granted with record-scope narrowing (visibility.ts)

| Module / Capability (permission) | OWNER | ADMIN | MANAGER | SALES_AGENT | FIELD_REP |
|---|---|---|---|---|---|
| dashboard.view | ✅ | ✅ | ✅ org | ~ own (myDay) | ~ visits world |
| journey.view | ✅ | ✅ | ✅ | ~ | ~ |
| search.use | ✅ | ✅ | ✅ | ~ scoped | ~ scoped |
| notifications.view | ✅ | ✅ | ✅ | ~ | ~ |
| leads.view | ✅ | ✅ | ✅ | ~ own+pool | ~ visit projection only |
| leads.create | ✅ | ✅ | ✅ | ✅ | ✅ |
| leads.assign | ✅ | ✅ | ✅ | ❌ | ❌ |
| leads.import / leads.dedupe / leads.export | ✅ | ✅ | ✅ | ❌ | ❌ |
| clients.view | ✅ | ✅ | ✅ | ~ linked | ~ minimum visit data |
| opportunities.view | ✅ | ✅ | ✅ | ~ own+pool | ~ visit projection (D-025) |
| opportunities.create | ✅ | ✅ | ✅ | ✅ | ❌ |
| opportunities.assign / stage_move | ✅ | ✅ | ✅ | ❌ | ❌ |
| pipeline.view | ✅ | ✅ | ✅ | ✅ (nav "Mon pipeline") | ❌ nav (API: projection) |
| pipeline.stages.manage | ✅ | ✅ | ❌ | ❌ | ❌ |
| properties.view | ✅ | ✅ | ✅ | ✅ catalogue | ✅ visit data |
| properties.manage | ✅ | ✅ | ✅ | ❌ | ❌ |
| visits.view / visits.create | ✅ | ✅ | ✅ | ~ own | ~ assigned projects |
| visits.assign | ✅ | ✅ | ✅ | ❌ | ❌ |
| reservations.view / create | ✅ | ✅ | ✅ | ~ request path | ❌ |
| reservations.approve | ✅ | ✅ | ✅ | ❌ | ❌ |
| payments.view | ✅ | ✅ | ✅ | ~ installments scope | ❌ |
| payments.record | ✅ | ✅ | ✅ | ❌ | ❌ |
| finance.overview | ✅ | ✅ | ✅ | ❌ | ❌ |
| analytics.view | ✅ | ✅ | ✅ | ❌ | ❌ |
| export.run | ✅ | ✅ | ✅ | ❌ | ❌ |
| users.view | ✅ | ✅ | ✅ (emails) | ~ names+roles only (no emails — F-14) | ~ |
| users.manage / users.invite | ✅ | ✅* | ❌ | ❌ | ❌ |
| audit.view | ✅ | ✅ | ✅ | ❌ | ❌ |
| metrics.view | ✅ | ✅ | ❌ | ❌ | ❌ |
| targets.view | ✅ | ✅ | ✅ | ~ self | ~ self |
| targets.manage | ✅ | ✅ | ❌ | ❌ | ❌ |
| settings.view | ✅ | ✅ | ✅ | ✅ | ✅ |
| settings.manage | ✅ | ✅ | ✅ | ❌ | ❌ |
| capture_tokens.manage | ✅ | ✅ | ✅ | ❌ | ❌ |
| sessions.revoke_others | ✅ | ✅ | ❌ | ❌ | ❌ |
| sav.view | ✅ | ✅ | ✅ | ~ | ~ |
| sav.assign | ✅ | ✅ | ✅ | ❌ | ❌ |
| documents.view | ✅ | ✅ | ✅ | ~ deal-related | ~ visit-related |

\* **ADMIN's ceiling (the Owner-only powers, enforced below the catalog in the users
routes)**: an ADMIN cannot create an OWNER account, change an OWNER's role, deactivate an
OWNER, or mint recovery codes for an OWNER — 403 ROLE_CEILING (all four verified by
P8/B). Additional guards: SELF_ROLE_CHANGE / SELF_DEACTIVATION (400), LAST_OWNER (last
active OWNER cannot be demoted/deactivated).

## Navigation consequence (permission-driven — `canSeeView`)

| View | OWNER | ADMIN | MANAGER | SALES_AGENT | FIELD_REP |
|---|---|---|---|---|---|
| Terrain (field) | ❌ | ❌ | ❌ | ❌ | ✅ **first item** (showFor) |
| Dashboard | Tableau de bord | ✅ | ✅ | **Ma journée** | ✅ |
| Leads / Pipeline | ✅ | ✅ | ✅ | **Mes prospects / Mon pipeline** | ❌ hidden (API serves the visit projection) |
| Visits / Tasks | ✅ | ✅ | ✅ | **Mes visites / Mes tâches** | ✅ |
| Properties / SAV | ✅ | ✅ | ✅ | ✅ | ✅ |
| Finance / Analytics / Audit | ✅ | ✅ | ✅ | ❌ (+ 403 lock screen on deep links) | ❌ |
| Settings | ✅ | ✅ | ✅ | ❌ | ❌ |

Deep links below the permission floor render the honest restricted-access card (verified:
`#/finance` as SALES_AGENT → "Restricted access — Access reserved for managers and
administrators", screenshot `evidence/p8-agent-finance-lock.png`).

## Enforcement inventory

- 25 API routes migrated to `requirePermission(<catalog name>)` (users.manage,
  finance.overview, analytics.view, audit.view, settings.manage, payments.record,
  properties.manage, leads.import/dedupe/export, capture_tokens.manage, metrics.view,
  targets.manage, pipeline.stages.manage, export.run, users.view…).
- The remaining routes compose `requireUser()` + record scopes (the ABAC layer) — their
  floors are per-record, not per-rank, and stay in the visibility law tables.
- Test truth: `tests/security/permission-matrix.test.ts` (135 rows: anon 401s, RBAC floors,
  org isolation 404-ghosts, record visibility, assignment, transitions, ghost-identity
  equality) + `tests/security/phase8-identity.test.ts` (17 rows: OWNER persona, ROLE_CEILING,
  token capability laws, scope echoes, roster minimization).
