# ASAS CRM — Phase 8 — Identity Architecture

**Phase**: 8 — IDENTITY, AUTHENTICATION, AUTHORIZATION & ROLE-BASED CRM EXPERIENCE
**Status**: IMPLEMENTED & VERIFIED (see ASAS_PHASE8_FINAL_ACCEPTANCE_GATE.md)
**Commits**: `f465244` (backend core) · `5ecb748` (role-experience UI) · `ccdb944` (adversarial suite + A4) · final docs commit
**Regression**: 903/903 tests (54 files, sequential law) · typecheck clean · lint 0 errors

---

## 1. The architecture in one page

Phase 8 did **not** introduce a new identity system — it **consolidated and completed** the
existing one. The discovery audit (Step 1–2) found a mature codebase with four scattered
authorization mechanisms; Phase 8 unified them behind a single typed authority and added the
missing account-lifecycle capabilities (invitation + owner-controlled recovery).

```
                       ┌─────────────────────────────────────────────┐
                       │  src/lib/permissions.ts  (ISOMORPHIC)      │
                       │  40-permission catalog · 5 role templates   │
                       │  can(role, permission) · module-load guards │
                       └──────────────┬──────────────────────────────┘
                                      │ mirrors exactly
  ┌───────────────────────────────────┼─────────────────────────────────────┐
  │ SERVER (action gate)              │ CLIENT (presentation only)          │
  │ src/lib/server/authorize.ts       │ view-registry permission/showFor/   │
  │ requirePermission(p) → 401/403    │ labelKeyByRole → canSeeView() nav   │
  │ + visibility.ts (record scopes)   │ + 403 lock screens on deep links    │
  │ + lifecycle law tables            │ (UI hiding is never authorization)  │
  └───────────────────────────────────┼─────────────────────────────────────┘
                                      │
          ┌───────────────────────────┴────────────────────────────┐
          │ ACCOUNT LIFECYCLE (new in Phase 8 — A1)               │
          │ AuthToken model (migration #26): INVITE | RESET        │
          │ 256-bit CSPRNG · sha256 at rest · single-use · org+    │
          │ user bound · expiring (72h / 30min) · tx-audited       │
          │ POST /api/auth/redeem-token (public, rate-limited)     │
          └────────────────────────────────────────────────────────┘
```

## 2. Role model — mandate → existing identifiers (nothing renamed)

| Mandate role | Code (unchanged) | Rank | Seeded persona | World |
|---|---|---|---|---|
| OWNER | `OWNER` | 100 | nadia@asas.dz | Full organizational control |
| (deputy tier, kept) | `ADMIN` | 90 | karim@asas.dz | Owner's deputy — **cannot mint/manage OWNER** (ROLE_CEILING) |
| MANAGER | `MANAGER` | 70 | sarah@asas.dz | Org-wide operational oversight |
| SALES_REP | `SALES_AGENT` | 40 | amine@asas.dz | Assigned records + shared pool + inventory |
| FIELD_VISIT_REP | `FIELD_REP` | 40 | mounia@asas.dz | Project-assigned visit execution |

The mandate's instruction — *"Inspect the actual current role model and map existing enum
values… without blindly replacing existing identifiers"* — is honored verbatim: the four
business roles map onto the existing enum; the ADMIN deputy tier is preserved (existing data,
existing tests) with its Owner-only ceiling intact and documented.

## 3. The four authorization layers (who may do what, to which records)

1. **Permission catalog** (`src/lib/permissions.ts`) — the typed, single source of truth for
   *actions*: 40 identifiers, each mapped to the roles whose live gates already enforced it.
   **Behavioral law**: every permission's role set exactly mirrors the pre-Phase-8 gates —
   adopting the catalog changed zero runtime behavior (135/135 permission-matrix rows stayed
   green through the migration). Module-load integrity guards reject unknown references and
   tier-monotonicity breaks at import time.
2. **Action gate** (`src/lib/server/authorize.ts`) — `authorize(user, permission)` (pure),
   `requirePermission(permission)` / `requireAnyPermission(...)` (enforce: 401 NO_SESSION →
   403 FORBIDDEN_ROLE, byte-compatible with the historic rank floors so pinned tests stay
   green). 25 API routes migrated from rank floors to named permissions.
3. **Record scopes** (`src/lib/server/visibility.ts`, unchanged — already the D-021 law) —
   *which records*: MANAGER+ org-wide; SALES_AGENT own+pool; FIELD_REP project-derived.
   Detail routes resolve foreign records as 404-ghosts (byte-identical to nonexistent ids).
4. **Lifecycle law tables** (visit-gate, offer-lifecycle, reservation-lifecycle, unchanged) —
   business-state restrictions (e.g. CLOSED_WON requires a valid completed-visit report).

Client-side `can()`/`canSeeView()` only drive **presentation** (nav filtering, labels, lock
screens); every API enforces the same catalog server-side.

## 4. Account lifecycle (new)

- **Invitation**: OWNER/ADMIN creates a member in `mode:"invite"` → account with **no
  password** + single-use INVITE token (72h) returned **once** → the employee redeems it at
  the login screen (`/api/auth/redeem-token`) to set **their own** password. The shared
  temp-password handoff retires mode-by-mode (kept as the classic option).
- **Recovery**: email delivery is **not configured** (honest posture — the login UI says so);
  recovery is owner-controlled: OWNER/ADMIN mints a 30-min single-use RESET code → the
  employee redeems it to choose a new password. Redemption bumps `passwordChangedAt` → every
  prior session dies (F-05 law: reset ⇒ revocation).
- **Security properties** (all enforced in `src/lib/server/auth-tokens.ts`): sha256-hashed at
  rest (a DB read yields no usable token); single-use consumed in the same transaction as the
  password write; org+user bound (cross-tenant replay impossible); active-account required;
  generic INVALID_TOKEN envelope for every failure (no existence oracle); per-IP spray limiter
  (5 token-class failures / 5 min, failures-only accounting); audit family USER_INVITED →
  USER_ACTIVATED / USER_RESET_REQUESTED → USER_PASSWORD_RESET_REDEEMED inside the same tx.

## 5. Schema change (migration #26 — additive only)

`AuthToken { id, orgId→Organization, userId→User, kind: "INVITE"|"RESET", tokenHash @unique,
expiresAt, usedAt?, createdBy?, createdAt }` + two indexes + back-relations. Applied under the
mandate's DB rules: backup first (`db/backups/backup-20261108T231203Z`, census users=8
leads=43), migration SQL reviewed, tested on an isolated copy, then applied — data intact
(users=8, leads=43, health `migrations: 26`). No existing table was touched.

## 6. What deliberately did NOT change

- The HMAC-signed cookie session stack (scrypt, 7-day absolute expiry, passwordChangedAt
  invalidation, revoke-all watermark, exact-pair logout revocation, DB-backed login lockout,
  same-origin CSRF) — inspected, verified secure, preserved per the mandate ("Do not replace
  it merely because another authentication library is available").
- The visibility scopes and lifecycle tables (already the record-boundary primitives).
- All existing role identifiers, seeded personas, and business data.
