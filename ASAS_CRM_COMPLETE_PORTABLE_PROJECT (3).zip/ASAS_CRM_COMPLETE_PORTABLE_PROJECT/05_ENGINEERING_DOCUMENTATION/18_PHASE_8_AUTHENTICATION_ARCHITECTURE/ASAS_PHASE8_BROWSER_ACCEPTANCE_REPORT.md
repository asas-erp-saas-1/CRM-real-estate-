# ASAS CRM — Phase 8 — Browser Acceptance Report

**Method**: agent-browser (headless Chromium) against the real Z.ai Preview dev server at
`http://127.0.0.1:3000/`, real logins with the seeded personas, live DOM assertions +
screenshots (in `evidence/`). Executed by the three implementation agents and re-verified
independently by the Principal.

---

## Matrix — executed & observed

| # | Check | Role / Lang / Layout | Result | Evidence |
|---|---|---|---|---|
| 1 | Login form renders, personas grid, bootstrap hidden (users exist) | anon / FR | ✅ | live DOM |
| 2 | Credential login (all four roles used across the session) | OWNER/MANAGER/SALES/FIELD | ✅ | live DOM |
| 3 | Forgot-password panel (aria-expanded, owner-controlled explanation, CTA) | anon / FR | ✅ | A6 /tmp/a6-*.png |
| 4 | Activation mode: token/password/confirm + eye toggles + back link | anon / FR | ✅ | A6 |
| 5 | Garbage token → INVALID_TOKEN alert (server 400 confirmed in log) | anon / FR | ✅ | A6 |
| 6 | Full activation success path with a real ADMIN-minted RESET code (success alert, identity echo, prefilled email, auto-return, login 200) | anon | ✅ | A6 |
| 7 | Arabic login + activation: dir=rtl, labels/placeholders/icons flipped | anon / AR | ✅ | A6 |
| 8 | 390px no horizontal overflow (login, login+panel, activation) | mobile | ✅ | A6 (scrollWidth=390) |
| 9 | OWNER nav: all 12 views + overdue badge | OWNER / FR | ✅ | Principal |
| 10 | OWNER finance view loads; dark mode toggle (`dark` class); EN labels | OWNER / EN / dark | ✅ | p8-owner-finance-dark.png, p8-owner-dashboard-en-dark.png |
| 11 | Session survives browser refresh (still signed in, language persisted) | OWNER | ✅ | Principal (reload → Dashboard) |
| 12 | Logout → login overlay returns → login as another persona | OWNER→SALES | ✅ | Principal |
| 13 | SALES nav: **My day / My leads / My pipeline / My visits / My tasks** + Inventory + SAV; no management items | SALES / EN | ✅ | Principal |
| 14 | Permission-denied state: `#/finance` deep link → "Restricted access" card (API 403) | SALES | ✅ | p8-agent-finance-lock.png |
| 15 | Mobile 390px main app: no overflow | SALES | ✅ | p8-agent-mobile-390.png |
| 16 | MANAGER nav: 11 views (no Terrain); AR dashboard RTL (dir=rtl, sw=1280) | MANAGER / AR | ✅ | p8-manager-dashboard-ar-rtl.png |
| 17 | FIELD nav: **Terrain first**, agenda+inventory world only (no leads/pipeline/finance/analytics/audit/settings) | FIELD / FR | ✅ | Principal |
| 18 | Terrain workspace: today's visit renders (unit chips A-02/A-11), sections Aujourd'hui/À venir | FIELD | ✅ | Principal |
| 19 | Execution sheet: checklist (3 items), outcome actions (no-show/reschedule/cancel), report contract (interestLevel select + notes + follow-up), submit | FIELD | ✅ | Principal |
| 20 | Terrain 390px: no overflow, FR **and** AR (dir=rtl, natural Arabic) | FIELD / mobile | ✅ | p8-a5-mobile-fr/ar.png |
| 21 | Team management (OWNER): provisioning toggle (invite recommended), one-time code dialog (copy, 72h expiry, warnings), pending-activation badge, re-issue action, role-change impact confirmation | OWNER | ✅ | A3 .tmp-scripts shots (re-verified) |
| 22 | Team management Arabic RTL rendering | OWNER / AR | ✅ | A3 |
| 23 | Console errors / page errors | all sessions | ✅ none | `agent-browser errors` sweeps |

## Notes

- Render-verification only for visit-status mutations in the browser (demo data preserved);
  the mutation contracts are pinned by the automated suites (visit-gate, permission-matrix
  transition rows, live curl E2E).
- Dev-server restarts occurred during parallel agent work (sandbox process reaping — the
  documented `(setsid nohup bun run dev &)` pattern restores it); all evidence above was
  captured against a healthy server (health 200).
- House law forbids `bun run build`; the production-artifact pipeline is the one verified in
  Phase 7.1/7.2 — Phase 8 changes are typecheck/lint/test-green and additive.
