# ASAS CRM — Phase 8 — Field Visit Representative Experience

**Persona**: mounia@asas.dz (FIELD_REP — the mandate's FIELD_VISIT_REP). **World**: assigned
visits on assigned projects + the minimum client/property information needed to execute them.
(browser-verified 2026-11-09, screenshots in `evidence/`)

## The dedicated mobile-first workspace — "Terrain" (new view, nav-first)

`showFor: ["FIELD_REP"]` makes **Terrain the first nav item** for field reps and invisible
for everyone else (their visit life is the visits view). A dedicated mobile-first agenda
(`src/components/crm/field/`):

- **Aujourd'hui** — today's visits sorted by time, count header, friendly empty state.
- **À venir** — upcoming visits.
- Collapsed history (completed / no-show / cancelled / rescheduled).
- **Visit card**: time · status chip (existing tone system) · property/project + unit chips
  · **location with a Google-Maps navigation link** · client name · sales rep · instructions
  (notes) · context-aware primary action — Confirm (SCHEDULED) or Start report (CONFIRMED).
- **Execution sheet** (the heart — Dialog, mobile-first): visit summary + navigation link ·
  structured local checklist (arrived / property presented / client questions) · outcome
  actions — no-show, request reschedule, cancel with reason · **the report contract**
  (interestLevel enum + reportNotes ≥20 chars + follow-up flag) submitting the exact PATCH
  payloads the proven dialogs use · server 422 guard errors surfaced · loading states ·
  query invalidation on success.
- Mobile 390px: zero horizontal overflow (verified FR **and** AR-RTL, screenshots
  `p8-a5-mobile-fr.png` / `p8-a5-mobile-ar.png` — `dir=rtl`, natural Arabic labels).
- The full workflow is status-driven per `VISIT_TRANSITIONS` — no arbitrary status changes
  (server-validated), timestamps and the authenticated actor are server-stamped.

## The nav law (browser-verified)

FIELD_REP sees: **Terrain** · Tableau de bord · Parcours client · Visites · Tâches ·
Inventaire · SAV — and **nothing else**: no Prospects, no Pipeline, no Finance, no
Analytique, no Audit, no Paramètres (permission + hideFor composition through `canSeeView`).

## Boundaries (server-enforced; the workspace is read-scoped by construction)

- Data arrives through `GET /api/visits` — auto-scoped to the FIELD_REP's assigned projects
  (D-021 `visitScope`); visits without a project are invisible.
- Clients: minimum visit data only (name, meeting time/location, instructions) — never the
  full CRM history, payments, balances, or other clients.
- Properties: name, location, unit, photos, main specs, public price — never acquisition
  costs, margins, negotiation floors, promoter contracts (not in any FIELD_REP response).
- Cannot: access the general lead list (nav-hidden; API serves only the visit projection),
  browse the pipeline, reassign clients, confirm reservations, touch payments, export, change
  roles (all 403/404 per the matrix).
- After submitting a report, the result flows to the sales rep's and manager's workflows
  (existing Activity/visit-report contract); the rep may flag follow-up but never takes
  ownership of the opportunity.

## Deferred (disclosed)

Visit **photo/document upload** (mandate §4 action #13): the documents module does not model
VISIT-attached entities; adding it requires a scoped schema+security follow-up. The other 13
execution actions are implemented.

## Verification evidence

Browser (Principal): field view renders today's seeded visit (unit chips A-02/A-11);
execution sheet opens with checklist + all outcome actions; 390px no-overflow FR+AR;
nav law confirmed. The PATCH contract itself is pinned by the existing visit suites
(visit-gate + permission-matrix transition rows).
