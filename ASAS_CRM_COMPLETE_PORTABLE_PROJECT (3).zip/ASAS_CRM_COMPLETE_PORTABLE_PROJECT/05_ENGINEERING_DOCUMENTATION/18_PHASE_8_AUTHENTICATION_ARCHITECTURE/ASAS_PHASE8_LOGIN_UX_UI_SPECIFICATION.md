# ASAS CRM — Phase 8 — Login UX/UI Specification

**Surface**: `src/components/crm/login-overlay.tsx` — the single-route app's auth gate,
rendered whenever the verified session is absent. (browser-verified 2026-11-09)

## Layout

- **Desktop**: split composition — deep-charcoal brand panel (the official stroke-A mark,
  aubergine/amber atmosphere, feature bullets) + the form card; RTL flips the split
  automatically.
- **Mobile**: single column, correct hierarchy, zero horizontal overflow at 390px (verified
  in login, login+panel, and activation modes), keyboard-safe spacing, comfortable 44px+
  targets.
- Visual language: the existing ASAS system (tokens, typography, shadcn/ui primitives,
  framer-motion transitions) — no unrelated visual language introduced.

## Modes

1. **login** (default): email + password (autofilled hint after activation), show/hide eye
   toggles, inline validation, submit with loading + duplicate-submission prevention,
   forgot-password **collapsible** (aria-expanded) → owner-controlled recovery explanation +
   CTA to activation mode, demo-persona grid (dev sandbox only — demo mode gate), first-run
   OWNER bootstrap flow (production posture, untouched).
2. **activate** (new): invitation/recovery code + new password + confirmation, back link,
   success state (identity echo + prefilled login email + ~4s auto-return).

## Error states — distinct treatments, i18n ×3 (fr/en/ar)

| State | Trigger | Presentation |
|---|---|---|
| Invalid credentials | 401 INVALID_CREDENTIALS | inline alert (generic — no account-existence disclosure) |
| Too many attempts | 429 ACCOUNT_LOCKED | inline alert + toast with remaining minutes |
| Invalid/expired code | 400 INVALID_TOKEN / 422 VALIDATION_ERROR | inline alert in activation mode |
| Code rate-limited | 429 TOKEN_RATE_LIMITED | inline alert |
| Weak password | 422 BOOTSTRAP_WEAK_PASSWORD | inline + field hint |
| Public demo password | 422 BOOTSTRAP_DEMO_PASSWORD | distinct refusal message |
| Network failure | fetch throw / NETWORK_ERROR | inline alert |
| Server error | 5xx / INTERNAL | inline alert |
| Expired session | 401 on session refresh | session-expired message (re-auth path) |

## Interaction quality (verified)

Inline validation (mismatch, min length — submit disabled) · keyboard navigation · visible
focus indicators · accessible labels (aria-invalid/aria-describedby, sr-only fallbacks) ·
correct autocomplete attributes (`email`, `current-password`, `new-password`, `off` for
tokens) · Enter submission · loading state · no duplicate requests · clear success/error
feedback · language switcher FR/EN/**ع** with full RTL flip of labels, placeholders, icons
and the split panel.

## i18n

Every string through `t()` — the activation/recovery/error keys were added to all three
dictionaries (the module-load parity guard enforces fr/en/ar equality; Arabic is natural,
not transliterated).

## Verification evidence

Browser (A6 agent, live DOM + screenshots /tmp/a6-01…12 + Principal re-checks): forgot panel
expand/collapse; activation form render; garbage-token submission → the French INVALID_TOKEN
alert (server log `400 INVALID_TOKEN`); ع → dir=rtl with correct label placement; 390px
no-overflow in all three modes; **the full success path with a real ADMIN-minted RESET code**
(success alert, identity echo, back button, auto-return, prefilled email, login with the new
password → 200).
