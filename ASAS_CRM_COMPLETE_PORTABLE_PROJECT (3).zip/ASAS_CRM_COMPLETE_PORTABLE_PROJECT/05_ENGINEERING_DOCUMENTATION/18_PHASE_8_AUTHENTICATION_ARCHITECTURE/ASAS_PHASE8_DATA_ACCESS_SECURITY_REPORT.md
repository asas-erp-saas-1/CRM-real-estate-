# ASAS CRM — Phase 8 — Data Access Security Report

**Question answered**: can any role reach records it should not — by URL, record id, query
parameter, request body, search, counts, exports, or notifications?

**Answer: NO — verified zero unauthorized data access across 152 black-box rows + live probes.**

---

## 1. The data-boundary stack (unchanged in Phase 8, re-verified)

`src/lib/server/visibility.ts` remains THE record-scope primitive (D-021 law):

| Caller | World |
|---|---|
| MANAGER+ | ORG — every record in the org |
| SALES_AGENT | OWN+POOL — owned leads/opps/tasks + unassigned intake + shared inventory |
| FIELD_REP | PROJECT-SCOPED — everything resolves through `project.assignments.some(userId)` |

Every data route composes its scope into the base query; **detail/mutation routes use scoped
findFirst so a foreign record resolves 404 — byte-identical to a nonexistent id** (no
existence leak). UI hiding is never authorization.

## 2. Boundary classes verified (evidence)

| Attack class | Result | Where |
|---|---|---|
| Anon → any protected API | 401 NO_SESSION (~28 surfaces) | permission-matrix |
| Forged cookie (raw userId / tampered) | treated as no session | session-governance |
| Below-rank → management APIs | 403 FORBIDDEN_ROLE (finance×5, analytics×2, audit, export×2, users×3, targets, settings PUT, apartments PATCH, assignments, duplicates×3, import×2…) | permission-matrix |
| Cross-org by id (IDOR) | 404-ghost, bidirectional, 12+ surfaces (leads/opps/offers/reservations/tasks/visits/sav/documents/matching/users) | permission-matrix |
| Peer-agent private records | agent×peer lead/task/opp → 404; list-level DB-truth assertions | permission-matrix |
| FIELD_REP × agent-lead | 404 (project-derived scope) | permission-matrix `vis/leads.detail.fieldrep×agent-lead` |
| Forged role/assignment payloads | ownerId/agentId moves = MANAGER (leads routes, bulk assign 403); mass-assignment fence on public capture (422) | permission-matrix + public-capture |
| Cross-org token replay | org-B token × org-A account → generic 400 INVALID_TOKEN | phase8-identity |
| Inactive-account re-arm | valid RESET code × deactivated user → 400 | phase8-identity |
| Token replay after use | 400 INVALID_TOKEN | phase8-identity + live curl |
| Search leakage | scope-composed AND predicates (leads/opps/contacts/sav; installments surface only MANAGER+) | search route audit + suite |
| Counts / dashboard aggregation leakage | dashboard computes inside scopes; echoes `scope:"own"` for agents (asserted) | phase8-identity P8/D |
| Export restrictions | MANAGER+ (EXPORT_FORBIDDEN below), org-scoped, ≤5000 rows, CSV defanged, audited | export routes + matrix |
| Roster PII | emails stripped below MANAGER (F-14) — asserted live | phase8-identity P8/D |
| Credential exposure | passwordHash never crosses the wire (asserted on the roster) ; no hashes in audit | phase8-identity |

## 3. Phase 8's own additions — security properties

- **Token capabilities**: 256-bit CSPRNG, sha256 at rest (DB read ⇒ no usable token),
  single-use consumed in the same tx as the password write, org+user bound, expiry enforced
  server-side (INVITE 72h / RESET 30min), active-account required, generic failure envelope
  (no oracle), spray-bounded per IP.
- **New permission surfaces**: users.manage/invite keep the ADMIN ceiling (an ADMIN operating
  user management simply cannot target OWNER rank — 4 attack vectors tested).
- **Nav is presentation**: `canSeeView` filters the sidebar; the same catalog permission is
  enforced by the API; deep links below the floor get the 403 lock screen.

## 4. Findings & fixes this phase

1. **Dead-code finding (fixed)**: the redeem schema's `min(12)` shadowed the
   `BOOTSTRAP_DEMO_PASSWORD` refusal (the demo password is 8 chars) — policy checks moved to
   the route body with demo-first precedence. Found by the adversarial suite before any user
   could hit it.
2. **Rate-limiter accounting (fixed)**: redemption rate limiting initially counted successful
   redemptions against the caller's budget; now failures-only (token-class 400s), matching
   the login limiter's law.
3. No authorization regressions: the catalog migration kept all 135 pinned matrix rows green.

## 5. Residual risks (disclosed, accepted)

- The redeem spray limiter is in-process (single-instance SQLite deployment — documented for
  the PostgreSQL port: move to the shared store).
- Visit **photo/document upload** in the field sheet is deferred: the documents module does
  not model VISIT-attached entities (documentScope covers LEAD/OPPORTUNITY/RESERVATION/
  APARTMENT/PROJECT); adding it is a scoped follow-up with its own security review.
- Roster `pendingActivation` exposes account state to MANAGER+ (management surface, by
  design — no credential material).
