# ASAS CRM — Phase 9 — Cross-Role Integration Report

**The mandate's handoff contracts, before → after**, each with its verification.

## Handoff 1 — manager/sales schedules a visit → field rep receives it

- Link: `agentId` = chosen follow-up rep (defaults to lead owner); visit carries lead + optional opportunity + project + units; POST auto-links the lead's single live opportunity (the closure-gate path).
- Field rep discovery: project-assignment scope (server-enforced) + bell groups VISITS_TODAY/TOMORROW + VISITS_FIELD_DECISION.
- **P9-D12 (new)**: POST idempotency — identical replay within 60 s → 409 VISIT_DUPLICATE (test-pinned).
- **P9-D01 (new)**: agentId reassignment now trails — Activity(ASSIGNMENT) «Visite réassignée» + VISIT_AGENT_CHANGED audit with before/after, committed in-tx (was silent — historical accountability lost; test-pinned via the audit row).

## Handoff 2 — field rep submits the report → sales rep receives the outcome

The 9-A3 audit found the weak link: propagation existed (timeline activity + reportComplete flag + conditional FOLLOW_UP task) but was **pull-only with multi-minute latency and no distinguishing signal**.

- **P9-D02 (new)**: the `VISITS_REPORTED` computed notification group — scoped to `visit.agentId = user.id` (with the lead-owner fallback the report authority itself uses), reports filed in the last 7 days, info tier, self-expiring, inherently idempotent (pure read + scope-keyed TTL cache). Browser-verified live: amine's bell shows «1 compte-rendu de visite à traiter · Le terrain a déposé son rapport · Mustapha Kaid».
- Follow-up task (existing, now test-pinned): created only when `followUpRequired ∧ COMPLETED`, deduped per visit, owned by the visit agent — **P9-D18 (new)**: dueAt rebased on `reportedAt ?? scheduledAt` + 24 h (a late report no longer mints an instantly-overdue task).
- **P9-D19 (new)**: `Visit.nextAction` wired into the report contract (was dead schema).

## Handoff 3 — manager supervises

- Org-wide scope (seesAllRecords) + the dashboard attention strip (unstaffed visits, reconfirm backlog, field decisions) + the new missed/completed visit KPIs + audit trail for every management act (reset, reassignment, corrections).

## Handoff 4 — task delegation (P9-D10, new)

- `POST /api/tasks` accepts `ownerId` (MANAGER+ only, org-validated → 422 OWNER_NOT_FOUND on foreign ids; below MANAGER → 403 TASK_DELEGATE_FORBIDDEN); delegated creation trails ASSIGNMENT «Tâche déléguée» on the lead timeline + TASK_CREATED audit carrying the owner.
- `PATCH /api/tasks/[id]` reassignment: MANAGER+ only (403 TASK_REASSIGN_FORBIDDEN otherwise), with ASSIGNMENT activity + TASK_OWNER_CHANGED audit in-tx. All test-pinned (16/16 suite).

## Idempotency & duplicate prevention (the mandate's law)

| Surface | Mechanism | Pinned |
|---|---|---|
| Visit POST replay | 60 s fingerprint gate → 409 | phase9-workflow ✓ |
| Report resubmission | VISIT_REPORT_IMMUTABLE 422 + no second task | phase9-workflow ✓ |
| Follow-up task creation | per-visit findFirst dedup (in-tx) | phase9-workflow ✓ |
| Lead conversion replay | 409 guards + DB uniques + **P9-D07: P2002 race now maps to 409 ALREADY_CONVERTED (was opaque 500)** | phase9-workflow ✓ |
| Notifications | computed aggregates (no persisted duplicates possible) | architecture law |

## No unrelated employee receives private client data

- Field world = project-assigned visits only; sales world = own+pool; document visibility now role-lawful (P9-D06); visit photos land only on the lead/opportunity timelines the scoped actors already see; VISITS_REPORTED items carry lead names only to the responsible rep (peer-rep negative test pinned).
