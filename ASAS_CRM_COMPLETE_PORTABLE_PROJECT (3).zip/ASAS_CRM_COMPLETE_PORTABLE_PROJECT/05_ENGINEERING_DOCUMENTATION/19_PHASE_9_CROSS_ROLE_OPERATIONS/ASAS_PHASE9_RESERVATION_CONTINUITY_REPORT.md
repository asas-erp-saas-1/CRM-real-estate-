# ASAS CRM — Phase 9 — Reservation & Commercial Continuity Report

**Mandate**: connect opportunities to the existing reservation/payment workflows **without redesigning the financial module or altering historical records**.

## 1. The verified baseline (9-A4 audit — unchanged in Phase 9)

- Booking core (`bookUnitInTx`): guard sequence (live-offer → UNIT_OPTIONED; availability; live-hold → ALREADY_RESERVED; dependents; one-hold-per-deal) → create/revive → apartment flip → stage advance — one transaction; partial unique live-hold indexes as the DB backstop.
- Two-step closure: agent prepares with evidence → MANAGER+ validates (visit gate + idempotent claim + apartment SOLD + opportunity CLOSED_WON + won-value alignment, one tx).
- Payment recording: MANAGER+ only (`payments.record`); fingerprint idempotency; in-tx balance; PAID stamped only by the payment tx.
- Amount semantics (estimate / agreed / schedule / settlement) — tested (booking-semantics, closure-value-consistency, financial-atomicity, payment-idempotency — all green in the final 932/932 run).

## 2. The two Phase 9 repairs (catalog ↔ route alignment, D-ARCH-3)

| Defect | Before | After | Pinned |
|---|---|---|---|
| **P9-D04** — `GET /api/finance/installments` | bare `requireUser()` + scope only — a project-assigned FIELD_REP could read installment amounts, due dates, payment history (the one crack where the CRM world touched financial reads against the declared template) | `requirePermission("payments.view")` — SALES_AGENT+ floor enforced; FIELD_REP → 403; zero behavior change for MANAGER+/SALES_AGENT (200 regression pinned) | phase9-workflow ✓ |
| **P9-D05** — `POST /api/reservations` | bare `requireUser()` — the catalog's `reservations.create` (SALES_AGENT+) floor was unenforced; a FIELD_REP with scoped opportunities could book units | `requirePermission("reservations.create")` — the catalog is the single source of truth for route gates | phase9-workflow ✓ |

Both floors now mirror the permission templates the 152-row matrix asserts — the matrix rows for these routes changed from "documented drift" to enforced reality.

## 3. Installment status gate (P9-D20)

`createInstallment` now rejects schedule lines on CANCELLED/EXPIRED holds (422 RESERVATION_TERMINAL) — previously a line attached to a dead hold permanently tripped RESERVATION_HAS_DEPENDENTS on revival, forcing manual cleanup. CONVERTED (sold) reservations remain bookable — the échéancier's legitimate target.

## 4. What was deliberately NOT touched

- The financial module's transactions, state machines, trust ladders, and DTO role-awareness.
- Historical financial records (no rebase, no retroactive edits).
- Offer lifecycle (MANAGER+ conversion, expiry sweeper — verified unchanged by offer-concurrency 8/8 in the final run).
- Amount field semantics (DZD float law with epsilon guards — documented house law H1).

## 5. Financial integrity in the final gate

booking-semantics ✓ · closure-value-consistency ✓ · financial-atomicity ✓ · payment-idempotency ✓ · money-cap ✓ · offer-concurrency ✓ — all green in the 932/932 sequential run (2026-11-09, restored seed census).
