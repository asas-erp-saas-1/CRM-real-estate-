# ASAS CRM — Phase 9 — UX/UI Acceptance

## 1. The Phase 7/8 backlog priorities — re-verified (mandate §4 A6)

| Priority | Verdict | Evidence |
|---|---|---|
| Dialog mobile-clipping sweep (P0) | **VERIFIED (code-level)** + guarded | 25/32 dialog files clean; 7 carry documented known-baseline debt (≤2 children each, all currently shrinkable); **new automated guard**: `bun run scan:dialogs` (scripts/dialog-rect-scan.mjs) — exit 0, "0 REGRESSIONS vs the frozen baseline"; playwright probe available |
| WCAG dialog close-button hit-area | **FIXED (P9-D13)** | dialog.tsx + sheet.tsx close buttons now `size-8` + `crm-hit` (≥44 px coarse-pointer target via the globals.css pseudo-inset law); sr-only localized labels kept |
| Account activation/credential hardening | **VERIFIED (was already done in Phase 8)** | invite-token / temp-password / reset-alert / login redemption — 9-A6 evidence table |

## 2. The P9 accessibility fixes

- **FormMessage role="alert"** (P9-D15): submit-time validation errors are now assertively announced (the login-overlay pattern generalized into the shared form primitive).
- **min-w-0 sweep** (P9-D16): the 7 residual at-risk dialog grids hardened (record-payment, add-installment, sav-create, create-lead, visit-dialogs ×3, apartment-detail).
- **Temp-password break-all** (P9-D17): long generated secrets wrap instead of overflowing.

## 3. Browser acceptance (STEP 10 — 17 evidence captures, 05_ENGINEERING_DOCUMENTATION/19_PHASE_9_CROSS_ROLE_OPERATIONS/evidence/)

| # | Evidence | Verified |
|---|---|---|
| p9-01 | Manager dashboard | new management KPIs render with real values; console clean |
| p9-02/03/04 | Leads view → lead drawer → timeline | 6 tabs; history traceable («Prospect créé · Source») |
| p9-05/06 | Pipeline kanban → opportunity dialog | ownership chips (LB/AC); «Planifier une visite» CTA present |
| p9-07/08 | Visits view → visit fiche | fiche carries the Documents section (visit-photo guidance) |
| p9-09 | FIELD_REP dashboard | «Terrain» KPI row (1/5/1) renders |
| p9-10/11 | Terrain workspace → execution sheet | agenda cards; checklist; report contract; issue actions |
| p9-12 | **Visit photo upload (LIVE)** | «Façade résidence · p9-visit-photo.png · 67 B · Par Mounia Larbi · cette minute-ci» — end-to-end through the real UI |
| p9-13 | Sales dashboard | My-Day KPIs (1/0) render |
| p9-14 | Notifications bell | **VISITS_REPORTED renders**: «1 compte-rendu de visite à traiter · Mustapha Kaid» |
| p9-15/16 | Mobile 390 px, Arabic RTL | dir=rtl, lang=ar, **no horizontal overflow**, Arabic nav renders (يومي/زياراتي/مهامي) |
| p9-17 | Permission-denied | 403 lock screen in AR («وصول مقيّد — الوصول محفوظ للمديرين») |

- No console errors on any captured surface (one benign chart-mount width warning).
- No clipped dialogs (rect-scan guard green), no broken interactions, no incorrect navigation.
- **Browser-caught product defect fixed**: all dashboard KPI cells rendered "0" (StrictMode count-up freeze) — root-caused and fixed in use-count-up.ts; post-fix, 12/12 cells render real values (see DASHBOARD_METRICS §1).

## 4. Consistency inventory (9-A6 — verified, unchanged by Phase 9)

Shared empty/error states (32 consumers) · one search grammar · one pagination control (6 views) · registry-driven headers/nav · skip-link · aria-labeled icon buttons · focus-visible rings · Radix focus trap/restore · table→card mobile patterns · full RTL plumbing · light/dark.

## 5. Honest residuals (documented, non-blocking)

- The 7 known-baseline dialog debts (bounded by the scan guard; fixing them is cosmetic-only per the mandate's no-cosmetic-changes law).
- Copy buttons in team dialogs at 40 px (24 px AA floor met; below the project's 44 px coarse preference) — INFO tier.
- The chart mount width warning (pre-existing, benign).
