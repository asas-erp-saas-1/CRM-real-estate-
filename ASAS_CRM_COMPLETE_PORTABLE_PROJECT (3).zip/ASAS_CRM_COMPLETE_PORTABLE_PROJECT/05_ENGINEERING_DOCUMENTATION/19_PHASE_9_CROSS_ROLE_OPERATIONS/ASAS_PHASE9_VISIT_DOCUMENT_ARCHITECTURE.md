# ASAS CRM — Phase 9 — Visit Document Architecture (D-ARCH-1)

**The mandate**: "Resolve the Phase 8 disclosure — visit photo uploads deferred because the document model does not support the VISIT entity — safely."

## 1. The decision (Option A — polymorphic extension)

Chosen: extend the existing polymorphic `Document.entityType` vocabulary with `"VISIT"` (+ a `VISIT_PHOTO` category). Rejected: a dedicated `visitId` FK column.

**Why**: 100% reuse of the verified upload security machinery (magic-byte sniffing independent of client MIME, 8 MB pre-parse cap, filename sanitization + lexical containment, realpath read guard, D-021 scoped findFirst 404-ghost law on every read, transactional row+Activity+Audit writes with disk compensation, egress re-sniffing + nosniff + no-store, DOC_DOWNLOADED audit). Zero migration risk in an environment with documented migration-table reset episodes (the `entityType` column is a plain string; both schema twins got comment-only updates). Referential integrity — the one weakness of polymorphic keys — is closed by the visit-DELETE sweep (§4).

## 2. The implementation (all test-pinned)

| Layer | Change | Evidence |
|---|---|---|
| Vocabulary | `"VISIT"` in DOC_ENTITY_TYPES; `"VISIT_PHOTO"` in DOCUMENT_CATEGORIES | constants.ts; constants-matrices tests 33/33 |
| Entity verification | `verifyDocEntity` case VISIT: scoped findFirst via `visitScope(user)` → 404 ghost for foreign/unassigned; returns `{leadId, opportunityId?, visitId}` so uploads thread the lead + opportunity timelines through the existing Activity.visitId linkage | documents.ts |
| Read scope | `documentScope` VISIT branch (visitScope-derived id set) + **P9-D06 fix**: FIELD_REP document visibility now derives from leadScope/oppScope/reservationScope (project world), not ownOrPool — the model-law violation closed; SALES_AGENT predicates byte-identical | visibility.ts; permission-matrix + visit-attachments suites |
| Upload authority | the scoped findFirst itself (any user who can see the visit) + the full content gate | documents route (zod enum flows VISIT automatically) |
| Orphan policy | visit DELETE sweeps its VISIT documents (rows in-tx, disk files post-commit via deleteDocFile) | visits/[id]/route.ts |
| Field UI | execution-sheet «Photos / pièces jointes» section (EntityDocuments, mobile-first) | field-visit-sheet.tsx; browser evidence p9-11/p9-12 |
| Reviewer UI | visit fiche gains the same section (print:hidden — the paper sheet stays clean) | visit-fiche-dialog.tsx; browser evidence p9-08 |
| i18n | `docs.category.VISIT_PHOTO`, `docs.empty.descVisit`, `field.photos.title` — fr/en/ar (parity-guarded) | i18n tests 10/10 |

## 3. Security review (the mandate's checklist, answered)

1. **documentScope VISIT branch is visitScope-derived** — yes (the D3 precedent was the fix, not the repeat).
2. **Upload authority** — scoped-visibility basis (same law as every other entity); content gate unchanged.
3. **Orphan handling on visit delete** — swept in-transaction (§4 of the table above).
4. **Category** — dedicated VISIT_PHOTO (vs reusing OTHER) — chosen: it makes visit evidence measurable in the documents module.
5. **Storage** — `db/docs`, 8 MB/file, sniffed; the persistence class equals the database's (disclosed limitation, §5 of the field-ops spec).

## 4. Adversarial results (tests/security/visit-attachments.test.ts — 9/9)

- FIELD_REP uploads to an assigned-project visit → 201 + listed ✓
- FIELD_REP upload to a visit NOT on their project → 404 ghost ✓
- Cross-org MANAGER upload → 404 ✓
- Unauthorized download (anon, unrelated peer) → refused ✓
- SALES_AGENT (own+pool world) sees the visit document ✓
- VISIT_PHOTO accepted; disguised .txt/.exe → rejected by content gate ✓
- FIELD_REP documentScope regression (pool-lead docs invisible) ✓
- Full teardown residue: 0 rows, 0 stray files ✓

## 5. Alternative considered (documented per mandate §6)

Option B (explicit `visitId` FK + relation) offers true DB-level referential integrity but required a migration in a reset-prone environment, broke the established polymorphic uniformity (5 string types + 1 FK = two query paths in scope/verify/UI), and touched both schema twins. The DELETE-sweep closes the orphan path Option A's weakness at a fraction of the risk. Decision recorded in WORKFLOW_ARCHITECTURE.md (D-ARCH-1).
