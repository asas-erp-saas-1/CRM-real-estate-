# ASAS CRM — Phase 9 — Test Evidence

**Final gate**: `bunx vitest run --maxWorkers=1` (the Phase 6 "FINAL REGRESSION (definitive)" methodology — sequential files against the live warm dev server; eliminates the SQLite lock-contention failures documented under parallel workers) — after a verified DB restore to the Phase 8 census.

## Definitive run (2026-11-09, post count-up fix, restored census)

```
Test Files  57 passed (57)
     Tests  932 passed (932)
  Duration  ~52 s (sequential, warm server)
```

Baseline at Phase 8 close: 903/903 (53 files). Phase 9 adds +29 tests (3 new suites + contract extension), zero removed, zero weakened assertions.

## New suites

| Suite | Tests | Pins |
|---|---|---|
| tests/security/visit-attachments.test.ts | 9 | VISIT entity upload/list/download security: assigned-project upload 201; unassigned/foreign-org 404 ghosts; unauthorized download refused; SALES own+pool visibility; VISIT_PHOTO category; content-gate rejections; FIELD_REP documentScope regression |
| tests/security/dashboard-metrics.test.ts | 4 | role KPI presence + null-gating per persona; RESCHEDULED delta law (create → todayVisits +1); commissions aggregate |
| tests/security/phase9-workflow-integration.test.ts | 16 | conversion success path (201 shape, linkage, CONVERSION activity, owner inheritance) + 409 repeat; P2002 race → 409; stage-move refusal codes (OPPORTUNITY_ILLEGAL_TRANSITION, LOST_REASON_REQUIRED); follow-up task creation + idempotency + reportedAt clock + nextAction; terminal-transition authority (403/200); visit POST duplicate 409; task delegation (403/201/audit) + reassignment (403/200/audit); VISITS_REPORTED (positive + peer-negative, TTL-poll aware); finance/reservation permission floors (403 + 200 regression) |

## Updated suites

- tests/contract/services-contract.test.ts — the P1-SVC-2 kpi key list extended with the 9 additive wire fields (the contract legitimately grew).
- tests/security/permission-matrix.test.ts — unchanged code, re-run green (135/135 standalone; in-suite under the sequential gate): the two formerly-drifted floors (installments GET, reservations POST) now match its declared rows.

## Quality gates

| Gate | Result |
|---|---|
| `bun run typecheck` | 0 errors |
| `bun run lint` | 0 errors / 42 warnings (the pre-existing baseline — the one new warning introduced mid-phase was removed) |
| `bun run scan:dialogs` | exit 0 — 32 files, 25 clean, 7 known-baseline, 0 regressions |
| `bunx vitest run tests/unit/i18n.test.ts` | 10/10 (parity guard over the new keys ×3 languages) |
| Production build | NOT run — house law (P7.1 verified pipeline unchanged; all Phase 9 changes are route/component-level, no build-config touch) |

## Incident log (the runs that did NOT count, and why)

1. Parallel full-suite attempts under `maxWorkers: 12/4/2`: SQLite lock-contention + dev-server OOM kill (kernel reaped next-server ~1.3 GB RSS) — the documented Phase 6/7 class. Recovery: restart + sequential methodology.
2. Two collection-time failures: the sandbox reaped the background dev server between tool invocations — preflight threw (the suites' mandatory no-skip law working as designed). Recovery: server + suite in one invocation.
3. One run failed on demo-DB fixture residue (order-dependent attribution test reading "first lead in list" — pre-existing design). Recovery: verified backup restore (interlocked script, safety snapshot first, census-matched).

Each incident is disclosed in SECURITY_AND_DATA_INTEGRITY_REPORT §4; none touched business data (final census = the Phase 8 backup census, byte-verified).
