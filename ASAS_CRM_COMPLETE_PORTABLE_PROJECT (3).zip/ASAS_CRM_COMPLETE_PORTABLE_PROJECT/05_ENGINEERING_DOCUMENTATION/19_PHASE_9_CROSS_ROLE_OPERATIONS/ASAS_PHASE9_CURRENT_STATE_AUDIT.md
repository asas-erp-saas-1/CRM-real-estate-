# ASAS CRM — Phase 9 — Current State Audit

**Date**: 2026-11-09 · **Principal**: consolidation of the six independent agent audits (9-A1…9-A6)
**Repo state at audit**: `main` @ `893fd1f`, clean tree; dev server healthy (`/api/health` 200, dbOk, migrations 26, demo preview mode preserved); pre-phase backup `db/backups/backup-20261109T124448Z` (census: users 8 · leads 43 · opportunities 21 · reservations 8 · apartments 46 · documents 0 · visits 24 · tasks 18).
**Method**: read-only code audits with file:line evidence; test re-runs where cited. No code was modified during the audit.

---

## 1. Canonical workspace verification (STEP 1)

| Fact | Value | Evidence |
|---|---|---|
| Framework | Next.js 16 App Router, React 19, TS 5, Tailwind 4, Prisma 6.11 / SQLite | package.json |
| Workspace | `/home/z/my-project` (single canonical project; no separate ZCode/export) | git branch `main` @ `893fd1f` |
| Migrations | 26 applied (incl. Phase 8 `phase8_auth_tokens`) | `/api/health` echo |
| Auth | Custom session architecture (SCRYPT + session table + centralized permission catalog) | src/lib/server/auth.ts, authorize.ts |
| Roles | OWNER, MANAGER, SALES_AGENT, FIELD_REP (+ ADMIN deputy tier, ceiling-pinned) | permissions.ts |
| Localization | FR-first, full AR RTL, EN; 21 dictionary domains; runtime parity guard (i18n tests 10/10) | src/lib/i18n |
| Test baseline | 903 tests green at Phase 8 close | Phase 8 gate |
| Preview | Port 3000, demo mode ON (dev preview contract preserved) | /api/health |

## 2. Phase 8 / Phase 7 backlog review (STEP 2)

- Phase 8 verdict **A** (identity, RBAC, four role workspaces, 152 adversarial rows, 903/903).
- **Disclosed follow-up #1 (now Phase 9 A2 core mandate)**: visit photo/document upload deferred — "the documents module has no VISIT entity; adding it is a scoped follow-up with its own security review."
- Phase 7 backlog P0 items re-verified by 9-A6: dialog mobile-clipping sweep substantively fixed in code (14/26 dialog files carry `min-w-0`; zero fixed-width children found) but **no automated rect-scan guard exists**; WCAG dialog close-button hit-area **genuinely open** (~16×16 px); account activation/credential hardening **VERIFIED** (invite-token, temp-password, reset-alert, login redemption all evidenced).

## 3. Six-agent audit summary (STEP 3)

### 9-A1 — CRM lifecycle (lead → opportunity)
| Workflow | State |
|---|---|
| Lead→opportunity conversion preserves history (atomic tx: Contact + Opportunity + CONVERSION activity; lead never deleted) | IMPLEMENTED_NOT_VERIFIED (no success-path test) |
| Sales-rep ownership preserved on conversion + reassignment cascade | IMPLEMENTED_NOT_VERIFIED |
| Conversion idempotency (DB uniques + 409 guards; **race → 500 not 409**) | IMPLEMENTED_NOT_VERIFIED (defect D2) |
| Stage transitions server-validated (adjacency matrix + hard money gates in-tx) | VERIFIED |
| Lost/won outcomes with coded reason taxonomy | VERIFIED |
| Source attribution preserved (immutable `Lead.source`) | VERIFIED |
| Visit outcome → sales FOLLOW_UP task (idempotent per visit) | IMPLEMENTED_NOT_VERIFIED (no test) |
| Lifecycle activities (LEAD_CREATED/CONVERSION/STAGE_CHANGE/ASSIGNMENT/VISIT) | IMPLEMENTED_NOT_VERIFIED (3 of 5 untested) |

### 9-A2 — Field operations & visit evidence
| Workflow | State |
|---|---|
| Visit model (7 statuses + structured report contract + relations) | VERIFIED |
| Visit transition matrix + server PATCH guards (stale 409, authority 403s) | VERIFIED — except NO_SHOW/CANCELLED/RESCHEDULED lack authority guard (D1) |
| Structured report (server-validated, server-stamped provenance, immutable) | VERIFIED |
| Field-rep scoping (project-assigned visits only; cross-org 404 ghost law) | VERIFIED |
| Field workspace (mobile-first agenda, fiche, checklist, report form) | VERIFIED |
| Documents module (disk storage `db/docs`, magic-byte sniffing, 8MB cap, sanitization, realpath guard, transactional writes, egress audit) | VERIFIED |
| **VISIT entity in documents module** | **MISSING** (the Phase 8 disclosure) |
| `documentScope` FIELD_REP uses `ownOrPool` (violates project-world law) | PARTIALLY_IMPLEMENTED (D3) |
| `Visit.nextAction` field | DOCUMENTED_ONLY (dead schema) |

### 9-A3 — Cross-role workflow integration
| Handoff | State |
|---|---|
| Notifications architecture (computed aggregates, scope-keyed, org-scoped, TTL cache) | VERIFIED (pull-based) |
| Visit assignment → field-rep agenda (project-scoped pull + bell groups) | VERIFIED |
| Visit report → sales rep outcome | PARTIALLY_IMPLEMENTED (timeline activity + reportComplete flag + conditional FOLLOW_UP task; **no dedicated notification** — multi-minute pull latency) |
| Visit agentId reassignment trail | **MISSING** (silent reassignment — no ASSIGNMENT activity/audit) |
| Follow-up task only when required (deduped per visit) | VERIFIED |
| Report retry idempotency (immutable guard) | VERIFIED |
| Visit POST retry idempotency | MISSING |
| Task delegation (ownerId on POST/PATCH) | MISSING (manager cannot delegate; tasks always creator-owned) |
| Manager supervision (org-wide scope) | VERIFIED |

### 9-A4 — Reservation & commercial continuity
| Control | State |
|---|---|
| Reservation↔opportunity linkage (scoped server validation; two-step closure approval; idempotent closure claim) | VERIFIED |
| Double-booking prevention (in-tx re-read + partial unique live-hold indexes) | VERIFIED |
| Payment authority (MANAGER+ only; SALES_AGENT cannot verify; idempotency fingerprint) | VERIFIED |
| FIELD_REP blocked from financial writes | VERIFIED |
| FIELD_REP blocked from financial reads | PARTIALLY_IMPLEMENTED (`GET /api/finance/installments` lacks `payments.view` gate — D1) |
| `reservations.create` permission floor (catalog says SALES_AGENT+) | DOCUMENTED_ONLY (route uses bare `requireUser()` — D2) |
| Installment status gate (no lines on CANCELLED/EXPIRED holds) | MISSING (LOW) |
| Amount semantics (estimate/agreed/schedule/settlement; DZD float law defended) | VERIFIED |

### 9-A5 — Dashboards & metrics
| Surface | State |
|---|---|
| Role-scoped dashboard API (~30 queries, visibility fragments, no leakage) | VERIFIED |
| todayVisits/upcomingVisits exclude RESCHEDULED status | PARTIALLY_IMPLEMENTED (undercount defect) |
| commissions.total / pendingIncentives.total sum only capped rows | PARTIALLY_IMPLEMENTED (understated money figures) |
| FIELD_REP dashboard metrics (pending reports, completed, reschedule requests) | MISSING |
| MANAGER missed-visits KPI, leads-awaiting-assignment on dashboard | MISSING / PARTIAL |
| SALES my-completed-visits, my-pending-reservations KPIs | MISSING |
| Analytics route unbounded findMany (3) | IMPLEMENTED_NOT_VERIFIED (perf defect) |

### 9-A6 — UX/UI quality & accessibility
| Priority | State |
|---|---|
| Dialog clipping sweep | PARTIALLY_IMPLEMENTED (manual fixes held; no automated guard — D2) |
| WCAG dialog/sheet close-button hit-area | **MISSING** (~16×16 px — WCAG 2.5.8 fail, D1) |
| Activation/credential hardening | VERIFIED |
| Shared states/search/pagination/headers consistency | VERIFIED (32 / 6-view / 6-view / registry-driven) |
| Skip-link, aria-labels, focus-visible, focus trap, RTL, responsive | VERIFIED |
| FormMessage assertive announcement | PARTIALLY_IMPLEMENTED (role="alert" missing, D3) |
| min-w-0 residual risk in 7 dialog files | PARTIALLY_IMPLEMENTED (D4) |

## 4. Overall assessment

The Phase 8 foundation is strong and honest: authorization, scoping, financial atomicity, and localization are verified layers with adversarial test coverage. Phase 9's real work is **integration debt**, in three clusters:

1. **Workflow continuity gaps** — silent visit reassignment, no report-submission signal to sales, no task delegation, unguarded terminal visit transitions, catalog↔route permission drift.
2. **The missing VISIT document entity** — the disclosed Phase 8 follow-up; all upload security machinery exists and is verified, only the entity vocabulary, scope branch, orphan policy, and field UI are missing.
3. **Metric correctness and completeness** — undercounted visit KPIs, understated money aggregates, and whole metric families absent for FIELD_REP/SALES/MANAGER dashboards.

Verification asymmetry (A1's finding) is systemic: money paths and rollbacks are heavily tested; happy-path lifecycle, handoffs, and follow-up creation are implemented but asserted nowhere. Phase 9 closes both the defects and the assertion gaps.
