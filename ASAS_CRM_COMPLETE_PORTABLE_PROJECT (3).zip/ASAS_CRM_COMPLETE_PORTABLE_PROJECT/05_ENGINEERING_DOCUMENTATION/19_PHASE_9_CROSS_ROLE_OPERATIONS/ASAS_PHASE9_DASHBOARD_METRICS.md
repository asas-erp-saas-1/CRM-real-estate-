# ASAS CRM — Phase 9 — Dashboard Metrics

**Law**: every metric is computed from real authorized database queries (role-scoped visibility fragments); no global counts or financial totals leak to unauthorized roles; definitions are documented and test-pinned (tests/security/dashboard-metrics.test.ts 4/4, tests/unit/services-dashboard.test.ts 10/10, contract test updated for the additive wire shape).

## 1. Correctness repairs (the 9-A5 audit defects)

| ID | Defect | Repair |
|---|---|---|
| P9-D08 | todayVisits/upcomingVisits excluded RESCHEDULED (a moved-slot pending visit vanished from the KPIs while the field agenda showed it) | AGENDA_VISIT_STATUSES = ACTIVE ∪ {RESCHEDULED} on both KPI counts and the todayVisits agenda list — delta-pinned by test (create a RESCHEDULED visit → count +1) |
| P9-D09 | commissions.total summed only the take:6 entries; pendingIncentives.total summed the 50 capped items — money figures understated | parallel SQL aggregates (`_sum`) over the same where; entries keep their caps; count stays the exact count() |
| P9-D22 | todayTasks/todayVisits agenda lists unbounded | take: 50 |
| P9-D21 | analytics route: 3 unbounded findMany shipped to JS | take: 5000 (the house W2-3 cap) — semantics identical |
| **NEW (browser-caught)** | **ALL KPI cells rendered "0" in the dev preview** — useCountUp's StrictMode double-mount froze the MotionValue at 0 (first mount's animation stopped by cleanup; remount early-returned) | settled-state guarantee on the unchanged path (`mv.set(value)`); production animation untouched; browser-verified: 12/12 cells render real values |

## 2. The mandated role metrics (all live, browser-verified on the seed census)

| Role | Metric | Definition | Live value (seed) |
|---|---|---|---|
| MANAGER+ | missedVisits | NO_SHOW count, scheduledAt in range | 1 |
| MANAGER+ | leadsAwaitingAssignment | status NEW ∧ ownerId null ∧ archived false (the LEADS_UNASSIGNED predicate) | 0 |
| MANAGER+ | completedVisits | COMPLETED, scheduledAt in range | 8 |
| MANAGER+ | lostOpportunities | CLOSED_LOST with closedAt in range (the lost twin of wonInRange's window) | 1 |
| SALES_AGENT | myCompletedVisits | COMPLETED in caller's visit scope, windowed | 1 (amine) |
| SALES_AGENT | myPendingReservations | reservations in caller's reservationScope with status ACTIVE/CLOSURE_REQUESTED | 0 (amine) |
| FIELD_REP | fieldPendingReports | SCHEDULED/CONFIRMED in visitScope with scheduledAt < now (execution+report overdue) | 1 (mounia) |
| FIELD_REP | fieldCompletedVisits | COMPLETED in scope, windowed | 5 |
| FIELD_REP | fieldRescheduleRequests | awaitingCustomerReconfirm in scope | 1 |

## 3. Null-gating (no leakage)

Every new field is `number | null` on the wire, populated only for its persona (the data-contract role gate — the same hide-on-null law as the attention strip): management KPIs null below MANAGER, My-Day KPIs null outside SALES_AGENT, Terrain KPIs null outside FIELD_REP. Asserted per-role by dashboard-metrics.test.ts (b + c rows). The UI renders each row only when its keys are non-null (RoleKpiRows) — no client-side role check to drift out of sync with the server.

## 4. Pre-existing verified surface (unchanged)

Core KPI strip (todayTasks/todayVisits/upcomingVisits/hotOpportunities/newLeads/wonInRange/conversionRate/pipelineValue — conversionRate is the CREATED_COHORT_RATE, named and documented in lib/metrics.ts), attention strip, funnel, sourcePerformance, incentives (agent money), activity series, recent leads, today agendas. No N+1 found (batched joins); agenda/economics single-query.

## 5. UI

Role-deep rows render as neutral context-tier cards (number + label + live/period dot — windowed metrics carry the violet dot, live ones the emerald pulse), «Terrain» section label for the field row, no fake deep-links (the honest-surface law). i18n: 10 new keys × fr/en/ar (parity-guarded).
