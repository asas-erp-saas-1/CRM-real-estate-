# ASAS CRM — Phase 9 — Defect Register (prioritized)

Source: six-agent audit (2026-11-09). Severity reflects business/security impact. Every item carries file:line evidence in the audit trail; fixes land in Phase 9 unless explicitly deferred.

## CRITICAL-path for Phase 9 missions (workflow integration)

| ID | Sev | Area | Defect | Location | Fix plan |
|---|---|---|---|---|---|
| P9-D01 | HIGH | A3 | Visit agentId reassignment is trail-silent — no ASSIGNMENT activity, no audit; historical accountability lost | visits/[id]/route.ts:368-372 | In-tx ASSIGNMENT activity + VISIT_AGENT_CHANGED audit (mirror leads route law) |
| P9-D02 | HIGH | A3 | No event on visit-report submission — sales rep discovers outcome only via pull with multi-minute latency | notifications/route.ts (design) | VISITS_REPORTED computed group scoped to `visit.agentId = user` |
| P9-D03 | MED | A2 | NO_SHOW/CANCELLED/RESCHEDULED transitions carry no authority guard — any in-scope user can terminally alter another actor's visit | visits/[id]/route.ts:175-576 | Apply report-authority predicate to terminal transitions |
| P9-D04 | MED | A4 | `GET /api/finance/installments` lacks `payments.view` gate — FIELD_REP reads installment amounts/payment history | finance/installments/route.ts:17 | requirePermission("payments.view") |
| P9-D05 | MED | A4 | `POST /api/reservations` has no permission floor — catalog says SALES_AGENT+ but route accepts any scoped user (FIELD_REP can book) | reservations/route.ts:63 | requirePermission("reservations.create") |
| P9-D06 | MED | A2 | `documentScope` FIELD_REP uses `ownOrPool` — violates project-world law; field rep sees pool-lead docs, misses project-world docs | visibility.ts:194-213 | FIELD_REP branch → leadScope/visit-derived |
| P9-D07 | MED | A1 | Double-convert race answers HTTP 500 (P2002 uncaught) instead of 409 | convert/route.ts:25-40 + session.ts:290 | In-tx P2002 catch → 409 ALREADY_CONVERTED |
| P9-D08 | MED | A5 | todayVisits/upcomingVisits exclude RESCHEDULED — KPI undercounts vs field agenda | services/dashboard.ts:297-302 | Include RESCHEDULED in predicates |
| P9-D09 | MED | A5 | commissions.total understates (sums take:6 rows); pendingIncentives.total sums 50 capped items | dashboard.ts:543-547, 577 | Parallel SQL aggregates |
| P9-D10 | MED | A3 | Task delegation impossible — POST/PATCH schemas lack ownerId; tasks always creator-owned | tasks/route.ts:68-76, [id]:22-28 | Optional org-validated ownerId (MANAGER+), ASSIGNMENT trail |
| P9-D11 | MED | A2 | **VISIT missing from documents module** (Phase 8 disclosure) — no visit photos/evidence | constants.ts, documents.ts, visibility.ts | Option A: extend entityType vocabulary (see architecture doc) |
| P9-D12 | MED | A3 | POST /api/visits not idempotent — client retry duplicates visit + activity | visits/route.ts:188-366 | 60s fingerprint duplicate gate (payments pattern) |

## HIGH-priority UX / a11y

| ID | Sev | Area | Defect | Location | Fix plan |
|---|---|---|---|---|---|
| P9-D13 | HIGH | A6 | Dialog/Sheet close-button hit-area ~16×16 px — WCAG 2.5.8 fail; app's own 44px law unenforced on most-used control | ui/dialog.tsx:120, ui/sheet.tsx:128 | crm-hit + size on both close buttons |
| P9-D14 | MED | A6 | No automated rect-scan guard for the P0 dialog-clipping class | scripts/ (absent) | Browser-driven sweep script + phase evidence |
| P9-D15 | LOW | A6 | FormMessage not assertively announced (role="alert" missing) | ui/form.tsx:146-155 | Add role="alert" |
| P9-D16 | LOW | A6 | 7 dialog files: grid children without min-w-0 (future clip risk) | record-payment/add-installment/sav-create/create-lead/visit-dialogs/apartment-detail | min-w-0 sweep |
| P9-D17 | LOW | A6 | Temp-password `<code>` lacks break-all (long secret overflows) | temp-password-dialog.tsx:68 | break-all |

## MEDIUM/LOW workflow correctness

| ID | Sev | Area | Defect | Location | Fix plan |
|---|---|---|---|---|---|
| P9-D18 | LOW | A3 | Auto follow-up dueAt = scheduledAt+24h — late-submitted report creates instantly-overdue task | visits/[id]/route.ts:549 | Base on reportedAt ?? scheduledAt |
| P9-D19 | LOW | A2 | `Visit.nextAction` dead schema (never written) | schema.prisma:597 | Wire into report PATCH |
| P9-D20 | LOW | A4 | createInstallment lacks reservation-status gate (lines on CANCELLED/EXPIRED holds trip dependency guard forever) | installments.ts:187-191 | Reject on terminal hold statuses |
| P9-D21 | LOW | A5 | Analytics route: 3 unbounded findMany shipped to JS | analytics/route.ts:63-66,140-147 | SQL aggregates / take caps |
| P9-D22 | LOW | A5 | todayTasks/todayVisits agenda lists unbounded | dashboard.ts:402-411 | take: 50 |
| P9-D23 | LOW | A1 | computeStageGates loads lead visits unbounded | opportunity-gates.ts:129-140 | take: 200 |
| P9-D24 | LOW | A3 | Unassigned-leads count runs for agents too (wasted query before isManager gate) | notifications/route.ts:139-141 | Move inside gate |
| P9-D25 | LOW | A3 | FOLLOW_UP dedup is app-level only (no unique constraint; SQLite single-writer mitigates) | visits/[id]/route.ts:544-548 | Accepted risk — document (no migration warranted) |

## Missing metrics (mandated dashboards)

| ID | Role | Missing metric | Fix plan |
|---|---|---|---|
| P9-M01 | FIELD_REP | pending visit reports / completed visits / rescheduling requests KPIs | field KPI block in dashboard API + UI |
| P9-M02 | MANAGER | missed visits (NO_SHOW) KPI; leads awaiting assignment on dashboard | Add kpis.missedVisits, kpis.leadsAwaitingAssignment (MANAGER+) |
| P9-M03 | SALES_AGENT | my completed visits; my pending reservations | Add scoped KPIs |
| P9-M04 | OWNER | lost count on dashboard | Reuse journey outcome count in dashboard API (MANAGER+) |

## Verification debt (test additions — no product change)

| ID | Area | Gap |
|---|---|---|
| P9-T01 | A1 | Conversion success-path test (201 shape, linkage, CONVERSION activity, owner inheritance, 409 repeat) |
| P9-T02 | A1 | Stage-move refusal codes at API level (422 family) |
| P9-T03 | A1 | Visit follow-up task creation + idempotency test |
| P9-T04 | A2 | Visit attachment security tests (cross-org, forged visit id, unauthorized download) |
| P9-T05 | A4 | Permission floor tests (FIELD_REP → 403 on installments GET + reservations POST) |
| P9-T06 | A5 | Dashboard metric tests (RESCHEDULED inclusion, aggregates) |

## Explicitly deferred (documented, not Phase 9)

- P9-D25 (FOLLOW_UP unique constraint — migration risk > benefit in single-writer SQLite)
- A2 D5 (outcome vs reportNotes semantic duplication — owner UX decision, contract-accepted)
- God-route extraction, lockout-DoS redesign, coverage thresholds (Phase 7 backlog D-category, owner's no-big-refactor stance)
- Notification read-state persistence (client-side localStorage is the documented architecture; server persistence is a designed follow-up, not a defect)
