# ASAS CRM — Phase 9 — Security & Data Integrity Report

## 1. Adversarial results — zero unauthorized access (target met)

| Attack class | Result | Where pinned |
|---|---|---|
| Unauthorized visit access (cross-org, unassigned project) | 404 ghost | permission-matrix (re-run green), visit-attachments |
| Unauthorized attachment downloads (anon, unrelated peer) | refused | visit-attachments 9/9 |
| Cross-organization file access | 404 ghost | visit-attachments (foreign MANAGER upload → 404) |
| Forged ownership identifiers (foreign agentId, ownerId, entityId) | 422/404, never silently linked | phase9-workflow (AGENT_NOT_FOUND / OWNER_NOT_FOUND paths), visit-attachments |
| Forged visit states (illegal transitions, replayed reports) | 422 family (VISIT_ILLEGAL_TRANSITION, VISIT_REPORT_IMMUTABLE) | phase9-workflow |
| Duplicate visit submission | 409 VISIT_DUPLICATE | phase9-workflow |
| Duplicate notification creation | impossible (computed aggregates) | architecture |
| Unauthorized payment actions | 403 (unchanged floors) | permission-matrix |
| Unauthorized reservation approval | unchanged two-step closure (MANAGER+) | closure-value-consistency |
| FIELD_REP financial reads | **403 (NEW — payments.view floor)** | phase9-workflow |
| FIELD_REP reservation creation | **403 (NEW — reservations.create floor)** | phase9-workflow |
| Terminal visit alteration by non-responsible actor | **403 VISIT_OUTCOME_FORBIDDEN (NEW)** | phase9-workflow |
| Search/dashboard leakage | none found (null-gated role KPIs; scoped aggregates) | dashboard-metrics per-role assertions |
| Report provenance spoofing | server-stamped reportedById/reportedAt (client keys stripped) | zod schema law, phase9-workflow |

## 2. Data integrity (the mandate's §8 checklist)

- Lead conversion: atomic tx (contact + opportunity + lead flip + CONVERSION activity + audit); **race now answers 409, never 500** (P9-D07); DB uniques as the backstop.
- Visit transitions: matrix + authority + stale-guard (409 VISIT_STALE on concurrent edits).
- Visit report submission: atomic both-fields contract, immutable after, auto-follow-up deduped per visit.
- Attachment association: org-scoped, visit-scoped, transactional row+activity+audit with disk compensation; visit DELETE sweeps orphans in-tx.
- Reservation creation: booking transaction + live-hold partial uniques (unchanged).
- Payment actions: idempotency fingerprint + in-tx balance (unchanged).
- Activity history: every Phase 9 write path trails (ASSIGNMENT ×3 new, VISIT family, TASK family, CONVERSION).
- Notifications: computed (no uncommitted-transaction generation possible).
- Installments: terminal-hold gate (422 RESERVATION_TERMINAL).

## 3. Database safety (mandate §6/§15 compliance)

- **No schema migration** (Option A is vocabulary-level; comment-only schema updates).
- **No reset, no reseed, no deletion of business records.**
- Pre-phase verified backup: `db/backups/backup-20261109T124448Z` (runId 266eef5f, census users 8 · leads 43 · opps 21 · reservations 8 · apartments 46 · documents 0).
- The demo DB was restored from that backup (sha256-verified, census-matching) whenever test-suite residue accumulated — the documented Phase 8 recovery procedure, executed with the interlocked restore script (safety snapshot taken first each time). Final state: exact Phase 8 census, migration count 26.

## 4. Disclosed incidents (honest record)

1. **OOM kill mid-suite** (kernel reaped next-server at ~1.3 GB RSS under 12 parallel vitest workers) — the documented Phase 6/7 incident class. Recovered: server restart + the house sequential methodology (`--maxWorkers=1` + warm server — exactly the Phase 6 "FINAL REGRESSION (definitive)" method). No data loss (SQLite file intact; integrity_check verified by the backup tooling).
2. **Environment background-process reaping** — the sandbox kills/restarts the dev server between tool invocations at unpredictable times, which produced two invalid full-suite attempts (collection-time preflight failures). Mitigation: server + suite in one invocation.
3. **Demo-DB fixture residue** from repeated suite runs (booking-semantics marker leads) broke the order-dependent attribution test once — resolved by the backup restore; the attribution test's "first lead in list" design is pre-existing (documented as residual test debt).

## 5. Residual security posture (carried, unchanged)

- Redeem spray limiter remains in-process (single-instance deployment; PostgreSQL port note in code).
- Session/notification read-state: client-side (documented architecture).
- No secrets, no password hashes, no customer PII appear in any Phase 9 artifact.
