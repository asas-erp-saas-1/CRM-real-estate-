# ASAS CRM — Phase 9 — Workflow Architecture (Principal-approved)

**Approval date**: 2026-11-09 · **Principal decision record** consolidating 9-A1…9-A6 findings into the implementation boundary.

## 1. Approved architecture decisions

### D-ARCH-1 — Visit attachments: extend the polymorphic document model (Option A)

**Decision**: add `"VISIT"` to `DOC_ENTITY_TYPES` (and a `VISIT_PHOTO` category) rather than a dedicated `visitId` FK column.

**Rationale**: 100% reuse of the verified upload security machinery (magic-byte sniffing, 8 MB cap, filename sanitization + lexical containment, realpath read guard, scoped findFirst 404-ghost law, transactional row+activity+audit writes with disk compensation, egress audit). Zero migration risk in an environment with documented migration-reset episodes; the `entityType` column is a plain string.

**Referential integrity**: polymorphic keys carry no FK — the visit DELETE route will delete attached document rows + disk files inside its transaction (mirroring the documents DELETE law), closing the orphan path.

**Scope rules**: `documentScope` gains a VISIT branch derived from `visitScope` (project-assigned world for FIELD_REP — fixing P9-D06), and `verifyDocEntity` resolves VISIT through the scoped visit lookup, returning `{leadId, opportunityId, visitId}` so uploaded photos land on the lead + opportunity timelines automatically through the existing `Activity.visitId` threading.

**Storage honesty**: files persist on the same disk class as the SQLite database (`db/docs`). This is the maximum durability the environment offers; the limitation is documented (no object storage in scope; sandbox reset hazard disclosed). Uploads remain ≤8 MB, sniffed, and org-scoped.

### D-ARCH-2 — Notifications stay computed (pull model), extended with a report-aware group

No new persistence engine. Add `VISITS_REPORTED` as a computed aggregate scoped to `visit.agentId = user.id` (reports filed recently that still warrant sales attention), consistent with the existing 12-group architecture (scope-keyed, TTL-cached, inherently idempotent).

### D-ARCH-3 — Permission catalog is the single source of truth for route gates

Routes currently using bare `requireUser()` where the catalog declares a floor (`payments.view` on installments GET; `reservations.create` on reservations POST) are brought in line with the catalog. The catalog itself is NOT weakened.

### D-ARCH-4 — Visit terminal transitions get the report-authority predicate

NO_SHOW / CANCELLED / RESCHEDULED acquire the same authority law as completion (assigned field rep ∨ visit agent ∨ lead owner ∨ MANAGER+). Plain RESCHEDULED becomes a manager/agent/executive action; field-rep slot moves keep using the counter-proposal discipline (`proposeAlternative` + customer reconfirm), restoring the D-026 §21 law.

### D-ARCH-5 — Dashboards: correct the existing metrics, add the mandated role KPIs in place

Fix undercount/understate defects (RESCHEDULED inclusion, SQL aggregates for money totals, take caps) and add the mandated metric families (FIELD_REP pending-reports/completed/reschedule-requests; MANAGER missed-visits + awaiting-assignment; SALES my-completed-visits/my-pending-reservations; OWNER lost count) inside the existing role-scoped dashboard service — no new endpoint, no leakage (all new fields null-gated below their role).

### D-ARCH-6 — Delegation and trails

Task POST/PATCH gain an optional org-validated `ownerId` (MANAGER+ only) with ASSIGNMENT activity trail. Visit agentId reassignment gains the ASSIGNMENT activity + VISIT_AGENT_CHANGED audit. Follow-up dueAt rebased on `reportedAt ?? scheduledAt`.

## 2. Implementation batches (with defect IDs)

- **Batch W (workflow integrity, Principal)**: P9-D01, D03, D07, D10, D12, D18, D19, D23, D24 + D04, D05, D20 (permission floors + installment gate).
- **Batch F (field evidence, Agent I1)**: P9-D11, D06 (documentScope), visit-attachment UI + orphan cleanup coordination + tests P9-T04.
- **Batch M (metrics + UX, Agent I2)**: P9-D08, D09, D13–D17, D21, D22, M01–M04 + tests P9-T06.
- **Batch T (verification debt, Principal)**: P9-T01, T02, T03, T05 + full regression.

## 3. Boundaries preserved

No ERP scope, no microservices, no auth/authorization replacement, no role renaming, no financial-module redesign, no historical-record alteration, no production release, no hosting change, no DB reset/reseed. All schema changes: none required (Option A is vocabulary-level). The pre-phase backup `backup-20261109T124448Z` stands as the recovery point.
