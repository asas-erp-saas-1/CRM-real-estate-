# ASAS CRM — Phase 9 — Field Operations Specification

**Scope**: the FIELD_REP daily execution world — agenda, execution sheet, structured report, visit evidence. Everything below is browser-verified (evidence: 05_ENGINEERING_DOCUMENTATION/19_PHASE_9_CROSS_ROLE_OPERATIONS/evidence/p9-09…p9-12) and test-pinned (tests/security/visit-attachments.test.ts, phase9-workflow-integration.test.ts).

## 1. The field world (verified)

- **Navigation**: Terrain · Tableau de bord · Parcours client · Visites · Tâches · Inventaire · SAV — no Finance, no Pipeline, no Settings-team (view-registry role law).
- **Scoping**: `visitScope(FIELD_REP)` = visits on **project assignments** (visibility.ts) — the rep sees only their assigned-project visits, server-enforced; cross-org visits 404-ghost (pinned by permission-matrix).
- **Dashboard (Phase 9 addition)**: the «Terrain» KPI row — `fieldPendingReports` (SCHEDULED/CONFIRMED past-slot visits = execution+report overdue), `fieldCompletedVisits` (windowed), `fieldRescheduleRequests` (awaitingCustomerReconfirm in scope). Live values browser-verified: 1 / 5 / 1 on the seed census.
- **Agenda (Terrain workspace)**: TODAY / NEXT / HISTORY groups; per-card unit chips, consignes, one-tap Maps navigation, CONFIRMER (assignment-gated), and «Démarrer le compte-rendu» (the execution sheet).

## 2. The execution sheet (mobile-first contract)

- Client block: name, project, follow-up agent, date/duration, units, consignes — the **minimum required client information** (no contact details beyond the fiche's scoped fields).
- **Checklist** (local guide, never persisted, never gates): Arrivé(e) sur site · Bien présenté · Questions traitées.
- **Issue actions**: Absence client (NO_SHOW) · Annuler (CANCELLED) · Demander une replanification (counter-proposal discipline).
- **Report contract** (server-validated, server-stamped): interestLevel (4-value enum) + reportNotes (20–5000) + followUpRequired + nextAction (P9: was dead schema, now wired) — `reportedById/reportedAt` stripped from client payloads and stamped from the session; IMMUTABLE after submission (422 VISIT_REPORT_IMMUTABLE — pinned).
- **Photos / pièces jointes (Phase 9 — the disclosed Phase 8 gap, closed)**: the EntityDocuments mount with entityType=VISIT — category «Photo de visite» (VISIT_PHOTO), 8 MB cap, PDF/PNG/JPG/WEBP magic-byte whitelist, uploader identity + timestamp recorded. Browser-verified live upload: «Façade résidence · p9-visit-photo.png · 67 B · Par Mounia Larbi · cette minute-ci».

## 3. The visit state machine (with the Phase 9 authority completion)

| Transition | Authority | Guards |
|---|---|---|
| SCHEDULED→CONFIRMED | assigned field rep (canConfirmVisit) ∨ MANAGER+ | presence stamps; final-date move allowed |
| CONFIRMED→SCHEDULED (reset) | MANAGER+ only | unwinds stamps; audited |
| →COMPLETED | report authority (assigned rep ∨ visit.agent ∨ lead.owner ∨ MANAGER+) | outcome + atomic report contract; auto FOLLOW_UP task (due report+24h, P9 law); report immutable |
| →NO_SHOW / →CANCELLED / SCHEDULED→RESCHEDULED | **P9-D03: same report-authority predicate** (was UNGATED — any in-scope user could terminally alter another actor's visit) | 403 VISIT_OUTCOME_FORBIDDEN otherwise |
| SCHEDULED→REJECTED | canConfirmVisit ∨ MANAGER+ | reason 3–500, immutable |
| counter-proposal | canConfirmVisit | awaitingCustomerReconfirm; proposedAt frozen |
| customer reconfirm | visit.agent ∨ MANAGER+ | clears flag only when pending |

Every transition validates: current state (matrix, 422) · authenticated user · assignment · role permission · allowed next state · required fields · timestamp and actor (stamps + Activity(VISIT) + audit on the management acts).

## 4. POST idempotency (P9-D12)

`POST /api/visits` now carries the payments-fingerprint law: identical (org, lead, scheduledAt, resolved agent) within 60 s → 409 VISIT_DUPLICATE (pinned). Client retries can no longer mint duplicate visits + duplicate «Visite planifiée» activities.

## 5. Storage honesty (the disclosed limitation)

Visit photos persist to `db/docs/` — the same disk class as the SQLite database itself. This is the maximum durability the environment offers; there is no object storage in scope. Files are ≤8 MB, sniffed, sanitized, org-scoped, and egress-audited. The limitation (sandbox reset hazard affects DB and docs identically) is documented, not hidden.
