# ASAS UI/UX PLATFORM TRANSFORMATION — Program of Record

**Mandate:** "ASAS — AUTONOMOUS ENTERPRISE PLATFORM ENGINEERING MASTER PROMPT" (37-§, 2026-10-08 — the user's authoritative platform mandate; supersedes `ASAS_UI_UX_TRANSFORMATION.md` as the active program doc, which stays as the Phase-13 record).
**Status:** Phase 15 COMPLETE (2026-10-08) — SAV integration closure: the after-sales domain is now reachable from the global palette (scoped search + cockpit deep-link), declarable from Inventory (unit-preset flow), and measured in Analytics (attention metrics + category ramp). Phases 1–14 remain the foundation; see §4.6.
**Role of this file:** the consolidated map for THIS mandate cycle: verified architecture snapshot → gap analysis → program → operating cadence → roadmap. It does NOT duplicate the specialist docs — `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/DESIGN_SYSTEM.md` (binding visual laws), `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/AUTHORIZATION_MODEL.md` (binding authorization laws), `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_STATE.md` (phase history), `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md` (D-021/D-022/D-023) remain the detail owners. Updated as implementation progresses (mandate §6).

---

## 1. Current architecture (verified this session — 2026-10-08, P14-0 forensic)

- **Stack:** Next.js 16 App Router · React 19 · TS strict · Tailwind 4 + shadcn/ui · Prisma/SQLite (migrations-based, 6 applied incl. `p14_sav_cases`) · react-query · zustand. Single `/` route; **10 views** via zustand hash routing (`#/view`); **59 API route files**, no server actions.
- **Route invariant (binding, AGENTS.md §23-1):** `requireUser(role?)` → zod `parseBody` → visibility-scoped Prisma (D-021 composition law) → side effects (`logActivity` + `logAudit`) → `ok()/fail()`.
- **Authorization:** role-rank RBAC (OWNER>ADMIN>MANAGER>SALES_AGENT>MARKETING/ACCOUNTING/OPERATIONS) + record-level visibility (D-021 OWN+POOL ∨ ORG) + finance money-laws (D-022) + SAV lifecycle-laws (D-023) — all through ONE primitive `src/lib/server/visibility.ts`; §40 matrix (`tmp-scripts/p12-visibility-matrix.ts`) = the permanent regression guard, **65/65**.
- **Design system:** semantic type scale, attention-tier + neutral-ladder tokens, icon vocabulary, motion catalog, elevation ramp, density control, shimmer skeletons. Premium laws: two-tier metric law (D-UX-015), hover = border/bg shift, no blue/indigo, restraint > decoration.
- **i18n:** 19 domain modules (~1170 keys × fr/en/ar), RTL hardened (logical properties, DirectionProvider, bidi isolation).
- **Maturity:** Phases 1–13 complete (CRM lifecycle, pipeline kanban, inventory radar, matching, visits calendar, tasks, analytics, audit, settings, import/export, copilot, WIP limits, week view, finance/collections).

## 2. Operating cadence — MANUAL (replaces ALL scheduled automation)

The user terminated the long-term scheduled automation (re-confirmed 2026-10-08): cron job 443511 (15-min `webDevReview`) is dead — disabled by scheduler exec limits — and **no scheduled review automation exists or may be created/re-enabled absent an explicit user instruction**. The former cron's duties are folded into the interactive-session workflow (this is now the standing law):

1. **Session-open health gates** (AGENTS.md first-visit checklist): lint + tsc + `curl /` + DB user count (R13 recovery: secret re-append → `db:seed`) + git status.
2. **Per-change validation** — the 5-gate protocol (TEST_STRATEGY) + the authorization matrix run; never trust "compiles" as "works".
3. **Visual QA after UI work** — agent-browser E2E (FR + AR RTL + dark + mobile 390) + VLM review with DOM/pixel verification of every claim (P6/P14 precedent: VLM claims get measured before they get believed).
4. **Continuation discipline** — each session picks the highest-value safe item from MASTER_ENGINEERING_ROADMAP, implements, validates, appends the worklog, commits conventionally. The worklog tail is the ONLY reliable inter-session record.
5. **Styling-detail + feature-growth** happen as roadmap increments on the main path — never as disconnected cosmetic one-offs (mandate §8 relationship set).

## 3. Forensic findings — mandate vs repository (gap analysis, 2026-10-08)

| Mandate requirement | Repository state | Verdict |
|---|---|---|
| §7 PHASE 0–6 (discover, IA, design system, shell, CRM, sales, inventory) | Complete (P2–P9, V1.9) — role-aware shell/nav/palette, enterprise tables, premium workspace | ✅ closed |
| §7 PHASE 7 Finance · §9 Finance IA · §17 CEO collections | Complete (P13/D-022) — échéanciers, collections workspace, dashboard attention | ✅ closed |
| §7 PHASE 8 Executive command center | Complete (P12 role-aware dashboard + analytics MANAGER+) | ✅ closed |
| §7 PHASE 9/10 hardening | Continuous (a11y/RTL sweeps P6-8/P7-3/P9, security F-01..F-15; deployment items gated on explicit instruction) | ✅ acceptable (env-gated tails documented) |
| §26 testing | Protocol-based (5 gates + 65/65 matrix); CI promotion environment-gated (R3) | ⚠️ environment-gated |
| **§7 lifecycle tail "→ Delivery → SAV" · §9 SAV IA ("Cases, Requests, Status, Assignments, Resolution")** | **ABSENT at P13 close** (deferred scope cut, STATE §13/§14 candidate #3) — no SAV model/routes/workspace/nav; the mandate explicitly includes SAV → the product decision is resolved by the mandate itself | ❌ **THE GAP — Phase 14 (D-023)** |

**Delivery (the step before SAV):** already represented by `Project.deliveryDate` + `PROJECT_STATUSES.DELIVERED` + `Installment.kind=DELIVERY` — a dedicated delivery-tracking domain stays a documented scope cut (no product signal beyond these fields; revisit only on user instruction).

## 4. Phase 14 program — SAV / after-sales domain (D-023)

**Product shape:** one `SavCase` = one client request on a sold/delivered unit (or common areas) — declared by ANY role (intake), claimed by any authenticated user when unassigned (triage self-service), progressed/resolved by the assignee or MANAGER+, closed/cancelled and re-assigned by MANAGER+ only. The workspace answers the mandate §17 questions for after-sales: *what is late, what is unhandled, who owns what, what was fixed.*

### 4.1 Data model (migration `p14_sav_cases`)

- `SavCase` — `orgId`, `seq` (org-wide, unique — human ref "SAV-{n}"), `title`, `category` (PLUMBING | ELECTRICAL | MASONRY | JOINERY | PAINT | ELEVATOR | COMMON_AREAS | WATERPROOFING | OTHER), `priority` (PRIORITIES), `status` (OPEN | IN_PROGRESS | RESOLVED | CLOSED | CANCELLED), `description`, `resolution?`, `leadId?`/`reservationId?`/`apartmentId?` (the sale chain), `assigneeId?`, `createdById?`, `reportedAt`, `dueAt?` (SLA), `resolvedAt?`, `closedAt?`. Indexes: `[orgId,seq]` unique, `[orgId,status]`, `[orgId,assigneeId,status]`, `[orgId,dueAt]`, `[apartmentId]`, `[leadId]`.
- `Activity.savCaseId` (nullable FK) — SAV events join the unified timeline (dual-linked: case + lead when the client is known).

### 4.2 Binding laws (D-023)

1. **Derived-overdue** (D-022 law-1 spirit): OVERDUE is never stored — `open work ∧ dueAt < now`; no state can rot.
2. **Lifecycle is server-enforced** — `SAV_STATUS_TRANSITIONS` with 422 + audit on violations; CLOSED/CANCELLED are terminal and immutable (409); → RESOLVED requires resolution text (422 RESOLUTION_REQUIRED) and stamps `resolvedAt`; reopen clears it (audit keeps history).
3. **Intake is everyone's work; assignment is management work** — POST is role-open (assignment field honored for MANAGER+ only, else 403); any authenticated user may CLAIM an unassigned case (`{assigneeId: self}` on `assigneeId === null`); any other assignment change requires MANAGER+.
4. **Acting rights** — status/content mutations: the case's assignee or MANAGER+ (a below-MANAGER non-assignee can VIEW in scope but not act → 403 SAV_CASE_NOT_ASSIGNEE).
5. **Closure is management confirmation** — CLOSED and CANCELLED transitions are MANAGER+-only (the client-confirmation step).
6. **Visibility** — `savScope(user) = assignee ∨ creator ∨ unassigned intake ∨ own+pool clients` below MANAGER; ORG at MANAGER+. The unassigned intake is deliberately shared (OWN+POOL philosophy — stranding walk-in reports would be the F-01 class of cruelty). AND-composition law applies (matrix S2 regression-guards).
7. **Audit + timeline** — SAV_CASE_CREATED/UPDATED/STATUS_CHANGED/ASSIGNED audits (entity SAV_CASE); SAV activity type (19th) on create/claim/progress/resolve/close/cancel, dual-linked to the client's lead timeline.

### 4.3 API surface (2 route files + 1 touched)

| Route | Methods | Law |
|---|---|---|
| `/api/sav` | GET (scoped list + scoped KPIs: open/overdue/unassigned/resolved/closed + buckets overdue/unassigned/open/inprogress/resolved/closed + AND-composed search), POST (any role; reference guards; tx seq) | conditions-array composition |
| `/api/sav/[id]` | GET (scoped detail + 50-event timeline), PATCH (status transitions, assignment/claim, content edits) | scoped findFirst → 404 ghost-identical; laws 2–5 |
| `/api/dashboard` (touched) | `sav` block `{open, overdue, unassigned}` — **scoped for ALL roles** (after-sales is not management-only; agents track their own clients) → sidebar amber badge; the three dashboard attention cards stay untouched (P13 VLM-verified layout) | management-block pattern inverted |

### 4.4 UI — the `sav` workspace (nav Opérations, all roles)

- Attention tier (D-UX-015): Dossiers en retard (rose, deep-link) + Non affectés (amber, deep-link) + all-clear zone that never disappears.
- Context tier: one receding row (Ouverts · Résolus · Clôturés).
- Bucket chips + text search + count + the ONE filled primary (Déclarer un dossier — the view's own action; the global lead CTA demotes to outline, D-UX-030).
- Enterprise zebra table (SAV-n mono ref · category icon + title/category · client deep-link · unit · PriorityBadge · assignee · SLA date rose-when-overdue · status badge + derived overdue chip · claim/progress + ⋯) + mobile transformed list twin.
- Declare dialog (reservation picker adopts client+unit links; standalone for common areas) · detail cockpit (facts grid, description/resolution, SAV timeline, contextual lifecycle actions, MANAGER+ assign select + cancel AlertDialog, resolve flow with required-text progressive disclosure).
- i18n: `domains/sav.ts` (~70 keys) + `sav.status/category` enums + audit actions/entity + `nav.sav` + `activity.sav` — ALL THREE languages. En route: fixed the latent P13 gap — `activity.payment` label key was missing (timeline showed the raw key).

### 4.5 Seed

`seedSavCases(db, org)` — idempotent: 9 cases on the won-deal clients (OPEN ×3 incl. 2 overdue · IN_PROGRESS ×3 · RESOLVED · CLOSED · CANCELLED), assigned/unassigned mixes, backdated SAV activities (15).

### 4.6 Phase 15 — SAV integration closure (roadmap §7 item 2, executed)

The P14 domain was an island reachable only through its nav entry. P15 wires it into the platform's other three reachability surfaces — search, inventory, analytics — with the same laws (no new model, no new dependency, D-021 everywhere):

1. **Palette search entity** — `/api/search` gains `savCases` (savScope AND-composed like leads — never spread next to the route's OR); matches: title / client name / unit code / the human ref (`SAV-3`, `sav 3` — a bare number does NOT match seq: noise, not signal). Selecting a hit = deep-link: new store primitive `openSavCase(id)` (in-memory `savFocusId`, hash → `#/sav`) consumed by SavView as DERIVED state (`focusedRow` from the scoped list; a by-id react-query fallback bridges the list-load gap — same cache key as the cockpit's own query, ghost-identical 404 for foreign ids → no dialog). Palette group "Dossiers SAV" wears the nav's Wrench glyph (icon-vocabulary `savCase` — one concept, one glyph).
2. **Inventory → SAV** — apartment detail gains "Déclarer un dossier" as the status-appropriate filled primary for SOLD/RESERVED units (intake is every role's work, D-023 law 3). `SavCreateDialog` accepts `presetApartment {id, code}`: a unit-context chip ("Dossier rattaché à l'unité V-02") + the unit's reservation auto-selected via DERIVED-with-override state (`userReservationId ?? presetMatch` — no effect, lint law honored); a unitless submit still anchors via `apartmentId` (already guarded server-side since P14).
3. **Analytics SAV block** — `/api/analytics` gains `sav`: open / overdue / unassigned / resolved / closed counts (derived-overdue preserved in-query), declared-in-window, avg resolution days, byCategory distribution. The view renders `SavPanel` in the right column stack (after StageDurations): four mini-metrics (overdue rose / unassigned amber when non-zero) + category bars indexed on the D-UX-034 categorical ramp by CANONICAL `SAV_CATEGORIES` order (never by rank) + the quiet "Ouvrir l'espace SAV" deep-link. Mutations invalidate `analytics` alongside `sav`/`dashboard`.
4. **Gap fix (P13-class, found in passing)** — `/api/search` never selected `leadId` on contacts, so the palette's contact → lead deep-link was silently dead since P9.5; now selected and live.

**Validation (executed):** lint 0 · tsc 0 src/ · matrix **65/65** (search-route change guarded) · API probes: title/ref match modes, agent-scope leak probes (foreign SAV-3/6 invisible to agent, own/shared visible), analytics 403 for agent intact · browser E2E: palette → deep-link → cockpit; SOLD unit → declare → SAV-10 created linked (unit V-02 + client + contract ACTE-2026-0387) with audit + timeline + live analytics invalidation; AR RTL palette/view/panel; mobile 390 (2px doc-scroll artifact pre-exists on untouched dashboard — no visible offender, documented) · residue zero (SAV-10 + activity + audit removed; counts back to 9/15/0). Known pre-existing (NOT introduced): Radix Select placeholder-pattern uncontrolled→controlled console warning, fires identically in the untouched P14 flow on user pick.

## 5. Migration & compatibility strategy

Additive only: new model + Activity nullable column + new routes + new view + nullable dashboard `sav` key. No existing route contract changed. No new dependencies. No blue/indigo.

## 6. Validation record (executed 2026-10-08)

- Static: lint 0 · tsc 0 src/ · `GET /` 200 (server restarted clean after the migration — Turbopack stale-module law).
- Ops catch ×1: the environment-restored DB had lost migration bookkeeping (R13 class) → `migrate dev` demanded a reset → clean path executed: reset (replay 5 migrations + seed) → `p14_sav_cases` created → reset again with the SAV seed. Lesson: after an R13 wipe, verify `migrate status` BEFORE seeding, not after.
- Matrix **65/65 PASS** (13 new SAV probes: S1 scoped list 0 foreign (unassigned intake correctly shared) · S2 search AND-composition zero-foreign · S3 org-wide 9 + overdue KPI 2 · S4 self-claim 200 · S5 assign-to-other 403 · S6 foreign progress 403 · S7 invalid transition 422 · S8 resolve-without-text 422 · S8b foreign detail 404 · S9 create 201 · exact-state cleanup).
- Browser E2E: manager full lifecycle through the UI (claim → traiter → résoudre w/ required text → clôturer — CLOSED verified via API after a stale-ref click miss, honestly logged), toast + row updates + badge live; agent: 6 scoped rows, 3 claim buttons, no Annuler/assign (403 class), 0 console errors; AR RTL desktop + dark + mobile 390 transformed list; FR light.
- VLM 4-surface review: hierarchy/table/restraint/typography PASS; **one accepted-and-fixed finding** (title `…` truncation discoverability → `title` attr hover) and **three claims rejected with evidence** (stock SelectTrigger ≠ disabled; SVG icons misread as "emoji decoration"; mobile touch targets covered by the `.crm-hit` ≥44px law). QA lesson banked: a `td.scrollHeight` probe in AR reports +6px "overflow" caused by the sr-only span's intentionally-clipped Arabic line box — NOT a visual defect; rect-probe verified zero visible overflows (applied `leading-none` hardening + documented in both tables).
- Residue: zero — SAV-2 restored to exact seed state (9 cases / 15 activities / 0 audits).

## 7. Roadmap (post-Phase-16, priority order)

1. R5/R6 product-owner data decisions (7 legacy held apartments · Larbaoui duplicate) — decision boundary, surfaced.
2. Arabic micro-copy human review (owner).
3. R3 test-harness promotion (environment-gated; the protocol + 52/52 matrix is the interim guard).
4. Deployment preparation (explicit instruction only; PRODUCTION_READINESS gate order).
5. Small polish backlog (documented, non-blocking): Radix Select placeholder warning (benign, fires on first pick). ~~login-overlay brand footer says v1.0 while shell says v1.9~~ — FIXED P16 (v1.9 + email autoFocus).

## Change log

- 2026-10-08 — created (P14-0 forensic refresh + gap analysis; operating cadence §2 recorded per the user's automation-termination instruction; Phase 14 program defined).
- 2026-10-08 — **Phase 14 COMPLETE**: migration `p14_sav_cases` (SavCase + Activity.savCaseId) + 2 routes + dashboard `sav` block + `sav` workspace (attention/context tiers, table + mobile twin, declare + detail dialogs) + nav (all roles, amber overdue badge) + i18n `domains/sav.ts` ×3 (+ enums/audit/nav/activity keys + the `activity.payment` P13 gap fix) + seed 9 cases. Matrix **65/65**, browser E2E both roles + full lifecycle, AR RTL/dark/mobile, VLM reviewed (1 accepted fix, 3 rejections with evidence), residue zero. Laws in D-023.
- 2026-10-08 — **Phase 15 COMPLETE** (SAV integration closure): palette search entity + `openSavCase` deep-link · Inventory→SAV declare with unit preset · analytics `sav` block + SavPanel · contact-leadId gap fix. Matrix **65/65**, browser E2E (deep-link, declare-from-inventory with audit/timeline/invalidations, AR RTL, mobile 390), residue zero. No schema change, no new dependency. Details §4.6.
- 2026-10-08 — **Phase 16 COMPLETE — SAV domain REMOVED (D-024, user product decision: "non-essential addition and no meaning in our system")**: migration `p16_remove_sav` (data+DDL in one — DELETE SAV activity/audit rows, DROP SavCase, Activity rebuild without savCaseId) · 8 SAV-only files deleted + 16 shared files surgically reverted (store/shell/nav/palette/icon-vocabulary/apartment-dialog/analytics/dashboard+search+analytics routes/visibility/audit/constants/types/seed) · i18n −93 lines ×3 langs · matrix re-baselined **52/52** · login polish (v1.9 footer contradiction + email autoFocus) · E2E full sweep (login credentials + demo + logout, all views, AR RTL, mobile 390) 0 console errors. D-023 superseded; the program's platform scope is now exactly the sales lifecycle.
