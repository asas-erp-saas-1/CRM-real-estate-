# ASAS CRM — Owner-UI Workflow Continuation Plan

**Origin**: user directive 2026-10-18 — «Review all previous owner-related user interface work and look for any errors, shortcomings, incomplete work, or unfinished workflows, and include them in a workflow continuation plan.»
**Method**: verify-then-work — static code audit (all OWNER-gated routes/APIs/components enumerated) + live agent-browser walkthrough AS the OWNER persona (Nadia Benali, Président · CEO) across every owner surface, console watched throughout. Guards at close: business baseline byte-exact `8/43/21/23/161/46/3/8/4/18` · lint 0 · console 0 on every surface · DB queries read-only.

---

> ## ✅ PLAN CLOSED — 2026-10-18 (the user's «Complete your work on the path and on the plan»)
>
> **W1 → P46 DONE & VERIFIED** (D-UX-057 — «Décisions en attente»: the §38 decision backlog surfaced end-to-end — attention cell + queue + bell; matrix 195/195 ×3).
> **W2 → P47 DONE & VERIFIED** (D-UX-058 — «Holds hérités»: the R5 legacy-holds surface + the live-caught apartment-PATCH RBAC hardening; matrix 200/200 ×3).
> **W3 → P48 DONE & VERIFIED** (D-UX-059 — the CommissionsPanel range + open-deal affordance + the compact-panel law; matrix 203/203 ×3).
> **W4 = the standing register rows** (R5's human decision — now one card away · Arabic micro-copy review · deployment on explicit instruction).
>
> Cumulative guard line: matrix 192→**203** · all three rounds residue byte-exact · console 0 · evidence qa-p46/ qa-p47/ qa-p48/ (×14 captures).

---

## 1. Audit inventory — previous owner-related UI work, reviewed live

| Surface | Built in | Live verdict (as OWNER) |
|---|---|---|
| Dashboard — CommissionsPanel (agency money, MANAGER+) | P18/D-025 | ✅ renders 1.8M DA + 4 entries (name · project · source chip · amount, truncation-disclosed per D-UX-051) |
| Dashboard — IncentivesPanel (rep money) | P18/D-025 | ✅ renders (verified in prior phases as rep; owner view nulled by design) |
| Dashboard — attention strip (uncontacted · overdueTasks · unstaffedVisits) | P8/D-015 + P20-C/D-028 | ✅ 3 cells live, null-gated rank discipline intact |
| Settings → Team & accès (R8-2): table, inline role Select, active Switch, reset-password AlertDialog, temp-password dialog, add-member dialog | R8-2 + P2-R1 | ✅ 8 members rendered; **ROLE_CEILING verified live** — as OWNER all 5 roles offered (Président · CEO … Représentant terrain); self-row switch disabled (self-lockout); create button disabled-until-valid |
| ROLE_CEILING / LAST_OWNER server guards | P20-C/P2-R1 F-07 | ✅ code-verified (`actor.role === "ADMIN" && body.role === "OWNER"` → 403; last-active-OWNER → 400) |
| Deal economics (§37 ladder + §38 machine + rebase escape) | P18/D-025 + P29/D-037 | ✅ live on the Sofiane deal: commission 1 160 000 · incentive 290 000 (agent name inline) · basis consigned · PENDING → «Approuvée/Rejetée» forward edges offered · decidedBy stamps render |
| Apartment status editor (force + audit) | P4 | ✅ live on A-21: combobox offers all 7 statuses; RESERVED→AVAILABLE path exists for MANAGER+ |
| Reverse-matching demand panel (the backfill path) | P24/D-032 | ✅ live on A-21: «3 prospect(s) correspondant(s)» + «Ouvrir le prospect» |
| Visits decision ladders + §17.3 no-rep chip | P20/D-026–028 | ✅ «Confirmer sur place» ladders + «Aucun représentant terrain» chip render |
| Audit view (filters + CHANGEMENTS chip system) | P6+ | ✅ entity/actor comboboxes + table render |
| Analytics (funnel + team performance) | P9+ | ✅ renders, console 0 |
| Notifications bell (5 groups) | P5+ | ✅ overdue / today-visits / today-tasks / tomorrow-visits / uncontacted all live |
| Export bundle (P7-4) | P7-4 | ✅ button fires, toast feedback wired (success with row count / 403 forbidden), console 0 |
| Keyboard focus contract (D-UX-056) | P45 | ✅ verified last phase on all modal surfaces |

**No errors found**: zero console errors/warnings across every owner surface; no broken interactions in the walkthrough; no dead routes in owner territory (D-042 scan clean).

---

## 2. Findings — shortcomings / incomplete / unfinished workflows

### F1 (HIGH — unfinished workflow): §38 incentive decision backlog is invisible to the OWNER
- **Live facts**: 3 PENDING incentives sit in the DB awaiting a MANAGER+ decision — H-31 (290 000 DA, the Sofiane ACTIVE hold) · A-01 (87 500 DA) · B-01 (59 000 DA). The per-deal approval machine is complete and live-verified.
- **The gap**: no attention-strip cell, no notification-bell group, no CommissionsPanel section, no queue/filter surface anywhere lists them. The OWNER discovers pending approvals only by opening each of the 46 opportunity dialogs one by one.
- **Why it matters**: the dashboard's own law (D-UX-015) says the attention tier is «what requires my attention right now». A decision backlog is precisely that. The §38 machine is complete; the **workflow layer above it** (knowing where decisions await) was never built.

### F2 (HIGH — unfinished workflow): R5 legacy orphan holds have no OWNER-facing decision surface
- **Live facts**: exactly 7 apartments are held with ZERO reservation rows — A-21 (RESERVED) · A-31 (OPTIONED) · B-11 (RESERVED) · H-12 (RESERVED) · H-21 (OPTIONED) · N-11 (RESERVED) · V-03 (RESERVED) — the pre-CRM legacy data (R5, owner-gated product decision since the register's origin; re-verified at P34).
- **The gap**: the release capability exists (per-apartment status combobox + force + audit) and the backfill path exists (P24 reverse-matching panel) — but nothing aggregates the 7, nothing signals them, and the per-dialog line «Aucune réservation active pour cet appartement» reads as a data inconsistency, not as a pending owner decision. The holds are scattered across 3+ projects; finding them is archaeology, not workflow.
- **Register law respected**: R5 must NOT be auto-resolved (release vs backfill is the human owner's call). The platform's job is to **surface** the decision, not make it.

### F3 (MEDIUM — shortcoming): CommissionsPanel is month-locked and link-less
- The API computes commissions on the calendar month (`monthStart/monthEnd`) regardless of the dashboard's global period selector (which drives KPIs/funnel/sourcePerformance). The panel title honestly says «du mois», so this is not dishonest — but the owner cannot see commissions over the selected period.
- Entries are static rows: no «open this deal» affordance from the money panel to the opportunity dialog (take: 6, no see-all).

### F4 (verified-by-design, recorded): expiring reservations live in the bell only
- The attention strip (3 cells) deliberately does not graduate expiring reservations; the bell carries them (API verified live: ACTIVE + expiry-window query at every `/api/notifications` poll). Two-tier design per D-UX-015 — not a defect.

---

## 3. Workflow continuation plan (the execution register)

> Priority order = user-visible decision value first. Every item follows the house laws: matrix 192/192 before/after · i18n ×3 · audit actions on mutations · D-UX decision entries · R23 commit-at-close.

### W1 → Phase P46: «Décisions en attente» — the owner's decision backlog surface (closes F1) — **DONE & VERIFIED (2026-10-18, D-UX-057; matrix 195/195 ×3)**
- **W1a — dashboard API**: `pendingIncentives` MANAGER+ KPI (null below MANAGER, like `unstaffedVisits`): count + total DA over reservations with `incentiveStatus: PENDING` + `agentIncentive != null`, with per-row refs (deal title, agent, apartment code) for the queue.
- **W1b — attention cell**: 4th cell in the strip (amber tier — money awaiting a human decision), deep-linking to the queue surface.
- **W1c — queue surface**: a compact «N primes en attente de décision» section under the CommissionsPanel (right rail, the management cockpit's own rail) listing each pending incentive with an open-deal affordance → the existing §38 machine in the opportunity dialog. No new mutation surface — W1 is a read/waypoint layer only; decisions still land through the audited PATCH.
- **W1d — bell group**: notifications group «N primes en attente de décision» (MANAGER+ only).
- Guards: D-UX decision entry (the attention-tier placement + the money-as-attention-tone question — attn-2 amber, never emerald-good-news); key-neutral i18n check; matrix probes for the KPI (PENDING count as OWNER vs agent scope).

### W2 → Phase P47: «Holds hérités» — the R5 owner decision surface (closes F2) — **DONE & VERIFIED (2026-10-18, D-UX-058; matrix 200/200 ×3; + the live-caught apartment-PATCH RBAC hardening)**
- **W2a — inventory segment**: a quiet card/segment in the Inventory view enumerating orphan-held units (held status ∧ no ACTIVE reservation — the derived predicate, no schema change), each row: unit code · project · held status · two affordances — «Libérer» (existing status→AVAILABLE force+audit path, AlertDialog confirm) and «Ouvrir» (apartment dialog → P24 reverse-matching prospects for backfill).
- **W2b — per-dialog legacy marker**: the «Aucune réservation active» line on a held apartment gains the legacy-hold explanation («Hold hérité — décision propriétaire : libérer ou requalifier»), so the state reads as a decision, not an inconsistency.
- **W2c — law entry**: R5 stays `[owner]`-gated — the surface presents, never decides; the seed's 7 holds stay untouched unless the owner acts. D-UX decision + register row amendment (R5: "surfaced in-UI P47, decision still owner-gated").
- Guards: matrix probe (the orphan predicate under each role); audit action for release already exists (APARTMENT_STATUS_CHANGED w/ force receipt); AR-RTL + 390 sweep on the new segment.

### W3 → Phase P48: CommissionsPanel completion (closes F3, polish tier) — **DONE & VERIFIED (2026-10-18, D-UX-059; matrix 203/203 ×3)**
- **W3a**: honor the dashboard `range` param in the commissions query (title follows the selected period honestly) or document the month-lock as the compact-panel law.
- **W3b**: per-entry open-deal affordance (the row deep-links the opportunity dialog).
- **W3c**: consider a see-all affordance beyond `take: 6` (or record the compact law).

### W4 — standing register rows (unchanged, explicit instruction only)
- R5 decision itself (W2 surfaces it; the human owner decides) · Arabic micro-copy human review `[owner]` · deployment on explicit instruction · P39/P40 lost artifacts (mockup library regen / competitor teardown — image-gen cost).

---

## 4. Evidence
- `download/qa-owner-audit/` — 01-dashboard-owner.png · 02-analytics-owner.png · 03-leads-owner.png
- Live transcripts in session record: ROLE_OPTIONS full-set as OWNER · A-21 dialog («Aucune réservation active» + 7-status combobox + 3 matching prospects) · Sofiane deal economics (PENDING→Approuvée/Rejetée) · notifications 5 groups · team table 8 rows.
- DB witness (read-only): PENDING incentives ×3 · orphan holds ×7 · business baseline byte-exact.
