# TEST & VALIDATION STRATEGY

## Sandbox reality (load-bearing constraints)
`bun run build` is FORBIDDEN. No test framework installed. Dev server (port 3000) is the runtime under test. Therefore validation is a **protocol**, not a suite — run it after EVERY meaningful change. Never claim "works" without running the relevant gate.

## The protocol (per change)

### Gate 1 — Static
```bash
bun run lint          # exit 0
bunx tsc --noEmit     # 0 errors in src/ (examples/+skills/ pre-existing are tolerated); tmp-scripts must stay clean
```

### Gate 2 — Server health
`GET /` → 200 · `tail dev.log` → no compile errors, no unexpected 500s · after `bun run db:push`: RESTART dev server (kill next/bun; `(setsid nohup bun run dev > /dev/null 2>&1 &)`) — stale Prisma client causes 500s (R10-4 evidence) — then re-hit one API route.

### Gate 3 — API (curl matrix, auth-ready)
```bash
curl -s -c ck -X POST localhost:3000/api/auth/login -H 'Content-Type: application/json' -d '{"email":"sarah@asas.dz","password":"asas1234"}'
# then with -b ck: hit the changed route(s) happy path + edge cases (404 fabricated cuid, 422 bad body, 403 role if RBAC touched, pagination clamps)
```
Security-sensitive changes additionally require the forged-cookie probes (raw id → 401; wrong-sig → 401) — see SECURITY_HARDENING.md.

### Gate 4 — E2E (agent-browser)
Login (overlay or sarah/asas1234) → exercise the changed view(s) → `window.__errs` (error + unhandledrejection listeners installed on load) must stay 0 → mobile 390×844 scrollWidth=390 → AR/RTL flip → restore 1440×900 FR #/dashboard.
Known automation artifacts (NOT app bugs): `fill ""` desyncs React inputs (clear via type+Backspace); Radix controls need `find role … click --name …`; hover styles media-gated off.

### Gate 5 — Residue audit
Any test data created (leads/tasks/visits/activities/audits) must be reverted via a tmp-scripts/*.ts cleanup (identify by createdAt window + ids); DB counts back to baseline; report exact restores in the worklog entry.

### Gate 6 — Fault injection (G5-P3-5, §41 — transactional-integrity changes)
Any change that folds mutation + Activity/Audit writes into one `$transaction` (or adds a new multi-write surface) must prove the rollback contract through the public HTTP surface, not by code reading:
- **Mechanism**: `src/lib/server/faults.ts` — `injectTxFault(req, stage)` throws `500 FAULT_INJECTED` AFTER the primary mutation, INSIDE the transaction. Two independent gates: `NODE_ENV === "production"` short-circuits (zero live surface) and the explicit `x-test-inject: <stage>` header must match the call site's stage EXACTLY (an unknown stage is a no-op — probed, FR41aa).
- **Probe pattern (matrix §41)**: per surface, TWO probes — (1) the call with the header → 500 + verify NOTHING landed (primary row unchanged, 0 Activity, 0 Audit); (2) the same call without → 200/201 + mutation + trail committed together with exact counts. Filesystem-backed surfaces (documents) additionally verify disk/DB agreement: the compensated file is gone after a forced failure, +1 after success.
- **Append-only law preserved**: production code never deletes audit rows; only the matrix's scratch cleanups do (the sanctioned QA exception since P12). LOGIN audits persist across runs BY DESIGN — the audit count grows ~+12/matrix-run; the 10-count baseline (worklog byte-exact contract) excludes audit.

### Gate 7 — State-machine changes (G5-P3-7, §42 — adjacency-matrix/law-table changes)
Any change that adds or edits a transition/lifecycle law table (`VISIT_TRANSITIONS` · `LEAD_TRANSITIONS` · `OPPORTUNITY_TRANSITIONS` · `RESERVATION_LIFECYCLE`) must prove BOTH the table's own laws and every behavioral class through the public HTTP surface:
- **Structural probes first** (the FR37e recomputation pattern): assert the table's documented invariants directly against the constants — terminal rows empty, reachability (CLOSED_LOST from every working state), forward-only ordering, dedicated-flow exclusions (CONVERTED/CLOSED_WON in no row). The constants ARE the law table; drift between doc and table fails here.
- **Per-class behavioral probes** (matrix §42 pattern): agent illegal edge → 422 + unchanged · authority without reason → 422 · authority with reason → 200 + the dedicated `*_CORRECTED` audit row CARRYING the reason (JSON.parse the `after` string) · routine forward edges stay 200 with the routine audit row (no approval ceremony) · bulk actions touch only matrix-eligible rows · the desync laws (sale-backed terminal reopens refused).
- **UI companions verified in-browser**: the filtered menu (below authority: no illegal edges offered), the correction reason dialog (authority: dialog → reason → re-send → toast + timeline entry), the honest refusal toast (below authority on error-driven surfaces).

## Regression checklist (weekly / per-phase)
1. 9 views render FR desktop (zero console errors) + 390 mobile + AR RTL (scrollWidth checks).
2. Auth cycle: logout → overlay → wrong password (Alert) → credentials → app boots.
3. RBAC sample: Sarah sees team read-only; Yacine GET /api/targets = own row only.
4. Booking: concurrent reservation POST → 409; expiry sweeper idempotent on notifications GET.
5. Dashboard ranges: 7d/30d/90d/all differ where data supports; targets ring renders.
6. LLM/VLM: first check gateway health (`bun run tmp-scripts/…` pattern z-ai create) — if down, verify graceful UI degradation only.

## Roadmap (Ph4/5)
Vitest unit layer (lib/ pure functions: phone, csv, validation, matching) → supertest-style API contract tests against a seeded throwaway DB → Playwright smoke of the 9-view sweep → GitHub Actions (lint + tsc + tests). Add ONLY when `bun run build`/CI become available in the environment.
