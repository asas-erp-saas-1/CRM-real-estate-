# TECHNICAL DEBT (categorized)

Current-state ledger (reconciled post-Phase-6 / P7-1).
Origins: P2-a/b/c/d audits; resolutions carry their evidence. Priority order in
MASTER_ENGINEERING_ROADMAP.md.

## Architecture / code
- **Component monoliths (R12) — PROGRAM COMPLETE (5/5, no unit >400 lines remains)**:
  ✅ dashboard-view 1153 → 192 + 7 modules in `views/dashboard/*` (Phase 5,
  worklog P5-2); ✅ leads-view 1206 → 394 + 6 modules in `views/leads/*`
  (Phase 5, worklog P5-3); ✅ import-leads-dialog 906 → 302 + 7 modules in
  `crm/import/*` — fields/field-icon/use-import-flow + 4 step components
  (Phase 5, worklog P5-5; subagent-executed verbatim surgery, main-session
  E2E parity: full CSV wizard inject→map→preview→commit→undo→back-nav,
  DB persistence + archive semantics identical, errs=0); ✅ team-section 580 →
  145 + 5 modules in `settings/team/*` (P6-7, worklog P6-8); ✅ entity-documents
  853 → 173-line root + 6 modules in `crm/documents/*` (P6-9, worklog P6-9 —
  mutations moved with their state; upload card self-contained; review
  mutations reach rows as structural prop slices preserving cross-row pending)
  — all verbatim moves, E2E-parity verified (errs=0).
- ✅ **i18n single-file serialize — RESOLVED (P7-1)**: the 3253-line
  `src/lib/i18n.ts` is now a module tree `src/lib/i18n/` (types + composition
  root + 18 domain modules, each holding fr/en/ar side-by-side so key parity
  is structural). Module-load duplicate-key guard restores the ts(1117)
  protection the single file got from the compiler; a zero-drift validator
  proved bit-equivalence (1013 keys × 3 langs; translate()/fallback/vars
  identical). Consumer surface unchanged (`@/lib/i18n`).
- ✅ **RBAC client drift — RESOLVED (P12-1 + P22)**: settings-view /
  team-section aligned in P12-1 (atLeastRole, null-safe widened input); the
  last two hand-rolled gates (visits-view + visits-calendar canReconfirm —
  `role !== SALES_AGENT && role !== FIELD_REP`) aligned in P22 to mirror the
  server reconfirm law verbatim (`agentId === user.id || atLeastRole(role,
  MANAGER)`). Remaining `.role === …` comparisons in src/ are selection
  filters (agent-option pickers, FIELD_REP lists), not permission gates —
  audited and classified 2026-10-10 via tmp-scripts/p22-i18n-audit.ts sweep.
- `next.config.ts`: ignoreBuildErrors:true + reactStrictMode:false — REQUIRED
  while `bun run build` is forbidden in the sandbox; flip only when build
  capability exists ([env] gate).
- ✅ 12 duplicated units — useDebounced/ROLE_TONE/toLocalDateTimeInputValue
  deduped (P4); load-or-404 lead pattern uses shared findLead.
- ✅ No-error-boundary risk — closed P3 (error.tsx + global-error.tsx).

## Database
- ✅ Migrations adopted (P3, D-014; baseline + replay-validated).
- ✅ Won-deal history seed consolidation (P3, D-015).
- ✅ Free-string enums closed (P4, D-016 — canonical constants in
  src/lib/constants.ts; schema columns remain strings by SQLite design,
  zod-enforced server-side).
- ✅ 5 composite indexes landed (P4, migration 2).
- Audit undo-scan reads ≤500 LEADS_IMPORT_UNDONE rows per audit page-load
  (fine <10×; watch-item, Low).
- Legacy display-only free-string columns (contact.type etc.) render via
  translation fallbacks — Low, harmless.

## Security (remaining — all deployment-time, see SECURITY_HARDENING.md)
- Cookie `secure` flag + lifetime rotation · Caddy body limit · demo-mode=0 ·
  dependency audit — gated on the deployment phase ([deploy]).
- ✅ Code-level: F-01..F-15 closed through Phase 5 (D-018 Origin enforcement
  + rightmost XFF the last two).

## Testing / DevOps
- R3: no automated test suite / CI — environment-gated ([env]; sandbox forbids
  build + test-suite code). Compensating control: TEST_STRATEGY.md 5-gate
  protocol + 34-case guard matrix runnable per-session
  (tmp-scripts/p4-guard-matrix.ts).
- ✅ Commit discipline + secrets hygiene (P3, D-012/D-013 gate).
- tmp-scripts/ accumulating by convention (inert, git-tracked, per-session
  reproducibility scripts; prune on commit slices when superseded).

## Product/domain
- Missing concepts pending product decision (Campaign/Offer/Commission/…):
  DOMAIN_MODEL.md — do not auto-add.
- ✅ Lead lifecycle free-form exits + opportunity terminal-stage creation gap
  (closed P4 — server-enforced 422s + audit rows).

## UX
- ✅ B1–B7 closed (P4). B8 duplicate-lead merge = R6 product decision.
