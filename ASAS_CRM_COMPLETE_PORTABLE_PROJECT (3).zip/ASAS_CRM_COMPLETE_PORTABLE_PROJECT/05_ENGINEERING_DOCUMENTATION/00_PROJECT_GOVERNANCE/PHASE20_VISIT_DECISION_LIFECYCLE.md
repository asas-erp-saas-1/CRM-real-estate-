# PHASE 20 — Visit Decision Lifecycle (program of record)

**User mandate:** FINAL MASTER DIRECTIVE (2026-10-09, `upload/Pasted Content_1791544557523.txt`) §18–§27 — the appointment/field-visit lifecycle completes here. Governs the P20-A slice: the field representative's decision vocabulary. Continuity: P18 (D-025) already delivers proposal≠confirmation (SCHEDULED created by the follow-up rep, CONFIRMED only on-site by the assigned FIELD_REP or MANAGER+). This slice adds the missing decisions: **reject with reason** and **counter-proposed time with explicit customer-reconfirmation**, plus the directive's §22 (preserve the original proposal slot) and §26 (concurrency guard).

## Binding laws (D-026)

1. **Decision authority** — REJECT and COUNTER-PROPOSE share the confirmation authority basis (`canConfirmVisit`): the FIELD_REP assigned to the visit's project at decision time (live lookup — a former assignee holds no cached authority), or MANAGER+ by rank. Sales reps never. Error codes: `VISIT_REJECT_FORBIDDEN` / `VISIT_PROPOSE_FORBIDDEN` (403).
2. **REJECTED is a proposal outcome, terminal from SCHEDULED only** — 422 `VISIT_NOT_PROPOSED` otherwise; requires a reason (3–500 chars, `REASON_REQUIRED`); stamps `rejectedAt`/`rejectedById`; `attended` stays null (a refusal is not an absence — NO_SHOW remains the customer-absence state). Not in any active set (dashboard/notifications/analytics unchanged).
3. **Counter-proposal is a date move + explicit customer-reconfirmation** — FIELD_REP PATCH `{scheduledAt, proposeAlternative:true}` (only from SCHEDULED) sets `awaitingCustomerReconfirm=true`, leaves `proposedAt` untouched, and writes the timeline entry. The new slot is NOT customer-accepted until the follow-up rep records `customerReconfirmed:true` (allowed: the visit's `agentId` or MANAGER+; 403 otherwise; 422 if no counter pending).
4. **`proposedAt` preserves the original slot** (§22) — set once at creation (= `scheduledAt`), immutable afterwards; the confirm-with-final-date move and any counter-proposal keep it queryable.
5. **Concurrency guard (§26)** — every PATCH may carry `expectedUpdatedAt`; a mismatch with the current row → 409 `VISIT_STALE` (no silent lost-update). All dialogs send it.
6. **Lifecycle transitions owned by this slice only** — the free-reset behavior (e.g. manager CONFIRMED→SCHEDULED, matrix probe FR5) is preserved; a full consolidated visit transition matrix is task **P20-B**, not smuggled in here.

## Execution order

1. Schema + migration `p20_visit_decision_lifecycle` (DDL via `migrate diff --script` + prepended data backfill `proposedAt = scheduledAt`).
2. `src/lib/constants.ts` — `VISIT_STATUSES` + `REJECTED`; `VISIT_STATUS_TONE` + rose.
3. `src/app/api/visits/route.ts` — POST sets `proposedAt`; GET decoration unchanged (same authority basis → `viewerCanConfirm` covers reject/propose).
4. `src/app/api/visits/[id]/route.ts` — patchSchema (reason / proposeAlternative / customerReconfirmed / expectedUpdatedAt), guards, stamps, timeline entries, 409/403/422 codes.
5. `src/lib/client/types.ts` + `visit-dialogs.tsx` (RejectVisitDialog + ProposeAlternativeDialog + inline customer-reconfirm action; all PATCH senders carry `expectedUpdatedAt`) + `visits-view.tsx` / `visits-calendar.tsx` gating ladders + hints.
6. i18n `domains/visits.ts` ×3 langs.
7. Seed: `proposedAt` everywhere; fixtures — 1 REJECTED (rep-assigned project), 1 SCHEDULED with `awaitingCustomerReconfirm` (Hydra), 1 SCHEDULED on the rep-less project (Villas Sidi Yahia — §17.3 fixture for P20-C).
8. Export bundle `visites.csv` + `rejectionReason` column (ERP contract completeness).
9. Matrix probes FR11–FR17 (RBAC ×2, happy paths ×3, reason-required 422, stale 409) + scratch-visit cleanup (activities by visitId FIRST — the P17 severed-activity lesson).
10. Validation: 5 gates + browser E2E (mounia reject/counter; yacine reconfirm; amine sees hints; AR RTL + mobile 390; zero console errors/warnings).

## Acceptance criteria

- Directive §58 Scenario B extended: the authorized representative confirms, **rejects with a reason, or proposes a different time**; the final status and history are correct; an unrelated representative cannot act (403) or see (404/visibility) the request.
- §21 "explicitly represent whether the customer must reconfirm" — the amber `awaitingCustomerReconfirm` state is visible to the follow-up rep and only they (or MANAGER+) clear it.
- §22 — `proposedAt` queryable on every visit, unchanged by date moves.
- §26 — a stale `expectedUpdatedAt` PATCH returns 409 and does not mutate.
- Matrix re-baseline: 62 → 69 probes, ×2 consecutive, steady-state residue zero.
- No regression: FR1–FR10 pass unchanged (incl. FR5 free reset).
