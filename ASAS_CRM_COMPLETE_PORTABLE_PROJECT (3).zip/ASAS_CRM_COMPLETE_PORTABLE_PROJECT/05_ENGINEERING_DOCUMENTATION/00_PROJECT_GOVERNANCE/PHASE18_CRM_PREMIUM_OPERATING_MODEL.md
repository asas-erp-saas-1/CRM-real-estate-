# PHASE 18 — CRM PREMIUM OPERATING MODEL (agency life, roles, field workflow, deal economics)

**Program of record for the user mandate of 2026-10-08** ("Continue your work on the path… Review the platform… modify the roles… agency's general manager… executive director… follow-up representatives… field visit representatives… Manager settings… financial-related content removed… ERP comes after CRM premium… sales representative sees the incentive… manager includes the agency commission… included and functional"). Captured verbatim as the operating story in `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/AGENCY_OPERATING_MODEL.md` — that file is the product truth; this one is the engineering program.

Supersedes, in scope terms: D-022's finance domain (reversed — see D-025) and the R10-4 sales-targets surface (financial content in manager settings — removed).

## 1. The operating model (what the user described)

**Roles** (the agency's operational life — anything else is out of scope):
| Role key | Label (fr) | Life |
|---|---|---|
| `OWNER` | Président · CEO (directeur général de l'agence) | Adds delegates, assigns them projects & responsibilities per their lifecycle; may conduct field visits personally (always visit-allowed by rank). |
| `ADMIN` | Administrateur | Platform administration (team, settings, audit) — unchanged. |
| `MANAGER` | Directeur exécutif | Executive management: org-wide data, commissions, confirmations, assignments. |
| `SALES_AGENT` | Représentant commercial | THE follow-up representative: owns inbound leads (site web, annonces réseaux sociaux, campagnes WhatsApp, campagnes Ouedkniss), follows up, **schedules appointments into the agenda — but never confirms them**. Sees the incentive received from the sale. |
| `FIELD_REP` (NEW) | Représentant terrain | Assigned to one or more projects by the CEO/executive. **Confirms the appointment on arrival on-site** (sometimes fixing the final date — which lands in the agenda). Sees ONLY the data of assigned projects (no information appears to other representatives). |

**Removed roles** (outside the operational life): `MARKETING` (its data life — campaign attribution on leads — already lives on Lead.source/campaign), `ACCOUNTING` (finance → future ERP), `OPERATIONS` (no surface ever used it).

**Visit confirmation discipline** (server-enforced): `SCHEDULED → CONFIRMED` is allowed ONLY to a FIELD_REP assigned to the visit's project, or MANAGER+ (executive director, admin, president — "the CEO may sometimes visit the projects themselves"). The confirming PATCH may carry the final date (`scheduledAt`) — the agenda then carries the confirmed final date. Confirmation is stamped `confirmedAt` + `confirmedById` and logged to the timeline.

**Deal economics (replaces the finance domain)**:
- `Reservation.commissionAmount` + `commissionFrom` (`DEVELOPER | CLIENT`) — the **agency commission**, set by MANAGER+ ("the manager includes the agency commission received from the developer or client").
- `Reservation.agentIncentive` — the **sales representative's incentive from the sale**, visible to the reservation's agent and MANAGER+; aggregated on the agent's dashboard.
- Financial/ERP content REMOVED: `Installment`, `Payment`, `SalesTarget` models + all routes/workspaces/settings surfaces (échéancier, encaissements, objectifs). The CRM tracks the money the agency and its reps EARN on a deal — not accounting, collections, or revenue objectives.

## 2. Gap table (mandate vs repo at P17 close)

| Mandate element | State at P17 | Action |
|---|---|---|
| CEO / executive director / follow-up rep roles | OWNER/MANAGER/SALES_AGENT exist but labeled differently | Relabel (fr/en/ar); keep keys (guards stable) |
| Field-visit representative role | Absent | New `FIELD_REP` + rank + labels + tones + seed persona |
| MARKETING/ACCOUNTING/OPERATIONS | Present (7 roles) | Removed from ROLES/RANK/i18n/tones/pickers; DB reassignment in migration |
| Project assignment (1 project ↔ N reps, 1 rep ↔ N projects) | Absent | New `ProjectAssignment` model + API + Settings/inventory UI (CEO/exec) |
| Visit confirm = field rep on-site (+ exec), final date → agenda | Anyone in scope can PATCH any status; confirm is one-click everywhere | Server guard + stamps + timeline entry; UI gated by a server-computed `viewerCanConfirm` |
| Rep data isolation (only assigned-project info) | No project-based scope exists | FIELD_REP scopes in `visibility.ts` (pure relation predicates) |
| Sales rep sees incentive; manager sets agency commission | Absent (finance domain = installments/payments) | `Reservation` economics fields + entry UI (manager) + visibility + agent dashboard block |
| Finance/ERP content out of manager settings | Finance workspace + targets (Objectifs) live | Full removal (models, routes, views, i18n, seed, matrix probes) |
| Campaign sources (site web / réseaux sociaux / WhatsApp / Ouedkniss) | Already covered by `SOURCES` + Lead.campaign | No change (attribution already correct) |

## 3. Engineering program (order of execution)

1. **Constants & roles** — ROLES/ROLE_RANK/labels/tones/personas/seed; picker surfaces re-derived.
2. **Schema migration `p18_crm_premium`** (data + DDL in ONE migration, p16 pattern): DELETE `Activity WHERE type='PAYMENT'`; DELETE `AuditLog WHERE entity='INSTALLMENT'`; reassign removed-role users (MARKETING→FIELD_REP, ACCOUNTING/OPERATIONS→SALES_AGENT); DROP `Payment`, `Installment`, `SalesTarget`; CREATE `ProjectAssignment`; `Visit.confirmedAt/confirmedById`; `Reservation.commissionAmount/commissionFrom/agentIncentive`.
3. **Finance + targets removal** — 13 finance-only files deleted + 17 shared-file surgical reverts + targets route/section/panel + i18n key removal (fr/en/ar) + seed blocks + matrix probes (53→41).
4. **FIELD_REP visibility** — `visibility.ts` role branches: visits/leads/opps/contacts/activities/reservations scoped through `project.assignments.some(userId)`; tasks own-only; nav hides leads/pipeline for FIELD_REP.
5. **Visit confirmation workflow** — PATCH guard (403 `VISIT_CONFIRM_FORBIDDEN` for non-entitled), stamps, timeline entry "Visite confirmée sur place", `viewerCanConfirm` in GET payloads, UI gating at the 2 confirm points (list row + calendar).
6. **Project assignments API + UI** — `POST/DELETE /api/properties/projects/[id]/assignments` (MANAGER+, assignee must be FIELD_REP, audited `PROJECT_ASSIGNED/UNASSIGNED`); "Équipe terrain" panel in the inventory project detail.
7. **Deal economics** — reservations GET `opportunityId` filter + economics fields; PATCH economics on `/api/reservations/[id]` (MANAGER+, audited `COMMISSION_SET`); deal-economics section in the opportunity dialog (manager edits, rep sees incentive); agent dashboard "Mes incentives" block; manager month-commission row.
8. **Matrix + E2E** — finance probes out, FIELD_REP probes in (assignment scoping, confirm RBAC, commission RBAC, cross-rep isolation); 5 gates; browser E2E ×4 roles (nadia/sarah/amine/mounia) FR/AR/mobile.

## 4. Binding laws (P18)

1. **Confirmation is presence, not intention** — only the assigned field rep (or an executive by rank) may confirm; a sales rep's `PATCH {status:"CONFIRMED"}` is a 403, and the UI never offers the button.
2. **A field rep's world is their projects** — every data surface resolves through `ProjectAssignment`; another representative's records are 404-byte-identical ghosts.
3. **The CRM earns, the ERP accounts** — deal economics are the only money on the platform: agency commission + agent incentive on the reservation; no schedules, no settlements, no targets.
4. **Role keys are stable identifiers** — OWNER/MANAGER keys keep their guards; labels carry the agency vocabulary ("Président · CEO", "Directeur exécutif").

## 5. Validation protocol

5 gates (TEST_STRATEGY): lint 0 · tsc 0 src · `GET /` 200 (stale-client restart protocol after migration) · matrix re-baselined and run ×2 (steady-state residue) · browser E2E sweep with 0 console errors/warnings, FR+AR+mobile 390, all four role lives exercised (president assigns; executive confirms + sets commission; follow-up rep schedules + sees incentive; field rep confirms on-site + project-scoped agenda). Residue discipline: matrix self-heals, counts back to baseline.
