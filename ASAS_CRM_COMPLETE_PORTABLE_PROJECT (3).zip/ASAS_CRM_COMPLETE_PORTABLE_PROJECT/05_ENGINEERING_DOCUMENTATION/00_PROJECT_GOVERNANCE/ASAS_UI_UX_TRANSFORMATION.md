# ASAS UI/UX TRANSFORMATION — Program of Record

**Mandate:** "ASAS — AUTONOMOUS ENTERPRISE UI/UX ENGINEERING" (41-§, this cycle).
**Status:** Phase 13 COMPLETE (2026-10-08) — Finance/Collections domain shipped end-to-end; see §7 execution record.
**Role of this file:** the consolidated map for THIS mandate cycle: forensic findings → gap analysis → program → roadmap. It does NOT duplicate the specialist docs — `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/DESIGN_SYSTEM.md` (binding visual laws), `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/AUTHORIZATION_MODEL.md` (binding authorization laws), `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_STATE.md` (phase history), `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/UX_MASTER_PLAN.md` (stage tables) remain the detail owners. Updated as implementation progresses (mandate §7).

---

## 1. Current architecture (verified — forensic audits P13-0-a / P13-0-b, 2026-10-08)

- **Stack:** Next.js 16 App Router · React 19 · TS strict · Tailwind 4 + shadcn/ui · Prisma/SQLite (migrations-based) · react-query · zustand. Single `/` route; **9 views** via zustand hash routing (`#/view`); **57 API route files**, no server actions.
- **Route invariant (binding, AGENTS.md §23-1):** `requireUser(role?)` → zod `parseBody` → visibility-scoped Prisma (D-021 composition law) → side effects (`logActivity` + `logAudit`) → `ok()/fail()`.
- **Authorization:** role-rank RBAC (OWNER>ADMIN>MANAGER>SALES_AGENT>MARKETING/ACCOUNTING/OPERATIONS) + **record-level visibility** (D-021: OWN+POOL below MANAGER / ORG at MANAGER+) through ONE primitive `src/lib/server/visibility.ts` across 32+ route files; §40 matrix (`tmp-scripts/p12-visibility-matrix.ts`) = permanent regression guard, 40/40.
- **Design system:** semantic type scale (`text-crm-*`), attention-tier + neutral-ladder + chart-ramp tokens, icon registry (`icon-vocabulary.tsx` — glyph contract), motion catalog, elevation ramp, density control, shimmer skeletons. **Premium laws:** restraint > decoration; two-tier metric law (D-UX-015); hover = border/bg shift; no blue/indigo.
- **i18n:** 18 domain modules, 1081 keys × fr/en/ar, RTL hardened (logical properties, DirectionProvider, bidi isolation).
- **Dashboard:** role-aware since P12 — agent "My Day" (`scope:"own"`, management panels null+uncomputed) vs manager/CEO team cockpit (`scope:"org"` + funnel/source/targets).
- **Maturity:** Phases 1–12 complete (see MASTER_ENGINEERING_STATE §2): CRM lifecycle, pipeline kanban, inventory radar, matching, visits calendar, tasks, analytics, audit, settings, import/export, copilot (server-side LLM), WIP limits, week view.

## 2. Forensic findings — mandate vs repository (gap analysis)

| Mandate requirement | Repository state | Verdict |
|---|---|---|
| §13/§15/§16 design system + enterprise tables | Complete (P6/P8/P9/V1.9) — sort/filter/zebra/density/j-k/bulk/saved views | ✅ closed |
| §17 role-aware dashboards | Agent My Day / manager cockpit / CEO analytics (P12) | ✅ closed |
| §18/§19/§20 RBAC, tenant, server-side authorization | D-021 visibility + matrix 40/40; orgId scoping everywhere; CSRF same-origin chain | ✅ closed |
| §21 RTL/LTR · §22 responsive · §23 a11y | Hardened P6-8/P7-3/P9-10 sweeps | ✅ closed |
| §24 loading/empty/error · §25 forms · §26 ⌘K | `crm/states.tsx` + per-surface skeletons; dialogs; command palette (6 entities) | ✅ closed |
| §27/§28/§30 frontend + types + component architecture | R12 extraction complete; shared `lib/client/types.ts` | ✅ closed |
| §29 performance | Audited per-phase; no open blockers | ✅ acceptable |
| §31 testing | Protocol-based (5 gates + guard matrix); CI promotion env-gated (R3) | ⚠️ environment-gated |
| **§10 lifecycle "Contract → Payment Schedule → Calls For Funds → Delivery" · §7 PHASE 7 Finance · §11 "Collections workspace" · §17 CEO "collections"** | **ABSENT — greenfield.** No Installment/Payment models, no finance routes, no collections UI, no collections KPI. Only traces: `Reservation.depositPaid` (single float), `Requirement.payment` (buyer preference), unused `APARTMENT_PAYMENT_PLANS`, reserved `ENTITY_ICON.payment: Banknote` glyph | ❌ **THE GAP — Phase 13** |

**Root cause:** finance/payments/commissions were triaged as "Phase 5+ advanced domain — awaiting product-owner decision" (MASTER_ENGINEERING_STATE §13). This mandate explicitly commissions them (§7 PHASE 7, §10, §11, §17) → the decision boundary is resolved by user instruction.

## 3. Phase 13 program — Finance / Collections domain (Recouvrement)

**Product shape:** an échéancier (payment schedule) per reservation, made of installments (appels de fonds), each settleable by payments (encaissements). The collections workspace answers the mandate §11 question set: *what is due, what is late, what requires action.*

### 3.1 Data model (additive migration `p13_finance_installments`)

- `Installment` — `orgId`, `reservationId`, `seq` (unique per reservation), `label`, `kind` (DOWN_PAYMENT | INSTALLMENT | DELIVERY | NOTARY_FEES | OTHER), `amount` DZD, `dueAt?`, `status` (PLANNED | CALLED | PAID | CANCELLED), `calledAt?`, `paidAt?`, `notes?`, `payments[]`. Indexes: `[orgId, status, dueAt]`, `[orgId, dueAt]`.
- `Payment` — `orgId`, `installmentId`, `amount`, `method` (CASH | CHEQUE | TRANSFER | OTHER), `paidAt`, `reference?`, `recordedById?`, `notes?`. Indexes: `[orgId, paidAt]`, `[installmentId]`.

### 3.2 Binding laws (D-022)

1. **Derived-overdue law:** OVERDUE is NOT a stored status — it is derived (`status CALLED ∧ dueAt < now ∧ payments-sum < amount`). No state can rot.
2. **Money recording is management work:** POST/PATCH installments + POST payments = `requireUser("MANAGER")`. Lists/overview stay role-scoped reads (defense-in-depth, D-021).
3. **Visibility:** `installmentScope(user)` = `{ reservation: reservationScope(user) }` — installments are visible through an in-scope reservation (agentId ∨ unassigned ∨ opportunity OWN+POOL). AND-composition law applies (AUTHORIZATION_MODEL §7).
4. **Starter-schedule-on-convert:** converting a reservation to CONVERTED auto-creates the DOWN_PAYMENT line from `reservation.depositPaid` (PAID + Payment row, notes "Acompte encaissé à la réservation") — the lifecycle becomes Contract → Schedule without manual bookkeeping. No deposit → no invented schedule (manager adds lines). Audited.
5. **PAID is stamped only by payment recording:** PATCH cannot set PAID directly (422). Full coverage (payments-sum ≥ amount) stamps `paidAt` inside the transaction.
6. **Activity + audit:** PAYMENT activity type (new, 18th) linked to reservation→lead timeline; audit actions INSTALLMENT_CREATED / _UPDATED / _CALLED / _CANCELLED, PAYMENT_RECORDED; entity INSTALLMENT.

### 3.3 API surface (4 new route files + 2 touched)

| Route | Methods | Law |
|---|---|---|
| `/api/finance/installments` | GET (scoped list + buckets + paidAmount), POST (MANAGER+, POST-reference guard) | conditions-array composition |
| `/api/finance/installments/[id]` | PATCH (MANAGER+; call/cancel/update; PAID-direct → 422) | scoped findFirst → 404 ghost-identical |
| `/api/finance/payments` | POST (MANAGER+; amount ≤ remaining; tx stamps PAID) | reservations-tx pattern |
| `/api/finance/overview` | GET (MANAGER+; KPIs + byProject) | analytics gating pattern |
| `/api/dashboard` (touched) | finance block `myDay ? null : {overdueCount, overdueAmount, dueSoon7d, collectedThisMonth}` | management-block pattern |
| `/api/reservations/[id]` (touched) | CONVERTED branch creates starter schedule | law 4 |

### 3.4 UI — Collections workspace (`finance` view, nav Opérations, minRole MANAGER)

- Attention tier (D-UX-015): EN RETARD (rose, count + amount, deep-link bucket) + À ENCAISSER ≤ 7j (amber); all-clear state when both zero.
- Context tier (one receding row): Échéancier total · Appelé · Encaissé · Reste à encaisser · Encaissé ce mois.
- Bucket chips: Tous / En retard / À encaisser / À venir / Soldés + text filter (client/apartment/label).
- Enterprise table (crm-th/crm-td ladder, sticky header): Échéance (label + kind badge + seq) · Client (deep-link → lead drawer) · Bien (apartment + project) · Montant (num + DZD) · Encaissé (amount + micro-meter) · Échéance date (rose when overdue) · Statut badge · Actions (Encaisser / Lancer l'appel / Détail).
- Record-payment dialog (amount ≤ remaining, method select, date, reference, notes) + installment detail dialog (payments ledger).
- Dashboard: third attention card "Recouvrement en retard" (MANAGER+ only, data null → absent for agents).
- i18n: new `domains/finance.ts` + `nav.finance` + enums labels + audit keys — ALL THREE languages.

### 3.5 Seed (idempotent extension)

`seedPaymentSchedules(db, org)` — standalone block after the won-deal seed: resolves CONVERTED + ACTIVE reservations, writes realistic VSP schedules (acompte PAID at reservation date; quarterly appels de fonds; older deals further along; **2 overdue lines incl. 1 partial payment**; upcoming lines; ACTIVE reservation = deposit only). Backdated PAYMENT activities. Idempotent by `installment.count() > 0`.

## 4. Migration & compatibility strategy

Additive only: new models + new routes + new view; NO existing route contract changes except the dashboard response gains a nullable `finance` key (clients null-tolerant — same pattern as P12 `funnel`) and reservations CONVERTED gains the audited starter schedule. No blue/indigo, no new fonts, no dependency additions.

## 5. Validation strategy (this phase)

5-gate protocol + §40 matrix extended with finance probes (scoped list, foreign-detail 404 byte-equality, agent money-mutation 403, overview MANAGER gate, own-schedule regression) + agent-browser E2E (manager records a payment on an overdue line; agent sees no Finance nav + 403 lock on deep-link; AR RTL; 390px) + VLM visual review (light/dark/AR) + zero-residue audit (scratch payment restored exactly).

## 6. Roadmap (post-Phase-13, priority order)

1. R5/R6 product-owner data decisions (7 legacy held apartments · Larbaoui duplicate) — decision boundary, surfaced.
2. Arabic micro-copy human review (owner).
3. R3 test-harness promotion (environment-gated; the protocol + matrices are the interim guard).
4. Deployment preparation (explicit instruction only; PRODUCTION_READINESS gate order).

## Change log

- 2026-10-08 — created (P13-0 forensic audits a/b; Phase 13 program defined; mandate gap analysis recorded).
- 2026-10-08 — **Phase 13 COMPLETE**: all §3 components shipped and validated — migration `p13_finance_installments` (2 models) + 4 finance routes + dashboard block + starter-schedule-on-convert + `finance` view (attention/context tiers, buckets, zebra table + mobile list, 3 dialogs) + nav/card/i18n ×3 + seed (37/9/9). Matrix **52/52** (12 new finance probes), browser E2E both roles, AR RTL, mobile 390, VLM 13/13 (caught + fixed the dashboard 3-card orphan row), residue zero. Binding laws in D-022. One accepted scope cut: SAV domain deferred (mandate §10 tail — next-cycle candidate, §6).
