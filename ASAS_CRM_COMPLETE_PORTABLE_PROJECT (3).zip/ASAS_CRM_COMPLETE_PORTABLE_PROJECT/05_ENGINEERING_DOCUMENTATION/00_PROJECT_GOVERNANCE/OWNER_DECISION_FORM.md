# ASAS CRM — Owner Decision Form (2026-10-25)

**How to answer:** each question lists lettered options. Reply with the question number + option
letter (e.g., "Q1: B, Q2: A") — or "Other: …" to specify, or "KEEP OPEN" to defer. Partial completion
is fine. **No option is approved until you answer.** Every ⭐ recommendation is
**RECOMMENDED — NOT APPROVED**. Evidence references: `NEXT_PHASE_PLAN.md` (NP§) and the file:line
citations within it. Questions marked ⛔ **block implementation** of the related workstream until answered.

---

## Q1 — Lifecycle scope of the visit/report gate ⛔ (blocks Phase B/C implementation)

**Decision needed:** where does the mandatory completed-visit-report gate apply?
**Why it matters:** it determines which transitions the server must guard and where reps feel it.
**Evidence:** NO visit gate exists anywhere today (NP§1.2-1); opportunity stages already include
VISIT_SCHEDULED → VISIT_COMPLETED (constants.ts:16-27); visits link to leads (required) and optionally
to opportunities (typed FK, D-021-validated).

| Option | Consequence |
|---|---|
| A — Lead lifecycle only | guards NEW→…→CONVERTED; deals opened pre-visit would need conversion blocked; visits often happen AFTER conversion in the current model → would fight the existing design |
| B — Opportunity lifecycle only ⭐ | the exit criterion of stage VISIT_SCHEDULED (+ entry to VISIT_COMPLETED/later) = a COMPLETED visit with a satisfied report linked to the deal; lead track stays light (progressive disclosure); smallest server change |
| C — Both, with distinct rules | strongest control; double the override surface; heavier UX at intake |
| D — Another boundary from the data model | specify |

**⭐ RECOMMENDED — NOT APPROVED: B** (uses existing stages + existing typed FK; NN/g progressive
disclosure; Salesforce stage-exit-criteria discipline). **Main alternative risk:** A/C add gates on
surfaces where visits are not yet modeled, creating override fatigue.
**Dependencies:** none. **Blocks:** Phase B/C implementation (not the specs).

Owner answer: __________

---

## Q2 — Gate strictness and authorized override ⛔ (blocks Phase B/C implementation)

**Decision needed:** strict block, manager override, or exception rules?
**Why it matters:** this is the governance semantics of the sales pipeline's most-used transition.
**Evidence:** existing override family = manager correction hatches with mandatory reason + dedicated
audit (leads/opps); D6's closure waiver is a SEPARATE decision (S-DIR §10 Q2 explicitly separates them).

| Option | Consequence |
|---|---|
| A — Strict block, no override | zero leakage; any legitimate no-visit deal (e.g., remote sale) becomes impossible without a code change |
| B — Strict block + MANAGER-only, reason-required, audited override ⭐ | fail-closed default; legitimate exceptions cost one explicit, audited management act (same family as existing hatches; OWASP Logging: who/what/when/why) |
| C — Soft warning only | fastest flow; the gate becomes advisory — does not satisfy "blocked until the visit actually occurred" (S-DIR §4.B) |
| D — Different rule per documented exception | specify per-outcome rules (interacts with Q3) |

**⭐ RECOMMENDED — NOT APPROVED: B.** **Alternative risks:** A's rigidity vs C's non-enforcement.
**Dependencies:** Q1. **Blocks:** Phase B/C implementation.

Owner answer: __________

---

## Q3 — No-show, cancellation, rescheduling, incomplete & repeat visits ⛔ (blocks Phase B/C implementation)

**Decision needed:** how each exceptional outcome affects the gate/status/history/next action.
**Why it matters:** "a scheduled visit is not a completed visit" — the gate must stay honest without
trapping real exceptions.
**Evidence (current matrix, constants.ts:54-62):** NO_SHOW exits ONLY to RESCHEDULED; COMPLETED/
CANCELLED/REJECTED are terminal (correction = a NEW visit); CONFIRMED→SCHEDULED = MANAGER reset
(audited, unwinds presence stamps).

| Outcome | Option A | Option B ⭐ |
|---|---|---|
| No-show | gate stays blocked; NO_SHOW→RESCHEDULED is the natural next action | same + surfaced as attention item for the follow-up rep |
| Customer cancellation | CANCELLED (terminal); gate blocked; next = schedule a NEW visit | same + cancellation reason recorded in the new report-adjacent field |
| Representative cancellation | same as customer cancellation (no separate status exists; use reason text) | add optional `cancellationInitiator` field to distinguish (additive) |
| Rescheduling | RESCHEDULED status or same-status date change (both exist); gate unchanged | same — the eventual COMPLETED visit satisfies the gate |
| Incomplete visit | no dedicated status today; treated as not-completed (gate blocked) | optional `incompleteReason` on the report (additive) |
| Repeat visit | multiple visits allowed; ANY completed one satisfies the gate | same + report chain visible in timeline |

**⭐ RECOMMENDED — NOT APPROVED: the B column** (additive, honest, no false completions).
**Dependencies:** Q1/Q2. **Blocks:** Phase B/C implementation.

Owner answer: __________

---

## Q4 — Standard field-visit report contract ⛔ (blocks Phase B/C implementation)

**Decision needed:** mandatory vs optional fields, validation, completion status, correction policy.
**Why it matters:** this is what "a completed visit with customer-interest notes" concretely means.
**Evidence (Visit model today, schema.prisma:434-481):** exists = outcome (free text, required at
COMPLETED), notes, followUpRequired, nextAction, attended, actor stamps; MISSING = interest level,
objections, discussed-property report, follow-up recommendation, next-action due date, report
author/stamp.

| Field | Proposal |
|---|---|
| Customer interest level | **Mandatory** — structured enum (VERY_INTERESTED / INTERESTED / NEUTRAL / NOT_INTERESTED) |
| Report notes (objections/concerns + discussed property/project) | **Mandatory** — free text, min length |
| Report author + timestamp | **Mandatory** — server-stamped (`reportedById`, `reportedAt`) |
| Follow-up recommendation | **Optional** — enum (CONTINUE / NUDGE / REQUALIFY / CLOSE_LOST) |
| Next action + due date | **Optional** — `nextActionDueAt` |
| Manager review required before stage advance? | **Not required by default** (the gate is the report's existence; manager review = the Q2 override path) |
| Corrections after submission | append-only revision (audited), never silent rewrite — the P20-B terminal-visits law extended to reports |

**⭐ RECOMMENDED — NOT APPROVED: the table above** (smallest defensible contract; facts separated
from managerial assessment per S-DIR §4.D). **Dependencies:** Q1. **Blocks:** Phase B/C.

Owner answer: __________

---

## Q5 — Report authority ⛔ (blocks Phase B/C implementation)

**Decision needed:** who creates/submits/amends/approves the report.
**Why it matters:** preserves the distinction between the person who performed the visit and the
manager who may review/override the workflow.
**Evidence:** completion today has NO authority gate (any in-scope user, visits/[id]:196-202) while
field decisions require the assigned FIELD_REP or MANAGER+ (visibility.ts:186-197); the P18 operating
model: the field rep confirms on-site, the follow-up rep coordinates.

| Option | Consequence |
|---|---|
| A — Assigned field rep submits; manager can review anytime | matches the operating model; no extra bottleneck |
| B — Assigned rep submits AND manager approval required for the gated transition | adds a second managerial touch to every deal — slows the main pipeline |
| C — Visit's agent (follow-up rep) submits when no field rep involved | covers rep-only visits |

**⭐ RECOMMENDED — NOT APPROVED: A + C combined** (assigned FIELD_REP submits when one is involved;
otherwise the visit's agent; managers review via the audit/timeline and override via Q2 only).
Amendments = audited append-only revisions (Q4). **Dependencies:** Q2/Q4. **Blocks:** Phase B/C.

Owner answer: __________

---

## Q6 — Representative workspace management actions (D-OWNER-01 detail) ⛔ (blocks R7 + representative workspace implementation)

**Decision needed:** the explicit action-by-action permission table (least privilege — no bundled
"full management").
**Why it matters:** D-OWNER-01 approved the DIRECTION only; the precise action set is undecided.
**Evidence (verified current walls, NP§3):** representatives today can create/edit in-scope records
across leads/tasks/visits/opps/reservations + request closure; they CANNOT reassign, correct, validate
closure, write economics, confirm visits (SALES_AGENT), or reach analytics/audit/settings.

Proposed representative-workspace additions (each independent — answer per line):

| # | Action | Proposed permission | Audit event |
|---|---|---|---|
| 6.1 | View own per-rep workspace (own overdue/ownership view — R7 surface) | SALES_AGENT: own; MANAGER+: any rep (D-021 unchanged) | read-only |
| 6.2 | Self-assign a POOL lead (ownerId null) | allow SALES_AGENT (pool only — never a peer's lead) | LEAD_ASSIGNED |
| 6.3 | Schedule/reschedule own-scope visits | already allowed — unchanged | existing |
| 6.4 | Record visit outcomes/reports on own-scope visits | allowed per Q5 | VISIT_COMPLETED + report |
| 6.5 | Request stage/transition (queued for manager approval instead of direct move) | optional new request-queue model | new REQUEST audit |
| 6.6 | Create tasks for self | already allowed | existing |
| 6.7 | Archive/restore own-of-record leads | already allowed | existing |
| 6.8 | Reassignment (any record) | **stays MANAGER+** | existing |
| 6.9 | Validate closure / economics / corrections | **stays MANAGER+** | existing |

**⭐ RECOMMENDED — NOT APPROVED: 6.1 + 6.2 + 6.5 as the additions; 6.8/6.9 unchanged.**
**Risks:** broadening 6.2 beyond pool leads breaks D-021 peer privacy; 6.5 without the queue = a
silent permission widening. **Dependencies:** independent. **Blocks:** R7 + workspace implementation.

Owner answer: __________

---

## Q7 — Commission helper contract (D5 detail) ⛔ (blocks Phase E implementation)

**Decision needed:** inputs, rate optionality, suggested-vs-confirmed semantics, logging, visibility.
**Why it matters:** arithmetic help on the money surface WITHOUT inventing an authoritative rate policy.
**Evidence:** amounts are manager-entered with recorded free-text basis — the §37/§38 trust law
(reservation-trust.ts:7-8; schema comment "no invented rates/formulas"); `reservation.amount` (nullable)
sits in the same dialog; the manager confirms/edits (approved direction).

| Option | Consequence |
|---|---|
| A — Optional rate input + client-side "calculate" prefill; manager confirms/edits; structured rate echo in the basis when used ⭐ | zero trust-law change; error-reduction; the rate is recorded only when actually used; audits reconstructable |
| B — Server-computed authoritative amount from a rate | changes the trust law (system becomes the rate's source of truth); requires a rate policy decision you have NOT made — rejected by the approved direction |
| C — Status quo (manual only) | the known arithmetic-error class stays open on the money surface |

**Sub-decisions folded into A (defaults, adjustable in your answer):** rate is OPTIONAL, never
defaulted; suggested value is transient (not persisted as a distinct field); the confirmed value rides
the existing audited COMMISSION_SET/INCENTIVE_SET path with decidedBy stamps; visibility unchanged
(MANAGER+ writes; agent aggregate reads).
**⭐ RECOMMENDED — NOT APPROVED: A.** **Dependencies:** none. **Blocks:** Phase E implementation.

Owner answer: __________

---

## Q8 — D6 completeness & waiver semantics ⛔ (blocks Phase E implementation)

**Decision needed:** exact behavior for missing amounts/payer/incentive/bases; zero-vs-NA-vs-waived-
vs-paid; whether request_closure also warns.
**Why it matters:** closes the verified silent-revenue-leakage gap while preserving closure speed.
**Evidence:** validate_closure performs NO economics check today (verified absent, NP§1.2-4); the
schema expresses zero (value 0 + basis text) and paid (INCENTIVE_PAID + paidAt) but has NO dedicated
"not applicable" or "waived" representation — the approved direction already defines zero+basis as
the not-due representation, so no new field semantics are invented.

| Option | Consequence |
|---|---|
| A — Warn at request_closure (advisory list) + 422 INCOMPLETE_ECONOMICS at validate_closure, overridable with `waiveEconomics:true` + reason embedded in the SALE_VALIDATED audit receipt ⭐ | earliest cheap fix + hard server gate + audited waiver; forward-only (historical CONVERTED rows untouched); existing callers unaffected unless they waive |
| B — Warning banner only at validate | visible but not enforced — weaker than your approved "reason-gated waiver" direction |
| C — Hard block, no waiver | zero leakage; stalls legitimate closings with pending developer terms (the Wave-3 recorded risk) |

**⭐ RECOMMENDED — NOT APPROVED: A** (exactly the approved warning+waive direction, made concrete).
**Dependencies:** none. **Blocks:** Phase E implementation.

Owner answer: __________

---

## Q9 — Cleanup approval boundary (blocks Phase H execution only)

**Decision needed:** which artifact categories may be archived/removed in a SEPARATE later task.
**Why it matters:** reduces environment distraction without destroying engineering evidence.
**Evidence:** the categorized inventory (NP§7): 58/65 download dirs + all evidence dirs referenced by
governance docs (retain); 7 zero-reference dirs (~5.8 MB) + 3 verified duplicates (archive candidates);
~25 unknown-purpose items incl. 12 upload UUID-images (owner review); `prisma/seed.ts` is canonical.

| Option | Consequence |
|---|---|
| A — Approve archiving the 7 zero-reference dirs + the verified duplicate pair; everything else retained pending item-by-item review ⭐ | smallest safe step; rollback = restore from archive |
| B — Full owner-item-by-item review of category 7 first, then a single cleanup pass | more owner time, maximal safety |
| C — Defer all cleanup | environment stays cluttered; no risk |

**⭐ RECOMMENDED — NOT APPROVED: A.** No deletion is authorized by THIS form — Phase H executes only
after a separately approved task. **Dependencies:** none. **Blocks:** Phase H only.

Owner answer: __________

---

*Answer even partially — every unanswered question stays OPEN and its gated work stays blocked (the
register's law: recommendations are not approvals).*

---

## ANSWERS RECEIVED — 2026-10-26 (UX-OWNER-PLAN-2)

The owner answered the questionnaire (supplied in-session under task UX-OWNER-PLAN-2, authority line
"Owner-approved decisions supplied on 2026-10-26"). The questions above are preserved verbatim
(append-only law); the canonical record of every answer is
`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md` §1a. Condensed transcription:

| Question | Owner's answer | Register ID |
|---|---|---|
| Q1 | **B — Opportunity lifecycle only.** The gate applies to the relevant Opportunity stage transition; the completed visit must be linked to the SAME Opportunity; no Lead-lifecycle gate by default. (Boundary verified against the actual matrix — no material mismatch; formalized in `NEXT_PHASE_PLAN.md` §2.1.) | GATE-Q1 |
| Q2 | **A — Strict blocking, NO override.** No `waiveVisitGate` mechanism; a D6 financial waiver never bypasses the visit gate. (Retires the ⭐ B recommendation — it was never approved.) | GATE-Q2 |
| Q3 | **B-column family — gate stays CLOSED for incomplete outcomes, with operational visibility.** Never mark COMPLETED unless it occurred; cancelled/no-show/incomplete never satisfy the gate; follow-up alert; optional structured fields (cancellation initiator, incomplete reason) considered per schema compatibility; reschedule/subsequent visit without rewriting history. | GATE-Q3 |
| Q4 | **Approved as proposed (required: interest-level 4-enum + written report notes + server-set author/timestamp; optional: follow-up recommendation + next-action due date).** Corrections audited, never erasing history. No additional mandatory fields without a separate recommendation. | REPORT-Q4 |
| Q5 | **A + C combined, refined: assigned FIELD_REP submits; else the representative responsible for the customer; managers review; corrections auditable; ordinary transitions need no per-report manager approval; NO role bypasses the strict gate.** | REPORT-Q5 |
| Q6 | Answered as three sub-parts: **Q6a** visibility (own workspace; MANAGER+ inspects within org scope; D-021 intact) · **Q6b** pool self-assignment (allowed with LEAD_ASSIGNED audit; NEVER a colleague's lead) · **Q6c** direct transitions (permitted when validations pass; the manager-request queue NOT approved as mandatory). | WORKSPACE-Q6a · POOL-Q6b · TRANSITIONS-Q6c |
| Q7 | **A — optional rate + base inputs; transient suggestion (not auto-persisted); manager confirms/edits; NO default rate/rate table/unapproved formula; basis recorded on confirmation via existing canonical audit paths; visibility restrictions preserved.** | D5-DETAIL-Q7 |
| Q8 | **A — request_closure warns; validate_closure rejects with 422 INCOMPLETE_ECONOMICS + missing-field list; authorized manager waiver via `waiveEconomics` + mandatory reason; waiver auditable (actor/time/reason/missing items); transaction safety/governance/idempotency/trust preserved.** (The zero/NA/waived/paid semantics question REMAINS OPEN — see RQ-3.) | D6-DETAIL-Q8 |
| Q9 | **A-shaped but explicitly PLANNING ONLY: candidate scope = the 7 zero-reference dirs + verified duplicates; before any future cleanup: second reference audit (done 2026-10-26), manifest, recoverable archive procedure, reproducibility verification.** No archiving/moving/deletion authorized now. | CLEANUP-Q9 |
| Q10 (new, this round) | **Server-side response minimization for reservation financial fields** — unauthorized fields must not be serialized to roles below the manager/administration boundary; UI hiding is insufficient. | FIN-MIN-Q10 |
| Q11 (new, this round) | **Formal lifecycle audit coverage** for lead qualification, conversion, opportunity-stage transitions, visit completion; activity timeline stays the user-facing surface; no duplicate/contradictory events. | AUDIT-Q11 |

**Status:** every answered question's gated workstream moves from "blocked on owner answer" to
"blocked on the owner's review of the revised plan" (`NEXT_PHASE_PLAN.md` v2) — the answers authorize
planning, NOT implementation.

---

## REMAINING QUESTIONS (2026-10-26 — only these three; each narrowly scoped, evidence-based)

**RQ-1 — CLOSED_LOST and the visit gate (affects the gate's edge set).**
`CLOSED_LOST` is a legal exit from EVERY working stage (constants.ts:125-136). If the gate also fires
on pre-visit→CLOSED_LOST, a deal that never had a visit could never be lost — a hard behavioral change
never discussed. **RECOMMENDED — NOT APPROVED: exempt CLOSED_LOST** (loss is not progression; early
disqualification stays possible).

**RQ-2 — `validate_closure` and the visit gate (affects the enforcement-point set).**
`validate_closure` writes opportunity CLOSED_WON directly (reservation-lifecycle.ts:191-196) and
reservation creation carries no stage precondition — so today a NEW-stage deal can be carried to
CLOSED_WON with zero stage PATCHes. Without extending the gate there, GATE-Q2 ("blocked until the
visit actually occurred") is bypassable on the money path. **RECOMMENDED — NOT APPROVED: extend the
same completed-visit requirement to `validate_closure`** (one predicate in the same interactive
transaction; a `waiveEconomics` retry clears only the economics rejection, never this check).

**RQ-3 — zero vs not-applicable vs waived vs paid (affects the D6 waiver receipt + representation).**
The current schema records zero (value + basis), paid (INCENTIVE_PAID + paidAt), and a waiver as an
audit receipt — but has NO distinct representation for "not applicable", and you instructed us not to
assume zero ≡ NA ≡ not-payable, waiver ≡ payment, or confirmed amount ≡ money received.
**RECOMMENDED — NOT APPROVED: keep the current representations and require the written explanation to
carry the disambiguation** (no new financial status model). If the ambiguity is operationally costly,
an explicit additive semantics discriminator can be specified for your review.

*Everything else previously open is answered above; do not re-ask decided matters. The full
decision-to-work mapping: `OWNER_DECISION_REGISTER.md` §1a.5.*

---

## CLOSURE ATTEMPT — 2026-10-26 (UX-OWNER-DECISION-CLOSE-3: no answers arrived)

The decision-closure directive `UX-OWNER-DECISION-CLOSE-3` ("close every owner decision explicitly
answered by the supplied response … conditional security Workstream S") arrived with its
owner-answers section carrying only the unfilled placeholder — **no actual form results were
supplied** (in-session or via `upload/`, verified read-only). Per the binding law (no
recommendation, default, or inference counts as owner approval), **the three questions above remain
OPEN and Workstream S remains unauthorized.** The round executed its documentation-only branch
(Case B): live-state verification (HEAD `cd7a725`, clean tree, environment reset re-confirmed
read-only), the residual-decision audit (register §1b.1), and the Workstream S implementation brief
(`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/WORKSTREAM_S_IMPLEMENTATION_BRIEF.md`) — ready for execution the moment the owner
answers. **The vehicle for closure remains THIS form's RQ-1/RQ-2/RQ-3 plus the explicit
Workstream-S authorization/refusal** (one combined reply closes everything).

---

## CLOSED — 2026-10-26 (WS-S-EXEC: the owner's answers arrived in-session)

The "Owner Decision Closure and Authorized Workstream S Execution" directive delivered the owner's
binding answers directly (no form upload needed — the answers were the directive's §2, explicitly
stated as "confirmed and binding"). **All three questions above are ANSWERED and CLOSED** (register
§1c.1):

- **RQ-1 → CLOSED_LOST is EXEMPT** from the mandatory visit/report gate (loss is not progression).
- **RQ-2 → server-side enforcement** in `validate_closure` and across every path that can result in
  a successful closure; client-side checks alone are insufficient.
- **RQ-3 → keep the existing financial model and schema unchanged**; zero + written explanation =
  the incentive is not due ONLY (never paid/waived/not-applicable by inference); no new
  financial-state semantics or fields during Workstream S.

Plus five further decisions recorded in the same reply: the visit-report correction policy
(append-only corrections with reason + auditable before/after, original intact), visit-exception
fields DEFERRED (existing statuses + follow-up alerts retained), visit–Opportunity same-Lead
consistency (server-side validation at visit create/update + gate revalidation — approved
requirement, not yet implemented), **Workstream S EXECUTION AUTHORIZED** (the only application-code
workstream in that round — executed), and the database-recovery boundary (restoration/reset/reseed
NOT authorized; isolated tests only; limitations disclosed). Canonical record: register §1c.
