# MASTER ENGINEERING PLAN

**The project's engineering constitution.** How ASAS CRM is engineered from the current state toward the target state. Read it before proposing any significant change. Evolve it deliberately (decision-log entry for constitutional changes).

## 1. Target state

A coherent, production-grade, maintainable, secure, usable, operationally complete CRM for the Algiers single-agency real-estate domain — deployable to GitHub + Supabase + Vercel **without architectural surgery**, and continuable by any future agent via the Continue protocol alone.

## 2. Architectural direction (fixed — changes require an ADR)

- **One stack**: Next.js 16 App Router + TypeScript + Tailwind 4 + shadcn/ui + Prisma(SQLite today, PostgreSQL at deployment) + react-query + zustand. **No second architecture** (no second ORM/auth/API pattern/state system/design system/DB abstraction).
- **Single `/` route**, hash-routed views; **API routes only** (no server actions).
- **Thin client, enforcing server**: every rule that matters (lifecycle, RBAC, tenant scope, validation, coherence) is enforced server-side; UI hiding is UX only.
- **Domain logic in server modules** (`src/lib/server/*`), never only in React components.
- **Migrations-based schema evolution** (D-014); seed = single entry point (D-015).
- SQLite pragmatism: express in-transaction invariants in code where SQLite can't express them declaratively (D-008); document the PostgreSQL shape for each such trade-off.

## 3. Engineering principles

1. Evidence over assertion — a claim of "works" requires a run gate (§7).
2. Smallest correct change; preserve working behavior; understand → dependents → callers → rollback before editing.
3. Correctness order when prioritizing: security → data integrity → core functionality → broken journeys → architectural blockers → reliability → testing gaps → performance → UX friction → debt → advanced → cosmetic.
4. No cosmetic progress (file counts / visual novelty are not progress); no hidden work (significant behavior/permission/schema changes must be surfaced in the worklog).
5. Uncertainty is classified, not guessed: Known / Inferred / Unknown / Needs research / Needs product decision. Product decisions are surfaced, never invented.
6. Every significant cycle ends with reconciliation: roadmap ↔ reality ↔ code ↔ validation ↔ docs (§10).
7. Knowledge compounds: recurring errors/patterns/constraints get documented in the repo, not carried in agent memory.

## 4. Subsystem boundaries

| Subsystem | Home | Boundary rule |
|---|---|---|
| Views (UI) | `src/components/crm/views/*` | render + local UX state only; data via react-query; no business rules |
| Shared UI | `src/components/ui/*`, `crm/states.tsx`, hooks | primitives + states; no domain fetch logic |
| Client data layer | `src/lib/client/api.ts` + react-query keys | the only fetch surface; relative URLs only |
| API layer | `src/app/api/**/route.ts` | invariant chain: requireUser → zod parseBody → org-scoped query → side effects → ok/fail |
| Domain/services | `src/lib/server/*` | business logic, guards, transactions, audit |
| Data | `prisma/schema.prisma` + migrations | schema changes authored on a scratch DB, applied via `db:migrate:deploy` + restart + one-route verify |
| Canonical vocabularies | `src/lib/constants.ts` | enums shared by API/UI/seed (D-016) — never re-declared locally |
| i18n | `src/lib/i18n.ts` | append-only marked blocks, genuine Arabic |

## 5. Quality gates (a significant feature is not complete if a relevant gate fails)

| Gate | What | How (current environment) |
|---|---|---|
| A — Type safety | tsc clean in src/ | `bunx tsc --noEmit` |
| B — Lint | eslint clean | `bun run lint` |
| C — Tests/contract | behavior proven | validation protocol (TEST_STRATEGY.md): curl matrix incl. 404/422/403 edges; guard-matrix script for lifecycle/RBAC/enums/audit; full CI suite is environment-gated |
| D — Build | production build | **environment-blocked** (`bun run build` forbidden) — type-check gate stands in; flip `ignoreBuildErrors` only when build becomes available |
| E — Database | migration discipline | `migrate status` clean; schema↔live diff empty; risky work preceded by `db:snapshot`; restart server after migrate |
| F — Security | new surfaces audited | authz matrix for new routes; forged-cookie probes on auth changes; no secret/PII in responses or logs |
| G — UX/workflow | the seven states | agent-browser: changed view happy path + empty/error paths where reachable; `window.__errs`=0; 390px + AR RTL when layout touched |
| H — Documentation | knowledge captured | worklog entry + affected docs updated in the same session |

## 6. Database rules

1. Schema changes: edit schema → author the migration on a **scratch database** (`bunx prisma migrate dev` with a throwaway `DATABASE_URL`, never the shared one) → review + commit the SQL → apply with `bun run db:migrate:deploy` → restart dev server → verify one route → `bun run db:migrate:status` clean. Never `db:push` as deployment (escape hatch is manual, documented, exceptional).
2. Business invariants enforced at the correct layer: DB constraints when expressible; otherwise in-tx guards (document the PostgreSQL future shape).
3. Every mutation of consequence is transactional where multi-record (conversion, booking, import commit, bulk ops).
4. Every consequential action writes an AuditLog row (actor/timestamp/action/entity/id/before/after — no secrets).
5. Tenant scoping (`orgId`) on every query — org-scoped reads/writes only.
6. Before destructive/risky DB work: `bun run db:snapshot`.
7. Seed is canonical demo data only (public password D-007); test fixtures live in throwaway DBs, never in seed.

## 7. Validation requirements (the honest-contract core)

- Never report fixed without running the gates; never leave test residue (exact restores documented).
- Agents must distinguish: verified live (command + outcome) vs code-level reasoning vs unverified.
- Known automation artifacts are not bugs (`fill ""` desync; Radix eval-click; media-gated hovers).

## 8. Release strategy

Single-deployment product in a sandbox. "Release" = conventional commit with validation evidence in the message. The future real release path (deployment phase, on explicit instruction): repo packaging → history purge (D-013) → remote → Supabase migrations replay → Vercel build validation → production checklist (PRODUCTION_READINESS.md).

## 9. Documentation rules

- Authoritative homes only (§ governance files); update in place; no duplicate competing docs; retire with a redirect stub when consolidating.
- Append-only: `worklog.md` (single heredoc appends), DECISION_LOG (new ADRs never rewritten).
- New audit actions / API surfaces / schema changes ⇒ relevant doc updated **in the same session**.

## 10. Change management

Significant change = anything that alters business rules, permissions, schema semantics, APIs, data behavior, or infrastructure. Requirements: ADR entry (problem/evidence/options/decision/trade-offs/validation) + worklog surface + affected docs + full gates. Never silently.

## 11. Agent operating rules (binding)

- Read `AGENTS.md` first, every session. `worklog.md` tail + master state second.
- Work in coherent increments: Understand → Plan → Implement → Validate → Document → reassess. Never attempt the whole platform in one operation.
- Continue protocol governs «Continue» messages (AGENTS.md §Continue protocol) — reconstruct context, pick the highest-value safe action, stop only at genuine decision boundaries.
- Subagents receive: Task ID, worklog pointer, deliverable contract (agent-ctx file + worklog append).
- Do not re-litigate recorded decisions casually (DECISION_LOG D-011 rule); do not preserve bad changes just because they exist — investigate and correct professionally.
- New technology: 5 steps — search repo → identify existing → judge sufficiency → research alternative with purpose → ADR before adoption.

## 12. Definition of done (per feature/subsystem)

Domain behavior defined → DB representation correct → authorization enforced → validation exists → happy AND failure paths work → persistence + UI feedback → audit where consequential → relevant gates run green → docs updated → no known regressions. Not every subsystem needs every dimension — engineering judgment, documented.
