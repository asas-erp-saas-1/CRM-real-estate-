# Platform Handoff Research Record (H6-b)

**Purpose:** Ground the ASAS CRM handoff decisions (GitHub import, Supabase PostgreSQL, Vercel deployment) in
current official documentation rather than stale memory, before the handoff package is executed.
**Date:** 2026-10-30 (all sources fetched and read today).
**Method:** Live fetch of official doc pages (rendered HTML → text; Prisma docs also expose `.md` variants), plus
the installed Prisma 6.11.1 CLI help as a primary source for flag semantics. Moved/404 URLs are noted per topic.
No fabricated citations; anything not read today is listed as "assumed" in §Verified vs assumed.

## Sources consulted

| # | URL | Digest |
|---|-----|--------|
| 1 | https://supabase.com/docs/guides/local-development/database-migrations | Local workflow: `supabase migration new` → `supabase/migrations/<timestamp>_<desc>.sql`; `db reset`; `supabase/seed.sql`; `supabase link --project-ref`; `db push`; `config.toml` from `supabase init`; diff engines (pg-delta vs migra). |
| 2 | https://supabase.com/docs/guides/deployment/database-migrations | `db push` compares `supabase/migrations/` against the `supabase_migrations.schema_migrations` tracking table and runs only unapplied files, in order; `--include-seed`; never edit the remote DB directly (push fails with sync errors); `migration repair`/`migration list`. |
| 3 | https://supabase.com/docs/guides/database/connecting-to-postgres | Connection-method table (serverless → shared pooler **transaction mode**); URL formats and ports; username rules; IPv4/IPv6; Prisma uses `pgbouncer=true` in transaction mode; serverless client guidance. |
| 4 | https://supabase.com/docs/guides/database/connecting-to-postgres/pooling-and-limits | Shared pooler (Supavisor, every plan, IPv4-only) vs dedicated pooler (PgBouncer, Pro+); client vs backend connection limits. |
| 5 | https://supabase.com/docs/guides/database/prisma | Supabase's Prisma quickstart: session-pooler string in `.env`; serverless "you'll also need your Transaction pooler string" (port 6543); direct string valid on IPv6/IPv4 add-on. |
| 6 | https://supabase.com/docs/reference/cli/supabase-db-push | CLI reference: "Pushes all local migrations to a remote database"; requires `supabase link`; first run creates the history table; `--dry-run`, `--db-url`, `--include-seed` flags. |
| 7 | https://www.prisma.io/docs/orm/v6/overview/databases/supabase | Prisma v6 + Supabase: `DATABASE_URL` = transaction pooler `:6543` + `?pgbouncer=true`; `DIRECT_URL` = direct or session pooler for the CLI; "serverless solutions will inevitably require connection pooling". |
| 8 | https://www.prisma.io/docs/orm/v6/overview/databases/postgresql | `datasource` block with `provider = "postgresql"`; connection-URL arguments (`connection_limit`, `schema`); PG↔Prisma type mapping. |
| 9 | https://www.prisma.io/docs/orm/v6/reference/prisma-cli-reference | `migrate diff` sources (`--from-empty`, `--to-schema`, `--from-migrations`), `--script`; both sources must use the same provider; notes Prisma 7 flag removals. |
| 10 | https://www.prisma.io/docs/orm/v6/reference/prisma-schema-reference | DateTime default on PG = `timestamp(3)`; `timestamptz(x)` ↔ `@db.Timestamptz(x)`; Prisma Client maps DateTime to JS `Date`. |
| 11 | Local: `bunx prisma migrate diff --help` (prisma 6.11.1) | Installed-CLI truth: `--from-empty` = "assume … empty datamodel"; `--to-schema-datamodel` = "path to a Prisma schema file, uses the datamodel"; `--script` = SQL script to stdout; command is read-only; `package.json#prisma` deprecated in Prisma 7. |
| 12 | https://vercel.com/docs/environment-variables | Environments: Production / Preview / Custom / Development semantics; encrypted at rest; 64 KB total limit; changes apply only to new deployments. |
| 13 | https://vercel.com/docs/environment-variables/framework-environment-variables | `NEXT_PUBLIC_` prefix is the Next.js mechanism for client-visible vars; Vercel auto-prefixes system vars for prod/preview but not locally. |
| 14 | https://vercel.com/docs/environment-variables/sensitive-environment-variables | Config vs Secret (Secret is write-only after saving; for passwords/API keys/tokens); build-log redaction ≥32 chars; "Separate Production Secret Values" policy. |
| 15 | https://vercel.com/docs/deployments/preview-deployments | Three default environments (Local/Preview/Production); custom environments define their own vars "like database connection information or API keys"; branch-specific preview vars override preview defaults. |
| 16 | https://vercel.com/docs/functions/runtimes/bun | Bun runtime for Vercel Functions is **Beta** on all plans; `bunVersion` in `vercel.json` (`"1.4.x"`/`"1.x"` only); Next.js would need `bun run --bun next build/dev`; middleware needs `nodejs` runtime. |
| 17 | https://vercel.com/changelog/bun-install-is-now-supported-with-zero-configuration | `bun.lockb` detected → `bun install` is the default Install Command; impacts build phase only, functions stay Node.js. |
| 18 | https://vercel.com/changelog/buns-text-lockfile-is-now-supported-with-zero-configuration | Text `bun.lock` (Bun ≥1.1.39, default in 1.2) also zero-configuration. |
| 19 | https://vercel.com/kb/guide/how-to-pin-a-specific-bun-version-for-vercel-builds | Pin Bun for builds via Install Command `bunx bun@x.x.x install` (Project Settings or `vercel.json`). (Page partially JS-rendered; key guidance extracted. Confidence: medium.) |
| 20 | https://docs.github.com/en/get-started/importing-your-projects-to-github/importing-source-code-to-github/adding-locally-hosted-code-to-github | Import flow: `git init -b main` → `git add .` → `git commit` → `git remote add origin REMOTE-URL` → `git remote -v` → `git push -u origin main`; warning: never push secrets. |
| 21 | https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository | Visibility is chosen explicitly (URL-query default is `public`); when importing, do not pre-create README/.gitignore/license (merge conflicts). |
| 22 | https://docs.github.com/en/code-security/secret-scanning/about-secret-scanning | Public repos: scanned free, automatically. Org-owned private/internal: requires GitHub Secret Protection on Team or Enterprise Cloud. User-owned private repos: not covered on Free. |
| 23 | https://docs.github.com/en/code-security/secret-scanning/push-protection-for-repositories-and-organizations | Push protection is disabled by default (repo/org/enterprise levels); blocks generic secrets incl. private keys and database connection strings; "push protection for users" covers public repos only. |
| 24 | https://github.com/oven-sh/setup-bun (README) | `oven-sh/setup-bun@v2`; version resolution: `packageManager` field → `engines.bun` → `latest`; `bun-version-file`; registry inputs. |

Moved/unreachable URLs (checked today): `supabase.com/docs/guides/deploying/database-migrations` → 404 (content at source #2);
`supabase.com/docs/guides/database/connection-strings` and `/guides/database/pooler` → 404 (content merged into sources #3/#4);
`prisma.io/docs/guides/integrations/supabase` → 404 (v6 content at source #7; unversioned Prisma docs now default to ORM 8);
`vercel.com/docs/runtimes/bun` and `/docs/frameworks/bun` → 404 (current page is source #16). Fallbacks used; confidence high except where noted.

## Topic findings

### 1. Supabase database migrations
- **Verified:** Migrations are plain SQL files in `supabase/migrations/` named `<timestamp>_<description>.sql`
  (e.g. `20250101000000_create_employees_table.sql`). `supabase db push` (after `supabase login` +
  `supabase link --project-ref <ref>`) applies exactly those files: it diffs the folder against
  `supabase_migrations.schema_migrations` and runs only unapplied files, in order (sources #1, #2, #6).
  So yes — plain SQL files in `supabase/migrations/` are applied by `db push`; no Prisma runtime is involved.
  `config.toml` is created by `supabase init` and configures the local stack (ports, auth providers, storage);
  it is not the migration format. `--dry-run` prints what would run; `--include-seed` pushes `supabase/seed.sql`.
- **ASAS application:** `supabase/migrations/20261030000001_init.sql`, `20261030000002_business_constraints.sql`, `20261030000003_rls_policies.sql`
  are the canonical chain; `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` §3 already documents `supabase link` + `db push`.
  ⚠ Deviation: our prefixes are `0001_…` sequence numbers, not the documented timestamp convention — see
  "Verified vs assumed" (needs a `--dry-run` check; `0002` must never be edited in place, only superseded).
  `supabase/config.toml` is hand-authored (its own header says it was not runtime-validated — no Docker in the
  packaging environment).

### 2. Supabase connection strings
- **Verified:** Three modes (source #3): direct `postgresql://postgres:[pw]@db.[PROJECT-REF].supabase.co:5432/postgres`
  (IPv6 by default; IPv4 only with the add-on); shared pooler **session** mode
  `postgresql://postgres.[PROJECT-REF]:[pw]@[POOLER-HOST]:5432/postgres` (IPv4, supports prepared statements); shared
  pooler **transaction** mode — same but port **6543** (IPv4, no prepared statements; Prisma sets `pgbouncer=true`).
  Pooler host is `aws-[INDEX]-[REGION].pooler.supabase.com` and cannot be composed from the region — copy it from
  the dashboard Connect dialog. Username on pooler connections is `postgres.[PROJECT-REF]` (vs `postgres` direct).
  Supabase's method table maps **serverless/edge functions → transaction mode**; migrations/pg_dump → direct.
- **ASAS application:** `.env.example` and `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` §7 currently recommend the **Session
  Pooler (5432)** as `DATABASE_URL` for Vercel. That is valid (session mode supports prepared statements, IPv4) and
  matches Supabase's Prisma quickstart for server-based deployments, but Prisma's own v6 Supabase guide (#7)
  recommends transaction mode `:6543` + `?pgbouncer=true` for the runtime URL with `DIRECT_URL` for the CLI — see
  decision impact. `src/lib/db.ts` already instantiates `PrismaClient` once at module scope (matches the documented
  serverless client guidance).

### 3. Prisma 6 + PostgreSQL
- **Verified:** Provider switching = edit the `datasource db { provider = … }` block (#8); the repo's two-schema
  pattern (SQLite authoritative, PostgreSQL rendering) is a supported configuration, not a hack. `prisma migrate diff`
  semantics (#9, #11): `--from-empty` assumes an empty datamodel as the source; `--to-schema-datamodel <file>` (the
  flag of installed 6.11.1; current docs render it as `--to-schema`) uses the schema's datamodel as the destination;
  `--script` renders SQL to stdout; the command is read-only; both sources must use the same provider — an
  empty→`schema.postgres.prisma` diff is provider-consistent and yields the full PostgreSQL DDL.
  `@db.Timestamptz(x)` maps to `timestamptz(x)` columns; DateTime's PG default is `timestamp(3)` (no tz); Prisma
  Client still reads/writes JS `Date` either way (#10). Prisma↔Supabase recommendation (#7): pooled
  `DATABASE_URL` (+`pgbouncer=true`), direct `DIRECT_URL` for CLI/migrations.
- **ASAS application:** `prisma/schema.postgres.prisma` already annotates DateTime fields `@db.Timestamptz(3)`
  (documented native type) and keeps enums as String+CHECK (ADR-001). `20261030000001_init.sql` is documented as
  Prisma-engine-generated DDL — regeneration uses exactly the verified `migrate diff --from-empty
  --to-schema-datamodel prisma/schema.postgres.prisma --script` command. Note: the schema header references
  `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md`, which does **not exist** in the repo — a documentation gap to fix at handoff.

### 4. Vercel environment variables
- **Verified (#12–#15):** Four scopes — Production (deployments from the production branch), Preview (all
  non-production branches; branch-specific values override preview defaults), Custom (Pro+, own vars/domains),
  Development (local, via `vercel env pull`). `NEXT_PUBLIC_` is required for anything the Next.js browser bundle
  must see; server-only values must not carry it. Values are encrypted at rest; **Secret** type values are
  write-only after saving (for passwords/API keys/tokens) and are redacted from build logs (≥32 chars).
  Env-var changes apply only to *new* deployments. Preview/prod data separation is achieved by giving each
  environment its own `DATABASE_URL` (custom environments exist exactly for "database connection information").
- **ASAS application:** `.env.example` defines `DATABASE_URL`, `ASAS_SESSION_SECRET` (→ Vercel **Secret**, scoped
  Production), `ASAS_DEMO_MODE=0` (Production only — the file itself warns demo mode is an account-takeover vector).
  No `NEXT_PUBLIC_*` variables exist in `src/` today (verified by grep) — keep it that way; nothing in the CRM
  should ship to the browser. Preview deployments should point at a separate Supabase project or branch-scoped
  preview `DATABASE_URL`, never the production database.

### 5. GitHub import, private defaults, secret protection
- **Verified (#20–#23):** The documented import flow is `git init` (skip — repo already has history) →
  `git add .` → `git commit` → create an **empty** repo on GitHub (choose visibility explicitly; the form default
  is public; do not pre-create README/.gitignore/license) → `git remote add origin <URL>` → `git push -u origin main`.
  Secret scanning runs free/automatic on **public** repos; org-owned **private** repos need GitHub Secret
  Protection (Team or Enterprise Cloud); user-owned private repos on Free get neither. Push protection is disabled
  by default and blocks generic secrets (private keys, **database connection strings**) once enabled.
- **ASAS application:** `.git` exists with full history and **no remote** (verified: `git remote -v` empty) — so the
  handoff is exactly the `remote add` + `push -u origin main` tail of the flow. On a Free personal account, a
  private ASAS repo gets **no** push protection — `.gitignore` already excludes `.env*` (only `.env.example`
  whitelisted) and `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` is the compensating control; enable Secret Protection +
  push protection if the repo lands under a Team/Enterprise org.

### 6. Bun on Vercel and CI
- **Verified (#16–#19, #24):** Vercel auto-detects Bun as the **package manager** from `bun.lockb` or text
  `bun.lock` and runs `bun install` with zero configuration (build phase; functions still run Node.js). Running
  functions on the Bun runtime is a separate, **Beta** feature (`bunVersion: "1.4.x"|"1.x"` in `vercel.json`).
  Pinning a Bun version for builds = Install Command `bunx bun@x.x.x install`. In GitHub Actions,
  `oven-sh/setup-bun@v2` resolves version from `packageManager` → `engines.bun` → `latest`, or `bun-version-file`.
- **ASAS application:** `bun.lock` (text) at repo root → zero-config `bun install` on Vercel. Do **not** set
  `bunVersion` (Beta) — keep the Node.js runtime for the Next.js build. `.github/workflows/ci.yml` already uses
  `oven-sh/setup-bun@v2` with `bun-version: latest`; `package.json` has **no** `packageManager`/`engines.bun`
  field, so CI and Vercel may resolve different Bun versions — pin one (see decision impact).

## Verified vs assumed

| Capability | Status | Basis |
|---|---|---|
| `supabase db push` applies plain SQL files from `supabase/migrations/`, in order, skipping applied ones | **Verified** | Sources #2, #6 |
| Migration filename convention `<timestamp>_<desc>.sql` | **Verified** (documented convention) | Sources #1, #2 |
| `0001_`/`0002_`/`0003_` (non-timestamp) prefixes accepted by `db push` | **Assumed** — docs only show timestamp prefixes and "applied in timestamp order"; must confirm with `supabase db push --dry-run` | Gap between repo naming and docs |
| Hand-authored `supabase/config.toml` works for local stack / `db push` | **Assumed** — file header itself says not runtime-validated (no Docker) | Repo header |
| Connection modes, ports (5432/6543), usernames, pooler host format | **Verified** | Source #3 |
| Serverless → transaction-mode pooler; Prisma `pgbouncer=true` | **Verified** | Sources #3, #7 |
| `pgbouncer=true` needed for classic (non-driver-adapter) Prisma engine on transaction mode | **Assumed** (docs frame it for driver-adapter clients; session mode avoids the question) | Source #7 wording |
| `migrate diff --from-empty --to-schema-datamodel --script` flags & semantics | **Verified** (installed 6.11.1 CLI help + v6 docs; docs now render `--to-schema`) | Sources #9, #11 |
| `@db.Timestamptz(x)` ↔ `timestamptz(x)`; JS `Date` client mapping | **Verified** | Source #10 |
| Vercel env scopes, `NEXT_PUBLIC_` rule, Secret write-only/redaction, 64 KB limit | **Verified** | Sources #12–#14 |
| Preview/prod data separation via per-environment `DATABASE_URL` | **Verified** | Source #15 |
| GitHub import flow (`remote add` + `push -u origin main`); empty-repo creation; public form default | **Verified** | Sources #20, #21 |
| Secret scanning/push protection unavailable for private repos on Free personal accounts | **Verified** | Sources #22, #23 |
| Vercel zero-config `bun install` from text `bun.lock`; Bun *runtime* is Beta | **Verified** | Sources #16–#18 |
| Pinning Bun on Vercel via `bunx bun@x.x.x install` | **Verified, medium confidence** (KB page partially JS-rendered) | Source #19 |
| Vercel behavior with Next.js 16 + `output: "standalone"` (build/deploy specifics) | **Not researched** (outside assigned topics) | — |

## Decision impact (handoff decisions grounded by this research)

- **GitHub import:** create an explicitly-**private**, empty GitHub repo (no pre-init README/.gitignore — docs warn
  of merge conflicts), then `git remote add origin <url>` + `git push -u origin main` per docs.github.com flow #20.
- **Secret protection:** on Free personal accounts nothing scans the private repo — treat `.env*` gitignore +
  `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md` as the guard; if an org repo, explicitly enable Secret Protection + push
  protection (off by default) before first push (#22, #23).
- **Schema deploy route:** apply the canonical chain via `supabase link --project-ref <ref>` +
  `supabase db push --dry-run` then `supabase db push`; never edit the remote schema via SQL editor — it breaks
  `db push` sync (#2, #6). Wire this into `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/SUPABASE_SETUP.md` §3 as the only sanctioned path.
- **Migration naming:** before the real push, verify `0001/0002/0003_` prefixes via `--dry-run`; if rejected, rename
  to timestamped prefixes in one commit (documented convention #1/#2). Never edit `0002` in place — supersede it.
- **Runtime connection URL (owner decision):** `.env.example`/`SUPABASE_SETUP.md` §7 say Session Pooler (5432);
  current Prisma v6 Supabase guidance says Transaction pooler (6543) + `?pgbouncer=true` for serverless, with
  `DIRECT_URL` (session pooler or direct) for CLI/migrations (#7). Update both files to state the chosen pattern
  and why; if staying on session mode, document that prepared statements work there (#3).
- **Vercel env scoping:** `ASAS_SESSION_SECRET` and the DB password as **Secret** type, Production-scoped;
  `ASAS_DEMO_MODE=0` Production-scoped; a separate preview `DATABASE_URL` (distinct Supabase project or
  branch-scoped preview variable) so preview traffic never touches production data (#12–#15).
- **No client-exposed config:** keep all ASAS secrets server-only (no `NEXT_PUBLIC_*` — none exist today, verified
  by grep of `src/`) (#13).
- **Bun on Vercel:** rely on zero-config `bun install` from the committed text `bun.lock`; do **not** set
  `bunVersion` (Bun functions runtime is Beta) — Node.js runtime for Next.js (#16–#18).
- **Pin Bun once:** add `packageManager: "bun@<version>"` (or `.bun-version` file) so `oven-sh/setup-bun@v2` in
  `.github/workflows/ci.yml` and Vercel's build resolve the same Bun instead of `latest` (#19, #24).
- **Docs gap:** create the referenced-but-missing `05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md` (or fix the references
  in `prisma/schema.postgres.prisma` / `supabase/config.toml`) so the documented regeneration command
  (`prisma migrate diff --from-empty --to-schema-datamodel … --script`) is discoverable at handoff (#9, #11).
