# ASAS CRM — Workstream S Implementation Brief (security remediation: reservation financial-field minimization)

**Created:** 2026-10-26 (task `UX-OWNER-DECISION-CLOSE-3`, Case B — documentation-only round).
**Status:** **AUTHORIZED AND EXECUTED** (2026-10-26, task `WS-S-EXEC` — the "Owner Decision Closure
and Authorized Workstream S Execution" directive, register §1c decision 7: "The owner explicitly
authorizes implementation of the reservation financial-data exposure fix described below. This is
the only authorized application-code workstream in this execution."). The §1c record supersedes the
NOT-AUTHORIZED status below. The execution's file inventory, verification evidence, and independent
review verdict live in §9 (change history) and the worklog `WS-S-EXEC` entry.

**Superseded status (kept per the append-only law):** the CLOSE-3 round's brief carried
**IMPLEMENTATION BRIEF — NOT AUTHORIZED** — the owner's decision-form results did NOT arrive with
that directive (the "owner's binding answers" section carried only the unfilled placeholder;
`upload/` contained no new owner file — newest entries remain the two byte-identical 2026-10-25
directive copies). Per the binding law ("do not interpret a recommendation, default selection, prior
agent report, or inferred business preference as owner approval"), **Workstream S was NOT authorized
and NO application source was edited in that task.** That round delivered this narrowly-scoped
implementation package awaiting exactly one thing: **the owner's explicit authorization** — which
arrived with the WS-S-EXEC directive (§1c.1 #7).

**Governing decisions:** FIN-MIN-Q10 (owner-approved direction, 2026-10-26 — server-side response
minimization; UI hiding insufficient) · D-021 (record scoping — untouched, second layer only) ·
register law §3-4 (never broaden commission/incentive visibility; server authorization
authoritative). **Canonical field-by-role matrix:** `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/ROLE_DATA_VISIBILITY_MATRIX.md`
2026-10-26 addendum (source of truth for every cell below — this brief does not re-adjudicate any
cell). **Plan home:** `NEXT_PHASE_PLAN.md` §6 (v2).

---

## 1. Objective (verbatim from the CLOSE-3 directive, Case A branch — restated here as the brief's target)

Prevent `SALES_AGENT` and `FIELD_REP` responses from receiving restricted reservation
commission/incentive fields, on **both `GET /api/reservations` and `POST /api/reservations`**, while
preserving authorized access and existing behavior for `MANAGER` and higher roles. Key-level
**absence** — returning `null`/`undefined`/empty-string/redacted placeholders does NOT satisfy the
requirement.

## 2. Verified exposure (re-verified read-only at HEAD `cd7a725` on 2026-10-26 — identical to the 494b87a evidence base; zero src changes exist between the two)

| Surface | Verdict | Live evidence (file:line at `cd7a725`) |
|---|---|---|
| `GET /api/reservations` | **LEAK** | `src/app/api/reservations/route.ts:76` `requireUser()` with no role argument → every authenticated role; `:112-116` `db.reservation.findMany({ where, orderBy, include: reservationInclude })` — **`include`, not a field-level `select`** → ALL Reservation scalar columns serialized; `:118-119` `withAgents()` spreads every row field (`:65-69` `...r`) + adds `agent`/`incentiveDecidedBy` joins; `ok({ data, total })` |
| `GET` query variants | **LEAK on all four** | `?status=` `:84-85` · `?apartmentId=` `:91-95` (adds implicit `status: "ACTIVE"`) · `?opportunityId=` `:100-101` · `?id=` `:109-110` — each INTERSECTS the D-021 `reservationScope` row set but NONE restricts fields by role |
| `POST /api/reservations` (201) | **LEAK** | `:138` `requireUser()` no role gate; `:189-194` `tx.reservation.update/create({ …, include: reservationInclude })` returns the full model; `:239-240` `withAgents([reservation])` → `ok({ reservation: withAgent }, 201)` |
| `GET /api/reservations/[id]` | N/A | No GET handler (PATCH-only route file → 405) — confirmed unchanged |
| Row scoping (D-021) | INTACT (not the defect) | `reservationScope`, `src/lib/server/visibility.ts:138-149` (agent: own agentId ∨ unassigned ∨ own/pool opportunity; FIELD_REP: project-derived; MANAGER+: org) |

**The exposed field inventory (derived from the LIVE schema, `prisma/schema.prisma:563-626`):**
§37 commission family — `commissionAmount` (597) · `commissionFrom` (598) · `commissionBasis` (605) ·
`commissionStatus` (606) · `commissionEarnedAmount` (607) · `commissionReceivedAmount` (608) ·
`commissionReceivedAt` (609); §38 incentive family — `agentIncentive` (599) · `incentiveBasis` (610) ·
`incentiveStatus` (611) · `incentiveDecidedById` (614) · `incentiveDecidedAt` (615) ·
`incentivePaidAt` (616); plus the derived join `incentiveDecidedBy {id,name}` added by `withAgents`
(`:68`). Also serialized today but **staying** per the matrix: booking facts `amount` (575) /
`depositPaid` (576) (RECOMMENDED in-scope — the owner may narrow later, NOT part of S) and workflow
facts `status`/`expiresAt`/`notary`/`contractRef`/`reason`/closure stamps (577-592 — floor-tier
closure-workflow necessity). **Do not use any invented or truncated field list — this inventory is
schema-derived and must be re-derived from the live schema at implementation time.**

## 3. Exact affected files (change inventory)

| # | File | Change |
|---|---|---|
| 1 | **`src/app/api/reservations/route.ts`** | The ONLY route file edited. GET: keep `requireUser()`, D-021 conditions, sweeper, query variants byte-identical; replace the raw `findMany({ include })` result serialization with the DTO helper (§4). POST: keep the transaction, guards, activity/audit writes byte-identical; serialize the returned row through the same DTO. `withAgents` stays for the manager path (or moves inside the DTO module — implementer's choice, single-consumer rule). |
| 2 | **`src/lib/server/reservation-dto.ts` (NEW)** | One shared role-aware serializer: `reservationDto(user, row)` (or `reservationListDto`) — mirrors the dashboard's proven field-selection + null-gating pattern (`src/app/api/dashboard/route.ts:272-511`). Branch on `atLeastRole(user.role, "MANAGER")` (ROLE_RANK ≥ 70 — `src/lib/constants.ts:354-368`). Manager branch: today's full shape (all fields + joins) — shape-stable. Floor branch: workflow + booking facts + `agent` join ONLY; every §37/§38 key **omitted at construction** (never set to null). |
| 3 | **`src/lib/client/types.ts`** | `Reservation` (line 623): the §37/§38 members are ALREADY optional (`commissionAmount?: number | null`, `:652-654`…) — verify no consumer requires them non-optional; adjust only if compilation demands (expected: zero edits). |
| 4 | **`src/components/crm/pipeline/deal-economics-agent.tsx`** (re-check, likely edit) | The agent branch reads `r.incentiveStatus`/`r.agentIncentive`/`r.incentiveBasis`/`r.incentivePaidAt` from the reservation row (`:53-71`). After S, those keys are absent for agents → the branch must render from the compensating source. **RECOMMENDED (engineering-spec, flagged in NP§6.3-2): the clean dashboard aggregate** ("Mes incentives" — pure aggregate, no record ids, `dashboard/route.ts:385-411`) OR an explicit per-role own-row incentive allowance — the latter would be an owner-visible semantics change and must NOT be chosen silently (the matrix's SALES_AGENT cell says raw values are removed). Default per the matrix: agent branch renders the aggregate or an honest static. |
| 5 | **`src/components/crm/pipeline/deal-economics.tsx` / `deal-economics-manager.tsx`** (re-check) | Manager branch unaffected (manager keeps full shape). Verify the `atLeastRole(session?.user?.role, "MANAGER")` gate (`deal-economics.tsx:32`) still routes correctly; no expected edit. |
| 6 | **`src/components/crm/properties/apartment-detail-dialog.tsx`** (re-check) | Consumes `GET ?apartmentId=` (`:126-128`) + POST (`:176`) — reads booking facts + status only (stays serializable). No expected edit; regression-verify only. |
| 7 | **`src/components/crm/audit/audit-target-overlay.tsx`** (re-check) | Consumes `GET ?id=` (`:281-282`) to resolve reservationId → opportunityId — reads `id`/`opportunityId` (workflow fields, stay). No expected edit; regression-verify only. |
| 8 | **New probe script** (`tmp-scripts/` scratch pattern, per the standing suite convention) | The absence-battery (§5). |
| 9 | **`docs/`** (same-session documentation duty) | Matrix addendum status flips (defect → fixed at named HEAD) · STATE/ROADMAP/CHECKPOINT/worklog per AGENTS.md documentation duties. |

**Explicitly NOT touched:** financial calculations · D5/D6 semantics · visit-gate rules · closure
semantics · `reservation-lifecycle.ts` · `reservation-economics.ts` · seeds · fixtures · secrets ·
environment flags · scheduler jobs · Git remotes · deployment config · any migration (see §7).

## 4. Implementation shape (the serializer contract)

1. **Role-aware explicit serialization** — build each response object field-by-field; never
   serialize a complete ORM model and rely on the UI to hide restricted fields.
2. **Single shared helper** consumed by BOTH the GET paths and the POST 201 path — no per-variant
   duplication that could drift.
3. **Manager+ branch is shape-stable**: same keys as today (including `incentiveDecidedBy` join),
   byte-comparable shape. Any shape change requires source evidence + explicit approval (none
   anticipated).
4. **Floor branch (SALES_AGENT/FIELD_REP)**: keys = `id`, `orgId`, `opportunityId`, `apartmentId`,
   `agentId`, `agent` (join), `amount`, `depositPaid`, `status`, `expiresAt`, `notary`,
   `contractRef`, `reason`, closure stamps, `createdAt`, `updatedAt`, + the existing
   `opportunity`/`apartment` include sub-selects. §37/§38 keys: **absent at construction**.
5. **Record-scope law:** the DTO is a SECOND layer on top of `reservationScope` — do not broaden or
   narrow the row set; do not weaken org/owner/agent/record-scope checks; ghost-404 semantics
   unchanged.
6. **Audit law:** the remediation adds NO new audit event (it narrows serialization, not writes —
   matrix addendum).

## 5. Tests (the regression battery — every role × method × variant)

1. **Absence probes (the core):** for SALES_AGENT and FIELD_REP — `GET /api/reservations` (unfiltered),
   `GET ?status=ACTIVE`, `GET ?apartmentId=…`, `GET ?opportunityId=…`, `GET ?id=…`, and
   `POST /api/reservations` (201) — assert EVERY §37/§38 key is **absent from the serialized JSON**
   (`!("commissionAmount" in row)` etc. — key-level, not value-level; NOT `=== null`/`undefined`).
   Derive the key list from the live schema at implementation time (§2 inventory as the checklist).
2. **Authorized-manager presence probes:** same six calls as MANAGER (and one OWNER/ADMIN sample) —
   assert the §37/§38 keys are PRESENT with today's shape (regression pair with 1).
3. **Record-scope enforcement probes:** cross-org reservation id → empty list/404 byte-identical;
   peer-agent out-of-scope row not returned (D-021 unchanged proof, both directions).
4. **My Day aggregate regression pair:** the agent's clean dashboard aggregate ("Mes incentives")
   still renders — the aggregate source is untouched; the agent cockpit branch (file #4) still shows
   the honest surface (aggregate or static per the implemented choice).
5. **UI consumer regression:** apartment dialog reservation block, audit-target-overlay reservation
   hop, manager economics form round-trip (read → PATCH → read) — all functional; E2E console-0;
   AR-RTL + 390px.
6. **Standing suites re-run at the named HEAD:** the 325-probe visibility matrix + Wave/Phase-D/D7
   suites (commit-anchored until the environment recovery, §7-prereq-2 — see the honest-limitation
   note below).
7. **Residue witness:** byte-exact audit/activity deltas (logins only) per the standing law.

**Testing prerequisites & the honest limitation:** the DB is currently EMPTY (0 rows all tables,
`_prisma_migrations` MISSING — R13 signature, re-verified 2026-10-26) and the canonical recovery is
separately authorized. Options for the implementation task (in preference order): (a) execute AFTER
the separately-authorized canonical recovery (AGENTS.md recipe) and run the full battery + standing
suites on the recovered baseline; (b) if authorized without recovery, use isolated scratch-org
fixtures (the established org-2 twin pattern) with byte-exact residue sweeps — and REPORT which
suites could not be re-run. **Never recover/seed the DB merely for convenience, and never report an
unexecuted test as passed.**

## 6. Acceptance criteria (definition of done)

1. Floor-role API responses (all six surfaces in §5-1) contain ZERO §37/§38 keys — byte-level
   assertion, key-absence not null.
2. MANAGER+ response shape unchanged (byte-comparable key set vs pre-change snapshot on identical
   rows).
3. D-021 record scoping unchanged (scope probes green; no broadening/narrowing).
4. My Day agent aggregate intact; agent cockpit branch renders its honest post-S surface.
5. All standing suites green at the named HEAD (or the un-run set honestly reported with the
   environment blocker).
6. Browser E2E console-0 on the affected surfaces; AR-RTL + 390px clean.
7. Independent read-only security review (the CLOSE-3 Case-A reviewer checklist): no restricted
   property leaks through either route; no route variant or post-create path bypasses the
   serializer; record access not unintentionally broadened/narrowed; D-021 + manager behavior
   intact; tests assert serialized-JSON key absence; no unrelated files changed. Material findings
   resolved BEFORE claiming completion.
8. Documentation updated in-session (matrix addendum status flip + STATE/ROADMAP/CHECKPOINT +
   worklog + conventional commit).

## 7. Constraints & rollback

- **Migration-free by design:** schema and data untouched; if any schema change appears necessary
  during implementation, STOP and request separate owner approval (the CLOSE-3 law).
- **Rollback:** the change is one route file + one new serializer module (+ optional agent-branch
  consumer fix) — documented single-commit revert restores today's behavior exactly; the probe
  script is scratch. No data migration to unwind.
- **Ordering law:** S is FIRST among implementation phases — never scheduled behind visual redesign
  (roadmap dependency edge). S may proceed in parallel with spec-finalization work but NOT after F.
- **Out of scope (hard):** visit gate, broad authorization redesign, D5/D6 implementation, UX
  redesign, database recovery, cleanup, financial calculations, closure semantics, fixtures, seeds,
  secrets, environment flags, scheduler jobs, Git remotes, deployment.

## 8. Prerequisites (the exact remaining list)

1. **Owner authorization** — ~~**Status: NOT GIVEN**~~ **STATUS: GIVEN — 2026-10-26 (register §1c.1
   decision 7; the WS-S-EXEC directive's explicit Workstream-S authorization; executed the same
   round).** The historical CLOSE-3 state is kept below per the append-only law: the decision-form
   results did not arrive (placeholder unfilled; no new upload) — that was the only blocking
   owner-decision prerequisite, now closed.
2. (For full verification) **Canonical environment recovery under its own authorization** — or the
   §5 fallback with honestly-reported limitations. **STATUS during execution: NOT authorized
   (register §1c.1 decision 8 — "Database restoration, reset, reseeding, and recovery are not
   authorized")** → the §5-b isolated-fixture path was used with limitations disclosed in §9.
3. (Recommended, non-blocking) RQ-3's answer would remove the residual ambiguity about the agent
   own-incentive surface shape — but S itself is fully specified without it (the matrix's cell is
   decisive for S: raw values absent below MANAGER+; the aggregate stays). **STATUS: ANSWERED
   2026-10-26 (register §1c.1 decision 3 — keep the current representations; no new semantics).**

## 9. Change history

| Date | Event |
|---|---|
| 2026-10-26 | Brief created (UX-OWNER-DECISION-CLOSE-3, Case B) from the live tree at HEAD `cd7a725` — every file:line predicate re-verified this session (read-only). NP§6.3 remains the plan-level spec; this file is its execution package. |
| 2026-10-26 | **AUTHORIZED AND EXECUTED (task `WS-S-EXEC`)** — the owner's eight decisions arrived in-session (register §1c); Workstream S implemented: new shared role-aware serializer `src/lib/server/reservation-dto.ts` wired into the reservations GET (all four query variants), POST 201, AND the PATCH `[id]` adapter (both branches — the directive's §3 "every path" law; the brief's original GET/POST inventory was extended to the PATCH response surfaces after live re-inspection found the `request_closure` return — reachable by the responsible SALES_AGENT — also spread the full row); the agent cockpit branch (`deal-economics-agent.tsx`) renders the honest aggregate-pointer static per §3-item-4; the absence battery + manager-presence pair + D-021 probes + My Day aggregate regression executed against isolated scratch fixtures (decision 8: no DB recovery) with a byte-exact sweep back to the empty baseline; independent read-only security review APPROVED. Full evidence: worklog `WS-S-EXEC` + D-GOV-10 + the matrix addendum flip. |
