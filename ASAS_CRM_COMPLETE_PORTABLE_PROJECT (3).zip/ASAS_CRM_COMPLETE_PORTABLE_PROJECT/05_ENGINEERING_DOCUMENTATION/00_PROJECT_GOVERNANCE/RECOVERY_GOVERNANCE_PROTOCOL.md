# ASAS CRM — Engineering Recovery & Governance Protocol (Execution Record)

> **Adopted:** 2026-10-19 (Task GOV-1) — the owner's «Engineering Recovery & Governance Protocol» directive.
> **Role of this file:** the protocol's execution anchor — mode declaration, stage tracker, deliverable mapping,
> evidence ledger, and audit plan. It complements (never replaces) `AGENTS.md` and `MASTER_ENGINEERING_STATE.md`
> in the orientation chain. Existing specialist docs remain the sources of truth for their domains; this file maps
> the protocol's required deliverables onto them and tracks what must still be produced or refreshed.
>
> **Mission:** recover ASAS CRM from implementation-led development into an evidence-based, documented,
> incrementally maintainable system. **Scope: CRM only** (no ERP — D-025). Agency commissions and
> sales-representative incentive status remain commercial CRM data.
>
> **Non-negotiable rule (as adopted 2026-10-19):** ~~no new features, no broad refactoring, no schema
> changes, until the Stage 2 audit and the Stage 4 architecture review are approved~~ — **the approval
> condition is now MET (D-GOV-5, 2026-10-19)**; the rule survives as: no changes OUTSIDE a named GOV-5
> roadmap task (§1 controlled-implementation mode). A check is only "passed" if it was actually executed and
> its result observed. Confirmed defects are distinguished from hypotheses everywhere.

## 1. Current mode: CONTROLLED IMPLEMENTATION (owner-ratified)

- **Transition 2026-10-19 (D-GOV-5):** the owner ratified D-GOV-4 and authorized proceeding from planning into
  controlled implementation per the GOV-5 roadmap. The read-only audit mode (in force since 2026-10-19 Stage 1)
  is ENDED. Permitted writes now: everything of the audit mode PLUS `src/`/`prisma/` changes — but **only as
  execution of a named GOV-5 roadmap task** (G5-P#-#), under §4 change control, each paying the full gate toll
  (lint 0 · tsc tolerated-4/src 0 · visibility matrix all-pass incl. new probes · console 0 · baseline
  byte-exact unless the task itself legitimately changes business data — then the delta is documented).
- **Standing rules that survive the transition:** one bounded task at a time · conventional commits ·
  never weaken tests/authorization/validation for a passing build · P0-class documented operational recovery
  (§5) · worklog + register discipline · the roadmap's ordering law (severity × proven reachability).
- **Nothing implementation-shaped is suspended mid-flight:** the owner-UI continuation plan
  (W1→P46 / W2→P47 / W3→P48) was already executed and verified (commits `5dcedad`, `4271809`, `af0c00e`;
  closure stamps `6546e3a`), as were P49–P53 (`cf0f990`…`ee46b47`). Standing owner gates remaining:
  deployment order · D-013 purge · channel ingestion (§9.5) — see `MASTER_ENGINEERING_STATE.md` §13.

## 2. Stage tracker

| Protocol stage | Status | Task ID | Output |
|---|---|---|---|
| 1 — Repository discovery | **COMPLETE** 2026-10-19 | GOV-1 (+GOV-1-b delegated inventory) | §6 evidence ledger + `worklog.md` GOV-1 |
| 2 — Evidence-based audit | **COMPLETE** 2026-10-19 | GOV-2 (+GOV-2-a/GOV-2-b delegated) | `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ARCHITECTURE_AUDIT.md` refreshed (19 findings, 231/231 matrix, B-1 runtime-confirmed) |
| 3 — Business & domain engineering | **COMPLETE** 2026-10-19 | GOV-3 | `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/WORKFLOW_SPECIFICATION.md` created (triangulated: code+probes+web receipts) · DOMAIN_MODEL & visibility matrix re-verified & refreshed |
| 4 — Architecture decision | **RATIFIED** 2026-10-19 (D-GOV-5 — the owner's written directive) | GOV-4 | `DECISION_LOG.md` **D-GOV-4** — incremental remediation inside the retained architecture; full rewrite rejected; module replacement held as tactic; no-middleware verdict KEEP; single-instance ACCEPTED (aligned w/ SQLite) |
| 5 — Remediation plan (P0–P5) | **COMPLETE** 2026-10-19 · **EXECUTING** (tiers P3–P4 unlocked by D-GOV-5) | GOV-5 | `MASTER_ENGINEERING_ROADMAP.md` restructured — REMEDIATION ROADMAP (P0–P5 tiers, 27 tasks w/ scope·deps·acceptance·validation·rollback·docs) + historical register retained |
| 6 — Execution governance | **ACTIVE** — controlled implementation per D-GOV-5 (roadmap order, §4 change control, gate toll per task) | all | this file + worklog discipline + bounded-task rule + the GOV-5 tier gates |

## 3. Deliverable mapping (protocol → existing docs — no duplicate sources of truth)

| Required deliverable | Adapted location | Status at GOV-1 |
|---|---|---|
| `AS_BUILT_ARCHITECTURE.md` | `05_ENGINEERING_DOCUMENTATION/01_SYSTEM_ARCHITECTURE/SYSTEM_ARCHITECTURE.md` | EXISTS — freshness verification in GOV-2 |
| `ARCHITECTURE_AUDIT.md` | `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ARCHITECTURE_AUDIT.md` (+ `docs/PHASE_2_ENGINEERING_AUDIT.md`, `RISK_REGISTER.md`) | EXISTS (Phase-2 era) — GOV-2 re-audit against current code |
| `DOMAIN_MODEL.md` | `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/DOMAIN_MODEL.md` (+ `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/DATABASE_DOMAIN_AUDIT.md`, `AGENCY_OPERATING_MODEL.md`) | **VERIFIED & REFRESHED (GOV-3)** — entity map now matches the 26 live models; state matrix updated to live code |
| `ROLE_PERMISSION_MATRIX.md` | `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/ROLE_DATA_VISIBILITY_MATRIX.md` + `AUTHORIZATION_MODEL.md` | **VERIFIED (GOV-3)** — 2 runtime-confirmed deviations annotated (F-02/F-14), stale rows refreshed |
| `WORKFLOW_SPECIFICATION.md` | `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/WORKFLOW_SPECIFICATION.md` (+ `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/USER_JOURNEYS.md` pointer) | **CREATED (GOV-3)** — the consolidated state diagrams w/ external verification receipts + OPEN DECISIONS register |
| `REMEDIATION_ROADMAP.md` | `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_ROADMAP.md` (legacy `ENGINEERING_ROADMAP.md` to be reconciled) | **RESTRUCTURED (GOV-5)** — P0–P5 remediation tiers prepended as the authoritative forward plan; legacy stub reconciliation noted; history retained |
| `DECISION_LOG.md` | `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md` (+ `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/UX_DECISION_LOG.md` for D-UX entries) | EXISTS — append protocol decisions (D-GOV-*) |
| `ENGINEERING_STATE.md` | `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_STATE.md` | EXISTS — this file is its governance companion |

Rule: when a GOV task lands a deliverable, older overlapping documents get a header pointer to the new
source of truth (no silent forks). ~~Reconcile the `MASTER_ENGINEERING_ROADMAP.md` / `ENGINEERING_ROADMAP.md`
duplicate in GOV-5.~~ **DONE (GOV-5, 2026-10-19):** the master roadmap is restructured into the P0–P5
remediation tiers + retained history; the legacy file is a redirect stub noting the restructure.

## 4. Change control (Stage 6 — until approval)

One bounded task at a time. Before editing: state objective, affected files, risks, acceptance criteria.
After editing: run the relevant checks, inspect the diff, report **actual** results, update docs.
Never weaken tests, authorization, or validation to obtain a passing build. Never combine unrelated
architectural changes. Conventional commits (`docs:` / `app:` / `db:` / `security:` / `chore:`).

## 5. P0 operational recovery executed (2026-10-19, GOV-1)

**Observed at open (the R25/R13-class environment reset, ~10th observed occurrence):**
`.env` reduced to `DATABASE_URL` only (`ASAS_SESSION_SECRET` missing → ephemeral-secret fallback in force);
DB schema-only with ALL 25 tables = 0 rows; zero migration bookkeeping (`migrate status`: 11 unapplied);
`migrate diff` datasource↔datamodel: "No difference detected" (no structural drift).

**Recovery per the binding AGENTS.md first-visit checklist** (secret value never printed, never committed):
fresh `ASAS_SESSION_SECRET` appended to git-ignored `.env` → dev server killed by PID (1177, port freed) →
`rm db/custom.db` → `bunx prisma migrate deploy` (11/11 applied) → `bunx prisma generate` →
`bun run db:seed` → subshell-detach restart.

**Post-recovery verification (all observed):**
`GET /` 200 · canonical baseline **byte-exact** `8/43/21/23/161/46/3/8/4/18`
(users/leads/opps/visits/activities/apartments/assignments/reservations/projects/tasks —
`tmp-scripts/count-baseline.ts`; full 25-table map in worklog GOV-1) · `migrate status` "up to date" ·
resurrection sweep ZERO zombies (D-041 law) · login smoke OWNER 200 → `/api/dashboard`, `/api/analytics`,
`/api/leads` all 200 with session cookie · unauthenticated `/api/dashboard` + `/api/analytics` → 401 ·
agent-browser render walk: login overlay (8 personas, a11y headings) → OWNER persona click → full dashboard
(9-view nav, h1, skip link) with **zero console errors**.
Known residue: `AuditLog` grows by append-only LOGIN telemetry rows (by design; the 10-number baseline
excludes audit).

## 6. Stage 1 evidence ledger (all executed & observed 2026-10-19)

- **Git:** branch `main`, HEAD `f4e3bf7`, working tree clean at open, no stash, **no remote configured**
  (local-only). Commit history: conventional, P34–P53 visible; the W1/W2/W3 continuation plan closed at `6546e3a`.
- **Stack:** Next.js 16.1.1 declared / 16.1.3 running · React 19 · TypeScript 5 · Tailwind v4 · shadcn/ui ·
  Prisma 6 + SQLite (`db/custom.db`) · TanStack Query/Table · zustand · zod v4 · framer-motion ·
  z-ai-web-dev-sdk (server-side only — boundary clean).
- **Surface:** single-route SPA (`/` only — the AGENTS.md invariant) · **59 API route handlers** ·
  248 src files ≈ 48.3k LOC · **26 Prisma models** · **11 migrations** (`0_init` → `p30_duplicate_management`) ·
  seed idempotent, time-relative (not byte-deterministic).
- **Auth:** custom HMAC-signed stateless cookie `asas_user` (httpOnly, lax, 30d; sessions voided by
  `passwordChangedAt`) · scrypt (N=16384) · per-email lockout 5/15min · CSRF `assertSameOrigin()` inside
  `requireUser()` AND `readJson()` (D-018/019/020) · **no `middleware.ts`** — all protection handler-level
  (57/59 authed routes per the GOV-1-b inventory).
- **Checks actually run:** `bun run lint` EXIT 0 (clean) · `bunx tsc --noEmit` exit 2 with **exactly the 4
  pre-classified tolerated errors** (`examples/websocket` ×2 missing socket.io deps; `skills/` ×2 — `src/` = 0
  errors) · `prisma migrate diff` datasource↔datamodel "No difference detected" · hardcoded-secret scan over
  `src/`: zero matches · `.env` git-ignored & untracked (only `.env.example` tracked) · `db/` git-ignored ·
  no `.github/`, no CI, no Dockerfile/deploy manifests (validation = the documented 5-gate protocol +
  53-probe matrix script, `TEST_STRATEGY.md` — automated test suites are environment-forbidden per the
  standing rule) · hygiene markers: 0 real TODO/FIXME/HACK/mock (placeholder hits are JSX attributes/i18n keys).
- **Documentation estate:** 17 engineering + 4 domain + 4 audits + 3 security + 1 database + 11 ux docs
  (mapped in §3).

## 7. Audit plan — the next safe steps

- **GOV-2 (evidence audit, read-only): COMPLETE 2026-10-19** — `05_ENGINEERING_DOCUMENTATION/06_FORENSIC_AUDITS/ARCHITECTURE_AUDIT.md` refreshed
  against the current code: 19 findings (F-01…F-19) with severity × impact × confidence + confirmed-vs-
  hypothesis labels; guard census deltas vs GOV-1-b = NONE (59 files / 77 handlers); verification receipts
  all executed (lint 0 · tsc 4 tolerated · matrix **231/231** · B-1 scope-leak **runtime-confirmed** via
  `tmp-scripts/gov2-b1-probe.ts` w/ exact-state cleanup · B-6 runtime-confirmed · agent-browser render walk
  console-0); Phase-2 audit fully dispositioned (10 fixed / 3 partial / 4 open / 3 by-design). Headline:
  server discipline verifiably strong; the two real defects are workflow-completeness (reservation
  lifecycle has NO UI writer — the money path) and the one unscoped bell aggregate (RESERVATIONS_EXPIRING).
- **GOV-3 (domain): COMPLETE 2026-10-19** — `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/WORKFLOW_SPECIFICATION.md` created as the
  consolidated source of truth (lead intake across the 13 live channels → qualification/assignment →
  the full visit matrix → pipeline → reservation/sale + §37/§38 economics → per-role access map),
  every claim triangulated per the owner's GOV-3 directive: live code/schema/probes (SOURCES == the
  13-source capture; VISIT_TRANSITIONS byte-verified; the 5 stale P2-c matrix rows dispositioned)
  + **external web receipts EXT-1…EXT-8** (Ouedkniss dominance; WhatsApp practice; **Algerian law
  11-04 art. 25 — the contrat de réservation is a real legal instrument**; two-sided commission
  practice; +213/5-6-7 numbering plan matching `src/lib/phone.ts`; DZD whole-dinar convention;
  industry pipeline benchmark; Algerian Meta-ads lead-gen reality). DOMAIN_MODEL.md entity map
  refreshed to the 26 live models (MARKETING/SalesTarget removed; 8 missing models added);
  ROLE_DATA_VISIBILITY_MATRIX.md: 2 runtime-confirmed deviations annotated (F-02 notifications,
  F-14 roster emails — fixes gated on Stage-4), stale rows refreshed (targets/collections removed
  D-025; check-duplicates → the P30/P53 machine). **6 OPEN DECISIONS registered explicitly**
  (free-form transitions intent · two-step win path · F-01 UI-writer product question · R5 holds ·
  inbound-channel ingestion · Arabic microcopy) — nothing invented, nothing auto-resolved.
- **GOV-4 (architecture decision): COMPLETE 2026-10-19** — `DECISION_LOG.md` **D-GOV-4** (the protocol's
  own deliverable per §3): incremental refactoring vs individual-module replacement vs full rewrite,
  scored across the seven mandated dimensions (defects · data integrity · security · change risk ·
  migration cost · testability · maintainability) → **(c) incremental remediation inside the retained
  architecture**; module replacement demoted to a per-module tactic (strangler-fig behind the matrix-proven
  API facade, invoked only if a module's decomposition stalls twice); full rewrite REJECTED. Binding
  verdicts: the target architecture IS the current architecture (SPA `/` · handler-level guards ·
  scoped-findFirst object-level access · domain state machines · SQLite single-instance) · the no-
  `middleware.ts` design KEPT (guards centralize via requireUser/visibility/atLeastRole; per OWASP
  API1:2023 the object-level defense must live in the data-access layer, which middleware cannot carry) ·
  single-instance assumptions ACCEPTED AS ALIGNED with SQLite's documented single-writer model (multi-
  instance = a deliberate future storage decision, a register row — not a defect). Triangulation per the
  owner's mandate: the three load-bearing defect facts re-verified live in-tree this round (F-01 economics-
  keys-only PATCH · F-02 the unspread RESERVATIONS_EXPIRING where-clause · F-04 build flags) + census
  re-verified (248 files / 48,334 LOC / 59 routes / 77 handlers / 26 components >400L) + **external web
  receipts EXT-9…EXT-16, 8/8** (Spolsky/Caudill rewrite risk · Fowler Strangler Fig · Nygard ADR practice ·
  Feathers characterization tests ≙ the 231-probe matrix · sqlite.org single-writer · nextjs.org Next.js 16
  currency · DORA small-batch · OWASP API1:2023 BOLA; receipts JSON + committed script). The 8 items requiring
  human approval are listed explicitly in the entry (Stage-4 ratification itself · WORKFLOW_SPEC §9.1/§9.2/
  §9.3 · R5 · Arabic review · deployment gate · channel ingestion). Read-only mode honored.
- **GOV-5 (remediation roadmap): COMPLETE 2026-10-19** — `MASTER_ENGINEERING_ROADMAP.md` restructured per
  the protocol's own tier definitions: **P0 preserve-state/critical-exposure** (ratification-transition guard ·
  environment-preservation runbook · the honest critical-exposure negative) · **P1 reproducible baseline**
  (R3 matrix→CI promotion `[env]` · F-04 build-strictness flip `[env]` · baseline discipline codified) ·
  **P2 target-architecture approval** (the owner gate cluster: D-GOV-4 ratification · §9.1/§9.2/§9.3 · R5 ·
  Arabic review) · **P3 foundational security/data/workflow repair** `[ratified]` (F-02 THE first fix · F-01
  money-path UI writer sized by §9.3 · F-05/F-11/F-13 symmetries · F-14 minimization · F-06/F-15 transactional
  writes · F-12 gates+coupling · §9.1-conditioned adjacency guard · the standing matrix-probe toll) · **P4
  bounded-module refactoring** (F-08 dep purge · F-10 helper consolidation · F-07 doc drift · size tier ·
  P2-era leftovers · the ui/-primitives honest negative) · **P5 production-readiness validation** `[deploy]`
  (D-013 purge first · production checklist · PostgreSQL decision · multi-instance register row · final
  validation). 27 tasks, each with scope/dependencies/acceptance/validation-commands/rollback/docs. Ordering
  law = severity × proven reachability (EXT-17); rollback law (EXT-18); OWASP A06 for the dep purge (EXT-19);
  secure-defaults for the checklist (EXT-20) — 4/4 external receipts this round (`/tmp/gov5-search-receipts.json`,
  script committed). Internal spot-verification this round: F-10 helper sites re-verified (startOfDay ×5 ·
  addDays ×3) · F-08 representatives re-verified zero-src-import (next-auth/next-intl/date-fns; @dnd-kit
  confirmed LIVE — the earlier loop's alternation bug caught and corrected) · legacy stub reconciliation
  noted. Historical register re-labeled as history; the forward plan is the tiers. Read-only mode honored.
- **OWNER RATIFICATION received 2026-10-19 (D-GOV-5):** the owner's written directive ratified D-GOV-4 and
  resolved the P2 cluster — §9.1 controlled state machines (free-form = defect → G5-P3-7 greenlit) ·
  §9.2/§9.3 two-step sale closure approved (agent prepares w/ evidence → manager validates; idempotent,
  retry-safe, concurrency-safe; monetary writes never as side effects → G5-P3-2 specified) · manager
  authority + CEO override discipline · MSA Arabic standard · R5 resolution authorized (least disruptive
  maintainable; reason + consequences recorded). Mode transitions to CONTROLLED IMPLEMENTATION (§1);
  tiers P3–P4 unlocked; execution begins at G5-P3-1 in roadmap order.

## 8. Pending human decisions (updated 2026-10-19 — D-GOV-5 resolved most of this list)

1. ~~**R5:** release vs requalify the 7 legacy held apartments~~ — **RESOLVED 2026-10-19 (D-GOV-6, G5-P2-5):**
   RELEASED to AVAILABLE via the P47 audited PATCH (the least disruptive maintainable remedy; backfill
   rejected — invented commercial records); seed aligned; matrix §32 pins the post-resolution world.
2. ~~Arabic microcopy human review~~ — **STANDARD SPECIFIED (D-GOV-5):** professional MSA (not Darja) + genuine
   RTL; the gate transforms into an MSA-conformance audit of the existing AR dictionaries (engineering task).
3. Deployment preparation (explicit-instruction gate; `PRODUCTION_READINESS.md`) — still owner-gated.
4. Git history purge execution (D-013 authorization gate; `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/GIT_HISTORY_PURGE.md`) — still owner-gated.
5. ~~**Stage 4 architecture approval**~~ — **RATIFIED 2026-10-19 (D-GOV-5):** incremental remediation, architecture
   retained; tiers P3–P4 unlocked; execution proceeds in GOV-5 roadmap order.
6. Inbound channel ingestion (WORKFLOW_SPECIFICATION §9.5) — remains a future product decision (not resolved
   by the directive).
