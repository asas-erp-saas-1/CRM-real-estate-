# ASAS CRM — Next-Phase Plan v2 (Lifecycle, Permissions, Security Remediation, Roadmap A–H)

**Created:** 2026-10-25 (UX-OWNER-PLAN-1) · **REVISED:** 2026-10-26 (**UX-OWNER-PLAN-2** — the owner's
Q1–Q11 answers reconciled; every owner-decided element below is marked `OWNER-APPROVED (2026-10-26)`).
**Authority chain:** owner directive S-DIR-2026-10-25 (`upload/Pasted Content_1792969410164.txt`) →
owner answers S-DIR-2026-10-26 (supplied in-session under task UX-OWNER-PLAN-2). **Nothing in this
file authorizes implementation.** The owner must review this revised plan and explicitly authorize a
defined implementation phase. Every element NOT marked owner-approved is **RECOMMENDED — NOT APPROVED**.

**Evidence base:** code research at HEAD `494b87a` (branch `main`, worktree clean) by sub-agents
3-a (lifecycle), 3-b (financial/permissions), 3-c (lead pool/audit coverage), 3-d (artifact
re-verification) + lead spot-verification — records in `agent-ctx/3-a-lifecycle-researcher.md`,
`agent-ctx/3-b-permission-researcher.md`, `agent-ctx/3-c-audit-coverage-researcher.md`,
`agent-ctx/3-d-artifact-re-verification.md`. The v1 evidence base (PLAN-1, HEAD `4dbb89f`, sub-agents
2-a/2-b/2-c/2-d-1/2-d-2) remains valid — `494b87a` only adds the two upload directive files
(committed by the environment, byte-identical) on top of the `70446c0` documentation package; **zero
src/schema/test changes exist between the two evidence bases.**

**Companion documents:** `OWNER_DECISION_REGISTER.md` §1a (the canonical record of the 2026-10-26
decisions) · `OWNER_DECISION_FORM.md` (the answered questionnaire + the 3 remaining questions RQ-1..3) ·
`ROLE_DATA_VISIBILITY_MATRIX.md` (2026-10-26 addendum: the field-by-role financial matrix) ·
`05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/PHASE_D_LIFECYCLE_COHERENCE.md` (Phase D history).

**Compressed notation:** “NP§n” = section n of THIS file. Statuses: `OWNER-APPROVED` (the owner
decided on 2026-10-26; implementation still gated) · `RECOMMENDED — NOT APPROVED` · `OPEN` (RQ-n).

---

## 0a. Conflict-reconciliation matrix (mandatory §6 of the UX-OWNER-PLAN-2 directive)

| # | Existing statement (exact home) | Latest owner decision | Real conflict? | Resolution | References |
|---|---|---|---|---|---|
| **A** | PLAN-1 v1 §2.1 recommended “strict server block + MANAGER-only, reason-required, audited override” for the visit gate (same override family as existing correction hatches) | GATE-Q2: strict blocking, **no override**; no `waiveVisitGate` mechanism; a D6 waiver must never bypass the visit gate | **No** — the v1 override was RECOMMENDED-NOT-APPROVED; no approved decision is contradicted | The override recommendation is RETIRED. The visit gate and the D6 economics waiver are documented as **separate enforcement controls**: the gate fires on Opportunity-stage boundary crossing (NP§2.1); the waiver clears ONLY the `INCOMPLETE_ECONOMICS` rejection at `validate_closure` (NP§5). A `waiveEconomics:true` retry with an unsatisfied visit gate still fails the visit check (if RQ-2 is approved) — the two checks are independent predicates in the same transaction | v1 §2.1 (superseded) · Register §1a.3-A · S-DIR-2026-10-26 Q2 |
| **B** | PLAN-1 v1 §5: “'not applicable' has NO dedicated representation (the zero+basis pair IS the approved expression)” — generalizing zero≡NA; v1 §5 also said “zero = recorded not-due value” | Q8: zero + written explanation records “incentive not due” ONLY; do NOT assume zero≡NA, zero≡not-payable, waiver≡payment, confirmed amount≡money received/paid | **YES — the v1 generalization exceeded the approved decision** (it was recommendation text, not an approved decision; corrected here) | The generalization is RETIRED. Approved semantics ONLY: (1) zero + written explanation = the recorded representation of “incentive not due” — an explicit recorded fact, never proof of payment; (2) “not applicable” has NO approved representation — the schema cannot distinguish not-due/NA/waived as separate states → documented gap → **RQ-3**; (3) waiver = the audited receipt (actor/time/reason/missing items), never a payment fact; (4) paid = `incentiveStatus: INCENTIVE_PAID` + `incentivePaidAt` (existing); (5) a confirmed commission amount is a manager statement of the agreed/expected value — never proof money moved (the §37/§38 trust law, reservation-trust.ts:1-18) | v1 §5 (superseded) · Register §1a.3-B · S-DIR-2026-10-26 Q8 |
| **C** | PLAN-1 v1 Q6.5 (OWNER_DECISION_FORM): proposed an optional manager-request queue for representative stage transitions | TRANSITIONS-Q6c: representatives perform otherwise-permitted transitions DIRECTLY; the queue NOT approved as mandatory; do not add unless a new evidence-based dependency is presented | **No** — never approved | The queue recommendation is RETIRED from the plan. Representatives act directly within existing server validations; no queue is planned | Register §1a.3-C · S-DIR-2026-10-26 Q6c |
| **D** | PLAN-1 v1 §2.1 contemplated a manager override as the documented no-visit-deal path (remote sales) | GATE-Q2 + GATE-Q3: strict block; NO_SHOW/CANCELLED/RESCHE DULED/incomplete never satisfy the gate; no override | **No** — never approved | Override path RETIRED. A no-visit deal cannot cross the visit boundary (or, if RQ-2 approved, reach CLOSED_WON via validate_closure) until a completed visit + report exists. The operational consequence — a genuinely remote/no-visit sale requires the owner to revisit GATE-Q2 — is documented as an accepted trade-off of the strict decision (surfaced here, not silently softened) | Register §1a.3-D · NP§2.3 |
| **E** | Security docs' intended read-side law (ROLE_DATA_VISIBILITY_MATRIX §1: commission reads management-only; agentIncentive visible to the reservation agent + MANAGER+; schema comment 593-596) vs code reality (GET/POST /api/reservations serialize the FULL §37/§38 family to floor roles — reservations/route.ts:76,112-116, 189-194) — v1 §1.3 documented it as drift D-2 “needs owner-aware adjudication” | FIN-MIN-Q10: server-side response minimization — unauthorized financial fields must NOT be serialized to lower-privilege clients at all | **No** — the drift awaited exactly this adjudication | Adjudicated: **the code is the defect; the documented visibility law is the target.** Elevated to a security remediation priority + implementation blocker (NP§6): a dedicated workstream with field-level `select` per role + regression probes proving ABSENCE of the fields in floor-role responses. No runtime change was made in this task | Register §1a.3-E · NP§6 · ROLE_DATA_VISIBILITY_MATRIX 2026-10-26 addendum |

**Reconciliation law applied:** no conflict was declared resolved except where grounded in the actual
canonical documents + these owner decisions (verified above against the live tree at `494b87a`).

---

## 1. Current lifecycle — as implemented (verified 2026-10-26 at HEAD `494b87a`)

### 1.1 The journey today (server-authoritative routes; who may act; what guards it)

| # | Hop | Route | Who | Guard |
|---|---|---|---|---|
| 1 | Lead intake | POST `/api/leads` (leads/route.ts:153-298) | any member | required: fullName, phone (E.164), source; dup-detection in-scope (foreign dup = generic 409); P2002 backstop; audited post-commit |
| 2 | Assignment | PATCH `/api/leads/:id` ownerId (:217-233); bulk assign | **MANAGER+** (403 otherwise — no self-assignment carve-out today) | org-validated owner; LEAD_ASSIGNED audit + ASSIGNMENT activity in-tx (:328-345) |
| 3 | Qualification | PATCH status (:185-201) | in-scope users (forward edges); MANAGER+ w/ correctionReason (backward) | LEAD_TRANSITIONS matrix (constants.ts:90-97); CLOSED_LOST needs lostReason; CONVERTED locked both ways (422 CONVERTED_LOCKED) |
| 4 | Conversion | POST `/api/leads/:id/convert` | any in-scope user (incl. pool leads) | one tx: Contact + Opportunity(stage QUALIFIED, probability 20, value=budgetMax, owner=lead.ownerId??user) + lead flip + ONE Activity(CONVERSION) (:28-68); **no visit precondition; NO AuditLog row** |
| 5 | Deal stages | PATCH `/api/opportunities/:id` (:80-112) | in-scope users (forward edges — skip-forward legal); MANAGER+ w/ reason (backward/terminal-reopen/PATCH-into-CLOSED_WON) | OPPORTUNITY_TRANSITIONS (constants.ts:125-136); §9.2 desync law blocks reopening sale-backed CLOSED_WON (:88-103); terminal stamps closedAt/probability 100/0; **NO visit-completion gate (confirmed absent — exhaustive sweep, 3-a §10)** |
| 6 | Visit scheduling | POST `/api/visits` (:206-334) | any authenticated role | units: org + AVAILABLE + single-project (:251-284); SCHEDULED + proposedAt set once; `opportunityId` D-021-scoped-validated (:223-230) but **NO cross-check that the opportunity belongs to the visit's lead** (validation gap, NP§2.6); `agentId` defaults to lead.ownerId (:300) |
| 7 | Visit field decisions | PATCH `/api/visits/:id` (:207-276) | **CONFIRM/REJECT/COUNTER: assigned FIELD_REP or MANAGER+ only** (canConfirmVisit, visibility.ts:186-197) | 403 VISIT_CONFIRM_FORBIDDEN; REJECT terminal w/ reason; counter arms awaitingCustomerReconfirm; customerReconfirm = visit agent or MANAGER+ (:265-276) |
| 8 | Visit completion | PATCH status COMPLETED (:196-202) | any in-scope user — **no authority gate on COMPLETED** | outcome required (422 OUTCOME_REQUIRED); attended server-set; idempotent FOLLOW_UP task +24h owned by visit.agentId??user (:431-453); **NO completion actor stamp on the row; never touches lead status or opp stage; NO AuditLog row** |
| 9 | Reservation | POST `/api/reservations` (:136-244) | any in-scope user (creator = agentId; **no opportunity-stage precondition**) | in-tx apartment AVAILABLE re-read + one-ACTIVE-row re-read (409s); apartment→RESERVED; APARTMENT_RESERVED audit in-tx; **response serializes the FULL model incl. §37/§38 (the FIN-MIN-Q10 leak)** |
| 10 | Closure request | PATCH `{action:"request_closure", evidence}` (reservation-lifecycle.ts:120-156) | responsible agent or MANAGER+ | from ACTIVE; evidence required (422); CLOSURE_REQUESTED + stamps |
| 11 | Validation (money event) | PATCH `{action:"validate_closure"}` (:165-255) | **MANAGER+** | status-preconditioned updateMany claim → idempotent 409 RESERVATION_ALREADY_CLOSED; one interactive tx: CONVERTED + apartment SOLD + opp CLOSED_WON/prob 100 (:191-196); **NO economics-completeness check (verified absent — zero commission/incentive references in the module)**; audits post-commit |
| 12 | Side paths | reject_closure / cancel (MANAGER+, reason) · EXPIRED sweeper (lazy at GET notifications/reservations, expiry.ts:22-67) | — | closure fields cleared; apartment released if still RESERVED |

### 1.2 The decisive findings (verified 2026-10-26; supersedes nothing — extends v1)

1. **NO visit gate exists anywhere** (3-a §10, exhaustive sweep). The `VISIT_COMPLETED` stage is
   reachable by manual stage PATCH with zero visits (skip edges NEW/QUALIFIED→VISIT_COMPLETED are
   legal in the matrix).
2. **The visit "report" surface is thin** (Visit model, schema.prisma:434-481): `outcome` (free text
   ≤2000, required at COMPLETED), `notes`, `followUpRequired`, `nextAction`, `attended`, confirm/reject
   actor stamps. **Missing:** interest level, objections, structured discussed-property report,
   follow-up recommendation, next-action due date, report author + reportedAt stamp, correction stamps.
3. **Completion has no authority gate** (any in-scope user) — contrasts with the P18 assigned-FIELD_REP
   gate on confirm/reject/counter.
4. **validate_closure performs zero economics-completeness checking** (confirmed again at HEAD).
5. **Exceptional visit outcomes exist as statuses** (constants.ts:54-62): NO_SHOW exits ONLY to
   RESCHEDULED; COMPLETED/CANCELLED/REJECTED terminal; CONFIRMED→SCHEDULED = MANAGER+ reset (audited,
   unwinds presence stamps). No dedicated INCOMPLETE status exists.
6. **The lead→opportunity boundary is clean and two-track**; visits attach to leads (required FK
   :438-439) and optionally to opportunities (typed FK :440-441, reverse relation on Opportunity :287,
   **no index**). `Visit.agentId` = the follow-up agent (defaults to lead.ownerId) — there is NO
   field-rep id column (field authority derives live from ProjectAssignment).
7. **NEW (3-c):** `fullName` IS PATCH-able today (:126, applied :237) and its edits are trail-silent
   (no audit, no activity) — the WAVE-2B approved direction excludes name from INLINE-EDIT scope, but
   the PATCH contract still accepts it; the Phase-D spec must reconcile (audit-before-approve or
   contract restriction — recommendation in NP§8 Phase D).
8. **NEW (3-c):** opportunity reassignment (`ownerId` on opportunities) is trail-silent (neither
   Activity nor AuditLog) — a Q11-adjacent gap; dispositioned in NP§7.
9. **NEW (3-b):** the reservation read/POST surfaces serialize the full §37/§38 family to floor roles
   (the FIN-MIN-Q10 leak — full assessment NP§6). `GET /api/reservations/[id]` does NOT exist
   (PATCH-only file → 405 on GET). Dashboard/notifications/analytics/apartments surfaces are clean
   (field-selected / null-gated / MANAGER+-gated).
10. **NEW (3-c):** audit write helper `logAudit(input, tx?)` — the optional `tx` param is honored on
    leads/visits/opps PATCH + reservations POST + bulk, but the whole reservation-lifecycle/economics
    module writes audits POST-commit (F-06 same-tx discipline gap on the money path). AuditLog is
    append-only by absence of code (zero update/delete in src/); the action string is NOT validated
    against a constant list.

### 1.3 Verified doc/code drift to carry into Phase A (updated 2026-10-26)

- `AUTHORIZATION_MODEL.md` + `ROLE_DATA_VISIBILITY_MATRIX.md`: promise agent self-service reassignment
  that code removed (ownerId changes are MANAGER+ everywhere — G5-P3-3 — **except the now-approved
  POOL-Q6b carve-out, planned**); list removed routes (`/api/leads/check-duplicates`, `/api/targets`);
  claim commission reads management-only while `GET /api/reservations` serializes the §37/§38 family to
  floor roles (**now adjudicated by FIN-MIN-Q10 → the docs are the target, the code is the defect**);
  matrix column bug (FIELD_REP semantics under the OWNER column); `documentScope` predicate divergence
  (2-b §8 D-1..D-9). **2026-10-26 addendum added to ROLE_DATA_VISIBILITY_MATRIX.md** (the field-by-role
  financial matrix); AUTHORIZATION_MODEL.md gains a dated addendum (the new approved rules).
- `MASTER_ENGINEERING_STATE.md` §3 + `ASAS_CRM_IMPLEMENTATION_CHECKPOINT.md`: refreshed 2026-10-25 by
  PLAN-1, re-refreshed this round (2026-10-26).
- `WORKFLOW_SPECIFICATION.md` state machines match code behavior (no material drift; two cosmetic notes
  recorded by 2-a §8).

---

## 2. Target lifecycle — OWNER-APPROVED direction + implementation spec (awaiting plan review)

The owner's approved journey, mapped onto the EXISTING two-track model with **zero new entities or
stages** (GATE-Q1 approved the Opportunity-lifecycle boundary; the candidate journey is now decided):

### 2.1 The gate — exact boundary, semantics, and enforcement `OWNER-APPROVED (2026-10-26)`

**Boundary formalization (verified against `OPPORTUNITY_TRANSITIONS`, constants.ts:125-136):**

- Stage zones (by the matrix's own order): **pre-visit** = {NEW, QUALIFIED, VISIT_SCHEDULED} ·
  **beyond-visit** = {VISIT_COMPLETED, NEGOTIATION, OPTION, RESERVATION, CONTRACT} · terminals =
  {CLOSED_WON (via validate_closure / manager correction only), CLOSED_LOST (legal exit from every
  working stage)}.
- **The gate fires on every PATCH stage change with source ∈ pre-visit AND target ∈ beyond-visit.**
  This covers BOTH the `VISIT_SCHEDULED` exits (VISIT_SCHEDULED→VISIT_COMPLETED/NEGOTIATION/OPTION/
  RESERVATION/CONTRACT) AND the legal skip edges (NEW→VISIT_COMPLETED, NEW→NEGOTIATION, QUALIFIED→
  NEGOTIATION, QUALIFIED→OPTION, … — all verified legal in the matrix). The v1 phrase “exit criterion
  of stage VISIT_SCHEDULED (+ entry to VISIT_COMPLETED/later)” is thus formalized without gap.
- **`VISIT_SCHEDULED` is semantically correct as the boundary stage — NO material mismatch** (verified:
  the stage exists, its meaning is exactly “a visit is scheduled for this deal”, and its exits are
  precisely the beyond-visit targets). Per the directive, two boundary-adjacent details are NOT
  silently decided → **RQ-1** (CLOSED_LOST exemption — RECOMMENDED: exempt; loss is not progression)
  and **RQ-2** (validate_closure extension — RECOMMENDED: extend; else the gate is bypassable via a
  fresh-deal reservation carried to CLOSED_WON with zero stage PATCHes, verified possible today).
- **The satisfaction predicate (GATE-Q1, exact):** ≥1 `Visit` row with `opportunityId ===` the
  opportunity's id AND `status === "COMPLETED"` AND the Q4 report contract satisfied (NP§2.2). **A
  completed visit for the same customer, another property, or another Opportunity NEVER satisfies the
  gate** (owner's explicit rule). Pre-conversion completed visits (opportunityId null) do NOT count —
  the normal flow links the visit to the opportunity at scheduling time (POST /api/visits takes the
  optional typed FK, D-021-validated).
- **Strictness (GATE-Q2): NO override, no `waiveVisitGate`, no role bypasses** — including manager
  correction-class PATCHes across the boundary (they fail like any other attempt; a manager correction
  that would cross the boundary requires the completed visit + report to exist first). Within-zone
  transitions (e.g., NEGOTIATION→OPTION) and backward corrections are NOT boundary crossings → not
  gated. Existing grandfathered deals already beyond the boundary stay put; any future crossing
  (including after a backward correction into the pre-visit zone) re-triggers the gate
  (engineering-specifiable detail, RECOMMENDED).
- **Server-side validation point:** inside the `PATCH /api/opportunities/:id` handler's existing
  transaction, BEFORE the stage write — a guarded query: fetch the opportunity (D-021 scoped findFirst,
  unchanged), and when (source ∈ pre-visit ∧ target ∈ beyond-visit), query
  `db.visit.findFirst({ where: { opportunityId, status: "COMPLETED", reportContractSatisfied } })`
  within the same interactive transaction; absence → throw-to-rollback (the Prisma official
  interactive-transaction pattern, 2-d-2). If RQ-2 is approved, the SAME predicate runs inside
  `validate_closure`'s interactive transaction before the updateMany claim.
- **Expected error response:** **422 `VISIT_REPORT_REQUIRED`** with an explicit missing-requirement
  list, e.g. `{ code: "VISIT_REPORT_REQUIRED", missing: ["completed visit linked to this opportunity"], visit: { linked: true|false, status: "SCHEDULED", reportComplete: false, missingReportFields: ["interestLevel","reportNotes"] } }`
  — the error TEACHES the exit criterion (NN/g error-message guidance: visible, specific, constructive;
  2-d-1). I18n keys in all 3 languages (the standing law).
- **How invalid transitions are tested:** a dedicated probe battery (Phase C/F test plan): permitted
  crossing WITH satisfied gate → 200; every gated edge WITHOUT a completed visit → 422 with the
  missing list; with a COMPLETED visit but incomplete report → 422 (report fields listed); with a
  NO_SHOW/CANCELLED/RESCHEDULED/REJECTED visit only → 422; with a completed visit linked to a DIFFERENT
  opportunity (same customer) → 422; cross-org/forged ids → 404 byte-identical; SALES_AGENT/FIELD_REP/
  MANAGER/ADMIN/OWNER all blocked identically when the predicate fails (no role bypass); manager
  correction across the boundary without the visit → 422; concurrency (two parallel crossings, one
  visit completing in-between) → guarded by the transaction.

### 2.2 The visit-report contract `OWNER-APPROVED (2026-10-26) — additive schema proposals in the roadmap ONLY`

**Required at submission (server-validated):**
1. **Customer-interest level** — 4-value enum `VERY_INTERESTED | INTERESTED | NEUTRAL | NOT_INTERESTED`
   (new shared constant in `src/lib/constants.ts` per the Enum-as-String law; zod-validated; UI selects
   use the same constants — none of these values exist today, verified).
2. **Written report notes** — the property/project discussed + customer objections/concerns (free text,
   min-length validated; distinct from the existing narrative `outcome` field, which remains the visit
   log).
3. **Author + timestamp recorded by the server** — `reportedById` (server-set from the session, never
   client-supplied) + `reportedAt` (server clock). Verified: no such stamps exist today (COMPLETED
   sets only `attended`).

**Optional at submission:** follow-up recommendation (enum vocabulary: CONTINUE/NUDGE/REQUALIFY/
CLOSE_LOST — RECOMMENDED — NOT APPROVED) · next-action due date (`nextActionDueAt`).

**Additive schema proposal (roadmap only — NOT implemented):** new nullable columns on `Visit`
(report fields + correction stamps below) + one migration; all existing rows unaffected (nullable);
the seed gains report content on its completed visits so the gate is demonstrable on fresh installs.

### 2.3 Exceptional outcomes — no-show, cancellations, rescheduling, incomplete, repeat `OWNER-APPROVED (2026-10-26)`

| Outcome | Rule (approved) | Current-matrix fit (verified) |
|---|---|---|
| No-show | never COMPLETED; never satisfies the gate; clear follow-up alert | NO_SHOW→RESCHEDULED is the ONLY edge (the absence is an immutable fact — P20-B law) |
| Customer cancellation | never COMPLETED; never satisfies the gate; reason recorded; follow-up alert | CANCELLED is terminal; a correction = a NEW visit |
| Representative cancellation | same; **optional structured `cancellationInitiator`** (CUSTOMER/REPRESENTATIVE) — additive proposal, RECOMMENDED — NOT APPROVED | no separate status exists (CANCELLED + reason text today) |
| Rescheduling | the eventual COMPLETED visit satisfies the gate; history never rewritten | RESCHEDULED status + same-status date change both exist |
| Incomplete visit | NOT completed unless it actually occurred; never satisfies the gate; **optional structured `incompleteReason`** — additive proposal, RECOMMENDED — NOT APPROVED | no INCOMPLETE status exists (stays SCHEDULED/CONFIRMED or CANCELLED+reason) |
| Repeat visits | multiple visits allowed; ANY completed one with a satisfied report passes the gate; the report chain stays visible in the timeline | unlimited Visit rows per opportunity today |

**Follow-up alert (approved direction, spec):** exceptional outcomes surface as attention items for
the follow-up representative — RECOMMENDED shape: a dashboard/notifications attention class for
NO_SHOW/CANCELLED visits on the rep's scope (the existing `unstaffedVisits` KPI pattern — amber,
MANAGER+ cell + per-rep alert), plus the existing auto FOLLOW_UP task. No new mandatory fields beyond
the approved contract (the owner's explicit constraint).

### 2.4 Report corrections — audited, history-preserving `OWNER-APPROVED direction + RECOMMENDED mechanism`

The report must be correctable WITHOUT erasing history. Mechanism proposal (grounded in verified
capabilities — the `logAudit` helper already carries before/after JSON snapshots; AuditLog is
append-only; COMPLETED visits are terminal so the row itself never re-opens):

- A correction = a PATCH of the report fields on a COMPLETED visit by an authorized actor
  (REPORT-Q5 authority + MANAGER+), writing additive `correctedById`/`correctedAt` stamps on the row
  and a dedicated audited event (`VISIT_REPORT_CORRECTED`) whose before/after payload carries the
  original vs corrected report content — **the original author (`reportedById`/`reportedAt`) and the
  original content (in the audit `before`) are never erased**.
- Original author + correcting actor + both timestamps + before/after content = the full provenance
  the owner requires. RECOMMENDED — NOT APPROVED (spec detail; no new entity, no history rewrite).

### 2.5 Report authority `OWNER-APPROVED (2026-10-26)`

- **The assigned FIELD_REP may submit** (assigned = live ProjectAssignment on the visit's project —
  the exact `canConfirmVisit` derivation, visibility.ts:186-197 — reused, not reinvented).
- **If no field rep is assigned, the representative responsible for the customer may submit** —
  verified carriers: the lead's `ownerId` / the visit's `agentId` (defaults to `lead.ownerId`,
  visits/route.ts:300). Authority check = visit.agentId??lead.ownerId === user.id, or MANAGER+.
- **Managers may review** (read + the correction path NP§2.4); ordinary valid transitions do NOT
  require per-report manager approval (REPORT-Q5); **no role may bypass the strict gate** (GATE-Q2).
- Role names verified: FIELD_REP / SALES_AGENT / MANAGER(70) / ADMIN(90) / OWNER(100) — no new
  hierarchy (constants.ts:354-360).

### 2.6 The visit↔opportunity relationship — verified adequate; one validation gap

`Visit.opportunityId` IS the required link (typed FK, D-021-validated at POST, reverse relation on
Opportunity). **No new entity and no repurposed foreign key are needed** for the gate. Documented gap
(NP§1.2-6): POST /api/visits validates the opportunity's existence + scope but does NOT cross-check
that the opportunity belongs to the visit's lead — a same-org user can link a visit to an unrelated
in-scope opportunity. RECOMMENDED (spec detail for Phase B/C): add the lead↔opportunity coherence
check at visit creation (opportunity.leadId === visit.leadId) — cheap, closes an integrity gap adjacent
to the gate's trust model. Also RECOMMENDED: an index on `Visit.opportunityId` (un-indexed today) once
the gate makes it a hot predicate.

### 2.7 What deliberately does NOT change

The two-step closure, the transition matrices (no new stages), D-021 scoping + ghost-404, the
correction hatches (leads/opps/visits), the §37/§38 economics write surface (MANAGER+), single
pipeline, attribution sources, org isolation, the activity timeline as the user-facing surface. The
gate and report are ADDITIVE. The Lead lifecycle stays ungated by default (GATE-Q1).

### 2.8 What the representative sees when blocked (UX spec essentials)

A blocked boundary-crossing attempt renders a constructive, i18n'd, attention-toned (amber) panel in
the stage-move surface (pipeline card / deal cockpit): the missing criterion named exactly (e.g.
« Une visite terminée avec compte-rendu est requise avant d'avancer ce deal » + the missing-report-
fields list when relevant), the deep link to schedule/complete the visit on THIS opportunity, and the
current visit chain (status chips). One primary next action (NN/g) = « Planifier la visite » when no
visit exists / « Compléter le compte-rendu » when a completed visit lacks its report. No override
affordance anywhere (GATE-Q2). AR-RTL + mobile-390 + console-0 = the standing laws.

---

## 3. Permission matrix — current verified + owner-approved deltas (3-b/3-c; full route table in agent-ctx/3-b)

**Roles (constants.ts:354-360):** OWNER(100) · ADMIN(90) · MANAGER(70) · SALES_AGENT(40) · FIELD_REP(40
— floor tier differs by DATA visibility, not rank).

### 3.1 Current state (verified at HEAD) — unchanged rows condensed from v1 §3

| Operation | SALES_AGENT | FIELD_REP | MANAGER+ |
|---|---|---|---|
| View leads | own + pool | via assigned-project visits | org |
| Create/edit leads (incl. **fullName today** — NP§1.2-7) | ✅ in-scope | ✅ project-derived | ✅ + assignment/correction/archive |
| Convert lead → opportunity | ✅ (incl. pool leads; opp owner falls back to converter) | ✅ | ✅ |
| Move opportunity stage | ✅ forward edges (skip-forward legal) | ✅ forward | ✅ + backward w/ reason |
| Schedule visit / create reservation / request closure | ✅ | ✅ (project-derived) | ✅ |
| Confirm/reject/counter visit | ❌ 403 | ✅ assigned project only | ✅ |
| Complete visit + outcome | ✅ in-scope (no authority gate today) | ✅ in-scope | ✅ |
| Validate/reject closure · cancel · economics writes · reassignment (any entity) · audit/analytics/settings/imports/exports | ❌ | ❌ | ✅ (user mgmt/WIP: ADMIN+) |
| Financial visibility | own incentives aggregate ONLY (dashboard null-gating) | none | full economics |
| **§37/§38 fields in reservation API responses** | ⚠️ **LEAK — full family serialized on in-scope rows** (NP§6) | ⚠️ same | ✅ (intended) |

### 3.2 Owner-approved deltas (2026-10-26 — implementation gated on plan review)

| Rule | Owner decision | Server shape (spec) |
|---|---|---|
| Representative workspace view | WORKSPACE-Q6a | SALES_AGENT: own workspace (D-021 own+pool data only); MANAGER+: inspect any representative workspace within org scope (their existing ORG scope — no new power, a navigation surface); FIELD_REP: own project-scoped life. D-021 + peer restrictions intact — no cross-rep data exposure |
| Self-assignment from the pool | POOL-Q6b | Additive carve-out in PATCH /api/leads/:id ownerId handling: when role < MANAGER, allow ONLY `ownerId === user.id` AND current `ownerId === null` (genuinely available) AND the record is in the caller's scope (pool rows are, verified) → then the existing in-tx LEAD_ASSIGNED audit + ASSIGNMENT activity fire unchanged. Any other agent-initiated ownerId change stays 403. Managers keep the full power |
| Direct opportunity transitions | TRANSITIONS-Q6c | No new permission: reps already move forward edges in-scope (verified). The queue is NOT built. The visit gate (NP§2.1) applies to ALL roles equally |
| Visit-report submission | REPORT-Q5 | NP§2.5 authority rule (assigned FIELD_REP → visit.agentId??lead.ownerId → MANAGER+); corrections per NP§2.4 |
| Reservation financial-field reads | FIN-MIN-Q10 | NP§6 — server-side minimization: §37/§38 + payment-related fields NOT serialized below MANAGER+ (the agent keeps their OWN aggregate incentive via the dashboard surface, which is already clean) |

**Enforcement invariants (verified, preserve):** server-side scoped findFirst → ghost-404 (D-021) ·
assertSameOrigin inside requireUser AND readJson (D-018/019/020) · HMAC session + passwordChangedAt ·
52-emitted-action audit taxonomy with before/after + decidedBy receipts · OWASP-alignment documented
(§11 S1-S3). **Never weakened for workflow convenience** (the register's scope-control law).

---

## 4. D5 commission helper — `OWNER-APPROVED semantics (2026-10-26)`

**Approved contract (D5-DETAIL-Q7, fixed):**
- **Inputs:** rate + calculation base = OPTIONAL manual inputs in the manager economics form. No
  default rate, no authoritative rate table, no unapproved formula — ever (the §37/§38 trust law,
  reservation-trust.ts:1-18, unchanged).
- **Calculation:** a **transient suggestion** (recommended: client-side compute `rate × reservation.amount`
  prefilling the amount field; NEVER auto-saved, never persisted as a distinct stored field).
- **Confirmation:** the manager confirms or edits the final amount → the existing audited
  COMMISSION_SET/INCENTIVE_SET path persists it with server-set decidedBy/decidedAt stamps
  (reservation-economics.ts:138-160 — verified to carry full before/after family snapshots).
- **Basis recording (approved):** when a rate was used, the basis string echoes a structured prefix
  (e.g. `rate 2.5% × 12 000 000 DZD — …`) so the calculation is reconstructable from the audit trail
  — RECOMMENDED format, the REQUIREMENT (record the basis when confirming) is owner-approved.
- **Visibility:** unchanged — MANAGER+ writes; the agent sees their own aggregate incentive; floor
  roles lose the raw §37/§38 API fields entirely per FIN-MIN-Q10 (NP§6).
- **Audit-path fit (verified):** the existing paths CAN represent the transient-vs-confirmed
  distinction — the suggestion never reaches the server as a persisted fact; the confirmed value +
  basis + decidedBy stamps do. **No additive field or audit event is required** (the verified answer
  to the directive's Q7 verification ask).

**Payment/accounting stay out** (standing law). The D5 UI rides the existing deal-economics manager
form (Phase E/F spec).

---

## 5. D6 closure-economics gate — `OWNER-APPROVED mechanism (2026-10-26)` + ONE unresolved semantic

**Completeness predicate (per the approved direction — fields verified schema.prisma:597-616):**
`commissionAmount ≠ null` ∧ `commissionFrom ∈ {DEVELOPER, CLIENT}` ∧ `agentIncentive ≠ null` (zero is
a VALID recorded value) ∧ `commissionBasis` non-empty ∧ `incentiveBasis` non-empty.

**Approved behavior (D6-DETAIL-Q8):**
1. `request_closure` → response carries an `economicsIncomplete` ADVISORY list (warn, no block) — the
   responsible agent sees what the manager will demand before preparing.
2. `validate_closure` → the interactive transaction computes the predicate BEFORE the updateMany
   claim; incomplete → **422 `INCOMPLETE_ECONOMICS`** with the explicit missing-field list (field
   labels i18n'd; the error teaches — NN/g).
3. An authorized manager may retry with **`waiveEconomics: true` + a mandatory reason** (min length,
   zod) → the closure proceeds AND the waiver is recorded as an audited receipt: actor, time, reason,
   the missing items — RECOMMENDED carrier: embedded in the `SALE_VALIDATED` audit payload (the
   existing post-commit audit path) or a dedicated `ECONOMICS_WAIVED` event; both additive-safe.
4. **Never weakened:** the two-step closure governance, the money-writes-never-side-effects law, the
   status-preconditioned idempotency (409 RESERVATION_ALREADY_CLOSED), the FR44a rollback set. F-06
   note (3-c): the lifecycle module writes audits post-commit today — folding the waiver + validate
   audits INTO the transaction is a RECOMMENDED hardening riding the same change window.
5. **The waiver NEVER interacts with the visit gate** (GATE-Q2 — conflict matrix A): `waiveEconomics`
   clears only the economics rejection; if RQ-2 is approved, the visit-gate predicate is a separate
   check in the same transaction that no flag clears.

**The unresolved financial semantic (RQ-3 — returned to the owner, NOT invented):** the current schema
expresses: zero (a recorded value + basis), paid (`INCENTIVE_PAID` + `paidAt`), waived (audit receipt
only — no column), and NOTHING for “not applicable”. The owner's explicit do-NOT-assume list (zero ≢
NA ≢ not-payable; waiver ≢ payment; confirmed amount ≢ money received) means the plan must NOT
generalize zero's meaning. RECOMMENDED — NOT APPROVED (RQ-3): keep the current representations and
require the written explanation to carry the disambiguation; introduce an explicit additive semantics
discriminator ONLY if the owner judges the ambiguity operationally costly. **No new financial status
model is introduced by this plan.**

---

## 6. Financial-field exposure assessment + prioritized remediation `OWNER-APPROVED direction (FIN-MIN-Q10)`

### 6.1 The verified exposure (3-b + lead spot-verification, HEAD `494b87a`)

| Surface | Verdict | Evidence |
|---|---|---|
| **GET `/api/reservations`** | **LEAK** — full §37/§38 family + booking economics serialized to EVERY authenticated role on in-scope rows | reservations/route.ts:76 `requireUser()` (no role gate) · :112-116 `findMany({ where, include: reservationInclude })` — **include, NOT a field-level select**; `reservationInclude` (26-47) only adds scoped opportunity/apartment sub-selects |
| **POST `/api/reservations` (201)** | **LEAK** — full model returned on creation | route.ts:189-194 + 239-240 |
| GET `/api/reservations/[id]` | N/A — no GET handler (PATCH-only file → 405) | 3-b |
| Dashboard (`/api/dashboard`) | CLEAN — field-selected + null-gated: commissions/pendingIncentives null below MANAGER; agent = pure-aggregate incentives; FIELD_REP neither | dashboard/route.ts:272-511 (3-b §7) |
| Notifications | CLEAN — items map only id/label/leadId | 3-b |
| Export bundle · analytics | CLEAN — MANAGER+-gated | 3-b |
| Apartments | CLEAN — count-only reservation data | 3-b |

**The §37/§38 + payment-adjacent field family exposed (schema.prisma:575-616):** `amount`, `depositPaid`,
`commissionAmount`, `commissionFrom`, `agentIncentive`, `commissionBasis`, `commissionStatus`,
`commissionEarnedAmount`, `commissionReceivedAmount`, `commissionReceivedAt`, `incentiveBasis`,
`incentiveStatus`, `incentiveDecidedById`, `incentiveDecidedAt`, `incentivePaidAt` (+ closure-governance
stamps `closureRequestedById/At`, `convertedById/At`, `reason` — lower sensitivity, included in the
matrix below).

### 6.2 The field-by-role matrix (canonical version: ROLE_DATA_VISIBILITY_MATRIX.md 2026-10-26 addendum)

| Field family | OWNER/ADMIN/MANAGER (≥70) | SALES_AGENT | FIELD_REP | Write | API return below MANAGER+ | Audit required | Negative tests |
|---|---|---|---|---|---|---|---|
| `commissionAmount/Basis/From/Status/EarnedAmount/ReceivedAmount/ReceivedAt` (§37) | read ✅ | ❌ | ❌ | MANAGER+ (COMMISSION_SET/REBASE, audited w/ before/after + decidedBy) | **MUST be absent (FIN-MIN-Q10)** — currently PRESENT (the defect) | already audited | floor-role GET/POST responses: assert the JSON keys are ABSENT (not null — absent), incl. `?id=`/`?opportunityId=`/`?apartmentId=` variants |
| `agentIncentive`, `incentiveBasis/Status/DecidedById/DecidedAt/PaidAt` (§38) | read ✅ | ❌ raw values (own-incentive visibility survives ONLY via the clean dashboard aggregate) | ❌ | MANAGER+ (INCENTIVE_SET/DECIDED/PAID/REBASE, audited) | **MUST be absent (FIN-MIN-Q10)** — currently PRESENT | already audited | same absence probes; plus the agent aggregate still renders (My Day) — regression pair |
| `amount`, `depositPaid` (booking facts) | read ✅ | RECOMMENDED: read on own/in-scope rows (commercial facts of the booking — v1 position; NOT decided by FIN-MIN-Q10's “commission, incentive, and related financial-basis fields” scope) | same | amount: any in-scope creator/manager; depositPaid: MANAGER+ | RECOMMENDED: stay serializable in-scope (decision-class: the owner may narrow) | creation audited (APARTMENT_RESERVED) | if narrowed: absence probes |
| `status`, `expiresAt`, `notary`, `contractRef`, closure stamps, `reason` | read ✅ | read in-scope (workflow facts — the closure workflow NEEDS them at floor tier) | same | per existing lifecycle rules | stays (workflow necessity) | lifecycle events audited | unchanged probes |
| `incentiveDecidedById` | read ✅ | ❌ | ❌ | server-set | MUST be absent below MANAGER+ | audited | absence probe |

**Record scope:** all of the above on TOP of the existing D-021 row scoping (reservationScope —
visibility.ts:138-149) — field minimization is a SECOND layer, never a replacement.

### 6.3 Remediation plan (the security workstream — implementation gated)

1. **Priority: SECURITY-REMEDIATION-FIRST** — this workstream is scheduled BEFORE/Above all UX/visual
   work in the roadmap (the directive's explicit “must not be buried behind visual redesign” law).
2. **Change shape (spec):** replace `include:` with a role-aware field-level `select` on
   GET/POST `/api/reservations` (one shared serializer helper — RECOMMENDED `reservationDto(user, row)`
   in lib/server, mirroring the dashboard's proven field-selection pattern); below MANAGER+ the §37/§38
   family keys are not serialized at all; the DTO shape for floor roles stays stable for the workflow
   fields. UI consumers re-checked (deal cockpit/deal-economics agent branch read agentIncentive — the
   agent-facing aggregate stays via dashboard; the cockpit's agent branch must not break — verified it
   renders from the reservation row, so the spec includes the compensating aggregate source or an
   explicit per-role own-row incentive allowance decision → folded into RQ-3's narrow scope? NO —
   kept as an engineering-spec item with the dashboard aggregate as the RECOMMENDED source).
3. **Regression:** new probe battery (absence assertions on every variant + role × the existing
   325-matrix re-run + the My Day aggregate regression pair + cross-org ghost-404 unchanged).
4. **Acceptance:** floor-role API responses contain ZERO §37/§38 keys (byte-level assertion), manager
   responses unchanged in shape, all standing suites green, browser E2E console-0, AR-RTL + 390.
5. **Rollback:** the serializer swap is a single-module change with a documented revert.

**Execution package (2026-10-26, UX-OWNER-DECISION-CLOSE-3 Case B):**
`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/WORKSTREAM_S_IMPLEMENTATION_BRIEF.md` — the exact affected-file inventory, the
serializer contract, the full test battery, acceptance criteria, rollback, and prerequisites,
built from the live tree at HEAD `cd7a725` (every §6.1 predicate re-verified that round). The
exposure remains OPEN until the owner authorizes the workstream — the CLOSE-3 directive's
owner-answers placeholder arrived unfilled, so **Workstream S was NOT authorized and no source
was edited** (register §1b).

**EXECUTED (2026-10-26, WS-S-EXEC — register §1c.1 decision 7):** the owner authorized Workstream S
in-session and it was implemented the same round, per this section's spec + the brief: the shared
role-aware serializer `src/lib/server/reservation-dto.ts` (floor-allowlist construction — §6.2's
matrix row-for-row; MANAGER+ pass-through) wired into GET (all four variants), POST 201, and BOTH
PATCH `[id]` branch returns (live re-inspection extended the inventory: `request_closure` — the
responsible-agent-reachable surface — also spread the full row). The cockpit agent branch renders
the honest aggregate-pointer static (the RECOMMENDED compensating source — the dashboard aggregate —
per §6.3-2). Verified: unit battery + 448-check live integration battery on isolated scratch
fixtures (byte-exact sweep to the empty baseline; decision 8 — no recovery) + browser E2E (FR/AR,
wire checks, 390px, console-0) + lint + tsc — evidence `download/qa-ws-s/`. **The standing-suite
re-run (§6.3-3) is honestly BLOCKED** (DB empty, recovery not authorized) — the 325-matrix remains
commit-anchored. Rollback = single-commit revert (§6.3-5). §8's Phase S row is DONE; the next
implementation phase is B/C (the RQ-1/RQ-2/correction/consistency requirements — now
owner-APPROVED).

---

## 7. Lifecycle audit design `OWNER-APPROVED direction (AUDIT-Q11)`

### 7.1 Verified current coverage (3-c census, HEAD `494b87a`)

| Lifecycle event | Activity (user timeline) | AuditLog (formal) |
|---|---|---|
| Lead creation | ✅ LEAD_CREATED | ✅ (post-commit) |
| Lead field edits (incl. fullName — NP§1.2-7) | ❌ | ❌ |
| Lead qualification (status change) | ✅ | ✅ LEAD_STATUS_CHANGED / LEAD_STATUS_CORRECTED (in-tx) |
| Lead assignment | ✅ ASSIGNMENT | ✅ LEAD_ASSIGNED (in-tx, before/after ownerId) |
| **Lead→Opportunity conversion** | ✅ CONVERSION | **❌ NONE — the gap** |
| Opportunity stage change | ✅ | ✅ OPPORTUNITY_STAGE_CHANGED/CORRECTED (in-tx) · **opportunity reassignment: NEITHER (gap)** |
| Visit creation / confirm / reject / counter | ✅ each | ❌ (only the manager reset → VISIT_RESET_TO_SCHEDULED) |
| **Visit completion** | ✅ + auto FOLLOW_UP task | **❌ NONE — the gap** |
| Reservation creation | ✅ | ✅ APARTMENT_RESERVED (in-tx, entity=APARTMENT) |
| §37/§38 economics writes | ⚠️ incentive decide/pay only | ✅ COMMISSION_SET/REBASE · INCENTIVE_SET/DECIDED/PAID/REBASE (post-commit, full before/after) |
| request/validate/reject/cancel closure | ✅ each | ✅ each (validate/cancel mutations in-tx, audits post-commit) |

### 7.2 The event taxonomy + minimal additional coverage (RECOMMENDED — the direction is owner-approved)

- **Two new formal audit events (the AUDIT-Q11 gaps):** `LEAD_CONVERTED` (conversion: actor, lead id,
  opportunity id, contact id — in-tx with the existing convert transaction) · `VISIT_COMPLETED`
  (completion: actor, visit id, lead/opportunity ids, outcome summary — in-tx). NOTE: an i18n key
  `audit.action.VISIT_CONFIRMED` exists as a label-only leftover (no emitter — 3-b); the new event is
  DISTINCT (`VISIT_COMPLETED`) — do not reuse the dead key's semantics.
- **Riding the new report work (NP§2):** `VISIT_REPORT_SUBMITTED` (author + report fact) and
  `VISIT_REPORT_CORRECTED` (before/after + correcting actor — NP§2.4). The self-assignment carve-out
  reuses the EXISTING `LEAD_ASSIGNED` event (POOL-Q6b — no new event).
- **Adjacent gaps dispositioned (RECOMMENDED, engineering-specifiable):** `fullName` edits → ride the
  WAVE-2B identity-field audit family (Phase D spec decision: restrict the PATCH contract or audit it);
  opportunity reassignment → `OPPORTUNITY_ASSIGNED` mirroring LEAD_ASSIGNED (Phase C/F); the dead
  `OPPORTUNITY_STAGE_CHANGED` emit inside validate_closure (post-commit guard reads the already-mutated
  stage — 3-c finding) → fix to emit the truthful `SALE_VALIDATED`-adjacent record only.
- **No duplicate/contradictory events (the owner's constraint):** the Activity timeline stays the
  user-facing surface (unchanged feeds); AuditLog stays the formal trail (MANAGER+ audit view). No
  event is written twice in both systems with different semantics — each new audit event has a
  distinct purpose (formal provenance vs operational narrative).
- **Not every field edit gets identity-grade audit** (the owner's constraint): routine non-identity
  field edits stay unaudited; identity-class (WAVE-2B scope) + financial + the lifecycle events above
  are the audit surface.
- **Semantics for every new event (OWASP Logging Cheat Sheet — §11):** who (actorId from session),
  what (action + entity + entityId), when (server timestamp), where (ip — the helper already captures),
  why (reason/payload where applicable); before/after where a value changes; immutability preserved
  (append-only — no update/delete paths, verified). RECOMMENDED hardening: fold the money-path
  post-commit audits into their transactions (F-06) in the same change windows.

---

## 8. The roadmap — Phases A–H revised (2026-10-26; planning workstreams — NOT an authorization to execute)

**Dependency order (revised):** **S → (B-spec done ∥ D ∥ E-spec done) → C → F → G → H**, where
**S = the security remediation workstream (FIN-MIN-Q10) — SCHEDULED FIRST among implementation
phases** and may proceed in parallel with spec-finalization work. B/E specs are DONE in this document
(NP§2/§4/§5); their “implementation” rows now carry the residual spec-to-code work.

| Phase | Objective | Key deliverables | Depends on | Owner gates | Acceptance essentials | Effort (assumptions) |
|---|---|---|---|---|---|---|
| **A — Evidence & documentation reconciliation** | canonical hierarchy + drift closure | DONE 2026-10-25 (PLAN-1) + EXTENDED 2026-10-26 (this round: register §1a, conflict matrix, field-by-role addendum, master-doc refresh, D-GOV-8) | — | none | docs match code at named HEAD; drift items dispositioned | done |
| **S — Financial-field response minimization (NEW — security blocker)** | close the verified §37/§38 leak | role-aware field-level serializer on reservations GET/POST; absence-probe battery; My Day aggregate regression pair; UI consumer re-check | **owner plan review** (this document) | FIN-MIN-Q10 approved (direction) — execution awaits plan authorization | floor-role responses contain ZERO §37/§38 keys (byte-asserted); manager shape unchanged; 325-matrix + new probes green; E2E console-0 | 0.5–1 day impl + 0.5 day probes |
| **B — Lifecycle implementation: visit gate + report contract** | GATE-Q1/Q2/Q3 + REPORT-Q4/Q5 in code | additive Visit schema (report fields + correction stamps + optional initiator/reason fields — the two optional ones RECOMMENDED only); the gate predicate in the opportunities PATCH tx (+ validate_closure if RQ-2 approved); 422 VISIT_REPORT_REQUIRED contract; report-authority rule; exception alert surfaces; blocked-UX panel; LEAD_CONVERTED + VISIT_COMPLETED + report audit events | S (or parallel-safe ordering decision at kickoff) + **RQ-1/RQ-2 answers** | plan review + RQ-1/RQ-2 | NP§2.1 test battery green; report-contract validation probes; exception-path probes; AR-RTL/390/console-0; grandfathered-deal policy documented | 2–3 days impl + 1–1.5 days probes |
| **C — Authorization & data-integrity implementation** | POOL-Q6b carve-out + workspace surfaces + integrity hardening | self-assignment (null→self only, LEAD_ASSIGNED reused); R7 per-rep surface (WORKSPACE-Q6a: manager navigation + agent own view); visit↔opportunity coherence check + opportunityId index; OPPORTUNITY_ASSIGNED audit; D4-B lead stale-guard (409 LEAD_STALE, backward-compatible) | B (shared surfaces) | plan review | self-assignment negative probes (colleague-lead 403/404, pool 200 + audit row); D-021 unchanged proof; stale-conflict E2E | 1.5–2 days |
| **D — Lead-editing (Wave-2B) implementation** | safe-field inline editing + identity audits | the frozen 10-field set client-side; identity-field audit + timeline before/after; **fullName PATCH-contract reconciliation decision** (NP§1.2-7 — restrict vs audit, RECOMMENDED: restrict to MANAGER+ correction-class + audit) | A (done) | approved direction standing; no new owner input | Wave-2B probe suite; identity-edit audit rows; conflict path E2E | 1–1.5 days |
| **E — Commission & closure-economics implementation** | D5 helper + D6 gate | D5 transient-suggestion UI + basis echo; D6 warn/422/waiver + audited receipt; F-06 same-tx hardening; **RQ-3 answer before the waiver receipt's final shape if the owner chooses a discriminator** | S (serializer first — the economics form reads the same rows) | plan review + **RQ-3** | no invented rates (assertion probes); INCOMPLETE_ECONOMICS battery incl. waiver audit row; FR44a/b/c/d re-run | 1.5–2 days |
| **F — UI/UX implementation batches** | role workspaces, canonical surfaces, high-friction journeys | per-batch: the standing laws (matrix + suites + E2E console-0 + AR-RTL + 390); Wave-4-retired polish folds here | B, C, D, E | per-batch plan review | per-batch gates | multi-batch, per-batch est. |
| **G — Verification & test-data readiness** | trustworthy verification restored | canonical environment recovery (separately authorized); demo-mode config contract (OFF default + dev opt-in) + tests; suite re-baseline on the recovered DB; all new probes registered | environment recovery authorization | recovery = its own execution authorization | recovery recipe green; baseline byte-exact 8/43/21/23/161/18/8/4/46; suites green at named HEAD | 0.5 day + recovery |
| **H — Artifact cleanup execution** | safe cleanup of the approved subset | manifest + recoverable archive + reproducibility verification, then archive the 7 zero-ref dirs + the duplicate candidates (3-d's re-verified list) | **separately approved future task** | CLEANUP-Q9 planning approved; EXECUTION needs its own approval | inventory re-verified pre/post; referenced artifacts intact; rollback = restore from archive | 0.5–1 day |

**Standing during ALL phases:** the 5-gate validation protocol (TEST_STRATEGY.md); conventional
commits; byte-exact residue; append-only worklog; **no phase marks the product production-ready**
(the P5 tier untouched). **Ordering law:** S (security) may not be postponed behind F (visual) —
the roadmap's dependency edges enforce it. **Wave 4 stays RETIRED.** Historical test claims stay
commit-anchored (§10).

---

## 9. Synthetic-data & artifact inventory + reversible cleanup plan (planning ONLY — zero deletions performed; re-verified 2026-10-26)

**Second, broader reference audit executed this round (the CLEANUP-Q9 precondition — sub-agent 3-d,**
**record `agent-ctx/3-d-artifact-re-verification.md`):** 12 search classes — all file types (md/ts/
tsx/js/sh/json/prisma/yml/Caddyfile/package.json/configs), hidden + untracked + git-ignored dirs,
cross-references from all 58 sibling download/ dirs (every VLM JSON + REPRODUCTION-LOG.md),
partial/bare tokens, 13 distinctive filename stems, ALL readdir/glob walkers (none touch download/),
no script constructs `download/qa-*` dynamically, no .github/Dockerfile/Makefile/CI exists, Caddyfile
is a pure proxy, git pickaxe across ALL history.

| Candidate (exact path) | Why a candidate | Reference checks performed | Reproducibility / impact | Proposed reversible action (future, gated) |
|---|---|---|---|---|
| `download/qa-p11` (6 files, 512K) | zero references under the broader audit (matches only in the meta-records proposing archival: this plan, worklog L4192, agent-ctx/2-c, + 2 ephemeral git-ignored tool-results echoes) | 12 search classes + git pickaxe (appears in exactly ONE commit ever: 70446c0, the planning commit itself) | git-tracked with known add-commits → archive reversible; orphaned P11-CLOSE evidence (worklog cites no evidence dir for that round) | archive to git-ignored archive dir + manifest, after the separate execution approval |
| `download/qa-p13` (5f, 740K) | same verdict class | same | P13-CLOSE VLM surfaces | same |
| `download/qa-p14` (10f, 1.3M) | same | same | P14-CLOSE SAV evidence — feature REMOVED by p16_remove_sav + P26 purge | same |
| `download/qa-p25` (9f, 752K) | same | same | P25 round VLM PASS ×3 | same |
| `download/qa-p26` (8f, 444K) | same | same | P26 round VLM ×4 | same |
| `download/qa-r7-3` (8f, 916K) | zero references; superseded by the REFERENCED `download/qa-round-r7/` (worklog cites it) | same + the ~30 `// R7-3` code comments verified to reference the engineering ROUND, not the dir (name-collision hazard documented) | R7-3 subagent residue | same |
| `download/uxa-phasea` (9f, 1.1M) | zero references | same | Phase A before/after evidence | same |
| `upload/Pasted Content_1792865001062.txt`-class duplicates: pair `1792968288177`/`1792969410164` (md5-identical, 557L) — **BOTH NOW COMMITTED at HEAD 494b87a** (status change vs v1); `16178fc…(1).png` ≡ `16178fc….png` (md5-identical, unreferenced); `1791544495557` vs `1791544557523` — **NOT byte-identical (1 byte: “GLM 4.3”→“GLM 5.3”; later = canonical FINAL MASTER DIRECTIVE, earlier = superseded revision)** | duplicates/superseded copies | md5 re-verification + reference census (canonical copy referenced: `…410164` 7 refs incl. worklog L4235 + 3 governance docs; the earlier paste only as “the duplicate”) | de-dup of the committed pair requires a `git rm` — still owner-gated (the owner called both canonical in S-DIR-2026-10-25 §2) | relabel the 1791544 pair “superseded 1-byte revision” (3-d's refinement); archive candidates listed for the future task |
| `upload/` UUID images (12, incl. the 1.65M orphaned `aaa51875…(1).png`) | zero functional references | per-file census | owner-review class (v1 category 7) — NOT in the approved cleanup scope until individually verified | owner review, then per-item disposition |
| `tests/`, `.zscripts/`, empty `mini-services/`, `q2/q3/q4.ts` | still unreferenced (3-d bonus re-check; `.zscripts/build.sh` calls its OWN same-named scripts — suspicion resolved) | literal + descriptive reference checks | policy-backed slots / documented inert scratch | retain (worklog L642 documents the q*.ts class) |

**Retained (untouched, canonical):** all 58/65 referenced download dirs + 11 evidence dirs + 13+5
agent-ctx records · `prisma/seed.ts` (canonical, D-016) · ~103 referenced regression fixtures ·
governance-referenced logs/reports. **3-d's verdict: NOTHING removed from the cleanup list — all 7
zero-reference verdicts held; the only refinement is the 1791544 relabel.** Execution remains a
separately approved future task (CLEANUP-Q9) with: manifest → git-ignored archive dir → referenced-set
integrity verification → documented rollback. **Nothing was archived/moved/renamed/deleted in this
task.**

---

## 10. Environment prerequisites (REVERIFIED 2026-10-26, read-only)

- **HEAD `494b87a`** (the environment-committed upload pair on top of `70446c0` — the PLAN-1
  documentation package; ZERO src/schema/test changes between them), branch `main`, **worktree clean**
  except this round's documentation edits.
- **Database EMPTY (reverified):** 0 rows in User/Lead/Opportunity/Visit/Reservation/Apartment/
  AuditLog/Activity/Contact/Task; **`_prisma_migrations` table MISSING** (the R13/R25
  interrupted-recovery signature — 18th observed occurrence class). Login fail-closed on the empty
  user table.
- **`ASAS_SESSION_SECRET` ABSENT** (`.env` carries only `DATABASE_URL` — key names only inspected; no
  values read or printed). **`ASAS_DEMO_MODE` unset** (code default ON — the demo-mode flip remains
  future authorized work, Phase G).
- **Dev server: HTTP 200** (single instance, port 3000; dev.log clean at tail).
- **Historical test results remain commit-anchored evidence** (suites green at `4dbb89f` ancestry —
  D7-R6 closure): lint 0 · tsc 4-tolerated (0 in src/) · matrix 325/325 · Wave1 21/21 · Wave2A 22/22 ·
  Wave3 55/55 · Phase D 15/15 · D7-R1..R6 17/10/10/14/7/7. **NO test was run during this task** (the
  DB is empty; recovery is separately authorized). **Required prerequisite for any future verification
  phase:** the canonical recipe (AGENTS.md DB constraint): fresh secret → `.env` → kill by PID →
  `rm db/custom.db` → `migrate deploy` ×11 → `generate` → `db:seed` → subshell restart → baseline
  byte-exact 8/43/21/23/161/18/8/4/46 → D-040/D-041 resurrection sweep → suite re-run at a named HEAD.

---

## 11. External research (verified sources — v1 records + 2026-10-26 reachability re-confirmation)

Full citations + verbatim quotes: `agent-ctx/2-d-1-external-research.md` (Salesforce official ×3 ·
NN/g ×3) + `agent-ctx/2-d-2-external-research.md` (OWASP ×3 · Prisma official). **Reachability
re-confirmed 2026-10-26** (HTTP 200): OWASP Authorization Cheat Sheet · OWASP Logging Cheat Sheet ·
NN/g Progressive Disclosure. No NEW external page was loaded this round (the sandbox web limitations
stand as documented in 2-d-1/2-d-2); the v1 sources remain the evidence base and their principles map
unchanged onto this round's decisions:

- **OWASP Authorization Cheat Sheet** (deny by default; server-side decisive enforcement; least
  privilege) → FIN-MIN-Q10's server-side minimization (NP§6) + the gate's server enforcement (NP§2.1).
- **OWASP Logging Cheat Sheet** (who/what/when/where; higher-risk functionality logged; integrity) →
  the D6 waiver receipt (NP§5) + the audit taxonomy (NP§7).
- **OWASP Top 10:2021 A01** (broken access control #1) → the §37/§38 leak is exactly this class.
- **Prisma official transactions/OCC docs** → the gate predicate + waiver inside interactive
  transactions (throw-to-rollback) + the D4-B/LEAD_STALE guard family.
- **NN/g (progressive disclosure · form usability · error messages)** → the light lead track
  (GATE-Q1), the report form's required/optional split, the teaching 422 contracts.
- **Salesforce (convert-after-qualification · two-track · early disqualification · stage exit
  criteria)** → the two-track boundary, RQ-1's CLOSED_LOST exemption recommendation.
- **Honest limitations (v1, still true):** no canonical Salesforce “Opportunity Stages” setup article
  reachable; search engines unusable in-sandbox; “stage exit criteria” is a documented synthesis, not
  a verbatim Salesforce term; OWASP/Trailhead/NN/g pages carry no visible dates.

**External research never overrides explicit owner decisions** (the standing law).

---

## 12. Document change log

### 12.1 UX-OWNER-PLAN-1 (2026-10-25 — preserved verbatim from v1)

| Path | Change |
|---|---|
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md` · `NEXT_PHASE_PLAN.md` · `OWNER_DECISION_FORM.md` | NEW (the planning package) |
| `MASTER_ENGINEERING_STATE.md` §3/§13/§14 · `MASTER_ENGINEERING_ROADMAP.md` forward layer · `ASAS_CRM_IMPLEMENTATION_CHECKPOINT.md` | refreshed from their stale states |
| `PHASE_D_LIFECYCLE_COHERENCE.md` §8 · `WAVE_2B/WAVE_3` briefs | dated addenda |
| `DECISION_LOG.md` | D-GOV-7 appended |
| `worklog.md` + `agent-ctx/2-*.md` | session + research records |

### 12.2 UX-OWNER-PLAN-2 (2026-10-26 — this round; documentation-only, verified)

| Path | Change | Rationale |
|---|---|---|
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md` | §1 heading annotated (superseded-by-§1a) + **§1a appended** (the 13 new decisions GATE-Q1…AUDIT-Q11, status changes, conflict matrix A–E, RQ-1..3, updated work mapping) | record the owner's 2026-10-26 answers canonically (append-only) |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/NEXT_PHASE_PLAN.md` | **rewritten as v2** (this file): conflict matrix §0a · verified lifecycle §1 (new findings 7-10) · OWNER-APPROVED gate/report specs §2 · permission deltas §3 · D5 §4 · D6 + RQ-3 §5 · financial exposure + remediation §6 · audit design §7 · revised roadmap §8 (Phase S FIRST) · re-verified cleanup §9 · re-verified environment §10 · research §11 · this change log | the directive's core deliverable |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_FORM.md` | dated answers addendum + the RQ-1..3 remaining-questions section | preserve the v1 form verbatim; record answers; expose only genuinely-unresolved questions |
| `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/ROLE_DATA_VISIBILITY_MATRIX.md` | **2026-10-26 addendum**: the field-by-role financial matrix + the verified leak + the remediation plan pointer | FIN-MIN-Q10's required matrix, in its canonical home |
| `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/AUTHORIZATION_MODEL.md` | **2026-10-26 addendum**: the new approved rules (gate strictness, report authority, self-assignment carve-out, direct transitions, field-level response minimization as the D-021-companion law) | the authorization canonical doc must carry the new laws (planning-level) |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_STATE.md` | §13 new dated update (prepended) + §14 item 1 refreshed | the orientation doc must reflect the new decision state |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_ROADMAP.md` | forward-plan header block updated (2026-10-26 layer) | same |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/ASAS_CRM_IMPLEMENTATION_CHECKPOINT.md` | current-phase resume point rewritten (UX-OWNER-PLAN-2 state) | the resume point law |
| `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/PHASE_D_LIFECYCLE_COHERENCE.md` | §8 addendum line (Q1–Q5 + #6 resolved 2026-10-26) | append-only history |
| `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/WAVE_3_OWNER_DECISION_REQUESTS.md` | dated addendum (Q7/Q8 answers; RQ-3 open) | append-only history |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md` | **D-GOV-8 appended** | the governance record of this round |
| `worklog.md` | UX-OWNER-PLAN-2 entry (+ sub-agent records note) | the append-only session record |
| `agent-ctx/3-a/3-b/3-c/3-d-*.md` | 4 research records | the AGENTS.md sub-agent convention |

**No source code, schema, migration, test, DB content, seed, secret, scheduler, Git remote/history,
publishing, or deployment state was changed in either round.** No file was archived, moved, renamed,
or deleted.

### 12.3 UX-OWNER-DECISION-CLOSE-3 (2026-10-26 — Case B: documentation-only, verified)

| Path | Change | Rationale |
|---|---|---|
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/WORKSTREAM_S_IMPLEMENTATION_BRIEF.md` | **NEW** — the complete Workstream S execution package (objective · live exposure re-verified at HEAD `cd7a725` with file:line · exact affected-file inventory · serializer contract · test battery · acceptance criteria · constraints & rollback · prerequisites) | the CLOSE-3 Case-B deliverable: the brief the owner authorizes against |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md` | **§1b appended** (the closure attempt WITHOUT the owner's form results — placeholder unfilled, upload checked; RQ-1..3 stay OPEN, Workstream S unauthorized; live-state verification record; the §1b.1 residual-decision audit with the four-class taxonomy and the complete OWNER-REQUIRED list) | record the round canonically without fabricating decisions (append-only) |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_FORM.md` | closure-attempt note appended to the remaining-questions section | the form remains the closure vehicle — record why nothing closed |
| `NEXT_PHASE_PLAN.md` (this file) | §6.3 execution-package pointer + this §12.3 | keep the plan↔brief linkage explicit |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/MASTER_ENGINEERING_STATE.md` / `MASTER_ENGINEERING_ROADMAP.md` / `ASAS_CRM_IMPLEMENTATION_CHECKPOINT.md` | dated CLOSE-3 notes (§13 item-1 addendum / header addendum / new top resume paragraph) | orientation docs stay truthful: still awaiting owner answers |
| `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md` | **D-GOV-9 appended** | the governance record of the round |
| `worklog.md` | UX-OWNER-DECISION-CLOSE-3 entry | the append-only session record |

**No source code, schema, migration, test, DB content, seed, secret, scheduler, Git remote/history,
publishing, or deployment state was changed in this round either. No file was archived, moved,
renamed, or deleted. NO decision was closed (the owner's answers did not arrive) — nothing here
upgrades any RECOMMENDED item to approved status.**

### 12.4 WS-S-EXEC (2026-10-26 — the owner's eight answers + the authorized Workstream S execution)

| Document | Change | Purpose |
|---|---|---|
| `OWNER_DECISION_REGISTER.md` | §1c (new) | the eight owner decisions recorded verbatim-faithful; RQ-1/RQ-2/RQ-3 CLOSED; Workstream S authorized; recovery boundary confirmed |
| `OWNER_DECISION_FORM.md` | CLOSED section | the RQ answers' arrival record |
| `WORKSTREAM_S_IMPLEMENTATION_BRIEF.md` | status flip + §8/§9 | AUTHORIZED AND EXECUTED; the PATCH-path inventory extension documented |
| `ROLE_DATA_VISIBILITY_MATRIX.md` | addendum §A status flip | the §37/§38 deviation → FIXED at this HEAD (with the executed negative-test note) |
| This file §6.3 | EXECUTED note | the S execution record + the honest BLOCKED disclosure |
| `MASTER_ENGINEERING_STATE.md` | §13 + §14 dated addenda | the decision closure + S-done state |
| `MASTER_ENGINEERING_ROADMAP.md` | forward-layer addendum | Phase S DONE at this HEAD |
| `ASAS_CRM_IMPLEMENTATION_CHECKPOINT.md` | new current-phase record | the resume point |
| `DECISION_LOG.md` | D-GOV-10 | the decision + implementation + verification record |
| `worklog.md` | WS-S-EXEC entry | the append-only session record |
| Application source | `src/lib/server/reservation-dto.ts` (NEW) · `src/app/api/reservations/route.ts` · `src/app/api/reservations/[id]/route.ts` · `src/components/crm/pipeline/deal-economics-agent.tsx` · `src/lib/i18n/domains/pipeline.ts` | the security fix + the regression-only UI adjustment |
| Evidence | `download/qa-ws-s/` ×6 · `tmp-scripts/ws-s-*.ts` ×6 | the executed-test outputs + the probe scripts |

**No schema, migration, seed, secret, scheduler, git-remote, or deployment change.**