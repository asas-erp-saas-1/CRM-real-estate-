# 00_PROJECT_GOVERNANCE

**Purpose (EN):** Living engineering governance: master state, roadmap, plan, decision log, risk register, technical debt, test strategy.
**الغرض:** الحوكمة الهندسية الحيّة: الحالة الرئيسية وخريطة الطريق والدستور الهندسي وسجلّ القرارات والمخاطر والدين التقني.
**Documents:** 24 · **Renamed from:** `engineering`

| # | File | Title | Bytes |
|---:|---|---|---:|
| 1 | `ASAS_CRM_IMPLEMENTATION_CHECKPOINT.md` | ASAS CRM — Implementation Checkpoint | 166,288 |
| 2 | `ASAS_UI_UX_PLATFORM_TRANSFORMATION.md` | ASAS UI/UX PLATFORM TRANSFORMATION — Program of Record | 18,926 |
| 3 | `ASAS_UI_UX_TRANSFORMATION.md` | ASAS UI/UX TRANSFORMATION — Program of Record | 11,204 |
| 4 | `DATABASE_RECOVERY_PROPOSAL.md` | ASAS CRM — Database Recovery Proposal (Dedicated Test Environment) | 41,433 |
| 5 | `DECISION_LOG.md` | DECISION LOG (ADRs — Phase 2) | 190,750 |
| 6 | `ENGINEERING_ROADMAP.md` | RETIRED — superseded by MASTERENGINEERINGROADMAP.md (Phase 5, 2026-10-03; GOV-5 restructur | 695 |
| 7 | `MASTER_ENGINEERING_PLAN.md` | MASTER ENGINEERING PLAN | 8,492 |
| 8 | `MASTER_ENGINEERING_ROADMAP.md` | MASTER ENGINEERING ROADMAP | 148,962 |
| 9 | `MASTER_ENGINEERING_STATE.md` | MASTER ENGINEERING STATE | 159,365 |
| 10 | `NEXT_PHASE_PLAN.md` | ASAS CRM — Next-Phase Plan v2 (Lifecycle, Permissions, Security Remediation, Roadmap A–H) | 67,672 |
| 11 | `OWNER_DECISION_FORM.md` | ASAS CRM — Owner Decision Form (2026-10-25) | 23,480 |
| 12 | `OWNER_DECISION_REGISTER.md` | ASAS CRM — Canonical Owner Decision Register | 78,202 |
| 13 | `OWNER_UI_WORKFLOW_CONTINUATION_PLAN.md` | ASAS CRM — Owner-UI Workflow Continuation Plan | 11,142 |
| 14 | `PHASE18_CRM_PREMIUM_OPERATING_MODEL.md` | PHASE 18 — CRM PREMIUM OPERATING MODEL (agency life, roles, field workflow, deal economics | 8,366 |
| 15 | `PHASE20_VISIT_DECISION_LIFECYCLE.md` | PHASE 20 — Visit Decision Lifecycle (program of record) | 4,781 |
| 16 | `PHASE_4_COMPLETION_REPORT.md` | PHASE 4 COMPLETION REPORT — Full Product Engineering | 10,146 |
| 17 | `PLATFORM_HANDOFF_RESEARCH.md` | Platform Handoff Research Record (H6-b) | 20,639 |
| 18 | `PRODUCTION_READINESS.md` | PRODUCTION READINESS | 17,303 |
| 19 | `PRODUCT_CAPABILITY_MATRIX.md` | PRODUCT CAPABILITY MATRIX (Phase 4 output — evidence-based) | 13,149 |
| 20 | `RECOVERY_GOVERNANCE_PROTOCOL.md` | ASAS CRM — Engineering Recovery & Governance Protocol (Execution Record) | 19,659 |
| 21 | `RISK_REGISTER.md` | RISK REGISTER | 6,826 |
| 22 | `TECHNICAL_DEBT.md` | TECHNICAL DEBT (categorized) | 4,478 |
| 23 | `TEST_STRATEGY.md` | TEST & VALIDATION STRATEGY | 5,840 |
| 24 | `WORKSTREAM_S_IMPLEMENTATION_BRIEF.md` | ASAS CRM — Workstream S Implementation Brief (security remediation: reservation financial- | 17,460 |

--- Part of `ASAS_CRM_COMPLETE_PORTABLE_PROJECT/05_ENGINEERING_DOCUMENTATION` — see root `README.md` for the master index.
