# PRODUCT CAPABILITY MATRIX (Phase 4 output — evidence-based)

Statuses: **Implemented** (works end-to-end: UI → API → guards → DB → audit) · **Partial** (works with defined gaps) · **Mock/Broken** (none found) · **Missing** (not built) · **Not required** (deliberate product scope decision for the Algiers single-agency real-estate domain).

Evidence column = primary code/doc reference. Last full verification: Phase 4 sprint (this session, guard matrix 34/34 + agent-browser QA; see worklog P4).

## Core CRM

| Capability | Status | Evidence / Notes |
|---|---|---|
| Leads | Implemented | Full lifecycle w/ terminal locks (P4 guards); search/filter/sort/pagination; bulk (assign/status+reason/tag/archive); import/export; tags; requirements; matching (bidirectional — see Matching engine row); AI copilot; WhatsApp deep-link; dedup checker (`/api/leads/check-duplicates`) |
| Lead qualification | Implemented | score 0-100, priority, status funnel, requirements model, copilot suggestions |
| Matching engine | Implemented | Weighted deterministic engine (§15 — budget 35 / location 25 / surface 15 / type 15 / parking 10, org-tuned via Settings); forward: lead→inventory top-20 persisted PropertyMatch w/ SUGGESTED→PRESENTED; **reverse (P24, D-032): apartment→waiting demand** — GET /api/matching/apartments/:id recomputes the SAME engine over live requirements (D-021 lead-law scoped, CLOSED_LOST excluded, floor 50, top 20) rendered as the apartment dialog's «demande en attente» panel (rows pitchable via WhatsApp while the lot is AVAILABLE — P25/D-033); matrix FR24a–f oracle probes |
| Contacts | Partial | Auto-created on conversion (1:1 with lead via unique leadId); profile shown in drawer. **Gap**: no standalone contact CRUD/UI — contacts are conversion artifacts, which matches the current funnel (lead-centric). Company accounts see below |
| Companies | Not required* | Domain = single-agency developer-side sales; counterparties are individuals/families. `Contact.type` reserves INDIVIDUAL/COMPANY (constants, P4). *Revisit if B2B/developer accounts become a product requirement |
| Opportunities / Deals | Implemented | Kanban pipeline, 10 stages, terminal-stage guards (closedAt+probability facts, P4), inline editing, next-action discipline, won/lost reasons |
| Pipelines & stages | Partial | DB models multi-pipeline (Pipeline/PipelineStage); UI/API use the default pipeline. Multiple pipelines = optional future capability (needs product decision) |
| Activities (timeline) | Implemented | Unified Activity primitive across entities; NOTE composer; NOTE deletion (author/manager, P4); system entries immutable by design |
| Tasks | Implemented | Types/priority/status, "my tasks" view (today/overdue/done), auto follow-up tasks from completed visits, delete (P4) |
| Calls | Partial | CALL activity logging + tel: deep links. No telephony integration (boundary: manual logging — WhatsApp-first market) |
| Meetings | Partial | Domain-adapted: Visits are the customer meeting entity; MEETING task type exists |
| Notes | Implemented | Composer (4 types) + timeline rendering + deletion (P4) |
| Follow-ups | Implemented | nextFollowUpAt + FOLLOW_UP tasks + auto-task on completed visits + overdue dashboards |
| Appointments (visits) | Implemented | Scheduling w/ agent+project+units (P4 unit picker), statuses, outcome discipline, rescheduling, calendar view, deletion (P4) |
| Communications | Partial | WhatsApp deep links + WHATSAPP_SENT audit (leads table + lead drawer popover + **demand panel pitch (P25, D-033): the lotAvailable contextual template — the exact lot facts prefilled, truth-gated on AVAILABLE**); call/email/sms activity log types. No in-app messaging (deliberate — market uses WhatsApp) |
| Tags | Implemented | LeadTag many-to-many, bulk add, filter chips |
| Sources & attribution | Implemented | 13 sources w/ icons, campaign/utm fields, source analytics |
| Assignment / ownership | Implemented | Single + bulk, owner validation, audited, agent leaderboard |

## Administration

| Capability | Status | Evidence / Notes |
|---|---|---|
| Users | Implemented | Create/update/deactivate, rank ceiling, self-guards, last-owner protection, CSPRNG temp passwords (P2-R1) |
| Teams | Not required | Single agency; ownership + roles cover team semantics. Multi-team = future product decision |
| Roles & permissions | Partial | 7-role rank RBAC, server-enforced on every route; granular per-action permissions = roadmap Phase 5 (optional) |
| Organization | Partial | Multi-org modeled in schema (orgId everywhere); single-org seeded. Multi-tenant onboarding = future |
| Settings | Implemented | Org settings, team mgmt, saved searches, sales targets, audit journal |
| Audit logs | Implemented | ~31 actions w/ before/after snapshots, entity filter, full trilingual labels (P4), RBAC MANAGER+ |

## Operations

| Capability | Status | Evidence / Notes |
|---|---|---|
| Entity search | Implemented | Server-side per-entity (leads/opps/apartments/tasks/visits/audit) with indexes |
| Global search | Implemented | Ctrl+K palette, grouped results, deep links |
| Filters & saved views | Implemented | Composable filters, removable chips, saved searches per user; P7-2: TEAM sharing (owner toggle, read-only team rows, audited) |
| Bulk operations | Implemented | Desktop toolbar + mobile selection mode (P4); destructive actions confirmed + reason-gated |
| CSV import | Implemented | Preview/validate/dedupe/commit-in-tx/undo; real auto-mapping (P4); defang-aware round-trip |
| CSV export | Implemented | MANAGER+ only, formula-injection neutralized (P4); shared conventions `lib/server/csv.ts` (P7-4) |
| Full-snapshot export bundle | Implemented | One-click ZIP: 5 entity CSVs + manifest, audited, bounded 5 000/entity (P7-4) |
| Notifications | Partial | In-app bell (reservation expiry sweeper, task/visit reminders). No push/email channels (use-case pending) |
| Activity history | Implemented | Unified timeline per lead/opportunity |
| Printable visit sheet (fiche de visite) | Implemented | P23 (D-031): GET /api/visits/:id visitScope-exact read-only payload + print-scoped A4 dialog from every visit row (list + calendar); @media print isolates the sheet (CDP print-to-PDF = sheet-only); client criteria + full apartment facts + project address + ruled notes; i18n ×3, AR RTL; matrix FR23a–e |

## Analytics

| Capability | Status | Evidence / Notes |
|---|---|---|
| Dashboard | Implemented | KPI cards, 4 range tabs, agent leaderboard, live data |
| Pipeline metrics | Implemented | Pipeline value, stage distribution, avg stage durations |
| Lead metrics | Implemented | Status funnel, source mix, conversion rate |
| Conversion metrics | Implemented | Lead→won funnel + rates; targets achievement |
| Revenue metrics | Implemented | Won DZD per range/month, sales targets (monthly/user), won-history seeded coherently |
| Activity-volume over time | Implemented (P21/D-029) | Dashboard « Volume d'activité » panel: `activitySeries` daily buckets (continuous zero-filled axis, adaptive `all` origin) + exact `activityTotal`, scoped by `activityScope` (My Day law — never a management-gated null); recharts AreaChart (chart-5 teal); matrix FR20a–e; E2E ×3 roles + AR/dark/mobile, 0 console errors |

## Cross-cutting (Phase 4 focus areas)

| Area | Status | Notes |
|---|---|---|
| Authentication | Implemented | scrypt + HMAC-signed cookies + lockout + timing-oracle closed (P4) + demo gate |
| Authorization | Implemented | Server-side on every route incl. new deletes; UI hiding is UX only |
| Validation | Implemented | zod on every write; enum closure (P4, D-016) — no free-string write-side enums remain except documented display-only fields |
| Transactions | Implemented | Lead conversion, reservation booking, import commit — interactive tx; guards coherent (P4 reservation-release guard) |
| Error handling | Implemented | ApiError taxonomy, error boundaries (segment+root), friendly copilot labels (P4) |
| Data integrity | Implemented | Lifecycle guards, terminal facts, coherence guards; migrations-based schema (2 migrations) |
| i18n | Implemented | fr/en/ar + RTL, domain modules composed at `src/lib/i18n/` — **single source (P26 D-034: the legacy single-file shadow DELETED after its 20 domains-absent keys were migrated byte-exact; the file-before-folder resolution had stranded 340 domains-only keys rendering raw)**; completeness guarded by matrix §26 (869 static literals + dynamic families ×3 langs) |
| Performance | Implemented* | 5 composite indexes (P4) + helper dedup; component extraction & i18n module split remain (optional, mechanical) |
| Observability | Partial | Audit trail + console diagnostics; no metrics/tracing (out of scope pre-deployment) |

## Explicitly deferred (product-owner decisions required — R5/R6)

- **R5**: 7 seed-legacy apartments RESERVED/OPTIONED with no reservation row (release or backfill).
- **R6**: possible Mohamed Larbaoui duplicate lead (merge or confirm distinct).
- Multiple pipelines; company/account entities; granular permissions; multi-tenant onboarding; external integrations (telephony, email sending, push) — all Phase 5 candidate scope, none blocking for the current product stage.

## Deal economics & field operations (P18, D-025 — 2026-10-09)

The Finance/Collections section (P13/D-022) and the sales-targets surface (R10-4) were **REMOVED
by explicit user product decision** — financial/accounting content moves to the future ERP
("when we finish CRM premium real estate agency we move on to ERP"). The CRM keeps only the
money the agency and its reps EARN on a deal. Product truth: `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/AGENCY_OPERATING_MODEL.md`.

| Capability | Status | Evidence / Notes |
|---|---|---|
| Agency commission (manager+) | Implemented | Reservation.commissionAmount + commissionFrom (DEVELOPER or CLIENT); PATCH economics branch (403 COMMISSION_FORBIDDEN below MANAGER; 422 COMMISSION_PAIRING when amount/source unpaired); COMMISSION_SET audit; opp-dialog "Économie du deal" section; manager dashboard "Commissions du mois" |
| Agent incentive (rep-visible) | Implemented | Reservation.agentIncentive — read by the reservation agent (opp dialog read-only card) + MANAGER+; agent dashboard "Mes incentives" (month/all-time/deals); [orgId,agentId] aggregation index |
| Field visit confirmation | Implemented | SCHEDULED→CONFIRMED only for the assigned FIELD_REP or MANAGER+ (403 VISIT_CONFIRM_FORBIDDEN); ConfirmVisitDialog (on-site, optional final date → agenda); confirmedAt/confirmedById stamps + timeline entry; viewerCanConfirm server flag drives list/calendar buttons; awaiting-field-rep hint for the follow-up rep |
| Project assignments (Équipe terrain) | Implemented | ProjectAssignment model (unique [projectId,userId]); POST/DELETE assignments route (MANAGER+, FIELD_REP-only assignees 422 otherwise, **ACTIVE-only since P20-C** — 422 ASSIGNEE_INACTIVE, §17.2; audited with affected-future-work facts); "Équipe terrain" panel in the inventory project detail; CEO/exec assigns per the operating model |
| No-eligible-rep exception (§17.3) | Implemented (P20-C/D-028) | `unstaffedVisits` MANAGER+ attention KPI (dashboard strip third cell, hides on null below MANAGER) + per-row `projectHasFieldRep` decoration + amber guidance chip (informational span below MANAGER, deep-link button → Équipe terrain for MANAGER+) in visits-view + calendar; eligibility = assignment to an ACTIVE FIELD_REP; the assign flow resolves the exception (matrix FR19c-b probed); FIELD_PENDING_STATUSES = SCHEDULED/RESCHEDULED single source |
| FIELD_REP data isolation | Implemented | Pure relation predicates through project.assignments (visits/leads/opps/contacts/activities/reservations); tasks own-only; no intake pool; leads/pipeline nav hidden; notifications via shared primitives; cross-rep 404-byte-equality (matrix FR1/FR2/FR10) |
| Role system (agency life) | Implemented | ROLES = OWNER (Président·CEO) / ADMIN / MANAGER (Directeur exécutif) / SALES_AGENT (Représentant commercial) / FIELD_REP (Représentant terrain); MARKETING/ACCOUNTING/OPERATIONS removed + users reassigned in-migration; labels fr/en/ar; ROLE_TONE violet for FIELD_REP |
| Visibility | Implemented | matrix probes FR1–FR26 + CLEANUP — **163/163 ×3 steady-state (149 activities)** |
| i18n / RTL / a11y | Implemented | visits.confirmOnSite.* + awaitingFieldRep + confirmedBy; properties.team.*; oppd.econ.*; commission.*; incentives.*/commissions.* — ×3 langs; AR RTL + mobile 390 verified live; **P26: the 340 stranded keys live again (demand panel, visit decisions, attention strip, role labels, WhatsApp templates), 0 raw keys across all views/languages — probed**; **P27: document scrollWidth = viewport at 390px on every view, LTR and RTL (shell-level overflow-x-clip — the touch-area pseudo phantom closed; hit-area floors preserved)** |
| Full ERP accounting | Out of scope | The future ERP (after CRM premium) owns accounting — the CRM ships a clean data contract (reservation economics + export bundle) |

