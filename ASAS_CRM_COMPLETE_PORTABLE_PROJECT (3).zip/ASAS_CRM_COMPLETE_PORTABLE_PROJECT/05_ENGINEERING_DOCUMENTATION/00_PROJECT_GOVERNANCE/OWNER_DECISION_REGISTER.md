# ASAS CRM — Canonical Owner Decision Register

**Created:** 2026-10-25 (the documentation-only reconciliation task — worklog `UX-OWNER-PLAN-1`).
**Purpose:** the single canonical register of OWNER-level product/business decisions — approved directions,
open sub-decisions, and retired questions. This file consolidates what was previously scattered across
`05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/PHASE_D_LIFECYCLE_COHERENCE.md` §8 (the #1–#7 list), `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/WAVE_2B_OWNER_DECISION_BRIEF.md`
(D1–D4), and `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/WAVE_3_OWNER_DECISION_REQUESTS.md` (D5–D6). It EXTENDS those records — no historical
decision is overwritten or silently reinterpreted (the append-only law).

**Statuses:** `APPROVED` (owner decided, recorded) · `APPROVED-DIRECTION` (the owner recorded a binding
direction; named sub-decisions remain open) · `RECOMMENDED-PENDING` (engineering recommendation —
**NOT APPROVED**) · `OPEN` (undecided) · `RETIRED` (withdrawn by the owner).

**Sources of owner authority (verified this session):**
- **S-DIR-2026-10-25** — `upload/Pasted Content_1792969410164.txt` (the "Owner Decision Reconciliation,
  Lifecycle Engineering Review, and Documentation-Only Roadmap Update" directive; byte-identical copy at
  `upload/Pasted Content_1792968288177.txt` — both retained). Carries: D-OWNER-01, D5, D6, Wave 2B,
  demo-mode, Wave 4 retirement, deployment/integration boundaries.
- **S-DIR-2026-10-24** — the Phase D directive (`upload/Pasted Content_1792811796192.txt`, on file per
  `05_ENGINEERING_DOCUMENTATION/05_UX_UI_DESIGN/PHASE_D_LIFECYCLE_COHERENCE.md` header): authorizes the Phase D UX/UI architecture track
  (bounded Path B / D-UX-PD-1) while preserving every business-rule gate.
- **S-GOV-2026-10-19** — the owner's Ratification & Execution Directive (**D-GOV-5**, `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DECISION_LOG.md`):
  incremental remediation inside the retained architecture (D-GOV-4 ratified); controlled implementation.
- **S-GOV-2026-10-19b** — **D-GOV-6**: R5 legacy orphan holds RESOLVED (released to AVAILABLE).
- **S-P18** — **D-025**: the agency operating model is the product truth (`05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/AGENCY_OPERATING_MODEL.md`).

---

## 1. The register (state at 2026-10-25 — superseded by §1a below; kept verbatim per the append-only law)

| ID | Decision | Status | Source | Open sub-decisions |
|---|---|---|---|---|
| **D-OWNER-01** | Representative workspace may include management actions — precise action set NOT approved | **APPROVED-DIRECTION** | S-DIR-2026-10-25 §3 | Q6 action-by-action permission table (see `OWNER_DECISION_FORM.md`) |
| **D5** | Commission calculation helper; manager confirms or edits the suggested result — NO authoritative rate/percentage/basis/formula approved | **APPROVED-DIRECTION** | S-DIR-2026-10-25 §3 | Q7 helper input/output contract, suggested-vs-confirmed semantics, logging & visibility |
| **D6** | Closure-economics gate: warn when incomplete + explicit, reason-gated, audited waiver — completeness = commission amount, commission payer, representative incentive, written bases (commissionBasis + incentiveBasis, field names verified `prisma/schema.prisma:597-608`); incentive-not-due = recorded zero + written explanation; zero ≠ proof of payment | **APPROVED-DIRECTION** | S-DIR-2026-10-25 §3 | Q8 exact validation/waiver semantics; whether request_closure also warns; zero/NA/waived/paid representation |
| **WAVE-2B** | Lead inline editing: ONLY the previously specified safe fields — email, secondary phone, WhatsApp, priority, score, notes, budget, property type, desired location, next follow-up (`email/secondaryPhone/whatsapp/priority/score/notes/budgetMin+budgetMax/propertyType/desiredLocation/nextFollowUpAt` — all verified accepted by the PATCH contract, `src/app/api/leads/[id]/route.ts:125-146`). **Primary phone and customer name remain OUT of scope.** In-scope identity-field changes generate the formal audit record + timeline entry with before/after values. Stale-data guard approved IN PRINCIPLE (backward-compatible optional expected-version token; clear conflict/reload UX) | **APPROVED-DIRECTION** | S-DIR-2026-10-25 §3 (supersedes the D1 recommendation; phone stays immutable, name excluded) | Per-field audit distinction (identity vs routine); D4-B guard contract details; D2 (phone validation) NOT needed — phone out of scope |
| **DEMO-MODE** | Demo mode OFF by default, explicitly opted into in development; production remains unauthorized | **APPROVED-DIRECTION** | S-DIR-2026-10-25 §3 | None at the decision level — the config contract & tests are planned work (Phase G of `NEXT_PHASE_PLAN.md`); today's code default is ON (inverted later, separately authorized) |
| **WAVE-4** | Wave 4 RETIRED as a separate engineering pass; justified polish may be prioritized within ordinary future workstreams | **RETIRED** | S-DIR-2026-10-25 §3 | None — do not recreate |
| **DEPLOY/INTEGRATE** | Deployment + GitHub publication NOT authorized; automated inbound WhatsApp/Ouedkniss NOT authorized (may remain attribution sources); single sales pipeline (no multi-pipeline activation); finance/payments/ERP out of ASAS scope | **APPROVED** (standing prohibition) | S-DIR-2026-10-25 §3 | None until the owner explicitly reopens |
| **#1 wave approvals/order** (Phase-C-era) | The wave-order approval question | **SUPERSEDED** — the wave framework is replaced by the Phase A–H plan proposal (pending owner approval of the plan itself) | PHASE_D §8 | Approve/reorder `NEXT_PHASE_PLAN.md` Phases A–H |
| **#2 Wave-2B scope** | Which fields become inline-editable | **RESOLVED-BY-DIRECTION** → WAVE-2B above (option-A field set; name+phone excluded) | PHASE_D §8 → S-DIR-2026-10-25 | Per-field audit treatment only |
| **#3 = D5 commission basis** | The % derivation model | **RESOLVED-BY-DIRECTION** → D5 above (helper + manager confirm; no authoritative rate) | WAVE_3 doc → S-DIR-2026-10-25 | Q7 details |
| **#4 = D6 closure gate** | Hard block vs warning+waive | **RESOLVED-BY-DIRECTION** → D6 above (warning + reason-gated audited waiver) | WAVE_3 doc → S-DIR-2026-10-25 | Q8 details |
| **#5 demo-mode policy** | Demo-mode default | **RESOLVED-BY-DIRECTION** → DEMO-MODE above | PHASE_D §8 → S-DIR-2026-10-25 | Implementation timing |
| **#6 rep-workspace scope (R7)** | What a manager may see/do per-rep beyond D-021 scoping | **OPEN — direction partially given by D-OWNER-01** | PHASE_D §8 | Q6 + the R7 per-rep surface scope (leaderboard `agentId` navigation stays honestly static until decided — the D7-R5 law) |
| **#7 lead-PATCH stale-guard** | Optimistic concurrency for lead edits | **RESOLVED-BY-DIRECTION** → WAVE-2B above (guard approved in principle, backward-compatible optional token) | PHASE_D §8 → S-DIR-2026-10-25 | Error-code/UX details (engineering-specifiable) |
| **Q1–Q5 lifecycle gates** (visit-completion gate scope/strictness/exceptions/report contract/report authority) | NOT yet decided — new decisions surfaced by the lifecycle review | **OPEN** (recommendations RECOMMENDED-PENDING in the form) | `OWNER_DECISION_FORM.md` | Block Phase B implementation |
| **Q9 cleanup approval boundary** | Artifact/screenshot cleanup authorization | **OPEN** — inventory + plan delivered, zero deletions performed | `NEXT_PHASE_PLAN.md` §7 | Blocks Phase H execution |

## 2. Preserved prior owner decisions (context — full records in their canonical homes)

- **D-025 / P18** — the agency operating model is the product truth (roles, visit confirmation authority,
  "deal economics are the only money"). `05_ENGINEERING_DOCUMENTATION/02_DOMAIN_MODEL/AGENCY_OPERATING_MODEL.md` · `DECISION_LOG.md`.
- **D-021** — role/record visibility law (scoped findFirst → ghost-404). Binding; never weakened for
  workflow convenience (S-DIR-2026-10-25 §3 restates: preserve D-021 and org isolation).
- **D-GOV-4 / D-GOV-5 (2026-10-19)** — architecture verdict + ratification: incremental remediation,
  retained architecture; the P0–P5 remediation tiers executed.
- **D-GOV-6 (2026-10-19)** — R5 legacy holds RESOLVED (released; seed aligned).
- **Two-step sale closure APPROVED** (G5-P3-2): agent prepares with evidence → manager validates.
  D6's gate must NOT weaken this (S-DIR-2026-10-25 §3).
- **Lead/Opportunity transition matrices APPROVED** (G5-P3-7): controlled state machines + manager
  correction hatch — the free-form code was the defect.
- **Production NOT AUTHORIZED** — the P5 deployment tier stays `[deploy]`-gated (PRODUCTION_READINESS.md);
  demo-mode production=0 is part of that tier (G5-P5-2).
- **Standing prohibitions reaffirmed by S-DIR-2026-10-25:** no ERP/payments scope; no multi-pipeline;
  WhatsApp/Ouedkniss inbound automation out; preserve canonical entity navigation, shared status
  components, historical audit semantics, organization isolation, D-021.

## 3. Register laws (inherited, binding)

1. **An existing code path is NOT proof of owner approval** of its underlying semantics (the Wave-3 law).
2. **Recommendations are NOT approvals** — every recommendation in the form is labeled RECOMMENDED — NOT APPROVED.
3. **Do not reopen approved decisions** because an alternative looks attractive; genuine contradictions
   become explicit owner-review exceptions (S-DIR-2026-10-25 §3 "Scope control").
4. **Scope control:** preserve org/workspace isolation and D-021 peer visibility; server authorization is
   authoritative, UI hiding supplementary; never broaden commission/incentive visibility to all
   representatives by default (field-level and action-level access recommended separately).
5. **Zero-incentive honesty:** a recorded zero + written basis is the approved representation of
   "incentive not due"; zero is never proof that payment occurred (S-DIR-2026-10-25 §3, D6).

## 4. Decision-to-work mapping (what each decision gates)

| Decision | Gated implementation work | Can anything proceed without it? |
|---|---|---|
| Q1–Q5 (lifecycle gates + report contract) | Phase B (lifecycle spec) and the server gate implementation inside Phase C | Yes: Phase A (docs), Phase G test-strategy, Wave-2B client work, D5/D6 design specs proceed independently |
| D5 details (Q7) | Phase E commission-helper implementation | Yes: D6 design + everything above |
| D6 details (Q8) | Phase E closure-gate implementation | Yes: D5 design + everything above |
| D-OWNER-01 details (Q6) | R7 per-rep surface + representative workspace actions | Yes: all lifecycle/UX work that stays within existing permissions |
| Q9 cleanup | Phase H artifact cleanup | Yes: everything (cleanup is independent) |
| DEMO-MODE implementation | Phase G config flip (separate execution authorization) | Yes: all feature work |

**Historical test results are commit-anchored, not re-runnable as-is:** the standing suites
(matrix 325/325 · Wave 21/22/55 · Phase D 15/15 · D7 17/10/10/14/7/7) were green at their respective
commits (last full set: D7-R6 closure, HEAD `4dbb89f` ancestry) — the current environment reset (empty
DB, no `_prisma_migrations`, ephemeral secret) requires the canonical recovery BEFORE any re-run
(`NEXT_PHASE_PLAN.md` §8).

---

## 1a. Register update — 2026-10-26 (UX-OWNER-PLAN-2: the owner's Q1–Q11 answers)

**New source of owner authority:** **S-DIR-2026-10-26** — the owner's answers to the Q1–Q9
questionnaire (+ the new Q10/Q11 directions), supplied in-session 2026-10-26 under task
`UX-OWNER-PLAN-2`. Every answer is recorded verbatim-faithfully below (the answers arrived as the
session's directive text — task ID “UX-OWNER-PLAN-2”, authority line “Owner-approved decisions
supplied on 2026-10-26”). **Status qualifier binding on ALL rows of this section:** these are
**approved owner decisions for PLANNING purposes — they do NOT authorize implementation.** The owner
must review the revised plan (`NEXT_PHASE_PLAN.md`, revised this round) and explicitly authorize a
defined implementation phase before any code changes.

Code evidence for every predicate below was re-verified at HEAD `494b87a` (branch `main`, worktree
clean) by sub-agents 3-a/3-b/3-c/3-d (+ lead spot-verification) — records in `agent-ctx/3-a-*`,
`3-b-*`, `3-c-*`, `3-d-*`.

### 1a.1 New decisions recorded (approved 2026-10-26)

| ID | Decision (owner's words, condensed) | Status | Source | Open sub-decisions |
|---|---|---|---|---|
| **GATE-Q1** | Visit/report gate scope = **Opportunity lifecycle ONLY**. The gate applies to the relevant Opportunity stage transition; the completed visit must be linked to **the same Opportunity** (a visit for another property/customer/opportunity never satisfies it); the Lead lifecycle stays ungated by default. Boundary verified against the actual matrix (`OPPORTUNITY_TRANSITIONS`, constants.ts:125-136): `VISIT_SCHEDULED` EXISTS and is semantically the boundary stage — **no material mismatch**. Precise formalization (see NP§2.1): the gate fires on every PATCH stage change from a pre-visit stage {NEW, QUALIFIED, VISIT_SCHEDULED} to a beyond-visit stage {VISIT_COMPLETED, NEGOTIATION, OPTION, RESERVATION, CONTRACT} — covering BOTH the `VISIT_SCHEDULED` exits AND the legal skip edges (e.g. NEW→VISIT_COMPLETED, QUALIFIED→NEGOTIATION, verified legal in the matrix). | **APPROVED** (planning) | S-DIR-2026-10-26 Q1 | **RQ-1** (CLOSED_LOST exemption — see 1a.4) · **RQ-2** (validate_closure extension — see 1a.4) |
| **GATE-Q2** | **Strict blocking, NO override.** The gated transition must not proceed until the visit has actually been completed AND its required report exists. **No manager override; do NOT add any `waiveVisitGate`-equivalent mechanism.** A D6 financial-completeness waiver must NEVER satisfy or bypass the visit/report gate — separate controls, separate purposes. Retires PLAN-1's option-B manager-override RECOMMENDATION (never approved — no historical decision contradicted). Per Q5's wording, **no role may bypass the strict visit gate** — manager correction-class PATCHes across the boundary are gated too. | **APPROVED** (planning) | S-DIR-2026-10-26 Q2 | none |
| **GATE-Q3** | Exceptional outcomes (no-show, customer cancellation, representative cancellation, rescheduling, incomplete visit): **gate stays CLOSED** — never mark COMPLETED unless the visit actually occurred; a cancelled/no-show/incomplete visit never satisfies the gate; provide a clear follow-up alert; consider OPTIONAL structured fields for cancellation initiator + incomplete reason (schema compatibility verified: neither exists today — additive proposals live in the roadmap, RECOMMENDED — NOT APPROVED); preserve reschedule/subsequent-visit without rewriting history (verified fit: `NO_SHOW→RESCHEDULED` only; COMPLETED/CANCELLED/REJECTED terminal; CONFIRMED→SCHEDULED manager reset — constants.ts:54-62). Includes PLAN-1's recommended option-B column (visibility + optional fields). | **APPROVED** (planning) | S-DIR-2026-10-26 Q3 | the two optional additive fields (roadmap proposals only) |
| **REPORT-Q4** | Standard visit report: **required** = customer-interest level (4-value enum: very interested / interested / neutral / not interested) + written report notes (property discussed + customer objections) + author & timestamp recorded by the SERVER; **optional** = follow-up recommendation + next-action due date. Schema verified: NONE of these exist on `Visit` today (schema.prisma:434-481) — all are ADDITIVE proposals in the roadmap only. Corrections must be audited and must NOT erase the historical report (revision mechanism proposal: existing `logAudit` before/after + additive corrected stamps — NP§2.4). No additional mandatory fields beyond this contract without a separate documented recommendation. | **APPROVED-DIRECTION** (implementation = roadmap only) | S-DIR-2026-10-26 Q4 | field names/types final at spec time |
| **REPORT-Q5** | Report authority: the **assigned FIELD_REP** may submit; if none is assigned, the **representative responsible for the customer** (verified carriers: the lead's ownerId / the visit's agentId — `agentId` defaults to `lead.ownerId`, visits/route.ts:300) may submit, subject to actual assignment/authorization rules; **managers may review**; corrections auditable; **ordinary valid transitions do NOT require per-report manager approval**; **no role may bypass the strict gate**. Role names verified against ROLES/ROLE_RANK (constants.ts:354-360) — no new hierarchy invented. | **APPROVED** (planning) | S-DIR-2026-10-26 Q5 | none |
| **WORKSPACE-Q6a** | Representative workspace visibility: a representative sees their OWN workspace + records authorized by existing visibility rules; MANAGER+ may inspect representative workspaces within organization scope; **D-021 and peer-record restrictions remain intact**. Resolves register row **#6** at the visibility level (the R7 per-rep surface direction — leaderboard `agentId` navigation may now be specified; the D7-R5 honest-static law lifts WITH an implementing change only). | **APPROVED** (planning) | S-DIR-2026-10-26 Q6a | per-surface spec details (engineering-specifiable) |
| **POOL-Q6b** | Self-assignment: a representative may assign an **unassigned pool lead** (ownerId IS NULL — verified pool semantics, visibility.ts ownOrPool) to themselves, with the formal **LEAD_ASSIGNED** audit event (exists, in-tx, before/after ownerId — leads/[id]:337-345), IF the record is genuinely available and ALL server-side conditions pass. **A representative must NEVER take a lead assigned to a colleague.** Current code gates ownerId changes MANAGER+-only (leads/[id]:217-220) — the additive carve-out (agent path: null→self ONLY) is planned, not implemented. | **APPROVED** (planning; implementation separately gated) | S-DIR-2026-10-26 Q6b | none at the decision level |
| **TRANSITIONS-Q6c** | Representatives may perform an otherwise-permitted Opportunity transition DIRECTLY when all server-side validations and permissions pass. This grants NO permission to: bypass the visit/report gate · change records outside authorized scope · access another representative's private records · perform manager-only reassignment/financial/closure/correction operations · override other governance controls. **The proposed manager-request queue is NOT approved as a mandatory mechanism** — do not add one unless a new evidence-based dependency is presented for owner review. Retires PLAN-1's Q6.5 queue RECOMMENDATION. | **APPROVED** (planning) | S-DIR-2026-10-26 Q6c | none |
| **D5-DETAIL-Q7** | D5 commission helper: rate + calculation base = **optional manual inputs**; the result is a **transient calculation suggestion, NOT automatically persisted**; the **manager confirms or edits the final amount**; **NO default rate, authoritative rate table, or unapproved formula**; the **basis of the calculation must be recorded when the amount is confirmed**, using existing canonical audit paths where suitable (verified fit: COMMISSION_SET/INCENTIVE_SET already carry before/after family snapshots + decidedBy/decidedAt stamps — reservation-economics.ts:138-160); preserve current financial visibility restrictions. | **APPROVED** (planning) | S-DIR-2026-10-26 Q7 | none at the decision level (UI shape = spec work) |
| **D6-DETAIL-Q8** | D6 closure-economics mechanism: `request_closure` **warns** about incomplete economics; `validate_closure` **rejects** incomplete economics with **422 INCOMPLETE_ECONOMICS + an explicit list of missing fields**; an **authorized manager may explicitly waive** via the proposed `waiveEconomics` flag + **mandatory reason**; the waiver must be **auditable** (actor, time, reason, missing items); preserve transaction safety, closure governance, idempotency, existing trust constraints. Verified semantics ground: validate_closure = interactive tx w/ status-preconditioned updateMany claim + 409 idempotency; NO economics check exists today (confirmed absent). | **APPROVED** (planning) | S-DIR-2026-10-26 Q8 | **RQ-3** — zero vs not-applicable vs waived vs paid semantics (see 1a.4) |
| **CLEANUP-Q9** | Artifact cleanup: **planning ONLY** (this answer authorizes NO archiving/moving/renaming/deletion now). Candidate scope = the 7 zero-reference dirs + verified duplicate artifacts ONLY. Before any future cleanup: second reference audit (DONE this round — 3-d, all 7 CONFIRMED under the broader audit) + manifest + documented recoverable-archive procedure + reproducibility verification. Canonical seeds, regression fixtures, evidence, referenced screenshots, worklogs, unknown-purpose artifacts preserved until individually verified. | **APPROVED-DIRECTION** (execution = separate future task) | S-DIR-2026-10-26 Q9 | none (execution gate = the future cleanup task itself) |
| **FIN-MIN-Q10** | Reservation financial-field visibility: commission, incentive, and related financial-basis fields **must NOT be returned by server responses to roles below the authorized manager/administration boundary** — hiding in the UI is insufficient; the target is **server-side response minimization** (unauthorized fields not serialized at all). Verified current state: **the leak EXISTS** — GET /api/reservations serializes the full §37/§38 family to floor roles on in-scope rows (include, no field select, requireUser() with no role gate — reservations/route.ts:76,112-116) and POST /api/reservations returns the full model on 201. Recorded as a **security remediation priority + implementation blocker** (NP§6); no runtime behavior changed in this task. Existing authorization rules must not be weakened. | **APPROVED-DIRECTION** (implementation = separate security workstream) | S-DIR-2026-10-26 Q10 | none at the decision level (field-level matrix delivered — ROLE_DATA_VISIBILITY_MATRIX addendum) |
| **AUDIT-Q11** | Lifecycle audit coverage: plan formal audit coverage for **Lead qualification · Lead-to-Opportunity conversion · Opportunity-stage transitions · Visit completion**. Retain the operational activity timeline as the user-facing surface; create NO duplicate/contradictory events merely to satisfy the audit requirement. Verified census (3-c): qualification ✅ audited (LEAD_STATUS_CHANGED/CORRECTED) · stage transitions ✅ (OPPORTUNITY_STAGE_CHANGED/CORRECTED) · **conversion ❌ NONE** · **visit completion ❌ NONE** — the two gaps + the event taxonomy recommendation = NP§7. Not every ordinary field edit requires identity-edit-grade audit. | **APPROVED-DIRECTION** (taxonomy + coverage = NP§7, implementation gated) | S-DIR-2026-10-26 Q11 | none at the decision level |

### 1a.2 Status changes to §1 rows (2026-10-26)

| §1 row | Change | Grounds |
|---|---|---|
| Q1–Q5 lifecycle gates (OPEN) | → **RESOLVED-BY-DECISION** (GATE-Q1/Q2/Q3 + REPORT-Q4/Q5) | S-DIR-2026-10-26 answers |
| #6 rep-workspace scope (OPEN) | → **RESOLVED-BY-DIRECTION** (WORKSPACE-Q6a + POOL-Q6b + TRANSITIONS-Q6c) | Q6a/b/c answers |
| D5 (APPROVED-DIRECTION) | → **APPROVED** (details fixed by D5-DETAIL-Q7; the §1 row's open sub-decisions closed) | Q7 answer |
| D6 (APPROVED-DIRECTION) | → **APPROVED** for the mechanism (D6-DETAIL-Q8); the zero/NA/waived/paid representation sub-question stays OPEN (RQ-3) | Q8 answer + the owner's explicit “do not assume” list |
| Q9 cleanup (OPEN) | → **APPROVED-DIRECTION** (CLEANUP-Q9 — planning only; execution still gated on the separate future task) | Q9 answer |
| WAVE-2B / DEMO-MODE / WAVE-4 / DEPLOY-INTEGRATE / D-OWNER-01 / #1–#5 / #7 | **UNCHANGED** (no new owner input this round; all prior decisions preserved verbatim) | — |

### 1a.3 Conflict reconciliation (matrix condensed — full version in NP§0a)

| # | Existing statement | Latest owner decision | Real conflict? | Resolution |
|---|---|---|---|---|
| A | D6 waiver vs visit gate (PLAN-1 §2.1 contemplated a manager override family shared with D6) | GATE-Q2: strict block, NO override; D6 waiver must never bypass the visit gate | **No** (the override was RECOMMENDED-NOT-APPROVED, never a decision) | The override recommendation is RETIRED; the two controls are documented as separate enforcement points (visit gate ≠ economics waiver); a `waiveEconomics` retry clears ONLY the economics rejection, never the visit gate |
| B | PLAN-1 §5: “'not applicable' has NO dedicated representation (the zero+basis pair IS the approved expression)” — a generalized zero≡NA equivalence | Q8: zero+written explanation = incentive-not-due ONLY; do NOT assume zero≡NA, zero≡not-payable, waiver≡payment, confirmed amount≡money received | **YES — the PLAN-1 generalization exceeded the approved decision** (it was a recommendation, now corrected) | The generalization is RETIRED from the plan; the ONLY approved semantics: zero + written explanation records “not due” (never proof of payment); the schema's inability to distinguish not-due/NA/waived as distinct states = documented gap → **RQ-3** (narrowly-scoped question; no new financial status model invented) |
| C | PLAN-1 Q6.5 proposed a manager-request queue for rep transitions | TRANSITIONS-Q6c: direct transitions approved; the queue NOT approved as mandatory | **No** (never approved) | The queue recommendation is RETIRED; reps act directly within existing permissions; the queue may return ONLY with a new evidence-based dependency for owner review |
| D | PLAN-1 §2.1 recommended a manager override for no-visit deals | GATE-Q2/Q3: strict block; exceptional outcomes keep the gate closed | **No** (never approved) | Override recommendation RETIRED; no-visit deals cannot cross the boundary until a completed visit + report exists (the remote-sale consequence is documented as an accepted owner trade-off, NP§2.3) |
| E | Security docs' intended law (commission = management-only read) vs code reality (full §37/§38 family serialized to floor roles) — documented as drift D-2 awaiting owner adjudication | FIN-MIN-Q10: server-side minimization approved as direction | **No** (the drift awaited exactly this adjudication) | The code is the DEFECT, the documented visibility law is the TARGET: elevated to a security remediation priority + implementation blocker (NP§6); no runtime change in this task |

### 1a.4 Remaining open questions (narrowly scoped — the complete current list)

| ID | Question | Why it must be asked | Recommendation (NOT APPROVED) |
|---|---|---|---|
| **RQ-1** | Does the visit gate apply when a pre-visit-stage deal is moved to **CLOSED_LOST** (no completed visit)? | `CLOSED_LOST` is a legal exit from EVERY working stage (constants.ts:125-136) — gating it would make a pre-visit deal impossible to lose, a hard behavioral change never discussed with the owner | **Exempt CLOSED_LOST** — loss is not progression; early disqualification stays possible (Salesforce early-disqualification precedent, 2-d-1) |
| **RQ-2** | Must **`validate_closure`** (the reservation-lifecycle money event that writes opportunity CLOSED_WON directly, reservation-lifecycle.ts:191-196) also require the completed visit + report? | Without it the stage gate is bypassable: a reservation can be created on a NEW-stage opportunity and carried to CLOSED_WON with zero stage PATCHes (verified: reservation creation carries no stage precondition) | **Extend the same completed-visit requirement to validate_closure** (one check in the same interactive transaction) — else GATE-Q2's “blocked until the visit actually occurred” is bypassable on the money path |
| **RQ-3** | The zero/not-applicable/waived/paid financial semantics: keep the single recorded representation (zero + written explanation; waiver = audit receipt; paid = INCENTIVE_PAID + paidAt) or introduce an explicit additive semantics discriminator? | The current schema cannot distinguish “not due (zero)” from “not applicable” from “waived” as separate states; the owner explicitly forbade assuming their equivalence | **Keep the current representations** (zero+basis = not-due; waiver = audited receipt; paid = status+paidAt) and require the written explanation to carry the disambiguation — NO new financial status model unless the owner finds the ambiguity operationally costly |

### 1a.5 Updated decision-to-work mapping

| Decision | Gated implementation work | Can anything proceed without it? |
|---|---|---|
| GATE-Q1/Q2/Q3 + REPORT-Q4/Q5 | Phase B/C lifecycle implementation (visit gate + report contract + exception surfaces) | Specs are DONE this round (NP§2); implementation awaits the owner's plan review + RQ-1/RQ-2 answers (RQ-2 affects the enforcement-point spec) |
| WORKSPACE-Q6a / POOL-Q6b / TRANSITIONS-Q6c | R7 per-rep surface + representative workspace + the self-assignment carve-out | Specs DONE (NP§3); implementation awaits plan review |
| D5-DETAIL-Q7 | Phase E commission-helper implementation | Spec DONE (NP§4); implementation awaits plan review |
| D6-DETAIL-Q8 | Phase E closure-gate implementation | Spec DONE (NP§5) except the RQ-3 semantic; implementation awaits plan review + RQ-3 |
| FIN-MIN-Q10 | The security remediation workstream (response minimization on reservations GET/POST + regression probes) | Plan DONE (NP§6 + the matrix addendum); **prioritized as a security blocker — scheduled FIRST among implementation phases** (must not sit behind visual redesign) |
| AUDIT-Q11 | Lifecycle audit coverage implementation (conversion + visit-completion audit rows + report events) | Taxonomy DONE (NP§7); implementation rides the lifecycle phase |
| CLEANUP-Q9 | Phase H artifact-cleanup EXECUTION | Second reference audit DONE (3-d); execution still requires the separately approved future cleanup task (manifest + recoverable archive + reproducibility verification) |

**Register laws unchanged (§3) — all still binding. Historical test results remain commit-anchored**
(suites green at `4dbb89f` ancestry; current environment: DB verified EMPTY again 2026-10-26, 0 rows /
`_prisma_migrations` table MISSING; `ASAS_SESSION_SECRET` absent from `.env` — only DATABASE_URL present;
dev server HTTP 200; recovery NOT performed in this task).

---

## 1b. Register update — 2026-10-26 (UX-OWNER-DECISION-CLOSE-3: the decision-closure attempt WITHOUT the owner's form results)

**Event:** the `UX-OWNER-DECISION-CLOSE-3` directive ("Owner Decision Closure, Residual-Gap Audit, and
Conditional Security Workstream S") arrived with its **"Owner's binding answers" section carrying only
the unfilled placeholder** ("[PASTE THE FULL ASAS CRM OWNER DECISION FORM RESULTS HERE]"). A read-only
check of `upload/` found **no new owner file** (newest entries remain the two byte-identical
2026-10-25 directive copies — `Pasted Content_1792969410164.txt` / `…8288177.txt`). Per the binding
law ("do not interpret a recommendation, default selection, prior agent report, or inferred business
preference as owner approval"), **NO decision was closed this round:**

- **RQ-1, RQ-2, RQ-3 remain OPEN** (unchanged, §1a.4 — still the complete list).
- **Workstream S was NOT authorized** (the expected explicit authorization/refusal for the
  reservations GET/POST financial-field remediation did not arrive) → the task executed **Case B
  (documentation-only)**: reconciliation + residual audit + the implementation brief
  `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/WORKSTREAM_S_IMPLEMENTATION_BRIEF.md`. **No application source was edited; the
  §37/§38 exposure is NOT fixed** (re-verified LIVE at HEAD `cd7a725` — the exposure evidence holds:
  `reservations/route.ts:76` requireUser() no role gate · `:112-116` findMany include (not select) ·
  `:189-194` full-model POST return · `:239-240` 201 serialization; `withAgents` `:57-70` spreads all
  row fields).
- The task-level status recorded for the round: **"DECISIONS RECORDED — OWNER DECISION STILL
  REQUIRED."**

**Live-state verification (read-only, 2026-10-26):** branch `main`, HEAD `cd7a725` (the PLAN-2
docs-only commit; parent `494b87a` — matches the reported baseline; worktree clean, zero changes since);
DB census 0 rows in User/Organization/Lead/Opportunity/Visit/Reservation/Apartment/AuditLog/Activity/
Contact/Task/ProjectAssignment; `_prisma_migrations` table MISSING; `.env` carries only the
`DATABASE_URL` key name (secret absent, demo-mode unset); dev server HTTP 200 single instance.
**No material divergence from the reported baseline** — no reconciliation blocker.

### 1b.1 Residual-decision audit (the CLOSE-3 §4 classification — every relevant item)

| Item | Class | Evidence / disposition |
|---|---|---|
| RQ-1 (CLOSED_LOST visit-gate exemption) | **OWNER-REQUIRED** | Register §1a.4 · FORM tail. Consequence: gates the Phase B edge set; without it the implementer cannot know whether pre-visit deals may be lost. Safe default (NOT APPROVED): exempt CLOSED_LOST. Exact decision required: exempt or gate CLOSED_LOST exits from pre-visit stages. |
| RQ-2 (validate_closure visit-gate extension) | **OWNER-REQUIRED** | Register §1a.4 · FORM tail. Consequence: without it GATE-Q2 is bypassable on the money path (reservation creation carries no stage precondition — verified). Safe default (NOT APPROVED): extend the same completed-visit predicate into the validate_closure transaction. Exact decision required: extend or leave the money path ungated. |
| RQ-3 (zero vs not-applicable vs waived vs paid) | **OWNER-REQUIRED** | Register §1a.4 · FORM tail. Consequence: the D6 waiver receipt's final shape + the agent own-incentive surface semantics. Safe default (NOT APPROVED): keep current representations (zero+basis = not-due; waiver = audited receipt; paid = INCENTIVE_PAID+paidAt), written explanation carries the disambiguation; no new financial status model. Exact decision required: confirm that representation or specify an additive discriminator. |
| Workstream S execution authorization (FIN-MIN-Q10 implementation) | **OWNER-REQUIRED** | The plan-v2 review gate (register §1a status qualifier: planning approvals do NOT authorize implementation). The CLOSE-3 directive's Case-A branch awaited the owner's explicit yes/no; it did not arrive. Safe default (NOT APPROVED): N/A — a privileged action cannot default to yes. Exact decision required: authorize or refuse Workstream S (brief: `WORKSTREAM_S_IMPLEMENTATION_BRIEF.md`). |
| Environment recovery (canonical reseed + secret) | **OWNER-REQUIRED** (its own execution authorization) | NP§10 / checkpoint: DB empty, migrations table missing; recovery recipe documented; separately gated. |
| Cleanup execution (Phase H) | **DEFERRED** | CLEANUP-Q9 planning approved; execution = the separately approved future task (second reference audit DONE). Future checkpoint: the owner-approved cleanup task itself. |
| Demo-mode config flip (Phase G) | **DEFERRED** | DEMO-MODE direction approved; the flip = separate execution authorization (today's code default ON in the sandbox is the documented current state, not a defect to fix ad hoc). |
| Serializer helper placement, DTO key order, probe script structure, compensating-source wiring for the agent cockpit branch (aggregate vs honest static) | **ENGINEERING-BOUND** | Within FIN-MIN-Q10's approved target + the matrix cells + least-privilege; specified in the brief §3-4; the agent-branch source choice is bounded by the matrix (raw values absent; aggregate stays). |
| `amount`/`depositPaid` booking-fact serialization for floor roles | **ENGINEERING-BOUND today** (RECOMMENDED: stay in-scope) · owner may narrow later | Matrix addendum row 3: NOT decided by FIN-MIN-Q10's scope; the owner may narrow in a future answer — recorded, not silently resolved. |
| Optional visit-exception fields (`cancellationInitiator`, `incompleteReason`) | **ENGINEERING-BOUND at spec time** (additive, RECOMMENDED only) | GATE-Q3: "consider OPTIONAL structured fields" — the owner's own wording leaves add/omit to spec within schema compatibility; both are additive proposals in the roadmap, NOT yet implemented. |
| Report field names/types final at spec time (REPORT-Q4) | **ENGINEERING-BOUND** | Register §1a REPORT-Q4 open sub-decision: "field names/types final at spec time" — ordinary naming within the approved contract. |
| R7 per-rep surface spec details (navigation shape per surface) | **ENGINEERING-BOUND** | WORKSPACE-Q6a: "per-surface spec details (engineering-specifiable)". |
| Stale-data guard error-code/UX details (Wave-2B D4-B) | **ENGINEERING-BOUND** | Register §1 #7: "engineering-specifiable". |
| Grandfathered-deal policy for the visit gate (pre-existing deals without visits) | **DEFERRED** (documented in Phase B kickoff) | NP§8 Phase B acceptance essentials: "grandfathered-deal policy documented" at implementation time — an engineering-documented policy within GATE-Q1/Q2's approved semantics, surfaced in the worklog, not a new owner semantic. |
| Report correction mechanism (additive corrected stamps vs revision rows) | **ENGINEERING-BOUND** | REPORT-Q4 approved the audited/history-preserving law; NP§2.4 mechanism is RECOMMENDED detail within it. |

**Audit verdict: the four OWNER-REQUIRED items above (RQ-1, RQ-2, RQ-3, Workstream-S authorization
— plus the standing plan-review gate and the separately-gated recovery) are the COMPLETE list of
genuinely open owner decisions.** No hidden or misclassified open question was found: every other
unresolved marker in the canonical set is either an explicitly labeled RECOMMENDED — NOT APPROVED
planning proposal, an engineering-bound detail, or a documented deferral. No document describes a
pending item as approved elsewhere (cross-checked register §1a.2/§1a.5 ↔ NP§0a/§8 ↔ STATE §13 ↔
ROADMAP header ↔ CHECKPOINT ↔ FORM tail ↔ matrix addendum ↔ AUTHORIZATION_MODEL addendum ↔ WAVE_3 /
PHASE_D dated addenda — all mutually consistent at HEAD `cd7a725`).

**No prior approved decision was reopened and no history was rewritten in this round** (append-only
law). D-021, the Wave-2B safe-field scope, optional stale-token compatibility, single pipeline, the
no-deployment boundary, no automated inbound WhatsApp/Ouedkniss, and the planning-only cleanup
boundary all remain standing verbatim.

---

## 1c. Register update — 2026-10-26 (WS-S-EXEC: the owner's eight answers RECEIVED; Workstream S AUTHORIZED AND EXECUTED)

**Event:** the "ASAS CRM — Owner Decision Closure and Authorized Workstream S Execution" directive
arrived **in-session with the owner's binding answers fully present** (no placeholder, no missing
form upload — the eight decisions below are quoted/recorded from the directive text itself, delivered
through this conversation). Per the same binding law that held CLOSE-3 to Case B ("do not interpret a
recommendation, default selection, prior agent report, or inferred business preference as owner
approval"), these ARE the owner's explicit answers — recorded exactly, with no interpretation added.

**Source of owner authority:** S-DIR-2026-10-26c — the Workstream-S execution directive, delivered
in-session (chat_id `35d918d5-3366-4e6e-8c96-3754d0bc96fb`, session `web-20caf220-eb3e-482b-922a-a8f79df24a2d`,
2026-10-26 23:4x UTC). Carries: the eight decisions below + the Workstream-S implementation
specification (§3 of the directive) + the scope boundaries (§4) + the execution procedure (§5) +
the acceptance criteria (§6). The directive explicitly states: "The owner has now approved the eight
recommendations below… Do not ask the owner to repeat decisions that have already been approved. Do
not use placeholders for owner answers."

### 1c.1 The eight decisions — recorded verbatim-faithful, each with its class

| # | ID | Decision (the owner's binding answer) | Register status | Implementation scope |
|---|---|---|---|---|
| 1 | **RQ-1 — Visit gate and lost opportunities** | "CLOSED_LOST" is excluded from the mandatory visit/report gate. The gate must not prevent an opportunity from being closed as lost. | **APPROVED** (closes §1a.4 RQ-1) | Requirement recorded; lifecycle implementation NOT in this pass (directive §1: "their lifecycle implementation is not included in this pass") |
| 2 | **RQ-2 — Successful closure enforcement** | The mandatory visit/report requirement must be enforced server-side in `validate_closure` and across every path that can result in a successful closure. Client-side checks alone are insufficient. This decision does not authorize bypassing any other approved access-control, authorization, or closure requirement. | **APPROVED** (closes §1a.4 RQ-2) | Requirement recorded; lifecycle implementation NOT in this pass |
| 3 | **RQ-3 — Financial semantics** | Keep the existing financial model and schema unchanged. A zero agent-incentive amount accompanied by a written explanation means only that the incentive is not due. Zero must never, by itself, be interpreted as Paid, Waived, or Not applicable. Do not introduce new financial-state semantics or database fields during Workstream S. | **APPROVED** (closes §1a.4 RQ-3 — matches the §1a.4 recommended default exactly) | Binding during S: no financial schema/semantics change; the zero+explanation law stands |
| 4 | **Visit-report correction policy** | The report author or an authorized manager may append a correction to a visit report. A correction must include a reason and an auditable before/after record. The original report must remain intact; no destructive overwrite or deletion of the original report is permitted. | **APPROVED** (new requirement — REPORT-Q4's correction law now owner-bound) | Requirement recorded; implementation NOT in this pass. The §1b.1 "correction mechanism (additive stamps vs revision rows)" stays ENGINEERING-BOUND *within* this law |
| 5 | **Visit exceptions** | Defer adding new structured visit-exception fields. Retain existing statuses and follow-up alerts. No new exception schema is authorized by this decision. | **APPROVED** (deferral — resolves the §1b.1 "optional visit-exception fields" row: NOT added) | No visit-exception schema work (retires the optional-fields proposal from this cycle) |
| 6 | **Visit–Opportunity consistency** | At visit creation and update, server-side validation must ensure that the visit and its related opportunity belong to the same Lead. The visit gate must revalidate this relationship when checking eligibility. | **APPROVED** (new requirement — GATE-Q1's same-lead law reinforced) | Requirement recorded; implementation NOT in this pass |
| 7 | **Workstream S authorization** | The owner explicitly authorizes implementation of the reservation financial-data exposure fix (server-side data minimization: §37/§38 fields absent — not null — from SALES_AGENT/FIELD_REP responses on the reservation API; MANAGER+ unchanged; D-021 row scoping untouched as the first layer). This is the only authorized application-code workstream in this execution. | **APPROVED — EXECUTION AUTHORIZED** (closes the §1b.1 Workstream-S authorization row; the plan-v2 review gate is passed for S ONLY) | **EXECUTED in this round** — the brief `WORKSTREAM_S_IMPLEMENTATION_BRIEF.md` + directive §3 are the spec |
| 8 | **Database environment and recovery** | Database restoration, reset, reseeding, and recovery are not authorized. Use isolated tests that do not depend on restoring or modifying the project database. Clearly disclose any validation limitations caused by the current database state. | **APPROVED** (boundary — confirms the §1b.1 recovery row stays separately gated: NOT authorized) | Binding during S: no recovery/reseed/migration; isolated tests only; limitations disclosed |

### 1c.2 Consequences for the register state

- **RQ-1, RQ-2, RQ-3 are CLOSED** (§1a.4's complete open list is now empty — every question the
  CLOSE-3 audit identified as OWNER-REQUIRED is answered).
- **The plan-review gate for Workstream S is PASSED** — implementation was authorized and executed
  in this same round (the directive's Steps C–F). The OTHER approved requirements (RQ-1/RQ-2
  lifecycle enforcement, correction policy, visit–Opportunity consistency) remain
  implementation-pending roadmap items — **approved requirements, not yet implemented** — and their
  execution still follows the roadmap's phase sequencing (NP§8 Phase B/C), NOT this round.
- **Standing boundaries re-confirmed by the directive (§4):** no visit-gate/closure-lifecycle code,
  no correction workflows, no visit-exception schema, no D5/D6 behavior, no financial
  formulas/schema/semantics, no lead/opportunity lifecycle changes, no general UI redesign, no
  fixture/canonical-seed changes, no secrets/env changes, no git-remote/deployment/history changes,
  no DB restore/reset/reseed/migration/recovery, no scheduler/cron changes, no broad cleanup. D-021
  and all role/tenant/org isolation must NOT be weakened to make tests pass.
- **No prior approved decision was reopened; no history rewritten** (append-only law). The RQ-1/RQ-2
  answers match the §1a.4 recommended defaults, and RQ-3 matches exactly — recorded as OWNER
  DECISIONS now, not as engineering defaults.

*(Workstream S execution evidence — files changed, tests, review verdict, commit — lives in
`WORKSTREAM_S_IMPLEMENTATION_BRIEF.md` §9 change history, the matrix addendum, D-GOV-10, and the
worklog WS-S-EXEC entry.)*

---

## 1d. Register update — 2026-10-27 (Phase B directive: the owner's D1–D9 answers RECEIVED; visit-gate execution AUTHORIZED)

**Event:** the "ASAS CRM — Phase B Execution Mandate — Opportunity Lifecycle, Visit Gate, Role-Based
Access, and Workflow UX" directive arrived in-session with the owner's nine decisions fully present
(no placeholders). Per the binding law held since CLOSE-3: these ARE the owner's explicit answers —
recorded verbatim-faithful, no interpretation added.

**Source of owner authority:** S-DIR-2026-10-27 — the Phase B execution directive, delivered
in-session (chat_id `35d918d5-3366-4e6e-8c96-3754d0bc96fb`). Carries: D1–D9 below + the explicit
implementation authorization (§3) + the not-authorized list (§3) + the execution workflow (§11) +
acceptance criteria (§12). The directive supersedes the WS-S-era note that lifecycle implementation
was "not in this pass" — for THIS pass it is the mandated work.

### 1d.1 The nine decisions — recorded verbatim-faithful, each with its class

| # | ID | Decision (the owner's binding answer) | Register status | Implementation scope |
|---|---|---|---|---|
| 1 | **D1 — Phase scope** | The current execution prioritizes the visit gate and successful-closure enforcement. Visit-report correction workflows are deferred to a separate implementation phase. | **APPROVED** | Binding phase scope for this round |
| 2 | **D2 — CLOSED_LOST** | "CLOSED_LOST" is exempt from the mandatory visit/report gate. A user must not be forced to complete a visit merely to record a genuinely lost opportunity. Preserve all existing authorization, audit, and valid-transition requirements. No new mandatory loss-reason field or workflow in this phase; if existing functionality already requires a reason, preserve it. | **APPROVED** (closes the RQ-1 exemption recorded §1c.1 #1 — now implemented this pass) | The gate never fires on CLOSED_LOST transitions; the existing lostReason prerequisite stays untouched |
| 3 | **D3 — Successful closure** | A successful opportunity closure requires a valid, completed visit and a compliant visit report. Enforced on the server in `validate_closure` AND every applicable path that can successfully close an opportunity; client-side checks are supplemental only. No bypass for any user, role, API caller, or alternate endpoint. | **APPROVED** (closes the RQ-2 enforcement requirement recorded §1c.1 #2 — now implemented this pass) | **EXECUTED in this round**: `validate_closure` + PATCH-into-CLOSED_WON + POST-at-CLOSED_WON (the discovered third path — the birth-closed hatch; ungated it would be exactly the "alternate endpoint" bypass D3 prohibits) |
| 4 | **D4 — Visit-report correction policy** | Approved requirement; implementation deferred. The original report must remain intact; corrections append-only, reasoned, auditable before/after; report author or authorized manager. Do not implement in this phase unless strictly necessary to keep the gate from accepting invalid data. | **APPROVED — DEFERRED** (same content as §1c.1 #4; re-affirmed) | No correction workflow this round |
| 5 | **D5 — Visit exceptions** | New structured visit-exception fields deferred. Retain existing statuses, follow-up alerts, supported behaviors. No new database fields or invented exception semantics. | **APPROVED — DEFERRED** (re-affirms §1c.1 #5) | No schema change this round |
| 6 | **D6 — Visit/Opportunity/Lead consistency** | At visit creation and update, server-side validation must ensure the visit and its associated Opportunity belong to the same Lead. The gate must revalidate this relationship when evaluating eligibility. | **APPROVED** (closes the §1c.1 #6 requirement — now implemented this pass) | **EXECUTED in this round**: POST /api/visits lead cross-check + the gate's lead revalidation; visit PATCH cannot move leadId/opportunityId (structurally immutable — verified, probed) |
| 7 | **D7 — Database environment** | Database restoration and recovery not authorized. Prepare a separate, reviewable recovery proposal for a dedicated test environment. Do not execute restore, reset, reseed, migration, or recovery. | **APPROVED** (re-affirms §1c.1 #8 for this round) | Binding: isolated scratch fixtures only; the recovery proposal delivered as a separate document (05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DATABASE_RECOVERY_PROPOSAL.md), nothing executed |
| 8 | **D8 — Workstream S verification** | Accept the Workstream S fix as intended to be serialization/data-minimization only, SUBJECT to actual diff verification: confirm authorization logic, lifecycle transitions, closure behavior, and audit semantics were not inadvertently changed. Inspect the actual changes; do not assume prior reports prove it. | **APPROVED** (verification mandate) | **EXECUTED in this round**: the e9dae1b diff re-inspected first-hand (reservation-lifecycle.ts untouched — empty diff; the route-level DTO choke point wraps both PATCH branches; authority/source-state/prerequisite guards byte-identical) + regression probes in the Phase B battery |
| 9 | **D9 — Professional operational UX** | The workflow must be usable by the intended roles: clear status, next actions, validation messages, loading/error/empty states, permission-aware controls. Respect D-021 and all existing role/scope restrictions; no peer records, financial fields, unauthorized actions, or sensitive data exposed to make the UI look more complete. | **APPROVED** (new requirement) | **EXECUTED in this round**: the blocked-closure notice (precise reason + next action, i18n ×3, RTL-safe) on the closure workflow; precise server messages on every gated path |

### 1d.2 Consequences for the register state

- **The GATE-Q1/Q2-approved direction (§1a) is now PARTIALLY IMPLEMENTED**: the successful-closure
  gate (D3's exact scope — every CLOSED_WON entry path) is code this round. The pre-visit→beyond-visit
  **boundary-crossing** gate (NP§2.1's formalization: source ∈ {NEW, QUALIFIED, VISIT_SCHEDULED} ∧
  target ∈ beyond-visit on routine stage moves) remains an approved-but-not-yet-implemented roadmap
  item — the Phase B directive scopes enforcement to successful closure, and it explicitly forbids
  broad lifecycle refactoring beyond the authorized requirements. Recorded here so the boundary is
  not silently forgotten.
- **The report contract implemented is the CURRENT model's** (D3 + D5 + no-migration law): a
  qualifying visit = status `COMPLETED` + non-empty `outcome` (the model's own enforced
  compte-rendu law, OUTCOME_REQUIRED at visits/[id]) + opportunityId match + leadId match (D6).
  **Documented gap (owner-visible, not improvised)**: the Q4 report contract's interest-level enum,
  the DISTINCT report-notes field, and the server-stamped report author/timestamp
  (`reportedById`/`reportedAt`) are NOT represented in the current schema and CANNOT be added
  without a migration (roadmap-only additive proposal per NP§2.2; D5 + D7 forbid it this round).
  The gate's 422 details therefore report the schema-represented requirements only.
- **The POST-at-CLOSED_WON historical-backfill hatch is now gated** (D3's anti-bypass law): a won
  deal can no longer be BORN won with zero visit — the honest backfill journey is create-at-working-
  stage → record the completed visit (+ compte-rendu) → close via the gated paths. This is the
  GATE-Q2 strictness trade-off (a genuinely visit-less sale requires the owner to revisit the gate
  decision — NP conflict-matrix row D) applied consistently to the birth path.
- **Standing boundaries re-confirmed by the directive (§3 not-authorized list)**: no correction
  workflow, no visit-exception schema, no financial formula/semantics/schema change, no dashboard
  redesign, no broad Lead/Opportunity refactor, no migrations, no restore/reset/reseed, no
  deployment/remote/history operations, no scheduler changes, no D-021 weakening. All hold.
- **No prior approved decision was reopened; no history rewritten** (append-only law).

*(Phase B execution evidence — files changed, tests, review verdict, commit — lives in the worklog
Phase B entry and the final report; this section records the decisions only.)*

---

## 1e. Register update — 2026-10-27/28 (Phase C directive: Decisions C-1/C-2/C-3 RECEIVED; recovery EXECUTED against the isolated test DB; the visit-report contract IMPLEMENTED)

**Event:** the "ASAS CRM — Phase C Execution Mandate — Database Integrity, Visit Report Contract, Lifecycle Enforcement, and Workflow-Centered UX" directive arrived in-session with the owner's three decisions fully present (no placeholders). Per the binding law held since CLOSE-3: these ARE the owner's explicit decisions — recorded verbatim-faithful, no interpretation added.

**Source of owner authority:** S-DIR-2026-10-27c — the Phase C execution directive, delivered in-session (chat_id `35d918d5-3366-4e6e-8c96-3754d0bc96fb`). Carries: C-1/C-2/C-3 below + the non-negotiable restrictions (§2) + the engineering-first law (§3) + the four workstreams (§4) + the gate sequence (§5) + the acceptance criteria (§6) + the DoD (§8) + the final-report contract (§9).

### 1e.1 The three decisions — recorded verbatim-faithful, each with its class

| # | ID | Decision (the owner's binding answer) | Register status | Implementation scope |
|---|---|---|---|---|
| 1 | **C-1 — Dedicated test-database recovery** | APPROVED, CONDITIONAL: recovery may be executed only against a dedicated, demonstrably isolated test database, and only after all three approval gates explicitly documented in `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/DATABASE_RECOVERY_PROPOSAL.md` have been verified. The owner's conditional authorization is not permission to bypass a gate; any missing/ambiguous/unsatisfied gate = hard stop. | **APPROVED — EXECUTED** | **EXECUTED this round**: all three proposal gates (§10.3, exact wording preserved) verified with evidence — GATE-1 (snapshot + test-file creation; writes confined to `db/backups/` + `db/test-environment.db`), GATE-2 (`migrate deploy` on the test file only — 12/12, "schema is up to date!"), GATE-3 (the suites window + post-window restore). Option B/Path D chosen (documented determination: `db/custom.db` was found EMPTY after another R13-class wipe — nothing to replicate; Option B matches the suites' design-era roster and never copies from the protected file). Recovery evidence: pre-op snapshot `custom-20261027-135347.db` (digest match), test-target backup `test-environment-20261027-135435.db` (rollback executed once, after the browser E2E, via restore + re-deploy), §7 all green (census pinned at the suite-era baseline 8/43/21/23/8/161/18/46/4; schema diff "No difference detected"; DDL digests identical modulo `_prisma_migrations`). **`db/custom.db` provably untouched (sha256 identical before/after; 0 rows).** |
| 2 | **C-2 — Visit-report contract and schema** | APPROVED: implement the contract — `interestLevel` (four levels: very interested / interested / neutral / not interested), `reportNotes` (meaningful notes: the property discussed + client objections), `reportedById` (the authenticated, authorized reporting user — server-controlled), `reportedAt` (server-generated timestamp). Author and timestamp never client-supplied. Migration executed ONLY against the approved isolated test database. Optional follow-up fields, due dates, correction workflows, and structured visit-exception fields are NOT part of this authorization. | **APPROVED — EXECUTED** | **EXECUTED this round**: schema + migration `20261027140445_phase_c_visit_report` (additive nullable columns — the Prisma SQLite table-rebuild pattern, every existing row carried, new fields NULL); `VISIT_INTEREST_LEVELS` + `VISIT_REPORT_NOTES_MIN/MAX` in constants.ts (the Enum-as-String law); zod-validated API (invalid enum → 422 with field detail; short notes → 422); server-stamped provenance (spoofed `reportedById`/`reportedAt` stripped by zod — probed); NP§2.5 authority (assigned FIELD_REP via canConfirmVisit / responsible rep `visit.agentId ?? lead.ownerId` / MANAGER+); the report immutable once submitted (corrections stay the separately-gated D4 workstream); the closure gate now requires the full contract (a COMPLETED visit with an incomplete report NEVER satisfies it — legacy outcome-only rows fail closed with `missingReportFields` named). Both compatibility paths verified: existing-data (migration 13 over the seeded 12-migration state — census unchanged, 12 legacy completed visits report-less) and fresh-schema (fresh file + 13 migrations + the report-bearing seed — 12/12 valid reports). The seed gains report content on completed visits per NP§2.2's owner-approved direction. |
| 3 | **C-3 — Phase C scope** | APPROVED: 1) establish the reliable isolated test DB and validate the recovery procedure; 2) implement and validate the visit-report contract and schema; 3) enforce the contract at the server and lifecycle boundaries; 4) verify role-based access, organizational scope, and D-021; 5) validate the actual CRM workflows and improve the UX; 6) run regression tests, document evidence, and produce an honest release-readiness assessment. No corrections/exception-fields/unrelated lifecycle redesign in this phase. | **APPROVED — EXECUTED** | **EXECUTED this round**: all six priorities delivered (evidence in the worklog PC-EXEC entries + the final report); the not-authorized list honored — no correction workflow, no visit-exception fields, no financial changes, no broad redesign, no deployment, no remote, no scheduler change, no D-021 weakening. |

### 1e.2 Consequences for the register state

- **The recovery is no longer "separately gated" — it has been executed and validated** against `db/test-environment.db` (the proposal's own three gates satisfied; the standing suites un-blocked and re-run twice: pre-implementation window #1 and final-state window #2). The standing BLOCKED record (WS-S/Phase B) is closed for the test environment. `db/custom.db` remains protected-as-is (empty, untouched) — its recovery is a SEPARATE owner decision (see below).
- **The §1d.2 documented gap is CLOSED**: the interest-level enum, the distinct report-notes field, and the server-stamped author/timestamp are now schema + code (the "cannot be added without a migration" roadmap item — added, via the C-2-authorized migration, applied only to the isolated test DB).
- **Lifecycle semantics intentionally evolved (owner-approved)**: completing a visit now requires the structured report (422 REPORT_FIELDS_REQUIRED); the successful-closure gate requires the full report contract; POST-at-CLOSED_WON stays refused; CLOSED_LOST stays exempt (D2) with its lostReason prerequisite untouched; D6 lead-consistency revalidation preserved. Drift adjudicated per the §9 law: the standing suites' gate-era expectations (p12 ×13, wave1 ×1, phase-b-probe ×23) are documented legitimate evolution — every scenario re-covered GREEN by the new phase-c-probe battery (80/80); NO suite was edited.
- **Standing boundaries re-confirmed**: no deployment/remote/history operations; no secrets/env changes (the test server's secret was generated inline, never persisted); no scheduler/cron changes (P14 honored — no `webDevReview` automation created); no weakening of D-021/roles/scope anywhere; `prisma/seed.ts` edited ONLY to add the owner-approved report content on completed visits (NP§2.2's "the seed gains report content... so the gate is demonstrable on fresh installs" — no fixture weakened, no expectation changed).
- **Next required owner decision (the only genuine new boundary)**: `db/custom.db` is EMPTY (R13 wipe) and is now ALSO schema-stale relative to migration 13 (it must never be migrated per the protected-DB law). The standing R13 recipe (`db:seed` alone) is no longer sufficient for it: the honest recovery is the same Option-B pattern aimed at the protected file (stop server → fresh file → `migrate deploy` ×13 → `db:seed` → restart), which requires an explicit owner instruction. Until then the project dev-server environment shows an empty workspace and its visit surfaces return 500 (the pre-existing stale-schema class, now documented with the exact dependency).
- No prior approved decision was reopened; no history rewritten (append-only law).

## 1f. Register update — 2026-10-30 (Phase H directive: the Z.ai exit handoff — Full Platform Engineering, Product Quality, and verified source ZIP)

**Event:** the "ASAS CRM — Full Platform Engineering, Product Quality, and Z.ai Exit Handoff" master mandate arrived in-session (upload/Pasted Content_1793322641210.txt, committed with H2). Per the binding law: recorded as the owner's explicit directive — full platform remediation, Supabase/PostgreSQL readiness, GitHub/Vercel preparation, and a verified clean-source ZIP as the primary deliverable. Scope boundaries honored: no remote push, no hosted Supabase mutation, no Vercel deployment, no history rewrite (the §17 prohibitions), `db/custom.db` remains protected.

**Executed (evidence: worklog PH-EXEC entries + 05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/FINAL_QA_REPORT.md):**
- H1 audits (3 parallel read-only agents): architecture/portability, database/Supabase-readiness, security/secrets. Findings: code-level portability clean (59 routes uniformly authed; 56 authed + 3 public-by-design; D-021 verified; no passwordHash exposure); git history NOT shippable as a bundle (an old real session-secret value + the pre-purge demo DB live in history — the purge stays owner-gated per D-013); z-ai SDK file-based config = the one platform-bound dependency.
- H2 portability fixes: `src/lib/server/ai-provider.ts` (503 AI_PROVIDER_UNAVAILABLE before rate-limiters), repo identity `asas-crm@1.0.0` + portable build/start + `typecheck` script, tsconfig scoped to src/prisma (the 6 tolerated non-src errors eliminated; `ignoreBuildErrors` removed), vestigial `tailwind.config.ts` retired, `.env.example` relative path + PG path + AI contract. Lint 0 · tsc 0 · battery 80/80 re-run green.
- H3 Supabase layer: `prisma/schema.postgres.prisma` (TIMESTAMPTZ(3) ×62), `supabase/migrations/` (20261030000001 init — Prisma-engine-generated DDL, 26 tables/65 FKs/53 indexes; 0002 CHECK vocabularies from the shared constants + the documented Reservation partial unique index; 0003 RLS — 26 tables, 104 org-scoped default-deny policies), `supabase/seed.sql` (511 canonical rows, FK-order-safe — the Activity-before-Reservation order bug caught and fixed by the validator), `supabase/config.toml`, `scripts/generate-seed-sql.ts` + `scripts/validate-seed.py`. Canonical-strategy law recorded in 05_ENGINEERING_DOCUMENTATION/03_DATABASE_ENGINEERING/MIGRATIONS_AND_SCHEMA.md; money stays DOUBLE PRECISION (semantics-preserving; NUMERIC upgrade = future owner decision); JSON-in-String stays TEXT (client-contract parity; JSONB = future decision).
- H4 browser verification on the recreated disposable test env (approved Option B/Path D recipe): login → dashboard/leads/visits/pipeline, AR RTL (dir=rtl), 390px no-overflow, console 0 errors.
- H5/H6 GitHub-ready layer: README/CONTRIBUTING/SECURITY, .gitattributes/.editorconfig, CI (honest static + SQLite-DB gates), the 10-file handoff doc set, PLATFORM_HANDOFF_RESEARCH.md (24 fetched primary sources), DATA_EXPORT_BLOCKED.md.
- H7/H8 packaging + clean-room: `handoff/ASAS_CRM_SOURCE_HANDOFF_2026-10-30.zip` (730 files) + `.sha256` + HANDOFF_MANIFEST.json; clean-room validated (install/generate/migrate/seed/lint/typecheck/boot/login/data-flow all green).

**Incident (disclosed, remediated):** the first clean-room `db:seed` hit the protected `db/custom.db` via the sandbox's globally exported `DATABASE_URL` overriding the clean room's `.env` (env-var precedence). Detected by checksum; restored byte-exact from the GATE-1 snapshot (`sha256 6f4b10a8…`, 0 users — verified after restore, after the re-run, and after the final server restore). Root cause + precedence warning documented in 05_ENGINEERING_DOCUMENTATION/07_HANDOFF_AND_OPERATIONS/ENVIRONMENT_VARIABLES.md.

**Register consequences:**
- The P14 standing order ("no scheduled review automation absent an explicit user instruction to the contrary") is superseded FOR THIS PHASE by the current session's explicit harness instruction mandating a 15-minute `webDevReview` cron task — created at phase close per that instruction, recorded here so the next session knows its provenance.
- §1e.2's "custom.db is schema-stale" characterization is OBSOLETE as of the 2026-10-30 environment reset: the file now carries the CURRENT 26-table schema (empty, no migration bookkeeping). Its recovery remains an explicit owner decision; the file was returned byte-exact to that state after the incident.
- New open owner decisions surfaced: (1) Supabase Storage adoption for document binaries (local-FS storage cannot survive Vercel); (2) NUMERIC(14,2) money upgrade; (3) JSONB adoption; (4) Supabase Auth for app users (cuid↔uuid mapping); (5) the git-history purge before any history-preserving bundle (D-013, unchanged); (6) real-data export (BLOCKED — no verified source). None undertaken autonomously.

## 1g. Register update — 2026-10-30 (H9-DELIVER: the final complete-source delivery directive)

**Event:** the owner's FINAL EXECUTION ORDER (in-session): produce and expose the actual downloadable ZIP of the complete ASAS CRM source project — with checksum, manifest, and report, verified by clean extraction and runnable checks. "No plans. No more promises. No documentation-only delivery."

**Executed (evidence: worklog H9-DELIVER + FINAL_HANDOFF_REPORT.md):** `ASAS_CRM_COMPLETE_SOURCE_HANDOFF_2026-10-30.zip` — 731 entries / 4,077,011 bytes / sha256 `3a63f4449028b625c6731913113054dcf6b1d62e8096232ff0454d90fc79c198`, cut from commit `6e61160` via the owner-approved H7 git-archive recipe (same 8 exclusions; 600 source files; `HANDOFF_MANIFEST.json` with 600 per-file checksums INSIDE the archive). Clean-room verified in a separate directory outside the repository: byte-exact extraction (600/600), `bun install` 527 packages, `migrate deploy` 13/13, seed census exact (8/43/21/23/8/161/46), `validate-seed.py` PASS, lint 0, typecheck 0, boot + password login (MANAGER) + 43-leads live data on isolated port 3100. Mirrored to the git-ignored `public/downloads/` and exposed via a SELF-GATING login-screen link (a HEAD probe renders the link only where the mirror actually exists — it cannot dangle in the owner's extraction). The protected `db/custom.db` was attested byte-identical (`6f4b10a8…`) before and after the entire delivery.

**Register consequences:**
- The P14 automation question, resolved factually: the mandated webDevReview job exists as scheduler job **485853** (Phase H §1f provenance, exact mandated description) and was disabled BY THE PLATFORM after 2 runs ("exec limits exceeded" — the class AGENTS.md P14 already documents). No duplicate was created (duplication would churn against the same account-level limit); the cron toolset exposes no re-enable action; P14's owner-gated re-enable law stands unchanged.
- The delivered archive does NOT contain the H9 login-link change (cut from `6e61160`, one commit before it — the delta is the `/public/downloads/` gitignore line only). Recorded so no future session mistakes the working tree for the archive; the login-link change is an environment delivery affordance, intentionally outside the shipped package.
- No prior decision reopened; append-only law honored; no remote push, no hosted mutation, no deployment, no history rewrite.

## 1h. Register update — 2026-10-31 (H9-R: the download surface restored after the environment reset)

**Event:** the owner requested the downloadable file again ("اريد ان انزل الملف من هنا") — the environment reset had wiped the git-ignored delivery mirror (public/downloads/) and the handoff/ output, leaving the registered H9 delivery undownloadable.

**Executed (evidence: worklog H9-R + FINAL_HANDOFF_REPORT.md + download/qa-handoff-redeliver/ ×3):** `ASAS_CRM_COMPLETE_SOURCE_HANDOFF_2026-10-31.zip` — 731 entries / 4,116,348 bytes / sha256 `017571de4b2ff29df6bb8b2bf2837fee7e47b008b9b6febbd2afd8691fdecdca`, re-cut from the IDENTICAL registered H9 commit `6e61160` with the identical 8-exclusion recipe (600 files / 8,881,930 staged bytes — exactly the registered counts; the zip bytes differ from the H9 original only by the regenerated embedded manifest, and the 600 per-file checksums inside HANDOFF_MANIFEST.json are the content-equality proof). Clean-room re-verified in full (18/18 gates: checksums, required-files, forbidden-content, secret scan, install 527, lint 0, typecheck 0, migrate 13/13, seed census exact, validate-seed PASS, boot :3100, MANAGER login, 43 leads live). Mirrored to the git-ignored public/downloads/ with the bilingual index.html download page; the login screen's self-gating link re-activated; curl + agent-browser downloads both byte-exact; protected db/custom.db attested byte-identical (6f4b10a8…) before and after.

**Register consequences:**
- The tree state at re-delivery: HEAD `9cdf1fb` carries an auto-committed, mid-flight **Phase D fragment** (finance/SAV/targets routes + dormant views; 82 type errors; dependencies never written; NOT wired into nav). It is QUARANTINED from the delivery — the shipped archive remains the last verified green state (`6e61160`). Phase D completion is recorded as the next session's work item; until then the packaging tree and the archive intentionally diverge (working tree ≠ shipped content).
- No prior decision reopened; append-only law honored; no remote push, no hosted mutation, no deployment, no history rewrite; the P14 cron stance (job 485853 disabled by the platform, owner-gated re-enable) unchanged.

**Addendum (same day, post-H9-R):** the scheduler was re-checked after the delivery and now lists **0 jobs** — platform job 485853 (the disabled P14 webDevReview job) no longer exists at all, so the §1g/§1h no-duplicate rationale is factually void. The mandated 15-minute webDevReview job was therefore recreated fresh as scheduler job **488884** (fixed_rate 900s, tz Africa/Algiers, exact mandated description). If the platform disables it again for exec limits, the P14 owner-gated stance resumes.

## 1i. Register update — 2026-10-31 (PC-CLOSE-2 + PD-EXEC: the "Complete your work on the stage C and D" directive)

**Event:** the owner instructed: "Complete your work on the stage C and D". Recorded as two executions: (1) the §1e.2 owner-gated recovery of the protected `db/custom.db` — the instruction IS the explicit authorization the register awaited; (2) the completion of the frozen Phase D fragment (commit `9cdf1fb`, the finance/SAV/targets code whose foundations were never written).

**Executed (evidence: worklog PC-CLOSE-2 + PD-EXEC + download/qa-phase-d/ ×25):**

- **PC-CLOSE-2**: the §1e.2 recipe verbatim — pre-recovery snapshot → server stopped → fresh file → `migrate deploy` 13/13 → `db:seed` (census 8/43/21/23/8/161/46) → restart → GET / 200 + MANAGER login + 43 leads live. The empty-workspace/stale-schema era is over; the demo surface serves data again.
- **PD-EXEC**: schema migration 14 (`20261031101714_pd_finance_sav_targets` — Installment/Payment/SavCase/SalesTarget + Activity.savCaseId, shapes field-for-field identical to the historical p13/p14/0_init DDL) · server vocabularies/scopes/audit extensions · client types/store/nav/routing · the i18n completion (the fragment's stale monolith `src/lib/i18n.ts` DELETED — it shadowed the domains composition and would have rendered 639 newer keys as raw strings; finance+sav wired into the composition; all never-written trilingual labels added) · dashboard PhaseDAttention + TargetsPanel + settings TargetsSection wired · fragment debris removed (dead routes, vestigial configs, placeholder component) · seedPhaseD demo data (census 606: +14 installments, +8 payments, +7 SAV cases, +3 targets, +22 timeline activities, +41 audits) · the full Supabase layer (postgres variant, migration `20261031000000_pd_finance_sav_targets` with CHECK vocabularies + RLS, seed.sql regenerated from a pristine scratch DB, validator updated → PASS).
- Verified end-to-end in the browser: payment recording, call-for-funds, installment creation, SAV claim/progress/resolve/create flows, agent 403 lock + scoped SAV, OWNER targets editor, AR RTL, mobile 390 (zero overflow), dark mode, console 0 errors. Gates: lint 0 · typecheck 0 · both schemas valid.

**Register consequences:**
- **The P16 scope cut ("SAV removed", 2026-10-08) and the P18 finance-to-ERP deferral are SUPERSEDED for this lineage by the Phase D mandate** — the domains are back per the owner's newest instruction, with their historical governance intact (audits, D-021 scopes, closed vocabularies, the D-022 derived-state law).
- The stale-monolith deletion is recorded as a REPAIR, not a regression: the H9-era runtime (pre-fragment) used the domains composition; the fragment accidentally reintroduced a pre-P7.1 monolith that shadowed it.
- The registered H9 delivery archive remains the pre-Phase-D state (`6e61160`); the working tree now intentionally diverges (Phase D complete). Any future re-delivery cuts a NEW package from the new HEAD.
- The P14 cron stance: scheduler job 488884 (created this morning per §1h addendum) was DELETED before this in-flight work to protect atomicity (an isolated reviewer turn would have fought the same 82 errors mid-implementation); recreated fresh at close per the standing mandate.
- No prior decision reopened beyond the documented supersession; append-only law honored; no remote push, no hosted mutation, no deployment, no history rewrite; the protected-DB law respected (the recovery WAS the owner-gated operation).

**Addendum (PD-EXEC close):** the mandated 15-minute webDevReview job was recreated fresh as scheduler job **489828** (fixed_rate 900s, tz Africa/Algiers, exact mandated description) — job 488884 had been deleted before the in-flight Phase D implementation to protect atomicity (documented in §1i). The standing 15-minute cadence law is restored at rest state.

## 1j. Register update — 2026-10-31 (UX-G: gateway-restored live AI verification + the fourth reset-class recovery)

**Event:** the owner's "Continue" on the lifecycle-UX mandate. Executed as UX-G (worklog UX-G, evidence download/qa-ux-gateway/ ×9): (1) the ZAI LLM gateway found RESTORED — single copilot, bulk copilot, and VLM document analysis verified LIVE for the first time (previously mock-only during the R10-era outage; the VLM extraction was ground-truth-verified field-by-field against a mock "Promesse de vente" built from the real H-31 reservation data — verdict Lisible, 98 % confidence, the unsigned-draft stamp read and flagged); (2) the FOURTH reset-class DB wipe discovered and the §1e.2 recovery recipe executed verbatim under its established §1i sanction (snapshot → fresh file → migrate deploy 14/14 → seed → census EXACT → live); (3) one real bug found & fixed: document status transitions (PENDING→VALIDATED/REJECTED/reopen) wrote an Activity but NO audit — now `DOC_STATUS_CHANGED` audits like every sibling status flow (server + trilingual labels, live-verified ×2 transitions); (4) infra: a dev-server watchdog daemon + heap cap (the OOM-kill class diagnosed via dmesg) — the server self-healed twice live during the round.

**Register consequences:**
- The R10 handover's #1 recommendation (re-test the AI surfaces once the gateway returns) is CLOSED with live evidence.
- The kept-demo-content policy (R10-2 won-deals precedent) extends to the H-31 analyzed contract document: it matches the real reservation/client/apartment/price and showcases the VLM feature; copilot QA residue was fully cleaned (scores restored, 5 activities + 5 audits deleted).
- The P14 cron stance: the scheduler listed **0 jobs** at round start (platform reset — the documented class). The mandated 15-minute webDevReview job was recreated fresh as scheduler job **491500** (fixed_rate 900s, tz Africa/Algiers, exact mandated description). If the platform disables it again for exec limits, the owner-gated stance resumes.
- No prior decision reopened; append-only law honored; no remote push, no hosted mutation, no deployment, no history rewrite; the protected-DB law respected (the recovery WAS the sanctioned operation; final sha256 5e8c9fde… with provenance in worklog UX-G).
