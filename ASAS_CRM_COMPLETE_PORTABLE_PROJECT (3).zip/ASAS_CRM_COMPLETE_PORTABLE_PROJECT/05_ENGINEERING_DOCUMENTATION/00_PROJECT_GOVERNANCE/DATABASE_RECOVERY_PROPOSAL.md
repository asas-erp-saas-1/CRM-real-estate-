# ASAS CRM — Database Recovery Proposal (Dedicated Test Environment)

**Created:** 2026-10-27 — Phase B (Opportunity Lifecycle and Visit Gate execution), task `F1` (docs-writer subagent).
**Status:** **PROPOSAL ONLY — NOT AUTHORIZED, NOT EXECUTED.** This document describes a recovery
procedure for a *dedicated test environment* and requests owner approval through the explicit gates of
§10. Nothing in it authorizes, triggers, or performs any restore, reset, reseed, migration, or recovery
operation. No procedure in this document was executed by the writing task (see write footprint below).

**Governing decisions and laws:**
- **Owner decision D7** — Phase B directive, 2026-10-27 (delivered in-session with the Phase B
  execution mandate; quoted verbatim): *"Database restoration and recovery are not authorized in this
  execution. Prepare a separate, reviewable recovery proposal for a dedicated test environment if
  required. Do not execute restore, reset, reseed, migration, or recovery operations."* This document
  is the "separate, reviewable recovery proposal" that directive requested — nothing more.
- `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md` §1c.1 decision 8 (WS-S boundary, 2026-10-26):
  *"Database restoration, reset, reseeding, and recovery are not authorized. Use isolated tests that do
  not depend on restoring or modifying the project database. Clearly disclose any validation
  limitations caused by the current database state."*
- `AGENTS.md` (DB constraint, secrets law, R13 recovery recipe, dev-server PID law, test-residue law)
  · `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/RECOVERY_GOVERNANCE_PROTOCOL.md` §5 (the P0 recovery precedent) · D-014
  (migrations-based schema change) · D-016 (canonical seed).

**Write footprint of the proposal task (F1):** exactly one new file (this document) plus the mandatory
`worklog.md` append. Nothing under `src/`, `prisma/`, `db/`, `tmp-scripts/`, `tests/`, or any config
was modified. All database access was read-only (Prisma row counts, `sqlite_master` / `PRAGMA`
queries, file checksum) — no mutating database command was run.

---

## 1. Purpose and scope

**Purpose.** Define a reviewable, step-by-step procedure to stand up a *dedicated, isolated test
environment* whose database carries the canonical seeded dataset and coherent Prisma migration
bookkeeping, so that the standing regression suites (§3) can be re-run — which they currently cannot,
because the project database lacks migration bookkeeping and, until the recent re-seed, had lost its
data entirely.

**This proposal is about a DEDICATED TEST ENVIRONMENT — it is NOT about "fixing" the current project
database.** `db/custom.db` is explicitly out of scope for every operation described here: it is not to
be restored, reset, reseeded, migrated, resolved, pushed, or otherwise written by this procedure. Its
current state (§2) — including its documented divergences — is *accepted as-is* per D7 and is not a
defect this proposal corrects.

**Approval checkpoints (preview — full definitions in §10).** Every checkpoint is an **explicit owner
instruction, never assumed, never inferred** (the register law: a recommendation, default selection,
prior agent report, or inferred preference is not owner approval):

| Gate | Authorizes | Touches |
|---|---|---|
| **[GATE-1]** | Creating the test-environment DB copy + pre-copy snapshot | only `db/backups/` + `db/test-environment.db` (both git-ignored) |
| **[GATE-2]** | Running `prisma migrate resolve` / `migrate deploy` **on the test file only** | only `db/test-environment.db` |
| **[GATE-3]** | Re-running the standing suites (incl. the temporary :3000 dev-server swap window) | test file + suite outputs; project DB file untouched on disk |

**Out of scope:** everything listed in §11 (no project-DB operation, no production deployment, no
schema change, no seed edit, no secret rotation, no `.env` edit).

## 2. Current database state

All facts below were verified read-only on 2026-10-27 (task F1: Prisma `count()` census +
`sqlite_master` query + `PRAGMA` reads + file checksum; identical numbers to the Phase B directive's
census run of the same date).

**The database:** `db/custom.db` (SQLite via Prisma; `DATABASE_URL` names it in the git-ignored
`.env`; template: `.env.example`). File facts at inspection time: 6,086,656 bytes (~5.8 MB), mtime
2026-10-27 11:48, SHA-256
`ea8d11d194c2394b0f516901b7e9abf9fe30fa6a7a2f11088ef30b7bb30148e8` (fingerprint recorded for
chain-of-custody; a later execution should expect this digest to match *unless* legitimate demo usage
or telemetry has since advanced the file — in which case the execution re-records the fresh
fingerprint). `db/backups/` does not exist yet (no snapshots on disk). No `-wal`/`-shm` sidecar files
present; `PRAGMA journal_mode` = **`delete`** (rollback-journal mode, not WAL — see §5). The dev
server was *not* listening on `:3000` at the inspection moment. `.env` currently carries only the
`DATABASE_URL` key name (`ASAS_SESSION_SECRET` absent → an ephemeral per-process secret fallback
applies whenever the server starts; relevant to §10).

### 2.1 Row-count census (2026-10-27, read-only)

| Model | Rows | | Model | Rows |
|---|---|---|---|---|
| `user` | 7 | | `activity` | 188 |
| `organization` | 1 | | `auditLog` | 153 |
| `lead` | 44 | | `task` | 21 |
| `opportunity` | 22 | | `apartment` | 46 |
| `visit` | 22 | | `project` (verified additionally) | 4 |
| `reservation` | 10 | | | |

This dataset is the post-WS-S re-seed of `prisma/seed.ts` (the canonical seed, D-016) — treated as
the canonical seed data for this execution. `auditLog` includes append-only LOGIN telemetry by design
(the GOV-1 convention: the business baseline excludes audit).

### 2.2 The `_prisma_migrations` gap

The `_prisma_migrations` table is **MISSING** from `db/custom.db` (verified via
`SELECT name FROM sqlite_master WHERE type='table' AND name LIKE '%prisma%'` → empty result), while
`prisma/migrations/` exists on disk with the canonical history: **12 migrations** — `0_init`,
`20261003020538_p4_composite_indexes`, `20261007120000_p8_9_schema_catchup_stage_changed_at`,
`20261007234744_p11_stage_wip_limit`, `20261008022052_p13_finance_installments`,
`20261008154438_p14_sav_cases`, `20261008231000_p16_remove_sav`,
`20261009050000_p18_crm_premium_operating_model`, `20261009080000_p20_visit_decision_lifecycle`,
`20261011090000_p29_commercial_trust`, `20261011150302_p30_duplicate_management`,
`20261019174640_p54_two_step_closure` (+ `migration_lock.toml`, provider `sqlite`). Consequence: any
Prisma migration command against this file sees the schema as *unmigrated* (all 12 "not yet applied")
even though the tables exist — the exact "restored DB lost its bookkeeping" class `AGENTS.md`
documents.

### 2.3 Divergence history (honest record — documented, not to be "fixed")

- The **WS-S round ended with the DB at 0 rows everywhere** (byte-exact empty baseline; worklog
  `WS-S-EXEC` closure addendum: "DB census 0 rows everywhere").
- **A subsequent session executed the R13-class recovery** (`bun run db:seed` per the canonical
  recipe) after that round — the census in §2.1 is the result. The re-seed was *not* executed by this
  proposal and predates it.
- The current counts **diverge from the suite-era baseline** the standing suites were designed
  against (`RECOVERY_GOVERNANCE_PROTOCOL.md` §5 / `NEXT_PHASE_PLAN.md` §10: users 8 · leads 43 ·
  opps 21 · visits 23 · activities 161 · apartments 46 · reservations 8 · projects 4 · tasks 18):

  | Model | Suite-era baseline | Current (2026-10-27) |
  |---|---|---|
  | user | 8 | **7** |
  | lead | 43 | 44 |
  | opportunity | 21 | 22 |
  | visit | 23 | 22 |
  | activity | 161 | 188 |
  | reservation | 8 | 10 |
  | task | 18 | 21 |
  | apartment / project / organization | 46 / 4 / 1 | 46 / 4 / 1 (identical) |

- **Roster detail (read-only observation):** the live DB holds 7 users in which `mounia@asas.dz`
  carries the legacy `MARKETING` role and `riadh@asas.dz` is absent — whereas the HEAD
  `prisma/seed.ts` creates **8** users with `mounia@asas.dz` and `riadh@asas.dz` both as `FIELD_REP`
  (P18/D-025). This is consistent with the re-seed having been executed from an earlier seed
  revision; the hypothesis is recorded, not adjudicated.
- **Per D7 this divergence is documented, not to be "fixed".** No operation in this proposal
  reconciles `db/custom.db` to any baseline. The *choice of which dataset the test environment
  targets* (a replica of the current DB vs a fresh run of the current seed) is an explicit GATE-1
  decision (§4).

## 3. Why the current state blocks particular tests

**The standing suites and what they assume.** The suites are HTTP probes against the live dev server
(`BASE = "http://localhost:3000"` — verified in `tmp-scripts/p12-visibility-matrix.ts` and
`tmp-scripts/count-baseline.ts`) combined with direct Prisma witnesses (`import { db } from
"@/lib/db"`) for baselines and residue sweeps:

| Suite | Script(s) (`tmp-scripts/`) | Last-green record |
|---|---|---|
| 325-probe authorization matrix | `p12-visibility-matrix.ts` | 325/325 (register: green at `4dbb89f` ancestry, D7-R6 closure) |
| Wave regression batteries | `pcc-wave1/2/3-regressions.ts` | 21 / 22 / 55 |
| Phase-C phased battery | `pcc-phased-regressions.ts` | 15/15 |
| Phase-D D7-R1..R6 batteries | `pd-d7r1…r6-regressions.ts` | 17 / 10 / 10 / 14 / 7 / 7 |
| Baseline witnesses | `count-baseline.ts`, `gov1-baseline-counts.ts`, `r6-financial-baseline.ts` | byte-exact at their anchored HEADs |

They were designed against the canonical seeded dataset and depend on it two ways:

1. **Fixture dependency.** Probes authenticate as the seeded personas (documented demo credentials,
   `AGENTS.md`) and assert visibility/scoping against seeded leads, opportunities, visits, and
   reservations; residue witnesses assert byte-exact return-to-baseline counts. With the DB empty
   (the WS-S state), every such suite is unrunnable — honestly recorded as **BLOCKED** in the WS-S
   execution and closure records ("standing 325-probe matrix + Wave/Phase-D suites are BLOCKED …
   recovery separately gated per register §1c.1 decision 8").
2. **Migration-bookkeeping dependency.** The repo's documented recovery recipe and any future
   `db:migrate`/`db:deploy` workflow assume coherent `_prisma_migrations` state. With the table
   missing, `prisma migrate status` reports all 12 migrations unapplied against a DB that already has
   the schema — an incoherent state that makes any migration-adjacent validation misleading and
   would make `migrate dev` attempt to re-apply `0_init` (§6).

**What Phase B does instead (and why that is not enough).** Per D7 and register §1c.1 decision 8,
Phase B uses **isolated scratch fixtures**: records created through the canonical APIs inside
throwaway scratch organizations, verified, then swept back to the exact starting baseline (the WS-S
byte-exact residue-witness pattern — census re-run to a 0-row delta, ×3). This validates the new
lifecycle code *without touching the project DB*, and it is the correct pattern for in-flight work.
**What remains blocked:** the standing matrix + Wave/Phase-D suites cannot be re-run at a current
HEAD at all, so the 325-probe authorization surface, the Wave UX regressions, and the Phase-D
navigation batteries are not re-asserted against seeded data while Phase B/C lifecycle work lands —
a standing regression-coverage gap (the WS-S record flagged the same gap). A dedicated, properly
migrated test environment with the canonical seed would un-block exactly this.

**Honest caveat (pre-declared, see §9):** un-blocking the suites does not guarantee they pass. They
were green at their commit-anchored HEADs; the tree has since moved (e.g. WS-S changed reservation
response shapes for floor roles; the seed-era dataset diverges per §2.3). Any post-recovery failure
must be *adjudicated against the change history and documented* — never silenced by weakening a
suite (the standing law: never weaken tests/authorization/validation for a passing build).

## 4. Proposed target environment

**Goal:** a database file that (a) carries a canonical seeded dataset and (b) has coherent Prisma
migration bookkeeping, (c) fully isolated from `db/custom.db`, (d) never committed (all of `db/` is
git-ignored, D-012).

### 4.1 Two variants — the GATE-1 choice

| | **Option A — replica of the current DB** | **Option B — fresh file + canonical seed** |
|---|---|---|
| Procedure | file-level copy of `db/custom.db` → `db/test-environment.db` | empty `db/test-environment.db` → `migrate deploy` (12/12) → `db:seed` |
| Dataset | exactly the §2.1 census (incl. its documented divergence) | whatever the **current** `prisma/seed.ts` produces (8 users incl. the `FIELD_REP` pair; must be censused at execution — the seed is time-relative, not byte-deterministic) |
| Bookkeeping | missing → repaired via Path R (§6) | created by `migrate deploy` itself (Path D) |
| Best for | reproducing the *live* environment's exact behavior | matching the suites' design-era roster most closely (8-persona grid incl. `riadh@asas.dz`) |

The owner (GATE-1) picks one; the chosen dataset's census is then **pinned as the test-env baseline**
and every later verification (§7, §9) compares against that pin. The two variants produce *different*
datasets — that difference is itself part of the §2.3 divergence record and must not be quietly
erased by mixing steps from both paths.

### 4.2 The isolation mechanism — CLI-level env override only, never an `.env` edit

Every command in this proposal that touches the test environment is prefixed with a per-command
environment override:

```bash
DATABASE_URL="file:/home/z/my-project/db/test-environment.db" <command>
```

- **Never edit `.env`** (it keeps naming `db/custom.db`; the override lives only in the executing
  shell command).
- **Precedence to verify before first use (read-only, value-free):** both Bun (auto-loads `.env`) and
  Next.js give real environment variables precedence over `.env`-file values — verify with
  `DATABASE_URL="file:…/db/test-environment.db" bun -e 'console.log(process.env.DATABASE_URL?.endsWith("test-environment.db"))'`
  → must print `true`. No value is ever printed.
- **Secrets law (D-012, `AGENTS.md`):** only variable *names* appear in this document
  (`DATABASE_URL`, `ASAS_SESSION_SECRET`, `ASAS_DEMO_MODE`). Values are never copied into any file,
  never printed. The test dev-server process (GATE-3 window) needs `ASAS_SESSION_SECRET` for stable
  sessions — supplied as a fresh random value (R13-recipe class: fresh `randomBytes(24)` /
  `openssl rand -hex 24`) inline in the launch command only, never appended to `.env` by this
  procedure. `ASAS_DEMO_MODE` stays at its sandbox default (ON) — do not "fix" it.

### 4.3 The dev-server swap window (GATE-3 only)

The suites probe `localhost:3000`, so the *server itself* must serve the test file during the run
window (the sandbox law: exactly one dev server, port 3000, never duplicated — so the test server
*replaces* the project server for the window):

1. Stop the project server **by PID** (`ss -tlnp` → `kill <PID>`; `pkill` can leave the port held —
   `AGENTS.md` dev-server law).
2. Start the test server backgrounded per the standing pattern:
   `(DATABASE_URL="file:/home/z/my-project/db/test-environment.db" ASAS_SESSION_SECRET="$(openssl rand -hex 24)" setsid nohup bun run dev > /dev/null 2>&1 &)`
   — the secret value is generated inline, never echoed, never persisted.
3. Run the suites (each with the same `DATABASE_URL` override prefix — the scripts' own `@/lib/db`
   witnesses must read the same test file).
4. Stop the test server by PID; restart the project server normally
   (`(setsid nohup bun run dev > /dev/null 2>&1 &)` — no override → `.env` → `db/custom.db`); verify
   `curl localhost:3000/` → 200 and the project-DB census unchanged.

### 4.4 Explicit isolation guarantees

1. `db/custom.db` is **never opened for write** by any step: the only commands aimed at it are
   read-only (`migrate status`, census counts, checksum) or the snapshot copy (a read of it).
2. **No shared file handles:** the test server and the suite scripts both point at
   `db/test-environment.db`; the project server is stopped during the window; SQLite's per-file
   single-writer model means zero contention with the project file.
3. **No `.env` change** (§4.2); the override exists only per-command.
4. **Never committed:** `db/` is git-ignored (D-012) — `db/test-environment.db` and `db/backups/`
   cannot enter version control; secrets never appear in any tracked file.
5. **Post-window proof:** a read-only re-census of *both* files — the test file shows the suite-run
   delta (telemetry/scratch, swept per §8), `db/custom.db` shows its pre-window counts and unchanged
   fingerprint (modulo legitimate concurrent demo usage, which must then be disclosed).

## 5. Backup / snapshot / rollback plan

**Snapshot before anything (GATE-1, first step).** `bun run db:snapshot` → creates the git-ignored
`db/backups/custom-<YYYYMMDD-HHMMSS>.db` (plain `cp` of `db/custom.db`; the script also lists the 3
newest). It currently does *not* exist on disk (§2) — the script creates the directory.

**Copy-safety caveat (SQLite file-level copies).** A SQLite file copied *while a writer holds it* can
capture a torn state: with WAL journaling, recent commits live in the `-wal` sidecar; with the
rollback journal (the verified current mode: `journal_mode=delete`), a transient `-journal` file
exists mid-transaction. Therefore, **before any copy — snapshot or test-env — either stop the dev
server (by PID) or checkpoint/confirm no active writer**, then verify no `custom.db-wal` /
`custom.db-shm` / `custom.db-journal` sidecars remain before `cp`. The generic rule the task mandates
stands even though WAL is not currently enabled: *stop the dev server or checkpoint (WAL) before
copying a SQLite file*. At proposal time this is trivially satisfied (server down, no sidecars).

**Copy with checksums (GATE-1).** After the pre-copy snapshot: copy `db/custom.db` →
`db/test-environment.db`, then `sha256sum` **both** files and record the digests + byte sizes in the
execution log (the §2 fingerprint is the reference for the source side). A digest mismatch = abort
and re-copy. For test-env-local snapshots later in the procedure, the same pattern applies with the
test filename (`cp db/test-environment.db db/backups/test-environment-<ts>.db`).

**Rollback definitions.**
- *Project DB (`db/custom.db`):* the procedure never writes it — there is **nothing to roll back**
  beyond restarting the project dev server (§4.3 step 4) if the swap window was entered. The
  pre-procedure snapshot is the belt-and-braces restore point: exact rollback = stop any server
  holding the file → restore the snapshot file over `db/custom.db` → restart the dev server →
  re-verify the census.
- *Test env (`db/test-environment.db`):* rollback = delete the file (plus any `-wal`/`-shm`/`-journal`
  sidecars) and re-create it from the snapshot per §6; or restore a mid-procedure test-env snapshot
  over it. No rollback path ever touches `db/custom.db`.

## 6. Canonical migration/recovery procedure

Derived from `AGENTS.md` (DB constraint: "A restored DB may lose `_prisma_migrations` bookkeeping →
`bunx prisma migrate resolve --applied 0_init` BEFORE `migrate dev` (bookkeeping only)"), the R13
recovery recipe, and `RECOVERY_GOVERNANCE_PROTOCOL.md` §5 (the P0 precedent: stop server → fresh file
→ `migrate deploy` → `prisma generate` → `db:seed` → restart). **Not executed by this document.**
`db:reset` (`prisma migrate reset` — DESTRUCTIVE) and `db:push` on the project DB appear **nowhere**
in this procedure. Script names: `db:snapshot` · `db:deploy` (`migrate deploy`) · `db:migrate`
(`migrate dev`) · `db:push` · `db:seed` · `db:reset` (`package.json`).

**Step 0 — read-only preflight (before GATE-1's copy; no writes anywhere):**
- `bunx prisma migrate status` (no override) — against the project DB: expect "12 migrations found …
  have not yet been applied" (the missing-table state, §2.2). Read-only.
- `bunx prisma migrate diff --from-url "file:/home/z/my-project/db/custom.db" --to-schema-datamodel prisma/schema.prisma`
  — expect **"No difference detected"** (the GOV-1 precedent). If differences are reported, STOP:
  the copied schema would not match `schema.prisma`, and bookkeeping repair alone cannot fix that —
  adjudicate before proceeding. (On a fresh `db/test-environment.db` after Option B's deploy, re-run
  the same diff against the test URL.)
- Record the §2 census + fingerprint (done at proposal time; re-run at execution — values must be
  re-observed, not trusted).

**Step 1 — snapshot (GATE-1):** `bun run db:snapshot`, after the §5 copy-safety check.

**Step 2 — copy (GATE-1, Option A only):** copy + checksum both files (§5). For Option B instead:
create the empty `db/test-environment.db` (an empty file) — no copy of the project DB at all.

**Step 3 — migration bookkeeping (GATE-2 — on the test file ONLY, via the §4.2 override):**

*Path R (Option A — the copy variant; bookkeeping-only, the `AGENTS.md` recipe):* for **each** of the
12 migrations, oldest first:

```bash
DATABASE_URL="file:/home/z/my-project/db/test-environment.db" \
  bunx prisma migrate resolve --applied <migration-directory-name>
```

`migrate resolve --applied <name>` only **records** bookkeeping (a row in `_prisma_migrations`) — it
does **not** execute the migration SQL (`AGENTS.md`: "bookkeeping only"). Repeat for all 12 names in
§2.2's order. **NO `migrate dev` is needed afterward** — `migrate dev` exists to *create* new
migrations; none are proposed here (schema change = non-goal, §11). Only if genuinely new migrations
existed would `db:migrate` follow, and then only against the test env. ⚠️ **Flagged uncertainty
(verify during execution):** whether `migrate resolve` succeeds when the `_prisma_migrations` table
is absent entirely (it may need to create it) — verify with read-only
`… bunx prisma migrate status` after the **first** resolve: the applied count must grow by one. If
resolve errors on the missing table, STOP and fall back to Option B (fresh file + Path D), recording
the observed behavior; do not improvise.

*Path D (Option B — the fresh-file variant; the GOV-1 P0 pattern):*

```bash
DATABASE_URL="file:/home/z/my-project/db/test-environment.db" bunx prisma migrate deploy
DATABASE_URL="file:/home/z/my-project/db/test-environment.db" bunx prisma generate
DATABASE_URL="file:/home/z/my-project/db/test-environment.db" bun run db:seed
```

`migrate deploy` applies the 12 migrations transactionally in order **and creates the
`_prisma_migrations` table itself** — clean on an empty file. ⚠️ **What `migrate deploy` does on a
missing-table DB that ALREADY HAS the schema (i.e. a copy, Option A): it cannot know the migrations
were applied — it attempts to apply `0_init` from scratch, whose `CREATE TABLE` statements collide
with the existing tables; the migration fails (recorded as failed) and deploy aborts in an
incoherent state. Therefore `migrate deploy` is ONLY for fresh empty files. Never point it at the
project DB or at a copy of it.** (`prisma generate` needs no database; included for recipe fidelity
with `RECOVERY_GOVERNANCE_PROTOCOL.md` §5.)

**Seed law:** `prisma/seed.ts` has an idempotence guard (skips if any `user` exists) — under Option A
never run `db:seed` (nothing to seed); under Option B run it exactly once with the override. Never
run `db:seed` without the override (it would target the project DB — forbidden).

**Step 4 — verification (GATE-2 exit):** §7 in full (`migrate status`, census vs the GATE-1 pin,
schema diff). All green before any suite runs.

**Step 5 — suite window (GATE-3):** the §4.3 swap window + §9 validation + §8 residue discipline +
project-server restore.

## 7. Data integrity and migration-history verification

**7.1 Migration-history verification — `bunx prisma migrate status` (with the §4.2 override).**
Interpretation table:

| Output | Meaning | Action |
|---|---|---|
| "12 migrations found … have not yet been applied" (all 12 listed) | missing bookkeeping (the pre-state; §2.2) | proceed with Path R (copy) or Path D (fresh) — never `migrate dev` |
| "Database schema is up to date!" | bookkeeping coherent with disk history | success — GATE-2 exit criterion |
| "following migration(s) have failed" | a deploy attempt collided (the §6 Path-D-on-a-copy hazard) or a genuine failure | STOP; adjudicate the failed entry against the execution log; never blind-retry, never `db:reset` |

**7.2 Row-count census against the pinned baseline.** Re-run the read-only census (the §2.1 battery:
server-independent Prisma `count()`s — not the HTTP-dependent `count-baseline.ts`, which needs the
swapped server). Compare against the **GATE-1 pin**: Option A → the §2.1 table exactly; Option B →
the census observed at first seed (recorded once, then frozen as the test-env baseline; the suite-era
witnesses `count-baseline.ts` / `gov1-baseline-counts.ts` / `r6-financial-baseline.ts` are then
re-pinned by *documented adjudication*, §8). Expected telemetry exception: `auditLog` may grow by
append-only LOGIN rows during any server-attached step — document the delta class, exclude it from
the byte-exact business comparison (the GOV-1 convention).

**7.3 Schema checksum comparison.** Primary tool (the GOV-1 precedent, read-only):
`bunx prisma migrate diff --from-url "file:/home/z/my-project/db/test-environment.db" --to-schema-datamodel prisma/schema.prisma`
→ **"No difference detected"**. Secondary, evidence-grade comparison against a reference: build a
throwaway reference file in a git-ignored temp path — `DATABASE_URL="file:…/db/reference.db" bunx prisma db push`
(fresh empty file; **never** `db:push` the project DB) — then compare the two files' `sqlite_master`
DDL via Prisma `$queryRaw` (the `sqlite3 .schema`-equivalent that needs no external CLI):
`SELECT type, name, sql FROM sqlite_master WHERE sql IS NOT NULL ORDER BY type, name` on each, and
compare normalized digests (sha256 of the concatenated rows). Digest equality + "No difference
detected" = the test DB's schema is provably the schema `schema.prisma` describes. Delete the
reference file afterwards.

**7.4 Dataset fidelity.** The seed is idempotent and **time-relative, not byte-deterministic**
(`RECOVERY_GOVERNANCE_PROTOCOL.md` §6) — row *counts* and referential shape are the invariant, never
byte-identity of rows or timestamps. Any census mismatch is adjudicated (seed revision? telemetry?
scratch residue?) and documented before proceeding — never silently re-seeded over.

## 8. Protecting canonical fixtures and seeds

- **`prisma/seed.ts` is versioned** (committed) — the canonical synthetic dataset, reproducible via
  `db:seed` (D-016). It is **never edited to make tests pass** — neither during recovery nor after
  (the standing law: never weaken tests/authorization/validation for a passing build; the WS-S
  boundary: no fixture/canonical-seed changes).
- **The test environment reseeds from the SAME canonical seed** (Option B) or replicates the live
  dataset (Option A) — either way `prisma/seed.ts` is read-only throughout the procedure. If a suite
  legitimately requires a dataset change, that is a *separate, explicitly-scoped* change with its own
  review and register record — never a side effect of recovery.
- **Test-residue discipline (the WS-S byte-exact residue-witness pattern).** Scratch fixtures created
  during suite runs are swept back to baseline: exact-state cleanup through the canonical APIs (or
  exact row restores), then the census re-run to a **0-row delta against the GATE-1 pin** — repeated
  (×3 in the WS-S precedent) and recorded. `AGENTS.md`: "Never leave test residue (DB counts back to
  baseline, exact restores documented)." In the test env the *pinned post-recovery census* is the
  baseline; in the project env the §2.1 census remains untouched by this whole procedure.
- **Baseline re-pinning is a documented adjudication, never a quiet edit.** If a witness's baked-in
  expectations no longer match the pinned dataset (the §2.3 divergence makes this likely for
  roster-sensitive probes), the change to the witness is recorded in the worklog with its reason and
  diff — the evidence chain (suite → baseline → dataset) stays auditable.

## 9. Validation plan after recovery

Executed **only** after GATE-2 exit criteria are met (§7 all green), inside the GATE-3 window, in
this order; every actual result recorded in the worklog (a check is passed only if executed and
observed):

| # | Check | Expected |
|---|---|---|
| 1 | Re-run the census (server-independent) against the test file | equals the GATE-1 pin exactly (§7.2 telemetry exception documented if present) |
| 2 | `bun run lint` | clean (0 errors) — tree health, DB-independent |
| 3 | `bunx tsc --noEmit` | 0 errors in `src/`; the pre-classified tolerated non-`src/` errors unchanged (the GOV-1 class) |
| 4 | Representative API probe through the swapped server (the GOV-1 §5 smoke): unauthenticated `GET /api/dashboard` → **401**; `POST /api/auth/login` with a documented demo persona → **200** + session cookie; authenticated `GET /api/dashboard` + `GET /api/leads` → **200** | exact statuses as stated |
| 5 | 325-probe authorization matrix (`DATABASE_URL=<test> bun tmp-scripts/p12-visibility-matrix.ts`) | **325/325 PASS** — or *documented drift* (see below) |
| 6 | Wave batteries `pcc-wave1/2/3-regressions.ts` | 21/21 · 22/22 · 55/55 — or documented drift |
| 7 | `pcc-phased-regressions.ts` + Phase-D `pd-d7r1…r6-regressions.ts` | 15/15 · 17/10/10/14/7/7 — or documented drift |
| 8 | Baseline witnesses (`count-baseline.ts`, `r6-financial-baseline.ts` as applicable) | byte-exact vs the re-pinned baseline |
| 9 | Post-suite residue witness (census ×3, §8) | 0-row delta vs the pin; documented telemetry exception only |
| 10 | Project-DB non-touch witness (§4.4.5) | `db/custom.db` census + fingerprint unchanged from the pre-window record (or legitimate concurrent usage disclosed) |

**Drift adjudication law.** The suites were green at their commit-anchored HEADs (last full set at
`4dbb89f` ancestry; register). Post-recovery failures **unrelated to the DB** — e.g. probes asserting
reservation response shapes that WS-S deliberately changed for floor roles, or roster-sensitive
probes against the divergent dataset (any probe authenticating as `riadh@asas.dz` fails against an
Option-A replica, §2.3) — are **documented with their cause and the responsible change**, triaged
into: (a) legitimate evolution → witness re-pinned per §8; (b) genuine regression → a separately
authorized fix; (c) inconclusive → flagged for owner review. A suite is never edited mid-run to
convert a failure into a pass, and no failure is silently dropped from the report.

## 10. Risks, prerequisites, and approval checkpoints

### 10.1 Risk register for the procedure

| Risk | Mitigation |
|---|---|
| **Torn SQLite copy** (WAL sidecar / mid-transaction journal) | stop the dev server (by PID) or confirm no active writer before any copy; verify no `-wal`/`-shm`/`-journal` sidecars; `sha256sum` both sides (§5). Currently `journal_mode=delete`, server down — trivially safe, but the check is mandatory anyway |
| **Dev-server file locking / port holding** | exactly one server on `:3000` at all times (swap window, §4.3); kill **by PID** from `ss -tlnp` (the `AGENTS.md` law — `pkill` can leave the port held); the stopped project server cannot hold `db/custom.db` |
| **Migration-bookkeeping edge cases** | `resolve` on a *missing* `_prisma_migrations` table = flagged uncertainty → verify with read-only `migrate status` after the first resolve (§6 Path R); `deploy` on a schema-present file = CREATE-collision failure → deploy only on fresh empty files (§6 Path D); `migrate dev` and `db:reset` excluded entirely |
| **Env-override precedence failure** (Bun/Next auto-load `.env`) | value-free boolean probe before every mutating command batch (§4.2); a failed probe = abort |
| **Secret exposure** | names only in every artifact; `ASAS_SESSION_SECRET` generated inline for the test server, never echoed/persisted; `.env` never edited; `db/` + `.env` git-ignored (D-012) |
| **Missing `ASAS_SESSION_SECRET` in `.env`** (observed, §2) | ephemeral-secret fallback resets sessions on server restart → mid-suite restarts could flake probes; use the inline secret for the test server (§4.2); re-appending to `.env` for the *project* env is the canonical R13 step but is a **separate** owner-authorized action, not part of this proposal |
| **Audit telemetry growth** | expected append-only LOGIN delta class, documented and excluded from byte-exact comparison (§7.2) |
| **Suite drift vs commit-anchored expectations** | pre-declared (§3, §9): adjudicate and document; never weaken a suite |
| **Dataset-choice confusion** (Option A vs B) | GATE-1 pins one variant + its census; steps from both paths are never mixed (§4.1) |

### 10.2 Prerequisites

- The three gates below, each an **explicit owner instruction** (recorded per the register's format —
  `OWNER_DECISION_REGISTER.md` is the canonical home; a directive, form answer, or in-session owner
  text qualifies; an agent recommendation does not).
- An execution session holding the Phase-B-class mandate; every step's *actual observed output*
  appended to `worklog.md`; evidence persisted under a dedicated `download/qa-*` directory.
- The §5 pre-copy safety state (server stopped or verified idle, no sidecars).

### 10.3 Approval checkpoints (binding)

| Gate | Exact authorization required | Boundary |
|---|---|---|
| **[GATE-1]** | Owner instruction authorizing: the pre-copy snapshot + creation of `db/test-environment.db` (choosing Option A replica or Option B fresh-seed) | writes only `db/backups/` + `db/test-environment.db`; reads `db/custom.db` at most |
| **[GATE-2]** | Owner instruction authorizing: running `prisma migrate resolve` (Path R) and/or `migrate deploy` (Path D) **against the test file only** | `db/custom.db` never a target; `migrate dev` / `db:reset` / `db:push`-on-project excluded; exit = §7 all green |
| **[GATE-3]** | Owner instruction authorizing: re-running the standing suites, incl. the temporary :3000 server swap window and the post-window project-server restore | project DB file untouched on disk; §9 executed in order; §8 residue + non-touch witnesses recorded |

**Every gate is an explicit owner instruction, never assumed, never inferred, never bundled** — a
prior gate's approval does not extend to the next. Absent a gate, the corresponding step simply does
not run (that is the current state of the world, and it remains valid).

## 11. Explicit non-goals

- **No restore, reset, reseed, migration, resolve, push, or recovery operation on the PROJECT
  database** (`db/custom.db`) — in this execution and in the proposed future one. Its state,
  including the §2.3 divergence, is accepted and documented.
- No production deployment, no remote, no git-history changes (D-013 stays separately gated).
- No schema changes (`prisma/schema.prisma` untouched); no new migrations; `db:migrate` not run.
- No edits to `prisma/seed.ts` or to any suite/witness to make tests pass.
- No secret rotation or generation beyond the inline, never-persisted test-server value; no `.env`
  edits; no secret values in any file, log, or output (names only).
- No changes under `src/`, `prisma/migrations/`, `db/` (beyond the git-ignored test-env artifacts),
  `tmp-scripts/`, `tests/`, or any config as part of the recovery itself; no weakening of D-021
  scoping, authorization, or validation anywhere in the procedure.

---

*Cross-references: `AGENTS.md` (DB constraint, secrets law, R13 recipe, dev-server law) ·
`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/OWNER_DECISION_REGISTER.md` (§1c.1 decision 8; the suite-green record) ·
`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/RECOVERY_GOVERNANCE_PROTOCOL.md` §5–§6 (P0 recovery precedent, surface census) ·
`05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/NEXT_PHASE_PLAN.md` §10 + Phase-G row (environment prerequisites; the
separately-gated recovery) · `05_ENGINEERING_DOCUMENTATION/00_PROJECT_GOVERNANCE/WORKSTREAM_S_IMPLEMENTATION_BRIEF.md` + worklog
`WS-S-EXEC`/`WS-S-REVIEW` (the isolated-fixtures precedent and the honest BLOCKED record) ·
`prisma/migrations/` (the 12-migration canonical history) · `prisma/seed.ts` (the canonical seed).*

---

## 12. EXECUTION ADDENDUM — 2026-10-27/28 (Phase C, Decision C-1: the three gates verified and PASSED; recovery EXECUTED against the isolated test database)

**Status change (this section only — everything above is preserved as the proposal history):** the owner's Phase C directive (register §1e, C-1) authorized execution conditional on the three §10.3 gates being verified. They were, and the recovery ran. Nothing above was edited.

**Gate results (exact §10.3 wording → evidence):**
- **[GATE-1]** "Owner instruction authorizing: the pre-copy snapshot + creation of `db/test-environment.db` (choosing Option A replica or Option B fresh-seed)" — SATISFIED: the Phase C mandate (C-1) is the explicit owner instruction; boundary honored (writes only `db/backups/` + `db/test-environment.db`; `db/custom.db` read at most). Variant: **Option B** (documented determination — `db/custom.db` was found EMPTY after another R13-class environment wipe: 0 rows everywhere, `_prisma_migrations` missing, schema == current via `migrate diff` "No difference detected"; there was nothing to replicate, and the proposal itself ranks Option B best for the suites' design-era roster). Pre-op snapshot taken after the §5 copy-safety check (server stopped by PID, port verified free, no sidecars): `db/backups/custom-20261027-135347.db`, sha256 both sides identical (`fde4c307…` — the fresh post-wipe fingerprint, re-recorded per the chain-of-custody law).
- **[GATE-2]** "Owner instruction authorizing: running `prisma migrate resolve` (Path R) and/or `migrate deploy` (Path D) against the test file only" — SATISFIED (C-1 + C-2): Path D executed with the per-command `DATABASE_URL` override (precedence probed `true` before every mutating batch; `.env` never edited): `migrate deploy` → 12/12 applied, "Database schema is up to date!"; `prisma generate`; `db:seed` → the canonical dataset. §7 verification all green: census PINNED at the suite-era design baseline (8 users / 43 leads / 21 opps / 23 visits / 8 reservations / 161 activities / 18 tasks / 46 apartments / 4 projects); `migrate diff` test-vs-schema = "No difference detected"; sqlite_master DDL digest vs a `db push` reference file = identical modulo exactly one object (`_prisma_migrations` — deploy's own bookkeeping table). `migrate dev` / `db:reset` / `db:push`-on-project: never run. Test-target backup: `db/backups/test-environment-20261027-135435.db` (digest match).
- **[GATE-3]** "Owner instruction authorizing: re-running the standing suites, incl. the temporary :3000 server swap window and the post-window project-server restore" — SATISFIED (C-1 + C-3 §6): the swap window executed per §4.3 (inline ephemeral secret, never echoed/persisted); §9 ran in order (smoke 401/login-200/auth-200; then p12 319/325 · wave1 20/21 · wave2 22/22 · wave3 55/55 · phased 15/15 · d7r1 17/17 · d7r2 10/10 · d7r3 10/10 · d7r4 14/14 · d7r5 7/7 · d7r6 5/7 — every failure drift-adjudicated per the §9 law, documented in the worklog; ZERO genuine regressions); residue witness ×3 byte-exact vs the pin; post-window project-server restore + project-DB non-touch witness (`custom.db` sha256 UNCHANGED, 0 users).

**Subsequent use of the test target (within the same authorization):** migration `20261027140445_phase_c_visit_report` (C-2) created via `migrate dev --create-only` with the override and applied via `migrate deploy` to the test file only; both compatibility paths verified (existing-data: census unchanged, 12 legacy completed visits report-less — they correctly fail the closure gate; fresh-schema: a scratch fresh file + 13 migrations + the report-bearing seed — 12/12 valid reports); after the browser E2E mutated the test data, the documented rollback was exercised ONCE (server stopped → the §5 test-target snapshot restored over `db/test-environment.db` → migration 13 re-applied → census re-verified at the pin) — the exact §5 rollback path, proving it viable.

**Protected-database attestation:** `db/custom.db` — never restored, reset, reseeded, migrated, resolved, pushed, or otherwise written; sha256 `fde4c307…` identical before and after the whole phase; 0 rows. The remaining dependency (the owner decision recorded in register §1e.2): the project DB is empty AND schema-stale relative to migration 13; its honest recovery is the Option-B pattern aimed at the protected file and requires an explicit owner instruction.
