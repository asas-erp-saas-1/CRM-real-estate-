"use client";

import { useEffect } from "react";

// Phase 1 Task 3 — global error boundary (Next.js App Router pattern:
// global-error.tsx catches errors in the root layout itself — error.tsx is
// bypassed there). MUST render its own <html>/<body>. Styling is inline on
// purpose: a root-layout failure cannot rely on the CSS pipeline, so this
// fallback is fully self-contained and immune to any stylesheet failure.
//
// UX contract: safe generic message (no internals), digest as one-way hash
// reference, recovery = retry (reset) + reload. Full error -> console only.
// French-first (app default); English/Arabic inline as secondary lines.

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  // FRONTEND-AUDIT fix — diagnostics side effect moved OUT of the render body
  // into an effect (the same pattern as error.tsx): console.error must not run
  // on every render pass.
  useEffect(() => {
    if (typeof console !== "undefined" && console.error) {
      console.error("[global-error-boundary]", error);
    }
  }, [error]);

  const card: React.CSSProperties = {
    maxWidth: "420px",
    margin: "15vh auto",
    padding: "24px",
    borderRadius: "8px",
    border: "1px solid #e2e2e0",
    background: "#fafaf9",
    color: "#1c1c1a",
    fontFamily:
      'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans Arabic", sans-serif',
    lineHeight: 1.5,
    textAlign: "start",
  };
  const btn: React.CSSProperties = {
    display: "inline-block",
    padding: "10px 16px",
    margin: "4px 8px 4px 0",
    borderRadius: "6px",
    fontSize: "14px",
    fontWeight: 600,
    cursor: "pointer",
    textDecoration: "none",
  };
  const primary: React.CSSProperties = { ...btn, background: "#047857", color: "#ffffff", border: "none" };
  const secondary: React.CSSProperties = { ...btn, background: "transparent", color: "#3f3f46", border: "1px solid #d4d4d4" };
  const muted: React.CSSProperties = { fontSize: "13px", color: "#71717a", margin: 0 };

  return (
    <html lang="fr">
      <body style={{ background: "#fcfcfb", margin: 0 }}>
        <main role="alert" style={card}>
          <p style={{ ...muted, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 4 }}>
            ASAS — CRM Immobilier
          </p>
          <h1 style={{ fontSize: "18px", margin: "0 0 8px" }}>Une erreur critique est survenue</h1>
          <p style={muted}>
            L'application n'a pas pu démarrer correctement. Vos données ne sont pas affectées.
          </p>
          <p style={muted}>
            A critical application error occurred. Your data is unaffected. · حدث خطأ حرج في التطبيق.
            بياناتك لم تتأثر.
          </p>
          <div style={{ marginTop: 16 }}>
            <button type="button" onClick={reset} style={primary}>
              Réessayer / Retry / أعد المحاولة
            </button>
            <a href="/" style={secondary}>
              Recharger / Reload / إعادة التحميل
            </a>
          </div>
          {error.digest ? (
            <p style={{ ...muted, marginTop: 16, fontFamily: "ui-monospace, monospace", wordBreak: "break-all" }}>
              ref: {error.digest}
            </p>
          ) : null}
        </main>
      </body>
    </html>
  );
}
