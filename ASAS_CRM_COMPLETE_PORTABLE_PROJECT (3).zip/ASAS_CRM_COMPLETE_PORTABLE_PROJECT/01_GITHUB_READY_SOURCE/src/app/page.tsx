"use client";

// ASAS — CRM Immobilier. Single visible route `/`; client-side view routing
// via zustand + URL hash. All data through /api (Task 1-a contract v1).

import { CrmApp } from "@/components/crm/crm-app";
import { Providers } from "@/components/crm/providers";

export default function Page() {
  return (
    <Providers>
      <CrmApp />
    </Providers>
  );
}
