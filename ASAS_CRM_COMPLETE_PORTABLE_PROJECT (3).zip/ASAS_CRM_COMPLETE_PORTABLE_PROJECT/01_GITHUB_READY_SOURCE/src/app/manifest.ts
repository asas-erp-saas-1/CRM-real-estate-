// ASAS — web app manifest (P42 brand kit + completion round: maskable +
// 512 raster entries). Brand: Phase 12 "Forêt & Champagne" — deep forest green #0f5d3c
// (oklch 0.45 0.10 160) on warm paper #FBFAF8. Icon set: favicon SVG (any)
// + 512 PNG route /icon-512 (Chrome install criterion; Firefox/Safari do
// not rasterize manifest SVGs) + full-bleed maskable SVG (OS circle/
// squircle crop-safe, mark at 80% in the safe zone) + apple-touch PNG 180.
import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "ASAS — CRM Immobilier",
    short_name: "ASAS",
    description:
      "CRM immobilier de nouvelle génération pour ASAS (Alger) — prospects, pipeline, visites, inventaire, analytique.",
    start_url: "/",
    display: "standalone",
    background_color: "#FBFAF8",
    theme_color: "#0f5d3c",
    icons: [
      {
        src: "/icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "any",
      },
      {
        // 512×512 raster — plain route handler (src/app/icon-512/route.ts)
        src: "/icon-512",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        // Full-bleed maskable variant — safe-zone centered monogram
        src: "/brand/asas-maskable-icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "maskable",
      },
      {
        // Apple touch artwork (auto-served PNG route, 180×180)
        src: "/apple-icon",
        sizes: "180x180",
        type: "image/png",
        purpose: "any",
      },
    ],
  };
}

