// ASAS — apple-touch-icon (P42 brand kit). ImageResponse renders the
// official tile mark at 180×180 (no text → no font payload needed).
// Static SVG sibling: src/app/icon.svg (auto-linked favicon).
import { ImageResponse } from "next/og";

export const size = { width: 180, height: 180 };
export const contentType = "image/png";

export default function AppleIcon() {
  return new ImageResponse(
    (
      <svg
        width={180}
        height={180}
        viewBox="0 0 32 32"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect x="1" y="1" width="30" height="30" rx="7" fill="#0f5d3c" />
        <g
          fill="none"
          stroke="#FBFAF8"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M16 8.2 9.2 24.2 M16 8.2 22.8 24.2" />
          <path d="M12.6 18.4 H19.4" />
          <path d="M8.2 27.6 H23.8" />
        </g>
      </svg>
    ),
    size,
  );
}
