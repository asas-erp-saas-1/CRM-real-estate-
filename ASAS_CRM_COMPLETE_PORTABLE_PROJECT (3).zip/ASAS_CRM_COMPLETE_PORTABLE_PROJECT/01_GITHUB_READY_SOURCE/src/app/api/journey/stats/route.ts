// GET /api/journey/stats — Journey Performance (NJ — the measurement layer
// of the customer journey).
//
// The management twin of the worklist: the SAME population (non-archived
// customers in the caller's org scope), the SAME derivation engine
// (src/lib/journey.ts — computeJourney + computeUrgency per customer, then
// computeJourneyStats over the whole book), so the two surfaces can never
// disagree (one engine, one truth — the G5 single-definition law).
//
// A2 (C1): the fact machinery (lean projections, the ONE batched reservation
// fetch, facts assembly, the money scan) lives in src/lib/server/
// journey-facts.ts, shared with GET /api/journey — the two surfaces read the
// world through the same code.
//
// Role law (D-021, the analytics law): performance metrics are MANAGER+.
// Agents keep the worklist; the API answers 403 below MANAGER (the client
// hides the tab for them — the analytics-view pattern).
//
// Returns computeJourneyStats output + scope (see the lib for the shape):
//   funnel   — cumulative "ever reached" counts + step conversion rates
//   live     — per live stage: count, avg age, stalled (SLA heuristics)
//   outcomes — won/lost counts, avg days to win/loss, lost-at-stage, reasons
//   urgency  — live customers per urgency tier (the pressure gauge)
//   money    — pipeline + reservation + expiring values
//
// Cost review (the mandate's engineering-cost discipline): ZERO schema
// change, ONE batched lead load (same lean projections as the worklist) +
// ONE batched reservation fetch — no N+1, no groupBy cascade; every number
// rides the pure engine.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { seesAllRecords } from "@/lib/server/visibility";
import { computeJourney, computeJourneyStats, computeUrgency } from "@/lib/journey";
import {
  buildJourneyFacts,
  FACT_INCLUDE,
  fetchReservationsByOpp,
  reservationsForLead,
  scanMoneyFacts,
} from "@/lib/server/journey-facts";

export async function GET(_req: NextRequest) {
  try {
    // D-021 — journey performance is a management metric surface.
    const user = await requirePermission("analytics.view");
    const isManager = seesAllRecords(user);

    const leads = await db.lead.findMany({
      where: {
        orgId: user.orgId,
        archived: false, // the live-funnel law (same population as the worklist)
      },
      include: FACT_INCLUDE,
      orderBy: [{ createdAt: "desc" }],
      take: 1000, // the whole active book; a seeded demo org sits far below.
    });

    // ONE batched reservation fetch for every opportunity (the Phase D
    // money-path join pattern — no N+1; the stats money aggregate reads the
    // amount column the worklist's scan also uses).
    const reservationsByOpp = await fetchReservationsByOpp(user.orgId, leads);

    const now = new Date();
    const entries: Parameters<typeof computeJourneyStats>[0] = [];

    for (const lead of leads) {
      const reservations = reservationsForLead(lead, reservationsByOpp);
      const facts = buildJourneyFacts(lead, reservations);

      const journey = computeJourney(facts);
      const urgency = computeUrgency(facts, journey.stage, now);

      // the worklist's money scan, verbatim — the two surfaces agree by code.
      const { oppValue, reservationAmount } = scanMoneyFacts(lead, reservations);

      entries.push({
        facts,
        journey,
        urgency,
        oppValue,
        reservationAmount,
      });
    }

    const stats = computeJourneyStats(entries, now);

    return ok({
      ...stats,
      scope: isManager ? "org" : "own",
      generatedAt: now.toISOString(),
    });
  } catch (error) {
    return fail(error);
  }
}
