// GET /api/journey/export — the Customer Journey worklist as CSV (R13).
//
// "Export what you see" for the journey workspace: the SAME loader as
// GET /api/journey (scope law + stage/owner/stalled/query filters + the
// prioritized act-next order — one pipeline, two consumers), rendered as
// the agency-head's reporting file. Role: MANAGER+ (the journey.export
// permission rides the same RBAC row as lead.export — exports are a
// management activity). A JOURNEY_EXPORTED audit entry is logged with the
// applied filter set.
//
// Format: semicolon-separated + UTF-8 BOM (FR-locale Excel default — target
// market is Algeria/French business environment), CRLF line endings — the
// same law as the leads export. Every free-text column flows through
// csvEscape (formula-injection defanging, P4-8 F-14 — shared at
// @/lib/server/csv); enum-ish columns (stage/urgency/nextAction/priority/
// source) export their raw stable ids, exactly like the leads CSV's
// status/source columns.

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, requireUser } from "@/lib/server/session";
import { csvDocument, csvEscape } from "@/lib/server/csv";
import { loadJourneyWorklist, parseJourneyWorklistQuery } from "@/lib/server/journey-worklist";
import { displayPhone } from "@/lib/phone";

const HEADERS = [
  "id",
  "fullName",
  "phone",
  "phoneDisplay",
  "email",
  "journeyStage",
  "stageSince",
  "daysInStage",
  "urgency",
  "urgencyRank",
  "stalled",
  "nextAction",
  "oppValue",
  "reservationAmount",
  "nextVisitAt",
  "owner",
  "score",
  "priority",
  "source",
  "createdAt",
  "lastContactAt",
  "nextFollowUpAt",
] as const;

const DAY_MS = 24 * 60 * 60 * 1000;

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser("MANAGER");
    const now = new Date();
    const result = await loadJourneyWorklist(user, parseJourneyWorklistQuery(req));

    const rows: (string | number | null | undefined)[][] = result.customers.map((c) => {
      const since = c.journey.since ? new Date(c.journey.since) : null;
      const daysInStage = since ? Math.max(0, Math.floor((now.getTime() - since.getTime()) / DAY_MS)) : "";
      return [
        c.lead.id,
        csvEscape(c.lead.fullName),
        c.lead.phone,
        csvEscape(displayPhone(c.lead.phone)),
        csvEscape(c.lead.email),
        c.journey.stage,
        c.journey.since ?? "",
        daysInStage,
        c.urgency.tier,
        c.urgency.rank,
        c.stalled ? "1" : "0",
        c.journey.nextAction,
        c.oppValue ?? "",
        c.reservationAmount ?? "",
        c.nextVisitAt ?? "",
        csvEscape(c.lead.owner?.name ?? ""),
        c.lead.score ?? "",
        c.lead.priority,
        c.lead.source,
        c.lead.createdAt.toISOString(),
        c.lead.lastContactAt?.toISOString() ?? "",
        c.lead.nextFollowUpAt?.toISOString() ?? "",
      ];
    });
    const csv = csvDocument(HEADERS, rows); // BOM + CRLF for Excel FR

    await logAudit({
      orgId: user.orgId,
      actor: user,
      action: "JOURNEY_EXPORTED",
      entity: "LEAD",
      after: {
        count: result.total,
        scope: result.scope,
        filters: Object.fromEntries(req.nextUrl.searchParams.entries()),
      },
    });

    const stamp = new Date().toISOString().slice(0, 10);
    return new NextResponse(csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="asas-parcours-${stamp}.csv"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    if (error instanceof ApiError && error.status === 403) {
      return NextResponse.json(
        { error: "L'export du parcours client requiert le rôle Manager ou supérieur.", code: "EXPORT_FORBIDDEN" },
        { status: 403 },
      );
    }
    return fail(error);
  }
}
