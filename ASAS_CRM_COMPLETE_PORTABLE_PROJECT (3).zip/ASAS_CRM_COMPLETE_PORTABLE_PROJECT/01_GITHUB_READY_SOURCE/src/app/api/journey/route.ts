// GET /api/journey — the Customer Journey worklist (CJ — guided lifecycle UX).
//
// THE role-aware "who needs what next" surface: every live customer in the
// caller's visibility scope, derived onto the 8-step journey model (one pure
// function — src/lib/journey.ts — shared with the drawer's rail so the two
// surfaces can never disagree), prioritized for action (urgency tiers), with
// the funnel counts for the header.
//
// Role law (visibility.ts, D-021/P18): the journey list is LEAD-scoped —
//   MANAGER+    → the whole org (plus the `owner` filter: me / unassigned)
//   SALES_AGENT → OWN+POOL (their day reads as "my customers + the intake")
//   FIELD_REP    → the leads of visits on their assigned projects
// Archived leads never enter the worklist (the funnel is live customers —
// same law as the leads view's default scan).
//
// A2 (C1): the fact machinery (lean projections, the ONE batched reservation
// fetch, facts assembly, the money scan) lives in src/lib/server/
// journey-facts.ts, shared with GET /api/journey/stats — the two surfaces
// read the world through the same code.
//
// Query params:
//   stage — filter to one JOURNEY_STAGES value (funnel segment click)
//   owner — "me" | "unassigned" (MANAGER+ only; ignored below)
//   query — free-text on name/phone/email (same predicate family as leads)
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope, seesAllRecords } from "@/lib/server/visibility";
import { toLeadDTO } from "@/lib/server/leads";
import { qp } from "@/lib/server/validation";
import {
  computeJourney,
  computeUrgency,
  JOURNEY_STAGES,
  type JourneyStage,
} from "@/lib/journey";
import {
  buildJourneyFacts,
  FACT_INCLUDE_FULL,
  fetchReservationsByOpp,
  reservationsForLead,
  scanMoneyFacts,
} from "@/lib/server/journey-facts";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();

    const stageFilter = qp(req, "stage");
    if (stageFilter && !JOURNEY_STAGES.includes(stageFilter as JourneyStage)) {
      throw new ApiError(422, "Paramètre 'stage' : valeur non reconnue", "INVALID_STAGE", {
        allowed: [...JOURNEY_STAGES],
      });
    }

    const ownerFilter = qp(req, "owner"); // "me" | "unassigned" — MANAGER+ only
    if (ownerFilter && ownerFilter !== "me" && ownerFilter !== "unassigned") {
      throw new ApiError(422, "Paramètre 'owner' : valeur non reconnue", "INVALID_OWNER");
    }

    const query = (qp(req, "query") ?? "").trim();
    const isManager = seesAllRecords(user);

    // ---- base scope: the lead-visibility law, then worklist refinements
    const base: Record<string, unknown> = {
      orgId: user.orgId,
      archived: false, // live funnel only
      ...(leadScope(user) ?? {}),
    };
    if (isManager && ownerFilter === "me") base.ownerId = user.id;
    if (isManager && ownerFilter === "unassigned") base.ownerId = null;
    if (query) {
      base.OR = [
        { fullName: { contains: query } },
        { phone: { contains: query } },
        { email: { contains: query } },
      ];
    }

    // Lean fact projections — exactly what the journey engine reads, plus the
    // owner/tags presentation joins (the shared module's FULL superset).
    const leads = await db.lead.findMany({
      where: base,
      include: FACT_INCLUDE_FULL,
      // 5a (G2 audit) — deterministic truncation: the 500-row cap needs a
      // total order or the cut is SQLite's whim (same-millisecond createdAt
      // ties — bulk import, seeded rows — could flip which leads fall out of
      // the worklist between two calls). createdAt desc (the live worklist
      // favors recent intake) with id asc as the tiebreaker is stable.
      // HONEST CEILING: `total` and `stages` below are computed over THIS
      // capped set, not the uncapped funnel — a >500-lead org sees funnel
      // counts for the newest 500 live customers only.
      orderBy: [{ createdAt: "desc" }, { id: "asc" }],
      // the full live funnel is bounded by the org's active book; a seeded
      // demo org sits far below this cap (the honest ceiling).
      take: 500,
    });

    // ---- ONE batched reservation fetch for the whole page's opportunities
    //      (the Phase D money-path join: reservations ride opportunities).
    const reservationsByOpp = await fetchReservationsByOpp(user.orgId, leads);

    const now = new Date();
    const stages: Record<JourneyStage, number> = {
      CAPTURED: 0,
      ENGAGED: 0,
      QUALIFIED: 0,
      VIEWING: 0,
      NEGOTIATING: 0,
      BOOKING: 0,
      WON: 0,
      LOST: 0,
    };
    const customers: {
      lead: ReturnType<typeof toLeadDTO>;
      journey: ReturnType<typeof computeJourney>;
      urgency: ReturnType<typeof computeUrgency>;
      oppValue: number | null;
      reservationAmount: number | null;
      nextVisitAt: string | null;
    }[] = [];

    for (const lead of leads) {
      const reservations = reservationsForLead(lead, reservationsByOpp);
      const facts = buildJourneyFacts(lead, reservations);

      const journey = computeJourney(facts);
      stages[journey.stage] += 1;
      if (stageFilter && journey.stage !== stageFilter) continue;

      const urgency = computeUrgency(facts, journey.stage, now);

      // Live deal value + next scheduled visit (worklist scan columns).
      const { oppValue, reservationAmount } = scanMoneyFacts(lead, reservations);
      const nextVisit = [...lead.visits]
        .filter((v) => v.status === "SCHEDULED" || v.status === "CONFIRMED")
        .sort((a, b) => a.scheduledAt.getTime() - b.scheduledAt.getTime())[0];

      customers.push({
        lead: toLeadDTO(lead),
        journey,
        urgency,
        oppValue,
        reservationAmount,
        nextVisitAt: nextVisit?.scheduledAt.toISOString() ?? null,
      });
    }

    // Prioritized order: urgency rank desc (the act-next ordering), then
    // compounding reasons count, then the newest lead first (stable).
    customers.sort((a, b) => {
      if (b.urgency.rank !== a.urgency.rank) return b.urgency.rank - a.urgency.rank;
      if (b.urgency.reasons.length !== a.urgency.reasons.length)
        return b.urgency.reasons.length - a.urgency.reasons.length;
      return (
        new Date(b.lead.createdAt).getTime() - new Date(a.lead.createdAt).getTime()
      );
    });

    return ok({
      stages,
      scope: isManager ? "org" : "own",
      owner: ownerFilter ?? null,
      query: query || null,
      total: customers.length,
      customers,
    });
  } catch (error) {
    return fail(error);
  }
}
