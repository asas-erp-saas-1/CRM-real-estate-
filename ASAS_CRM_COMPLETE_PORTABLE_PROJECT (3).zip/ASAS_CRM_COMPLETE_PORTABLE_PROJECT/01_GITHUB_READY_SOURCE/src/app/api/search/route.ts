// GET /api/search?q — global search across leads, opportunities, projects,
// apartments, developers, contacts, SAV cases and finance installments.
// Indexed contains queries only — no full-table JS filtering. q < 2 chars →
// empty result sets.
// D-021 — search results respect record visibility (mandate §15): below
// MANAGER, lead/opportunity/contact hits are OWN+POOL scoped — a foreign
// record never leaks through results, counts or autocomplete. Projects,
// apartments and developers are shared inventory — org-scoped for all roles.
// UX-S — the two lifecycle workspaces join the palette: SAV cases (every
// role — the SAV view's own law, savScope composition) and finance
// installments (MANAGER+ only — the finance view IS the collections
// workspace gated by overview; a below-MANAGER palette row would deep-link
// straight into the 403 lock screen, the exact dead-end this surface kills).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok, requireUser } from "@/lib/server/session";
import { contactScope, installmentScope, leadScope, oppScope, savScope, seesAllRecords } from "@/lib/server/visibility";
import { qp } from "@/lib/server/validation";
import { normalizeArabicQuery } from "@/lib/arabic";

const EMPTY = {
  leads: [],
  opportunities: [],
  projects: [],
  apartments: [],
  developers: [],
  contacts: [],
  savCases: [],
  installments: [],
};

/** UX-S — "SAV-3" / "sav 3" / "SAV3" → 3 (the org-wide human reference is
 * the one number a team actually says out loud). Anything else → null. */
function savSeqFromQuery(q: string): number | null {
  const m = /^sav[-\s]?(\d{1,6})$/i.exec(q.trim());
  return m ? Number(m[1]) : null;
}

/** R14 — Arabic-alias contains fragments (the data-level Arabic search):
 * the raw query against the Arabic field PLUS the folded variant when
 * folding changed it — a tashkeel/hamza-carrying query reaches the stored
 * folded space through qAr. Latin queries fold to themselves → the second
 * fragment is simply never emitted. Structurally compatible with every
 * *WhereInput carrying the field (spread into each model's own OR). */
function arContains(field: "fullNameAr" | "nameAr", q: string, qAr: string) {
  const out: Record<string, { contains: string }>[] = [{ [field]: { contains: q } }];
  if (qAr !== q) out.push({ [field]: { contains: qAr } });
  return out;
}

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;

    const q = qp(req, "q");
    if (!q || q.length < 2) return ok(EMPTY);
    // R14 — the folded query (Arabic ambiguity → the stored fold space)
    const qAr = normalizeArabicQuery(q);

    const savSeq = savSeqFromQuery(q);
    // UX-S — installments surface only where the finance view they deep-link
    // into actually renders (MANAGER+ — the nav's own minRole for Finance).
    const canSeeFinance = seesAllRecords(user);

    const [leads, opportunities, projects, apartments, developers, contacts, savCases, installments] = await Promise.all([
      db.lead.findMany({
        // D-021 — scope AND match-terms, composed via AND (spreading the
        // scope's OR next to this route's own OR key would silently overwrite
        // it — the exact bug the §40 matrix caught: a foreign lead leaked into
        // autocomplete. AND-composition is the only safe shape here).
        where: {
          orgId,
          AND: [
            leadScope(user) ?? {},
            {
              OR: [
                { fullName: { contains: q } },
                { phone: { contains: q } },
                { phoneRaw: { contains: q } },
                { email: { contains: q } },
                ...arContains("fullNameAr", q, qAr),
              ],
            },
          ],
        },
        take: 5,
        select: {
          id: true,
          fullName: true,
          fullNameAr: true,
          phone: true,
          email: true,
          status: true,
          source: true,
          owner: { select: { id: true, name: true } },
        },
      }),
      db.opportunity.findMany({
        // D-021 — same AND-composition (scope's OR must never be overwritten).
        where: {
          orgId,
          AND: [
            oppScope(user) ?? {},
            {
              OR: [
                { title: { contains: q } },
                { lead: { fullName: { contains: q } } },
                { lead: { fullNameAr: { contains: q } } },
                ...(qAr !== q ? [{ lead: { fullNameAr: { contains: qAr } } }] : []),
              ],
            },
          ],
        },
        take: 5,
        select: {
          id: true,
          title: true,
          stage: true,
          value: true,
          lead: { select: { id: true, fullName: true, fullNameAr: true } },
        },
      }),
      db.project.findMany({
        where: {
          orgId,
          OR: [{ name: { contains: q } }, { district: { contains: q } }, ...arContains("nameAr", q, qAr)],
        },
        take: 5,
        select: { id: true, name: true, nameAr: true, district: true, city: true, status: true },
      }),
      db.apartment.findMany({
        where: { orgId, OR: [{ code: { contains: q } }, { building: { name: { contains: q } } }] },
        take: 5,
        select: {
          id: true,
          code: true,
          unitType: true,
          status: true,
          price: true,
          surface: true,
          building: { select: { name: true, project: { select: { name: true } } } },
        },
      }),
      db.developer.findMany({
        where: { orgId, OR: [{ name: { contains: q } }, ...arContains("nameAr", q, qAr)] },
        take: 5,
        select: { id: true, name: true, nameAr: true },
      }),
      db.contact.findMany({
        where: {
          orgId,
          AND: [
            contactScope(user) ?? {},
            {
              OR: [
                { fullName: { contains: q } },
                ...arContains("fullNameAr", q, qAr),
              ],
            },
          ],
        },
        take: 5,
        select: { id: true, fullName: true, fullNameAr: true, phone: true, email: true, leadId: true },
      }),
      db.savCase.findMany({
        // UX-S — D-021 AND-composition (the scope fragment is element 0 of
        // the conditions array — never spread next to this route's own OR).
        // Matches: the human reference (SAV-3), the title, the reported
        // description, or the client's name — every way a case is recalled.
        where: {
          orgId,
          AND: [
            savScope(user) ?? {},
            {
              OR: [
                ...(savSeq !== null ? [{ seq: savSeq }] : []),
                { title: { contains: q } },
                { description: { contains: q } },
                { lead: { fullName: { contains: q } } },
                ...arContains("fullNameAr", q, qAr).map((f) => ({ lead: f })),
              ],
            },
          ],
        },
        take: 5,
        // most recently reported first — how a team recalls "the case we
        // just opened" (the list view keeps its own overdue-first scan law)
        orderBy: { reportedAt: "desc" },
        select: {
          id: true,
          seq: true,
          title: true,
          category: true,
          priority: true,
          status: true,
          dueAt: true,
          lead: { select: { id: true, fullName: true, fullNameAr: true } },
          apartment: { select: { id: true, code: true } },
        },
      }),
      canSeeFinance
        ? db.installment.findMany({
            // UX-S — same AND-composition with installmentScope (defense-in
            // depth — the route's own law); the finance palette row deep-links
            // by CLIENT NAME, which /api/finance/installments?query= matches
            // (label · apartment code · lead fullName — the exact predicates).
            where: {
              orgId,
              AND: [
                installmentScope(user) ?? {},
                {
                  OR: [
                    { label: { contains: q } },
                    { reservation: { contractRef: { contains: q } } },
                    { reservation: { apartment: { code: { contains: q } } } },
                    { reservation: { opportunity: { lead: { fullName: { contains: q } } } } },
                    ...arContains("fullNameAr", q, qAr).map((f) => ({
                      reservation: { opportunity: { lead: f } },
                    })),
                  ],
                },
              ],
            },
            take: 5,
            // the finance list route's own ordering law, verbatim: dueAt asc
            // then reservation then line — the collections instinct (what is
            // late or imminent first) identical on both surfaces.
            orderBy: [{ dueAt: "asc" }, { reservationId: "asc" }, { seq: "asc" }],
            select: {
              id: true,
              seq: true,
              label: true,
              kind: true,
              status: true,
              amount: true,
              dueAt: true,
              reservation: {
                select: {
                  id: true,
                  contractRef: true,
                  opportunity: { select: { lead: { select: { id: true, fullName: true, fullNameAr: true } } } },
                  apartment: { select: { id: true, code: true } },
                },
              },
            },
          })
        : Promise.resolve([]),
    ]);

    return ok({ leads, opportunities, projects, apartments, developers, contacts, savCases, installments });
  } catch (error) {
    return fail(error);
  }
}
