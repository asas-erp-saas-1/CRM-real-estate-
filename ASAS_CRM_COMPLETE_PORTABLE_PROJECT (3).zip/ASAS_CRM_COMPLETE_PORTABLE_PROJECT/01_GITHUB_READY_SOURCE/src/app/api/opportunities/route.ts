// GET  /api/opportunities — filtered deal list (with lead, owner, project) + stages.
// POST /api/opportunities — create a deal for a lead, logged on the timeline.
//        Terminal-stage discipline (P4): CLOSED_WON/CLOSED_LOST at creation
//        require closedAt (analytics/targets key off it); CLOSED_LOST also
//        requires lostReason (mirrors PATCH); terminal probability is forced
//        (100 won / 0 lost) so weighted/progress semantics stay coherent.
//        PIPE-01 (G3 §3 — the next-action law at birth): an OPEN deal is born
//        with its next activity — nextAction null/empty on a non-terminal
//        stage is a 422 NEXT_ACTION_REQUIRED (zod stays permissive; the
//        handler owns the law with a stable code, mirroring PATCH).
import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import { LOST_REASONS, OPP_CLOSED_STAGES, OPPORTUNITY_STAGES, OPP_STAGE_DEFAULT_PROBABILITY } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { ApiError, fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { refuseBirthClosed } from "@/lib/server/visit-gate";
import { leadScope, oppScope } from "@/lib/server/visibility";
import { findLead } from "@/lib/server/leads"; // G5-P4-2 — the shared scoped-lookup helper
import { optionalId, optionalMoney, parseBody, qp, qpEnum } from "@/lib/server/validation";

const opportunityInclude = {
  lead: { select: { id: true, fullName: true, phone: true, status: true } },
  owner: { select: { id: true, name: true, role: true } },
  project: { select: { id: true, name: true, district: true } },
} as const;

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const params = req.nextUrl.searchParams;

    // Pipeline views rarely paginate — generous default, still bounded.
    const page = parseIntParam(params.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(params.get("pageSize"), 200, { min: 1, max: 500 });

    // D-021 — record visibility: below MANAGER, the deal list is OWN+POOL scoped.
    const conditions: Prisma.OpportunityWhereInput[] = [{ orgId, ...oppScope(user) }];

    const stage = qpEnum(req, "stage", OPPORTUNITY_STAGES);
    if (stage) conditions.push({ stage });

    // D7-R3 — exact-id lookup (audit-view target resolution). Additive and
    // backward-compatible: the condition INTERSECTS the org + D-021 scope
    // above, so an out-of-scope id yields an empty page, never a leak.
    const id = qp(req, "id");
    if (id) conditions.push({ id });

    const ownerId = qp(req, "ownerId");
    if (ownerId) conditions.push({ ownerId });

    // PIPE-03 — the create dialog's duplicate-open-deal warning reads a
    // lead's OPEN deals (leadId + open=true). Same additive, scope-
    // intersecting law as id/ownerId/projectId above: the condition
    // INTERSECTS the org + D-021 scope, so an out-of-scope leadId yields an
    // empty page, never a leak.
    const leadId = qp(req, "leadId");
    if (leadId) conditions.push({ leadId });

    const projectId = qp(req, "projectId");
    if (projectId) conditions.push({ projectId });

    const query = qp(req, "query");
    if (query) {
      conditions.push({
        OR: [{ title: { contains: query } }, { lead: { fullName: { contains: query } } }],
      });
    }

    // open=true → exclude closed deals (handy for kanban).
    if (params.get("open") === "true") {
      conditions.push({ stage: { notIn: [...OPP_CLOSED_STAGES] } }); // R15 — shared set
    }

    const where: Prisma.OpportunityWhereInput =
      conditions.length > 1 ? { AND: conditions } : conditions[0];

    const pipeline = await db.pipeline.findFirst({ where: { orgId, isDefault: true } });
    const [total, opportunities, stages] = await Promise.all([
      db.opportunity.count({ where }),
      db.opportunity.findMany({
        where,
        orderBy: [{ stage: "asc" }, { updatedAt: "desc" }],
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: opportunityInclude,
      }),
      pipeline
        ? db.pipelineStage.findMany({ where: { pipelineId: pipeline.id }, orderBy: { order: "asc" } })
        : Promise.resolve([]),
    ]);

    return ok({ data: opportunities, total, page, pageSize, stages });
  } catch (error) {
    return fail(error);
  }
}

// ── POST ──────────────────────────────────────────────────────────────────────

const createSchema = z.object({
  leadId: z.string().min(1, "leadId requis"),
  title: z.string().trim().min(1, "Titre requis").max(200),
  // W1-2 (Phase 2.1): non-negative money law (was optionalNumber).
  value: optionalMoney,
  projectId: optionalId,
  stage: z.enum(OPPORTUNITY_STAGES).default("NEW"),
  probability: z.coerce.number().int().min(0).max(100).optional(),
  expectedCloseAt: z.coerce.date().nullable().optional(),
  nextAction: z.string().trim().max(200).nullable().optional(),
  nextActionAt: z.coerce.date().nullable().optional(),
  // P4 — terminal-stage creation discipline (historical backfill use case)
  closedAt: z.coerce.date().optional(),
  lostReason: z.string().trim().min(1).max(500).optional(),
  // G3 (§2 taxonomy) — the coded loss motive (preferred); a backfill that
  // carries only the free text is stamped OTHER server-side so every lost
  // row lands analytics-grade.
  lostReasonCode: z.enum(LOST_REASONS).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const body = await parseBody(req, createSchema);

    // D-021 — the referenced lead must be in the caller's scope (404 otherwise).
    const lead = await findLead(orgId, body.leadId, leadScope(user), {
      select: { id: true, ownerId: true, convertedContactId: true, fullName: true },
    }); // G5-P4-2
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    // P4 — terminal-stage creation guard: analytics/targets key off closedAt;
    // a closed deal without a closing date silently drops out of every metric.
    const isTerminal = body.stage === "CLOSED_WON" || body.stage === "CLOSED_LOST";
    if (isTerminal && !body.closedAt) {
      throw new ApiError(
        422,
        "closedAt est requis pour créer directement une opportunité au stade final (CLOSED_WON / CLOSED_LOST)",
        "TERMINAL_STAGE_REQUIRES_CLOSED_AT"
      );
    }
    if (body.stage === "CLOSED_LOST" && !body.lostReasonCode && !body.lostReason?.trim()) {
      throw new ApiError(
        422,
        "Motif de perte (lostReasonCode ou lostReason) requis pour clôturer une opportunité",
        "LOST_REASON_REQUIRED"
      );
    }

    // PIPE-01 (G3 §3 — the next-action law at birth): an OPEN deal is born
    // with its next activity (a deal without one rots — the Pipedrive law;
    // the create dialog's required field is the human-facing twin). Terminal
    // backfills keep the right to create without one (won/lost cards carry
    // facts, not plans — the exact PATCH parity). zod stays permissive (the
    // convert flow seeds its own default); the handler owns the law with a
    // stable code so the client can teach instead of showing a raw zod error.
    if (!isTerminal && (body.nextAction == null || body.nextAction.trim() === "")) {
      throw new ApiError(
        422,
        "Une action suivante est requise pour créer une opportunité ouverte",
        "NEXT_ACTION_REQUIRED"
      );
    }

    // Phase B (D3 / register §1d): the birth-closed hatch is gated — a won
    // deal cannot be BORN won with zero visit (an ungated create-at-CLOSED_WON
    // is exactly the "alternate endpoint" bypass the owner's anti-bypass law
    // prohibits; at creation no visit row can reference the opportunity yet,
    // so the predicate is unsatisfiable by construction → the teaching
    // refusal, never a silent allow). The honest backfill journey: create at
    // a working stage → record the completed visit (+ compte-rendu) → close
    // through the gated paths. CLOSED_LOST creation stays allowed (D2:
    // loss is not progression — the lostReason prerequisite above suffices).
    if (body.stage === "CLOSED_WON") {
      refuseBirthClosed();
    }

    // Terminal probability is a fact, not an estimate. (Phase B: the
    // CLOSED_WON half of this ternary is now provably dead — refuseBirthClosed
    // above returns never, so TS narrows stage to exclude it. A won deal can
    // no longer be born won; only CLOSED_LOST reaches here terminally.)
    // P2.4 (A1-B5): an absent probability now defaults to the ONE canonical
    // stage table (was a silent 0); an explicit body value stays authoritative.
    const probability =
      body.stage === "CLOSED_LOST" ? 0 : (body.probability ?? OPP_STAGE_DEFAULT_PROBABILITY[body.stage]);

    let projectId: string | null = null;
    if (body.projectId) {
      const project = await db.project.findFirst({ where: { id: body.projectId, orgId }, select: { id: true } });
      if (!project) throw new ApiError(404, "Projet introuvable", "PROJECT_NOT_FOUND");
      projectId = project.id;
    }

    // G5-P3-5 (F-06, D-GOV-5): the creation and its Activity/Audit trail
    // commit as ONE transaction — a forced mid-transaction failure rolls back
    // both (no committed deal without its timeline entry, no orphaned audit
    // row without a deal). The §41 fault hook proves the rollback contract.
    const opportunity = await db.$transaction(async (tx) => {
      const row = await tx.opportunity.create({
        data: {
          orgId,
          leadId: lead.id,
          contactId: lead.convertedContactId,
          title: body.title,
          value: body.value ?? null,
          projectId,
          stage: body.stage,
          probability,
          ownerId: lead.ownerId ?? user.id,
          expectedCloseAt: body.expectedCloseAt ?? null,
          nextAction: body.nextAction ?? null,
          nextActionAt: body.nextActionAt ?? null,
          lostReason: body.stage === "CLOSED_LOST" ? (body.lostReason ?? null) : null,
          // G3 (§2) — the coded motive on the birth-lost backfill: the explicit
          // code when carried, else OTHER whenever a free-text detail exists.
          lostReasonCode:
            body.stage === "CLOSED_LOST"
              ? (body.lostReasonCode ?? (body.lostReason ? "OTHER" : null))
              : null,
          closedAt: isTerminal ? body.closedAt! : null,
          // P8-9 (D-UX-018) — aging signal starts at creation.
          stageChangedAt: new Date(),
        },
        include: opportunityInclude,
      });
      injectTxFault(req, "opps-post");

      await logActivity({
        orgId,
        actorId: user.id,
        leadId: lead.id,
        opportunityId: row.id,
        type: "STAGE_CHANGE",
        title: `Opportunité créée — ${row.title}`,
        body: `Entrée dans le pipeline à l'étape ${row.stage}`,
        meta: { opportunityId: row.id, stage: row.stage, value: row.value },
      }, tx);
      // W1-3 (Phase 2.1 — A6#2): opportunity creation now audited.
      await logAudit({
        orgId,
        actor: user,
        action: "OPPORTUNITY_CREATED",
        entity: "OPPORTUNITY",
        entityId: row.id,
        before: null,
        after: { title: row.title, stage: row.stage, value: row.value, leadId: lead.id },
      }, tx);
      return row;
    });

    return ok({ opportunity }, 201);
  } catch (error) {
    return fail(error);
  }
}
