// GET /api/opportunities/:id/gates — G3 (§1 STAGE GATES): the auto-computed
// qualification checklist for one deal. Returns { stage, items } where items
// are the entry gates of the REQUESTED stage (defaults to the deal's current
// stage — the StagePlaybook checklist; `?stage=X` serves the pre-advance
// check the ONE use-stage-move engine runs before a forward move).
// Advisory by design: the server's OPPORTUNITY_TRANSITIONS matrix and the
// visit gate stay the only enforcement — this surface reads facts, it never
// refuses a write. Scoped like every sibling: requireUser + orgId + oppScope.
import type { NextRequest } from "next/server";
import { OPPORTUNITY_STAGES } from "@/lib/constants";
import { db } from "@/lib/db";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { oppScope } from "@/lib/server/visibility";
import { qpEnum } from "@/lib/server/validation";
import { computeStageGates } from "@/lib/server/opportunity-gates";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    // D-021 scoped lookup — the same findFirst shape as [id]/route.ts.
    const opportunity = await db.opportunity.findFirst({
      where: { id, orgId, ...oppScope(user) },
    });
    if (!opportunity) throw new ApiError(404, "Opportunité introuvable", "OPPORTUNITY_NOT_FOUND");

    // The evaluated stage: the caller's ?stage= target (the pre-advance
    // check) or the deal's own position (the cockpit checklist). The
    // predicates never read the stage, so the synthetic copy is safe.
    const stageParam = qpEnum(req, "stage", OPPORTUNITY_STAGES);
    const stage = stageParam ?? (opportunity.stage as (typeof OPPORTUNITY_STAGES)[number]);

    const items = await computeStageGates(db, orgId, {
      id: opportunity.id,
      orgId: opportunity.orgId,
      leadId: opportunity.leadId,
      stage,
      value: opportunity.value,
      expectedCloseAt: opportunity.expectedCloseAt,
      nextAction: opportunity.nextAction,
    });

    return ok({ stage, items });
  } catch (error) {
    return fail(error);
  }
}
