// PATCH  /api/opportunities/:id — stage moves (CLOSED_LOST requires the coded
//        lostReasonCode or the legacy free-text lostReason, closing stamps
//        closedAt, terminal stages force probability 100/0 — P4 + G3 §2)
//        + value/probability/next-action updates + owner reassignment.
//        Every stage change → Activity(STAGE_CHANGE) + AuditLog; a
//        lostReason-only edit on a closed-lost deal → AuditLog (B4 — the
//        recorded loss motive can no longer be rewritten invisibly);
//        a value/probability field-only edit → AuditLog (B4 sibling — the
//        PRICE_CHANGED law on apartments); an ownerId change →
//        Activity(ASSIGNMENT) + AuditLog(OPPORTUNITY_ASSIGNED) (2a — the
//        assignment used to commit with ZERO trail, invisible reattribution).
//        G5-P3-7 (D-GOV-5 §9.1): the OPPORTUNITY_TRANSITIONS adjacency matrix
//        governs every stage move — routine forward moves (any later stage,
//        skip allowed) stay open to in-scope users; backward moves, terminal
//        reopens and any PATCH entry into CLOSED_WON (the material event — the
//        canonical money path is validate_closure) are 422 unless MANAGER+
//        carries a correctionReason (audited as OPPORTUNITY_STAGE_CORRECTED).
//        Reopening a CLOSED_WON backed by a CONVERTED reservation is refused
//        outright (the §9.2 desync law — checked INSIDE the transaction, B3).
//        G5-P3-5 (F-06, same class): the mutation and its trail commit as ONE
//        transaction.
//        PIPE-02 (G3 §1 severity law, server-side): the HARD entry gates are
//        enforced where they were only taught — a routine FORWARD move into
//        RESERVATION requires a LIVE hold on the deal, into CONTRACT the hold
//        PLUS ≥1 installment (computeStageGates is the single source of what
//        HARD means; checked INSIDE the transaction like its W2.3 sibling).
//        PIPE-01 (G3 §3 — the next-action law): a payload that CLEARS the next
//        action on a non-terminal resulting stage is a 422 NEXT_ACTION_REQUIRED
//        (an open deal without a next activity rots — the server now says so).
// DELETE /api/opportunities/:id — only from NEW or CLOSED_LOST (data discipline);
//        blocked when reservations exist (FK-safe cascade for activities/tasks/visits).
//        W2.3 (master audit — DOM-D3): a move into CLOSED_LOST is refused while
//        a LIVE reservation (ACTIVE or CLOSURE_REQUESTED) holds a unit for the
//        deal — cancel/expire the hold first (never a lost card over a
//        RESERVED apartment).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { LOST_REASONS, OPPORTUNITY_STAGES, atLeastRole, canTransitionOpp } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { findClosurePriceSource, alignWonDealValue } from "@/lib/server/financial-semantics";
import { injectTxFault } from "@/lib/server/faults";
import { computeStageGates } from "@/lib/server/opportunity-gates";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { assertClosureVisitGate } from "@/lib/server/visit-gate";
import { oppScope } from "@/lib/server/visibility";
import { optionalMoney, parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const opportunityInclude = {
  lead: { select: { id: true, fullName: true, phone: true, status: true } },
  owner: { select: { id: true, name: true, role: true } },
  project: { select: { id: true, name: true, district: true } },
} as const;

const patchSchema = z.object({
  title: z.string().trim().min(1).max(200).optional(),
  stage: z.enum(OPPORTUNITY_STAGES).optional(),
  // G5-P3-7 — the manager correction escape hatch: mandatory + audited when
  // the requested move is illegal per OPPORTUNITY_TRANSITIONS. On legal moves
  // the field is ignored (routine work needs no reason — the directive).
  correctionReason: z.string().trim().min(1).max(500).optional(),
  // API-03 (platform audit 2026-11-04) — the money law the POST already
  // enforces (optionalMoney: non-negative, ≤ MAX_MONEY_DZD) now holds on
  // PATCH too: a negative deal value is no longer persistable here.
  value: optionalMoney,
  probability: z.coerce.number().int().min(0).max(100).optional(),
  nextAction: z.string().trim().max(200).nullable().optional(),
  nextActionAt: z.coerce.date().nullable().optional(),
  expectedCloseAt: z.coerce.date().nullable().optional(),
  lostReason: z.string().trim().min(1).max(500).nullable().optional(),
  // G3 (§2 taxonomy) — the coded loss motive (preferred); the free text above
  // stays the optional detail. Either one satisfies the CLOSED_LOST contract.
  lostReasonCode: z.enum(LOST_REASONS).nullable().optional(),
  ownerId: z.string().nullable().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    const opportunity = await db.opportunity.findFirst({ where: { id, orgId, ...oppScope(user) } }); // D-021 scoped
    if (!opportunity) throw new ApiError(404, "Opportunité introuvable", "OPPORTUNITY_NOT_FOUND");

    const stageChanged = body.stage !== undefined && body.stage !== opportunity.stage;

    // G5-P3-3 (F-11, D-GOV-5): assignment law — ownerId changes are MANAGER-
    // gated (parity: leads/[id] F-05 + the bulk-assign gate). Routine PATCHes
    // (title/stage/…) stay open to in-scope agents.
    if (body.ownerId !== undefined && body.ownerId !== opportunity.ownerId && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(403, "La réattribution d'une opportunité est une décision managériale", "FORBIDDEN_ROLE");
    }

    // Commercial discipline: losing a deal requires a reason — the CODED
    // motive (G3 §2, preferred) or the legacy free text (back-compat).
    if (
      stageChanged &&
      body.stage === "CLOSED_LOST" &&
      !body.lostReasonCode &&
      !body.lostReason?.trim()
    ) {
      throw new ApiError(422, "Motif de perte (lostReasonCode ou lostReason) requis pour clôturer une opportunité", "LOST_REASON_REQUIRED");
    }

    // PIPE-01 (G3 §3 — the next-action law, server-side): a payload that
    // EXPLICITLY clears the next action (null, or empty after zod's trim)
    // while the deal's RESULTING stage is not terminal is a 422 — an open
    // deal without a next activity rots (the Pipedrive law the board's
    // « Sans action » toggle hunts). Terminal results keep the right to
    // clear (won/lost cards carry facts, not plans). zod stays permissive
    // by design; the HANDLER owns the law with a stable code so the
    // client can teach instead of showing a raw validation error.
    const resultingStage = body.stage ?? opportunity.stage;
    if (
      (body.nextAction === null || body.nextAction === "") &&
      resultingStage !== "CLOSED_WON" &&
      resultingStage !== "CLOSED_LOST"
    ) {
      throw new ApiError(
        422,
        "Une action suivante est requise tant que l'affaire est ouverte",
        "NEXT_ACTION_REQUIRED",
      );
    }

    // 2a — captured for the assignment trail (null = no ownership transfer).
    let newOwnerName: string | null = null;
    const ownerChanged = body.ownerId !== undefined && body.ownerId !== opportunity.ownerId;

    // G5-P3-7 (D-GOV-5 §9.1) — the adjacency guard: illegal edges (backward
    // moves, terminal reopens, PATCH entries into CLOSED_WON) are manager
    // corrections — authority, then the reason; the §9.2 desync law itself
    // now runs INSIDE the mutation transaction (B3 — see the guard next to
    // the W2.3 live-hold check below).
    let correction = false;
    // (inline `body.stage !== undefined` — narrows the zod optional for the
    // matrix call; `stageChanged` alone does not carry the narrowing)
    if (stageChanged && body.stage !== undefined && !canTransitionOpp(opportunity.stage, body.stage)) {
      if (!atLeastRole(user.role, "MANAGER")) {
        throw new ApiError(
          422,
          `Déplacement illégal : ${opportunity.stage} → ${body.stage}. Seul un manager peut corriger (motif obligatoire).`,
          "OPPORTUNITY_ILLEGAL_TRANSITION"
        );
      }
      if (!body.correctionReason?.trim()) {
        throw new ApiError(
          422,
          "Motif de correction (correctionReason) requis pour forcer un déplacement illégal",
          "CORRECTION_REASON_REQUIRED"
        );
      }
      correction = true;
    }

    if (body.ownerId !== undefined && body.ownerId !== opportunity.ownerId && body.ownerId !== null) {
      // 2a — resolve the target's NAME too: the assignment trail titles it
      // (the leads route's cascade pattern — `Lead assigné à ${name}`).
      const owner = await db.user.findFirst({
        where: { id: body.ownerId, orgId },
        select: { id: true, name: true },
      });
      if (!owner) throw new ApiError(422, "Propriétaire (ownerId) introuvable", "OWNER_NOT_FOUND");
      newOwnerName = owner.name;
    }

    const data: Record<string, unknown> = {};
    if (body.title !== undefined) data.title = body.title;
    if (body.stage !== undefined) data.stage = body.stage;
    if (body.value !== undefined) data.value = body.value;
    if (body.probability !== undefined) data.probability = body.probability;
    if (body.nextAction !== undefined) data.nextAction = body.nextAction;
    if (body.nextActionAt !== undefined) data.nextActionAt = body.nextActionAt;
    if (body.expectedCloseAt !== undefined) data.expectedCloseAt = body.expectedCloseAt;
    if (body.lostReason !== undefined) data.lostReason = body.lostReason;
    if (body.lostReasonCode !== undefined) data.lostReasonCode = body.lostReasonCode;
    if (body.ownerId !== undefined) data.ownerId = body.ownerId;

    if (stageChanged) {
      // P8-9 (D-UX-018) — stage moves stamp the aging signal (days-in-stage
      // on kanban cards; exactness starts here — the migration backfilled
      // history from updatedAt).
      data.stageChangedAt = new Date();
      if (body.stage === "CLOSED_WON" || body.stage === "CLOSED_LOST") {
        data.closedAt = new Date();
        // P4 — terminal probability is a fact, not an estimate: won → 100,
        // lost → 0 (overrides any body.probability on the closing transition).
        data.probability = body.stage === "CLOSED_WON" ? 100 : 0;
      } else {
        // Reopening a closed deal clears the closing stamp — and BOTH loss
        // fields (the G3 §2 mirror of the lostReason clearing law).
        data.closedAt = null;
        if (body.lostReason === undefined) data.lostReason = null;
        if (body.lostReasonCode === undefined) data.lostReasonCode = null;
      }
    }

    // G5-P3-5 (F-06, same class — folded while landing G5-P3-7 in this
    // file): the mutation and its Activity/Audit trail commit as ONE
    // transaction; the fault-injection hook lets the §42 matrix prove the
    // rollback contract on the correction path too.
    const updated = await db.$transaction(async (tx) => {
      // Phase B (D3 / register §1c RQ-2): PATCH entry into CLOSED_WON (manager
      // correction — the only PATCH route into the won state) runs the SAME
      // visit/report gate as validate_closure, inside this transaction,
      // BEFORE the stage write. GATE-Q2: corrections get NO bypass — a
      // manager forcing the move without a qualifying visit fails like any
      // other attempt. CLOSED_LOST never enters this branch (D2 exemption:
      // loss is not progression — the lostReason prerequisite above is the
      // whole discipline for lost deals).
      if (stageChanged && body.stage === "CLOSED_WON") {
        await assertClosureVisitGate(tx, opportunity);
        // W2-A2 (P1 — DOM-03): the manager correction path into CLOSED_WON
        // applies the SAME value-alignment law as the canonical money path
        // (validate_closure → financial-semantics.alignWonDealValue): the
        // won card's pipeline value becomes the sale-backing reservation's
        // agreed price when one exists (CONVERTED first, else a live hold).
        // An explicit `value` in the SAME request wins — the manager typed
        // that number deliberately, and the alignment is skipped for it.
        // No-op when the amounts already agree or no price source exists.
        if (body.value === undefined) {
          const source = await findClosurePriceSource(tx, orgId, opportunity.id);
          if (source) {
            await alignWonDealValue(tx, {
              orgId,
              actor: user,
              opportunityId: opportunity.id,
              leadId: opportunity.leadId,
              agreed: source.amount,
              reservationId: source.reservationId,
              reason: "Correction vers Gagné — le prix convenu devient la valeur du deal gagné",
            });
          }
        }
      }
      // §9.2 desync law — a CLOSED_WON backed by a CONVERTED reservation is
      // the money path's record: reopening it here would desync the
      // reservation/apartment/sale triad. The correction must go through the
      // reservation lifecycle (a dedicated future flow), never this PATCH.
      // B3 (TOCTOU closure): this CONVERTED-count read now runs INSIDE the
      // mutation transaction — same law as the W2.3 live-hold guard below (a
      // reservation validated as CONVERTED between an outside check and the
      // stage write can no longer slip through the window). Fires only for
      // manager-correction moves whose origin is CLOSED_WON: every stage
      // change out of terminal CLOSED_WON is correction-class, and
      // `correction` is set on exactly those (post role + reason gates). The
      // one deliberate precedence shift: a reason-less correction attempt now
      // fails on CORRECTION_REASON_REQUIRED before this count runs — both
      // 422s, the doomed request class is unchanged.
      if (correction && opportunity.stage === "CLOSED_WON") {
        const backed = await tx.reservation.count({
          where: { opportunityId: opportunity.id, status: "CONVERTED" },
        });
        if (backed > 0) {
          throw new ApiError(
            422,
            "Opportunité adossée à une vente validée (réservation CONVERTED) — la réouverture passe par le cycle de vie de la réservation",
            "OPPORTUNITY_BACKED_BY_SALE"
          );
        }
      }
      // W2.3 (master audit — DOM-D3) — lost-deal guard, checked inside the
      // mutation transaction (no TOCTOU): the deal still holds a live unit
      // (ACTIVE or CLOSURE_REQUESTED reservation). Closing it as lost here
      // would desync the pipeline from the inventory (a CLOSED_LOST card with
      // a RESERVED apartment) — the reservation must be cancelled or left to
      // expire FIRST. Applies to routine moves and manager corrections alike:
      // the reservation lifecycle is the only release path.
      if (stageChanged && body.stage === "CLOSED_LOST") {
        const liveHold = await tx.reservation.findFirst({
          where: { opportunityId: opportunity.id, status: { in: ["ACTIVE", "CLOSURE_REQUESTED"] } },
          select: { id: true },
        });
        if (liveHold) {
          throw new ApiError(
            422,
            "Impossible de clôturer en perdu : une réservation en cours (ACTIVE ou clôture demandée) détient une unité pour cette opportunité — annulez ou laissez expirer la réservation d'abord.",
            "ACTIVE_RESERVATION_EXISTS",
            { reservationId: liveHold.id }
          );
        }
      }
      // PIPE-02 (P1 — G3 §1 severity law, server-side HARD gates): the
      // money-path entry gates are now enforced where they were only
      // taught. A routine FORWARD move into RESERVATION requires a LIVE
      // hold on THIS deal (ACTIVE or CLOSURE_REQUESTED — the W2.3 set; a
      // card in the Réservation column without a hold is a fake
      // pipeline), and into CONTRACT the same hold PLUS ≥1 installment
      // row on it (money already on the table — the échéancier). The
      // predicates come from computeStageGates — the SINGLE source of
      // what HARD means (GATE_SEVERITY) — run with the in-tx client so
      // the teaching UI (gates route + GateDialog) and this refusal can
      // never drift. Checked INSIDE the transaction (no TOCTOU), before
      // the stage write. Correction-class moves follow the engine's
      // direction semantics: gates guard FORWARD entry (routine legal
      // edges); a MANAGER's audited correction (backward moves, terminal
      // reopens — the `correction` flag above) keeps the documented
      // escape hatch, the same override the severity law grants on the
      // client. GATE-Q2 sibling: no bypass for anyone on a routine move.
      if (stageChanged && !correction && (body.stage === "RESERVATION" || body.stage === "CONTRACT")) {
        const gates = await computeStageGates(tx, orgId, {
          id: opportunity.id,
          orgId: opportunity.orgId,
          leadId: opportunity.leadId,
          stage: body.stage,
          // Shape parity with the gates route; the money-path predicates
          // (liveReservation/deposit) never read these three, and a
          // stage-move PATCH does not change them in the same request.
          value: opportunity.value,
          expectedCloseAt: opportunity.expectedCloseAt,
          nextAction: opportunity.nextAction,
        });
        const missing = gates.find((g) => g.severity === "hard" && !g.done);
        if (missing?.id === "liveReservation") {
          throw new ApiError(
            422,
            "Une réservation en cours (ACTIVE ou clôture demandée) est requise pour entrer dans l'étape Réservation",
            "GATE_RESERVATION_REQUIRED"
          );
        }
        if (missing?.id === "deposit") {
          throw new ApiError(
            422,
            "Au moins une échéance doit être enregistrée sur la réservation en cours pour entrer dans l'étape Contrat",
            "GATE_DEPOSIT_REQUIRED"
          );
        }
      }
      const row = await tx.opportunity.update({
        where: { id: opportunity.id },
        data,
        include: opportunityInclude,
      });
      injectTxFault(req, "opps-patch");

      if (stageChanged) {
        if (correction) {
          // The manager escape hatch — the reason rides BOTH the timeline
          // entry and the dedicated audit action (never the routine rows).
          await logActivity({
            orgId,
            actorId: user.id,
            leadId: opportunity.leadId,
            opportunityId: opportunity.id,
            type: "STAGE_CHANGE",
            title: `Étape corrigée : ${opportunity.stage} → ${row.stage}`,
            body: body.correctionReason ?? null,
            meta: { before: opportunity.stage, after: row.stage, title: opportunity.title, corrected: true, reason: body.correctionReason },
          }, tx);
          await logAudit({
            orgId,
            actor: user,
            action: "OPPORTUNITY_STAGE_CORRECTED",
            entity: "OPPORTUNITY",
            entityId: opportunity.id,
            before: { stage: opportunity.stage },
            after: { stage: row.stage, correctionReason: body.correctionReason, closedAt: row.closedAt },
          }, tx);
        } else {
          await logActivity({
            orgId,
            actorId: user.id,
            leadId: opportunity.leadId,
            opportunityId: opportunity.id,
            type: "STAGE_CHANGE",
            title: `Étape : ${opportunity.stage} → ${row.stage}`,
            body: (row.lostReason ?? undefined) ?? null,
            meta: { before: opportunity.stage, after: row.stage, title: opportunity.title },
          }, tx);
          await logAudit({
            orgId,
            actor: user,
            action: "OPPORTUNITY_STAGE_CHANGED",
            entity: "OPPORTUNITY",
            entityId: opportunity.id,
            before: { stage: opportunity.stage },
            after: { stage: row.stage, value: row.value, closedAt: row.closedAt },
          }, tx);
        }
      }

      // B4 (audit-trail completeness): a lostReason-only edit on an existing
      // CLOSED_LOST deal used to commit with ZERO trail — the route's
      // Activity/Audit rows fired only on stageChanged, so the recorded loss
      // motive could be rewritten invisibly. Field-only edits carry an audit
      // row (the PRICE_CHANGED law on apartments — see the 2b block below for
      // value/probability): the timeline vocabulary has no honest ActivityType
      // for a non-stage field edit, so the governance record rides the audit
      // trail alone — written in the SAME transaction as the mutation (F-06),
      // before/after values preserved the way every other audit entry in this
      // route does. G3 (§2): the coded motive rides the same guard.
      if (
        !stageChanged &&
        ((body.lostReason !== undefined && body.lostReason !== opportunity.lostReason) ||
          (body.lostReasonCode !== undefined && body.lostReasonCode !== opportunity.lostReasonCode))
      ) {
        await logAudit({
          orgId,
          actor: user,
          action: "OPPORTUNITY_LOST_REASON_EDITED",
          entity: "OPPORTUNITY",
          entityId: opportunity.id,
          before: { lostReason: opportunity.lostReason, lostReasonCode: opportunity.lostReasonCode },
          after: { lostReason: row.lostReason, lostReasonCode: row.lostReasonCode },
        }, tx);
      }

      // 2b (G2 audit) — the PRICE_CHANGED law on apartments, for deals: a
      // value/probability FIELD-ONLY edit (no stage move) used to commit with
      // ZERO trail, so the deal's economics could be rewritten invisibly —
      // exactly the class B4 closed for lostReason. AuditLog only (no Activity
      // row: the timeline vocabulary has no honest type for a field edit, and
      // the B4 precedent keeps governance records on the audit trail alone),
      // before/after payloads on the apartment PRICE_CHANGED shape. No-op
      // edits (same value re-sent) stay silent — no audit noise.
      if (!stageChanged) {
        const valueChanged = body.value !== undefined && body.value !== opportunity.value;
        const probabilityChanged =
          body.probability !== undefined && body.probability !== opportunity.probability;
        if (valueChanged || probabilityChanged) {
          await logAudit({
            orgId,
            actor: user,
            action: "OPPORTUNITY_VALUE_CHANGED",
            entity: "OPPORTUNITY",
            entityId: opportunity.id,
            before: { value: opportunity.value, probability: opportunity.probability },
            after: { value: row.value, probability: row.probability },
          }, tx);
        }
      }

      // 2a (G2 audit) — an ownerId change used to commit with ZERO trail: an
      // in-scope MANAGER could reattribute a deal with no Activity, no AuditLog
      // — invisible reattribution (the single PATCH on leads writes both; the
      // opportunity route wrote neither). ASSIGNMENT is the exact activity
      // vocabulary the leads route uses for ownership transfers — same type
      // string, same trail shape, inside the SAME transaction (F-06).
      if (ownerChanged) {
        await logActivity({
          orgId,
          actorId: user.id,
          leadId: opportunity.leadId,
          opportunityId: opportunity.id,
          type: "ASSIGNMENT",
          title: newOwnerName ? `Opportunité assignée à ${newOwnerName}` : "Opportunité désassignée",
          meta: { before: opportunity.ownerId, after: row.ownerId },
        }, tx);
        await logAudit({
          orgId,
          actor: user,
          action: "OPPORTUNITY_ASSIGNED",
          entity: "OPPORTUNITY",
          entityId: opportunity.id,
          before: { ownerId: opportunity.ownerId },
          after: { ownerId: row.ownerId },
        }, tx);
      }
      return row;
    });

    return ok({ opportunity: updated });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    const opportunity = await db.opportunity.findFirst({ where: { id, orgId, ...oppScope(user) } }); // D-021 scoped
    if (!opportunity) throw new ApiError(404, "Opportunité introuvable", "OPPORTUNITY_NOT_FOUND");

    // G5-P3-3 (F-11, D-GOV-5): the owner|MANAGER inner gate its siblings have
    // (tasks/[id]:95, activities/[id]:35, visits/[id]:460) — scope alone let
    // any agent delete an in-scope pool opportunity.
    if (opportunity.ownerId !== user.id && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(403, "Seul le propriétaire de l'opportunité ou un manager peut la supprimer", "FORBIDDEN_ROLE");
    }

    if (opportunity.stage !== "NEW" && opportunity.stage !== "CLOSED_LOST") {
      throw new ApiError(
        422,
        "Suppression autorisée uniquement aux étapes NEW ou CLOSED_LOST",
        "OPPORTUNITY_NOT_DELETABLE"
      );
    }

    // Reservation.opportunityId is a required FK — refuse instead of failing.
    const reservationCount = await db.reservation.count({ where: { opportunityId: opportunity.id } });
    if (reservationCount > 0) {
      throw new ApiError(422, "Impossible de supprimer : réservations rattachées", "HAS_RESERVATIONS");
    }

    // W2-2 (Phase 2.1 — A2#4): Document's polymorphic (entityType, entityId)
    // link carries NO FK — deleting the opportunity used to orphan its
    // documents silently. The guarded delete now re-points them to the parent
    // LEAD (history preserved on the customer's dossier) or deletes them when
    // no lead exists — both audited. One transaction: opportunity + documents
    // + trail commit together or not at all.
    const orphanDocs = await db.document.findMany({
      where: { entityType: "OPPORTUNITY", entityId: opportunity.id, orgId },
      select: { id: true, title: true },
    });
    let docsRepointed = 0;
    let docsDeleted = 0;
    await db.$transaction(async (tx) => {
      if (orphanDocs.length > 0) {
        if (opportunity.leadId) {
          const res = await tx.document.updateMany({
            where: { entityType: "OPPORTUNITY", entityId: opportunity.id, orgId },
            data: { entityType: "LEAD", entityId: opportunity.leadId },
          });
          docsRepointed = res.count;
        } else {
          const res = await tx.document.deleteMany({
            where: { entityType: "OPPORTUNITY", entityId: opportunity.id, orgId },
          });
          docsDeleted = res.count;
        }
      }
      // Activities / tasks / visits reference the opportunity through optional FKs
      // (SetNull) — they survive the delete with the link cleared.
      await tx.opportunity.delete({ where: { id: opportunity.id } });

      await logAudit({
        orgId,
        actor: user,
        action: "OPPORTUNITY_DELETED",
        entity: "OPPORTUNITY",
        entityId: opportunity.id,
        before: { title: opportunity.title, stage: opportunity.stage, value: opportunity.value },
        after: { documentsRepointedToLead: docsRepointed, documentsDeleted: docsDeleted },
      }, tx);
    });

    return ok({ deleted: true, id: opportunity.id });
  } catch (error) {
    return fail(error);
  }
}
