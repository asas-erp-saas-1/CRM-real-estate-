// GET /api/matching/compare?ids=a,b,c — Phase 10 (A3): the side-by-side unit
// comparison payload (≤ 4 units). Org-scoped, availability + freshness
// disclosed per unit; unavailable units stay comparable (the comparison is
// inventory data, not a matching claim — the badge carries the truth).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { atLeastRole } from "@/lib/constants";
import { classifyFreshness, getFreshnessPolicy } from "@/lib/server/inventory-events";
import { fail, ok } from "@/lib/server/session";
import { requireUser } from "@/lib/server/session";

const MAX_COMPARE = 4;

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;

    const idsParam = req.nextUrl.searchParams.get("ids") ?? "";
    const ids = idsParam
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, MAX_COMPARE);
    if (ids.length < 2) {
      return ok({ units: [], compared: 0, hint: "ids=a,b[,c[,d]] — 2 à 4 lots" });
    }

    const [policy, apartments] = await Promise.all([
      getFreshnessPolicy(orgId),
      db.apartment.findMany({
        where: {
          orgId,
          id: { in: ids },
          // R2 — the catalog boundary: floor roles compare APPROVED inventory
          // only (MANAGER+ keeps the operational full view — e.g. reviewing a
          // DRAFT against a published reference before approving it).
          ...(atLeastRole(user.role, "MANAGER") ? {} : { recordStatus: "APPROVED" }),
        },
        select: {
          id: true,
          code: true,
          unitType: true,
          status: true,
          price: true,
          parkingPrice: true,
          surface: true,
          totalSurface: true,
          rooms: true,
          bedrooms: true,
          bathrooms: true,
          floorNumber: true,
          orientation: true,
          view: true,
          finishing: true,
          deliveryStatus: true,
          parking: true,
          paymentPlan: true,
          availabilityVerifiedAt: true,
          priceUpdatedAt: true,
          building: {
            select: { name: true, project: { select: { id: true, name: true, city: true, district: true, status: true, deliveryDate: true, developer: { select: { name: true } } } } },
          },
        },
      }),
    ]);

    // Preserve the caller's id order (the comparison column order).
    const byId = new Map(apartments.map((a) => [a.id, a]));
    const units = ids
      .map((id) => byId.get(id))
      .filter((a): a is NonNullable<typeof a> => a != null)
      .map((a) => ({
        ...a,
        freshness: classifyFreshness(a.availabilityVerifiedAt, policy),
      }));

    return ok({ units, compared: units.length });
  } catch (error) {
    return fail(error);
  }
}
