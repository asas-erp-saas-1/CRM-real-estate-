// POST /api/matching/opportunities/:id/match — Phase 10 (A3): run the
// deterministic matching IN THE OPPORTUNITY CONTEXT (Journey C): the deal's
// lead carries the structured requirement; the engine recomputes the ranked
// candidates against AVAILABLE inventory and returns the matches with their
// explanations + freshness. Scope: oppScope (the D-021 law).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { computeLeadMatches } from "@/lib/server/matching";
import { oppScope } from "@/lib/server/visibility";
import { findRequirement, listMatches } from "@/lib/server/matches";
import { classifyFreshness, getFreshnessPolicy } from "@/lib/server/inventory-events";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    // D-021 scoped lookup — the deal must be visible to the caller.
    const opportunity = await db.opportunity.findFirst({
      where: { id, orgId, ...oppScope(user) },
      select: { id: true, leadId: true, title: true, stage: true },
    });
    if (!opportunity) throw new ApiError(404, "Opportunité introuvable", "OPPORTUNITY_NOT_FOUND");

    const requirement = await findRequirement(opportunity.leadId);
    if (!requirement) {
      throw new ApiError(
        422,
        "Aucun critère défini pour le client de ce deal. Renseignez d'abord ses besoins (budget, localisation, type, surface…) avant de lancer le matching.",
        "NO_REQUIREMENT",
      );
    }

    // The engine (the SAME deterministic core the lead surface rides — no
    // duplicate implementation, §14 law) + the trail in-tx.
    const results = await computeLeadMatches(orgId, opportunity.leadId, { actor: user });
    const matches = await listMatches(requirement.id);

    // The freshness disclosure per matched unit (A2/A3 law — a stale unit
    // never hides behind a confident score).
    const policy = await getFreshnessPolicy(orgId);
    const matchesWithFreshness = matches.map((m) => ({
      ...m,
      freshness: classifyFreshness(m.apartment?.availabilityVerifiedAt ?? null, policy),
    }));

    return ok({ matches: matchesWithFreshness, computed: results.length });
  } catch (error) {
    return fail(error);
  }
}
