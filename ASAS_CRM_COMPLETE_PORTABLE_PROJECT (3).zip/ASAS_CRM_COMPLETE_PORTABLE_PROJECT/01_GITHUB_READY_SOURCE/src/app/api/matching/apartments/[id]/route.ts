// GET /api/matching/apartments/:id — REVERSE matching (P24, D-032): given an
// apartment (any status — the inquiry is honest at every lifecycle state:
// activate demand on AVAILABLE, watch the fall-through on RESERVED/OPTIONED),
// rank the org's waiting demand: every lead requirement VISIBLE to the caller
// (leadScope — the D-021 law: below MANAGER an agent sees own+pool demand
// only, a field rep sees leads that visited her assigned projects) in a live
// stage (CLOSED_LOST excluded — dead demand is noise; every other stage,
// CONVERTED included, may still act on an alternative lot) scored by the SAME
// deterministic engine + org-tuned weights as the forward path (§15). Score
// floor 50 = the established fit-tier boundary (≥80 emerald, 50–79 primary —
// below is scan noise). Top 20, score desc. READ-ONLY: nothing is persisted,
// no Activity/Audit row (reads never write — the D-031 convention). Derived
// live — never a second source of truth beside PropertyMatch.
import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { scoreMatch } from "@/lib/server/matching";
import { getMatchWeights } from "@/lib/server/settings";
import { leadScope } from "@/lib/server/visibility";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

/** Minimum score to surface (the fit-tier boundary: 50–79 primary, ≥80 emerald). */
const MATCH_FLOOR = 50;
/** Same density cap as the forward path (top 20 persisted matches). */
const MATCH_CAP = 20;
/** Bounded demand scan — mirrors the forward engine's inventory bound. */
const REQUIREMENT_SCAN_CAP = 500;

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    const apartment = await db.apartment.findFirst({
      where: { id, orgId },
      include: { building: { include: { project: true } } },
    });
    if (!apartment) throw new ApiError(404, "Appartement introuvable", "APARTMENT_NOT_FOUND");

    // Demand visibility rides the lead law (D-021): scope ∧ live stage.
    const stageFilter: Prisma.LeadWhereInput = { status: { not: "CLOSED_LOST" } };
    const scope = leadScope(user);
    const leadWhere: Prisma.LeadWhereInput = scope ? { AND: [scope, stageFilter] } : stageFilter;

    const [requirements, weights] = await Promise.all([
      db.requirement.findMany({
        where: { orgId, lead: leadWhere },
        include: { lead: { include: { owner: { select: { name: true } } } } },
        // 5b (G2 audit) — deterministic truncation: the 500-row demand cap
        // without a total order cut at SQLite's whim, so two consecutive
        // calls over an oversized demand book could rank DIFFERENT lead
        // subsets. createdAt asc + id keeps the cut stable (oldest demand
        // first — insertion order — with id as the total-order tiebreaker).
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
        take: REQUIREMENT_SCAN_CAP,
      }),
      getMatchWeights(orgId),
    ]);

    const matches = requirements
      .map((req) => {
        const { apartmentId: _aptId, ...result } = scoreMatch(req, apartment, weights);
        return {
          leadId: req.lead.id,
          fullName: req.lead.fullName,
          stage: req.lead.status,
          phone: req.lead.phone,
          ownerName: req.lead.owner?.name ?? null,
          budgetMin: req.budgetMin ?? null,
          budgetMax: req.budgetMax ?? null,
          score: result.score,
          reasons: result.reasons,
        };
      })
      .filter((m) => m.score >= MATCH_FLOOR)
      .sort((a, b) => b.score - a.score)
      .slice(0, MATCH_CAP);

    return ok({
      apartment: { id: apartment.id, code: apartment.code ?? null, status: apartment.status },
      total: matches.length,
      matches,
    });
  } catch (error) {
    return fail(error);
  }
}
