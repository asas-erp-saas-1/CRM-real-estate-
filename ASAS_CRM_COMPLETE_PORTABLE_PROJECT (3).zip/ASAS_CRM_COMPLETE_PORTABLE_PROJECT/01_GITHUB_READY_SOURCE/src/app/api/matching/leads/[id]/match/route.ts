// POST /api/matching/leads/:id/match — recompute the weighted matching
// (budget 35 / location 25 / surface 15 / type 15 / parking 10) against
// AVAILABLE inventory only, upsert the top 20 PropertyMatch rows, and log the
// recomputation on the lead timeline (F-06: trail rows join the SAME
// transaction as the match writes — see computeLeadMatches). 422
// NO_REQUIREMENT when the lead has no structured requirement yet.
import type { NextRequest } from "next/server";
import { computeLeadMatches } from "@/lib/server/matching";
import { findLead } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { findRequirement, listMatches } from "@/lib/server/matches";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    const requirement = await findRequirement(lead.id);
    if (!requirement) {
      throw new ApiError(
        422,
        "Aucun critère défini pour ce lead. Renseignez d'abord ses besoins (budget, localisation, type, surface…) via POST /api/leads/:id/requirements avant de lancer le matching.",
        "NO_REQUIREMENT"
      );
    }

    // 1e (G2 audit, F-06): the trail (MATCH Activity + LEAD_MATCH_RECOMPUTED
    // audit) is written INSIDE computeLeadMatches' persistence transaction —
    // the top-20 replacement and its trail commit together or not at all
    // (previously three separate writes: matches tx, then activity, then
    // audit — a crash between them orphaned one side).
    const results = await computeLeadMatches(orgId, lead.id, { actor: user });
    const matches = await listMatches(requirement.id);

    return ok({ matches, computed: results.length });
  } catch (error) {
    return fail(error);
  }
}
