// POST /api/matching/leads/:id/present — mark a suggested match as PRESENTED
// and log "Bien présenté" on the lead timeline.
// 3d (G2 audit): PRESENTED is a transition, not a blind overwrite — a match
// already ACCEPTED or REJECTED is a final customer verdict that a re-present
// call must never regress (409 MATCH_STATUS_FINAL). SUGGESTED → PRESENTED and
// the idempotent PRESENTED → PRESENTED (re-presenting the same listing) stay
// legal.
// 1f (G2 audit, F-06): the status write and its Activity/Audit trail commit
// as ONE transaction — a crash between them can no longer leave a PRESENTED
// match with no timeline entry (or an orphaned audit row).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { findLead } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { findRequirement, matchInclude, parseReasons } from "@/lib/server/matches";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  apartmentId: z.string().min(1, "apartmentId requis"),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, schema);

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    const requirement = await findRequirement(lead.id);
    if (!requirement) {
      throw new ApiError(422, "Aucun critère défini pour ce lead", "NO_REQUIREMENT");
    }

    const match = await db.propertyMatch.findUnique({
      where: { requirementId_apartmentId: { requirementId: requirement.id, apartmentId: body.apartmentId } },
    });
    if (!match) {
      throw new ApiError(
        404,
        "Match introuvable — lancez d'abord POST /api/matching/leads/:id/match",
        "MATCH_NOT_FOUND"
      );
    }

    // 3d — forward-only presentation: ACCEPTED/REJECTED are customer
    // verdicts; a stale re-present call regressing them to PRESENTED would
    // falsify the matching history (dead vocabulary today — the guard keeps
    // it honest the day the acceptance flow lands).
    if (match.status !== "SUGGESTED" && match.status !== "PRESENTED") {
      throw new ApiError(
        409,
        `Match déjà à l'état ${match.status} — la présentation ne peut plus être modifiée`,
        "MATCH_STATUS_FINAL",
        { matchId: match.id, status: match.status }
      );
    }

    const updated = await db.$transaction(async (tx) => {
      const row = await tx.propertyMatch.update({
        where: { id: match.id },
        data: { status: "PRESENTED" },
        include: matchInclude,
      });
      injectTxFault(req, "match-present");

      await logActivity({
        orgId,
        actorId: user.id,
        leadId: lead.id,
        type: "MATCH",
        title: "Bien présenté",
        body: row.apartment.code,
        meta: { apartmentId: body.apartmentId, code: row.apartment.code, score: row.score },
      }, tx);
      // W1-3 (Phase 2.1 — A6#2): presentation now audited.
      await logAudit({
        orgId,
        actor: user,
        action: "MATCH_PRESENTED",
        entity: "LEAD",
        entityId: lead.id,
        before: { matchId: match.id, status: match.status },
        after: { matchId: row.id, status: row.status, apartmentId: body.apartmentId },
      }, tx);
      return row;
    });

    return ok({ match: { ...updated, reasons: parseReasons(updated.reasons) } });
  } catch (error) {
    return fail(error);
  }
}
