// GET /api/matching/leads/:id — persisted matches for the lead's requirement
// (score desc, reasons parsed). Read-only: no computation happens here.
import type { NextRequest } from "next/server";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { findLead } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { findRequirement, listMatches } from "@/lib/server/matches";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    const requirement = await findRequirement(lead.id);
    const matches = requirement ? await listMatches(requirement.id) : [];

    return ok({ requirement: requirement ?? null, matches });
  } catch (error) {
    return fail(error);
  }
}
