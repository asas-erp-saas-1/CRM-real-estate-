// /api/users — team directory (R8-2 evolution of the P1 switcher endpoint).
//
// GET  — users of the org, sorted by role rank (OWNER > ADMIN > …) then name.
//        Default: active users only (sidebar switcher / assignment targets —
//        unchanged contract). `?includeInactive=1` returns EVERY user with the
//        `active` flag (team management table in Settings → Équipe).
// POST — OWNER/ADMIN only: create a member (name/email/role), unique email
//        (409 USER_EMAIL_TAKEN). Phase 8 (A1) adds TWO provisioning modes:
//        · "temp"   (default, historical): a readable temp password is
//          generated, scrypt-hashed and returned ONCE — the shared-secret
//          handoff (kept for operators who prefer it);
//        · "invite" (Phase 8): the account is created WITHOUT a password
//          (passwordHash null) and a single-use INVITE token (72h, hashed at
//          rest) is returned ONCE — the employee redeems it at
//          /api/auth/redeem-token to set their OWN password. This is the
//          mandate's first-login invitation flow (no shared permanent
//          temporary password). Audited USER_CREATED + USER_INVITED in the
//          SAME transaction (API-06/F-06 law).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { ROLES, ROLE_RANK, atLeastRole, type Role } from "@/lib/constants";
import { can } from "@/lib/permissions";
import { db } from "@/lib/db";
import { generateTempPassword, hashPassword } from "@/lib/server/auth";
import { mintAuthToken } from "@/lib/server/auth-tokens";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { isPrismaKnownError, parseBody, qpBool } from "@/lib/server/validation";

function roleRank(role: string): number {
  return ROLE_RANK[role as Role] ?? 0;
}

export async function GET(req: NextRequest) {
  try {
    const user = await requirePermission("users.view");
    const includeInactive = qpBool(req, "includeInactive");
    const users = await db.user.findMany({
      where: { orgId: user.orgId, ...(includeInactive ? {} : { active: true }) },
      // Phase 8 (A3): hasPassword drives the management table's "pending
      // activation" state (invite-mode accounts carry passwordHash null
      // until the employee redeems their invitation token).
      select: { id: true, name: true, email: true, role: true, active: true, passwordHash: true },
    });
    users.sort((a, b) => roleRank(b.role) - roleRank(a.role) || a.name.localeCompare(b.name, "fr"));
    // G5-P3-4 (F-14, D-GOV-5): data minimization — emails are PII and the
    // roster below MANAGER is names+roles (the visibility-matrix contract;
    // B-6 runtime-confirmed any-member exposure). MANAGER+ keeps email: the
    // Settings → Équipe management table displays it (team-table.tsx:123).
    // No consumer below MANAGER reads email (dialogs/filters/switcher use
    // name+role only — the census this fix ran on).
    const roster = atLeastRole(user.role, "MANAGER")
      ? users.map(({ passwordHash, ...rest }) => ({ ...rest, pendingActivation: passwordHash === null }))
      : users.map(({ email: _email, passwordHash: _ph, ...rest }) => rest);
    return ok({ data: roster });
  } catch (error) {
    return fail(error);
  }
}

// ── POST — create a member (OWNER/ADMIN via users.manage) ───────────────────

const createSchema = z.object({
  name: z.string().trim().min(2, "Nom trop court").max(120, "Nom trop long"),
  email: z.email("Adresse email invalide"),
  role: z.enum(ROLES),
  // Phase 8 (A1): "temp" (historical shared-secret) | "invite" (employee
  // sets their own password via single-use token). Default "temp" keeps
  // every existing client/test contract byte-identical.
  mode: z.enum(["temp", "invite"]).default("temp"),
});

export async function POST(req: NextRequest) {
  try {
    // Phase 8 (A2): the named permission (catalog: users.manage → ADMIN+);
    // the 403 envelope stays byte-compatible with the old rank floor.
    const actor = await requirePermission("users.manage");
    const body = await parseBody(req, createSchema);
    const email = body.email.trim().toLowerCase();

    // P2-R1 FIX 3 (F-07): rank ceiling — OWNER-rank accounts are created by
    // the OWNER only. An ADMIN minting an OWNER (temp password or invite
    // token returned in the 201!) is a self-escalation vector.
    if (actor.role === "ADMIN" && body.role === "OWNER") {
      throw new ApiError(403, "Seul un OWNER peut créer un compte OWNER.", "ROLE_CEILING");
    }
    // Phase 8 integrity guard: the catalog and the ceiling must agree —
    // users.manage without users.invite would be a template drift.
    if (!can(actor.role, "users.invite")) {
      throw new ApiError(403, "Invitation non autorisée.", "FORBIDDEN_ROLE");
    }

    const existing = await db.user.findUnique({ where: { email }, select: { id: true } });
    if (existing) {
      throw new ApiError(409, "Cette adresse email est déjà utilisée", "USER_EMAIL_TAKEN");
    }

    // P2-R1 FIX 7 (F-13): CSPRNG-based temp password (shared helper in
    // lib/server/auth — node:crypto randomInt over the unambiguous alphabet).
    // Computed ONLY for the historical mode — invite mode arms no password.
    const tempPassword = body.mode === "temp" ? generateTempPassword() : null;
    const passwordHash = tempPassword ? await hashPassword(tempPassword) : null;

    try {
      // API-06 (F-06): member creation + its USER_CREATED audit row commit
      // as ONE transaction — no committed user without its trail (the
      // single-row mutation + audit house law). Phase 8 invite mode folds
      // the INVITE mint into the SAME transaction (user + token + audit
      // commit or roll back together).
      const created = await db.$transaction(async (tx) => {
        const row = await tx.user.create({
          data: {
            orgId: actor.orgId,
            name: body.name,
            email,
            role: body.role,
            active: true,
            passwordHash,
          },
          select: { id: true, name: true, email: true, role: true, active: true, orgId: true },
        });
        await logAudit({
          orgId: actor.orgId,
          actor,
          action: "USER_CREATED",
          entity: "USER", // P2-R1 FIX 8: canonical uppercase entity form
          entityId: row.id,
          after: { name: row.name, email: row.email, role: row.role, active: true, mode: body.mode },
        }, tx);
        let invite: { raw: string; expiresAt: Date } | null = null;
        if (body.mode === "invite") {
          const minted = await mintAuthToken(tx, {
            orgId: actor.orgId,
            userId: row.id,
            kind: "INVITE",
            createdBy: actor.id,
          });
          await logAudit({
            orgId: actor.orgId,
            actor,
            action: "USER_INVITED",
            entity: "USER",
            entityId: row.id,
            after: { userId: row.id, expiresAt: minted.expiresAt.toISOString() },
          }, tx);
          invite = { raw: minted.raw, expiresAt: minted.expiresAt };
        }
        return { row, invite };
      });

      // The temp password / invite token is returned ONCE — never persisted
      // in clear anywhere (the invite token's HASH is what lives in the DB).
      return ok(
        {
          user: created.row,
          ...(tempPassword ? { tempPassword } : {}),
          ...(created.invite
            ? {
                inviteToken: created.invite.raw,
                inviteExpiresAt: created.invite.expiresAt.toISOString(),
              }
            : {}),
        },
        201,
      );
    } catch (error) {
      if (isPrismaKnownError(error, "P2002")) {
        throw new ApiError(409, "Cette adresse email est déjà utilisée", "USER_EMAIL_TAKEN");
      }
      throw error;
    }
  } catch (error) {
    return fail(error);
  }
}
