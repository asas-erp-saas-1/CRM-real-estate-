// POST /api/users/[id]/reset-password — OWNER/ADMIN only (R8-2; Phase 8 A1).
//
// Phase 8 (A1) — TWO reset modes (body { mode }):
//   · "temp" (default, historical): generates a readable temp password
//     (`Asas-` + 6 unambiguous alphanumerics, CSPRNG — P2-R1 FIX 7), stores
//     its scrypt hash, bumps `passwordChangedAt` (F-05: every session issued
//     before the reset is invalidated), clears login lockout state and audits
//     USER_PASSWORD_RESET (API-06: credential write + audit as ONE tx — F-06).
//     The temp password is returned ONCE — never logged, never persisted clear.
//   · "code" (Phase 8 — the mandate's owner-controlled secure recovery):
//     does NOT write any password. Mints a single-use RESET token (30 min,
//     sha256-hashed at rest) returned ONCE to the requesting admin for
//     out-of-band transmission; the EMPLOYEE redeems it at
//     /api/auth/redeem-token to choose their own new password (the redeem tx
//     bumps passwordChangedAt — sessions die — and audits the redemption).
//     Minting is audited USER_RESET_REQUESTED in the same transaction.
//
// An ADMIN cannot reset an OWNER's password (P2-R1 FIX 3 — ROLE_CEILING);
// the same ceiling applies to code mode (an ADMIN minting an OWNER recovery
// code would take over the OWNER account at redemption).
// (Self password change is the separate /api/auth/change-password endpoint.)
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { clearFailures, generateTempPassword, hashPassword } from "@/lib/server/auth";
import { mintAuthToken } from "@/lib/server/auth-tokens";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const resetSchema = z.object({
  // Phase 8 (A1): "temp" (historical) | "code" (employee redeems own password).
  mode: z.enum(["temp", "code"]).default("temp"),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    // Phase 8 (A2): named permission (users.manage → ADMIN+), envelope
    // byte-compatible with the old ADMIN rank floor. (assertSameOrigin runs
    // inside requireUser — CSRF coverage is unchanged for body-less callers.)
    const actor = await requirePermission("users.manage");
    // Backward compatibility: the historical client POSTs with NO body — an
    // empty body keeps the historical "temp" mode (every existing contract
    // byte-identical). An explicitly WRONG mode value still 422s.
    let body: z.output<typeof resetSchema> = { mode: "temp" };
    try {
      body = await parseBody(req, resetSchema);
    } catch (error) {
      if (!(error instanceof ApiError) || error.code !== "INVALID_JSON") throw error;
    }
    const { id } = await ctx.params;

    const target = await db.user.findFirst({
      where: { id, orgId: actor.orgId },
      select: { id: true, email: true, name: true, role: true },
    });
    if (!target) throw new ApiError(404, "Utilisateur introuvable", "USER_NOT_FOUND");

    // P2-R1 FIX 3 (F-07): rank ceiling — an ADMIN resetting an OWNER's
    // password (temp returned) or minting an OWNER recovery code (redeemed
    // by the ADMIN) would take over the OWNER account.
    if (actor.role === "ADMIN" && target.role === "OWNER") {
      throw new ApiError(403, "Seul un OWNER peut réinitialiser le mot de passe d'un OWNER.", "ROLE_CEILING");
    }

    // ── Phase 8 code mode: mint the one-time recovery capability ──────────
    if (body.mode === "code") {
      const minted = await db.$transaction(async (tx) =>
        mintAuthToken(tx, {
          orgId: actor.orgId,
          userId: target.id,
          kind: "RESET",
          createdBy: actor.id,
        }).then(async (token) => {
          await logAudit({
            orgId: actor.orgId,
            actor,
            action: "USER_RESET_REQUESTED",
            entity: "USER",
            entityId: target.id,
            // No password material, ever — just the capability's shape.
            after: { userId: target.id, method: "RESET_CODE", expiresAt: token.expiresAt.toISOString() },
          }, tx);
          return token;
        }),
      );
      // The raw code is returned ONCE — only its sha256 hash is at rest.
      return ok({
        resetToken: minted.raw,
        resetExpiresAt: minted.expiresAt.toISOString(),
      });
    }

    // ── Historical temp mode ────────────────────────────────────────────────
    const tempPassword = generateTempPassword();
    const passwordHash = await hashPassword(tempPassword);

    // F-05: the reset invalidates every session issued before it
    // (signed-cookie issuedAt < passwordChangedAt → 401 — logout-everywhere).
    // API-06 (F-06): the credential write + its USER_PASSWORD_RESET audit
    // row commit as ONE transaction — no committed reset without its trail
    // (the single-row mutation + audit house law).
    await db.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: target.id },
        data: { passwordHash, passwordChangedAt: new Date() },
      });
      await logAudit({
        orgId: actor.orgId,
        actor,
        action: "USER_PASSWORD_RESET",
        entity: "USER", // P2-R1 FIX 8: canonical uppercase entity form
        entityId: target.id,
        // No passwords (neither clear nor hashed) in the audit trail.
        after: { userId: target.id, email: target.email, method: "ADMIN_RESET" },
      }, tx);
    });

    // A reset is an administrative trust action — clear login lockout state.
    // (After the commit on purpose: the limiter is in-memory, not a DB write —
    // a rolled-back reset must not have cleared the lockout either.)
    clearFailures(target.email);

    return ok({ tempPassword });
  } catch (error) {
    return fail(error);
  }
}
