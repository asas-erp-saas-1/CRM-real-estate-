// PATCH /api/users/[id] — team management (R8-2), OWNER/ADMIN only.
// Body: { role?: string, active?: boolean } with rank ceiling, self-lockout
// and last-owner guards (documented precedence, R8-2 + P2-R1):
//  - ROLE_CEILING (P2-R1 FIX 3, F-07): an ADMIN cannot edit an OWNER member
//    nor promote anyone to OWNER — OWNER rank is OWNER-only territory;
//  - cannot change your own role (400 SELF_ROLE_CHANGE);
//  - cannot deactivate yourself (400 SELF_DEACTIVATION);
//  - cannot deactivate or demote the LAST active OWNER (400 LAST_OWNER);
//  - role must be a valid constant role; active must be a boolean.
// Every change is audited USER_UPDATED with before/after role/active (API-06:
// row + audit commit as ONE transaction — F-06).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { ROLES } from "@/lib/constants";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z
  .object({
    role: z.enum(ROLES).optional(),
    active: z.boolean().optional(),
  })
  .refine((v) => v.role !== undefined || v.active !== undefined, {
    message: "Rien à modifier (role ou active requis)",
  });

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const actor = await requirePermission("users.manage"); // ADMIN rank = OWNER or ADMIN
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    const target = await db.user.findFirst({
      where: { id, orgId: actor.orgId },
      select: { id: true, orgId: true, name: true, email: true, role: true, active: true },
    });
    if (!target) throw new ApiError(404, "Utilisateur introuvable", "USER_NOT_FOUND");

    // ── Rank ceiling (P2-R1 FIX 3, F-07) ──
    // After the org-scoped load, before the mutability checks: an ADMIN can
    // neither manage an OWNER member nor promote anyone to OWNER. (The
    // SELF_* > LAST_OWNER precedence from R8-2 is untouched — ROLE_CEILING
    // simply precedes both for ADMIN→OWNER-shaped requests.)
    if (actor.role === "ADMIN" && (target.role === "OWNER" || body.role === "OWNER")) {
      throw new ApiError(403, "Seul un OWNER peut gérer un compte OWNER.", "ROLE_CEILING");
    }

    // ── Self-lockout guards ──
    if (target.id === actor.id) {
      if (body.role !== undefined && body.role !== target.role) {
        throw new ApiError(400, "Vous ne pouvez pas modifier votre propre rôle", "SELF_ROLE_CHANGE");
      }
      if (body.active === false) {
        throw new ApiError(400, "Vous ne pouvez pas désactiver votre propre compte", "SELF_DEACTIVATION");
      }
    }

    const roleChanged = body.role !== undefined && body.role !== target.role;
    const activeChanged = body.active !== undefined && body.active !== target.active;
    const demotesOwner = roleChanged && target.role === "OWNER" && body.role !== "OWNER";
    const deactivatesOwner = body.active === false && target.role === "OWNER" && target.active;

    if (!roleChanged && !activeChanged) {
      // Idempotent no-op — return the unchanged member (still 200).
      return ok({ user: target });
    }

    // API-06 (F-06): the member update + its USER_UPDATED audit row commit as
    // ONE transaction — no committed role/active change without its trail
    // (the single-row mutation + audit house law). The data object is built
    // BEFORE the closure so the aliased-narrowed body fields stay narrowed.
    const patchData = {
      ...(roleChanged ? { role: body.role } : {}),
      ...(activeChanged ? { active: body.active } : {}),
    };
    const updated = await db.$transaction(async (tx) => {
      // DB-AUDIT fix (P3-1) — the LAST_OWNER count re-decides INSIDE the write
      // transaction: two concurrent demotions/deactivations of the last two
      // owners each seeing activeOwners=2 OUTSIDE the tx could otherwise both
      // pass and strip the org of every active OWNER. SQLite serializes
      // interactive transactions, making the count-then-write atomic here.
      if ((demotesOwner || deactivatesOwner) && target.active) {
        const activeOwners = await tx.user.count({
          where: { orgId: actor.orgId, role: "OWNER", active: true },
        });
        if (activeOwners <= 1) {
          throw new ApiError(
            400,
            "Impossible : il doit toujours rester au moins un propriétaire actif",
            "LAST_OWNER",
          );
        }
      }
      const row = await tx.user.update({
        where: { id: target.id },
        data: patchData,
        select: { id: true, orgId: true, name: true, email: true, role: true, active: true },
      });
      await logAudit({
        orgId: actor.orgId,
        actor,
        action: "USER_UPDATED",
        entity: "USER", // P2-R1 FIX 8: canonical uppercase entity form
        entityId: target.id,
        before: { role: target.role, active: target.active },
        after: { role: row.role, active: row.active },
      }, tx);
      return row;
    });

    return ok({ user: updated });
  } catch (error) {
    return fail(error);
  }
}
