// GET   /api/sav/:id — case detail + its timeline (P14, D-023).
// PATCH /api/sav/:id — the case lifecycle (status transitions, assignment,
// content edits) with the server-enforced laws:
//
//   • Scoped findFirst — foreign ids are 404, byte-identical to ghosts (D-021).
//   • Mutation rights: the case's ASSIGNEE or MANAGER+ (a below-MANAGER
//     non-assignee may VIEW a case in scope but not act on it → 403).
//     Exception — the self-claim: any authenticated user may claim an
//     UNASSIGNED case ({assigneeId: own id}) — assignment triage self-service.
//     Any other assignment change requires MANAGER+ (403).
//   • Status transitions follow SAV_STATUS_TRANSITIONS (422 on violation).
//     → RESOLVED requires a resolution text (body or existing) — 422 otherwise.
//     → CLOSED is the management confirmation step (MANAGER+ only → 403).
//     → CANCELLED invalidates a client request — MANAGER+ only (403).
//   • CLOSED/CANCELLED cases are immutable history (409 on any mutation).
//   • F-06 (API-06): the case update, its timeline entries (up to 5) and the
//     audit row commit as ONE transaction — no mutated case without its
//     trail, no partial trail on a mid-write crash.
import type { NextRequest } from "next/server";
import { z } from "zod";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { atLeastRole, PRIORITIES, SAV_CATEGORIES, SAV_OPEN_STATUSES, SAV_STATUSES, SAV_STATUS_TRANSITIONS } from "@/lib/constants";
import { logActivity, logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { savScope } from "@/lib/server/visibility";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const caseInclude = {
  assignee: { select: { id: true, name: true } },
  createdBy: { select: { id: true, name: true } },
  lead: { select: { id: true, fullName: true, phone: true } },
  apartment: {
    select: {
      id: true,
      code: true,
      unitType: true,
      surface: true,
      building: { select: { name: true, project: { select: { id: true, name: true } } } },
    },
  },
  reservation: {
    select: {
      id: true,
      status: true,
      contractRef: true,
      agentId: true,
      opportunity: { select: { id: true, leadId: true } },
    },
  },
} satisfies Prisma.SavCaseInclude;

const now0 = () => new Date();
// W3.4 (master audit — ARCH-T2/D4+D5): OPEN_WORK was a local re-declaration of
// the canonical SAV_OPEN_STATUSES (src/lib/constants.ts) — replaced by the
// import above (single source, the enum-drift law).

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    // D-021 — scoped findFirst: foreign cases are 404, byte-identical to ghosts.
    const sav = await db.savCase.findFirst({
      where: { id, orgId: user.orgId, ...savScope(user) },
      include: {
        ...caseInclude,
        activities: {
          orderBy: { occurredAt: "desc" },
          take: 50,
          select: { id: true, type: true, title: true, body: true, meta: true, occurredAt: true, actorId: true, actor: { select: { id: true, name: true } } },
        },
      },
    });
    if (!sav) throw new ApiError(404, "Dossier introuvable", "SAV_CASE_NOT_FOUND");

    return ok({
      savCase: {
        ...sav,
        overdue: (SAV_OPEN_STATUSES as readonly string[]).includes(sav.status) && sav.dueAt !== null && sav.dueAt < now0(),
      },
    });
  } catch (error) {
    return fail(error);
  }
}

const patchSchema = z.object({
  title: z.string().trim().min(1).max(120).optional(),
  category: z.enum(SAV_CATEGORIES).optional(),
  priority: z.enum(PRIORITIES).optional(),
  description: z.string().trim().min(1).max(2000).optional(),
  dueAt: z.coerce.date().nullable().optional(),
  resolution: z.string().trim().max(2000).nullable().optional(),
  assigneeId: z.string().min(1).nullable().optional(),
  // W3.4 (master audit — ARCH-T2/D4): the status vocabulary imports the
  // canonical SAV_STATUSES — the inline 5-value re-declaration is dead.
  status: z.enum(SAV_STATUSES).optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    // D-021 — scoped findFirst first: foreign cases 404 byte-identical, THEN rights.
    const sav = await db.savCase.findFirst({
      where: { id, orgId, ...savScope(user) },
      include: { ...caseInclude, assignee: { select: { id: true, name: true } } },
    });
    if (!sav) throw new ApiError(404, "Dossier introuvable", "SAV_CASE_NOT_FOUND");

    const isManager = atLeastRole(user.role, "MANAGER");
    const isAssignee = sav.assigneeId === user.id;
    const terminal = sav.status === "CLOSED" || sav.status === "CANCELLED";

    // ── immutability law: closed/cancelled history never changes ──────────────
    if (terminal) {
      throw new ApiError(409, `Dossier ${sav.status === "CLOSED" ? "clôturé" : "annulé"} — historique immuable`, "SAV_CASE_TERMINAL");
    }

    // ── assignment law ────────────────────────────────────────────────────────
    const isSelfClaim = body.assigneeId === user.id && sav.assigneeId === null;
    let assignedToName: string | null = sav.assignee?.name ?? null;
    if (body.assigneeId !== undefined) {
      const isUnassign = body.assigneeId === null;
      if (!isManager && !isSelfClaim && !isUnassign) {
        throw new ApiError(403, "L'affectation est réservée au management.", "ASSIGNMENT_FORBIDDEN");
      }
      if (body.assigneeId != null) {
        const assignee = await db.user.findFirst({ where: { id: body.assigneeId, orgId, active: true }, select: { id: true, name: true } });
        if (!assignee) throw new ApiError(404, "Utilisateur introuvable", "USER_NOT_FOUND");
        assignedToName = assignee.name;
      } else {
        assignedToName = null;
      }
    }

    // ── acting rights: assignee or manager (self-claim excepted — handled above) ──
    const wantsStatus = body.status !== undefined;
    const wantsContent = [body.title, body.category, body.priority, body.description, body.dueAt, body.resolution].some((v) => v !== undefined);
    if ((wantsStatus || wantsContent) && !isManager && !isAssignee && !isSelfClaim) {
      throw new ApiError(403, "Seul le responsable du dossier (ou le management) peut le modifier.", "SAV_CASE_NOT_ASSIGNEE");
    }

    // ── status transition laws ───────────────────────────────────────────────
    if (wantsStatus) {
      const allowed = SAV_STATUS_TRANSITIONS[sav.status] ?? [];
      if (!allowed.includes(body.status!)) {
        throw new ApiError(422, `Transition ${sav.status} → ${body.status} non autorisée`, "SAV_INVALID_TRANSITION", { from: sav.status, to: body.status, allowed });
      }
      if (body.status === "RESOLVED") {
        const hasResolution = (body.resolution ?? sav.resolution ?? "").trim().length > 0;
        if (!hasResolution) {
          throw new ApiError(422, "La résolution est requise pour clore le traitement.", "RESOLUTION_REQUIRED");
        }
      }
      if ((body.status === "CLOSED" || body.status === "CANCELLED") && !isManager) {
        throw new ApiError(403, "La clôture/annulation est réservée au management.", "SAV_CLOSE_FORBIDDEN");
      }
    }

    const data: {
      title?: string;
      category?: (typeof SAV_CATEGORIES)[number];
      priority?: (typeof PRIORITIES)[number];
      description?: string;
      dueAt?: Date | null;
      resolution?: string | null;
      assigneeId?: string | null;
      status?: string;
      resolvedAt?: Date | null;
      closedAt?: Date;
    } = {};
    if (body.title !== undefined) data.title = body.title;
    if (body.category !== undefined) data.category = body.category;
    if (body.priority !== undefined) data.priority = body.priority;
    if (body.description !== undefined) data.description = body.description;
    if (body.dueAt !== undefined) data.dueAt = body.dueAt;
    if (body.resolution !== undefined) data.resolution = body.resolution;
    if (body.assigneeId !== undefined) data.assigneeId = body.assigneeId;
    if (body.status === "IN_PROGRESS") {
      data.status = "IN_PROGRESS";
      data.resolvedAt = null; // reopen clears the resolved stamp (audit keeps history)
    }
    if (body.status === "RESOLVED") {
      data.status = "RESOLVED";
      data.resolvedAt = now0();
      if (body.resolution !== undefined) data.resolution = body.resolution;
    }
    if (body.status === "CLOSED") {
      data.status = "CLOSED";
      data.closedAt = now0();
    }
    if (body.status === "CANCELLED") data.status = "CANCELLED";

    if (Object.keys(data).length === 0) {
      throw new ApiError(422, "Aucun champ modifiable fourni", "EMPTY_PATCH");
    }

    const before = { status: sav.status, title: sav.title, category: sav.category, priority: sav.priority, assigneeId: sav.assigneeId, dueAt: sav.dueAt, resolution: sav.resolution };

    // ── side effects: timeline + audit (route invariant) ─────────────────────
    const activityBase = {
      orgId,
      leadId: sav.leadId,
      reservationId: sav.reservationId,
      savCaseId: sav.id,
      actorId: user.id,
      type: "SAV" as const,
    };

    // API-06 (F-06 transaction law): the update, up to 5 logActivity rows
    // and the logAudit row commit as ONE transaction — previously the
    // update committed FIRST and the trail followed sequentially outside
    // it, so a crash mid-trail left a mutated case with a partial (or
    // empty) trail: the exact orphan class F-06 closes route by route.
    const updated = await db.$transaction(async (tx) => {
      const row = await tx.savCase.update({ where: { id: sav.id }, data });

      if (body.status === "IN_PROGRESS") {
        await logActivity({ ...activityBase, title: `Prise en charge — ${row.title}`, meta: { savCaseId: sav.id, status: "IN_PROGRESS" } }, tx);
      }
      if (body.status === "RESOLVED") {
        await logActivity({ ...activityBase, title: `Dossier résolu — ${row.title}`, body: row.resolution, meta: { savCaseId: sav.id, status: "RESOLVED" } }, tx);
      }
      if (body.status === "CLOSED") {
        await logActivity({ ...activityBase, title: `Dossier clôturé — ${row.title}`, body: "Clôture confirmée avec le client après contrôle final.", meta: { savCaseId: sav.id, status: "CLOSED" } }, tx);
      }
      if (body.status === "CANCELLED") {
        await logActivity({ ...activityBase, title: `Dossier annulé — ${row.title}`, meta: { savCaseId: sav.id, status: "CANCELLED" } }, tx);
      }
      if (body.assigneeId !== undefined) {
        await logActivity({
          ...activityBase,
          title: body.assigneeId === user.id ? `Dossier pris en charge — ${row.title}` : `Dossier affecté à ${assignedToName ?? "—"} — ${row.title}`,
          meta: { savCaseId: sav.id, assigneeId: row.assigneeId },
        }, tx);
      }

      const action = wantsStatus
        ? "SAV_CASE_STATUS_CHANGED"
        : body.assigneeId !== undefined
          ? "SAV_CASE_ASSIGNED"
          : "SAV_CASE_UPDATED";
      await logAudit({
        orgId,
        actor: user,
        action,
        entity: "SAV_CASE",
        entityId: sav.id,
        before,
        after: { status: row.status, title: row.title, category: row.category, priority: row.priority, assigneeId: row.assigneeId, dueAt: row.dueAt, resolution: row.resolution, resolvedAt: row.resolvedAt, closedAt: row.closedAt },
      }, tx);

      return row;
    });

    return ok({
      savCase: {
        ...updated,
        overdue: (SAV_OPEN_STATUSES as readonly string[]).includes(updated.status) && updated.dueAt !== null && updated.dueAt < now0(),
      },
    });
  } catch (error) {
    return fail(error);
  }
}
