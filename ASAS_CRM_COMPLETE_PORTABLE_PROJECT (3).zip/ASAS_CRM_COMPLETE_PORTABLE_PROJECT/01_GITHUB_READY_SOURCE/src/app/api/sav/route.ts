// GET  /api/sav — the after-sales case list + scoped KPIs (P14, D-023).
// POST /api/sav — declare a new SAV case (ANY authenticated role may declare —
// an agent reporting a client's issue is the intake; assignment is management
// work, so an assigneeId from a below-MANAGER caller is a 403).
//
// Laws (AUTHORIZATION_MODEL §7 composition law + D-022 spirit):
//   • Reads are visibility-scoped (savScope: assignee/creator ∨ unassigned
//     intake ∨ own+pool clients); OVERDUE is derived (open work ∧ dueAt < now)
//     — never stored, nothing can rot.
//   • POST-reference guards: reservation/lead references must be in scope —
//     foreign-but-existing ids are 404, byte-identical to ghosts.
//   • seq is org-wide (human ref "SAV-{seq}") — stamped inside the create
//     transaction; a P2002 race maps to 409 (retry).
import type { NextRequest } from "next/server";
import { z } from "zod";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { atLeastRole, PRIORITIES, SAV_CATEGORIES, SAV_OPEN_STATUSES, SAV_STATUSES } from "@/lib/constants";
import { logActivity, logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { assertLeadVisible, reservationScope, savScope } from "@/lib/server/visibility";
import { isPrismaKnownError, parseBody, qp, qpEnum } from "@/lib/server/validation";

const BUCKETS = ["overdue", "unassigned", "open", "inprogress", "resolved", "closed"] as const;

const savInclude = {
  assignee: { select: { id: true, name: true } },
  createdBy: { select: { id: true, name: true } },
  lead: { select: { id: true, fullName: true, phone: true } },
  apartment: {
    select: {
      id: true,
      code: true,
      unitType: true,
      building: { select: { name: true, project: { select: { id: true, name: true } } } },
    },
  },
  reservation: {
    select: {
      id: true,
      status: true,
      contractRef: true,
      agentId: true,
      opportunity: { select: { id: true, leadId: true } },
    },
  },
} satisfies Prisma.SavCaseInclude;

type SavRow = Prisma.SavCaseGetPayload<{ include: typeof savInclude }>;

// W3.4 (master audit — ARCH-T2/D4+D5): OPEN_WORK was a local re-declaration
// of the canonical SAV_OPEN_STATUSES (src/lib/constants.ts) — the exact
// enum-drift class that bit the tasks filter once. All `status` vocabulary
// now imports from the single source.

/** Derived SAV state — never stored (D-022 law-1 spirit). */
function decorate(row: SavRow, now: Date) {
  return {
    ...row,
    overdue: (SAV_OPEN_STATUSES as readonly string[]).includes(row.status) && row.dueAt !== null && row.dueAt < now,
  };
}

/** Scan order: overdue open work first, then OPEN → IN_PROGRESS, history last. */
const STATUS_RANK: Record<string, number> = { OPEN: 0, IN_PROGRESS: 1, RESOLVED: 2, CLOSED: 3, CANCELLED: 4 };
function sortRows(a: SavRow, b: SavRow): number {
  const now = new Date();
  const openStatuses = SAV_OPEN_STATUSES as readonly string[];
  const ao = openStatuses.includes(a.status) && a.dueAt && a.dueAt < now ? -1 : 0;
  const bo = openStatuses.includes(b.status) && b.dueAt && b.dueAt < now ? -1 : 0;
  if (ao !== bo) return ao - bo; // overdue open work on top
  const rank = (STATUS_RANK[a.status] ?? 9) - (STATUS_RANK[b.status] ?? 9);
  if (rank !== 0) return rank;
  const ad = a.dueAt?.getTime() ?? Number.MAX_SAFE_INTEGER;
  const bd = b.dueAt?.getTime() ?? Number.MAX_SAFE_INTEGER;
  if (ad !== bd) return ad - bd; // nearest SLA first
  return b.seq - a.seq;
}

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const now = new Date();

    const bucket = qpEnum(req, "bucket", BUCKETS);
    // W3.4 (master audit — ARCH-T2/D4): the status vocabulary imports the
    // canonical SAV_STATUSES — the inline 5-value re-declaration is dead.
    const status = qpEnum(req, "status", SAV_STATUSES);
    const category = qpEnum(req, "category", SAV_CATEGORIES);
    const priority = qpEnum(req, "priority", PRIORITIES);
    const assigneeId = qp(req, "assigneeId") || undefined;
    const apartmentId = qp(req, "apartmentId") || undefined;
    const leadId = qp(req, "leadId") || undefined;
    const query = (qp(req, "query") || qp(req, "q") || "").trim();

    // W3.6 (master audit — PERF-P4): house pagination params (the
    // leads/route.ts pattern) — default 200 / clamp 500 so existing UI
    // callers (sav-view passes only bucket/query) see no change.
    const params = req.nextUrl.searchParams;
    const page = parseIntParam(params.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(params.get("pageSize"), 200, { min: 1, max: 500 });

    // conditions-array composition (AUTHORIZATION_MODEL §7 rule 3): the scope
    // fragment is element 0 — never spread next to this route's own OR key.
    const conditions: Prisma.SavCaseWhereInput[] = [{ orgId, ...savScope(user) }];
    if (bucket === "overdue") conditions.push({ status: { in: [...SAV_OPEN_STATUSES] }, dueAt: { lt: now } });
    else if (bucket === "unassigned") conditions.push({ status: "OPEN", assigneeId: null });
    else if (bucket === "open") conditions.push({ status: "OPEN" });
    else if (bucket === "inprogress") conditions.push({ status: "IN_PROGRESS" });
    else if (bucket === "resolved") conditions.push({ status: "RESOLVED" });
    else if (bucket === "closed") conditions.push({ status: { in: ["CLOSED", "CANCELLED"] } });
    else if (status) conditions.push({ status });
    if (category) conditions.push({ category });
    if (priority) conditions.push({ priority });
    if (assigneeId) conditions.push({ assigneeId });
    if (apartmentId) conditions.push({ apartmentId });
    if (leadId) conditions.push({ leadId });
    if (query) {
      conditions.push({
        OR: [
          { title: { contains: query } },
          { description: { contains: query } },
          { lead: { fullName: { contains: query } } },
          { apartment: { code: { contains: query } } },
        ],
      });
    }

    const where: Prisma.SavCaseWhereInput = conditions.length > 1 ? { AND: conditions } : conditions[0];
    const [rows, kpis] = await Promise.all([
      // W2-4 (Phase 2.1 — A6#4): the scan is bounded by the house 5000 cap
      // (the export-bundle convention) — the derived in-memory sort order is
      // a documented law (PERF-P4 above), but the unbounded full-relation
      // scan was not. `total` semantics preserved (rows-in-window).
      db.savCase.findMany({ where, include: savInclude, take: 5000 }),
      // KPIs follow the caller's scope — no bucket filters (attention tier + context row).
      (async () => {
        const scope = { orgId, ...savScope(user) };
        const [open, overdue, unassigned, resolved, closedTotal] = await Promise.all([
          db.savCase.count({ where: { ...scope, status: { in: [...SAV_OPEN_STATUSES] } } }),
          db.savCase.count({ where: { ...scope, status: { in: [...SAV_OPEN_STATUSES] }, dueAt: { lt: now } } }),
          db.savCase.count({ where: { ...scope, status: "OPEN", assigneeId: null } }),
          db.savCase.count({ where: { ...scope, status: "RESOLVED" } }),
          db.savCase.count({ where: { ...scope, status: { in: ["CLOSED", "CANCELLED"] } } }),
        ]);
        return { open, overdue, unassigned, resolved, closed: closedTotal };
      })(),
    ]);

    const data = rows.map((r) => decorate(r, now)).sort(sortRows);

    // W3.6 (master audit — PERF-P4): the page rides the SORTED array, not a
    // DB take/skip — the scan order is DERIVED in memory (overdue open work
    // first, D-022 law-1: `overdue` = open work ∧ dueAt < now, an ordering
    // SQLite cannot express), so SQL-level skip/take would reorder pages.
    // `total` keeps its exact former semantics (the full matching count —
    // it was `data.length` of the unpaginated list); the response only ADDS
    // page/pageSize (never removes/renames — backward-compatible contract).
    const total = data.length;
    const paged = data.slice((page - 1) * pageSize, page * pageSize);

    return ok({ data: paged, total, page, pageSize, kpis });
  } catch (error) {
    return fail(error);
  }
}

const createSchema = z.object({
  title: z.string().trim().min(1, "Titre requis").max(120),
  category: z.enum(SAV_CATEGORIES).default("OTHER"),
  priority: z.enum(PRIORITIES).default("NORMAL"),
  description: z.string().trim().min(1, "Description requise").max(2000),
  reservationId: z.string().min(1).optional(),
  leadId: z.string().min(1).optional(),
  apartmentId: z.string().min(1).optional(),
  // Honored for MANAGER+ only — assignment is management work (D-022 law-2 analog).
  assigneeId: z.string().min(1).nullable().optional(),
  dueAt: z.coerce.date().nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const body = await parseBody(req, createSchema);

    // Assignment is management work — a below-MANAGER caller cannot pre-assign.
    if (body.assigneeId != null && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(403, "L'affectation est réservée au management.", "ASSIGNMENT_FORBIDDEN");
    }

    // ── POST-reference guards (D-021): every reference must be in scope ──
    let leadId = body.leadId ?? null;
    let apartmentId = body.apartmentId ?? null;
    if (body.reservationId) {
      const reservation = await db.reservation.findFirst({
        where: { id: body.reservationId, orgId, ...reservationScope(user) },
        select: { id: true, apartmentId: true, opportunity: { select: { leadId: true } } },
      });
      if (!reservation) throw new ApiError(404, "Réservation introuvable", "RESERVATION_NOT_FOUND");
      // adopt the sale's links unless explicitly overridden
      leadId = body.leadId ?? reservation.opportunity.leadId;
      apartmentId = body.apartmentId ?? reservation.apartmentId;
      body.reservationId = reservation.id;
    }
    if (leadId) await assertLeadVisible(user, leadId);
    if (apartmentId) {
      const apartment = await db.apartment.findFirst({ where: { id: apartmentId, orgId }, select: { id: true } });
      if (!apartment) throw new ApiError(404, "Bien introuvable", "APARTMENT_NOT_FOUND");
    }
    if (body.assigneeId != null) {
      const assignee = await db.user.findFirst({ where: { id: body.assigneeId, orgId, active: true }, select: { id: true } });
      if (!assignee) throw new ApiError(404, "Utilisateur introuvable", "USER_NOT_FOUND");
    }

    try {
      const sav = await db.$transaction(async (tx) => {
        const last = await tx.savCase.findFirst({ where: { orgId }, orderBy: { seq: "desc" }, select: { seq: true } });
        const row = await tx.savCase.create({
          data: {
            orgId,
            seq: (last?.seq ?? 0) + 1,
            title: body.title,
            category: body.category,
            priority: body.priority,
            status: "OPEN",
            description: body.description,
            leadId,
            reservationId: body.reservationId ?? null,
            apartmentId,
            assigneeId: body.assigneeId ?? null,
            createdById: user.id,
            reportedAt: new Date(),
            dueAt: body.dueAt ?? null,
          },
          include: savInclude,
        });

        // API-06 (F-06): the route invariant "side effects after the write"
        // upgrades to "inside the write" — the timeline entry and the audit
        // row ride the SAME transaction as the create (a forced failure
        // rolls back case AND trail together; no orphaned trail without a
        // case, no case born without its trail).
        await logActivity({
          orgId,
          actorId: user.id,
          leadId: row.leadId,
          reservationId: row.reservationId,
          savCaseId: row.id,
          type: "SAV",
          title: `Dossier SAV ouvert — ${row.title}`,
          body: `${row.lead?.fullName ?? "—"} · ${row.apartment?.code ?? "—"} · ${row.category}`,
          meta: { savCaseId: row.id, seq: row.seq, category: row.category, priority: row.priority },
        }, tx);
        await logAudit({
          orgId,
          actor: user,
          action: "SAV_CASE_CREATED",
          entity: "SAV_CASE",
          entityId: row.id,
          before: null,
          after: { seq: row.seq, title: row.title, category: row.category, priority: row.priority, leadId: row.leadId, apartmentId: row.apartmentId, assigneeId: row.assigneeId, dueAt: row.dueAt },
        }, tx);

        return row;
      });

      return ok({ savCase: decorate(sav, new Date()) }, 201);
    } catch (error) {
      // [orgId, seq] unique — concurrent seq races land here.
      if (isPrismaKnownError(error, "P2002")) {
        throw new ApiError(409, "Conflit de numérotation — réessayez", "SEQ_CONFLICT");
      }
      throw error;
    }
  } catch (error) {
    return fail(error);
  }
}
