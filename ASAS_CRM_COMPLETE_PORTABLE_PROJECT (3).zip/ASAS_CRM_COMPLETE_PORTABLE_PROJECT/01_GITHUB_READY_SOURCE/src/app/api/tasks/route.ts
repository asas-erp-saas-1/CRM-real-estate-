// GET  /api/tasks — status/owner/overdue/dueBefore/lead filters, dueAt asc.
// POST /api/tasks — create a task (owner = current user, or a MANAGER+-
// delegated org member — P9-D10), logged on the timeline.
import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import { PRIORITIES, TASK_STATUSES, TASK_TYPES, atLeastRole } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { ApiError, fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { leadScope, oppScope, taskScope } from "@/lib/server/visibility";
import { findLead } from "@/lib/server/leads"; // G5-P4-2 — the shared scoped-lookup helper
import { findOpportunity } from "@/lib/server/opportunities"; // W3.3 — the shared scoped-lookup helper
import { taskInclude } from "@/lib/server/tasks"; // W3.2 — shared task DTO module
import { optionalId, parseBody, qp, qpBool, qpDate, qpEnum } from "@/lib/server/validation";

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const params = req.nextUrl.searchParams;

    const page = parseIntParam(params.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(params.get("pageSize"), 50, { min: 1, max: 200 });

    // D-021 — record visibility: below MANAGER, the task list is OWN+POOL scoped.
    const conditions: Prisma.TaskWhereInput[] = [{ orgId, ...taskScope(user) }];

    const status = qpEnum(req, "status", TASK_STATUSES);
    if (status) conditions.push({ status });

    const ownerId = qp(req, "ownerId");
    if (ownerId) conditions.push({ ownerId });

    if (qpBool(req, "overdue")) {
      conditions.push({ status: "OPEN", dueAt: { lt: new Date() } });
    }

    const dueBefore = qpDate(req, "dueBefore");
    if (dueBefore) conditions.push({ dueAt: { lte: dueBefore } });

    const leadId = qp(req, "leadId");
    if (leadId) conditions.push({ leadId });

    const where: Prisma.TaskWhereInput = conditions.length > 1 ? { AND: conditions } : conditions[0];

    const [total, tasks] = await Promise.all([
      db.task.count({ where }),
      db.task.findMany({
        where,
        orderBy: { dueAt: "asc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: taskInclude,
      }),
    ]);

    return ok({ data: tasks, total, page, pageSize });
  } catch (error) {
    return fail(error);
  }
}

// ── POST ──────────────────────────────────────────────────────────────────────

const createSchema = z.object({
  title: z.string().trim().min(1, "Titre requis").max(200),
  type: z.enum(TASK_TYPES),
  dueAt: z.coerce.date(),
  priority: z.enum(PRIORITIES).default("NORMAL"),
  leadId: optionalId,
  opportunityId: optionalId,
  // P9-D10 — DELEGATION: optional task owner. Omitted → creator-owned (the
  // historical law); supplied → MANAGER+ only, org-validated (the leads.assign
  // rank — no new catalog entry: templates mirror current enforcement).
  ownerId: optionalId,
  notes: z.string().trim().max(5000).nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const body = await parseBody(req, createSchema);

    let leadId: string | null = null;
    if (body.leadId) {
      // D-021 — the referenced lead must be in the caller's scope (404 otherwise).
      const lead = await findLead(orgId, body.leadId, leadScope(user), { select: { id: true } }); // G5-P4-2
      if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");
      leadId = lead.id;
    }

    let opportunityId: string | null = null;
    if (body.opportunityId) {
      // D-021 — same for the referenced opportunity.
      // W3.3 (master audit — ARCH-T4): the scoped lookup rides the shared
      // findOpportunity helper (findLead's pattern — org + oppScope, 404 on miss).
      const opportunity = await findOpportunity(orgId, body.opportunityId, oppScope(user), {
        select: { id: true },
      });
      if (!opportunity) throw new ApiError(404, "Opportunité introuvable", "OPPORTUNITY_NOT_FOUND");
      opportunityId = opportunity.id;
    }

    // P9-D10 — DELEGATION: a MANAGER+ may create a task owned by another org
    // member (manager → sales/field delegation was previously impossible —
    // tasks were always creator-owned). Below MANAGER the field is refused;
    // a foreign-org or nonexistent id 422s (never silently links).
    let ownerId: string | null = user.id;
    let delegated = false;
    if (body.ownerId !== undefined && body.ownerId !== null) {
      if (!atLeastRole(user.role, "MANAGER")) {
        throw new ApiError(
          403,
          "Seul un manager peut déléguer une tâche à un autre membre",
          "TASK_DELEGATE_FORBIDDEN",
        );
      }
      const owner = await db.user.findFirst({ where: { id: body.ownerId, orgId }, select: { id: true } });
      if (!owner) throw new ApiError(422, "Destinataire (ownerId) introuvable", "OWNER_NOT_FOUND");
      ownerId = owner.id;
      delegated = ownerId !== user.id;
    }

    // G5-P3-5 (F-06): task creation + its Activity/Audit trail commit as ONE
    // transaction — the leads/[id]/tasks pattern (that route already wraps
    // the identical operation): a crash between the write and the trail can
    // no longer leave a task without its audit row (or an orphaned trail
    // without a task). The §41 hook proves the rollback contract.
    const task = await db.$transaction(async (tx) => {
      const row = await tx.task.create({
        data: {
          orgId,
          leadId,
          opportunityId,
          ownerId,
          title: body.title,
          type: body.type,
          dueAt: body.dueAt,
          priority: body.priority,
          notes: body.notes ?? null,
        },
        include: taskInclude,
      });
      injectTxFault(req, "tasks-post");

      if (leadId) {
        await logActivity({
          orgId,
          actorId: user.id,
          leadId,
          opportunityId,
          taskId: row.id,
          type: "TASK",
          title: `Tâche créée — ${row.title}`,
          meta: { dueAt: row.dueAt.toISOString(), taskType: row.type, priority: row.priority },
        }, tx);
        // P9-D10 — the delegation hand-off rides the lead timeline so the
        // assignee (and the audit trail) sees WHO tasked WHOM (the leads
        // ASSIGNMENT law, task-shaped; personal/unattached tasks stay
        // audit-only — a timeline needs a lead to live on).
        if (delegated) {
          await logActivity({
            orgId,
            actorId: user.id,
            leadId,
            opportunityId,
            taskId: row.id,
            type: "ASSIGNMENT",
            title: "Tâche déléguée",
            meta: { taskId: row.id, ownerId, createdBy: user.name },
          }, tx);
        }
      }
      // W1-3 (Phase 2.1 — A6#2): task creation now audited (activity only
      // rides the lead-attached variant — a personal task has no lead timeline).
      await logAudit({
        orgId,
        actor: user,
        action: "TASK_CREATED",
        entity: "TASK",
        entityId: row.id,
        before: null,
        after: { title: row.title, type: row.type, dueAt: row.dueAt?.toISOString() ?? null, leadId, ownerId },
      }, tx);
      return row;
    });

    return ok({ task }, 201);
  } catch (error) {
    return fail(error);
  }
}
