// PATCH /api/tasks/:id — status/outcome/notes/dueAt/priority updates.
// DONE emits Activity(TASK) "Tâche terminée" with the outcome as body.
// priority is validated against PRIORITIES (P2-R2 — was a free string, drift vector).
// API-07 (audit completeness): every field-carrying PATCH is audited
//        TASK_UPDATED with before/after status/priority (TASK_CREATED and
//        TASK_DELETED existed; the update path alone was dark).
// DELETE /api/tasks/:id — owner-or-MANAGER+ (P4, closes UX B1); Activity rows
//        survive via SetNull; deletion is audit-logged with a before snapshot.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { PRIORITIES, TASK_STATUSES, atLeastRole, canTransitionTask, type TaskStatus } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { taskScope } from "@/lib/server/visibility";
import { taskInclude } from "@/lib/server/tasks"; // W3.2 — shared task DTO module (same enrichment as the list route)
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  status: z.enum(TASK_STATUSES).optional(),
  outcome: z.string().trim().max(2000).nullable().optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
  dueAt: z.coerce.date().optional(),
  priority: z.string().max(20).optional(), // enum-guarded below → 422 INVALID_PRIORITY (P2-R2)
  // P9-D10 — REASSIGNMENT: task owner moves are MANAGER+ only (the
  // leads.assign rank), org-validated, with the ASSIGNMENT trail in-tx.
  ownerId: z.string().nullable().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    // P2-R2: priority must be a PRIORITIES value (POST already enforced this).
    if (body.priority !== undefined && !(PRIORITIES as readonly string[]).includes(body.priority)) {
      throw new ApiError(422, "Priorité invalide", "INVALID_PRIORITY", {
        priority: body.priority,
        allowed: PRIORITIES,
      });
    }

    // D-021 — scoped findFirst: foreign tasks are 404 for below-MANAGER callers.
    const task = await db.task.findFirst({ where: { id, orgId, ...taskScope(user) } });
    if (!task) throw new ApiError(404, "Tâche introuvable", "TASK_NOT_FOUND");

    // W3-4 (Phase 2.1 — A4#7): the task status machine. Illegal edges are
    // 422 (the house contract); reopening a terminal task is a correction —
    // owner-of-record or MANAGER+ (the lead-correction law, mirrored).
    if (body.status !== undefined && body.status !== task.status) {
      if (!canTransitionTask(task.status as TaskStatus, body.status)) {
        throw new ApiError(422, `Transition de statut de tâche invalide : ${task.status} → ${body.status}`, "TASK_ILLEGAL_TRANSITION", {
          from: task.status,
          to: body.status,
        });
      }
      if (task.status !== "OPEN" && !(task.ownerId === user.id || atLeastRole(user.role, "MANAGER"))) {
        throw new ApiError(
          403,
          "La réouverture d'une tâche terminée/annulée est réservée à son propriétaire ou à la direction",
          "FORBIDDEN_ROLE",
        );
      }
    }

    const data: Record<string, unknown> = {};
    if (body.status !== undefined) data.status = body.status;
    if (body.outcome !== undefined) data.outcome = body.outcome;
    if (body.notes !== undefined) data.notes = body.notes;
    if (body.dueAt !== undefined) data.dueAt = body.dueAt;
    if (body.priority !== undefined) data.priority = body.priority;

    // P9-D10 — REASSIGNMENT: MANAGER+ only, org-validated (404-ghost on a
    // foreign id — never silently links), with the assignment trail below.
    // Reassignment preserves historical accountability: the ASSIGNMENT
    // activity + TASK_OWNER_CHANGED audit commit with the change itself.
    let ownerChanged = false;
    if (body.ownerId !== undefined && body.ownerId !== task.ownerId) {
      if (!atLeastRole(user.role, "MANAGER")) {
        throw new ApiError(
          403,
          "Seul un manager peut réassigner une tâche",
          "TASK_REASSIGN_FORBIDDEN",
        );
      }
      if (body.ownerId !== null) {
        const owner = await db.user.findFirst({ where: { id: body.ownerId, orgId }, select: { id: true } });
        if (!owner) throw new ApiError(422, "Destinataire (ownerId) introuvable", "OWNER_NOT_FOUND");
      }
      data.ownerId = body.ownerId;
      ownerChanged = true;
    }

    // G5-P3-5 (F-06): task update + its DONE timeline entry + the TASK_UPDATED
    // audit row commit as ONE transaction (§41 FR41p/q — no DONE task without
    // its activity row; API-07 — no updated task without its audit row).
    const updated = await db.$transaction(async (tx) => {
      const row = await tx.task.update({
        where: { id: task.id },
        data,
        include: taskInclude,
      });
      injectTxFault(req, "tasks-patch");
      // P9-D10 — the reassignment trail (only when the owner actually
      // moved): ASSIGNMENT activity on the lead timeline + audit row, the
      // leads-route law. Unattached tasks carry the audit trail alone.
      if (ownerChanged) {
        if (task.leadId) {
          await logActivity({
            orgId,
            actorId: user.id,
            leadId: task.leadId,
            opportunityId: task.opportunityId,
            taskId: task.id,
            type: "ASSIGNMENT",
            title: "Tâche réassignée",
            meta: { before: { ownerId: task.ownerId }, after: { ownerId: body.ownerId ?? null } },
          }, tx);
        }
        await logAudit({
          orgId,
          actor: user,
          action: "TASK_OWNER_CHANGED",
          entity: "TASK",
          entityId: task.id,
          before: { ownerId: task.ownerId },
          after: { ownerId: body.ownerId ?? null },
        }, tx);
      }
      if (body.status === "DONE" && task.status !== "DONE") {
        await logActivity({
          orgId,
          actorId: user.id,
          leadId: task.leadId,
          opportunityId: task.opportunityId,
          taskId: task.id,
          type: "TASK",
          title: "Tâche terminée",
          body: (body.outcome ?? task.outcome ?? undefined) ?? null,
          meta: { taskTitle: task.title, type: task.type },
        }, tx);
        // W3-3 (Phase 2.1 — A4#4): completing a FOLLOW_UP task fulfils an
        // overdue lead follow-up commitment — clear it in the same tx
        // (updateMany is conditional: only rows whose commitment is past
        // due; future commitments stay).
        if (task.type === "FOLLOW_UP" && task.leadId) {
          await tx.lead.updateMany({
            where: { id: task.leadId, orgId, nextFollowUpAt: { lte: new Date() } },
            data: { nextFollowUpAt: null },
          });
        }
      }
      // API-07 (audit completeness): the update path used to commit with
      // ZERO audit rows — TASK_CREATED/TASK_DELETED existed while a
      // status/priority change was invisible to the admin trail (the B4
      // field-edit law). TASK_UPDATED carries the before/after status/
      // priority dimensions (the opportunities route's snapshot style);
      // a field-less {} PATCH stays silent — no audit noise (the
      // OPPORTUNITY_VALUE_CHANGED no-op law).
      if (Object.keys(data).length > 0) {
        await logAudit({
          orgId,
          actor: user,
          action: "TASK_UPDATED",
          entity: "TASK",
          entityId: task.id,
          before: { status: task.status, priority: task.priority },
          after: { status: row.status, priority: row.priority },
        }, tx);
      }
      return row;
    });

    return ok({ task: updated });
  } catch (error) {
    return fail(error);
  }
}

// ── DELETE ────────────────────────────────────────────────────────────────────

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    // D-021 — same visibility predicate on the delete path (RBAC layer below stays).
    const task = await db.task.findFirst({ where: { id, orgId, ...taskScope(user) } });
    if (!task) throw new ApiError(404, "Tâche introuvable", "TASK_NOT_FOUND");

    // RBAC — server-enforced: task owner or MANAGER+ (UI hiding ≠ authorization).
    if (task.ownerId !== user.id && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(
        403,
        "Seul le propriétaire de la tâche ou un manager peut la supprimer",
        "FORBIDDEN_ROLE"
      );
    }

    // Activity.taskId is SetNull — the timeline survives with the link cleared.
    // G5-P3-5 (F-06): deletion + its audit row commit as ONE transaction.
    await db.$transaction(async (tx) => {
      await tx.task.delete({ where: { id: task.id } });
      injectTxFault(req, "tasks-delete");
      await logAudit({
        orgId,
        actor: user,
        action: "TASK_DELETED",
        entity: "TASK",
        entityId: task.id,
        before: {
          title: task.title,
          type: task.type,
          status: task.status,
          dueAt: task.dueAt,
          ownerId: task.ownerId,
          leadId: task.leadId,
        },
        after: null,
      }, tx);
    });

    return ok({ deleted: true, id: task.id });
  } catch (error) {
    return fail(error);
  }
}
