// ASAS — Export bundle (P7-4): one-click full-snapshot archive for
// backup/handoff. GET /api/export/bundle → ZIP with 5 entity CSVs + manifest.
// Role: MANAGER+ (same permission family as the leads CSV export).
//
// Conventions inherited from leads/export (P4-8): semicolon separator, UTF-8
// BOM, CRLF, formula-sigil defanging on free-text columns via csvEscape;
// normalized columns (ids, enums, ISO dates, E.164, non-negative numbers)
// stay raw. An EXPORT_BUNDLE audit entry records the per-entity row counts.
// Snapshots are bounded (take ≤ 5 000 rows per entity, same ceiling as the
// leads export) — larger datasets need paginated exports (not in scope).
//
// P19 (D-025 alignment): reservations.csv carries the deal economics
// (commissionAmount + commissionFrom + agentIncentive — the ONLY money in the
// CRM, the data contract for the future ERP) and visites.csv carries the
// on-site confirmation stamps (confirmedAt + confirmedBy) — the operating
// model's appointment truth travels with the export.

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { csvDocument, csvEscape } from "@/lib/server/csv";
import { createZip } from "@/lib/server/zip";
import { displayPhone } from "@/lib/phone";

const TAKE = 5000;

const LEAD_HEADERS = [
  "id",
  "fullName",
  "phone",
  "phoneDisplay",
  "email",
  "source",
  "campaign",
  "status",
  "priority",
  "score",
  "budgetMin",
  "budgetMax",
  "propertyType",
  "desiredLocation",
  "owner",
  "tags",
  "createdAt",
  "lastContactAt",
  "nextFollowUpAt",
  "lostReason",
  "archived",
] as const;

const OPPORTUNITY_HEADERS = [
  "id",
  "title",
  "lead",
  "project",
  "stage",
  "value",
  "probability",
  "owner",
  "expectedCloseAt",
  "nextAction",
  "nextActionAt",
  "lostReason",
  "closedAt",
  "createdAt",
] as const;

const VISIT_HEADERS = [
  "id",
  "lead",
  "agent",
  "scheduledAt",
  "proposedAt",
  "durationMin",
  "location",
  "status",
  "confirmedAt",
  "confirmedBy",
  "rejectionReason",
  "attended",
  "outcome",
  "followUpRequired",
  "nextAction",
  "createdAt",
] as const;

const TASK_HEADERS = [
  "id",
  "title",
  "owner",
  "lead",
  "type",
  "dueAt",
  "priority",
  "status",
  "outcome",
  "createdAt",
] as const;

const RESERVATION_HEADERS = [
  "id",
  "opportunity",
  "apartment",
  "project",
  "agent",
  "amount",
  "depositPaid",
  "commissionAmount",
  "commissionFrom",
  "agentIncentive",
  "status",
  "expiresAt",
  "notary",
  "contractRef",
  "reason",
  "createdAt",
] as const;

function iso(d: Date | null | undefined): string {
  return d ? d.toISOString() : "";
}

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("export.run");
    const orgId = user.orgId;

    const [org, leads, opportunities, visits, tasks, reservations] = await Promise.all([
      db.organization.findUnique({ where: { id: orgId }, select: { name: true } }),
      db.lead.findMany({
        where: { orgId },
        orderBy: { createdAt: "desc" },
        take: TAKE,
        include: {
          owner: { select: { name: true } },
          tags: { include: { tag: { select: { name: true } } } },
        },
      }),
      db.opportunity.findMany({
        where: { orgId },
        orderBy: { createdAt: "desc" },
        take: TAKE,
        include: {
          lead: { select: { fullName: true } },
          project: { select: { name: true } },
          owner: { select: { name: true } },
        },
      }),
      db.visit.findMany({
        where: { orgId },
        orderBy: { scheduledAt: "desc" },
        take: TAKE,
        include: {
          lead: { select: { fullName: true } },
          agent: { select: { name: true } },
          confirmedBy: { select: { name: true } },
        },
      }),
      db.task.findMany({
        where: { orgId },
        orderBy: { dueAt: "desc" },
        take: TAKE,
        include: {
          owner: { select: { name: true } },
          lead: { select: { fullName: true } },
        },
      }),
      // Reservation.agentId carries no Prisma relation (house pattern — join
      // agent names in memory, same as /api/reservations).
      db.reservation.findMany({
        where: { orgId },
        orderBy: { createdAt: "desc" },
        take: TAKE,
        include: {
          opportunity: { select: { title: true } },
          apartment: { select: { code: true, building: { select: { name: true, project: { select: { name: true } } } } } },
        },
      }),
    ]);

    const agentIds = Array.from(
      new Set(reservations.map((r) => r.agentId).filter((id): id is string => id !== null)),
    );
    const agents = agentIds.length
      ? await db.user.findMany({ where: { id: { in: agentIds } }, select: { id: true, name: true } })
      : [];
    const agentMap = new Map(agents.map((a) => [a.id, a.name]));

    const prospectsCsv = csvDocument(
      LEAD_HEADERS,
      leads.map((l) => [
        l.id,
        csvEscape(l.fullName),
        l.phone,
        csvEscape(displayPhone(l.phone)),
        csvEscape(l.email),
        l.source,
        csvEscape(l.campaign),
        l.status,
        l.priority,
        l.score,
        l.budgetMin ?? "",
        l.budgetMax ?? "",
        l.propertyType ?? "",
        csvEscape(l.desiredLocation),
        csvEscape(l.owner?.name ?? ""),
        csvEscape(l.tags.map((t) => t.tag.name).join(", ")),
        l.createdAt.toISOString(),
        iso(l.lastContactAt),
        iso(l.nextFollowUpAt),
        csvEscape(l.lostReason),
        l.archived ? "true" : "false",
      ]),
    );

    const opportunitiesCsv = csvDocument(
      OPPORTUNITY_HEADERS,
      opportunities.map((o) => [
        o.id,
        csvEscape(o.title),
        csvEscape(o.lead?.fullName ?? ""),
        csvEscape(o.project?.name ?? ""),
        o.stage,
        o.value ?? "",
        o.probability,
        csvEscape(o.owner?.name ?? ""),
        iso(o.expectedCloseAt),
        csvEscape(o.nextAction),
        iso(o.nextActionAt),
        csvEscape(o.lostReason),
        iso(o.closedAt),
        o.createdAt.toISOString(),
      ]),
    );

    const visitsCsv = csvDocument(
      VISIT_HEADERS,
      visits.map((v) => [
        v.id,
        csvEscape(v.lead?.fullName ?? ""),
        csvEscape(v.agent?.name ?? ""),
        v.scheduledAt.toISOString(),
        v.proposedAt.toISOString(),
        v.durationMin ?? "",
        csvEscape(v.location),
        v.status,
        iso(v.confirmedAt),
        csvEscape(v.confirmedBy?.name ?? ""),
        csvEscape(v.rejectionReason ?? ""),
        v.attended == null ? "" : v.attended ? "true" : "false",
        csvEscape(v.outcome),
        v.followUpRequired ? "true" : "false",
        csvEscape(v.nextAction),
        v.createdAt.toISOString(),
      ]),
    );

    const tasksCsv = csvDocument(
      TASK_HEADERS,
      tasks.map((k) => [
        k.id,
        csvEscape(k.title),
        csvEscape(k.owner?.name ?? ""),
        csvEscape(k.lead?.fullName ?? ""),
        k.type,
        k.dueAt.toISOString(),
        k.priority,
        k.status,
        csvEscape(k.outcome),
        k.createdAt.toISOString(),
      ]),
    );

    const reservationsCsv = csvDocument(
      RESERVATION_HEADERS,
      reservations.map((r) => [
        r.id,
        csvEscape(r.opportunity?.title ?? ""),
        csvEscape(r.apartment ? `${r.apartment.building.name}-${r.apartment.code}` : ""),
        csvEscape(r.apartment?.building.project.name ?? ""),
        csvEscape(r.agentId ? agentMap.get(r.agentId) ?? "" : ""),
        r.amount ?? "",
        r.depositPaid ?? "",
        r.commissionAmount ?? "",
        r.commissionFrom ?? "",
        r.agentIncentive ?? "",
        r.status,
        iso(r.expiresAt),
        csvEscape(r.notary),
        csvEscape(r.contractRef),
        csvEscape(r.reason),
        r.createdAt.toISOString(),
      ]),
    );

    const exportedAt = new Date();
    const counts = {
      prospects: leads.length,
      opportunites: opportunities.length,
      visites: visits.length,
      taches: tasks.length,
      reservations: reservations.length,
    };
    const manifest = [
      "ASAS — CRM Immobilier — Export complet",
      `Organisation : ${org?.name ?? orgId}`,
      `Généré le : ${exportedAt.toISOString()}`,
      `Par : ${user.name} (${user.role})`,
      "",
      "Contenu :",
      `  - prospects.csv      : ${counts.prospects} ligne(s) — instantané complet, archivés inclus`,
      `  - opportunites.csv   : ${counts.opportunites} ligne(s)`,
      `  - visites.csv        : ${counts.visites} ligne(s) — créneau proposé d'origine + refus motivé inclus`,
      `  - taches.csv         : ${counts.taches} ligne(s)`,
      `  - reservations.csv   : ${counts.reservations} ligne(s) — économie du deal incluse`,
      "",
      "Format des CSV : séparateur « ; », encodage UTF-8 avec BOM, fins de ligne CRLF",
      "(ouverture directe dans Excel FR). Les cellules dont le premier caractère est",
      "= + - @ sont préfixées d'une apostrophe (protection contre l'injection de formules).",
      "Les snapshots sont plafonnés à 5 000 lignes par entité.",
    ].join("\r\n");

    const zip = createZip([
      { name: "prospects.csv", data: prospectsCsv },
      { name: "opportunites.csv", data: opportunitiesCsv },
      { name: "visites.csv", data: visitsCsv },
      { name: "taches.csv", data: tasksCsv },
      { name: "reservations.csv", data: reservationsCsv },
      { name: "MANIFEST.txt", data: manifest },
    ]);

    await logAudit({
      orgId,
      actor: user,
      action: "EXPORT_BUNDLE",
      entity: "ORG",
      after: { counts, totalRows: Object.values(counts).reduce((a, b) => a + b, 0) },
    });

    const stamp = exportedAt.toISOString().slice(0, 10);
    return new NextResponse(new Uint8Array(zip), {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="asas-export-${stamp}.zip"`,
        "Cache-Control": "no-store",
        // Same-origin fetch — readable by the client for the success toast.
        "X-Asas-Rows": String(Object.values(counts).reduce((a, b) => a + b, 0)),
      },
    });
  } catch (error) {
    if (error instanceof ApiError && error.status === 403) {
      return NextResponse.json(
        { error: "L'export complet requiert le rôle Manager ou supérieur.", code: "EXPORT_FORBIDDEN" },
        { status: 403 },
      );
    }
    return fail(error);
  }
}
