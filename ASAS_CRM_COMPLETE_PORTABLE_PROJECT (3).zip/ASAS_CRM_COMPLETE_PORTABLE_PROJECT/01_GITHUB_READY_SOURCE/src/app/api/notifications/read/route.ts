// ASAS — P10-1: POST /api/notifications/read — persist read-state watermarks.
//
// Body: { keys: string[] } — a subset of the CLOSED notification-group
// vocabulary (unknown keys → 422 UNKNOWN_NOTIFICATION_KEYS; the vocabulary
// bounds the table: no free-text growth vector). Response: the user's full
// readState map (the client swaps it in — one round-trip, no follow-up GET).
//
// Not audited by design: marking a bell item read is a UI preference, not a
// security event (contrast: LOGIN, SAVED_SEARCH_SHARED — state the business
// or an auditor needs). No org scoping needed — rows are keyed (userId, key)
// and the route resolves the user from the session.

import type { NextRequest } from "next/server";
import { z } from "zod";
import {
  isNotificationKey,
  markNotificationsRead,
  MAX_MARK_KEYS,
} from "@/lib/server/notification-read";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

const schema = z.object({
  keys: z
    .array(z.string().trim().min(1))
    .min(1, "keys requis")
    .max(MAX_MARK_KEYS, "Trop de clés par appel"),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, schema);

    // Closed vocabulary gate — silently growing the table with arbitrary keys
    // is a bug class, not a user action: reject with the offending list.
    const unknown = body.keys.filter((k) => !isNotificationKey(k));
    if (unknown.length > 0) {
      throw new ApiError(422, "Clés de notification inconnues", "UNKNOWN_NOTIFICATION_KEYS", {
        unknown: unknown.slice(0, 5),
      });
    }

    const readState = await markNotificationsRead(user.id, [...new Set(body.keys)]);
    return ok({ readState });
  } catch (error) {
    return fail(error);
  }
}
