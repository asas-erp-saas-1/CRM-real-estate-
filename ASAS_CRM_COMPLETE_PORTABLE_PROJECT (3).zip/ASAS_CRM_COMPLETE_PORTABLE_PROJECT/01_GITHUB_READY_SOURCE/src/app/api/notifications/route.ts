// ASAS — Notifications (master prompt §45: meaningful, not spam).
// Computed LIVE from domain sources of truth (tasks/visits/leads/reservations
// domains own their state — §49); nothing is persisted or duplicated here.
// Server returns semantic payloads; the frontend renders translated labels.
//
// GET /api/notifications
// Scope: SALES_AGENT → own + unassigned items; MANAGER+ → org-wide.
// Shape: { data: Notification[], generatedAt, readState }
// Notification: { key, type, severity, occurredAt, count, view, leadId?, items[] }
// readState (P10-1): per-USER group-key → readAt watermark map — appended AFTER
// the scope-shared cache retrieval (never cached: it mutates on every mark-read
// and is per-user, while the computed payload is per-scope).

import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ACTIVE_VISIT_STATUSES, FIELD_PENDING_STATUSES, atLeastRole } from "@/lib/constants";
import { expireDueReservations } from "@/lib/server/expiry";
// E2E-FINAL (D9) — the sweeper's time dimension: boot the in-process
// interval on first API traffic (singleton; see expiry-scheduler.ts).
import "@/lib/server/expiry-scheduler";
import { isFieldRep, leadScope, reservationScope, taskScope, visitScope } from "@/lib/server/visibility";
import { pendingDuplicatePairsCached } from "@/lib/server/duplicates";
import { getOrgSettings } from "@/lib/server/settings";
import { notificationCache, notificationCacheKey } from "@/lib/server/notification-cache";
import { getReadState } from "@/lib/server/notification-read";
import { fail, ok, requireUser } from "@/lib/server/session";
import { startOfDay } from "@/lib/dates"; // G5-P4-2 — shared helper (was a local duplicate)

type Severity = "urgent" | "warning" | "info";

interface NotifItem {
  id: string;
  label: string; // entity name (task title / lead name / visit code line)
  leadId?: string | null;
}

interface Notification {
  key: string;
  type:
    | "TASKS_OVERDUE"
    | "TASKS_TODAY"
    | "VISITS_TODAY"
    | "VISITS_TOMORROW"
    | "LEADS_UNCONTACTED"
    | "LEADS_UNASSIGNED"
    | "RESERVATIONS_EXPIRING"
    | "RESERVATIONS_CLOSURE_REQUESTED"
    | "INCENTIVES_PENDING"
    | "VISITS_RECONFIRM"
    | "VISITS_FIELD_DECISION"
    | "VISITS_REPORTED"
    | "LEADS_DUPLICATES";
  severity: Severity;
  occurredAt: string; // most recent relevant timestamp (drives unread logic)
  count: number;
  view: "tasks" | "visits" | "leads" | "properties" | "dashboard" | "pipeline";
  items: NotifItem[]; // capped at 5 — actionable without spam
}

const DAY_MS = 86_400_000;

// P10-1 — occurredAt CORRECTION LAW. The read-state watermark (readAt) is
// compared against each group's occurredAt: "when did this backlog last
// change". Three anchor defects made that comparison unsound and were fixed
// with this pass (all verified live: groups re-fired seconds after every
// mark-all-read, or never settled):
//   · `new Date()` stamps (leads-uncontacted/-unassigned) oscillated on EVERY
//     30 s recompute — the badge re-fired itself, forever.
//   · FUTURE anchors (visits-tomorrow = tomorrow 00:00, visits-reconfirm =
//     proposedAt/scheduledAt of a future slot, reservations-expiring =
//     expiresAt) stayed ahead of any readAt — permanently unread.
//   · Day-list groups anchored on a future slot time (visits-today) re-fired
//     for the same reason.
// THE LAW: occurredAt is always a stable PAST moment — the newest arrival /
// state-change among the group's rows (max stamp), or the day-start for
// "today's list" groups. Future-dated display info (slot times, expiries)
// never serves as the watermark anchor.
function latestOf(dates: Date[]): Date {
  return dates.reduce((acc, d) => (d > acc ? d : acc), dates[0] ?? new Date(0));
}

export async function GET(_req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;

    // P2/W3 (Agent 4) — scoped 30s TTL cache: the payload is a pure read of
    // slow-moving backlog state; every tab / refocus burst within the TTL now
    // shares ONE computation (measured: ~35 queries per manager poll, ~16 per
    // agent — see notification-cache.ts for the entry-gate numbers). The key
    // mirrors the route's visibility law (managers share the org bucket;
    // agent/field scopes are per-user) — no cross-visibility leakage is
    // possible. Freshness bound = TTL 30 s = the client staleTime contract.
    const cacheKey = notificationCacheKey(user);
    const cached = notificationCache.get(cacheKey);
    // P10-1 — the read-state is per-USER (mutates on mark-read) while the
    // computed payload is per-SCOPE (cached): append it AFTER retrieval, into
    // a NEW object — the cached entry must never carry user-specific state.
    if (cached) {
      return ok({ ...cached, readState: await getReadState(user.id) });
    }

    // lazy sweeper — P2-R2: expire past-due ACTIVE reservations before reading
    // (awaited; idempotent no-op when nothing is due). Runs on cache misses
    // only — the in-process expiry-scheduler keeps sweeping independently.
    await expireDueReservations();

    const isManager = atLeastRole(user.role, "MANAGER");
    // P18 (D-025): the bell follows the shared visibility primitives — agents
    // see own+unassigned work, FIELD_REPs see their assigned-project agenda +
    // own tasks (no sales pool); managers see everything.
    const taskOwner = taskScope(user) ?? {};
    const visitAgent = visitScope(user) ?? {};
    const leadOwner = leadScope(user) ?? {};
    // G5-P3-1 (F-02 fix, D-GOV-5): the expiring-reservation aggregate now follows
    // the same shared visibility primitive as every other group — was org-wide
    // to SALES_AGENT/FIELD_REP (runtime-confirmed GOV-2 B-1: foreign lead names
    // in the bell). `reservationScope` returns undefined for MANAGER+ (org-wide).
    const reservationAgent = reservationScope(user) ?? {};

    const now = new Date();
    const todayStart = startOfDay(now);
    const tomorrowStart = new Date(todayStart.getTime() + DAY_MS);
    const dayAfterTomorrow = new Date(todayStart.getTime() + 2 * DAY_MS);

    // Tunable thresholds (Settings view, R5) — defaults: 24h freshness, 7-day window.
    const settings = await getOrgSettings(orgId);
    const uncontactedCutoff = new Date(now.getTime() - settings["notifications.uncontactedHours"] * 3_600_000);
    const expiringHorizon = new Date(now.getTime() + settings["notifications.expiringReservationsDays"] * DAY_MS);

    const [overdueTasks, todayTasks, todayVisits, tomorrowVisits, uncontactedLeads, unassignedLeads, unassignedAnchor, expiringReservations] =
      await Promise.all([
        db.task.findMany({
          where: { orgId, status: "OPEN", dueAt: { lt: now }, ...taskOwner },
          // P10-1 — desc: items show the NEWEST overdue slip first (what just
          // fell behind is the actionable end), and occurredAt anchors on it.
          orderBy: { dueAt: "desc" },
          take: 5,
          include: { lead: { select: { id: true, fullName: true } } },
        }),
        db.task.count({
          where: { orgId, status: "OPEN", dueAt: { gte: now, lt: tomorrowStart }, ...taskOwner },
        }),
        db.visit.findMany({
          where: {
            orgId,
            status: { in: [...ACTIVE_VISIT_STATUSES] }, // R15 — shared set (was an inline pair)
            scheduledAt: { gte: todayStart, lt: tomorrowStart },
            ...visitAgent,
          },
          orderBy: { scheduledAt: "asc" },
          take: 5,
          include: { lead: { select: { id: true, fullName: true } }, project: { select: { name: true } } },
        }),
        db.visit.count({
          where: {
            orgId,
            status: { in: [...ACTIVE_VISIT_STATUSES] }, // R15 — shared set (was an inline pair)
            scheduledAt: { gte: tomorrowStart, lt: dayAfterTomorrow },
            ...visitAgent,
          },
        }),
        db.lead.findMany({
          where: { orgId, status: "NEW", lastContactAt: null, archived: false, ...leadOwner },
          orderBy: { createdAt: "desc" },
          take: 5,
          select: { id: true, fullName: true, createdAt: true },
        }),
        // P9-D24 — the unassigned count renders MANAGER+ only; running it
        // for every role was a wasted org-wide count per agent poll.
        // P10-1 — the manager branch also fetches the newest unassigned
        // arrival (createdAt) as the group's stable PAST watermark anchor.
        isManager
          ? db.lead.count({
              where: { orgId, status: "NEW", ownerId: null, archived: false },
            })
          : Promise.resolve(0),
        isManager
          ? db.lead.findFirst({
              where: { orgId, status: "NEW", ownerId: null, archived: false },
              orderBy: { createdAt: "desc" },
              select: { createdAt: true },
            })
          : Promise.resolve(null),
        db.reservation.findMany({
          where: {
            orgId,
            // G5-P3-2: a closure request does not stop the hold's clock — the
            // expiring warning covers CLOSURE_REQUESTED holds too (the agent's
            // pending request still dies at expiry).
            status: { in: ["ACTIVE", "CLOSURE_REQUESTED"] },
            expiresAt: { gte: now, lt: expiringHorizon },
            ...reservationAgent,
          },
          orderBy: { expiresAt: "asc" },
          take: 5,
          include: {
            apartment: { select: { id: true, code: true } },
            opportunity: { select: { lead: { select: { id: true, fullName: true } } } },
          },
        }),
      ]);

    const notifications: Notification[] = [];

    // ── Urgent: overdue follow-ups/tasks ──
    if (overdueTasks.length > 0) {
      const total = await db.task.count({
        where: { orgId, status: "OPEN", dueAt: { lt: now }, ...taskOwner },
      });
      notifications.push({
        key: "tasks-overdue",
        type: "TASKS_OVERDUE",
        severity: total > 5 ? "urgent" : "warning",
        // P10-1 — desc order: the newest slip anchors the watermark (a task
        // that JUST fell overdue re-fires the badge; the ancient ones don't).
        occurredAt: overdueTasks[0]!.dueAt.toISOString(),
        count: total,
        view: "tasks",
        items: overdueTasks.map((t) => ({
          id: t.id,
          label: t.title,
          leadId: t.leadId,
        })),
      });
    }

    // ── Today's tasks ──
    if (todayTasks > 0) {
      notifications.push({
        key: "tasks-today",
        type: "TASKS_TODAY",
        severity: "info",
        occurredAt: todayStart.toISOString(),
        count: todayTasks,
        view: "tasks",
        items: [],
      });
    }

    // ── Today's visits (rare + high value → individual items) ──
    if (todayVisits.length > 0) {
      notifications.push({
        key: "visits-today",
        type: "VISITS_TODAY",
        severity: "warning",
        // P10-1 — day-anchored (the agenda became current TODAY): a future
        // slot time (18:00 tonight) would sit ahead of every readAt and keep
        // the group permanently unread.
        occurredAt: todayStart.toISOString(),
        count: todayVisits.length,
        view: "visits",
        items: todayVisits.map((v) => ({
          id: v.id,
          label: v.lead?.fullName ?? "—",
          leadId: v.leadId,
        })),
      });
    }

    // ── Tomorrow's visits ──
    if (tomorrowVisits > 0) {
      notifications.push({
        key: "visits-tomorrow",
        type: "VISITS_TOMORROW",
        severity: "info",
        // P10-1 — day-anchored: tomorrow 00:00 is a FUTURE stamp (permanently
        // unread); the reminder became current today, so today anchors it.
        occurredAt: todayStart.toISOString(),
        count: tomorrowVisits,
        view: "visits",
        items: [],
      });
    }

    // ── New leads never contacted (aging > threshold = warning, else info) ──
    if (uncontactedLeads.length > 0) {
      const total = await db.lead.count({
        where: { orgId, status: "NEW", lastContactAt: null, archived: false, ...leadOwner },
      });
      const oldest = uncontactedLeads[uncontactedLeads.length - 1]!.createdAt;
      notifications.push({
        key: "leads-uncontacted",
        type: "LEADS_UNCONTACTED",
        severity: oldest < uncontactedCutoff ? "warning" : "info",
        // P10-1 — newest arrival (desc[0]) anchors the watermark: a new lead
        // landing re-fires the badge; the former `new Date()` stamp re-fired
        // it on every 30 s recompute.
        occurredAt: uncontactedLeads[0]!.createdAt.toISOString(),
        count: total,
        view: "leads",
        items: uncontactedLeads.map((l) => ({ id: l.id, label: l.fullName, leadId: l.id })),
      });
    }

    // ── Unassigned leads (managers only — they distribute work) ──
    if (isManager && unassignedLeads > 0) {
      notifications.push({
        key: "leads-unassigned",
        type: "LEADS_UNASSIGNED",
        severity: "info",
        // P10-1 — newest unassigned arrival anchors the watermark (PAST — the
        // former `new Date()` stamp oscillated with every recompute).
        occurredAt: (unassignedAnchor?.createdAt ?? todayStart).toISOString(),
        count: unassignedLeads,
        view: "leads",
        items: [],
      });
    }

    // ── Reservations expiring within 7 days ──
    if (expiringReservations.length > 0) {
      notifications.push({
        key: "reservations-expiring",
        type: "RESERVATIONS_EXPIRING",
        severity: "warning",
        // P10-1 — newest hold PLACEMENT anchors the watermark (createdAt — PAST;
        // expiresAt is future-dated display info and kept the group
        // permanently unread). Items stay ordered by soonest expiry (the
        // act-first list); the watermark tracks arrivals, not urgency order.
        occurredAt: latestOf(expiringReservations.map((r) => r.createdAt)).toISOString(),
        count: expiringReservations.length,
        view: "properties",
        items: expiringReservations.map((r) => ({
          id: r.id,
          label: `${r.apartment?.code ?? "—"} — ${r.opportunity?.lead?.fullName ?? "—"}`,
          leadId: r.opportunity?.lead?.id ?? null,
        })),
      });
    }

    // ── P46 (W1) — §38 pending incentive decisions (MANAGER+ only: the
    // approval machine's queue — money proposed, no human decision yet).
    // Warning tier (a decision backlog is attention, D-UX-015); the group
    // deep-links to the dashboard where the queue panel lives. Items keep
    // leadId so an item click opens the prospect drawer (group context:
    // unit — client · rep).
    if (isManager) {
      const pendingIncentives = await db.reservation.findMany({
        where: { orgId, incentiveStatus: "PENDING", agentIncentive: { not: null } },
        orderBy: { updatedAt: "desc" },
        take: 5,
        include: {
          apartment: { select: { code: true } },
          opportunity: { select: { lead: { select: { id: true, fullName: true } } } },
        },
      });
      if (pendingIncentives.length > 0) {
        const totalPending = await db.reservation.count({
          where: { orgId, incentiveStatus: "PENDING", agentIncentive: { not: null } },
        });
        // The agentId pattern: no Prisma relation — the rep's name is joined
        // in-memory from the org's users.
        const agentIds = [...new Set(pendingIncentives.map((x) => x.agentId).filter((x): x is string => x != null))];
        const agents = agentIds.length
          ? await db.user.findMany({ where: { id: { in: agentIds } }, select: { id: true, name: true } })
          : [];
        const agentById = new Map(agents.map((a) => [a.id, a]));
        notifications.push({
          key: "incentives-pending",
          type: "INCENTIVES_PENDING",
          severity: "warning",
          occurredAt: pendingIncentives[0]!.updatedAt.toISOString(),
          count: totalPending,
          view: "dashboard",
          items: pendingIncentives.map((res) => ({
            id: res.id,
            label: `${res.apartment?.code ?? "—"} — ${res.opportunity?.lead?.fullName ?? "—"} · ${res.agentId ? agentById.get(res.agentId)?.name ?? "—" : "—"}`,
            leadId: res.opportunity?.lead?.id ?? null,
          })),
        });
      }
    }

    // ── G5-P3-2 (D-GOV-5 §9.2) — pending sale-closure validations
    // (MANAGER+ only: the two-step closure's decision queue — an agent has
    // prepared the request with evidence; the money-state change waits for
    // a manager). Warning tier (a decision backlog is attention, D-UX-015);
    // items keep leadId so a click opens the prospect drawer; view = pipeline
    // (the deal's home, where DealEconomics carries the validate/reject
    // controls).
    if (isManager) {
      const closureQueue = await db.reservation.findMany({
        where: { orgId, status: "CLOSURE_REQUESTED" },
        orderBy: { closureRequestedAt: "asc" },
        take: 5,
        include: {
          apartment: { select: { code: true } },
          opportunity: { select: { lead: { select: { id: true, fullName: true } } } },
        },
      });
      if (closureQueue.length > 0) {
        const totalClosure = await db.reservation.count({
          where: { orgId, status: "CLOSURE_REQUESTED" },
        });
        notifications.push({
          key: "closures-pending",
          type: "RESERVATIONS_CLOSURE_REQUESTED",
          severity: "warning",
          // P10-1 — the newest REQUEST anchors the watermark (a request that
          // just landed re-fires the badge); the queue display stays
          // oldest-first (act on the waiting-longest request).
          occurredAt: latestOf(closureQueue.map((r) => r.closureRequestedAt ?? r.createdAt)).toISOString(),
          count: totalClosure,
          view: "pipeline",
          items: closureQueue.map((res) => ({
            id: res.id,
            label: `${res.apartment?.code ?? "—"} — ${res.opportunity?.lead?.fullName ?? "—"}`,
            leadId: res.opportunity?.lead?.id ?? null,
          })),
        });
      }
    }

    // ── P49 — customer-reconfirmation backlog (D-UX-057 agent-side: the
    // counter-proposed visits whose customer has not agreed yet). The
    // today/tomorrow groups above cannot carry these — a counter moves the
    // slot DAYS out; without this group the state was findable only by
    // scanning the visits list for amber chips. Warning tier (a decision
    // backlog is attention, D-UX-015). Scope = the D-026 authority: the
    // visit's agent sees their OWN backlog (agentId = user.id — not the
    // visitScope pool clause: an agent cannot reconfirm a pool visit);
    // MANAGER+ sees org-wide; FIELD_REPs get nothing (they countered — the
    // customer loop is the agent's decision, not theirs). Items keep leadId
    // so an item click opens the prospect drawer; the group routes to the
    // visits view where the P49 filter chip isolates the state.
    if (!isFieldRep(user)) {
      const reconfirmVisits = await db.visit.findMany({
        where: {
          orgId,
          status: "SCHEDULED",
          awaitingCustomerReconfirm: true,
          ...(isManager ? {} : { agentId: user.id }),
        },
        orderBy: { scheduledAt: "asc" },
        take: 5,
        include: {
          lead: { select: { id: true, fullName: true } },
          project: { select: { name: true } },
        },
      });
      if (reconfirmVisits.length > 0) {
        const totalReconfirm = await db.visit.count({
          where: {
            orgId,
            status: "SCHEDULED",
            awaitingCustomerReconfirm: true,
            ...(isManager ? {} : { agentId: user.id }),
          },
        });
        notifications.push({
          key: "visits-reconfirm",
          type: "VISITS_RECONFIRM",
          severity: "warning",
          // P10-1 — the state-arose moment: when the counter was filed /
          // the row last changed (updatedAt — PAST). proposedAt/scheduledAt
          // are future-dated slots (permanently-unread anchors).
          occurredAt: latestOf(reconfirmVisits.map((v) => v.updatedAt)).toISOString(),
          count: totalReconfirm,
          view: "visits",
          items: reconfirmVisits.map((v) => ({
            id: v.id,
            label: `${v.lead?.fullName ?? "—"}${v.project?.name ? ` · ${v.project.name}` : ""}`,
            leadId: v.leadId,
          })),
        });
      }
    }

    // ── P50 — the FIELD_REP's decision backlog (D-UX-057 on the last persona
    // class): SCHEDULED/RESCHEDULED proposals awaiting the field side's
    // CONFIRM/REJECT/COUNTER. The today/tomorrow groups above cannot carry a
    // proposal DAYS out (the P49 structural limitation) and do not
    // distinguish a pending proposal from an agreed slot even when they do
    // carry it — without this group the rep's queue was findable only by
    // scanning the visits list for «Planifiée» rows. Warning tier (a decision
    // backlog is attention, D-UX-015). Scope = the D-UX-060 authority: the
    // FIELD_REP sees their OWN assigned-project backlog (the live
    // canConfirmVisit basis); MANAGER+ sees the org-wide count on STAFFED
    // projects only (the unstaffed exception has its own surfaces — §17.3);
    // SALES_AGENTs get nothing (no authority — their loop is the reconfirm
    // group above). Items keep leadId so an item click opens the prospect
    // drawer; the group routes to the visits view where the P50 filter chip
    // isolates the decision rows.
    if (user.role !== "SALES_AGENT") {
      const fieldDecisionWhere = {
        orgId,
        status: { in: [...FIELD_PENDING_STATUSES] },
        awaitingCustomerReconfirm: false,
        ...(isFieldRep(user)
          ? { project: { assignments: { some: { userId: user.id } } } }
          : {
              project: {
                assignments: { some: { user: { active: true, role: "FIELD_REP" } } },
              },
            }),
      };
      const fieldVisits = await db.visit.findMany({
        where: fieldDecisionWhere,
        orderBy: { scheduledAt: "asc" },
        take: 5,
        include: {
          lead: { select: { id: true, fullName: true } },
          project: { select: { name: true } },
        },
      });
      if (fieldVisits.length > 0) {
        const totalField = await db.visit.count({ where: fieldDecisionWhere });
        notifications.push({
          key: "visits-field-decision",
          type: "VISITS_FIELD_DECISION",
          severity: "warning",
          // P10-1 — the state-arose moment (updatedAt — PAST): scheduledAt is
          // a future slot and kept the group permanently unread.
          occurredAt: latestOf(fieldVisits.map((v) => v.updatedAt)).toISOString(),
          count: totalField,
          view: "visits",
          items: fieldVisits.map((v) => ({
            id: v.id,
            label: `${v.lead?.fullName ?? "—"}${v.project?.name ? ` · ${v.project.name}` : ""}`,
            leadId: v.leadId,
          })),
        });
      }
    }

    // ── P53 (D-UX-064) — the §12.2 duplicate backlog (MANAGER+ only: the
    // merge-or-dismiss decision authority — the same D-021 gate the scan
    // itself enforces; an org-wide duplicate group below MANAGER would leak
    // foreign-lead existence through the pair labels). Warning tier (a
    // decision backlog is attention, D-UX-015 — data integrity awaiting a
    // human decision). Items: up to 5 pairs, label = "A / B" (both sides'
    // names — the pair IS its two profiles), leadId = the pair's first side
    // so an item click opens the prospect drawer; occurredAt = the fresher
    // side's createdAt (the pair's "last changed shape" timestamp). The
    // group routes to the leads view where the P53 token auto-opens the
    // DuplicatesDialog (aggregate → isolate → act in one click).
    if (isManager) {
      const { pairs: dupPairs } = await pendingDuplicatePairsCached(orgId); // W5-4: 60s TTL — the per-poll 5k-lead scan is gone
      if (dupPairs.length > 0) {
        notifications.push({
          key: "leads-duplicates",
          type: "LEADS_DUPLICATES",
          severity: "warning",
          occurredAt: dupPairs[0]!.occurredAt.toISOString(),
          count: dupPairs.length,
          view: "leads",
          items: dupPairs.slice(0, 5).map((p) => ({
            id: p.id,
            label: `${p.leadAName} / ${p.leadBName}`,
            leadId: p.leadAId,
          })),
        });
      }
    }

    // ── P9 (D-ARCH-2) — VISITS_REPORTED: the sales-side hand-off the pull
    // architecture lacked. When a field rep files a visit report, the
    // responsible sales representative previously discovered it only by
    // scanning lists (multi-minute poll latency, nothing distinguishing
    // "report ready" from background noise — 9-A3 audit D2). This computed
    // group surfaces the reports filed in the last 7 days on visits the
    // caller is responsible for (agentId = user.id, or the lead-owner
    // fallback the report authority itself uses). Info tier (a digest, not
    // an alarm); self-expiring (reportedAt window); inherently idempotent
    // (pure read, scope-keyed TTL cache). Items keep leadId so a click opens
    // the prospect drawer; the group routes to the visits view where the
    // report chip isolates the rows.
    if (user.role === "SALES_AGENT") {
      const reportedWhere = {
        orgId,
        status: "COMPLETED" as const,
        reportedAt: { gte: new Date(now.getTime() - 7 * DAY_MS) },
        OR: [
          { agentId: user.id },
          { agentId: null, lead: { ownerId: user.id } },
        ],
      };
      const reportedVisits = await db.visit.findMany({
        where: reportedWhere,
        orderBy: { reportedAt: "desc" },
        take: 5,
        include: { lead: { select: { id: true, fullName: true } } },
      });
      if (reportedVisits.length > 0) {
        const totalReported = await db.visit.count({ where: reportedWhere });
        notifications.push({
          key: "visits-reported",
          type: "VISITS_REPORTED",
          severity: "info",
          occurredAt: reportedVisits[0]!.reportedAt?.toISOString() ?? new Date().toISOString(),
          count: totalReported,
          view: "visits",
          items: reportedVisits.map((v) => ({
            id: v.id,
            label: v.lead?.fullName ?? "—",
            leadId: v.leadId,
          })),
        });
      }
    }

    // Severity ordering: urgent → warning → info; stable keys for read-state.
    const sevRank: Record<Severity, number> = { urgent: 0, warning: 1, info: 2 };
    notifications.sort((a, b) => sevRank[a.severity] - sevRank[b.severity]);

    const payload = { data: notifications, generatedAt: new Date().toISOString() };
    notificationCache.set(cacheKey, payload);
    // P10-1 — cache stores ONLY the computed scope payload; readState rides
    // along per request (one indexed scan, the same cost class as the poll).
    return ok({ ...payload, readState: await getReadState(user.id) });
  } catch (error) {
    return fail(error);
  }
}
