// GET  /api/campaigns — the org's campaigns (campaigns.view: pickers,
//      attribution reads). Each row carries its live lead count (one groupBy
//      for the whole list — no N+1).
// POST /api/campaigns — create (campaigns.manage, MANAGER+). The CODE is the
//      immutable attribution key; a duplicate code is a clean 409.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { campaignCreateSchema, campaignLeadCounts, toCampaignDTO } from "@/lib/server/campaigns";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("campaigns.view");
    const rows = await db.campaign.findMany({
      where: { orgId: user.orgId },
      orderBy: [{ createdAt: "desc" }],
    });
    const counts = await campaignLeadCounts(user.orgId);
    return ok({ data: rows.map((r) => toCampaignDTO(r, counts.get(r.id) ?? 0)) });
  } catch (error) {
    return fail(error);
  }
}

// ── POST (create) ──────────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("campaigns.manage");
    const body = await parseBody(req, campaignCreateSchema);
    const orgId = user.orgId;

    const existing = await db.campaign.findUnique({ where: { orgId_code: { orgId, code: body.code } } });
    if (existing) {
      throw new ApiError(409, "Une campagne utilise déjà ce code", "CAMPAIGN_CODE_EXISTS");
    }
    if (body.startDate && body.endDate && body.endDate <= body.startDate) {
      throw new ApiError(422, "La date de fin doit suivre la date de début", "VALIDATION_ERROR");
    }

    const row = await db.campaign.create({
      data: {
        orgId,
        name: body.name,
        code: body.code,
        channel: body.channel,
        status: body.status,
        startDate: body.startDate ?? null,
        endDate: body.endDate ?? null,
        budgetPlanned: body.budgetPlanned ?? null,
        notes: body.notes ?? null,
        createdById: user.id,
      },
    });
    await logAudit({
      orgId,
      actor: user,
      action: "CAMPAIGN_CREATED",
      entity: "CAMPAIGN",
      entityId: row.id,
      after: { name: row.name, code: row.code, channel: row.channel, status: row.status },
    });
    return ok({ data: toCampaignDTO(row, 0) }, 201);
  } catch (error) {
    return fail(error);
  }
}
