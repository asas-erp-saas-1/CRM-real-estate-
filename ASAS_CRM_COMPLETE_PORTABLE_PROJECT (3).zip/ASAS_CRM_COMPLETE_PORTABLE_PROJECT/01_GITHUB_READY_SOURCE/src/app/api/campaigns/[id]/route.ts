// PATCH /api/campaigns/:id — edit (campaigns.manage, MANAGER+). The CODE and
// the CHANNEL are immutable (the code is the attribution key stored on every
// stamped lead; the channel feeds source-effectiveness analytics). Status is
// the soft lifecycle (ACTIVE/PAUSED/ENDED) — ending a campaign preserves all
// historical attribution for reporting.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { campaignUpdateSchema, toCampaignDTO } from "@/lib/server/campaigns";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requirePermission("campaigns.manage");
    const { id } = await ctx.params;
    const body = await parseBody(req, campaignUpdateSchema);

    const row = await db.campaign.findFirst({ where: { id, orgId: user.orgId } });
    if (!row) throw new ApiError(404, "Campagne introuvable", "CAMPAIGN_NOT_FOUND");

    const nextStart = body.startDate !== undefined ? body.startDate : row.startDate;
    const nextEnd = body.endDate !== undefined ? body.endDate : row.endDate;
    if (nextStart && nextEnd && nextEnd <= nextStart) {
      throw new ApiError(422, "La date de fin doit suivre la date de début", "VALIDATION_ERROR");
    }

    const updated = await db.campaign.update({
      where: { id: row.id },
      data: {
        ...(body.name !== undefined ? { name: body.name } : {}),
        ...(body.status !== undefined ? { status: body.status } : {}),
        ...(body.startDate !== undefined ? { startDate: body.startDate } : {}),
        ...(body.endDate !== undefined ? { endDate: body.endDate } : {}),
        ...(body.budgetPlanned !== undefined ? { budgetPlanned: body.budgetPlanned } : {}),
        ...(body.notes !== undefined ? { notes: body.notes } : {}),
      },
    });
    await logAudit({
      orgId: user.orgId,
      actor: user,
      action: "CAMPAIGN_UPDATED",
      entity: "CAMPAIGN",
      entityId: row.id,
      before: { name: row.name, status: row.status, startDate: row.startDate, endDate: row.endDate, budgetPlanned: row.budgetPlanned, notes: row.notes },
      after: { name: updated.name, status: updated.status, startDate: updated.startDate, endDate: updated.endDate, budgetPlanned: updated.budgetPlanned, notes: updated.notes },
    });
    return ok({ data: toCampaignDTO(updated, 0) });
  } catch (error) {
    return fail(error);
  }
}
