// GET /api/inventory/dashboard — Phase 10 (A5): the inventory control-center
// metrics. Every number is a real database calculation over the org's scoped
// inventory (no mock numbers, §5-A5 law). Visible to every authenticated role
// (properties.view parity — the org-shared inventory); the quality detail and
// the import surface stay management-only.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { classifyFreshness, getFreshnessPolicy } from "@/lib/server/inventory-events";
import { fail, ok } from "@/lib/server/session";
import { requireUser } from "@/lib/server/session";

export async function GET(_req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;

    const policy = await getFreshnessPolicy(orgId);
    const since = new Date(Date.now() - 30 * 86_400_000); // 30-day operational window

    const [
      total,
      byStatus,
      apartments,
      recentPriceChanges,
      recentAvailabilityChanges,
      pendingDiscountApprovals,
      liveOffers,
      activeReservations,
      projectCount,
    ] = await Promise.all([
      db.apartment.count({ where: { orgId } }),
      db.apartment.groupBy({ by: ["status"], where: { orgId }, _count: { _all: true } }),
      db.apartment.findMany({
        where: { orgId },
        select: { id: true, availabilityVerifiedAt: true, bathrooms: true, finishing: true, buildingId: true },
      }),
      db.unitPriceEvent.count({ where: { orgId, createdAt: { gte: since } } }),
      db.unitAvailabilityEvent.count({ where: { orgId, createdAt: { gte: since } } }),
      db.offer.count({ where: { orgId, status: "PENDING_APPROVAL" } }),
      db.offer.count({ where: { orgId, status: { in: ["ACTIVE", "CONFIRMED"] } } }),
      db.reservation.count({ where: { orgId, status: { in: ["ACTIVE", "CLOSURE_REQUESTED"] } } }),
      db.project.count({ where: { orgId } }),
    ]);

    const statusCount = (s: string) => byStatus.find((r) => r.status === s)?._count._all ?? 0;

    // Freshness distribution over the real anchors.
    const freshness = { VERIFIED: 0, RECENT: 0, STALE: 0, UNKNOWN: 0 } as Record<string, number>;
    for (const a of apartments) freshness[classifyFreshness(a.availabilityVerifiedAt, policy)]++;

    // Essential-data completeness (the quality view carries the row detail).
    const missingBathrooms = apartments.filter((a) => a.bathrooms == null).length;
    const missingFinishing = apartments.filter((a) => a.finishing == null).length;

    return ok({
      total,
      projectCount,
      byStatus: {
        available: statusCount("AVAILABLE"),
        optioned: statusCount("OPTIONED"),
        reserved: statusCount("RESERVED"),
        sold: statusCount("SOLD"),
        blocked: statusCount("BLOCKED"),
        unavailable: statusCount("UNAVAILABLE"),
        offMarket: statusCount("OFF_MARKET"),
      },
      freshness,
      freshnessPolicy: policy,
      dataQuality: {
        missingBathrooms,
        missingFinishing,
      },
      activity: {
        recentPriceChanges,
        recentAvailabilityChanges,
        pendingDiscountApprovals,
        liveOffers,
        activeReservations,
      },
    });
  } catch (error) {
    return fail(error);
  }
}
