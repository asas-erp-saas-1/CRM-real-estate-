// GET /api/inventory/quality — Phase 10 (A5): the actionable data-quality
// view (MANAGER+ — the management decision surface). Row-level issues with
// precise categories; NOTHING is auto-modified (§5-A5-D law — questionable
// records are surfaced, never silently "fixed").
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { classifyFreshness, getFreshnessPolicy } from "@/lib/server/inventory-events";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("inventory.quality.view");
    const orgId = user.orgId;

    const policy = await getFreshnessPolicy(orgId);

    // The full unit set with the issue-detection projection (bounded by real
    // inventory size; org-scoped).
    const apartments = await db.apartment.findMany({
      where: { orgId },
      select: {
        id: true,
        code: true,
        status: true,
        price: true,
        surface: true,
        bathrooms: true,
        totalSurface: true,
        finishing: true,
        view: true,
        availabilityVerifiedAt: true,
        building: { select: { id: true, name: true, project: { select: { id: true, name: true } } } },
      },
      orderBy: [{ buildingId: "asc" }, { code: "asc" }],
    });

    // Validated unit images (Document is polymorphic — entityType/entityId).
    const apartmentIds = apartments.map((a) => a.id);
    const validatedDocs = apartmentIds.length
      ? await db.document.groupBy({
          by: ["entityId"],
          where: { orgId, entityType: "APARTMENT", entityId: { in: apartmentIds }, status: "VALIDATED" },
          _count: { _all: true },
        })
      : [];
    const docsByApartment = new Map(validatedDocs.map((d) => [d.entityId, d._count._all]));

    // Orphan-hold predicate (the P47/W2 derived concept — held with no live
    // hold behind it): resolved against the live offer/reservation sets.
    const [liveOfferApartments, liveReservationApartments] = await Promise.all([
      db.offer.findMany({
        where: { orgId, status: { in: ["ACTIVE", "CONFIRMED"] }, apartmentId: { not: null } },
        select: { apartmentId: true },
      }),
      db.reservation.findMany({
        where: { orgId, status: { in: ["ACTIVE", "CLOSURE_REQUESTED"] } },
        select: { apartmentId: true },
      }),
    ]);
    const heldWithLiveOffer = new Set(liveOfferApartments.map((o) => o.apartmentId!));
    const heldWithLiveReservation = new Set(liveReservationApartments.map((r) => r.apartmentId));

    interface Issue {
      apartmentId: string;
      code: string;
      project: string;
      status: string;
      category: string;
      detail: string;
    }
    const issues: Issue[] = [];

    // Duplicate unit codes within a PROJECT (the unique constraint is
    // [orgId, buildingId, code] — the same code in two buildings of one
    // project is a business duplicate risk).
    const byProjectCode = new Map<string, typeof apartments>();
    for (const a of apartments) {
      const key = `${a.building?.project?.id ?? "?"}|${a.code}`;
      const list = byProjectCode.get(key) ?? [];
      list.push(a);
      byProjectCode.set(key, list);
    }

    for (const a of apartments) {
      const project = a.building?.project?.name ?? "—";
      const freshness = classifyFreshness(a.availabilityVerifiedAt, policy);

      if (a.bathrooms == null) {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "MISSING_BATHROOMS", detail: "Salles de bain non renseignées (inconnu explicite)" });
      }
      if (a.totalSurface == null) {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "MISSING_TOTAL_SURFACE", detail: "Surface totale non renseignée" });
      }
      if (a.finishing == null) {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "MISSING_FINISHING", detail: "État de finition non renseigné" });
      }
      if (a.price <= 0) {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "INVALID_PRICE", detail: `Prix invalide : ${a.price}` });
      }
      if (a.surface <= 0) {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "INVALID_SURFACE", detail: `Surface invalide : ${a.surface}` });
      }
      if (freshness === "STALE") {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "STALE_AVAILABILITY", detail: `Disponibilité non vérifiée depuis plus de ${policy.staleDays} j` });
      }
      if (freshness === "UNKNOWN") {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "UNKNOWN_FRESHNESS", detail: "Disponibilité jamais vérifiée" });
      }
      if ((a.status === "RESERVED" || a.status === "OPTIONED") && !heldWithLiveOffer.has(a.id) && !heldWithLiveReservation.has(a.id)) {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "ORPHAN_HOLD", detail: "Statut bloqué sans réservation ni offre active derrière — décision requise" });
      }
      if (a.status === "AVAILABLE" && (docsByApartment.get(a.id) ?? 0) === 0) {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "NO_IMAGES", detail: "Aucun visuel validé sur un lot en commercialisation" });
      }
      const key = `${a.building?.project?.id ?? "?"}|${a.code}`;
      const duplicates = byProjectCode.get(key) ?? [];
      if (duplicates.length > 1 && duplicates[0].id === a.id) {
        issues.push({ apartmentId: a.id, code: a.code, project, status: a.status, category: "DUPLICATE_CODE", detail: `Code « ${a.code} » présent dans ${duplicates.length} bâtiments du même projet` });
      }
    }

    // Category rollup for the summary strip.
    const byCategory: Record<string, number> = {};
    for (const issue of issues) byCategory[issue.category] = (byCategory[issue.category] ?? 0) + 1;

    return ok({
      totalUnits: apartments.length,
      issueCount: issues.length,
      byCategory,
      issues,
    });
  } catch (error) {
    return fail(error);
  }
}
