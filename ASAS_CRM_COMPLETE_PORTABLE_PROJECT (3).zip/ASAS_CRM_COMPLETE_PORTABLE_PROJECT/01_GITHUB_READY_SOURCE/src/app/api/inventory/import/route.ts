// POST /api/inventory/import — Phase 10 (A5): the CONTROLLED unit CSV import.
//   { action: "preview", csv, mapping? }   → parsed + validated rows with
//                                           row-level errors + duplicate detection
//   { action: "commit", csv, mapping, fileName? } → all-or-nothing insert
//                                           (any row-level error refuses the
//                                           WHOLE import — no partial inventory
//                                           gaps) + INVENTORY_IMPORTED audit
//                                           with the created ids.
// MANAGER+ (inventory.import). Validation law (the leads-import pattern, the
// §5-A5-E import rules): never import without validation; never silently
// overwrite an existing unit (same building+code → DUPLICATE, row refused);
// structures resolve by NAME within the org (project must exist; building
// must exist unless allowCreateBuilding); every created unit leaves an
// availability event (source IMPORT) in the creation transaction.
import type { NextRequest } from "next/server";
import { z } from "zod";
import {
  APARTMENT_PAYMENT_PLANS,
  APARTMENT_STATUSES,
  UNIT_DELIVERY_STATUSES,
  UNIT_FINISHING,
  UNIT_TYPES,
  UNIT_VIEWS,
} from "@/lib/constants";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { IMPORT_MAX_CSV_BYTES, IMPORT_MAX_ROWS, parseCsv } from "@/lib/server/csv";
import { recordAvailabilityEvent, recordPriceEvent } from "@/lib/server/inventory-events";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

const PREVIEW_ROW_CAP = 200;
const DB_CHUNK = 300;

// The importable vocabulary (closed enums validated app-side — ADR-001).
const UNIT_FIELDS = [
  "projectName",
  "buildingName",
  "code",
  "unitType",
  "rooms",
  "bedrooms",
  "bathrooms",
  "surface",
  "totalSurface",
  "floorNumber",
  "orientation",
  "parking",
  "balcony",
  "terrace",
  "view",
  "finishing",
  "deliveryStatus",
  "price",
  "parkingPrice",
  "paymentPlan",
  "status",
  "notes",
] as const;
type UnitField = (typeof UNIT_FIELDS)[number];

/** FIX-C.3 — the explicit-ignore sentinel (the wizard's « Ignorer » choice
 *  stores it per column instead of deleting the key). When building the
 *  resolved mapping, sentinel columns are DROPPED so their auto-detected
 *  field can never re-enter — preview and commit walk this one resolution. */
const IGNORE_COLUMN = "__ignore__";

const importSchema = z.object({
  action: z.enum(["preview", "commit"]),
  csv: z.string().min(1, "CSV vide").max(IMPORT_MAX_CSV_BYTES, "Fichier trop volumineux"),
  mapping: z.record(z.string(), z.union([z.enum(UNIT_FIELDS), z.literal(IGNORE_COLUMN)])).optional(),
  allowCreateBuilding: z.boolean().optional(),
  fileName: z.string().trim().max(200).optional(),
});

/** French/English-tolerant booleans (the import UX reality). */
function coerceBool(raw: string): boolean | null {
  const v = raw.trim().toLowerCase();
  if (["1", "true", "yes", "oui", "vrai", "v"].includes(v)) return true;
  if (["0", "false", "no", "non", "faux", "f"].includes(v)) return false;
  return null;
}

function coerceInt(raw: string): number | null {
  const v = raw.trim().replace(/\s/g, "").replace(",", ".");
  const n = Number(v);
  return Number.isFinite(n) && Number.isInteger(n) ? n : null;
}

function coerceFloat(raw: string): number | null {
  const v = raw.trim().replace(/\s/g, "").replace(",", ".");
  if (!v) return null;
  const n = Number(v.replace(/[^\d.\-]/g, ""));
  return Number.isFinite(n) ? n : null;
}

function coerceMoney(raw: string): number | null {
  const n = coerceFloat(raw);
  return n != null && n >= 0 ? n : null;
}

/** Enum coercion with alias tolerance (fr/en; null = unknown → row error for enums). */
function coerceEnum<T extends string>(raw: string, values: readonly T[], aliases?: Record<string, T>): T | null {
  const v = raw.trim().toUpperCase().replace(/[\s-]+/g, "_");
  if (!v) return null;
  if ((values as readonly string[]).includes(v)) return v as T;
  const aliased = aliases?.[v] ?? aliases?.[raw.trim().toLowerCase()];
  return aliased ?? null;
}

const TYPE_ALIASES: Record<string, (typeof UNIT_TYPES)[number]> = {
  STUDIO: "STUDIO",
  F2: "F2",
  F3: "F3",
  F4: "F4",
  F5: "F5",
  DUPLEX: "DUPLEX",
  VILLA: "VILLA",
  TERRAIN: "LAND",
  LAND: "LAND",
};
const FINISHING_ALIASES: Record<string, (typeof UNIT_FINISHING)[number]> = {
  BRUT: "ROUGH",
  GROS_UVRE: "ROUGH",
  ROUGH: "ROUGH",
  SEMI_FINI: "PARTIAL",
  PARTIEL: "PARTIAL",
  PARTIAL: "PARTIAL",
  FINI: "FULL",
  FULL: "FULL",
  STANDARD: "FULL",
  LUXE: "LUXURY",
  LUXURY: "LUXURY",
};
const VIEW_ALIASES: Record<string, (typeof UNIT_VIEWS)[number]> = {
  MER: "SEA",
  SEA: "SEA",
  VILLE: "CITY",
  CITY: "CITY",
  JARDIN: "GARDEN",
  GARDEN: "GARDEN",
  RUE: "STREET",
  STREET: "STREET",
  MONTAGNE: "MOUNTAIN",
  MOUNTAIN: "MOUNTAIN",
  PARC: "PARK",
  PARK: "PARK",
};
const DELIVERY_ALIASES: Record<string, (typeof UNIT_DELIVERY_STATUSES)[number]> = {
  NON_DEMARRE: "NOT_STARTED",
  NOT_STARTED: "NOT_STARTED",
  EN_COURS: "UNDER_CONSTRUCTION",
  CONSTRUCTION: "UNDER_CONSTRUCTION",
  UNDER_CONSTRUCTION: "UNDER_CONSTRUCTION",
  PRET: "READY",
  READY: "READY",
  LIVRE: "DELIVERED",
  DELIVERED: "DELIVERED",
};

/** Auto-map CSV headers to unit fields (name/label tolerance, fr+en). */
function autoMapHeaders(headers: string[]): Record<number, UnitField> {
  const norm = (s: string) =>
    s
      .trim()
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "_");
  const HEADER_TO_FIELD: Record<string, UnitField> = {
    projet: "projectName",
    project: "projectName",
    batiment: "buildingName",
    bat: "buildingName",
    building: "buildingName",
    bloc: "buildingName",
    code: "code",
    lot: "code",
    reference: "code",
    ref: "code",
    type: "unitType",
    type_bien: "unitType",
    unit_type: "unitType",
    pieces: "rooms",
    rooms: "rooms",
    chambres: "bedrooms",
    bedrooms: "bedrooms",
    sdb: "bathrooms",
    salles_de_bain: "bathrooms",
    bathrooms: "bathrooms",
    surface: "surface",
    superficie: "surface",
    surface_interieure: "surface",
    surface_totale: "totalSurface",
    total_surface: "totalSurface",
    surfacetotale: "totalSurface",
    superficie_totale: "totalSurface",
    etage: "floorNumber",
    floor: "floorNumber",
    floor_number: "floorNumber",
    etage_num: "floorNumber",
    orientation: "orientation",
    parking: "parking",
    balcon: "balcony",
    balcony: "balcony",
    terrasse: "terrace",
    terrace: "terrace",
    vue: "view",
    view: "view",
    finition: "finishing",
    finishing: "finishing",
    etat_livraison: "deliveryStatus",
    delivery: "deliveryStatus",
    delivery_status: "deliveryStatus",
    prix: "price",
    price: "price",
    prix_parking: "parkingPrice",
    parking_price: "parkingPrice",
    prixparking: "parkingPrice",
    plan_paiement: "paymentPlan",
    payment_plan: "paymentPlan",
    statut: "status",
    status: "status",
    disponibilite: "status",
    notes: "notes",
    remarques: "notes",
  };
  const mapping: Record<number, UnitField> = {};
  headers.forEach((h, i) => {
    const field = HEADER_TO_FIELD[norm(h)];
    if (field && !Object.values(mapping).includes(field)) mapping[i] = field;
  });
  return mapping;
}

interface ParsedUnitRow {
  rowNumber: number;
  projectName: string;
  buildingName: string;
  code: string;
  unitType: string;
  price: number;
  surface: number;
  rooms?: number;
  bedrooms?: number;
  bathrooms?: number | null;
  totalSurface?: number | null;
  floorNumber?: number;
  orientation?: string | null;
  parking?: boolean;
  balcony?: boolean | null;
  terrace?: boolean | null;
  view?: string | null;
  finishing?: string | null;
  deliveryStatus?: string | null;
  parkingPrice?: number | null;
  paymentPlan?: string | null;
  status?: string;
  notes?: string | null;
}

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("inventory.import");
    const orgId = user.orgId;
    const body = await parseBody(req, importSchema);

    // Parse + size guards (the csv.ts law).
    const rows = parseCsv(body.csv);
    if (rows.length < 2) throw new ApiError(422, "CSV vide ou sans lignes de données", "EMPTY_CSV");
    if (rows.length - 1 > IMPORT_MAX_ROWS) {
      throw new ApiError(422, `Trop de lignes (${rows.length - 1} > ${IMPORT_MAX_ROWS})`, "TOO_MANY_ROWS");
    }

    const headers = rows[0];
    const mapping = body.mapping ?? undefined;
    const auto = autoMapHeaders(headers);
    // Explicit mapping wins over auto-detected (column index → field).
    // FIX-C.3 — a column whose mapping value is the ignore sentinel is
    // DROPPED from the resolved mapping (not left to the auto-detected
    // fallback): « Ignorer » is an explicit veto, honored identically by the
    // preview dry-run and the commit insert (they walk this one resolution).
    const resolved: Record<number, UnitField> = { ...auto };
    if (mapping) {
      for (const [col, field] of Object.entries(mapping)) {
        if (field === IGNORE_COLUMN) delete resolved[Number(col)];
        else resolved[Number(col)] = field;
      }
    }

    const fieldOf = (row: string[], field: UnitField): string => {
      const col = Object.entries(resolved).find(([, f]) => f === field)?.[0];
      return col != null ? (row[Number(col)] ?? "").trim() : "";
    };

    // ── Row validation (the dry-run core) ──
    interface RowError { row: number; field: string; message: string; }
    const rowErrors: RowError[] = [];
    const parsed: ParsedUnitRow[] = [];

    rows.slice(1).forEach((row, idx) => {
      const rowNumber = idx + 2; // header is row 1
      const projectName = fieldOf(row, "projectName");
      const buildingName = fieldOf(row, "buildingName");
      const code = fieldOf(row, "code");
      const unitTypeRaw = fieldOf(row, "unitType");
      const priceRaw = fieldOf(row, "price");
      const surfaceRaw = fieldOf(row, "surface");

      if (!projectName) rowErrors.push({ row: rowNumber, field: "projectName", message: "Projet requis" });
      if (!buildingName) rowErrors.push({ row: rowNumber, field: "buildingName", message: "Bâtiment requis" });
      if (!code) rowErrors.push({ row: rowNumber, field: "code", message: "Code lot requis" });

      const unitType = coerceEnum(unitTypeRaw, UNIT_TYPES, TYPE_ALIASES);
      if (!unitType) rowErrors.push({ row: rowNumber, field: "unitType", message: `Type invalide : « ${unitTypeRaw} »` });

      const price = coerceMoney(priceRaw);
      if (price == null || price <= 0) rowErrors.push({ row: rowNumber, field: "price", message: `Prix invalide : « ${priceRaw} »` });
      const surface = coerceFloat(surfaceRaw);
      if (surface == null || surface <= 0) rowErrors.push({ row: rowNumber, field: "surface", message: `Surface invalide : « ${surfaceRaw} »` });

      const rooms = fieldOf(row, "rooms") ? coerceInt(fieldOf(row, "rooms")) : null;
      const bedrooms = fieldOf(row, "bedrooms") ? coerceInt(fieldOf(row, "bedrooms")) : null;
      const bathroomsRaw = fieldOf(row, "bathrooms");
      const bathrooms = bathroomsRaw ? coerceInt(bathroomsRaw) : null;
      if (bathroomsRaw && bathrooms == null) rowErrors.push({ row: rowNumber, field: "bathrooms", message: `SDB invalide : « ${bathroomsRaw} »` });
      const totalSurfaceRaw = fieldOf(row, "totalSurface");
      const totalSurface = totalSurfaceRaw ? coerceFloat(totalSurfaceRaw) : null;
      const floorNumber = fieldOf(row, "floorNumber") ? coerceInt(fieldOf(row, "floorNumber")) : null;
      const parkingRaw = fieldOf(row, "parking");
      const parking = parkingRaw ? coerceBool(parkingRaw) : null;
      if (parkingRaw && parking == null) rowErrors.push({ row: rowNumber, field: "parking", message: `Parking invalide (oui/non) : « ${parkingRaw} »` });
      const balconyRaw = fieldOf(row, "balcony");
      const balcony = balconyRaw ? coerceBool(balconyRaw) : null;
      const terraceRaw = fieldOf(row, "terrace");
      const terrace = terraceRaw ? coerceBool(terraceRaw) : null;
      const viewRaw = fieldOf(row, "view");
      const view = viewRaw ? coerceEnum(viewRaw, UNIT_VIEWS, VIEW_ALIASES) : null;
      if (viewRaw && !view) rowErrors.push({ row: rowNumber, field: "view", message: `Vue invalide : « ${viewRaw} »` });
      const finishingRaw = fieldOf(row, "finishing");
      const finishing = finishingRaw ? coerceEnum(finishingRaw, UNIT_FINISHING, FINISHING_ALIASES) : null;
      if (finishingRaw && !finishing) rowErrors.push({ row: rowNumber, field: "finishing", message: `Finition invalide : « ${finishingRaw} »` });
      const deliveryRaw = fieldOf(row, "deliveryStatus");
      const deliveryStatus = deliveryRaw ? coerceEnum(deliveryRaw, UNIT_DELIVERY_STATUSES, DELIVERY_ALIASES) : null;
      if (deliveryRaw && !deliveryStatus) rowErrors.push({ row: rowNumber, field: "deliveryStatus", message: `État de livraison invalide : « ${deliveryRaw} »` });
      const parkingPriceRaw = fieldOf(row, "parkingPrice");
      const parkingPrice = parkingPriceRaw ? coerceMoney(parkingPriceRaw) : null;
      const paymentPlanRaw = fieldOf(row, "paymentPlan");
      const paymentPlan = paymentPlanRaw
        ? coerceEnum(paymentPlanRaw, APARTMENT_PAYMENT_PLANS, {
            CASH: "CASH", COMPTANT: "CASH",
            INSTALLMENT: "INSTALLMENT", ECHELANNE: "INSTALLMENT", "ECHELANNE_": "INSTALLMENT",
            NOTARY_1_3: "NOTARY_1_3", NOTAIRE_1_3: "NOTARY_1_3",
          })
        : null;
      const statusRaw = fieldOf(row, "status");
      const status = statusRaw
        ? coerceEnum(statusRaw, APARTMENT_STATUSES, {
            DISPONIBLE: "AVAILABLE", AVAILABLE: "AVAILABLE",
            RESERVE: "RESERVED", VENDU: "SOLD", BLOQUE: "BLOCKED",
            INDISPONIBLE: "UNAVAILABLE", OPTIONNE: "OPTIONED",
            RETIRE: "OFF_MARKET",
          })
        : null;

      parsed.push({
        rowNumber,
        projectName,
        buildingName,
        code,
        unitType: unitType ?? "",
        price: price ?? 0,
        surface: surface ?? 0,
        rooms: rooms ?? undefined,
        bedrooms: bedrooms ?? undefined,
        bathrooms,
        totalSurface,
        floorNumber: floorNumber ?? undefined,
        orientation: fieldOf(row, "orientation") || null,
        parking: parking ?? false,
        balcony,
        terrace,
        view,
        finishing,
        deliveryStatus,
        parkingPrice,
        paymentPlan,
        status: status ?? "AVAILABLE",
        notes: fieldOf(row, "notes") || null,
      });
    });

    // ── Structure + duplicate resolution (org-scoped) ──
    const orgProjects = await db.project.findMany({
      where: { orgId },
      select: { id: true, name: true, nameAr: true },
    });
    const projectByName = new Map<string, { id: string }>();
    for (const p of orgProjects) {
      projectByName.set(p.name.toLowerCase(), p);
      if (p.nameAr) projectByName.set(p.nameAr.toLowerCase(), p);
    }

    // In-file duplicate codes (same project+building+code twice).
    const seenKeys = new Set<string>();
    for (const r of parsed) {
      const key = `${r.projectName.toLowerCase()}|${r.buildingName.toLowerCase()}|${r.code.toLowerCase()}`;
      if (seenKeys.has(key)) {
        rowErrors.push({ row: r.rowNumber, field: "code", message: `Code dupliqué dans le fichier : « ${r.code} »` });
      }
      seenKeys.add(key);
    }

    // Structure resolution per row (project must exist; building may be created).
    const buildingsByProject = new Map<string, Map<string, string>>(); // projectId → lowercase name → id
    const existingUnits = await db.apartment.findMany({
      where: { orgId },
      select: { code: true, buildingId: true, building: { select: { name: true, projectId: true, project: { select: { name: true } } } } },
    });
    const existingUnitKeys = new Set(
      existingUnits.map((u) => `${u.building?.project?.name.toLowerCase()}|${u.building?.name.toLowerCase()}|${u.code.toLowerCase()}`),
    );
    const existingBuildings = await db.building.findMany({
      // R2 — org-scoped via the project leg (Building carries no orgId column;
      // the previous unscoped scan over-read every org's buildings).
      where: { project: { orgId } },
      select: { id: true, name: true, projectId: true },
    });
    for (const b of existingBuildings) {
      const map = buildingsByProject.get(b.projectId) ?? new Map<string, string>();
      map.set(b.name.toLowerCase(), b.id);
      buildingsByProject.set(b.projectId, map);
    }

    for (const r of parsed) {
      const project = projectByName.get(r.projectName.toLowerCase());
      if (!project) {
        rowErrors.push({ row: r.rowNumber, field: "projectName", message: `Projet introuvable : « ${r.projectName} »` });
        continue;
      }
      const buildingMap = buildingsByProject.get(project.id);
      const buildingId = buildingMap?.get(r.buildingName.toLowerCase());
      if (!buildingId && !body.allowCreateBuilding) {
        rowErrors.push({ row: r.rowNumber, field: "buildingName", message: `Bâtiment introuvable dans « ${r.projectName} » : « ${r.buildingName} » (création non autorisée)` });
      }
      const unitKey = `${r.projectName.toLowerCase()}|${r.buildingName.toLowerCase()}|${r.code.toLowerCase()}`;
      if (existingUnitKeys.has(unitKey)) {
        rowErrors.push({ row: r.rowNumber, field: "code", message: `Lot déjà existant : « ${r.code} » — jamais écrasé (import refusé pour cette ligne)` });
      }
    }

    // ── PREVIEW: the validated dry-run report ──
    if (body.action === "preview") {
      // validRows counts ROWS without errors (a row with two field errors is
      // ONE bad row, not two — found by adversarial browser QA: the old
      // `parsed.length - rowErrors.length` undercounted multi-error rows and
      // mislabeled the commit button "Importer 0 lot(s)" when 1 row was valid).
      const errorRowSet = new Set(rowErrors.map((e) => e.row));
      return ok({
        totalRows: parsed.length,
        validRows: parsed.length - errorRowSet.size,
        errorCount: rowErrors.length,
        rowErrors: rowErrors.slice(0, PREVIEW_ROW_CAP),
        truncatedErrors: Math.max(0, rowErrors.length - PREVIEW_ROW_CAP),
        preview: parsed.slice(0, PREVIEW_ROW_CAP),
        detectedMapping: resolved,
        headers,
        allowCreateBuilding: body.allowCreateBuilding === true,
      });
    }

    // ── COMMIT: all-or-nothing (no partial inventory gaps) ──
    if (rowErrors.length > 0) {
      throw new ApiError(
        422,
        `Import refusé : ${rowErrors.length} ligne(s) en erreur (aperçu détaillé via action=preview). Aucun lot créé.`,
        "IMPORT_HAS_ERRORS",
        { errorCount: rowErrors.length, firstErrors: rowErrors.slice(0, 10) },
      );
    }

    const createdIds: string[] = [];
    await db.$transaction(async (tx) => {
      // Create missing buildings first (flagged path only).
      const toCreateBuildings = new Set(
        parsed
          .map((r) => {
            const project = projectByName.get(r.projectName.toLowerCase())!;
            const exists = buildingsByProject.get(project.id)?.has(r.buildingName.toLowerCase());
            return exists ? null : `${project.id}|${r.buildingName}`;
          })
          .filter((v): v is string => v !== null),
      );
      for (const key of toCreateBuildings) {
        const [projectId, name] = key.split("|");
        const building = await tx.building.create({ data: { projectId, name, floors: 1 } });
        const map = buildingsByProject.get(projectId) ?? new Map<string, string>();
        map.set(name.toLowerCase(), building.id);
        buildingsByProject.set(projectId, map);
      }

      // Insert the units (chunked creates; events + audit in the same tx).
      for (let i = 0; i < parsed.length; i += DB_CHUNK) {
        const chunk = parsed.slice(i, i + DB_CHUNK);
        for (const r of chunk) {
          const project = projectByName.get(r.projectName.toLowerCase())!;
          const buildingId = buildingsByProject.get(project.id)!.get(r.buildingName.toLowerCase())!;
          const unit = await tx.apartment.create({
            data: {
              orgId,
              buildingId,
              code: r.code,
              unitType: r.unitType,
              rooms: r.rooms ?? 2,
              bedrooms: r.bedrooms ?? 1,
              bathrooms: r.bathrooms ?? null,
              surface: r.surface,
              totalSurface: r.totalSurface ?? null,
              floorNumber: r.floorNumber ?? 0,
              orientation: r.orientation,
              parking: r.parking ?? false,
              balcony: r.balcony ?? null,
              terrace: r.terrace ?? null,
              view: r.view,
              finishing: r.finishing,
              deliveryStatus: r.deliveryStatus,
              price: r.price,
              parkingPrice: r.parkingPrice ?? null,
              paymentPlan: r.paymentPlan,
              status: r.status ?? "AVAILABLE",
              notes: r.notes,
              priceUpdatedAt: new Date(),
              availabilityVerifiedAt: new Date(), // the import IS a verification act
              statusReason: "Import CSV",
            },
          });
          createdIds.push(unit.id);
          await recordAvailabilityEvent(tx, {
            orgId,
            apartmentId: unit.id,
            from: "NONE",
            to: unit.status,
            actorId: user.id,
            reason: `Import CSV${body.fileName ? ` — ${body.fileName}` : ""}`,
            source: "IMPORT",
          });
          // R2 — the initial-price anchor (provenance: every unit's price
          // history now starts at its import; previousPrice=0 is the documented
          // "no prior price existed" convention — the unit is new).
          await recordPriceEvent(tx, {
            orgId,
            apartmentId: unit.id,
            previousPrice: 0,
            newPrice: unit.price,
            actorId: user.id,
            reason: `Prix initial — import CSV${body.fileName ? ` — ${body.fileName}` : ""}`,
            source: "IMPORT",
          });
        }
      }

      await logAudit(
        {
          orgId,
          actor: user,
          action: "INVENTORY_IMPORTED",
          entity: "APARTMENT",
          entityId: createdIds[0] ?? null,
          before: null,
          after: {
            createdCount: createdIds.length,
            unitIds: createdIds,
            fileName: body.fileName ?? null,
            allowCreateBuilding: body.allowCreateBuilding === true,
          },
        },
        tx,
      );
    });

    return ok({ created: createdIds.length, unitIds: createdIds }, 201);
  } catch (error) {
    return fail(error);
  }
}
