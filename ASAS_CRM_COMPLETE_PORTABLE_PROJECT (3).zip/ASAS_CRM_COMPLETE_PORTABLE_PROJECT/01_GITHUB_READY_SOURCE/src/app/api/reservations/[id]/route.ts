// PATCH /api/reservations/:id — two shapes:
//   1. lifecycle  { action, evidence?/reason? } — the G5-P3-2 (D-GOV-5 §9.2)
//      TWO-STEP sale closure: request_closure (responsible agent, evidence
//      required) → validate_closure (MANAGER+ — ONE transactional event:
//      reservation CONVERTED + apartment SOLD + opportunity CLOSED_WON),
//      plus reject_closure / cancel; EXPIRED stays sweeper-only. Domain in
//      src/lib/server/reservation-lifecycle.ts.
//   2. economics  { commission family, incentive family, rebase?, reason? } —
//      P18 (D-025) + P29 (D-037) deal economics: the ONLY money on the CRM,
//      MANAGER+, with the §37/§38 trust machines (forward-only commission
//      ladder, incentive approval, locked-behind-rebase historical values).
//      Domain in src/lib/server/reservation-economics.ts.
// Since the G5-P4-4 round-3 decomposition this file is the HTTP adapter
// only: the request contract (zod), the D-021 scoped isolation query, and
// the branch dispatch. Every business law lives in the two domain modules
// (verbatim code motion — behavior parity by construction).
// W2-A2 (P1 — DOM-03): the value/amount semantics this route serves are
// owned by src/lib/server/financial-semantics.ts — the lifecycle branch
// (applyReservationLifecycle → validate_closure) calls its helpers
// (agreedAmount / alignWonDealValue) for the one sanctioned closure
// alignment; the economics branch keeps §37/§38 laws (reservation-trust).
// This adapter deliberately re-declares NEITHER.
import type { NextRequest } from "next/server";
import { z } from "zod";
import {
  COMMISSION_SOURCES,
  COMMISSION_STATUSES,
  INCENTIVE_STATUSES,
  RESERVATION_ACTIONS,
} from "@/lib/constants";
import { db } from "@/lib/db";
import { reservationDto } from "@/lib/server/reservation-dto";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { reservationScope } from "@/lib/server/visibility";
import { MAX_MONEY_DZD, parseBody } from "@/lib/server/validation";
import { RESERVATION_PATCH_INCLUDE, applyReservationLifecycle } from "@/lib/server/reservation-lifecycle";
import { applyReservationEconomics } from "@/lib/server/reservation-economics";
import { COMMISSION_FAMILY, INCENTIVE_FAMILY } from "@/lib/server/reservation-trust";

type Ctx = { params: Promise<{ id: string }> };

// P18 — one PATCH schema, two branches: `action` present → lifecycle;
// economics keys present (and no action) → deal economics (MANAGER+).
// P29 — the economics keys grew into two families (§37 commission trust,
// §38 incentive approval) + the rebase flag.
const money = z
  .number()
  .min(0, "Le montant doit être positif ou nul")
  // C8 (Phase 5): the ceiling is the ONE shared DZD money law (MAX_MONEY_DZD)
  // — this schema previously inlined a 10_000_000_000 literal that would
  // silently drift from every other money site on a future cap change.
  .max(MAX_MONEY_DZD, "Montant trop élevé");
const isoDate = z
  .string()
  .refine((v) => !Number.isNaN(Date.parse(v)), "Date invalide")
  .nullable()
  .optional();

const patchSchema = z.object({
  // G5-P3-2 (D-GOV-5 §9.2) — the lifecycle is a CONTROLLED state machine:
  // named actions with per-action authority/prerequisites replace the old
  // free-form `status` write (an editable field is never permission to
  // change status — the owner's directive). EXPIRED stays sweeper-only.
  action: z.enum(RESERVATION_ACTIONS).optional(),
  evidence: z.string().trim().min(1, "Le justificatif de clôture est requis").max(1000).optional(),
  reason: z.string().trim().max(500).optional(),
  // ── commission family (§37) ──
  commissionAmount: money.nullable().optional(),
  commissionFrom: z.enum(COMMISSION_SOURCES).nullable().optional(),
  commissionBasis: z.string().trim().max(500).nullable().optional(),
  commissionStatus: z.enum(COMMISSION_STATUSES).nullable().optional(),
  commissionEarnedAmount: money.nullable().optional(),
  commissionReceivedAmount: money.nullable().optional(),
  commissionReceivedAt: isoDate,
  // ── incentive family (§38) ──
  agentIncentive: money.nullable().optional(),
  incentiveBasis: z.string().trim().max(500).nullable().optional(),
  incentiveStatus: z.enum(INCENTIVE_STATUSES).nullable().optional(),
  incentivePaidAt: isoDate,
  // ── §37/§38 explicit authorized recalculation ──
  rebase: z.boolean().optional(),
});

// The economics families' presence check rides the domain module's family
// tables (single source of truth) — mirrored here only for dispatch.

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    // D-021 — scoped findFirst: foreign reservations are 404.
    const reservation = await db.reservation.findFirst({
      where: { id, orgId: user.orgId, ...reservationScope(user) },
      include: RESERVATION_PATCH_INCLUDE,
    });
    if (!reservation) throw new ApiError(404, "Réservation introuvable", "RESERVATION_NOT_FOUND");

    const body = await parseBody(req, patchSchema);
    const commissionKeys = COMMISSION_FAMILY.some((k) => body[k] !== undefined);
    const incentiveKeys = INCENTIVE_FAMILY.some((k) => body[k] !== undefined);
    const wantsEconomics = body.action === undefined && (commissionKeys || incentiveKeys);

    // Workstream S (FIN-MIN-Q10): BOTH branch responses ride the shared
    // role-aware DTO — the single serialization choke point for this route.
    // The economics branch is MANAGER+-gated inside the domain module and the
    // three manager-only lifecycle actions are authority-gated before any
    // write, so their rows pass through the DTO UNCHANGED (manager shape
    // byte-identical). request_closure, however, is callable by the
    // responsible SALES_AGENT — its response previously spread the full DB
    // row (§37/§38 included); the DTO now removes the financial family at
    // construction for floor roles. The D-021 scoped findFirst above is the
    // row-level layer and stays byte-identical.
    // G5-P3-5 (F-06): `req` now rides into the economics branch too — same
    // §41 fault-injection channel as the lifecycle branch (no-op without the
    // explicit x-test-inject header).
    const result = wantsEconomics
      ? await applyReservationEconomics(user, reservation, body, req)
      : await applyReservationLifecycle(user, reservation, body, req);
    return ok({ reservation: reservationDto(user, result.reservation) });
  } catch (error) {
    return fail(error);
  }
}
