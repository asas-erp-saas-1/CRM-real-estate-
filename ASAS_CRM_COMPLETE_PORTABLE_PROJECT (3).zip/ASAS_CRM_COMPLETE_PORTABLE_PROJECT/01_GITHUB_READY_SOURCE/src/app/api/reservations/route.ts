// GET  /api/reservations — reservation list (D-021 scoped, W2.9 paginated, the
//        shared role-aware DTO on every row).
// POST /api/reservations — transaction-safe booking (ADR-004).
// Thin HTTP adapters (W2-A3, ARCH-01): zod/query-param contract → requireUser
// → the reservations domain service → ok/fail envelope. The whole booking law
// (in-tx apartment re-read, the W1-A1 live-offer cross-guard → 409
// UNIT_OPTIONED, the revive/dependency/one-hold-per-deal guards, the W2.1
// economics reset, the stage advance, the atomic trail, the P2002 backstop
// mapping) lives in src/lib/services/reservations.ts (bookUnitInTx — the
// shared core the offer conversion also rides).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { RESERVATION_STATUSES } from "@/lib/constants";
import { createReservation, listReservations, withReservationAgents } from "@/lib/services/reservations";
import { reservationDto } from "@/lib/server/reservation-dto";
import { requirePermission } from "@/lib/server/authorize";
import { fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { optionalMoney, parseBody, qp, qpEnum } from "@/lib/server/validation";
import { expireDueReservations } from "@/lib/server/expiry";

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();

    // lazy sweeper — P2-R2: expire past-due ACTIVE reservations before reading
    // (awaited; idempotent no-op when nothing is due).
    await expireDueReservations();

    const params = req.nextUrl.searchParams;
    const query = {
      // W2.9 (master audit — PERF-P1) — pagination params (the leads house
      // pattern): page ≥ 1, pageSize ∈ [1, 500], defaults 1 / 200.
      page: parseIntParam(params.get("page"), 1, { min: 1, max: 100000 }),
      pageSize: parseIntParam(params.get("pageSize"), 200, { min: 1, max: 500 }),
      status: qpEnum(req, "status", RESERVATION_STATUSES),
      apartmentId: qp(req, "apartmentId"),
      opportunityId: qp(req, "opportunityId"),
      id: qp(req, "id"),
    };
    const { data, total, page, pageSize } = await listReservations(user, query);
    return ok({ data, total, page, pageSize });
  } catch (error) {
    return fail(error);
  }
}

// ── POST ──────────────────────────────────────────────────────────────────────

const createSchema = z.object({
  opportunityId: z.string().min(1, "opportunityId requis"),
  apartmentId: z.string().min(1, "apartmentId requis"),
  // W1-2 (Phase 2.1): non-negative money law — negatives were API-reachable
  // while the UI MoneyField strips minus signs (server weaker than client).
  amount: optionalMoney,
  depositPaid: optionalMoney,
  expiresAt: z.coerce.date().nullable().optional(),
  notary: z.string().trim().max(160).nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    // P9-D05 — the permission catalog declares reservations.create for
    // SALES_AGENT+ (the commercial floor); the route previously trusted the
    // visibility scope alone, leaving the floor unenforced (a FIELD_REP with
    // project-scoped opportunities could book units). The catalog is the
    // single source of truth for route gates (D-ARCH-3).
    const user = await requirePermission("reservations.create");
    const body = await parseBody(req, createSchema);
    const { reservation } = await createReservation(user, body, req);
    const [withAgent] = await withReservationAgents([reservation]);
    // Workstream S: the POST 201 body rides the same shared DTO — the
    // creating floor-role caller (the agent who booked) gets the workflow /
    // booking shape with the §37/§38 family absent; a MANAGER+ caller's
    // response is byte-identical to the pre-S shape.
    return ok({ reservation: reservationDto(user, withAgent) }, 201);
  } catch (error) {
    return fail(error);
  }
}
