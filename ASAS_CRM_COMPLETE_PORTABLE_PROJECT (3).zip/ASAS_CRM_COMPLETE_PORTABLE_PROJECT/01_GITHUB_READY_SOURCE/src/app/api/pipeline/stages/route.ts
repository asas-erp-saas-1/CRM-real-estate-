// GET /api/pipeline/stages — stages of the org's default pipeline, ordered.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok, requireUser } from "@/lib/server/session";

export async function GET(_req: NextRequest) {
  try {
    const user = await requireUser();
    const pipeline = await db.pipeline.findFirst({
      where: { orgId: user.orgId, isDefault: true },
    });
    if (!pipeline) return ok({ data: [] });

    const stages = await db.pipelineStage.findMany({
      where: { pipelineId: pipeline.id },
      orderBy: { order: "asc" },
    });

    return ok({ data: stages, pipelineId: pipeline.id });
  } catch (error) {
    return fail(error);
  }
}
