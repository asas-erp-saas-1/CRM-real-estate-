// PATCH /api/pipeline/stages/:id — ADMIN-only WIP-limit editor (P11, D-UX-043).
//        PipelineStage.wipLimit is an optional kanban-column capacity signal
//        (null = unlimited, 1..99). The board NEVER blocks a stage move on it:
//        the UI renders a count/limit chip (amber at capacity, rose over) and
//        warns with a toast on over-limit drops — warn-never-block law.
//        Org-scoped exactly like every data route: the default pipeline is
//        loaded org-first, the stage is then matched INSIDE that pipeline, so
//        a foreign-tenant stage id resolves to 404 (no cross-tenant leak).
//        Every change is audit-logged with before/after wipLimit values.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  wipLimit: z.number().int().min(1).max(99).nullable(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requirePermission("pipeline.stages.manage");
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    // Org scope first: the stage must belong to THIS org's default pipeline.
    const pipeline = await db.pipeline.findFirst({
      where: { orgId, isDefault: true },
      select: { id: true },
    });
    const stage = pipeline
      ? await db.pipelineStage.findFirst({ where: { id, pipelineId: pipeline.id } })
      : null;
    if (!stage) throw new ApiError(404, "Étape de pipeline introuvable", "STAGE_NOT_FOUND");

    // G5-P3-5 (F-06): the WIP-limit change and its audit trail commit as ONE
    // transaction — a crash between them can no longer leave a changed column
    // capacity with no governance record (or an orphaned audit row).
    const updated = await db.$transaction(async (tx) => {
      const row = await tx.pipelineStage.update({
        where: { id: stage.id },
        data: { wipLimit: body.wipLimit },
      });
      injectTxFault(req, "pipeline-stage-patch");

      await logAudit({
        orgId,
        actor: user,
        action: "PIPELINE_STAGE_WIP_LIMIT",
        entity: "PipelineStage",
        entityId: stage.id,
        before: { wipLimit: stage.wipLimit },
        after: { wipLimit: body.wipLimit },
      }, tx);
      return row;
    });

    return ok({ data: updated });
  } catch (error) {
    return fail(error);
  }
}
