// POST /api/public/lead-capture — the PUBLIC, token-gated lead intake (DOM-04).
//
// NO AUTHENTICATION (deliberately): a landing page / WhatsApp bio posts the
// form with ONLY the capture token — no cookie, no org id. The token IS the
// org scope (src/lib/server/lead-capture.ts resolves it). A session cookie,
// present or absent, changes NOTHING (verified by tests: a logged-in caller
// gets the same generic response — the endpoint never reads the session).
//
// CORS-SAFE BY DESIGN: cross-origin is the feature, so this route does NOT go
// through requireUser()/readJson() (the authed mutation choke-points that
// enforce same-origin for CSRF); there is no session to forge here — CSRF is
// a session-forgery attack class. The JSON body is read directly and the
// response is JSON only, never credentialed.
//
// RESPONSE LAW — every accepted outcome (created / duplicate / honeypot /
// min-interval swallow) answers the SAME generic `{ ok: true }`: no lead id,
// no org data, no enumeration signal. Rejections: 401 INVALID_TOKEN (generic
// — unknown/expired/revoked are indistinguishable), 422 VALIDATION_ERROR /
// INVALID_PHONE, 429 RATE_LIMITED (+ Retry-After), 400 INVALID_JSON.
import type { NextRequest } from "next/server";
import { clientIp, fail, ok, ApiError } from "@/lib/server/session";
import {
  publicCaptureBodySchema,
  readPublicCaptureJson,
  submitPublicCapture,
} from "@/lib/server/lead-capture";
import { validate } from "@/lib/server/validation";

export async function POST(req: NextRequest) {
  try {
    const body = validate(publicCaptureBodySchema, await readPublicCaptureJson(req));
    const outcome = await submitPublicCapture({ ip: await clientIp(), body });
    // Generic success — the outcome kind is internal (tests read it from the
    // DB, never from this response).
    void outcome;
    return ok({ ok: true });
  } catch (error) {
    // Rate-limited answers carry the standard envelope + Retry-After.
    if (error instanceof ApiError && error.code === "RATE_LIMITED") {
      const res = await fail(error);
      const retryAfter = (error.details as { retryAfterSec?: number } | null)?.retryAfterSec ?? 60;
      res.headers.set("Retry-After", String(Math.max(1, Math.ceil(retryAfter))));
      return res;
    }
    return fail(error);
  }
}
