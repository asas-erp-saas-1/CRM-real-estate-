// ASAS — Org settings API (R5): matching weight tuning + notification thresholds.
//
// GET /api/settings  → { settings } (defaults merged over persisted rows)
// PUT /api/settings  → { settings } (MANAGER+ only; full-shape zod validation;
//                       SETTINGS_UPDATED audit entry with before/after snapshot —
//                       API-06: the four per-key upserts + the audit row commit
//                       as ONE transaction, F-06)
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { getOrgSettings, saveOrgSettings, settingsSchema } from "@/lib/server/settings";
import { fail, ok, requireUser } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

export async function GET() {
  try {
    const user = await requireUser();
    const settings = await getOrgSettings(user.orgId);
    return ok({ settings });
  } catch (error) {
    return fail(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await requirePermission("settings.manage");
    const body = await parseBody(req, settingsSchema);

    const before = await getOrgSettings(user.orgId);
    // API-06 (F-06): the four per-key upserts + the SETTINGS_UPDATED audit
    // row commit as ONE transaction — previously the writes committed and
    // the audit followed outside them, so a crash between the two left
    // silently re-keyed settings (matching weights!) with no trail. The
    // after-read rides the SAME tx client (the settings helpers take the
    // DbOrTx — the audit.ts law) so the snapshot reflects what THIS
    // transaction is committing.
    const settings = await db.$transaction(async (tx) => {
      await saveOrgSettings(user.orgId, body, tx);
      const after = await getOrgSettings(user.orgId, tx);
      await logAudit({
        orgId: user.orgId,
        actor: user,
        action: "SETTINGS_UPDATED",
        entity: "ORGANIZATION",
        entityId: user.orgId,
        before: {
          matchingWeights: before["matching.weights"],
          uncontactedHours: before["notifications.uncontactedHours"],
          expiringReservationsDays: before["notifications.expiringReservationsDays"],
          defaultExpiryDays: before["reservations.defaultExpiryDays"],
          // R2 — the commercial policies join the audit snapshot.
          discountPolicy: before["offer.discount.policy"],
          freshnessPolicy: before["inventory.freshness"],
        },
        after: {
          matchingWeights: after["matching.weights"],
          uncontactedHours: after["notifications.uncontactedHours"],
          expiringReservationsDays: after["notifications.expiringReservationsDays"],
          defaultExpiryDays: after["reservations.defaultExpiryDays"],
          discountPolicy: after["offer.discount.policy"],
          freshnessPolicy: after["inventory.freshness"],
        },
      }, tx);
      return after;
    });

    return ok({ settings });
  } catch (error) {
    return fail(error);
  }
}
