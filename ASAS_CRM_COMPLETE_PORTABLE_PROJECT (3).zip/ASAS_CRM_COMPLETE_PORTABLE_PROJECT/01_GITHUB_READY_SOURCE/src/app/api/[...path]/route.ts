// ALL /api/* — the unknown-path JSON 404 (W5-3, Phase 2.1 — A6#10 → P5/W2-A6).
//
// Next.js answers unmatched /api/* paths with its HTML 404 page; every REAL
// route answers in the { error, code } JSON envelope. API-only consumers
// (monitors, integrations, the client's api.ts) previously got HTML on a
// typo'd path. Static and dynamic routes always take precedence over this
// catch-all — it fires ONLY on genuinely unknown paths, for every method,
// with the same envelope + no-store contract as the auth-gate 404s.
//
// P5/W2-A6 (P4-L08 — the A6-F04 gap): this route previously built its
// NextResponse directly and therefore bypassed ok()/fail() — no structured
// log line, no obs recording, while obs.ts claimed "every API response
// passes through one of them". An unknown path IS a normal API path
// semantically (typo'd client, scanner noise), so it now gets the SAME
// side effects a fail(new ApiError(404, …, "NOT_FOUND")) would produce:
// one `api_error` structured line + route-stat + NOT_FOUND error-category
// counters. The RESPONSE is byte-identical to the pre-fix shape (status
// 404, { error, code } body, Cache-Control: no-store) — pinned by
// tests/contract/api.test.ts and the phase-4 security probe log, so ONLY
// the logging/metrics side effects changed, never the wire contract.
import { NextResponse } from "next/server";
import { logEvent } from "@/lib/server/logger";
import { recordApiRequest, recordErrorCategory } from "@/lib/server/obs";
import { requestContext } from "@/lib/server/session";

async function jsonNotFound() {
  const ctx = await requestContext();
  const durationMs = Math.max(Date.now() - ctx.startedAtMs, 0);
  recordApiRequest(ctx.route, ctx.method, 404, durationMs);
  recordErrorCategory("NOT_FOUND");
  // Same shape/level as fail()'s classified 404s (a real NOT_FOUND route
  // logs an api_error line at error level — this path is no different).
  logEvent("error", "api_error", {
    requestId: ctx.requestId,
    route: ctx.route,
    method: ctx.method,
    status: 404,
    category: "NOT_FOUND",
    code: "NOT_FOUND",
  });
  return NextResponse.json(
    { error: "Route API inconnue", code: "NOT_FOUND" },
    { status: 404, headers: { "Cache-Control": "no-store" } },
  );
}

export const GET = jsonNotFound;
export const POST = jsonNotFound;
export const PATCH = jsonNotFound;
export const PUT = jsonNotFound;
export const DELETE = jsonNotFound;
