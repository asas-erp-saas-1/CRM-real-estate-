// POST /api/finance/payments — record a settlement against a schedule line
// (P13, D-022, MANAGER+). Thin HTTP adapter (W2-A3, ARCH-01): zod contract →
// requireUser → the payments domain service → ok/fail envelope. Every business
// law (payable-line gate, in-tx balance decision, PAID stamp, atomic
// audit/activity trail, the "payments-post" fault-injection site) lives in
// src/lib/services/payments.ts.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { SETTLEMENT_METHODS } from "@/lib/constants";
import { recordPayment } from "@/lib/services/payments";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { MAX_MONEY_DZD, parseBody } from "@/lib/server/validation";

const paymentSchema = z.object({
  installmentId: z.string().min(1, "installmentId requis"),
  amount: z.preprocess(
    (v) => (v === "" || v === null ? undefined : typeof v === "string" ? Number(v) : v),
    // DB-12 (cap single-sourcing): the ceiling imports MAX_MONEY_DZD — the
    // shared optionalMoney cap (10 milliards DZD, validation.ts) — instead of
    // this route's old private 1e12: a payment could previously exceed
    // every other money field's law by two orders of magnitude. .positive()
    // stays (a payment is strictly > 0; optionalMoney's 0 is for fields a
    // form can legitimately leave at zero).
    z.number().positive("Montant requis").max(MAX_MONEY_DZD, "Montant hors limites"),
  ),
  method: z.enum(SETTLEMENT_METHODS).default("TRANSFER"),
  paidAt: z.coerce.date().optional(),
  reference: z.string().trim().max(120).nullable().optional(),
  notes: z.string().trim().max(500).nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("payments.record");
    const body = await parseBody(req, paymentSchema);
    const { payment, installment } = await recordPayment(user, body, req);
    return ok({ payment, installment }, 201);
  } catch (error) {
    return fail(error);
  }
}
