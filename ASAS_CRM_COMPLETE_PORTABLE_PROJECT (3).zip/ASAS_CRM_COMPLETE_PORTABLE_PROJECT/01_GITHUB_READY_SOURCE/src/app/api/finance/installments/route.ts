// GET  /api/finance/installments — the échéancier list (P13, D-022).
// POST /api/finance/installments — add a schedule line (MANAGER+).
// Thin HTTP adapters (W2-A3, ARCH-01): query-param parsing → requireUser →
// the installments domain service → ok/fail envelope. Every law (derived
// buckets, scoped reads, seq claim, atomic audit trail) lives in
// src/lib/services/installments.ts.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { INSTALLMENT_KINDS, INSTALLMENT_STATUSES } from "@/lib/constants";
import { createInstallment, listInstallments } from "@/lib/services/installments";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { MAX_MONEY_DZD, parseBody, qp, qpEnum } from "@/lib/server/validation";

export async function GET(req: NextRequest) {
  try {
    // P9-D04 — the catalog's payments.view (SALES_AGENT+; FIELD_REP
    // excluded) now gates the échéancier read: the scope fragment alone let
    // a project-assigned FIELD_REP read installment amounts, due dates and
    // payment history (installments route audit D1). Zero behavior change
    // for MANAGER+/SALES_AGENT; the catalog is the contract (D-ARCH-3).
    const user = await requirePermission("payments.view");
    const filters = {
      bucket: qpEnum(req, "bucket", ["overdue", "due", "upcoming", "paid"] as const),
      status: qpEnum(req, "status", INSTALLMENT_STATUSES),
      reservationId: qp(req, "reservationId") || undefined,
      query: (qp(req, "query") || qp(req, "q") || "").trim() || undefined,
    };
    const { data, total } = await listInstallments(user, filters);
    return ok({ data, total });
  } catch (error) {
    return fail(error);
  }
}

const createSchema = z.object({
  reservationId: z.string().min(1, "reservationId requis"),
  label: z.string().trim().min(1, "Libellé requis").max(120),
  kind: z.enum(INSTALLMENT_KINDS).default("INSTALLMENT"),
  amount: z.preprocess(
    (v) => (v === "" || v === null ? undefined : typeof v === "string" ? Number(v) : v),
    // C8 / P4-M04 (Phase 5): the schedule-line ceiling is the ONE shared DZD
    // money law (MAX_MONEY_DZD, 10 milliards) — this route previously carried
    // a private 1e12, 100× every other money field's cap. Boundary proof:
    // tests/security/money-cap.test.ts.
    z.number().positive("Montant requis").max(MAX_MONEY_DZD, "Montant hors limites"),
  ),
  dueAt: z.coerce.date().nullable().optional(),
  notes: z.string().trim().max(500).nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    // Money recording is management work (D-022 law 2).
    const user = await requirePermission("payments.record");
    const body = await parseBody(req, createSchema);
    const installment = await createInstallment(user, body, req);
    return ok({ installment }, 201);
  } catch (error) {
    return fail(error);
  }
}
