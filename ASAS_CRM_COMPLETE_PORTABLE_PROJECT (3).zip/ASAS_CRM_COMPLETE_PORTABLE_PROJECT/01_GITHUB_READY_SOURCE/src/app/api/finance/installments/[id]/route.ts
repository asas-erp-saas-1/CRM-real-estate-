// PATCH /api/finance/installments/:id — schedule-line lifecycle (P13, D-022,
// MANAGER+). Thin HTTP adapter (W2-A3, ARCH-01): zod contract → requireUser →
// the installments domain service → ok/fail envelope. The lifecycle laws
// (PAID never hand-set, CALLED only from PLANNED, PAID immutability,
// amount-below-collected, atomic audit trail) live in
// src/lib/services/installments.ts (planInstallmentUpdate / updateInstallment).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { INSTALLMENT_KINDS } from "@/lib/constants";
import { updateInstallment } from "@/lib/services/installments";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { MAX_MONEY_DZD, parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  label: z.string().trim().min(1).max(120).optional(),
  kind: z.enum(INSTALLMENT_KINDS).optional(),
  amount: z.preprocess(
    (v) => (v === "" || v === null ? undefined : typeof v === "string" ? Number(v) : v),
    // C8 / P4-M04 (Phase 5): the ONE shared DZD money law (MAX_MONEY_DZD,
    // 10 milliards) — this route previously carried a private 1e12, 100×
    // every other money field's cap. Boundary proof:
    // tests/security/money-cap.test.ts.
    z.number().positive("Montant invalide").max(MAX_MONEY_DZD, "Montant hors limites").optional(),
  ),
  dueAt: z.coerce.date().nullable().optional(),
  notes: z.string().trim().max(500).nullable().optional(),
  status: z.enum(["CALLED", "CANCELLED"]).optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requirePermission("payments.record");
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);
    const { installment } = await updateInstallment(user, id, body, req);
    return ok({ installment });
  } catch (error) {
    return fail(error);
  }
}
