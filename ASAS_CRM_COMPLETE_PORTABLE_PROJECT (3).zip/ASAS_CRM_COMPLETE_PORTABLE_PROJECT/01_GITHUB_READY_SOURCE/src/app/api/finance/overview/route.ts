// GET /api/finance/overview — collections KPI block (P13, D-022, MANAGER+).
// The finance workspace header + the deep metrics behind the dashboard card.
// Gated exactly like /api/analytics: collections are a management aggregate.
//
// KPI semantics (D-022):
//   scheduled  — sum of non-cancelled schedule amounts (the whole échéancier)
//   called     — everything ever called for funds (CALLED + PAID lines)
//   collected  — sum of all Payment rows (money actually in)
//   outstanding— called − collected (≥ 0 by the payment-route guard)
//   overdue*   — derived: CALLED ∧ dueAt < now ∧ unsettled
//   dueSoon7d* — derived: CALLED ∧ dueAt ∈ [now, now+7d] ∧ unsettled
//   collectedThisMonth — payments with paidAt ≥ month start
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { MONEY_EPSILON } from "@/lib/services/payments"; // DB-AUDIT P3-3 fix — the money-scale epsilon, single-sourced

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("finance.overview");
    const orgId = user.orgId;
    const now = new Date();
    const in7d = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    // one bounded fetch of live lines (CALLED/PLANNED/PAID — cancelled excluded
    // from every aggregate); per-row unsettled needs the payments sum in memory.
    // API-11 (master audit — PERF, deliberate skip): this scan stays UNBOUNDED —
    // every aggregate below (scheduled/called sums, byProject buckets, the
    // derived overdue/dueSoon counts) is a TOTAL over the org's whole
    // non-cancelled échéancier, so a row cap (the installments list's take:500)
    // would silently UNDER-REPORT the KPI block: correctness > cap (the list
    // route can cap because it renders rows; this route computes totals).
    // Bounding it properly wants SQL-side aggregation (groupBy/_sum), not a
    // take — out of scope this round by the finding's own judgment call.
    const rows = await db.installment.findMany({
      where: { orgId, status: { not: "CANCELLED" } },
      select: {
        amount: true,
        status: true,
        dueAt: true,
        payments: { select: { amount: true } },
        reservation: {
          select: { apartment: { select: { building: { select: { project: { select: { id: true, name: true } } } } } } },
        },
      },
    });

    const [collectedAgg, monthAgg] = await Promise.all([
      db.payment.aggregate({ where: { orgId }, _sum: { amount: true } }),
      db.payment.aggregate({ where: { orgId, paidAt: { gte: monthStart } }, _sum: { amount: true } }),
    ]);

    let scheduled = 0;
    let called = 0;
    let overdueCount = 0;
    let overdueAmount = 0;
    let dueSoonCount = 0;
    let dueSoonAmount = 0;
    const byProject = new Map<string, { projectId: string; projectName: string; scheduled: number; collected: number; overdueAmount: number }>();

    for (const row of rows) {
      const paid = row.payments.reduce((sum, p) => sum + p.amount, 0);
      const unsettled = paid < row.amount - MONEY_EPSILON;
      scheduled += row.amount;
      if (row.status === "CALLED" || row.status === "PAID") called += row.amount;

      const project = row.reservation.apartment.building.project;
      const bucket = byProject.get(project.id) ?? {
        projectId: project.id,
        projectName: project.name,
        scheduled: 0,
        collected: 0,
        overdueAmount: 0,
      };
      bucket.scheduled += row.amount;
      bucket.collected += paid;
      byProject.set(project.id, bucket);

      if (row.status === "CALLED" && unsettled) {
        if (row.dueAt && row.dueAt < now) {
          overdueCount += 1;
          overdueAmount += row.amount - paid;
          bucket.overdueAmount += row.amount - paid;
        } else if (row.dueAt && row.dueAt <= in7d) {
          dueSoonCount += 1;
          dueSoonAmount += row.amount - paid;
        }
      }
    }

    const collected = collectedAgg._sum.amount ?? 0;
    const collectedThisMonth = monthAgg._sum.amount ?? 0;

    return ok({
      kpis: {
        scheduled,
        called,
        collected,
        outstanding: Math.max(0, called - collected),
        overdueCount,
        overdueAmount,
        dueSoonCount,
        dueSoonAmount,
        collectedThisMonth,
      },
      byProject: Array.from(byProject.values()).sort((a, b) => b.scheduled - a.scheduled),
    });
  } catch (error) {
    return fail(error);
  }
}
