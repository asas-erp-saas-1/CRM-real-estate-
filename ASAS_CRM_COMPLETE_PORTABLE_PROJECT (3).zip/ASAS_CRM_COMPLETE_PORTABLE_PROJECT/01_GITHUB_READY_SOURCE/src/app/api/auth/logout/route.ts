// POST /api/auth/logout — R7 → P2/W2 (Agent 2): SERVER-SIDE session revocation.
//
// Before P2: logout only cleared the client cookie — the HMAC value itself
// stayed valid until expiry (7 days): a stolen copy of the cookie (XSS dump,
// shared machine, proxy log) kept FULL access after the user "logged out".
// Now the route ALSO writes an exact (userId, issuedAtMs) revocation row:
// the ended cookie — and any copy of it — no longer authenticates
// (getCurrentUser rejects the pair; verified by the replay test in
// tests/security/session-governance.test.ts).
//
// Stays idempotent on stale sessions (a logout without a valid session is a
// no-op that still clears the cookie) and same-origin-guarded (P5: cross-site
// logout CSRF).
import type { NextRequest } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { SESSION_COOKIE, assertSameOrigin, fail, getCurrentUser, ok, readSessionIssuedAt } from "@/lib/server/session";
import { logAudit } from "@/lib/server/audit";
import { logEvent } from "@/lib/server/logger";

// Inert-row sweep horizon: revocations for cookies issued >8 days ago are
// dead weight (those sessions are absolutely expired anyway) — cleaned on
// the write path, no cron dependency.
const REVOKED_SWEEP_MS = 8 * 24 * 60 * 60 * 1000;

export async function POST(req: NextRequest) {
  try {
    // P5: logout is deliberately not requireUser-gated (idempotent on stale sessions),
    // so the same-origin check is applied explicitly — cross-site logout CSRF.
    assertSameOrigin(req.headers);
    const jar = await cookies();
    const raw = jar.get(SESSION_COOKIE)?.value;
    const user = await getCurrentUser();
    if (user) {
      const issuedAtMs = readSessionIssuedAt(raw);
      if (issuedAtMs !== null) {
        // Exact-pair revocation — idempotent under double-logout (unique index).
        await db.revokedSession.upsert({
          where: { userId_issuedAtMs: { userId: user.id, issuedAtMs: BigInt(issuedAtMs) } },
          create: { userId: user.id, issuedAtMs: BigInt(issuedAtMs), reason: "LOGOUT" },
          update: { reason: "LOGOUT" },
        });
      }
      await logAudit({
        orgId: user.orgId,
        actor: user,
        action: "LOGOUT",
        entity: "USER", // P2-R1 FIX 8: canonical uppercase entity form
        entityId: user.id,
        after: { email: user.email, revokedSession: issuedAtMs !== null },
      });
      // Opportunistic sweep of inert revocation rows (tiny table, bounded).
      try {
        await db.revokedSession.deleteMany({
          where: { revokedAt: { lt: new Date(Date.now() - REVOKED_SWEEP_MS) } },
        });
      } catch {
        // sweep must never block logout
      }
      logEvent("info", "user_logout", { userId: user.id, requestId: undefined });
    }
    const res = await ok({ ok: true });
    res.cookies.set(SESSION_COOKIE, "", { httpOnly: true, sameSite: "lax", path: "/", maxAge: 0 });
    return res;
  } catch (error) {
    return fail(error);
  }
}
