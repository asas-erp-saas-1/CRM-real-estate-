// POST /api/auth/login — R7 production-shape auth (ADR-002 evolution).
// Two flows on one endpoint:
//   1. Credentials: { email, password } — scrypt verification, sliding-window
//      rate limit (5 failures / 15 min → 429 ACCOUNT_LOCKED), audited LOGIN.
//   2. Demo persona quick-login: { userId } — the demo-workspace mechanism
//      shared with the sidebar role switcher (audited LOGIN_QUICK).
//      P2-R1 FIX 2 (F-01/F-03): demo-mode only (403 DEMO_MODE_DISABLED when
//      ASAS_DEMO_MODE=0) AND lockout-respecting (assertNotLocked before
//      issuing — quick-login no longer bypasses the credentials lockout).
// Both set the httpOnly `asas_user` cookie (lax, 7 days — the W1.5 absolute
// SESSION_MAX_AGE_MS; browser and server truth agree) — the value is
// HMAC-signed `${userId}.${issuedAtMs}.${sig}` (P2-R1 FIX 1, F-02).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ApiError, SESSION_COOKIE, clientIp, fail, isDemoMode, isDemoModeMisconfigured, ok, signSession, type SessionUser } from "@/lib/server/session";
import { getDemoWorkspaceOrgId } from "@/lib/server/demo-org";
import { parseBody } from "@/lib/server/validation";
import { assertNotLocked, clearFailures, createIpAttemptWindow, logLoginFailureUnknownEmail, LoginLockedError, recordFailure, verifyPassword } from "@/lib/server/auth";
import { logAudit } from "@/lib/server/audit";

const schema = z.union([
  z.object({
    email: z.string().email("Email invalide"),
    password: z.string().min(1, "Mot de passe requis"),
  }),
  z.object({
    userId: z.string().min(1, "userId requis"),
  }),
]);

// W1.4/W1.5 (master audit — SEC-V03/V04): `secure` in production (HTTPS-only
// transmission; harmless in the plain-HTTP sandbox) and maxAge aligned with
// the server-side SESSION_MAX_AGE_MS (7d) so browser and server agree.
const SESSION_OPTS = {
  httpOnly: true,
  sameSite: "lax",
  path: "/",
  secure: process.env.NODE_ENV === "production",
  maxAge: 7 * 24 * 60 * 60, // 7 days — matches SESSION_MAX_AGE_MS
} as const;

// P4-8 (F-12 — login timing oracle / email enumeration): precomputed
// throwaway hash in the exact `hashPassword` format (scrypt, N=16384/r=8/p=1,
// keylen 32, 16-byte salt — generated once with node:crypto, preimage discarded).
// It is NOT a secret and matches no account: it exists only so that a login
// attempt for a NON-EXISTENT email burns the same scrypt work as one for an
// existing email. Without it, `verifyPassword` short-circuits on
// `stored == null` and the 401 lands in ~8ms vs ~45ms — a timing side channel
// that defeats the byte-identical INVALID_CREDENTIALS body. verifyPassword
// against it always returns false (and even if a submitted password were its
// preimage, `!user` still forces the 401 — no behavior change).
const DUMMY_HASH = "scrypt:34f6eb70089755af06552dbce0aa8bcb:486d8463fcb14e5e9abeb13ac287efe34e7a99f222d5adeef0cdb3164d89c670";

// DB-AUDIT fix (P2) — per-IP throttle (30 failures / 15 min, deliberately
// well above the per-email 5 so a shared NAT office cannot be locked out):
// the email-keyed lockout alone lets an attacker ROTATING distinct emails
// (credential stuffing) retry with a fresh budget per address. In-process
// bounded window — resets on restart (documented single-instance trade-off).
const loginIpWindow = createIpAttemptWindow(
  30,
  15 * 60_000,
  "IP_RATE_LIMITED",
  "Trop de tentatives depuis cette adresse — réessayez plus tard.",
);

export async function POST(req: NextRequest) {
  try {
    const body = await parseBody(req, schema);

    if ("userId" in body) {
      // Demo persona quick-login (sidebar switcher / login overlay grid).
      // P2-R1 FIX 2: rejected outright when demo mode is off, and it now
      // respects the login lockout (F-03 — before, this branch bypassed it).
      // Phase 2 / W2.2 — production fail-fast: a production build with demo
      // mode still on is a deployment MISCONFIGURATION (the F-01 takeover
      // chain); refuse with the exact remedy instead of silently working.
      if (isDemoModeMisconfigured()) {
        throw new ApiError(
          500,
          "Configuration de production invalide : le mode démo est actif. Définissez ASAS_DEMO_MODE=0 sur ce serveur pour activer l'authentification.",
          "DEMO_MODE_PRODUCTION_MISCONFIG",
        );
      }
      if (!isDemoMode()) {
        throw new ApiError(403, "Quick-login désactivé (mode démo inactif).", "DEMO_MODE_DISABLED");
      }
      // P0-4 (F-01 takeover half): quick-login is constrained to the
      // DESIGNATED demo workspace organization (first-created org — see
      // src/lib/server/demo-org.ts). A userId belonging to ANY other
      // organization must fail exactly like a nonexistent id — 404
      // USER_NOT_FOUND with the identical message — so the response carries
      // no org-membership oracle. No organizations at all → same ghost 404.
      const demoOrgId = await getDemoWorkspaceOrgId();
      if (!demoOrgId) {
        throw new ApiError(404, "Utilisateur introuvable ou inactif", "USER_NOT_FOUND");
      }
      const user = await db.user.findFirst({
        where: { id: body.userId, active: true, orgId: demoOrgId },
        select: { id: true, orgId: true, name: true, email: true, role: true },
      });
      if (!user) throw new ApiError(404, "Utilisateur introuvable ou inactif", "USER_NOT_FOUND");
      const sessionUser = user as SessionUser;

      // F-03 — a locked persona stays locked, quick-login or not.
      try {
        await assertNotLocked(user.email);
      } catch (err) {
        if (err instanceof LoginLockedError) {
          // P2/W2 — the lockout itself is a security event worth auditing.
          await logAudit({
            orgId: user.orgId,
            actor: null,
            action: "LOGIN_LOCKED",
            entity: "USER",
            entityId: user.id,
            after: { email: user.email, retryAfterMs: err.retryAfterMs },
          });
          throw new ApiError(
            429,
            `Trop de tentatives échouées — réessayez dans ${Math.ceil(err.retryAfterMs / 60_000)} min.`,
            "ACCOUNT_LOCKED",
            { retryAfterMs: err.retryAfterMs },
          );
        }
        throw err;
      }

      await logAudit({
        orgId: user.orgId,
        actor: sessionUser,
        action: "LOGIN_QUICK",
        entity: "USER", // P2-R1 FIX 8: canonical uppercase entity form
        entityId: user.id,
        after: { email: user.email, role: user.role },
      });
      const res = await ok({ user });
      res.cookies.set(SESSION_COOKIE, signSession(user.id), SESSION_OPTS);
      return res;
    }

    // Credentials flow.
    const email = body.email.trim().toLowerCase();
    const ip = await clientIp();
    // DB-AUDIT fix (P2) — the per-IP window gates BEFORE any email-keyed
    // state is touched, bounding the aggregate damage regardless of how
    // many distinct emails are probed from this address.
    loginIpWindow.assert(ip);
    try {
      await assertNotLocked(email);
    } catch (err) {
      if (err instanceof LoginLockedError) {
        // P2/W2 — audit the lockout when the email maps to a real account
        // (unknown emails carry no org — structured log line instead).
        const lockedUser = await db.user.findFirst({ where: { email }, select: { id: true, orgId: true } });
        if (lockedUser) {
          await logAudit({
            orgId: lockedUser.orgId,
            actor: null,
            action: "LOGIN_LOCKED",
            entity: "USER",
            entityId: lockedUser.id,
            after: { email, retryAfterMs: err.retryAfterMs },
          });
        }
        throw new ApiError(
          429,
          `Trop de tentatives échouées — réessayez dans ${Math.ceil(err.retryAfterMs / 60_000)} min.`,
          "ACCOUNT_LOCKED",
          { retryAfterMs: err.retryAfterMs },
        );
      }
      throw err;
    }

    const user = await db.user.findFirst({
      where: { email, active: true },
      select: { id: true, orgId: true, name: true, email: true, role: true, passwordHash: true },
    });

    // P4-8 (F-12): unknown email (or an account with no hash) verifies against
    // DUMMY_HASH so both arms of the 401 cost one scrypt run — same latency
    // distribution, no enumeration signal. Lockout/quick-login semantics untouched.
    const valid = await verifyPassword(body.password, user?.passwordHash ?? DUMMY_HASH);
    if (!user || !valid) {
      await recordFailure(email, ip);
      loginIpWindow.record(ip);
      if (user) {
        // P2/W2 — security event on a REAL account: AuditLog row with the IP
        // (org known from the account; unknown emails have no org to audit
        // and go to the structured log instead — logLoginFailureUnknownEmail).
        await logAudit({
          orgId: user.orgId,
          actor: null,
          action: "LOGIN_FAILED",
          entity: "USER",
          entityId: user.id,
          after: { email: user.email, ip },
        });
      } else {
        logLoginFailureUnknownEmail(email, ip);
      }
      throw new ApiError(401, "Email ou mot de passe incorrect", "INVALID_CREDENTIALS");
    }

    await clearFailures(email);
    const { passwordHash: _hash, ...session } = user;
    void _hash;
    const sessionUser = session as SessionUser;
    await logAudit({
      orgId: user.orgId,
      actor: sessionUser,
      action: "LOGIN",
      entity: "USER", // P2-R1 FIX 8: canonical uppercase entity form
      entityId: user.id,
      after: { email: user.email, role: user.role },
    });
    const res = await ok({ user: session });
    res.cookies.set(SESSION_COOKIE, signSession(user.id), SESSION_OPTS);
    return res;
  } catch (error) {
    return fail(error);
  }
}
