// POST /api/auth/change-password — ANY authenticated user, own password only
// (R8-2). Body: { currentPassword, newPassword }.
//  - current password is verified (401 WRONG_PASSWORD on mismatch);
//  - newPassword must be ≥ 12 chars (422 VALIDATION_ERROR) — DB-AUDIT fix
//    (P3): aligned with the bootstrap/redeem policy (PASSWORD_MIN=12 across
//    every password-issuing surface; the previous 8 was the lone outlier);
//  - new scrypt hash stored, audited USER_PASSWORD_CHANGED (userId only —
//    passwords NEVER land in the audit trail, not even hashed);
//  - P2-R1 (F-05): `passwordChangedAt` is bumped, so every session cookie
//    issued before the change — INCLUDING the caller's current one — is
//    invalidated (accepted: the user re-authenticates with the new password;
//    the client shows the login overlay on the next 401 NO_SESSION).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { clearFailures, hashPassword, verifyPassword } from "@/lib/server/auth";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

const schema = z.object({
  currentPassword: z.string().min(1, "Mot de passe actuel requis"),
  newPassword: z.string().min(12, "Le nouveau mot de passe doit contenir au moins 12 caractères"),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, schema);

    const record = await db.user.findUnique({
      where: { id: user.id },
      select: { id: true, email: true, passwordHash: true },
    });

    const valid = await verifyPassword(body.currentPassword, record?.passwordHash);
    if (!record || !valid) {
      throw new ApiError(401, "Mot de passe actuel incorrect", "WRONG_PASSWORD");
    }

    const passwordHash = await hashPassword(body.newPassword);
    // P2-R1 FIX 1/F-05: bumping passwordChangedAt invalidates every session
    // issued before this moment (signed-cookie issuedAt < passwordChangedAt
    // → 401 on the next request — including the cookie used for THIS call).
    await db.user.update({ where: { id: user.id }, data: { passwordHash, passwordChangedAt: new Date() } });

    // Defensive: a successful own-password change also clears lockout state.
    await clearFailures(record.email);

    await logAudit({
      orgId: user.orgId,
      actor: user,
      action: "USER_PASSWORD_CHANGED",
      entity: "USER", // P2-R1 FIX 8: canonical uppercase entity form
      entityId: user.id,
      after: { userId: user.id }, // no password material, ever
    });

    return ok({ changed: true });
  } catch (error) {
    return fail(error);
  }
}
