// POST /api/auth/sessions/revoke-all — P2/W2 (Agent 2): the kill switch.
//
// Two authority modes:
//   · SELF (no body): any authenticated user revokes EVERY session of their
//     own account — "déconnecter tous mes appareils" (lost/stolen device,
//     shared-machine hygiene). The current cookie is cleared too.
//   · ADMIN+ (body { userId }): an ADMIN/OWNER force-terminates every session
//     of a user in THEIR OWN organization (offboarding, suspected compromise)
//     — org isolation enforced, an ADMIN of org A can never touch org B.
//
// Mechanics: sets the user's `sessionsRevokedAt` watermark — getCurrentUser()
// already reads that column from the SAME user row it fetches per request, so
// every cookie issued before the watermark dies on its next use with ZERO
// additional per-request cost. Audited as SESSIONS_REVOKED with actor/target.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ApiError, SESSION_COOKIE, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";
import { logAudit } from "@/lib/server/audit";
import { logEvent } from "@/lib/server/logger";

const schema = z
  .object({
    userId: z.string().min(1).optional(),
  })
  .strict();

export async function POST(req: NextRequest) {
  try {
    const body = await parseBody(req, schema);
    const requester = await requireUser();

    let targetId: string;
    if (body.userId && body.userId !== requester.id) {
      // Admin force-revocation of ANOTHER user — ADMIN+ and same-org only.
      if (requester.role !== "ADMIN" && requester.role !== "OWNER") {
        throw new ApiError(403, "Seul un administrateur peut révoquer les sessions d'un autre compte.", "FORBIDDEN_ROLE");
      }
      const target = await db.user.findFirst({
        where: { id: body.userId, orgId: requester.orgId },
        select: { id: true, email: true },
      });
      if (!target) {
        // Identical body for missing AND foreign-org users — no org-membership
        // oracle (the P0-4 lesson, applied consistently).
        throw new ApiError(404, "Utilisateur introuvable", "USER_NOT_FOUND");
      }
      targetId = target.id;
    } else {
      targetId = requester.id;
    }

    const now = new Date();
    await db.user.update({
      where: { id: targetId },
      data: { sessionsRevokedAt: now },
    });

    const isSelf = targetId === requester.id;
    const target = await db.user.findUnique({ where: { id: targetId }, select: { email: true } });
    await logAudit({
      orgId: requester.orgId,
      actor: requester,
      action: "SESSIONS_REVOKED",
      entity: "USER",
      entityId: targetId,
      after: { email: target?.email ?? null, mode: isSelf ? "SELF" : "ADMIN", watermark: now.toISOString() },
    });
    logEvent("warn", "sessions_revoked", { targetUserId: targetId, mode: isSelf ? "SELF" : "ADMIN" });

    const res = await ok({ ok: true, revokedAt: now.toISOString(), self: isSelf });
    if (isSelf) {
      // The caller's own cookie is dead too (issued < watermark) — clear it
      // client-side so the UI lands on the login overlay immediately.
      res.cookies.set(SESSION_COOKIE, "", { httpOnly: true, sameSite: "lax", path: "/", maxAge: 0 });
    }
    return res;
  } catch (error) {
    return fail(error);
  }
}
