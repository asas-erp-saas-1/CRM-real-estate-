// POST /api/auth/bootstrap — Phase 7.2 first-run OWNER provisioning.
//
// WHY THIS EXISTS: the Z.ai native hosting artifact bakes the database at
// BUILD time, and the sandbox R13 restore law wipes the untracked dev DB
// before every publish window — so a freshly published instance can boot
// with a schema-only, ZERO-user database (the 2026-11-08 owner lockout:
// every login answered 401 INVALID_CREDENTIALS because the hosted User
// table was empty; see ASAS_PHASE7_2_AUTHENTICATION_TRACE_REPORT.md).
// The sanctioned CLI (scripts/provision-owner.ts) cannot be executed by
// the owner — they have no terminal. This route is its IN-APP equivalent,
// executed by the owner against the hosted instance so the owner's
// password never transits terminal logs, reports, source code or chat.
//
// LAWS (ported verbatim from scripts/provision-owner.ts — the Phase 5 / C4
// sanctioned initial-owner policy):
//   · Available ONLY while the database contains ZERO users (and demo mode
//     is off). Once any account exists this route refuses forever — the
//     bootstrap is once-only by design, exactly like the CLI's idempotence
//     guard. Never a second OWNER, never a takeover surface.
//   · Password ≥ 12 chars, and the PUBLIC demo password ("asas1234") is
//     rejected outright — a production OWNER must not be reachable with a
//     credential shown on the login overlay.
//   · Destructive scope: creates ONE organization (only when none exists)
//     and ONE OWNER user — nothing else.
//   · The password is NEVER echoed, logged or audited; only the email,
//     name, role and org identity are recorded (BOOTSTRAP_OWNER audit).
//   · Rate-limited by the SAME DB-backed sliding window as credential
//     login (5 failures / 15 min → 429 ACCOUNT_LOCKED) — the endpoint is
//     web-exposed, so the CLI's "operator trust" assumption is replaced
//     with the login route's lockout discipline.
//   · On success the session cookie is issued immediately (the owner lands
//     in the CRM without a second round-trip login).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ApiError, SESSION_COOKIE, clientIp, fail, isDemoMode, ok, signSession, type SessionUser } from "@/lib/server/session";
import { assertNotLocked, clearFailures, createIpAttemptWindow, DEMO_PASSWORD, hashPassword, LoginLockedError, recordFailure } from "@/lib/server/auth";
import { logAudit } from "@/lib/server/audit";
import { logEvent } from "@/lib/server/logger";
import { parseBody } from "@/lib/server/validation";

/** Mirrors scripts/provision-owner.ts MIN_PASSWORD_LENGTH. */
const MIN_PASSWORD_LENGTH = 12;

// DB-AUDIT fix (P2) — per-IP throttle for the first-run takeover window
// (10 attempts / hour): the email-keyed lockout below is keyed by the
// ATTACKER-CHOSEN email, so rotating emails gave a fresh 5-try budget per
// address while the instance was still zero-user. The window stays open
// until the legitimate owner claims it — this bounds the scramble itself.
// In-process bounded window — resets on restart (documented trade-off).
const bootstrapIpWindow = createIpAttemptWindow(
  10,
  60 * 60_000,
  "BOOTSTRAP_IP_RATE_LIMITED",
  "Trop de tentatives depuis cette adresse — réessayez dans une heure.",
);

const schema = z.object({
  email: z.string().email("Email invalide"),
  // provision-owner law: a real display name (≥2 chars after trim).
  name: z.string().trim().min(2, "Nom requis (2 caractères minimum)"),
  password: z.string().min(1, "Mot de passe requis"),
  orgName: z.string().trim().min(2).max(80).optional(),
});

// Same cookie posture as POST /api/auth/login (W1.4/W1.5 master audit).
const SESSION_OPTS = {
  httpOnly: true,
  sameSite: "lax",
  path: "/",
  secure: process.env.NODE_ENV === "production",
  maxAge: 7 * 24 * 60 * 60, // 7 days — matches SESSION_MAX_AGE_MS
} as const;

export async function POST(req: NextRequest) {
  try {
    // ── Gate 1: demo posture — the bootstrap is a production-posture path. ──
    if (isDemoMode()) {
      throw new ApiError(403, "Provisionnement initial indisponible en mode démo.", "BOOTSTRAP_DEMO_MODE");
    }

    // ── Gate 2: once-only. Any existing account disables the bootstrap ──
    // forever (read-check here; re-checked INSIDE the write transaction to
    // close the concurrent-request race below).
    if ((await db.user.count()) > 0) {
      throw new ApiError(404, "Un compte existe déjà — le provisionnement initial est terminé.", "BOOTSTRAP_UNAVAILABLE");
    }

    const body = await parseBody(req, schema);
    const email = body.email.trim().toLowerCase();
    const ip = await clientIp();
    // ── Gate 2b (DB-AUDIT P2 fix): per-IP throttle — bounds the takeover
    // scramble per source address (see the window's docblock above). ──
    bootstrapIpWindow.assert(ip);

    // ── Gate 3: rate limit (same DB-backed window as credential login). ──
    try {
      await assertNotLocked(email);
    } catch (err) {
      if (err instanceof LoginLockedError) {
        throw new ApiError(
          429,
          `Trop de tentatives échouées — réessayez dans ${Math.ceil(err.retryAfterMs / 60_000)} min.`,
          "ACCOUNT_LOCKED",
          { retryAfterMs: err.retryAfterMs },
        );
      }
      throw err;
    }

    // ── Gate 4: provision-owner password laws (F-04/C4 policy). ──────────
    if (body.password === DEMO_PASSWORD) {
      await recordFailure(email, ip);
      bootstrapIpWindow.record(ip);
      throw new ApiError(
        422,
        "Refusé — c'est le mot de passe démo PUBLIC. Choisissez un mot de passe privé d'au moins 12 caractères.",
        "BOOTSTRAP_DEMO_PASSWORD",
      );
    }
    if (body.password.length < MIN_PASSWORD_LENGTH) {
      await recordFailure(email, ip);
      bootstrapIpWindow.record(ip);
      throw new ApiError(
        422,
        `Le mot de passe doit contenir au moins ${MIN_PASSWORD_LENGTH} caractères.`,
        "BOOTSTRAP_WEAK_PASSWORD",
      );
    }

    const passwordHash = await hashPassword(body.password);

    // ── The write: ONE org (when none) + ONE OWNER, inside a transaction ──
    // that re-asserts the zero-user precondition — a racing pair of requests
    // serializes on the SQLite writer and the loser sees count > 0 → 404.
    const created = await db.$transaction(async (tx) => {
      if ((await tx.user.count()) > 0) return null;

      let org = await tx.organization.findFirst({ orderBy: { createdAt: "asc" }, select: { id: true, name: true, slug: true } });
      let createdOrg = false;
      if (!org) {
        const slug =
          email
            .split("@")[1]!
            .toLowerCase()
            .replace(/[^a-z0-9-]+/g, "-")
            .slice(0, 40) || "asas";
        org = await tx.organization.create({
          data: { name: body.orgName ?? "ASAS Immobilier", slug },
          select: { id: true, name: true, slug: true },
        });
        createdOrg = true;
      }

      const owner = await tx.user.create({
        data: { orgId: org.id, email, name: body.name, role: "OWNER", phone: null, passwordHash },
        select: { id: true, orgId: true, name: true, email: true, role: true },
      });
      return { owner, org, createdOrg };
    });

    if (!created) {
      // Lost the race — an account appeared between the gate and the tx.
      await recordFailure(email, ip);
      bootstrapIpWindow.record(ip);
      throw new ApiError(404, "Un compte existe déjà — le provisionnement initial est terminé.", "BOOTSTRAP_UNAVAILABLE");
    }

    await clearFailures(email);
    const sessionUser = created.owner as SessionUser;

    // Security event — email/name/org identity only, NEVER the password
    // (the audit row is the durable record of who claimed the instance).
    await logAudit({
      orgId: created.org.id,
      actor: sessionUser,
      action: "BOOTSTRAP_OWNER",
      entity: "USER",
      entityId: created.owner.id,
      after: {
        email: created.owner.email,
        name: created.owner.name,
        role: "OWNER",
        org: { id: created.org.id, name: created.org.name, slug: created.org.slug, createdNow: created.createdOrg },
      },
    });
    logEvent("info", "bootstrap_owner_success", { email, orgSlug: created.org.slug, createdOrg: created.createdOrg });

    const res = await ok({
      user: created.owner,
      organization: { id: created.org.id, name: created.org.name, slug: created.org.slug },
    });
    res.cookies.set(SESSION_COOKIE, signSession(created.owner.id), SESSION_OPTS);
    return res;
  } catch (error) {
    return fail(error);
  }
}
