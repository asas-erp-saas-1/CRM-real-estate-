// GET /api/auth/session — current user + organization (ADR-002 cookie session).
// R7: when there is NO session, the response carries `demoUsers` (id, name,
// role only) so the client login overlay can render its quick-access persona
// grid without hitting any authenticated endpoint.
// P2-R1 FIX 2 (F-01): `demoUsers` is a DEMO-MODE surface — with
// ASAS_DEMO_MODE=0 (production) the unauthenticated response returns an
// empty list (never discloses user ids). Authenticated responses unchanged.
// P0-4 (F-01 org isolation): the listing is also scoped to the DESIGNATED
// demo workspace organization (first-created org — see
// src/lib/server/demo-org.ts). In a multi-org database the unauthenticated
// roster can never disclose another organization's users.
import type { NextRequest } from "next/server";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { fail, getCurrentUser, isDemoMode, isDemoModeMisconfigured, ok, readSessionIssuedAt, SESSION_COOKIE, SESSION_MAX_AGE_MS } from "@/lib/server/session";
import { bootstrapAvailable } from "@/lib/server/bootstrap";
import { getDemoWorkspaceOrgId } from "@/lib/server/demo-org";

export async function GET(_req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      // Phase 2 / W2.2 — production fail-fast: demoUsers are ALSO suppressed
      // in a misconfigured production (demo still on) — the unauthenticated
      // persona listing is half of the F-01 chain and must never leak there.
      if (!isDemoMode() || isDemoModeMisconfigured()) {
        // Phase 7.2 — first-run OWNER bootstrap signal: a production-posture
        // instance whose database still holds ZERO users advertises it (the
        // login overlay renders the one-time owner setup form instead of the
        // credential form). Server-driven, exactly like `demoUsers`: the
        // client never decides availability — /api/auth/bootstrap itself
        // re-asserts the zero-user + demo-off gates on every POST.
        return ok({ user: null, organization: null, demoUsers: [], bootstrapAvailable: await bootstrapAvailable() });
      }
      // P0-4: scope the persona grid to the designated demo workspace org.
      // No organizations at all → no demo workspace → empty roster (never an
      // unscoped cross-org query).
      const demoOrgId = await getDemoWorkspaceOrgId();
      if (!demoOrgId) {
        return ok({ user: null, organization: null, demoUsers: [] });
      }
      const demoUsers = await db.user.findMany({
        where: { active: true, orgId: demoOrgId },
        select: { id: true, name: true, role: true },
        orderBy: { createdAt: "asc" },
        take: 8,
      });
      return ok({ user: null, organization: null, demoUsers });
    }
    const organization = await db.organization.findUnique({
      where: { id: user.orgId },
      select: { id: true, name: true, slug: true },
    });
    // P2/W2 — session card metadata (Settings → Sécurité des sessions):
    // when THIS cookie was issued and when it expires absolutely. Read-only,
    // self-scoped (the caller can only ever see their own session's dates).
    const issuedAtMs = readSessionIssuedAt((await cookies()).get(SESSION_COOKIE)?.value);
    const sessionMeta =
      issuedAtMs !== null
        ? {
            issuedAt: new Date(issuedAtMs).toISOString(),
            expiresAt: new Date(issuedAtMs + SESSION_MAX_AGE_MS).toISOString(),
          }
        : null;
    return ok({ user, organization, session: sessionMeta });
  } catch (error) {
    return fail(error);
  }
}
