// POST /api/auth/redeem-token — PUBLIC (no session): single-use account-token
// redemption (Phase 8, A1 — the mandate's §3.A.D/E flows).
//
// Body: { token, newPassword }
//   · token      — the one-time INVITE (account activation) or RESET (password
//                  recovery) capability the OWNER/ADMIN surface minted and
//                  handed to the employee out-of-band;
//   · newPassword — chosen by the EMPLOYEE (never shared with the admin):
//                  ≥12 chars (the bootstrap law), not the demo password.
//
// Effects (ONE transaction — consume-or-nothing):
//   · the token's usedAt is set (single-use, replay-dead);
//   · the target user's passwordHash + passwordChangedAt are written — every
//     previously issued session dies (F-05: reset ⇒ revocation);
//   · USER_ACTIVATED / USER_PASSWORD_RESET_REDEEMED lands in the audit trail.
//
// Security posture:
//   · generic 400 INVALID_TOKEN for unknown/used/expired/inactive/cross-org
//     tokens — NO existence oracle (the mandate's no-enumeration law);
//   · per-IP redeem rate limit (5 / 5 min — defense-in-depth over the
//     256-bit capability; see auth-tokens.ts for the shared-store note);
//   · same-origin enforcement via parseBody (login-CSRF family, P5 F-15);
//   · no session is established: the holder signs in with the new password
//     through the normal login path (no session-fixation surface);
//   · demo password is refused (BOOTSTRAP_DEMO_PASSWORD family — an invite
//     code must not arm the known demo credential).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { DEMO_PASSWORD } from "@/lib/server/auth";
import {
  assertRedeemNotRateLimited,
  isValidRedeemPassword,
  recordRedeemFailure,
  redeemAuthToken,
} from "@/lib/server/auth-tokens";
import { ApiError, clientIp, fail, ok } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

const redeemSchema = z.object({
  token: z.string().trim().min(20, "Jeton invalide").max(200, "Jeton invalide"),
  // Minimal shape only — password POLICY (demo refusal, then the 12-char
  // floor) is checked in the route body in that precedence: the public demo
  // password is 8 chars, so a schema-level min(12) would shadow the demo
  // refusal with a misleading "too short" (A6's activation form maps
  // BOOTSTRAP_DEMO_PASSWORD to a distinct, clearer error state).
  newPassword: z.string().min(1, "Mot de passe requis"),
});

export async function POST(req: NextRequest) {
  try {
    // Defense-in-depth BEFORE any token math (the capability is unguessable;
    // the limiter bounds scripted spraying — FAILURES ONLY are recorded, the
    // login limiter's law: a success never counts against the holder).
    const ip = await clientIp();
    assertRedeemNotRateLimited(ip);
    const body = await parseBody(req, redeemSchema);

    // The demo password is public knowledge (shown in the login overlay) —
    // refusing it here keeps an invite from arming the worst credential.
    // (422 policy rejections do NOT consume the spray budget — only
    // token-class 400 failures do: the budget exists to bound guessing.)
    if (body.newPassword === DEMO_PASSWORD) {
      throw new ApiError(
        422,
        "Choisissez un mot de passe différent (mot de passe de démonstration refusé).",
        "BOOTSTRAP_DEMO_PASSWORD",
      );
    }
    if (!isValidRedeemPassword(body.newPassword)) {
      throw new ApiError(422, "Mot de passe trop court", "BOOTSTRAP_WEAK_PASSWORD");
    }

    let result;
    try {
      result = await redeemAuthToken({
        raw: body.token,
        newPassword: body.newPassword,
      });
    } catch (error) {
      // A failed token redemption (unknown/used/expired/cross-state)
      // consumes the attacker's spray budget — a success never does.
      if (error instanceof ApiError && error.status === 400) recordRedeemFailure(ip);
      throw error;
    }

    // Echo only non-sensitive identity facts (the login form's email hint).
    return ok({
      kind: result.kind,
      email: result.email,
      name: result.name,
    });
  } catch (error) {
    return fail(error);
  }
}
