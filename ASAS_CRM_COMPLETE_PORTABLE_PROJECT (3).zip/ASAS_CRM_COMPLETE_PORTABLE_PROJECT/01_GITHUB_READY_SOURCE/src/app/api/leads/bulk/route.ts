// POST /api/leads/bulk — mass operations on leads (org-scoped updateMany).
// assign requires MANAGER+; status/assign emit one Activity per affected lead
// and a single summarizing AuditLog entry (no audit spam).
// Lifecycle discipline mirrors the single PATCH route: bulk CLOSED_LOST
// requires an explicit reason (P4); the G5-P3-7 adjacency matrix decides
// eligibility (CONVERTED's empty row keeps converted leads locked; illegal
// edges are not eligible); leaving CLOSED_LOST clears the lost fields.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { LEAD_STATUSES, atLeastRole, canTransitionLead } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { reassignLeadCascade } from "@/lib/server/leads";
import { injectTxFault } from "@/lib/server/faults";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope } from "@/lib/server/visibility";
import { optionalId, parseBody } from "@/lib/server/validation";

const schema = z.object({
  ids: z.array(z.string().min(1)).min(1, "ids requis").max(200),
  action: z.enum(["assign", "status", "addTag", "archive"]),
  value: optionalId,
  reason: z.string().trim().min(1).max(500).optional(), // required when status=CLOSED_LOST
});

export async function POST(req: NextRequest) {
  try {
    // API-10 (401 precedence): authenticate BEFORE parsing — the body used to
    // be parsed first, so an anonymous caller got the payload's 422 (or the
    // same-origin 403) instead of 401 NO_SESSION. Auth is the outermost
    // gate; payload shape errors only concern callers who are already in.
    const user = await requireUser();
    const orgId = user.orgId;
    const body = await parseBody(req, schema);

    // Role gate (post-parse): assignment (re-attribution) is a management
    // decision — the atLeastRole gate style of opportunities/[id] F-11 /
    // leads/[id] F-05 (bulk already imports atLeastRole for the archive
    // branch; a second requireUser round-trip would re-read the session for
    // nothing). Other actions stay open to any authenticated in-scope user.
    if (body.action === "assign" && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(
        403,
        "L'attribution groupée de prospects est une décision managériale",
        "FORBIDDEN_ROLE"
      );
    }

    // D-021 — target rows resolve inside the caller's visibility scope:
    // foreign ids in `ids` simply never match (updateMany operates only on
    // the in-scope subset — no cross-agent bulk manipulation).
    const leads = await db.lead.findMany({
      where: { id: { in: body.ids }, orgId, ...leadScope(user) },
      select: { id: true, fullName: true, status: true, ownerId: true, archived: true },
    });
    if (leads.length === 0) return ok({ updated: 0 });

    // ── pre-transaction validations (422s before any write touches the DB) ──
    let owner: { id: string; name: string } | null = null;
    if (body.action === "assign") {
      if (!body.value) throw new ApiError(422, "value (userId) requis pour l'action assign", "VALUE_REQUIRED");
      const target = await db.user.findFirst({ where: { id: body.value, orgId }, select: { id: true, name: true } });
      if (!target) throw new ApiError(422, "Utilisateur cible introuvable", "OWNER_NOT_FOUND");
      owner = target;
    }
    if (body.action === "status") {
      if (!body.value) throw new ApiError(422, "value (status) requis pour l'action status", "VALUE_REQUIRED");
      if (!(LEAD_STATUSES as readonly string[]).includes(body.value)) {
        throw new ApiError(422, `Statut invalide: ${body.value}`, "INVALID_STATUS", { allowed: LEAD_STATUSES });
      }
      if (body.value === "CONVERTED") {
        throw new ApiError(422, "La conversion passe par POST /api/leads/:id/convert", "INVALID_TRANSITION");
      }
      // Commercial discipline: bulk closure requires an explicit reason.
      if (body.value === "CLOSED_LOST" && !body.reason?.trim()) {
        throw new ApiError(
          422,
          "Motif de perte (reason) requis pour la clôture groupée",
          "LOST_REASON_REQUIRED"
        );
      }
    }
    let tag: { id: string } | null = null;
    if (body.action === "addTag") {
      if (!body.value) throw new ApiError(422, "value (tagId) requis pour l'action addTag", "VALUE_REQUIRED");
      const found = await db.tag.findFirst({ where: { id: body.value, orgId }, select: { id: true } });
      if (!found) throw new ApiError(422, "Tag introuvable", "TAG_NOT_FOUND");
      tag = found;
    }

    const now = new Date();
    let updated = 0;
    let auditValue: string | null = null;
    // (ENG-05 cleanup — the former `bulkCascade` accumulator was write-only
    // dead state: assigned from reassignLeadCascade but never surfaced in
    // the audit summary or the response. The cascade itself still runs.)

    // G5-P3-5 (F-06): every mutation write of the bulk action — the
    // updateMany/createMany, the per-lead Activity rows, and the summary
    // AuditLog — commit as ONE transaction (§41 FR41r/s: a forced failure
    // leaves no partially-updated subset and no orphaned activity rows;
    // previously N leads could flip with zero timeline entries). Timeout is
    // generous: 200 leads × activity rows ride the same transaction.
    await db.$transaction(
      async (tx) => {
        if (body.action === "assign") {
          const affected = leads.filter((l) => l.ownerId !== owner!.id);
          const res = await tx.lead.updateMany({
            where: { id: { in: affected.map((l) => l.id) }, orgId },
            data: { ownerId: owner!.id },
          });
          updated = res.count;
          auditValue = owner!.id;
          injectTxFault(req, "leads-bulk");
          // W3-1 (Phase 2.1 — A4#1): the bulk assign now cascades the
          // workload exactly like the single PATCH — one shared law, the
          // reassignLeadCascade helper (open opps + open tasks + future
          // visits follow the client; terminal/DONE stay with history).
          await reassignLeadCascade(tx, orgId, affected.map((l) => l.id), owner!.id);

          for (const lead of affected) {
            await logActivity({
              orgId,
              actorId: user.id,
              leadId: lead.id,
              type: "ASSIGNMENT",
              title: `Lead assigné à ${owner!.name} (action groupée)`,
              meta: { before: lead.ownerId, after: owner!.id, bulk: true },
            }, tx);
          }
        } else if (body.action === "status" && body.value) {
          // (`body.value` re-narrowed inline — the pre-tx VALUE_REQUIRED throw
          // guarantees a status action never reaches here without it)
          // G5-P3-7 (D-GOV-5 §9.1) — the bulk action obeys the LEAD_TRANSITIONS
          // adjacency matrix: only leads whose current → target edge is legal
          // are affected (CONVERTED's empty row subsumes the old terminal
          // exclusion; PATCH entry into CONVERTED is impossible by matrix —
          // the dedicated /convert flow owns it). Illegal-edge rows are simply
          // not eligible — the surgical, no-partial-subset law: legal rows
          // proceed, the summary audit names the exact affected count.
          // (const capture — property narrowing does not flow into the filter
          // closures below; the branch condition already proved it a string)
          const targetStatus = body.value;
          const eligible = leads.filter((l) => canTransitionLead(l.status, targetStatus));
          const affected = eligible.filter((l) => l.status !== targetStatus);
          const data: Record<string, unknown> = { status: targetStatus };
          if (targetStatus === "CLOSED_LOST") {
            data.lostReason = body.reason;
            data.lostAt = now;
          } else {
            // Leaving CLOSED_LOST (whatever the destination): clear the stale lost
            // fields. Rows that were never lost already carry null — no-op for them.
            data.lostReason = null;
            data.lostAt = null;
          }
          if (body.value === "REACTIVATED") {
            data.reactivatedAt = now;
          }
          const res = await tx.lead.updateMany({
            where: { id: { in: affected.map((l) => l.id) }, orgId },
            data,
          });
          updated = res.count;
          auditValue = body.value ?? null;
          injectTxFault(req, "leads-bulk");

          for (const lead of affected) {
            await logActivity({
              orgId,
              actorId: user.id,
              leadId: lead.id,
              type: "STATUS_CHANGE",
              title: `Statut changé : ${lead.status} → ${body.value} (action groupée)`,
              meta: { before: lead.status, after: body.value, bulk: true },
            }, tx);
          }
        } else if (body.action === "addTag") {
          // skipDuplicates is unsupported on SQLite → pre-filter existing links
          // (inside the transaction: the dedup read and the createMany cannot
          // interleave with a concurrent addTag).
          const existing = await tx.leadTag.findMany({
            where: { tagId: tag!.id, leadId: { in: leads.map((l) => l.id) } },
            select: { leadId: true },
          });
          const existingSet = new Set(existing.map((e) => e.leadId));
          const missing = leads.filter((l) => !existingSet.has(l.id));
          if (missing.length > 0) {
            await tx.leadTag.createMany({
              data: missing.map((l) => ({ leadId: l.id, tagId: tag!.id })),
            });
          }
          updated = missing.length;
          auditValue = tag!.id;
          injectTxFault(req, "leads-bulk");
        } else {
          // archive — 2c (G2 audit): the owner|MANAGER inner gate its single
          // PATCH sibling enforces (leads/[id]:248 — “Seul le propriétaire du
          // prospect ou un manager peut l'archiver”) used to be MISSING here:
          // any in-scope SALES_AGENT could bulk-archive pool/own leads en
          // masse. Rows the caller may not archive are SKIPPED-WITH-COUNT —
          // the partial-result law the status action already follows (legal
          // rows proceed; the summary audit names the affected count vs the
          // requested count).
          const mayArchive = (l: { ownerId: string | null }) =>
            l.ownerId === user.id || atLeastRole(user.role, "MANAGER");
          const affected = leads.filter((l) => !l.archived && mayArchive(l));
          const res = await tx.lead.updateMany({
            where: { id: { in: affected.map((l) => l.id) }, orgId },
            data: { archived: true },
          });
          updated = res.count;
          injectTxFault(req, "leads-bulk");
        }

        await logAudit({
          orgId,
          actor: user,
          action: `LEAD_BULK_${body.action.toUpperCase()}`,
          entity: "LEAD",
          after: {
            action: body.action,
            value: auditValue,
            reason: body.action === "status" && body.value === "CLOSED_LOST" ? body.reason : undefined,
            count: updated,
            requested: body.ids.length,
          },
        }, tx);
      },
      { timeout: 15_000 },
    );

    return ok({ updated });
  } catch (error) {
    return fail(error);
  }
}
