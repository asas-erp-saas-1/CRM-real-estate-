// GET  /api/leads   — server-side filtering, sorting, pagination (contract v1).
// POST /api/leads   — create with phone normalization + duplicate detection
//                     (same org + normalized phone OR email) before insert.
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { z } from "zod";
import type { Prisma } from "@prisma/client";
import { atLeastRole, CONTACT_PREFERENCES, LEAD_STATUSES, OPP_CLOSED_STAGES, PRIORITIES, READINESS_LEVELS, SOURCES, UNIT_TYPES, ACTIVE_VISIT_STATUSES } from "@/lib/constants";
import { db } from "@/lib/db";
import { normalizePhone } from "@/lib/phone";
import { normalizeArabicQuery } from "@/lib/arabic";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { leadInclude, refreshLeadScore, toLeadDTO } from "@/lib/server/leads";
import { autoAssignNewLead } from "@/lib/server/routing";
import { serializeScoreBreakdown } from "@/lib/server/scoring";
import { ApiError, fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { leadScope, seesAllRecords } from "@/lib/server/visibility";
import { isPrismaKnownError, optionalEmail, optionalId, optionalMoney, parseBody, qp, qpDate, qpEnum, qpNumber } from "@/lib/server/validation";

const SORT_FIELDS = ["createdAt", "updatedAt", "nextFollowUpAt", "score", "fullName", "lastContactAt", "convertedAt"] as const;
const SORT_DIRS = ["asc", "desc"] as const;

/** P3 (unified Prospects page) — the "idle" law inherited from the customer
 *  book: a relationship with no contact for more than 14 days is cooling.
 *  Never-contacted (lastContactAt null) is NOT idle — it has its own facet. */
const IDLE_DAYS = 14;

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const params = req.nextUrl.searchParams;

    const page = parseIntParam(params.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(params.get("pageSize"), 25, { min: 1, max: 100 });

    // D-021 — record visibility: below MANAGER, the list is OWN+POOL scoped.
    const conditions: Prisma.LeadWhereInput[] = [{ orgId, ...leadScope(user) }];

    const query = qp(req, "query");
    if (query) {
      // R14 — Arabic-alias matching: the folded query reaches the stored
      // folded Arabic names (the list view's own search box behaves exactly
      // like the global palette — one search law across surfaces).
      const queryAr = normalizeArabicQuery(query);
      conditions.push({
        OR: [
          { fullName: { contains: query } },
          { phone: { contains: query } },
          { phoneRaw: { contains: query } },
          { email: { contains: query } },
          { fullNameAr: { contains: query } },
          ...(queryAr !== query ? [{ fullNameAr: { contains: queryAr } }] : []),
        ],
      });
    }

    // P3 — MULTI-STATUS: the list UI has always sent the comma-joined
    // vocabulary of its status checkboxes (`status=NEW,CONTACTED`), which the
    // single-value qpEnum silently… loudly rejected with 422 the moment more
    // than one chip was armed (live-reproduced: two status chips → red error
    // state on the page). The contract now accepts the comma vocabulary:
    // every member validated against LEAD_STATUSES (garbage → 422
    // INVALID_FILTER — the validation law, never a silent ignore), single
    // values behave exactly as before (contract v1 unchanged for them).
    const statusParam = params.get("status");
    if (statusParam) {
      const requested = statusParam.split(",").map((s) => s.trim()).filter(Boolean);
      const invalid = requested.filter((s) => !(LEAD_STATUSES as readonly string[]).includes(s));
      if (invalid.length > 0) {
        throw new ApiError(422, `Statut invalide : ${invalid.join(", ")}`, "INVALID_FILTER");
      }
      if (requested.length === 1) conditions.push({ status: requested[0] });
      else if (requested.length > 1) conditions.push({ status: { in: requested } });
    }

    const source = qpEnum(req, "source", SOURCES);
    if (source) conditions.push({ source });

    const ownerId = qp(req, "ownerId");
    if (ownerId) conditions.push({ ownerId });

    const priority = qpEnum(req, "priority", PRIORITIES);
    if (priority) conditions.push({ priority });

    const tagId = qp(req, "tagId");
    if (tagId) conditions.push({ tags: { some: { tagId } } });

    const minBudget = qpNumber(req, "minBudget");
    if (minBudget !== null) {
      // The lead's budget range must intersect [minBudget, ∞)
      conditions.push({ OR: [{ budgetMax: { gte: minBudget } }, { budgetMin: { gte: minBudget } }] });
    }
    const maxBudget = qpNumber(req, "maxBudget");
    if (maxBudget !== null) {
      // The lead's budget range must intersect (-∞, maxBudget]
      conditions.push({ OR: [{ budgetMax: { lte: maxBudget } }, { budgetMin: { lte: maxBudget } }] });
    }

    const location = qp(req, "location");
    if (location) {
      conditions.push({
        OR: [{ desiredLocation: { contains: location } }, { requirements: { some: { district: { contains: location } } } }],
      });
    }

    // Phase C Wave 3A — the dashboard's headline attention KPI (uncontacted
    // leads, `lastContactAt: null`) finally reproducible through the list
    // contract: `uncontacted=1` isolates exactly the never-contacted set INSIDE
    // the caller's D-021 scope (AND-composed with every other facet — a facet
    // composes, never replaces). Additive optional param: callers that omit it
    // behave exactly as before (contract v1 unchanged for them).
    if (params.get("uncontacted") === "1" || params.get("uncontacted") === "true") {
      conditions.push({ lastContactAt: null });
    }

    // P2.2 (Task 2-a, Agent 2-b's flagged gap) — the INTAKE POOL facet: the
    // distribution worklist's missing predicate. `unassigned=1` isolates the
    // unassigned pool (`ownerId: null`) inside the caller's scope — the same
    // set the notifications route's LEADS_UNASSIGNED group counts (NEW +
    // ownerId null + active) minus the status narrowing (this facet is the
    // raw pool: every active unassigned lead, status-agnostic, so it composes
    // with the existing status facet for the exact NEW-intake). MANAGER+ only
    // (403 FORBIDDEN_ROLE below): below MANAGER the list is OWN+POOL already —
    // the pool is half of an agent's world, not a filter on it.
    if (params.get("unassigned") === "1" || params.get("unassigned") === "true") {
      const caller = await requireUser();
      if (!seesAllRecords(caller)) {
        throw new ApiError(
          403,
          "Le filtre « non assignés » est réservé à la direction",
          "FORBIDDEN_ROLE",
        );
      }
      conditions.push({ ownerId: null });
    }

    // P3 (unified Prospects page) — the IDLE facet ported from the customer
    // book: `idle=1` isolates relationships whose last contact is older than
    // 14 days (lastContactAt strictly before the cutoff). Never-contacted
    // leads (lastContactAt null) are NOT idle — they stay the
    // `uncontacted=1` facet's own set. AND-composed with every other facet.
    if (params.get("idle") === "1" || params.get("idle") === "true") {
      conditions.push({ lastContactAt: { lt: new Date(Date.now() - IDLE_DAYS * 24 * 3600 * 1000) } });
    }

    // Phase C Wave 3A — the created-date window facet (the newLeads KPI's
    // reproduction path: the dashboard echoes `rangeStart`, the deep-link
    // passes it here). `createdAfter=<ISO date>` → createdAt >= date.
    // qpDate validates (garbage → 422 INVALID_DATE, the existing validation
    // law — never a silent ignore, never a raw predicate).
    const createdAfter = qpDate(req, "createdAfter");
    if (createdAfter) {
      conditions.push({ createdAt: { gte: createdAfter } });
    }

    const propertyType = qpEnum(req, "propertyType", UNIT_TYPES);
    if (propertyType) conditions.push({ propertyType });

    // archived=false by default; `archived=true` shows only archived; `archived=all` disables the filter.
    const archivedParam = params.get("archived");
    if (archivedParam === "true" || archivedParam === "1") conditions.push({ archived: true });
    else if (archivedParam !== "all") conditions.push({ archived: false });

    const where: Prisma.LeadWhereInput = conditions.length > 1 ? { AND: conditions } : conditions[0];

    const sortField = (SORT_FIELDS as readonly string[]).includes(params.get("sort") ?? "")
      ? (params.get("sort") as (typeof SORT_FIELDS)[number])
      : "createdAt";
    const sortDir = (SORT_DIRS as readonly string[]).includes(params.get("dir") ?? "")
      ? (params.get("dir") as (typeof SORT_DIRS)[number])
      : "desc";

    const [total, leads] = await Promise.all([
      db.lead.count({ where }),
      db.lead.findMany({
        where,
        orderBy: { [sortField]: sortDir } as Prisma.LeadOrderByWithRelationInput,
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: leadInclude,
      }),
    ]);

    // P3 — `withStats=1`: the per-row relationship enrichment the unified
    // Prospects page triages by (commercial weight + the TRUE next action:
    // the earliest of next follow-up / open-deal next action / next active
    // visit — the customer book's unified chip, now on every prospect row).
    // Opt-in and page-bounded: two batched queries over the page's lead ids
    // (≤ pageSize ≤ 100 — the duplicates scanner's own batching pattern),
    // zero N+1, zero cost for callers that don't ask (export, palette…).
    let stats: Map<string, {
      openOpps: number;
      liveValue: number;
      wonValue: number;
      nextActionAt: string | null;
      nextActionKind: "followUp" | "deal" | "visit";
      nextVisitAt: string | null;
      idle: boolean;
    }> | null = null;
    if (params.get("withStats") === "1" || params.get("withStats") === "true") {
      const ids = leads.map((l) => l.id);
      const idleCutoff = Date.now() - IDLE_DAYS * 24 * 3600 * 1000;
      const [opps, visits] = ids.length
        ? await Promise.all([
            db.opportunity.findMany({
              where: { orgId, leadId: { in: ids } },
              select: { leadId: true, stage: true, value: true, nextActionAt: true },
            }),
            db.visit.findMany({
              where: { orgId, leadId: { in: ids }, status: { in: [...ACTIVE_VISIT_STATUSES] } },
              select: { leadId: true, scheduledAt: true },
              orderBy: { scheduledAt: "asc" },
            }),
          ])
        : [[], []];
      const oppsByLead = new Map<string, typeof opps>();
      for (const o of opps) {
        const list = oppsByLead.get(o.leadId) ?? [];
        list.push(o);
        oppsByLead.set(o.leadId, list);
      }
      const nextVisitByLead = new Map<string, Date>();
      for (const v of visits) {
        const prev = nextVisitByLead.get(v.leadId);
        if (!prev || v.scheduledAt < prev) nextVisitByLead.set(v.leadId, v.scheduledAt);
      }
      stats = new Map(
        leads.map((l) => {
          const leadOpps = oppsByLead.get(l.id) ?? [];
          const open = leadOpps.filter((o) => !(OPP_CLOSED_STAGES as readonly string[]).includes(o.stage));
          const liveValue = open.reduce((acc, o) => acc + (o.value ?? 0), 0);
          const wonValue = leadOpps
            .filter((o) => o.stage === "CLOSED_WON")
            .reduce((acc, o) => acc + (o.value ?? 0), 0);
          const oppNext = open
            .map((o) => o.nextActionAt)
            .filter((d): d is Date => d != null)
            .sort((a, b) => a.getTime() - b.getTime())[0] ?? null;
          const nextVisit = nextVisitByLead.get(l.id) ?? null;
          // The unified next action = earliest of the three sources.
          const candidates: ["followUp" | "deal" | "visit", Date | null][] = [
            ["followUp", l.nextFollowUpAt ?? null],
            ["deal", oppNext],
            ["visit", nextVisit],
          ];
          let bestKind: "followUp" | "deal" | "visit" = "followUp";
          let bestAt: Date | null = null;
          for (const [kind, at] of candidates) {
            if (at != null && (bestAt == null || at < bestAt)) {
              bestAt = at;
              bestKind = kind;
            }
          }
          return [
            l.id,
            {
              openOpps: open.length,
              liveValue,
              wonValue,
              nextActionAt: bestAt ? bestAt.toISOString() : null,
              nextActionKind: bestAt ? bestKind : "followUp",
              nextVisitAt: nextVisit ? nextVisit.toISOString() : null,
              idle: l.lastContactAt != null && l.lastContactAt.getTime() < idleCutoff,
            },
          ] as const;
        }),
      );
    }

    return ok({
      data: leads.map((l) => {
        const dto = toLeadDTO(l);
        return stats ? { ...dto, stats: stats.get(l.id)! } : dto;
      }),
      total,
      page,
      pageSize,
    });
  } catch (error) {
    return fail(error);
  }
}

// ── POST ──────────────────────────────────────────────────────────────────────

const createSchema = z.object({
  fullName: z.string().trim().min(1, "Nom complet requis").max(160),
  phone: z.string().trim().min(1, "Téléphone requis").max(40),
  email: optionalEmail,
  source: z.enum(SOURCES),
  campaign: z.string().trim().max(120).nullable().optional(),
  // ── Phase 11 (A1/A4) — structured attribution + intake preference. The
  // campaign CODE resolves to campaignId server-side (exact match, 422 if
  // unknown — the employee picked it from a picker, unlike the public
  // surface where unknown is preserved silently).
  campaignCode: z.string().trim().min(2).max(60).optional(),
  utmSource: z.string().trim().max(120).nullable().optional(),
  utmMedium: z.string().trim().max(120).nullable().optional(),
  utmCampaign: z.string().trim().max(120).nullable().optional(),
  utmContent: z.string().trim().max(120).nullable().optional(),
  utmTerm: z.string().trim().max(120).nullable().optional(),
  preferredContact: z.enum(CONTACT_PREFERENCES).nullable().optional(),
  decisionReadiness: z.enum(READINESS_LEVELS).nullable().optional(),
  mainObjections: z.string().trim().max(500).nullable().optional(),
  priority: z.enum(PRIORITIES).default("NORMAL"),
  ownerId: optionalId,
  // LM (D-LD-04) — budgets are money: the non-negative domain law (W1-2
  // A4#3) applies to the lead's DZD range too, not just reservations.
  budgetMin: optionalMoney,
  budgetMax: optionalMoney,
  propertyType: z.enum(UNIT_TYPES).nullable().optional(),
  desiredLocation: z.string().trim().max(120).nullable().optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
  whatsapp: z.string().trim().max(40).nullable().optional(),
  secondaryPhone: z.string().trim().max(40).nullable().optional(),
  force: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const body = await parseBody(req, createSchema);

    // Phone discipline (master prompt §10): canonical E.164 before insert.
    const phone = normalizePhone(body.phone);
    if (!phone) {
      throw new ApiError(422, "Numéro de téléphone invalide (formats DZ ou international)", "INVALID_PHONE", {
        field: "phone",
        value: body.phone,
      });
    }

    const secondaryPhone = body.secondaryPhone ? (normalizePhone(body.secondaryPhone) ?? body.secondaryPhone) : null;
    const whatsapp = body.whatsapp ? (normalizePhone(body.whatsapp) ?? phone) : phone;

    if (body.budgetMin != null && body.budgetMax != null && body.budgetMin > body.budgetMax) {
      throw new ApiError(422, "budgetMin doit être ≤ budgetMax", "BUDGET_RANGE_INVALID");
    }

    // Ownership validation (same org only).
    // W1-7 (Phase 2.1 — A3#6): create-time assignment joins the D-GOV-5 law —
    // "assignment is managerial" was enforced on PATCH/bulk but not on POST,
    // leaving a UI-hidden/server-permissive gap. Below MANAGER the lead is
    // created unassigned (the pool) exactly like the UI already does.
    let ownerId: string | null = null;
    if (body.ownerId) {
      if (!atLeastRole(user.role, "MANAGER")) {
        throw new ApiError(403, "L'affectation d'un prospect est une décision managériale", "FORBIDDEN_ROLE");
      }
      const owner = await db.user.findFirst({ where: { id: body.ownerId, orgId }, select: { id: true } });
      if (!owner) throw new ApiError(422, "Propriétaire (ownerId) introuvable dans l'organisation", "OWNER_NOT_FOUND");
      ownerId = owner.id;
    }

    // Duplicate detection BEFORE insert — same org + phone, or same org + email
    // (case-insensitive: SQLite LIKE is ASCII case-insensitive).
    // D-021: duplicates are resolved INSIDE the caller's visibility scope — a
    // foreign duplicate yields a generic existence-only 409 (empty list: no
    // name/owner leak through the dedupe surface, mandate §15).
    if (!body.force) {
      const dupConditions: Prisma.LeadWhereInput[] = [{ orgId, phone }];
      // LM (D-LD-03) — EXACT email equality, not `contains`: the substring
      // probe false-positived on suffixes ("h@asas.dz" matched the stored
      // "sarah@asas.dz") and produced spurious 409s that blocked legitimate
      // creates. A duplicate email is the SAME address, byte-for-byte.
      if (body.email) dupConditions.push({ orgId, email: body.email });
      const dupWhere: Prisma.LeadWhereInput = { OR: dupConditions };
      const scope = leadScope(user);
      const duplicates = await db.lead.findMany({
        where: scope ? { AND: [dupWhere, scope] } : dupWhere,
        take: 10,
        include: leadInclude,
      });
      if (duplicates.length > 0) {
        return NextResponse.json(
          {
            error: "Lead déjà existant (téléphone ou email en doublon)",
            code: "DUPLICATE",
            duplicates: duplicates.map(toLeadDTO),
          },
          { status: 409 }
        );
      }
      if (scope) {
        // A duplicate exists but is owned by another member — report it
        // WITHOUT identifying details. The [orgId, phone] unique index keeps
        // data integrity: the insert below can never create a phone twin.
        const foreignCount = await db.lead.count({ where: dupWhere });
        if (foreignCount > 0) {
          return NextResponse.json(
            {
              error: "Un prospect avec ces coordonnées existe déjà — rapprochez-vous d'un responsable.",
              code: "DUPLICATE",
              duplicates: [],
            },
            { status: 409 }
          );
        }
      }
    }

    let lead;
    try {
      // G5-P3-5 (F-06, D-GOV-5): the creation and its Activity/Audit trail
      // commit as ONE transaction — a crash between them can no longer leave
      // a lead without its timeline entry (or an orphaned audit row). The
      // P2002 catch below still answers the contract-shaped 409: the unique
      // violation aborts the whole transaction, so nothing else was written.
      //
      // W2-A2 (P1): the lead's INITIAL score is computed in the SAME
      // transaction — the cache is born fresh (a brand-new lead scores low,
      // and that is the honest number), through the single writer
      // (refreshLeadScore → scoring.ts). No client-supplied score exists on
      // the create contract — the score is NEVER a free input field.
      lead = await db.$transaction(async (tx) => {
        // Phase 11 (A1) — resolve the closed attribution key. The employee
        // picked the code from a campaign picker: an unknown code is a
        // honest 422 (never a silently invented attribution).
        let campaignId: string | null = null;
        if (body.campaignCode) {
          const campaignRow = await tx.campaign.findUnique({
            where: { orgId_code: { orgId, code: body.campaignCode } },
            select: { id: true },
          });
          if (!campaignRow) {
            throw new ApiError(422, "Code campagne inconnu", "CAMPAIGN_CODE_UNKNOWN");
          }
          campaignId = campaignRow.id;
        }
        const row = await tx.lead.create({
          data: {
            orgId,
            fullName: body.fullName,
            phone,
            phoneRaw: body.phone,
            secondaryPhone,
            whatsapp,
            email: body.email ?? null,
            source: body.source,
            campaign: body.campaign ?? null,
            campaignId,
            utmSource: body.utmSource ?? null,
            utmMedium: body.utmMedium ?? null,
            utmCampaign: body.utmCampaign ?? null,
            utmContent: body.utmContent ?? null,
            utmTerm: body.utmTerm ?? null,
            preferredContact: body.preferredContact ?? null,
            decisionReadiness: body.decisionReadiness ?? null,
            mainObjections: body.mainObjections ?? null,
            priority: body.priority,
            ownerId,
            budgetMin: body.budgetMin ?? null,
            budgetMax: body.budgetMax ?? null,
            propertyType: body.propertyType ?? null,
            desiredLocation: body.desiredLocation ?? null,
            notes: body.notes ?? null,
          },
          include: leadInclude,
        });
        injectTxFault(req, "leads-post");

        const score = await refreshLeadScore(tx, orgId, row.id);
        if (score) {
          // Fold the just-written cache into the response row (same tx
          // values — no re-read needed).
          row.score = score.score;
          row.scoreComputedAt = new Date();
          row.scoreBreakdown = serializeScoreBreakdown(score.breakdown);
        }

        await logActivity({
          orgId,
          actorId: user.id,
          leadId: row.id,
          type: "LEAD_CREATED",
          title: `Lead créé — ${row.fullName}`,
          meta: { source: row.source, phone: row.phone },
        }, tx);
        await logAudit({
          orgId,
          actor: user,
          action: "LEAD_CREATED",
          entity: "LEAD",
          entityId: row.id,
          after: { fullName: row.fullName, phone: row.phone, source: row.source, ownerId: row.ownerId },
        }, tx);
        // Phase 11 (A3) — when no owner was chosen, the org routing policy
        // may auto-assign (MANUAL default = the historical behavior). The
        // assignment + its trail commit with the creation (one tx).
        if (!ownerId) {
          await autoAssignNewLead(tx, orgId, row.id, user);
        }
        return row;
      });
    } catch (error) {
      // The @@unique([orgId, phone]) index is the hard backstop: force:true can
      // override an EMAIL duplicate, but never a phone duplicate (phone = one
      // person). Surface it as a contract-shaped 409.
      if (isPrismaKnownError(error, "P2002")) {
        // D-021 — the backstop path is scope-aware too: a foreign phone twin
        // surfaces as a generic duplicate (empty list), a visible one keeps
        // the historical contract-shaped 409.
        const scope = leadScope(user);
        const existing = await db.lead.findMany({
          where: scope ? { AND: [{ orgId, phone }, scope] } : { orgId, phone },
          take: 5,
          include: leadInclude,
        });
        return NextResponse.json(
          {
            error: existing.length
              ? "Un lead avec ce téléphone existe déjà — le téléphone identifie une personne unique et ne peut pas être forcé."
              : "Un prospect avec ce téléphone existe déjà — rapprochez-vous d'un responsable.",
            code: "DUPLICATE",
            duplicates: existing.map(toLeadDTO),
          },
          { status: 409 }
        );
      }
      throw error;
    }

    return ok({ lead: toLeadDTO(lead) }, 201);
  } catch (error) {
    return fail(error);
  }
}
