// POST /api/leads/duplicates/merge — §12.2 (P30, D-038): absorb one lead into
// another, PRESERVING references and history (the directive's own words).
// MANAGER+ (an authorized user — never automated, never silent). The
// direction is explicit: the caller picks the survivor; everything flows
// merged → survivor inside ONE interactive transaction.
//
// LAWS (D-038 — the register's R6 cell semantics verbatim):
//  · Phone (R6: "merge — keep both phones as primary/secondary"): the
//    survivor keeps its primary phone; the merged phone becomes the
//    survivor's secondaryPhone when that slot is empty. When the slot is
//    already taken the merged phone is NOT lost — it rides the merge
//    Activity + the audit payload (archived in the history, never silent).
//  · Fill-if-empty: email / whatsapp / secondaryPhone / budgetMin /
//    budgetMax / propertyType / desiredLocation — never overwrite the
//    survivor's own truth.
//  · Attribution (source/campaign/utm/referrer) is NEVER touched — it is
//    the survivor's own sourcing truth; the merged attribution snapshot is
//    preserved in the merge Activity meta.
//  · Lifecycle (status/priority/score) is NEVER rewritten by a merge —
//    those are separate explicit audited actions. A converted source may
//    thus merge into a non-converted survivor (the inspector warns); the
//    BOTH-converted case is refused (409 MERGE_BOTH_CONVERTED — the two
//    one-to-one client rows cannot be silently resolved; surface, never
//    invent).
//  · References re-point: activities, tasks, visits, opportunities, LEAD
//    documents (entityType/entityId), tags (union), contact &
//    requirement (when the survivor has none). When BOTH leads carry a
//    requirement, the merged one + its match history is preserved VERBATIM
//    in the merge Activity meta then deleted (recoverable, auditable —
//    the unique(leadId) makes coexistence impossible).
//  · lastContactAt = the more recent of the two; nextFollowUpAt = the
//    earliest non-null (a commitment is never lost by a merge).
//  · Concurrency: expectedUpdatedAt on BOTH sides (the P18 stale-guard
//    pattern) → 409 MERGE_STALE naming the drifted side.
//  · The merge Activity (type MERGE) lands on the survivor's timeline with
//    the full preservation payload; the audit row carries before/after.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { bustDuplicateCache } from "@/lib/server/duplicates";
import { leadInclude, toLeadDTO } from "@/lib/server/leads";
import { logAudit } from "@/lib/server/audit";
import { fail, ok, ApiError } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

// P30 live-catch (the first transactional route in the app): the default 5s
// interactive-transaction timeout is NOT enough for the merge's re-pointing
// work on SQLite (5 updateMany + tag union + requirement/contact handling +
// the timeline row + deletes — measured >5s under dev query logging) — the
// transaction expired mid-flight and 500'd. 30s matches the work; atomicity
// is unchanged.
const MERGE_TX_TIMEOUT_MS = 30_000;

const bodySchema = z.object({
  survivorId: z.string().min(1),
  mergedId: z.string().min(1),
  // §26-style stale-guard tokens — the caller must have SEEN both records'
  // current state (z.coerce.date() = the visits PATCH convention).
  survivorExpectedUpdatedAt: z.coerce.date(),
  mergedExpectedUpdatedAt: z.coerce.date(),
  note: z.string().trim().min(3).max(500).optional(),
});

function snapshot(lead: {
  id: string; fullName: string; phone: string; secondaryPhone: string | null; email: string | null;
  whatsapp: string | null; status: string; ownerId: string | null; source: string; campaign: string | null;
  utmSource: string | null; utmMedium: string | null; utmCampaign: string | null; referrerName: string | null;
  budgetMin: number | null; budgetMax: number | null; propertyType: string | null; desiredLocation: string | null;
  notes: string | null; score: number; archived: boolean; createdAt: Date;
}) {
  return {
    id: lead.id, fullName: lead.fullName, phone: lead.phone, secondaryPhone: lead.secondaryPhone,
    email: lead.email, whatsapp: lead.whatsapp, status: lead.status, ownerId: lead.ownerId,
    source: lead.source, campaign: lead.campaign, utmSource: lead.utmSource, utmMedium: lead.utmMedium,
    utmCampaign: lead.utmCampaign, referrerName: lead.referrerName, budgetMin: lead.budgetMin,
    budgetMax: lead.budgetMax, propertyType: lead.propertyType, desiredLocation: lead.desiredLocation,
    notes: lead.notes, score: lead.score, archived: lead.archived, createdAt: lead.createdAt,
  };
}

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("leads.dedupe");
    const orgId = user.orgId;
    const body = await parseBody(req, bodySchema);

    if (body.survivorId === body.mergedId) {
      throw new ApiError(422, "Une fusion nécessite deux fiches distinctes.", "MERGE_SAME_ID");
    }

    // Org-scoped load of both records (the ghost law: a foreign/absent id is
    // a byte-identical 404 — no existence leak).
    const [survivor, merged] = await Promise.all([
      db.lead.findFirst({ where: { id: body.survivorId, orgId }, include: leadInclude }),
      db.lead.findFirst({ where: { id: body.mergedId, orgId }, include: leadInclude }),
    ]);
    if (!survivor || !merged) {
      throw new ApiError(404, "Prospect introuvable.", "LEAD_NOT_FOUND");
    }

    // Stale guards — the caller must have SEEN both records' current state.
    if (body.survivorExpectedUpdatedAt.getTime() !== survivor.updatedAt.getTime()) {
      throw new ApiError(409, "La fiche survivante a changé depuis sa lecture — rechargez puis réessayez.", "MERGE_STALE", { side: "survivor" });
    }
    if (body.mergedExpectedUpdatedAt.getTime() !== merged.updatedAt.getTime()) {
      throw new ApiError(409, "La fiche absorbée a changé depuis sa lecture — rechargez puis réessayez.", "MERGE_STALE", { side: "merged" });
    }

    // The both-converted refusal: two one-to-one client rows (Contact) cannot
    // be silently resolved — §12.2 "do not silently merge".
    const [survivorContact, mergedContact] = await Promise.all([
      db.contact.findFirst({ where: { leadId: survivor.id, orgId } }),
      db.contact.findFirst({ where: { leadId: merged.id, orgId } }),
    ]);
    if (survivorContact && mergedContact) {
      throw new ApiError(
        409,
        "Les deux fiches sont converties (clients distincts) — la fusion des deux fiches client doit être tranchée avant.",
        "MERGE_BOTH_CONVERTED",
      );
    }

    const survivorSnap = snapshot(survivor);
    const mergedSnap = snapshot(merged);

    const result = await db.$transaction(async (tx) => {
      // ── 1. References re-point (history preserved in place) ─────────────
      // W1-1 (Phase 2.1 — A2#1): SavCase.leadId joins the re-point set. The FK
      // is SET NULL — without this, deleting the absorbed lead silently
      // detached after-sales dossiers (postdates the P30 merge design).
      const [activities, tasks, visits, opportunities, documents, savCases] = await Promise.all([
        tx.activity.updateMany({ where: { leadId: merged.id, orgId }, data: { leadId: survivor.id } }),
        tx.task.updateMany({ where: { leadId: merged.id, orgId }, data: { leadId: survivor.id } }),
        tx.visit.updateMany({ where: { leadId: merged.id, orgId }, data: { leadId: survivor.id } }),
        tx.opportunity.updateMany({ where: { leadId: merged.id, orgId }, data: { leadId: survivor.id } }),
        tx.document.updateMany({ where: { entityType: "LEAD", entityId: merged.id, orgId }, data: { entityId: survivor.id } }),
        tx.savCase.updateMany({ where: { leadId: merged.id, orgId }, data: { leadId: survivor.id } }),
      ]);

      // ── 2. Tags — union (composite pk; insert the missing pairs only) ──
      const mergedTags = await tx.leadTag.findMany({ where: { leadId: merged.id }, include: { tag: true } });
      const survivorTagIds = new Set(
        (await tx.leadTag.findMany({ where: { leadId: survivor.id }, select: { tagId: true } })).map((t) => t.tagId),
      );
      let tagsUnited = 0;
      for (const lt of mergedTags) {
        if (!survivorTagIds.has(lt.tagId)) {
          await tx.leadTag.create({ data: { leadId: survivor.id, tagId: lt.tagId } });
          survivorTagIds.add(lt.tagId);
          tagsUnited++;
        }
      }

      // ── 3. Contact — re-point when the survivor has none ───────────────
      let contactRepointed = false;
      if (mergedContact && !survivorContact) {
        await tx.contact.update({ where: { id: mergedContact.id }, data: { leadId: survivor.id } });
        contactRepointed = true;
      }

      // LM (D-LD-02 heal) — the lifecycle follows the artifact: when the
      // absorbed lead's CLIENT record moved onto the survivor, the survivor
      // IS converted from that moment (a lead that owns a Contact row with
      // status ≠ CONVERTED is a lying state). Without this carry, a later
      // /convert on the survivor hit the 1:1 contact→lead unique index as an
      // opaque 500 (P2002) — the exact defect the domain audit flagged. The
      // carry is explicit, transactional, and documented on the merge
      // Activity (never silent — the same law as every lifecycle change).
      let lifecycleCarried = false;
      if (contactRepointed && mergedContact && survivor.status !== "CONVERTED") {
        await tx.lead.update({
          where: { id: survivor.id },
          data: {
            status: "CONVERTED",
            convertedContactId: mergedContact.id,
            convertedAt: merged.convertedAt ?? new Date(),
          },
        });
        lifecycleCarried = true;
      }

      // ── 4. Requirement — re-point or preserve-then-delete ──────────────
      const mergedRequirement = await tx.requirement.findFirst({
        where: { leadId: merged.id, orgId },
        include: { matches: true },
      });
      const survivorRequirement = await tx.requirement.findFirst({ where: { leadId: survivor.id, orgId } });
      let requirementRepointed = false;
      let preservedRequirement: unknown = null;
      if (mergedRequirement && !survivorRequirement) {
        await tx.requirement.update({ where: { id: mergedRequirement.id }, data: { leadId: survivor.id } });
        requirementRepointed = true;
      } else if (mergedRequirement && survivorRequirement) {
        // The unique(leadId) forbids coexistence — preserve VERBATIM in the
        // merge Activity meta (recoverable, auditable), then delete.
        preservedRequirement = {
          requirement: mergedRequirement,
          matches: mergedRequirement.matches,
        };
        await tx.requirement.delete({ where: { id: mergedRequirement.id } }); // cascades matches
      }

      // ── 5. Survivor fields — phone law + fill-if-empty (never overwrite) ─
      const data: {
        secondaryPhone?: string | null;
        email?: string | null;
        whatsapp?: string | null;
        budgetMin?: number | null;
        budgetMax?: number | null;
        propertyType?: string | null;
        desiredLocation?: string | null;
        lastContactAt?: Date | null;
        nextFollowUpAt?: Date | null;
      } = {};
      const filled: string[] = [];

      // R6's own semantics: keep both phones as primary/secondary.
      const phoneToSecondary =
        survivor.secondaryPhone == null && merged.phone !== survivor.phone ? merged.phone : null;
      if (phoneToSecondary) {
        data.secondaryPhone = phoneToSecondary;
        filled.push("secondaryPhone");
      }
      if (survivor.email == null && merged.email != null) { data.email = merged.email; filled.push("email"); }
      if (survivor.whatsapp == null && merged.whatsapp != null) { data.whatsapp = merged.whatsapp; filled.push("whatsapp"); }
      if (survivor.budgetMin == null && merged.budgetMin != null) { data.budgetMin = merged.budgetMin; filled.push("budgetMin"); }
      if (survivor.budgetMax == null && merged.budgetMax != null) { data.budgetMax = merged.budgetMax; filled.push("budgetMax"); }
      if (survivor.propertyType == null && merged.propertyType != null) { data.propertyType = merged.propertyType; filled.push("propertyType"); }
      if (survivor.desiredLocation == null && merged.desiredLocation != null) { data.desiredLocation = merged.desiredLocation; filled.push("desiredLocation"); }

      // Operational fields — preserving semantics: the person's real last
      // contact across both records; the earliest pending commitment.
      if (merged.lastContactAt && (!survivor.lastContactAt || merged.lastContactAt > survivor.lastContactAt)) {
        data.lastContactAt = merged.lastContactAt;
      }
      if (merged.nextFollowUpAt && (!survivor.nextFollowUpAt || merged.nextFollowUpAt < survivor.nextFollowUpAt)) {
        data.nextFollowUpAt = merged.nextFollowUpAt;
      }

      const updatedSurvivor = Object.keys(data).length
        ? await tx.lead.update({ where: { id: survivor.id }, data, include: leadInclude })
        : await tx.lead.findUniqueOrThrow({ where: { id: survivor.id }, include: leadInclude });

      // ── 6. The merge Activity on the survivor's timeline (§12 history) ──
      const moved = {
        activities: activities.count,
        tasks: tasks.count,
        visits: visits.count,
        opportunities: opportunities.count,
        documents: documents.count,
        savCases: savCases.count,
        tags: tagsUnited,
      };
      const title = `Fusion — ${merged.fullName} absorbée dans ${survivor.fullName}`;
      const bodyParts: string[] = [];
      if (moved.activities || moved.tasks || moved.visits || moved.opportunities || moved.documents || moved.savCases || moved.tags) {
        bodyParts.push(
          `Re-rattaché : ${moved.activities} activités · ${moved.tasks} tâches · ${moved.visits} visites · ${moved.opportunities} opportunités · ${moved.documents} documents · ${moved.savCases} dossiers SAV · ${moved.tags} étiquettes`,
        );
      }
      if (phoneToSecondary) bodyParts.push(`Téléphone secondaire ← ${merged.phone}`);
      else if (merged.phone !== survivor.phone) bodyParts.push(`Ancien téléphone ${merged.phone} (archivé — voir l'audit)`);
      if (contactRepointed) bodyParts.push("Fiche client re-rattachée");
      // LM (D-LD-02) — the carried lifecycle surfaces in the same timeline
      // entry (the survivor's conversion is a CONSEQUENCE of this merge,
      // not a separate user action).
      if (lifecycleCarried) bodyParts.push("Statut converti hérité de la fiche absorbée");
      if (requirementRepointed) bodyParts.push("Critères de recherche re-rattachés");
      if (merged.notes) bodyParts.push(`Notes de la fiche absorbée : « ${merged.notes} »`);
      if (body.note) bodyParts.push(`Motif : ${body.note}`);

      const activity = await tx.activity.create({
        data: {
          orgId,
          actorId: user.id,
          leadId: survivor.id,
          type: "MERGE",
          title,
          body: bodyParts.join("\n") || null,
          meta: JSON.stringify({
            merged: mergedSnap,
            moved,
            phoneLaw: { survivorPhone: survivor.phone, mergedPhone: merged.phone, movedToSecondary: phoneToSecondary != null },
            filled,
            contactRepointed,
            requirementRepointed,
            preservedRequirement,
            note: body.note ?? null,
          }),
          occurredAt: new Date(),
        },
      });

      // ── 7. Audit (§26) — AFTER COMMIT, from the committed result: the
      // audit row must never outlive the merge (a rolled-back merge with a
      // surviving audit row would describe an event that never happened —
      // the orphan-audit corruption the first live run caught when logAudit
      // escaped the expired transaction). The payload is built from the
      // pre-captured snapshots + the transaction's return value.
      // ── 8. Delete the absorbed record (references already re-pointed) ──
      await tx.leadTag.deleteMany({ where: { leadId: merged.id } });
      await tx.lead.delete({ where: { id: merged.id } });

      return { survivor: updatedSurvivor, moved, activityId: activity.id, contactRepointed, requirementRepointed, preservedRequirement, filled, phoneToSecondary };
    }, { timeout: MERGE_TX_TIMEOUT_MS });

    bustDuplicateCache(orgId); // W5-4: the next bell/dashboard poll reflects the merged pair.

    // Post-commit audit — the merge HAPPENED; this row describes reality.
    await logAudit({
      orgId,
      actor: user,
      action: "LEAD_MERGED",
      entity: "LEAD",
      entityId: survivor.id,
      before: { merged: mergedSnap, survivor: survivorSnap },
      after: {
        survivor: {
          id: result.survivor.id, fullName: result.survivor.fullName, phone: result.survivor.phone,
          secondaryPhone: result.survivor.secondaryPhone, email: result.survivor.email,
          whatsapp: result.survivor.whatsapp, lastContactAt: result.survivor.lastContactAt,
          nextFollowUpAt: result.survivor.nextFollowUpAt,
        },
        mergedDeletedId: merged.id,
        moved: result.moved,
        filled: result.filled,
        phoneLaw: { movedToSecondary: result.phoneToSecondary != null, mergedPhone: merged.phone },
        contactRepointed: result.contactRepointed,
        requirementRepointed: result.requirementRepointed,
        preservedRequirement: result.preservedRequirement,
        note: body.note ?? null,
      },
    });

    return ok({
      lead: toLeadDTO(result.survivor),
      moved: result.moved,
      activityId: result.activityId,
    });
  } catch (error) {
    return fail(error);
  }
}
