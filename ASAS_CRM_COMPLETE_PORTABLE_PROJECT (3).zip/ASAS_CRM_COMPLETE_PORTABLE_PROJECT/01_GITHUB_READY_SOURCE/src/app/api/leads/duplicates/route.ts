// GET /api/leads/duplicates — §12.2 duplicate management (P30, D-038):
// EXPLAINABLE likely-duplicate suggestions, org-wide, MANAGER+ only (an
// org-wide scan below MANAGER would be a D-021 scope-leak vector — agents
// would learn foreign leads exist through the suggestions).
//
// P53 (D-UX-064): the pair DISCOVERY itself now delegates to the ONE shared
// predicate (src/lib/server/duplicates.ts — the scan, the dashboard KPI and
// the bell group ask the same question through the same writer; the
// aggregate can never drift from the machine). The route keeps what is
// genuinely its own: the RBAC gate, the involved-lead enrichment (stats +
// DTOs) and the response shape. The delegation is byte-identical — the same
// rules, the same dismissed/both-archived exclusions, the same strong-first
// ordering (proved by the pre/post scan diff at landing).
//
// Rules (DUPLICATE_RULES — labels leads.dup.rule.*):
//   EMAIL       same non-null email (case-insensitive)          — strong
//   PHONE_CROSS A's phone == B's secondaryPhone or vice versa    — strong
//   NAME        same normalized fullName (trim/lower/collapse)  — WEAK: the
//               directive's own «names resemble» case — surfaced as a
//               suggestion ONLY; no automatic action ever rides on it.
// Pairs where BOTH sides are archived are excluded (out of the active
// funnel — pure noise); a live/archived pair stays visible (the archived
// badge carries the judgment). Dismissed pairs (§12.2 "link/confirm
// distinct", R6's second path) are excluded by construction.
//
// READS NEVER WRITE (the P24 law): no Activity, no Audit row — the scan is a
// pure derived view. Bounded: the export-bundle convention (take ≤ 5000).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { leadInclude, toLeadDTO, type LeadWithRelations } from "@/lib/server/leads";
import { pendingDuplicatePairs } from "@/lib/server/duplicates";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";

interface LeadStats {
  activities: number;
  tasks: number;
  visits: number;
  opportunities: number;
  hasContact: boolean;
  hasRequirement: boolean;
}

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("leads.dedupe");
    const orgId = user.orgId;

    // The shared §12.2 predicate (the ONE writer — see the module header).
    const { pairs: pairsLite, scanned } = await pendingDuplicatePairs(orgId);

    // Relation stats for the involved leads only (inspect payload).
    const involved = new Set<string>();
    for (const p of pairsLite) {
      involved.add(p.leadAId);
      involved.add(p.leadBId);
    }
    const stats = new Map<string, LeadStats>();
    const fullById = new Map<string, LeadWithRelations>();
    if (involved.size > 0) {
      const [actRows, taskRows, visitRows, oppRows, contactRows, reqRows, fullLeads] =
        await Promise.all([
          db.activity.groupBy({ by: ["leadId"], where: { orgId, leadId: { in: [...involved] } }, _count: { _all: true } }),
          db.task.groupBy({ by: ["leadId"], where: { orgId, leadId: { in: [...involved] } }, _count: { _all: true } }),
          db.visit.groupBy({ by: ["leadId"], where: { orgId, leadId: { in: [...involved] } }, _count: { _all: true } }),
          db.opportunity.groupBy({ by: ["leadId"], where: { orgId, leadId: { in: [...involved] } }, _count: { _all: true } }),
          db.contact.findMany({ where: { orgId, leadId: { in: [...involved] } }, select: { leadId: true } }),
          db.requirement.findMany({ where: { orgId, leadId: { in: [...involved] } }, select: { leadId: true } }),
          // The involved leads only — the pair view's own enrichment basis
          // (same org scope, same leadInclude, same DTO path as before the
          // delegation; the light rows carry the pair keys).
          db.lead.findMany({ where: { orgId, id: { in: [...involved] } }, include: leadInclude }),
        ]);
      const countOf = (rows: { leadId: string | null; _count: { _all: number } }[], id: string) =>
        rows.find((r) => r.leadId === id)?._count._all ?? 0;
      for (const id of involved) {
        stats.set(id, {
          activities: countOf(actRows, id),
          tasks: countOf(taskRows, id),
          visits: countOf(visitRows, id),
          opportunities: countOf(oppRows, id),
          hasContact: contactRows.some((c) => c.leadId === id),
          hasRequirement: reqRows.some((r) => r.leadId === id),
        });
      }
      for (const l of fullLeads) fullById.set(l.id, l);
    }

    const pairs = pairsLite
      .map((p) => {
        const a = fullById.get(p.leadAId);
        const b = fullById.get(p.leadBId);
        if (!a || !b) return null;
        return {
          id: p.id,
          reasons: p.rules,
          strong: p.strong,
          a: { ...toLeadDTO(a), stats: stats.get(p.leadAId) },
          b: { ...toLeadDTO(b), stats: stats.get(p.leadBId) },
        };
      })
      .filter((p): p is NonNullable<typeof p> => p !== null);
    // (pendingDuplicatePairs already sorts strong-first then by pair key —
    // the P30 ordering law, unchanged.)

    return ok({
      pairs,
      // The scan basis size (org leads, bounded 5000 — the export-bundle
      // convention) — the same number the pre-P53 full scan reported.
      scanned,
    });
  } catch (error) {
    return fail(error);
  }
}
