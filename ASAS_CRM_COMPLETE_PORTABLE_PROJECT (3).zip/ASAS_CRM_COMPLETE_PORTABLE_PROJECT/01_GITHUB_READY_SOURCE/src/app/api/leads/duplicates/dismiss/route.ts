// POST /api/leads/duplicates/dismiss — §12.2 (P30, D-038): the "link /
// confirm distinct" path (R6's second option). A MANAGER+ explicitly records
// «these two records are NOT the same person» — the scan then excludes the
// pair. Audited (LEAD_DUPLICATE_DISMISSED) with the optional decision note.
// Idempotent: re-dismissing the same pair is a no-op (the unique index on
// the normalized pair + upsert semantics — no error, no duplicate rows).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { fail, ok, ApiError } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";
import { bustDuplicateCache } from "@/lib/server/duplicates";

const bodySchema = z.object({
  leadAId: z.string().min(1),
  leadBId: z.string().min(1),
  note: z.string().trim().min(3).max(500).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("leads.dedupe");
    const orgId = user.orgId;
    const body = await parseBody(req, bodySchema);

    if (body.leadAId === body.leadBId) {
      throw new ApiError(422, "Une paire nécessite deux fiches distinctes.", "PAIR_SAME_ID");
    }

    // Org-scoped existence check of both records (ghost law — byte-identical
    // 404, no existence leak).
    const count = await db.lead.count({ where: { orgId, id: { in: [body.leadAId, body.leadBId] } } });
    if (count !== 2) {
      throw new ApiError(404, "Prospect introuvable.", "LEAD_NOT_FOUND");
    }

    // Unordered-pair normalization (a < b) — the dismissal table's law.
    const [leadAId, leadBId] = body.leadAId < body.leadBId ? [body.leadAId, body.leadBId] : [body.leadBId, body.leadAId];

    const existing = await db.leadDuplicateDismissal.findUnique({
      where: { orgId_leadAId_leadBId: { orgId, leadAId, leadBId } },
    });
    if (existing) {
      return ok({ dismissed: true, already: true });
    }

    const dismissal = await db.leadDuplicateDismissal.create({
      data: { orgId, leadAId, leadBId, dismissedById: user.id, note: body.note ?? null },
    });

    await logAudit({
      orgId,
      actor: user,
      action: "LEAD_DUPLICATE_DISMISSED",
      entity: "LEAD",
      entityId: leadAId,
      before: { pair: [leadAId, leadBId] },
      after: { pair: [leadAId, leadBId], note: body.note ?? null, dismissalId: dismissal.id },
    });

    bustDuplicateCache(orgId); // W5-4: the next bell poll reflects this decision

    return ok({ dismissed: true, already: false });
  } catch (error) {
    return fail(error);
  }
}
