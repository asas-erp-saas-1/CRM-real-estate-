// ASAS — WhatsApp click-to-chat logging (R9-4).
//
// POST /api/leads/:id/whatsapp  { template, message?, lang? }
//
// Fired by the UI right after a wa.me chat is opened for a lead so the
// contact attempt lands on the lead timeline: Activity type WHATSAPP (the
// existing convention — no new constant needed) with the template name as
// title, the exact prefilled message as body, and template/phone/via in
// meta. WHATSAPP is a contact type, so the lead's lastContactAt is
// refreshed. An audit row (WHATSAPP_SENT) records the intent.
//
// P25 (D-033): the enum gains the CONTEXTUAL template "lotAvailable" — the
// apartment demand panel's pitch message ("this lot matches your search").
// It is not part of the drawer popover's person-level vocabulary; it exists
// for surfaces that carry lot context.
//
// RBAC: any authenticated org member — agents message leads (same gate as
// the manual activities POST).

import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { findLead } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

/** Localized activity titles (server-generated copy — the client passes its
 *  UI language so the timeline matches, mirroring the copilot route). */
const TEMPLATE_TITLES: Record<string, Record<string, string>> = {
  fr: {
    followUp: "Relance WhatsApp",
    visitReminder: "Rappel de visite WhatsApp",
    offer: "Offre WhatsApp",
    lotAvailable: "Lot disponible WhatsApp",
    custom: "Message WhatsApp personnalisé",
  },
  en: {
    followUp: "WhatsApp follow-up",
    visitReminder: "WhatsApp visit reminder",
    offer: "WhatsApp offer",
    lotAvailable: "WhatsApp unit-available pitch",
    custom: "Custom WhatsApp message",
  },
  ar: {
    followUp: "متابعة عبر واتساب",
    visitReminder: "تذكير بالزيارة عبر واتساب",
    offer: "عرض عبر واتساب",
    lotAvailable: "وحدة متاحة عبر واتساب",
    custom: "رسالة واتساب مخصصة",
  },
};

const schema = z
  .object({
    template: z.enum(["followUp", "visitReminder", "offer", "lotAvailable", "custom"]),
    message: z.string().trim().max(500).optional(),
    lang: z.enum(["fr", "en", "ar"]).optional(),
  })
  .refine((b) => b.template !== "custom" || Boolean(b.message && b.message.length > 0), {
    message: "Message requis pour un envoi personnalisé",
    path: ["message"],
  });

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, schema);

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    const lang = body.lang ?? "fr";
    const title = (TEMPLATE_TITLES[lang] ?? TEMPLATE_TITLES.fr)[body.template];
    const message = (body.message ?? "").trim() || null;

    // G5-P3-5 (F-06): the contact attempt is ONE business event — activity
    // row + lastContactAt refresh + audit row commit together (a forced
    // failure rolls back all three; §41 FR41n/o — previously a failure
    // between them logged a contact that never refreshed the lead, or an
    // activity with no audit trail).
    const activity = await db.$transaction(async (tx) => {
      const row = await logActivity({
        orgId,
        actorId: user.id,
        leadId: lead.id,
        contactId: lead.convertedContactId,
        type: "WHATSAPP",
        title,
        body: message,
        meta: {
          template: body.template,
          via: "wa.me",
          phone: lead.whatsapp ?? lead.phone,
        },
      }, tx);

      // Contact-type activity — refresh the lead's lastContactAt.
      await tx.lead.update({ where: { id: lead.id }, data: { lastContactAt: new Date() } });

      injectTxFault(req, "whatsapp-post");
      await logAudit({
        orgId,
        actor: user,
        action: "WHATSAPP_SENT",
        entity: "LEAD",
        entityId: lead.id,
        before: null,
        after: { template: body.template, activityId: row.id },
      }, tx);
      return row;
    });

    return ok({ activity }, 201);
  } catch (error) {
    return fail(error);
  }
}
