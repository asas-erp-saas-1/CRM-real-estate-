// GET   /api/leads/:id — full aggregate (per contract v1): lead + owner + tags +
//       activities (desc, take 100) + tasks + visits + opportunities + requirements + contact.
// PATCH /api/leads/:id — partial update with commercial discipline:
//       CLOSED_LOST requires lostReason; leaving CLOSED_LOST clears lostReason/
//       lostAt (any destination — P4); CONVERTED is terminal (lock, dedicated
//       flows only); status/owner changes are logged (Activity + AuditLog).
//       G5-P3-7 (D-GOV-5 §9.1): the LEAD_TRANSITIONS adjacency matrix governs
//       every status change — routine forward edges stay open to in-scope
//       users; illegal edges are 422, overridable ONLY by MANAGER+ with a
//       mandatory correctionReason (audited as LEAD_STATUS_CORRECTED).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { CONTACT_PREFERENCES, LEAD_STATUSES, PRIORITIES, READINESS_LEVELS, UNIT_TYPES, atLeastRole, canTransitionLead } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { findLead, leadInclude, reassignLeadCascade, refreshLeadScore, toLeadDTO } from "@/lib/server/leads";
import { isScoreStale, parseScoreBreakdown, serializeScoreBreakdown } from "@/lib/server/scoring";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope } from "@/lib/server/visibility";
import { optionalMoney, parseBody } from "@/lib/server/validation";
import { isValidPhone, normalizePhone } from "@/lib/phone";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    // D-021 — scoped findFirst: a foreign-owned lead is 404, byte-identical
    // to a nonexistent id (no existence leak).
    const lead = await db.lead.findFirst({
      where: { id, orgId: user.orgId, ...leadScope(user) },
      include: {
        owner: { select: { id: true, name: true, role: true } },
        tags: { include: { tag: true } },
        activities: {
          orderBy: { occurredAt: "desc" },
          take: 100,
          include: { actor: { select: { id: true, name: true } } },
        },
        // 7 (G2 audit) — bounded relations: activities was the only capped
        // relation; tasks/visits/opportunities were UNBOUNDED (a 10k-task
        // lead would serialize the whole table into one response). The
        // drawer renders these as client-side paginated/scrollable tab lists
        // (LeadDetail keeps plain arrays — the caps truncate, the contract
        // shape is unchanged). requirements is a 1:1 row (unique leadId) —
        // bounded by construction, no take needed.
        tasks: {
          orderBy: { dueAt: "asc" },
          take: 200,
          include: {
            owner: { select: { id: true, name: true } },
            // D7-R4A — the drawer's Tâches tab gets the same authoritative
            // opportunity association as the tasks view (one contract).
            opportunity: { select: { id: true, title: true, stage: true } },
          },
        },
        visits: {
          orderBy: { scheduledAt: "desc" },
          take: 200,
          include: {
            agent: { select: { id: true, name: true } },
            project: { select: { id: true, name: true, district: true } },
            apartments: { include: { apartment: { select: { id: true, code: true, unitType: true, status: true } } } },
          },
        },
        opportunities: {
          orderBy: { createdAt: "desc" },
          take: 100,
          include: { owner: { select: { id: true, name: true } }, project: { select: { id: true, name: true } } },
        },
        requirements: true,
        contact: true,
      },
    });
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    // W2-A2 (P1) — lazy score refresh (the expiry-sweeper precedent for
    // writes-on-GET: idempotent, bounded to THIS one row). The aggregate
    // already carries everything the staleness predicate needs (activities'
    // head = latest event, the visits' updatedAt, the lead's own updatedAt)
    // — no extra reads. STALE = never computed (legacy/seed rows) or any
    // relevant event strictly newer than the cache stamp. The LIST stays
    // read-only (25 rows × engine loads would be abuse); the drawer
    // recomputes on open, so every surface converges through the same
    // single writer (refreshLeadScore → scoring.ts).
    let leadScoreBreakdown: ReturnType<typeof parseScoreBreakdown> = parseScoreBreakdown(lead.scoreBreakdown);
    if (isScoreStale(lead, {
      lastActivityAt: lead.activities[0]?.occurredAt ?? null,
      lastVisitUpdatedAt: lead.visits.reduce<Date | null>(
        (acc, v) => (acc == null || v.updatedAt > acc ? v.updatedAt : acc),
        null,
      ),
      leadUpdatedAt: lead.updatedAt,
    })) {
      const refreshed = await refreshLeadScore(db, user.orgId, lead.id);
      if (refreshed) {
        lead.score = refreshed.score;
        lead.scoreComputedAt = new Date();
        lead.scoreBreakdown = serializeScoreBreakdown(refreshed.breakdown);
        leadScoreBreakdown = refreshed.breakdown;
      }
    }

    const {
      owner,
      tags,
      activities,
      tasks,
      visits,
      opportunities,
      requirements,
      contact,
      ...leadFields
    } = lead;

    // Phase D (D-UX-064, the documented contract gap): the per-customer
    // workspace needs the reservation state (the money-path position: ACTIVE
    // hold / closure requested / CONVERTED / CANCELLED / EXPIRED) — previously
    // reachable ONLY by already knowing the apartmentId/opportunityId and
    // querying /api/reservations (the drawer never could). ADDITIVE field on
    // the v1 aggregate: joins through THIS lead's already-authorized
    // opportunities (D-021 scope inherited from the scoped findFirst above —
    // no new read path, no schema change, existing consumers unaffected).
    const oppIds = opportunities.map((o) => o.id);
    const reservations = oppIds.length
      ? await db.reservation.findMany({
          where: { orgId: user.orgId, opportunityId: { in: oppIds } },
          orderBy: { createdAt: "desc" },
          select: {
            id: true,
            status: true,
            expiresAt: true,
            amount: true,
            depositPaid: true,
            createdAt: true,
            opportunityId: true,
            apartment: { select: { id: true, code: true, unitType: true, status: true } },
          },
        })
      : [];

    return ok({
      // W2-A2 — the lead row with the score cache; `scoreBreakdown` rides
      // as the PARSED explanation array (the raw JSON string never crosses
      // the server boundary — the toLeadDTO law).
      lead: { ...leadFields, scoreBreakdown: leadScoreBreakdown },
      owner: owner ?? null,
      tags: tags.map((t) => t.tag),
      activities,
      tasks,
      visits: visits.map((v) => ({ ...v, apartments: v.apartments.map((va) => va.apartment) })),
      opportunities,
      requirements,
      contact: contact ?? null,
      reservations,
    });
  } catch (error) {
    return fail(error);
  }
}

// ── PATCH ─────────────────────────────────────────────────────────────────────

const patchSchema = z.object({
  fullName: z.string().trim().min(1).max(160).optional(),
  // LM (D-LD-05) — PATCH contact fields now validate like the create
  // contract: the email shape is enforced (it used to persist any string),
  // and both phone fields are phone-checked then NORMALIZED so wa.me / tel:
  // deep links and future dedup probes see the canonical E.164 form.
  email: z
    .string()
    .trim()
    .max(200)
    .refine((v) => !v || /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v), "Adresse email invalide")
    .nullable()
    .optional(),
  secondaryPhone: z
    .string()
    .trim()
    .max(40)
    .refine((v) => !v || isValidPhone(v), "Numéro invalide")
    .nullable()
    .optional(),
  whatsapp: z
    .string()
    .trim()
    .max(40)
    .refine((v) => !v || isValidPhone(v), "Numéro invalide")
    .nullable()
    .optional(),
  status: z.enum(LEAD_STATUSES).optional(),
  // G5-P3-7 — the manager correction escape hatch: mandatory + audited when
  // the requested edge is illegal per LEAD_TRANSITIONS. On legal edges the
  // field is ignored (routine work needs no reason — the directive).
  correctionReason: z.string().trim().min(1).max(500).optional(),
  ownerId: z.string().nullable().optional(),
  priority: z.enum(PRIORITIES).optional(),
  // W2-A2 — RETIRED writable field: kept in the schema ONLY so a client that
  // still sends it receives the teaching 422 above (a silent strip would
  // look like success while writing nothing).
  score: z.coerce.number().int().min(0).max(100).optional(),
  lostReason: z.string().trim().min(1).max(500).nullable().optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
  // ── Phase 11 (A4) — the qualification facts (editable while unconverted).
  // Attribution fields (source, campaignId, utm*) stay immutable: never here.
  preferredContact: z.enum(CONTACT_PREFERENCES).nullable().optional(),
  decisionReadiness: z.enum(READINESS_LEVELS).nullable().optional(),
  mainObjections: z.string().trim().max(500).nullable().optional(),
  nextFollowUpAt: z.coerce.date().nullable().optional(),
  // LM (D-LD-04) — the money law reaches the PATCH path (same domain rule
  // as the create contract now enforces).
  budgetMin: optionalMoney,
  budgetMax: optionalMoney,
  propertyType: z.enum(UNIT_TYPES).nullable().optional(),
  desiredLocation: z.string().trim().max(120).nullable().optional(),
  archived: z.boolean().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    // W2-A2 (P1) — the single-writer law: `score` is a COMPUTED cache
    // (scoring.ts), never a free input. The historical manual/AI write path
    // (the copilot's « Appliquer le score », bulk apply) is RETIRED with this
    // teaching 422 — the score refreshes automatically in this very PATCH,
    // and on demand through POST /api/leads/:id/score.
    if (body.score !== undefined) {
      throw new ApiError(
        422,
        "Le score d'un prospect est calculé automatiquement (règles transparentes) — impossible de le saisir manuellement. Le score est recalculé par cette même requête ; un recalcul explicite est disponible via POST /api/leads/:id/score.",
        "SCORE_IS_COMPUTED",
        { field: "score" },
      );
    }

    // D-021 — same visibility predicate on the mutation path.
    const lead = await findLead(orgId, id, leadScope(user)); // G5-P4-2 — the shared helper
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    // CONVERTED is terminal: entered only via POST /convert, never left via
    // free PATCH (re-conversion/unconversion requires a dedicated flow).
    if (body.status === "CONVERTED") {
      throw new ApiError(422, "Le statut CONVERTED s'obtient via POST /api/leads/:id/convert", "INVALID_TRANSITION");
    }
    if (lead.status === "CONVERTED" && body.status !== undefined) {
      throw new ApiError(
        422,
        "Lead converti — le statut ne peut plus être modifié (flux dédiés uniquement)",
        "CONVERTED_LOCKED"
      );
    }

    // Commercial discipline: closing a lead requires a reason.
    const statusChanged = body.status !== undefined && body.status !== lead.status;
    if (statusChanged && body.status === "CLOSED_LOST" && !body.lostReason?.trim()) {
      throw new ApiError(422, "Motif de perte (lostReason) requis pour clôturer un lead", "LOST_REASON_REQUIRED");
    }

    // G5-P3-7 (D-GOV-5 §9.1) — the adjacency guard. The CONVERTED locks above
    // keep their specific codes; every other illegal edge is refused unless a
    // MANAGER+ carries a correctionReason (the escape hatch: explicit,
    // limited, traceable — the audit row names the reason).
    let correction = false;
    // (inline `body.status !== undefined` — narrows the zod optional for the
    // matrix call; `statusChanged` alone does not carry the narrowing)
    if (statusChanged && body.status !== undefined && !canTransitionLead(lead.status, body.status)) {
      if (!atLeastRole(user.role, "MANAGER")) {
        throw new ApiError(
          422,
          `Transition illégale : ${lead.status} → ${body.status}. Seul un manager peut corriger (motif obligatoire).`,
          "LEAD_ILLEGAL_TRANSITION"
        );
      }
      if (!body.correctionReason?.trim()) {
        throw new ApiError(
          422,
          "Motif de correction (correctionReason) requis pour forcer une transition illégale",
          "CORRECTION_REASON_REQUIRED"
        );
      }
      correction = true;
    }

    // Budget coherence after merge with existing values.
    const effectiveMin = body.budgetMin !== undefined ? body.budgetMin : lead.budgetMin;
    const effectiveMax = body.budgetMax !== undefined ? body.budgetMax : lead.budgetMax;
    if (effectiveMin != null && effectiveMax != null && effectiveMin > effectiveMax) {
      throw new ApiError(422, "budgetMin doit être ≤ budgetMax", "BUDGET_RANGE_INVALID");
    }

    // Assignment validation.
    // G5-P3-3 (F-05, D-GOV-5): assignment is a management decision — the single
    // PATCH joins the bulk-assign law (`leads/bulk` is MANAGER-gated for
    // "assign"). Agents keep every routine edit on in-scope leads; only
    // re-attribution is gated. UI companion: the drawer's owner-switch menu is
    // hidden below MANAGER (server gate remains the enforcement).
    let newOwnerName: string | null = null;
    const ownerChanged = body.ownerId !== undefined && body.ownerId !== lead.ownerId;
    if (ownerChanged && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(403, "La réattribution d'un prospect est une décision managériale", "FORBIDDEN_ROLE");
    }
    // G5-P3-3 (F-05): archival joins the sibling deletion gates (tasks/[id]:95,
    // activities/[id]:35, visits/[id]:460) — owner-of-record or MANAGER+.
    const archivedChanged = body.archived !== undefined && body.archived !== lead.archived;
    if (archivedChanged && lead.ownerId !== user.id && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(403, "Seul le propriétaire du prospect ou un manager peut l'archiver ou le désarchiver", "FORBIDDEN_ROLE");
    }
    if (ownerChanged && body.ownerId !== null) {
      const owner = await db.user.findFirst({
        where: { id: body.ownerId, orgId },
        select: { id: true, name: true },
      });
      if (!owner) throw new ApiError(422, "Propriétaire (ownerId) introuvable", "OWNER_NOT_FOUND");
      newOwnerName = owner.name;
    }

    const data: Record<string, unknown> = {};
    if (body.fullName !== undefined) data.fullName = body.fullName;
    if (body.email !== undefined) data.email = body.email;
    // LM (D-LD-05) — store the CANONICAL form of both phone-ish fields when a
    // value survives validation (empty string → null clears the field).
    if (body.secondaryPhone !== undefined)
      data.secondaryPhone = body.secondaryPhone ? normalizePhone(body.secondaryPhone) : null;
    if (body.whatsapp !== undefined)
      data.whatsapp = body.whatsapp ? normalizePhone(body.whatsapp) : null;
    if (body.status !== undefined) data.status = body.status;
    if (body.ownerId !== undefined) data.ownerId = body.ownerId;
    if (body.priority !== undefined) data.priority = body.priority;
    if (body.notes !== undefined) data.notes = body.notes;
    // Phase 11 (A4) — the qualification facts.
    if (body.preferredContact !== undefined) data.preferredContact = body.preferredContact;
    if (body.decisionReadiness !== undefined) data.decisionReadiness = body.decisionReadiness;
    if (body.mainObjections !== undefined) data.mainObjections = body.mainObjections;
    if (body.budgetMin !== undefined) data.budgetMin = body.budgetMin;
    if (body.budgetMax !== undefined) data.budgetMax = body.budgetMax;
    if (body.propertyType !== undefined) data.propertyType = body.propertyType;
    if (body.desiredLocation !== undefined) data.desiredLocation = body.desiredLocation;
    if (body.archived !== undefined) data.archived = body.archived;

    if (body.nextFollowUpAt !== undefined) data.nextFollowUpAt = body.nextFollowUpAt;

    if (statusChanged) {
      if (body.status === "CLOSED_LOST") {
        data.lostReason = body.lostReason ?? lead.lostReason;
        data.lostAt = new Date();
      } else if (lead.status === "CLOSED_LOST") {
        // Leaving CLOSED_LOST (whatever the destination): lost fields are
        // stale business facts and must not survive the transition.
        data.lostReason = null;
        data.lostAt = null;
      }
      if (body.status === "REACTIVATED") {
        data.reactivatedAt = new Date();
      }
    } else if (body.lostReason !== undefined) {
      data.lostReason = body.lostReason;
    }

    // G5-P3-5 (F-06): the mutation and its Activity/Audit trail commit as ONE
    // transaction — a forced failure between them rolls back both (no status
    // change without its timeline entry, no orphaned audit row). The
    // fault-injection hook lets the §41 matrix prove the rollback contract.
    const updated = await db.$transaction(async (tx) => {
      const row = await tx.lead.update({
        where: { id: lead.id },
        data,
        include: leadInclude,
      });
      injectTxFault(req, "leads-patch");

      // W2-A2 (P1) — every lead PATCH recomputes the score cache inside the
      // SAME transaction (the trigger matrix, scoring.ts): the fresh budget /
      // status / follow-up this request just wrote feeds the engine through
      // the same single writer. A mid-tx fault rolls the edit AND the cache
      // back together (F-06). No trail rows — a score is a derivation
      // (provenance = scoreComputedAt + scoreBreakdown).
      const score = await refreshLeadScore(tx, orgId, lead.id);
      if (score) {
        row.score = score.score;
        row.scoreComputedAt = new Date();
        row.scoreBreakdown = serializeScoreBreakdown(score.breakdown);
      }

      if (statusChanged) {
        if (correction) {
          // The manager escape hatch — its own trail shape: the correction is
          // an explicit override, so the reason rides BOTH the timeline entry
          // and the dedicated audit action (never the routine rows).
          await logActivity({
            orgId,
            actorId: user.id,
            leadId: lead.id,
            type: "STATUS_CHANGE",
            title: `Statut corrigé : ${lead.status} → ${row.status}`,
            body: body.correctionReason ?? null,
            meta: { before: lead.status, after: row.status, corrected: true, reason: body.correctionReason },
          }, tx);
          await logAudit({
            orgId,
            actor: user,
            action: "LEAD_STATUS_CORRECTED",
            entity: "LEAD",
            entityId: lead.id,
            before: { status: lead.status },
            after: { status: row.status, correctionReason: body.correctionReason, lostReason: row.lostReason },
          }, tx);
        } else {
          await logActivity({
            orgId,
            actorId: user.id,
            leadId: lead.id,
            type: "STATUS_CHANGE",
            title: `Statut changé : ${lead.status} → ${row.status}`,
            body: (row.lostReason ?? undefined) ?? null,
            meta: { before: lead.status, after: row.status },
          }, tx);
          await logAudit({
            orgId,
            actor: user,
            action: "LEAD_STATUS_CHANGED",
            entity: "LEAD",
            entityId: lead.id,
            before: { status: lead.status },
            after: { status: row.status, lostReason: row.lostReason },
          }, tx);
        }
      }

      if (ownerChanged) {
        // W3-1/W3-2 (Phase 2.1) — the workload follows the client through the
        // ONE shared cascade (single and bulk reassignment used to disagree:
        // open opportunities moved here, nothing moved in bulk; open tasks and
        // future visits were orphaned on the old owner in both). Terminal
        // deals / DONE / CANCELLED stay with history — settled facts, not
        // workload.
        const cascade = await reassignLeadCascade(tx, orgId, [lead.id], row.ownerId!);
        await logActivity({
          orgId,
          actorId: user.id,
          leadId: lead.id,
          type: "ASSIGNMENT",
          title: newOwnerName ? `Lead assigné à ${newOwnerName}` : "Lead désassigné",
          body:
            cascade.opportunities + cascade.tasks + cascade.visits > 0
              ? `${cascade.opportunities} opportunité(s) · ${cascade.tasks} tâche(s) ouverte(s) · ${cascade.visits} visite(s) suivent le client`
              : null,
          meta: { before: lead.ownerId, after: row.ownerId, ...cascade },
        }, tx);
        await logAudit({
          orgId,
          actor: user,
          action: "LEAD_ASSIGNED",
          entity: "LEAD",
          entityId: lead.id,
          before: { ownerId: lead.ownerId },
          after: { ownerId: row.ownerId, ...cascade },
        }, tx);
      }
      return row;
    });

    return ok({ lead: toLeadDTO(updated) });
  } catch (error) {
    return fail(error);
  }
}
