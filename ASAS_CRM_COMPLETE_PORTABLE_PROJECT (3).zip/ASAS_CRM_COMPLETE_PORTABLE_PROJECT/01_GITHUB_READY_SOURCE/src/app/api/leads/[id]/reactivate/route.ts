// POST /api/leads/:id/reactivate — CLOSED_LOST → CONTACTED, clears lost fields,
// stamps reactivatedAt. 409 when already REACTIVATED.
// W2.6 (master audit — DOM-D7): the mutation + Activity + Audit commit as ONE
// db.$transaction (the leads PATCH F-06 house pattern — previously the
// timeline row was written OUTSIDE any transaction, and no audit row existed:
// a crash between the two left a reactivated lead with no trail).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { findLead, leadInclude, toLeadDTO } from "@/lib/server/leads";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope } from "@/lib/server/visibility";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    const lead = await findLead(orgId, id, leadScope(user)); // D-021 scoped (G5-P4-2 — the shared helper)
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");
    if (lead.status === "REACTIVATED") {
      throw new ApiError(409, "Lead déjà réactivé", "ALREADY_REACTIVATED");
    }
    if (lead.status !== "CLOSED_LOST") {
      throw new ApiError(
        409,
        `Seul un lead CLOSED_LOST peut être réactivé (statut actuel : ${lead.status})`,
        "NOT_CLOSED_LOST"
      );
    }

    // W2.6 (master audit — DOM-D7) — the house F-06 pattern: mutation +
    // Activity + AuditLog in ONE db.$transaction (logActivity/logAudit take
    // the tx client), so a failure between them rolls back BOTH — no
    // reactivated lead without its trail, no orphaned timeline/audit rows.
    const updated = await db.$transaction(async (tx) => {
      const row = await tx.lead.update({
        where: { id: lead.id },
        data: {
          status: "CONTACTED",
          lostReason: null,
          lostAt: null,
          reactivatedAt: new Date(),
        },
        include: leadInclude,
      });
      await logActivity({
        orgId,
        actorId: user.id,
        leadId: lead.id,
        type: "STATUS_CHANGE",
        title: `Statut changé : ${lead.status} → CONTACTED`,
        body: "Lead réactivé",
        meta: { before: lead.status, after: "CONTACTED", reactivated: true },
      }, tx);
      await logAudit({
        orgId,
        actor: user,
        action: "LEAD_REACTIVATED",
        entity: "LEAD",
        entityId: lead.id,
        before: { status: lead.status, lostReason: lead.lostReason, lostAt: lead.lostAt },
        after: { status: "CONTACTED", reactivatedAt: row.reactivatedAt },
      }, tx);
      return row;
    });

    return ok({ lead: toLeadDTO(updated) });
  } catch (error) {
    return fail(error);
  }
}
