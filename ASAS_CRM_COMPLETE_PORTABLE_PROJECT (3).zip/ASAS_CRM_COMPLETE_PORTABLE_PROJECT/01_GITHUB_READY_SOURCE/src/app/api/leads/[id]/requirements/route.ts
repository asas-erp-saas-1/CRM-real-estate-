// POST /api/leads/:id/requirements — upsert the single structured Requirement
// for the lead (leadId is unique). No timeline noise: this is criteria data,
// surfaced through the matching endpoints.
// W2-A2 (P1): completing the requirement IS the qualification act — the
// score's biggest input block (qualification/budget/timeframe/preferences,
// 47 of 100 points) changes here, so the cache recomputes in the SAME
// transaction (the trigger matrix, scoring.ts).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { MATCH_HARD_FILTER_KEYS, PAYMENT_METHODS, PURPOSES, TIMEFRAMES, UNIT_TYPES, UNIT_FINISHING, UNIT_VIEWS } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { findLead, refreshLeadScore } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { optionalMoney, optionalNonNegativeInt, optionalNonNegativeNumber, parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  // API-04 (money law): budgets flow through optionalMoney exactly like the
  // lead create/PATCH schemas (W1-2 — non-negative, capped at 10 milliards
  // DZD); the plain optionalNumber accepted negatives/NaN here while the
  // client's MoneyField refused them (server-weaker-than-client — the same
  // gap W1-2 closed on reservations/opportunities).
  budgetMin: optionalMoney,
  budgetMax: optionalMoney,
  propertyType: z.enum(UNIT_TYPES).nullable().optional(),
  // G2 (audit 3a) — measured quantities are non-negative by domain (the
  // optionalMoney law): a negative surface/floor/bedroom bound is noise the
  // server used to persist while the requirement form's client validation
  // refused it. floor 0 = rez-de-chaussée stays a legal value.
  surfaceMin: optionalNonNegativeNumber,
  surfaceMax: optionalNonNegativeNumber,
  district: z.string().trim().max(120).nullable().optional(),
  floorMin: optionalNonNegativeInt,
  floorMax: optionalNonNegativeInt,
  parking: z.boolean().nullable().optional(),
  bedroomsMin: optionalNonNegativeInt,
  payment: z.enum(PAYMENT_METHODS).nullable().optional(),
  purpose: z.enum(PURPOSES).nullable().optional(),
  timeframe: z.enum(TIMEFRAMES).nullable().optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
  // ── Phase 10 (A3) — preference enrichment + the hard/soft distinction ──
  bathroomsMin: optionalNonNegativeInt,
  wantsBalcony: z.boolean().nullable().optional(),
  wantsTerrace: z.boolean().nullable().optional(),
  view: z.enum(UNIT_VIEWS).nullable().optional(),
  finishing: z.enum(UNIT_FINISHING).nullable().optional(),
  /** Must-have dimensions (the elimination filters). Closed vocabulary —
   *  unknown keys are dropped server-side; null clears the set. */
  hardFilters: z
    .array(z.enum(MATCH_HARD_FILTER_KEYS))
    .max(MATCH_HARD_FILTER_KEYS.length)
    .nullable()
    .optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, schema);

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    if (
      body.budgetMin != null &&
      body.budgetMax != null &&
      body.budgetMin > body.budgetMax
    ) {
      throw new ApiError(422, "budgetMin doit être ≤ budgetMax", "BUDGET_RANGE_INVALID");
    }

    // Upsert semantics: undefined = keep existing value, null = clear, value = set.
    const provided: Record<string, unknown> = {};
    if (body.budgetMin !== undefined) provided.budgetMin = body.budgetMin;
    if (body.budgetMax !== undefined) provided.budgetMax = body.budgetMax;
    if (body.propertyType !== undefined) provided.propertyType = body.propertyType;
    if (body.surfaceMin !== undefined) provided.surfaceMin = body.surfaceMin;
    if (body.surfaceMax !== undefined) provided.surfaceMax = body.surfaceMax;
    if (body.district !== undefined) provided.district = body.district;
    if (body.floorMin !== undefined) provided.floorMin = body.floorMin;
    if (body.floorMax !== undefined) provided.floorMax = body.floorMax;
    if (body.parking !== undefined) provided.parking = body.parking;
    if (body.bedroomsMin !== undefined) provided.bedroomsMin = body.bedroomsMin;
    if (body.payment !== undefined) provided.payment = body.payment;
    if (body.purpose !== undefined) provided.purpose = body.purpose;
    if (body.timeframe !== undefined) provided.timeframe = body.timeframe;
    if (body.notes !== undefined) provided.notes = body.notes;
    // Phase 10 (A3) — the preference enrichment rides the same upsert law.
    if (body.bathroomsMin !== undefined) provided.bathroomsMin = body.bathroomsMin;
    if (body.wantsBalcony !== undefined) provided.wantsBalcony = body.wantsBalcony;
    if (body.wantsTerrace !== undefined) provided.wantsTerrace = body.wantsTerrace;
    if (body.view !== undefined) provided.view = body.view;
    if (body.finishing !== undefined) provided.finishing = body.finishing;
    if (body.hardFilters !== undefined) {
      provided.hardFilters = body.hardFilters == null || body.hardFilters.length === 0 ? null : JSON.stringify(body.hardFilters);
    }

    // E2E-FINAL (D11 family — confirmed live) — completing the structured
    // requirement IS the qualification act (the journey engine already
    // derives QUALIFIED from hasRequirement): the lead's status must follow,
    // or every status-filtered surface (list chip, dashboard, filters) keeps
    // saying « Nouveau »/« Contacté » while the journey says « Qualifié ».
    // NEW → QUALIFIED (fast-track) and CONTACTED → QUALIFIED are routine
    // forward edges of LEAD_TRANSITIONS; other statuses are left to their
    // owning flows.
    const advanceStatus =
      lead.status === "NEW" || lead.status === "CONTACTED" ? "QUALIFIED" : null;

    // E2E-FINAL — upsert + status advance commit as ONE transaction, the
    // advance riding the house tx law (activity + audit, or nothing).
    const requirement = await db.$transaction(async (tx) => {
      const row = await tx.requirement.upsert({
        where: { leadId: lead.id },
        update: provided,
        create: {
          orgId,
          leadId: lead.id,
          budgetMin: body.budgetMin ?? null,
          budgetMax: body.budgetMax ?? null,
          propertyType: body.propertyType ?? null,
          surfaceMin: body.surfaceMin ?? null,
          surfaceMax: body.surfaceMax ?? null,
          district: body.district ?? null,
          floorMin: body.floorMin ?? null,
          floorMax: body.floorMax ?? null,
          parking: body.parking ?? null,
          bedroomsMin: body.bedroomsMin ?? null,
          payment: body.payment ?? null,
          purpose: body.purpose ?? null,
          timeframe: body.timeframe ?? null,
          notes: body.notes ?? null,
        },
      });

      if (advanceStatus) {
        await tx.lead.update({ where: { id: lead.id }, data: { status: advanceStatus } });
        await logActivity(
          {
            orgId,
            actorId: user.id,
            leadId: lead.id,
            type: "STATUS_CHANGE",
            title: `Statut changé : ${lead.status} → ${advanceStatus}`,
            body: "Exigence structurée complétée (qualification automatique)",
            meta: { before: lead.status, after: advanceStatus, auto: "requirement-complete" },
          },
          tx
        );
        await logAudit(
          {
            orgId,
            actor: user,
            action: "LEAD_STATUS_CHANGED",
            entity: "LEAD",
            entityId: lead.id,
            before: { status: lead.status },
            after: { status: advanceStatus, auto: "requirement-complete" },
          },
          tx
        );
      }

      // LM (D-LD-07 heal) — the lead snapshot mirrors the requirement truth:
      // budget / propertyType / desiredLocation on the Lead row used to be a
      // SECOND, drifting copy of the same facts (create wrote them once; the
      // requirements form then diverged silently). The drawer's info band and
      // the list read the Lead snapshot, so every requirements save now
      // re-syncs the overlapping columns in the SAME transaction — one write
      // path, one truth. district → desiredLocation is the deliberate
      // vocabulary join (the create form's free-text location and the
      // requirement's district are the same business concept).
      const snapshot: Record<string, unknown> = {};
      if (row.budgetMin !== lead.budgetMin) snapshot.budgetMin = row.budgetMin;
      if (row.budgetMax !== lead.budgetMax) snapshot.budgetMax = row.budgetMax;
      if (row.propertyType !== lead.propertyType) snapshot.propertyType = row.propertyType;
      if (row.district !== lead.desiredLocation) snapshot.desiredLocation = row.district;
      if (Object.keys(snapshot).length > 0) {
        await tx.lead.update({ where: { id: lead.id }, data: snapshot });
      }

      // W2-A2 (P1) — the qualification act recomputes the score cache in the
      // SAME transaction (single writer; no trail rows — a derivation). The
      // engine reads the just-upserted requirement through this tx, so the
      // response-consistent cache lands with the facts that caused it.
      await refreshLeadScore(tx, orgId, lead.id);

      return row;
    });

    return ok({ requirement });
  } catch (error) {
    return fail(error);
  }
}
