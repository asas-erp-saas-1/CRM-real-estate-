// POST /api/leads/:id/tags — find-or-create a tag in the org, then attach it to
// the lead. Already attached → 200 (idempotent); newly attached → 201.
import type { NextRequest } from "next/server";
import { z } from "zod";
import type { Tag } from "@prisma/client";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { findLead } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { isPrismaKnownError, parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  name: z.string().trim().min(1, "Nom du tag requis").max(60),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, schema);

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    // G5-P3-5 (F-06, D-GOV-5): find-or-create, attach, and the trail commit
    // as ONE transaction — a crash between them can no longer leave an
    // attached tag with no timeline entry (or an orphaned audit row).
    const { tag, attached } = await db.$transaction(async (tx) => {
      // Find-or-create within the org (Tag @@unique([orgId, name])). The
      // find-first pass is the fast path; the P2002 catch below is the
      // concurrent-create race backstop — idempotent by design.
      let tag: Tag | null = await tx.tag.findFirst({ where: { orgId, name: body.name } });
      if (!tag) {
        try {
          tag = await tx.tag.create({ data: { orgId, name: body.name } });
        } catch (error) {
          // 3c (G2 audit): a concurrent duplicate-name create winning the
          // unique race used to surface as a raw 500. Same idempotency law
          // as the leadTag.create P2002 below: re-fetch the winner and
          // continue — the org ends with exactly one tag of that name.
          if (!isPrismaKnownError(error, "P2002")) throw error;
          tag = await tx.tag.findFirstOrThrow({ where: { orgId, name: body.name } });
        }
      }

      try {
        await tx.leadTag.create({ data: { leadId: lead.id, tagId: tag.id } });
      } catch (error) {
        if (isPrismaKnownError(error, "P2002")) {
          // Already attached — idempotent success (no trail row: nothing
          // changed on the lead).
          return { tag, attached: false };
        }
        throw error;
      }
      injectTxFault(req, "lead-tags-post");

      // W1-3 (Phase 2.1 — A6#2): tag attachment was fully invisible (no
      // activity, no audit) — now both trail rows land with the mutation.
      await logActivity({
        orgId,
        actorId: user.id,
        leadId: lead.id,
        type: "TAG",
        title: `Étiquette ajoutée — ${tag.name}`,
        meta: { tagId: tag.id, tagName: tag.name },
      }, tx);
      await logAudit({
        orgId,
        actor: user,
        action: "LEAD_TAG_ADDED",
        entity: "LEAD",
        entityId: lead.id,
        before: null,
        after: { tagId: tag.id, tagName: tag.name },
      }, tx);
      return { tag, attached: true };
    });

    if (attached) return ok({ tag, attached: true }, 201);
    return ok({ tag, attached: false });
  } catch (error) {
    return fail(error);
  }
}
