// POST /api/leads/:id/touches — record a channel interaction (P2/W5 Agent 6B).
// GET  /api/leads/:id/touches — the lead's attribution timeline (desc, take 100).
//
// The attribution LAWS this route enforces:
//   · Lead.source (the ORIGINAL source) is never touched — touches are their
//     own table; a later interaction can never overwrite where the customer
//     came from (mission rule, structural: separate tables, separate API).
//   · Scope: the same visibility primitive as every lead surface
//     (leadScope — agents touch their own/unassigned leads only; a foreign
//     lead is a 404 byte-identical to a nonexistent one).
//   · Closed vocabulary: channel ∈ TOUCH_CHANNELS, direction ∈ {INBOUND,
//     OUTBOUND}; note ≤ 500 chars; campaign ≤ 120 chars.
//   · occurredAt defaults to now and cannot be backdated beyond 1 year
//     (attribution history must stay honest) nor postdated into the future.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { TOUCH_CHANNELS, TOUCH_DIRECTIONS } from "@/lib/constants";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope } from "@/lib/server/visibility";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const MAX_BACKDATE_MS = 365 * 24 * 60 * 60 * 1000;

const touchSchema = z
  .object({
    channel: z.enum(TOUCH_CHANNELS),
    direction: z.enum(TOUCH_DIRECTIONS),
    note: z.string().trim().max(500).optional(),
    campaign: z.string().trim().max(120).optional(),
    occurredAt: z.string().datetime().optional(),
  })
  .strict();

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const body = await parseBody(req, touchSchema);

    const lead = await db.lead.findFirst({
      where: { id, orgId: user.orgId, ...leadScope(user) },
      select: { id: true, orgId: true, source: true, fullName: true },
    });
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    let occurredAt = new Date();
    if (body.occurredAt) {
      const t = new Date(body.occurredAt);
      if (Number.isNaN(t.getTime())) {
        throw new ApiError(400, "Date d'interaction invalide", "INVALID_TOUCH_DATE");
      }
      const now = Date.now();
      if (t.getTime() > now + 60_000) {
        throw new ApiError(400, "La date d'interaction ne peut pas être dans le futur", "TOUCH_DATE_FUTURE");
      }
      if (t.getTime() < now - MAX_BACKDATE_MS) {
        throw new ApiError(400, "La date d'interaction ne peut pas être antérieure à un an", "TOUCH_DATE_TOO_OLD");
      }
      occurredAt = t;
    }

    const touch = await db.leadTouch.create({
      data: {
        orgId: lead.orgId,
        leadId: lead.id,
        channel: body.channel,
        direction: body.direction,
        note: body.note ?? null,
        campaign: body.campaign ?? null,
        actorId: user.id,
        occurredAt,
      },
    });

    await logAudit({
      orgId: lead.orgId,
      actor: user,
      action: "LEAD_TOUCH_RECORDED",
      entity: "LEAD",
      entityId: lead.id,
      after: { channel: body.channel, direction: body.direction, campaign: body.campaign ?? null },
    });

    return ok({ touch }, 201);
  } catch (error) {
    return fail(error);
  }
}

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    const lead = await db.lead.findFirst({
      where: { id, orgId: user.orgId, ...leadScope(user) },
      select: { id: true, orgId: true, source: true, createdAt: true },
    });
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    const touches = await db.leadTouch.findMany({
      where: { leadId: lead.id, orgId: lead.orgId },
      orderBy: { occurredAt: "desc" },
      take: 100,
      include: { actor: { select: { id: true, name: true } } },
    });

    // The attribution summary: original source (immutable) + first touch.
    const firstInbound = touches.filter((t) => t.direction === "INBOUND").at(-1) ?? null;
    return ok({
      touches,
      attribution: {
        originalSource: lead.source, // NEVER overwritten by interactions
        firstTouchAt: firstInbound?.occurredAt.toISOString() ?? lead.createdAt.toISOString(),
        firstTouchChannel: firstInbound?.channel ?? lead.source,
        firstTouchIsFallback: firstInbound === null, // true → fell back to lead creation
      },
    });
  } catch (error) {
    return fail(error);
  }
}
