// POST /api/leads/:id/score — W2-A2 (P1): recompute the lead's score NOW.
// The explicit, on-demand recalculation endpoint of the scoring trigger
// matrix (scoring.ts docblock): org-scoped through the D-021 leadScope law
// (visibility decides — the PATCH parity rule: an in-scope user of ANY role
// may refresh a lead they can see and edit; a foreign lead is a 404
// byte-identical to a missing one). No role floor on purpose: the score is a
// read-derived cache, and every writer is the same single engine.
//
// Response: the fresh score, its full per-signal breakdown, and the cache
// stamp — the same transparency contract as the drawer's « Pourquoi ce
// score ? ». No Activity/Audit rows (a derivation, not a business event —
// see scoring.ts).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { findLead, refreshLeadScore } from "@/lib/server/leads";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope } from "@/lib/server/visibility";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    // D-021 — the scoped read: a foreign-owned lead is 404, byte-identical
    // to a nonexistent id (no existence leak).
    const lead = await findLead(orgId, id, leadScope(user), { select: { id: true } });
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    // The single writer, in its own transaction: facts load → engine →
    // three-column cache write, all-or-nothing.
    const result = await db.$transaction(async (tx) => refreshLeadScore(tx, orgId, lead.id));
    if (!result) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND"); // vanished mid-flight

    return ok({
      score: result.score,
      breakdown: result.breakdown,
      version: result.version,
      scoreComputedAt: new Date().toISOString(),
    });
  } catch (error) {
    return fail(error);
  }
}
