// POST /api/leads/:id/convert — lead → contact + opportunity (stage QUALIFIED)
// in a single transaction. 409 when already converted.
// PIPE-01 (G3 §3 — the next-action law): the convert-born deal carries a next
// action from birth (was null — a born-open deal with nothing to do next is
// exactly the rot the Pipedrive law hunts).
import type { NextRequest } from "next/server";
import { OPP_STAGE_DEFAULT_PROBABILITY } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { findLead, leadInclude, toLeadDTO } from "@/lib/server/leads";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope } from "@/lib/server/visibility";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    const lead = await findLead(orgId, id, leadScope(user)); // D-021 scoped (G5-P4-2 — the shared helper)
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");
    if (lead.convertedContactId || lead.status === "CONVERTED") {
      throw new ApiError(409, "Lead déjà converti", "ALREADY_CONVERTED");
    }
    // LM (D-LD-02 guard) — a pre-fix merge could leave a client record
    // re-pointed onto this lead while its own status/convertedContactId
    // still read unconverted; the 1:1 contact→lead unique index would then
    // surface the state as an opaque 500 (P2002). Answer it honestly: the
    // lead ALREADY owns a client record.
    const existingContact = await db.contact.findFirst({ where: { leadId: lead.id, orgId } });
    if (existingContact) {
      throw new ApiError(
        409,
        "Ce prospect possède déjà une fiche client (héritée d'une fusion) — statut à corriger via un manager.",
        "ALREADY_HAS_CLIENT_RECORD",
      );
    }

    const title = `${lead.fullName} — ${lead.propertyType ?? "Bien"} ${lead.desiredLocation ?? ""}`.trim();

    // P9-D07 — the two pre-checks above run OUTSIDE the transaction, so a
    // concurrent double-POST dies on the unique indexes (Contact.leadId /
    // Lead.convertedContactId) with an opaque P2002 → 500. Answer the race
    // honestly: catch the unique-violation at the tx boundary and surface
    // it as the same 409 the pre-checks use (no duplicate rows can persist —
    // the DB backstop holds either way).
    const { contact, opportunity } = await db
      .$transaction(async (tx) => {
        const contact = await tx.contact.create({
          data: {
            orgId,
            leadId: lead.id,
            fullName: lead.fullName,
            // Phase 11 (A4) — the conversion-carry contract: the contact
            // inherits the lead's richer identity channels exactly as it
            // always inherited fullNameAr. Preservation law (master §A2-D):
            // no channel is silently dropped at conversion.
            fullNameAr: lead.fullNameAr,
            secondaryPhone: lead.secondaryPhone,
            whatsapp: lead.whatsapp,
            phone: lead.phone,
            email: lead.email,
            notes: lead.notes,
          },
        });
        const opportunity = await tx.opportunity.create({
          data: {
            orgId,
            leadId: lead.id,
            contactId: contact.id,
            title,
            stage: "QUALIFIED",
            value: lead.budgetMax,
            ownerId: lead.ownerId ?? user.id,
            // Phase 11 (A4) — the conversion attribution carry: the deal
            // inherits the acquisition origin snapshot (stamped once, never
            // edited) so source/campaign revenue analytics never joins back.
            sourceOrigin: lead.source,
            campaignId: lead.campaignId,
            // P2.4 (A1-B5) — creation-time probability reads the ONE canonical
            // stage table (was a hardcoded 20 that drifted from the seed's 15).
            probability: OPP_STAGE_DEFAULT_PROBABILITY.QUALIFIED,
            // PIPE-01 (G3 §3) — the birth next action: the canonical French
            // text of the create dialog's FIRST preset chip (« Appeler le
            // prospect » — the qualification follow-up a fresh deal starts
            // with). Platform convention: server-authored strings are French
            // (documented debt — the seed is not localized; the cockpit's edit
            // form re-labels it in the user's language).
            nextAction: "Appeler le prospect",
            // W3-8 (Phase 2.1 — A4#11): kanban aging starts at creation on the
            // convert path too (POST /api/opportunities already stamps it).
            stageChangedAt: new Date(),
          },
        });
        const convertedAt = new Date();
        await tx.lead.update({
          where: { id: lead.id },
          data: { status: "CONVERTED", convertedContactId: contact.id, convertedAt },
        });
        // G5-P3-5 (F-06): the CONVERSION timeline entry commits with the
        // conversion itself — a forced failure rolls back all four rows
        // (contact + opportunity + lead flip + activity; §41 FR41g/h).
        injectTxFault(req, "convert-post");
        await logActivity({
          orgId,
          actorId: user.id,
          leadId: lead.id,
          opportunityId: opportunity.id,
          contactId: contact.id,
          type: "CONVERSION",
          title: `Lead converti — ${lead.fullName}`,
          body: `Opportunité « ${title} » créée`,
          meta: { opportunityId: opportunity.id, contactId: contact.id, stage: "QUALIFIED" },
        }, tx);
        // W1-3 (Phase 2.1 — A6#2): lead conversion is a major business event —
        // it now carries an audit row inside the same transaction (F-06 law).
        await logAudit({
          orgId,
          actor: user,
          action: "LEAD_CONVERTED",
          entity: "LEAD",
          entityId: lead.id,
          before: { status: lead.status },
          after: { status: "CONVERTED", contactId: contact.id, opportunityId: opportunity.id },
        }, tx);
        return { contact, opportunity };
      })
      .catch((error: unknown) => {
        // P2002 = unique-constraint violation → the concurrent twin already
        // converted (Contact.leadId unique) — surface the honest 409.
        if (
          typeof error === "object" &&
          error !== null &&
          (error as { code?: string }).code === "P2002"
        ) {
          throw new ApiError(409, "Lead déjà converti", "ALREADY_CONVERTED");
        }
        throw error;
      });

    const updatedLead = await db.lead.findUnique({ where: { id: lead.id }, include: leadInclude });

    return ok({ lead: updatedLead ? toLeadDTO(updatedLead) : null, contact, opportunity }, 201);
  } catch (error) {
    return fail(error);
  }
}
