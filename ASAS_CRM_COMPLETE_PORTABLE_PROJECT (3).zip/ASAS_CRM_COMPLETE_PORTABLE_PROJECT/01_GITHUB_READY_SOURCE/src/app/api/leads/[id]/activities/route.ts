// POST /api/leads/:id/activities — manual timeline entries (NOTE, CALL, WHATSAPP,
// EMAIL, SMS, MEETING, DOCUMENT). Contact-type entries refresh lastContactAt.
// P29 (D-037) — §12.4: contact-type entries may carry a STRUCTURED outcome
// (FOLLOW_UP_OUTCOMES, the directive's list verbatim) alongside the free-text
// body; a NOTE (or any non-contact type) never does — 422 OUTCOME_TYPE_MISMATCH.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { FOLLOW_UP_OUTCOMES, OUTCOME_BEARING_TYPES } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { findLead } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const USER_ACTIVITY_TYPES = ["NOTE", "CALL", "WHATSAPP", "EMAIL", "SMS", "MEETING", "DOCUMENT"] as const;
const CONTACT_TYPES = new Set<string>(["CALL", "WHATSAPP", "EMAIL", "SMS", "MEETING"]);
const OUTCOME_BEARING = new Set<string>(OUTCOME_BEARING_TYPES);
// E2E-FINAL (D12) — twin-detection window (see the guard in POST): an
// activity row identical on org/lead/actor/type/title/body and younger
// than this is a double-click echo, not a new entry.
const DEDUP_WINDOW_MS = 5_000;

const schema = z.object({
  type: z.enum(USER_ACTIVITY_TYPES),
  title: z.string().trim().min(1, "Titre requis").max(200),
  body: z.string().trim().max(5000).nullable().optional(),
  // P29 (D-037) — §12.4 structured outcome: enum-closed (D-016), nullable
  // (an attempt can legitimately end without a recorded outcome yet).
  outcome: z.enum(FOLLOW_UP_OUTCOMES).nullable().optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, schema);

    // §12.4 law: outcomes belong to CONTACT attempts — a note or document row
    // mixing an outcome is a vocabulary error, rejected with a named code.
    if (body.outcome != null && !OUTCOME_BEARING.has(body.type)) {
      throw new ApiError(
        422,
        "Le résultat de contact ne s'applique qu'aux activités de contact (appel, WhatsApp, e-mail, SMS, rencontre)",
        "OUTCOME_TYPE_MISMATCH",
      );
    }

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    // E2E-FINAL (D11 — master-audit finding, confirmed live) — a contact
    // attempt on a NEW lead advances it to CONTACTED. The journey engine had
    // already derived ENGAGED from lastContactAt while the lead.status chip
    // (and every status-filtered surface: list chips, dashboard NEW KPI,
    // status filters) still said « Nouveau » — the two surfaces disagreed
    // after the very first logged call. NEW → CONTACTED is a routine forward
    // edge of LEAD_TRANSITIONS (no correction ceremony); every other status
    // is left to its owning flow.
    const advanceStatus = CONTACT_TYPES.has(body.type) && lead.status === "NEW" ? "CONTACTED" : null;

    // E2E-FINAL (D11) — the activity row, the lastContactAt refresh and the
    // status advance commit as ONE transaction (previously the update ran
    // after the create — a failure between them left a contact activity with
    // no lastContactAt stamp). The status advance rides the same tx law as
    // every other status change: activity + audit, or nothing.
    const { activity, deduplicated } = await db.$transaction(async (tx) => {
      // E2E-FINAL (D12 — master-audit finding) — timeline writes had no
      // idempotency: a double-click on the composer's submit created twin
      // rows (same org/lead/actor/type/title/body, seconds apart). The
      // guard re-reads INSIDE the transaction, so check-then-create is
      // atomic: an identical row younger than DEDUP_WINDOW_MS is this very
      // submission arriving again — answer with it, create nothing. body
      // compares null-safe (Prisma null matches IS NULL, mirroring the
      // create's `?? null` normalization). System rows never collide: their
      // types (STATUS_CHANGE, …) are outside USER_ACTIVITY_TYPES.
      const twin = await tx.activity.findFirst({
        where: {
          orgId,
          leadId: lead.id,
          actorId: user.id,
          type: body.type,
          title: body.title,
          body: body.body ?? null,
          createdAt: { gte: new Date(Date.now() - DEDUP_WINDOW_MS) },
        },
        orderBy: { createdAt: "desc" },
      });
      if (twin) return { activity: twin, deduplicated: true };

      const row = await tx.activity.create({
        data: {
          orgId,
          actorId: user.id,
          leadId: lead.id,
          contactId: lead.convertedContactId,
          type: body.type,
          title: body.title,
          body: body.body ?? null,
          outcome: body.outcome ?? null,
          occurredAt: new Date(),
        },
      });

      if (CONTACT_TYPES.has(body.type) || advanceStatus) {
        // W3-3 (Phase 2.1 — A4#4): a logged contact FULFILLS an overdue
        // follow-up commitment — the journey urgency kept +100 forever after
        // fresh contact because nextFollowUpAt never auto-advanced. Future
        // commitments stay (a contact today doesn't cancel next week's
        // planned follow-up); only the overdue one clears.
        const overdueFollowUp =
          CONTACT_TYPES.has(body.type) && lead.nextFollowUpAt != null && lead.nextFollowUpAt.getTime() <= Date.now();
        await tx.lead.update({
          where: { id: lead.id },
          data: {
            ...(CONTACT_TYPES.has(body.type) ? { lastContactAt: new Date() } : {}),
            ...(advanceStatus ? { status: advanceStatus } : {}),
            ...(overdueFollowUp ? { nextFollowUpAt: null } : {}),
          },
        });
      }

      if (advanceStatus) {
        await logActivity(
          {
            orgId,
            actorId: user.id,
            leadId: lead.id,
            type: "STATUS_CHANGE",
            title: `Statut changé : ${lead.status} → ${advanceStatus}`,
            body: "Premier contact enregistré (avance automatique)",
            meta: { before: lead.status, after: advanceStatus, auto: "first-contact" },
          },
          tx
        );
        await logAudit(
          {
            orgId,
            actor: user,
            action: "LEAD_STATUS_CHANGED",
            entity: "LEAD",
            entityId: lead.id,
            before: { status: lead.status },
            after: { status: advanceStatus, auto: "first-contact" },
          },
          tx
        );
      }

      return { activity: row, deduplicated: false };
    });

    // E2E-FINAL (D12) — the idempotent re-answer: 200 + the existing row
    // (a double-click is not an error — the client treats any 2xx as
    // success; the twin simply never gets written).
    if (deduplicated) return ok({ activity, deduplicated: true }, 200);
    return ok({ activity }, 201);
  } catch (error) {
    return fail(error);
  }
}
