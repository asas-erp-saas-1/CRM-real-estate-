// POST /api/leads/:id/tasks — create a task attached to the lead
// (owner = lead owner or current user), logged on the timeline.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { PRIORITIES, TASK_TYPES } from "@/lib/constants";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { findLead } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({
  title: z.string().trim().min(1, "Titre requis").max(200),
  type: z.enum(TASK_TYPES),
  dueAt: z.coerce.date(),
  priority: z.enum(PRIORITIES).default("NORMAL"),
  notes: z.string().trim().max(5000).nullable().optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, schema);

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    // G5-P3-5 (F-06, D-GOV-5): the task creation and its Activity/Audit
    // trail commit as ONE transaction — a crash between them can no longer
    // leave a task without its timeline entry (or an orphaned audit row).
    const task = await db.$transaction(async (tx) => {
      const row = await tx.task.create({
        data: {
          orgId,
          leadId: lead.id,
          ownerId: lead.ownerId ?? user.id,
          title: body.title,
          type: body.type,
          dueAt: body.dueAt,
          priority: body.priority,
          notes: body.notes ?? null,
        },
      });
      injectTxFault(req, "lead-tasks-post");

      await logActivity({
        orgId,
        actorId: user.id,
        leadId: lead.id,
        taskId: row.id,
        type: "TASK",
        title: `Tâche créée — ${row.title}`,
        meta: { dueAt: row.dueAt.toISOString(), taskType: row.type, priority: row.priority },
      }, tx);
      // W1-3 (Phase 2.1 — A6#2): lead-task creation now audited.
      await logAudit({
        orgId,
        actor: user,
        action: "TASK_CREATED",
        entity: "TASK",
        entityId: row.id,
        before: null,
        after: { title: row.title, type: row.type, dueAt: row.dueAt.toISOString(), leadId: lead.id },
      }, tx);
      return row;
    });

    return ok({ task }, 201);
  } catch (error) {
    return fail(error);
  }
}
