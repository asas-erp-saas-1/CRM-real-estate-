// ASAS — Lead AI Copilot (R6): LLM-generated commercial assessment.
//
// POST /api/leads/:id/copilot  { lang?: "fr" | "en" | "ar" }  (default fr)
//
// Builds a compact lead context (profile, requirement, open tasks, visits,
// opportunities, top matches, recent timeline) and asks the LLM
// (z-ai-web-dev-sdk, server-side only) for a structured JSON assessment:
// summary, temperature HOT/WARM/COLD, next best action, WhatsApp draft,
// talking points, risks. The payload is persisted as an Activity (type
// COPILOT — full JSON in meta, summary in body) so every generation lands on
// the lead timeline, and the latest one is returned to the caller.
//
// Guardrails: org-scoped lead; light in-memory rate limit (1 per 20s per lead)
// against accidental double-fires; tolerant JSON parsing (fences/prose);
// 502 COPILOT_BAD_RESPONSE when the model output is unusable.

import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireAiProvider } from "@/lib/server/ai-provider";
import { logActivity, logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope } from "@/lib/server/visibility";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const TEMPERATURES = new Set(["HOT", "WARM", "COLD"]);
const SUGGESTED_TYPES = new Set(["CALL", "WHATSAPP", "EMAIL", "FOLLOW_UP", "MEETING", "VISIT"]);
const WHENS = new Set(["TODAY", "TOMORROW", "THIS_WEEK", "LATER"]);

const RATE_LIMIT_MS = 20_000;
const lastRunAt = new Map<string, number>();

// W3.8 (master audit — PERF-P9): the LLM call's hard ceiling. The
// z-ai-web-dev-sdk exposes NO timeout/abort option (its create() fetch carries
// no signal — verified in dist/index.js), so the route bounds the await itself
// with a Promise.race timer; a loss maps to 504 COPILOT_TIMEOUT instead of an
// open-ended hang that pins the request (and its rate-limit budget) forever.
const COPILOT_TIMEOUT_MS = 60_000;

const bodySchema = z.object({
  lang: z.enum(["fr", "en", "ar"]).optional(),
});

interface CopilotPayload {
  summary: string;
  temperature: "HOT" | "WARM" | "COLD";
  nextAction: {
    title: string;
    rationale: string;
    suggestedType: string;
    when: string;
  };
  whatsappDraft: string;
  /** R7: ready-to-send email variant (subject + body) — null when unusable. */
  emailDraft: { subject: string; body: string } | null;
  /** R7: LLM-proposed lead score 0–100 (agent applies it in one click). */
  suggestedScore: number | null;
  scoreRationale: string;
  talkingPoints: string[];
  risks: string[];
  generatedAt: string;
  lang: string;
}

function clampStr(v: unknown, max: number): string {
  return String(v ?? "").trim().slice(0, max);
}

/** Tolerant parse: strip fences, find the outermost JSON object, clamp fields. */
function parseCopilot(raw: string, lang: string): CopilotPayload {
  let text = raw.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) text = fence[1]!.trim();
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start >= 0 && end > start) text = text.slice(start, end + 1);

  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new ApiError(502, "Réponse IA non exploitable", "COPILOT_BAD_RESPONSE");
  }

  const nextRaw = (parsed.nextAction ?? {}) as Record<string, unknown>;
  const temperatureRaw = String(parsed.temperature ?? "WARM").toUpperCase();
  const suggestedTypeRaw = String(nextRaw.suggestedType ?? "FOLLOW_UP").toUpperCase();
  const whenRaw = String(nextRaw.when ?? "THIS_WEEK").toUpperCase();

  const talkingPoints = Array.isArray(parsed.talkingPoints)
    ? parsed.talkingPoints.map((p) => clampStr(p, 160)).filter(Boolean).slice(0, 5)
    : [];
  const risks = Array.isArray(parsed.risks)
    ? parsed.risks.map((r) => clampStr(r, 160)).filter(Boolean).slice(0, 4)
    : [];

  // R7 — suggested score: clamp to 0–100 integer; null when absent/unparseable.
  const scoreNum = Number(parsed.suggestedScore);
  const suggestedScore =
    parsed.suggestedScore !== null &&
    parsed.suggestedScore !== undefined &&
    Number.isFinite(scoreNum)
      ? Math.min(100, Math.max(0, Math.round(scoreNum)))
      : null;

  // R7 — email draft: tolerate string-only bodies and missing subjects.
  const emailRaw = parsed.emailDraft as Record<string, unknown> | string | null | undefined;
  let emailDraft: CopilotPayload["emailDraft"] = null;
  if (typeof emailRaw === "string" && emailRaw.trim()) {
    emailDraft = { subject: "", body: clampStr(emailRaw, 1200) };
  } else if (emailRaw && typeof emailRaw === "object") {
    const subject = clampStr((emailRaw as Record<string, unknown>).subject, 140);
    const emailBody = clampStr((emailRaw as Record<string, unknown>).body, 1200);
    if (subject || emailBody) emailDraft = { subject, body: emailBody };
  }

  return {
    summary: clampStr(parsed.summary, 700),
    temperature: (TEMPERATURES.has(temperatureRaw) ? temperatureRaw : "WARM") as CopilotPayload["temperature"],
    nextAction: {
      title: clampStr(nextRaw.title, 140),
      rationale: clampStr(nextRaw.rationale, 400),
      suggestedType: SUGGESTED_TYPES.has(suggestedTypeRaw) ? suggestedTypeRaw : "FOLLOW_UP",
      when: WHENS.has(whenRaw) ? whenRaw : "THIS_WEEK",
    },
    whatsappDraft: clampStr(parsed.whatsappDraft, 600),
    emailDraft,
    suggestedScore,
    scoreRationale: clampStr(parsed.scoreRationale, 300),
    talkingPoints,
    risks,
    generatedAt: new Date().toISOString(),
    lang,
  };
}

function iso(d: Date | null | undefined): string | null {
  return d ? d.toISOString().slice(0, 16).replace("T", " ") : null;
}

function promptFor(ctx: unknown, lang: string): string {
  const outputLang =
    lang === "ar"
      ? "Arabic (Modern Standard, Algerian real-estate vocabulary)"
      : lang === "en"
        ? "English"
        : "French (registre professionnel algérien, ton chaleureux)";
  return `You are the AI copilot of ASAS, a real-estate CRM in Algiers, Algeria. You advise the sales agent who owns this lead.
Analyze the lead context below and produce a commercial assessment.

CONTEXT (JSON):
${JSON.stringify(ctx, null, 1)}

Return ONLY a JSON object, no markdown fence, in exactly this shape:
{
  "summary": "2–3 sentences: where this lead stands, engagement level, momentum.",
  "temperature": "HOT" | "WARM" | "COLD",
  "nextAction": {
    "title": "concrete next action (imperative, ≤ 80 chars)",
    "rationale": "1–2 sentences: why this action now",
    "suggestedType": "CALL" | "WHATSAPP" | "EMAIL" | "FOLLOW_UP" | "MEETING" | "VISIT",
    "when": "TODAY" | "TOMORROW" | "THIS_WEEK" | "LATER"
  },
  "whatsappDraft": "a ready-to-send WhatsApp message to the lead, warm professional tone, ≤ 60 words, references their requirement concretely (budget/type/district when known), ends with a clear question",
  "emailDraft": { "subject": "concise email subject ≤ 60 chars", "body": "a ready-to-send email to the lead, 80–140 words, professional warm tone, structured in 2–3 short paragraphs, references their requirement concretely, ends with a clear call to action" },
  "suggestedScore": 0-100 integer lead score, where 90+ = signing imminent, 70–89 = engaged & qualified, 40–69 = responsive but unconfirmed, < 40 = weak/stalling/lost signals,
  "scoreRationale": "1 sentence justifying the suggested score from engagement signals",
  "talkingPoints": ["3–4 short bullets for the next conversation"],
  "risks": ["0–3 risks: competition, budget mismatch, stalling, lost signals — empty array if none"]
}

Rules:
- Write every human-facing string in ${outputLang}. Keys stay English.
- temperature: HOT = engaged/visiting/negotiating; WARM = responsive but slow; COLD = no contact for a long time or closed-lost signals.
- Base every statement on the provided context only. If data is missing, phrase the draft generically — never invent budget figures, project names they never visited, or promises (price discounts, availability guarantees).
- Money amounts use DA. Dates as-is from context.
- whatsappDraft must NOT include placeholders like [Name] — use the lead's first name if known.
- emailDraft: professional but warmer than a formal letter; no placeholders; use the lead's first name. If the context says hasEmail is false, still write the draft (the agent will collect the address).
- suggestedScore must reflect OBSERVED engagement only (contacts, visits, stage, recency) — not potential.
Respond with the JSON object only.`;
}

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const body = await parseBody(req, bodySchema);
    const lang = body.lang ?? "fr";

    // D-021 — AI surfaces inherit the caller's record visibility: the copilot
    // can only ever summarize a lead the caller is authorized to open.
    const lead = await db.lead.findFirst({
      where: { id, orgId: user.orgId, ...leadScope(user) },
      include: {
        owner: { select: { id: true, name: true } },
        requirements: true,
        opportunities: {
          orderBy: { createdAt: "desc" },
          take: 5,
          include: { project: { select: { name: true, district: true } } },
        },
      },
    });
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    // H2 portability guard: resolve the AI provider BEFORE the rate limiter —
    // an unconfigured host answers 503 AI_PROVIDER_UNAVAILABLE and never
    // consumes the lead's rate-limit budget (nor builds the context).
    const zai = await requireAiProvider();

    // Light in-memory rate limit — protects against double-clicks and loops.
    // W5-8 (Phase 2.1 — A3#3): keyed by (user, lead) — the old per-lead key
    // made one agent's run throttle every other agent working the same lead.
    const now = Date.now();
    const limiterKey = `${user.id}:${lead.id}`;
    const last = lastRunAt.get(limiterKey) ?? 0;
    if (now - last < RATE_LIMIT_MS) {
      throw new ApiError(429, "Analyse très récente — patientez quelques secondes", "COPILOT_RATE_LIMITED");
    }
    lastRunAt.set(limiterKey, now);

    const requirement = lead.requirements[0] ?? null;

    const [openTasks, visits, activities, topMatches] = await Promise.all([
      db.task.findMany({
        where: { leadId: lead.id, status: "OPEN" },
        orderBy: { dueAt: "asc" },
        take: 8,
        select: { title: true, type: true, dueAt: true, priority: true },
      }),
      db.visit.findMany({
        where: { leadId: lead.id },
        orderBy: { scheduledAt: "desc" },
        take: 6,
        select: { scheduledAt: true, status: true, outcome: true, attended: true },
      }),
      db.activity.findMany({
        where: { leadId: lead.id },
        orderBy: { occurredAt: "desc" },
        take: 20,
        select: { type: true, title: true, occurredAt: true },
      }),
      requirement
        ? db.propertyMatch.findMany({
            where: { requirementId: requirement.id },
            orderBy: { score: "desc" },
            take: 3,
            include: {
              apartment: {
                select: { code: true, unitType: true, price: true, surface: true, status: true },
              },
            },
          })
        : Promise.resolve([]),
    ]);

    const context = {
      lead: {
        name: lead.fullName,
        status: lead.status,
        priority: lead.priority,
        score: lead.score,
        hasEmail: Boolean(lead.email),
        source: lead.source,
        budgetMin: lead.budgetMin,
        budgetMax: lead.budgetMax,
        propertyType: lead.propertyType,
        desiredLocation: lead.desiredLocation,
        lastContactAt: iso(lead.lastContactAt),
        nextFollowUpAt: iso(lead.nextFollowUpAt),
        lostReason: lead.lostReason,
        notes: lead.notes?.slice(0, 500) ?? null,
        owner: lead.owner?.name ?? null,
        createdAt: iso(lead.createdAt),
      },
      requirement: requirement
        ? {
            district: requirement.district,
            propertyType: requirement.propertyType,
            surfaceMin: requirement.surfaceMin,
            surfaceMax: requirement.surfaceMax,
            bedroomsMin: requirement.bedroomsMin,
            floorMin: requirement.floorMin,
            floorMax: requirement.floorMax,
            parking: requirement.parking,
            payment: requirement.payment,
            purpose: requirement.purpose,
            timeframe: requirement.timeframe,
          }
        : null,
      openTasks: openTasks.map((tk) => ({
        title: tk.title,
        type: tk.type,
        dueAt: iso(tk.dueAt),
        priority: tk.priority,
      })),
      visits: visits.map((v) => ({
        scheduledAt: iso(v.scheduledAt),
        status: v.status,
        attended: v.attended,
        outcome: v.outcome?.slice(0, 160) ?? null,
      })),
      opportunities: lead.opportunities.map((o) => ({
        title: o.title,
        stage: o.stage,
        value: o.value,
        project: o.project?.name ?? null,
        nextAction: o.nextAction,
      })),
      topMatches: topMatches.map((m) => ({
        code: m.apartment?.code ?? null,
        unitType: m.apartment?.unitType ?? null,
        price: m.apartment?.price ?? null,
        score: m.score,
      })),
      recentTimeline: activities.map((a) => ({
        type: a.type,
        title: a.title.slice(0, 120),
        at: iso(a.occurredAt),
      })),
    };

    // W3.8 (master audit — PERF-P9): race the SDK call against the ceiling —
    // `.finally` clears the timer on WHICHEVER branch settles first (no
    // dangling handle keeps the process alive after a fast completion, and a
    // timeout clears itself harmlessly). The loser of the race is simply
    // dropped (the SDK's own fetch is not abortable — it finishes in the
    // background and its result is ignored).
    let copilotTimer: ReturnType<typeof setTimeout> | undefined;
    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: "assistant",
            content:
              "You are an expert real-estate sales coach. You output strictly valid JSON, concise, actionable, never invent facts.",
          },
          { role: "user", content: promptFor(context, lang) },
        ],
        stream: false,
        thinking: { type: "disabled" },
      }),
      new Promise<never>((_, reject) => {
        copilotTimer = setTimeout(
          () =>
            reject(
              new ApiError(
                504,
                "Le copilote IA met trop de temps à répondre — réessayez dans un instant",
                "COPILOT_TIMEOUT",
              ),
            ),
          COPILOT_TIMEOUT_MS,
        );
      }),
    ]).finally(() => clearTimeout(copilotTimer));
    const content = completion.choices?.[0]?.message?.content ?? "";
    if (!content.trim()) throw new ApiError(502, "Réponse IA vide", "COPILOT_BAD_RESPONSE");

    const copilot = parseCopilot(content, lang);

    // Persist as a timeline Activity (COPILOT) — body keeps it scannable,
    // meta carries the full structured payload for the UI.
    const activity = await logActivity({
      orgId: user.orgId,
      actorId: user.id,
      leadId: lead.id,
      type: "COPILOT",
      title: `Copilote IA — ${copilot.temperature}`,
      body: copilot.summary,
      meta: copilot as unknown as Record<string, unknown>,
    });

    await logAudit({
      orgId: user.orgId,
      actor: user,
      action: "COPILOT_GENERATED",
      entity: "LEAD",
      entityId: lead.id,
      before: null,
      after: { temperature: copilot.temperature, lang, activityId: activity.id },
    });

    return ok({ copilot, activityId: activity.id });
  } catch (error) {
    return fail(error);
  }
}
