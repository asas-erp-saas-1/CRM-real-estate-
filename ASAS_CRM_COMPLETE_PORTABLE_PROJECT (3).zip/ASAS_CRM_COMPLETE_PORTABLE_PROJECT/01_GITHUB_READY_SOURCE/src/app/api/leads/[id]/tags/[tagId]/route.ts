// DELETE /api/leads/:id/tags/:tagId — detach a tag from a lead (org-scoped).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { findLead } from "@/lib/server/leads";
import { leadScope } from "@/lib/server/visibility";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string; tagId: string }> };

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id, tagId } = await ctx.params;

    const lead = await findLead(orgId, id, leadScope(user));
    if (!lead) throw new ApiError(404, "Lead introuvable", "LEAD_NOT_FOUND");

    const tag = await db.tag.findFirst({ where: { id: tagId, orgId } });
    if (!tag) throw new ApiError(404, "Tag introuvable", "TAG_NOT_FOUND");

    const existing = await db.leadTag.findUnique({
      where: { leadId_tagId: { leadId: lead.id, tagId: tag.id } },
    });
    if (!existing) throw new ApiError(404, "Ce tag n'est pas attaché à ce lead", "TAG_NOT_ATTACHED");

    // G5-P3-5 (F-06, D-GOV-5): the detach and its Activity/Audit trail commit
    // as ONE transaction — a crash between them can no longer leave a detached
    // tag with no timeline entry (or an orphaned audit row).
    await db.$transaction(async (tx) => {
      await tx.leadTag.delete({ where: { leadId_tagId: { leadId: lead.id, tagId: tag.id } } });
      injectTxFault(req, "lead-tags-delete");

      // W1-3 (Phase 2.1 — A6#2): tag detachment was fully invisible (no
      // activity, no audit) — now both trail rows land with the mutation.
      await logActivity({
        orgId,
        actorId: user.id,
        leadId: lead.id,
        type: "TAG",
        title: `Étiquette retirée — ${tag.name}`,
        meta: { tagId: tag.id, tagName: tag.name, removed: true },
      }, tx);
      await logAudit({
        orgId,
        actor: user,
        action: "LEAD_TAG_REMOVED",
        entity: "LEAD",
        entityId: lead.id,
        before: { tagId: tag.id, tagName: tag.name },
        after: null,
      }, tx);
    });

    return ok({ removed: true, tagId: tag.id });
  } catch (error) {
    return fail(error);
  }
}
