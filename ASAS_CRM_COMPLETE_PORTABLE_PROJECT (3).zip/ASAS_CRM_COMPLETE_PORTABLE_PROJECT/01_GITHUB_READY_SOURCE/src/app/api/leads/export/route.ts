// ASAS — Leads CSV export (master prompt §23: exports respect permissions).
// GET /api/leads/export?…same filters as GET /api/leads…
// Role: MANAGER+ (lead.export permission per master prompt §24 RBAC matrix).
// Format: semicolon-separated + UTF-8 BOM (FR-locale Excel default — target
// market is Algeria/French business environment), CRLF line endings.
// A LEAD_EXPORTED audit entry is logged with the applied filter set.

import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { LEAD_STATUSES, PRIORITIES, SOURCES, UNIT_TYPES } from "@/lib/constants";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { csvDocument, csvEscape } from "@/lib/server/csv";
import { qp, qpDate, qpEnum, qpNumber } from "@/lib/server/validation";
import { seesAllRecords } from "@/lib/server/visibility";
import { displayPhone } from "@/lib/phone";

/** LM (D-LD-11) — the idle law mirrors the list route's own constant. */
const IDLE_DAYS = 14;

const HEADERS = [
  "id",
  "fullName",
  "phone",
  "phoneDisplay",
  "email",
  "source",
  "campaign",
  "status",
  "priority",
  "score",
  "budgetMin",
  "budgetMax",
  "propertyType",
  "desiredLocation",
  "owner",
  "tags",
  "createdAt",
  "lastContactAt",
  "nextFollowUpAt",
  "lostReason",
] as const;

// P4-8 (F-14 / CWE-1236 — CSV/spreadsheet formula injection): a cell whose
// first non-whitespace character is one of = + - @ \t \r is prefixed with a
// single quote `'` (the Excel/LibreOffice "force text" marker) BEFORE the
// quoting logic, so payloads like `=CMD|'/C calc'!A0`, `=SUM(1+1)`, `+1|REM`,
// `@SUM(...)`, `-2+3|cmd` export as inert text instead of executing when a
// MANAGER opens the file. Applied INSIDE csvEscape (shared at
// `@/lib/server/csv` — P7-4 extraction; behavior byte-identical): every
// user-controlled free-text column (fullName, email, campaign,
// desiredLocation, owner, tags, lostReason, phoneDisplay) flows through here.
// The defang marker is stripped back on import (leads/import/route.ts) so
// export→import round-trips. Raw (non-escaped) columns stay raw: id/dates are
// server-generated, and phone/source/status/priority/score/budgets/
// propertyType are enum- or E.164-normalized values (digits/letters only — no
// executable shape).

export async function GET(req: NextRequest) {
  try {
    const user = await requirePermission("leads.export");
    const orgId = user.orgId;
    const params = req.nextUrl.searchParams;

    // Same filter surface as the list endpoint — export what you see.
    const conditions: Prisma.LeadWhereInput[] = [{ orgId }];
    const query = qp(req, "query");
    if (query) {
      conditions.push({
        OR: [
          { fullName: { contains: query } },
          { phone: { contains: query } },
          { phoneRaw: { contains: query } },
          { email: { contains: query } },
        ],
      });
    }
    // LM (D-LD-01) — MULTI-STATUS: the list UI sends the comma-joined
    // vocabulary of its status checkboxes (status=NEW,CONTACTED); the old
    // single-value qpEnum 422'd the export the moment two chips were armed
    // ("export what you see" broke exactly when the view got richest).
    // Same contract as the list route: every member validated against
    // LEAD_STATUSES (garbage → 422 INVALID_FILTER — never a silent ignore).
    const statusParam = qp(req, "status");
    if (statusParam) {
      const requested = statusParam.split(",").map((s) => s.trim()).filter(Boolean);
      const invalid = requested.filter((s) => !(LEAD_STATUSES as readonly string[]).includes(s));
      if (invalid.length > 0) {
        throw new ApiError(422, `Paramètre 'status' : valeur non reconnue`, "INVALID_FILTER", {
          param: "status",
          value: statusParam,
          allowed: LEAD_STATUSES,
        });
      }
      if (requested.length === 1) conditions.push({ status: requested[0] });
      else if (requested.length > 1) conditions.push({ status: { in: requested } });
    }
    const source = qpEnum(req, "source", SOURCES);
    if (source) conditions.push({ source });
    const ownerId = qp(req, "ownerId");
    if (ownerId) conditions.push({ ownerId });
    const priority = qpEnum(req, "priority", PRIORITIES);
    if (priority) conditions.push({ priority });
    const minBudget = qpNumber(req, "minBudget");
    if (minBudget !== null) {
      conditions.push({ OR: [{ budgetMax: { gte: minBudget } }, { budgetMin: { gte: minBudget } }] });
    }
    const maxBudget = qpNumber(req, "maxBudget");
    if (maxBudget !== null) {
      conditions.push({ OR: [{ budgetMax: { lte: maxBudget } }, { budgetMin: { lte: maxBudget } }] });
    }
    const location = qp(req, "location");
    if (location) {
      conditions.push({
        OR: [{ desiredLocation: { contains: location } }, { requirements: { some: { district: { contains: location } } } }],
      });
    }
    const propertyType = qpEnum(req, "propertyType", UNIT_TYPES);
    if (propertyType) conditions.push({ propertyType });
    // Phase C Wave 3A — the attention facets join the export contract (the
    // "export what you see" law: the isolated view and its CSV export must
    // carry the SAME predicate set; qpDate validates garbage → 422).
    if (params.get("uncontacted") === "1" || params.get("uncontacted") === "true") {
      conditions.push({ lastContactAt: null });
    }
    // LM (D-LD-11) — the P3 customer-book facets join the export contract:
    // `idle=1` (last contact > 14 days, never-contacted NOT idle — the same
    // law as the list route) and `unassigned=1` (the manager's intake pool,
    // same 403 gate). The exported CSV is now byte-honest with the isolated
    // view that produced it.
    if (params.get("idle") === "1" || params.get("idle") === "true") {
      conditions.push({ lastContactAt: { lt: new Date(Date.now() - IDLE_DAYS * 24 * 3600 * 1000) } });
    }
    if (params.get("unassigned") === "1" || params.get("unassigned") === "true") {
      if (!seesAllRecords(user)) {
        throw new ApiError(
          403,
          "Le filtre « non assignés » est réservé à la direction",
          "FORBIDDEN_ROLE",
        );
      }
      conditions.push({ ownerId: null });
    }
    const createdAfter = qpDate(req, "createdAfter");
    if (createdAfter) {
      conditions.push({ createdAt: { gte: createdAfter } });
    }
    const archivedParam = params.get("archived");
    if (archivedParam === "true" || archivedParam === "1") conditions.push({ archived: true });
    else if (archivedParam !== "all") conditions.push({ archived: false });

    const where: Prisma.LeadWhereInput = conditions.length > 1 ? { AND: conditions } : conditions[0];

    const leads = await db.lead.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 5000, // bounded export; pagination covers larger datasets
      include: {
        owner: { select: { name: true } },
        tags: { include: { tag: { select: { name: true } } } },
      },
    });

    const rows: (string | number | null | undefined)[][] = leads.map((l) => [
      l.id,
      csvEscape(l.fullName),
      l.phone,
      csvEscape(displayPhone(l.phone)),
      csvEscape(l.email),
      l.source,
      csvEscape(l.campaign),
      l.status,
      l.priority,
      l.score,
      l.budgetMin ?? "",
      l.budgetMax ?? "",
      l.propertyType ?? "",
      csvEscape(l.desiredLocation),
      csvEscape(l.owner?.name ?? ""),
      csvEscape(l.tags.map((t) => t.tag.name).join(", ")),
      l.createdAt.toISOString(),
      l.lastContactAt?.toISOString() ?? "",
      l.nextFollowUpAt?.toISOString() ?? "",
      csvEscape(l.lostReason),
    ]);
    const csv = csvDocument(HEADERS, rows); // BOM + CRLF for Excel FR

    await logAudit({
      orgId,
      actor: user,
      action: "LEADS_EXPORTED",
      entity: "LEAD",
      after: { count: leads.length, filters: Object.fromEntries(params.entries()) },
    });

    const stamp = new Date().toISOString().slice(0, 10);
    return new NextResponse(csv, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="asas-prospects-${stamp}.csv"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    if (error instanceof ApiError && error.status === 403) {
      return NextResponse.json(
        { error: "L'export de prospects requiert le rôle Manager ou supérieur.", code: "EXPORT_FORBIDDEN" },
        { status: 403 },
      );
    }
    return fail(error);
  }
}
