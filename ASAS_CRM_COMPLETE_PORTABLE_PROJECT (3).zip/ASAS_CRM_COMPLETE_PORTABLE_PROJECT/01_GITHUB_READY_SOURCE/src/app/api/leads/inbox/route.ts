// GET /api/leads/inbox — the Phase 11 INTAKE WORKSPACE read (inbox.view).
//
// One endpoint, two role shapes, ONE status vocabulary (the A2 discovery law:
// reuse the existing lifecycle — no new statuses, no duplicate states):
//   MANAGER+  → the whole org's intake console (the §A3 lead inbox).
//   SALES_AGENT → the personal slice (leadScope = own + the shared pool —
//               "my new leads, my uncontacted, my day"), same facets.
//   FIELD_REP → no inbox.view permission → 403 by the catalog gate.
//
// Facets (queue param): new · unassigned · awaiting_contact · overdue_contact
// (contact SLA law, LEAD_CONTACT_SLA_HOURS) · overdue_followups · qualified
// · converted · lost · reactivated. Counts ship for every facet in one
// payload.
//
// T43/T44 (W3-c) — scale integrity: the former ONE lean findMany (take 500,
// createdAt desc) + in-memory aggregation capped every count at 500 and let
// SLA-overdue records beyond the slice VANISH. Now:
//   · COUNTS — one DB count per queue over the SAME scope the rows use
//     (exact, never capped; the predicates are the in-memory filters lifted
//     verbatim into Prisma where-clauses, archived:false included).
//   · ROWS — the 500-row display slice stays (acceptable UX), but it is
//     queue-scoped at the DB and ordered per queue: overdue_contact oldest
//     first (the most overdue at the head — the former newest-first order
//     hid exactly the records the queue exists to surface), overdue_followups
//     by nextFollowUpAt ascending, the others newest-first. `total` stays
//     the pagination total over that slice (the frontend pages the fetched
//     window; the chips' counts are the truthful queue sizes).
import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { LEAD_CONTACT_SLA_HOURS } from "@/lib/constants";
import { db } from "@/lib/db";
import { ApiError, fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { qp } from "@/lib/server/validation";
import { leadScope } from "@/lib/server/visibility";

const QUEUES = [
  "new",
  "unassigned",
  "awaiting_contact",
  "overdue_contact",
  "overdue_followups",
  "qualified",
  "converted",
  "lost",
  "reactivated",
] as const;
type Queue = (typeof QUEUES)[number];

const ACTIVE_STATUSES = ["NEW", "CONTACTED", "QUALIFIED", "REACTIVATED"] as const;

const ROW_SELECT = {
  id: true,
  fullName: true,
  fullNameAr: true,
  phone: true,
  phoneRaw: true,
  whatsapp: true,
  source: true,
  campaignId: true,
  campaignRef: { select: { code: true, name: true } },
  status: true,
  priority: true,
  score: true,
  budgetMin: true,
  budgetMax: true,
  propertyType: true,
  ownerId: true,
  owner: { select: { id: true, name: true } },
  createdAt: true,
  lastContactAt: true,
  nextFollowUpAt: true,
  archived: true,
} as const;

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const queue = (qp(req, "queue") ?? "new") as Queue;
    if (!QUEUES.includes(queue)) {
      throw new ApiError(422, `File d'attente inconnue (queue: ${queue})`, "VALIDATION_ERROR");
    }
    const page = parseIntParam(req.nextUrl.searchParams.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(req.nextUrl.searchParams.get("pageSize"), 50, { min: 1, max: 100 });

    // D-021 scope — SALES_AGENT reads own+pool; MANAGER+ the org (leadScope).
    // Unchanged (byte-identical in intent): every count AND the rows spread
    // the same fragment — the scoping never diverges between the two reads.
    const scope = { orgId, ...leadScope(user) };
    const now = new Date();
    const slaCutoff = new Date(now.getTime() - LEAD_CONTACT_SLA_HOURS * 3_600_000);

    // T43 — the queue predicates, lifted verbatim from the former in-memory
    // filters (archived:false = the former `active` pre-filter). ONE
    // definition serves both the counts and the rows, so the two can never
    // disagree about what a queue contains.
    const queueWhere = (q: Queue): Prisma.LeadWhereInput => {
      switch (q) {
        case "new":
          return { status: "NEW" };
        case "unassigned":
          return { ownerId: null, status: { in: [...ACTIVE_STATUSES] } };
        case "awaiting_contact":
          return { status: "NEW", ownerId: { not: null }, lastContactAt: null };
        case "overdue_contact":
          return { status: "NEW", lastContactAt: null, createdAt: { lt: slaCutoff } };
        case "overdue_followups":
          return { status: { in: [...ACTIVE_STATUSES] }, nextFollowUpAt: { not: null, lt: now } };
        case "qualified":
          return { status: "QUALIFIED" };
        case "converted":
          return { status: "CONVERTED" };
        case "lost":
          return { status: "CLOSED_LOST" };
        case "reactivated":
          return { status: "REACTIVATED" };
      }
    };

    // T43 — per-queue DB counts: exact queue sizes over the SAME scoping the
    // rows use (the former in-memory aggregation capped at the 500-row
    // slice — an org with 800 SLA-overdue intakes showed "500" on the chip
    // and the oldest records past the slice never surfaced at all).
    const [
      cntNew,
      cntUnassigned,
      cntAwaitingContact,
      cntOverdueContact,
      cntOverdueFollowups,
      cntQualified,
      cntConverted,
      cntLost,
      cntReactivated,
    ] = await Promise.all(
      QUEUES.map((q) => db.lead.count({ where: { ...scope, archived: false, ...queueWhere(q) } })),
    );
    const counts = {
      new: cntNew,
      unassigned: cntUnassigned,
      awaiting_contact: cntAwaitingContact,
      overdue_contact: cntOverdueContact,
      overdue_followups: cntOverdueFollowups,
      qualified: cntQualified,
      converted: cntConverted,
      lost: cntLost,
      reactivated: cntReactivated,
    };

    // T44 — per-queue row ordering: overdue_contact ASC by createdAt (oldest
    // first = most overdue), overdue_followups ASC by nextFollowUpAt (the
    // soonest-broken promise first), the rest newest-first (the historical
    // default).
    const rowsOrderBy: Prisma.LeadOrderByWithRelationInput[] =
      queue === "overdue_contact"
        ? [{ createdAt: "asc" }]
        : queue === "overdue_followups"
          ? [{ nextFollowUpAt: "asc" }]
          : [{ createdAt: "desc" }];

    // T44 — the 500-row display slice, now queue-scoped at the DB (the
    // former unscoped newest-500 could hold zero rows of the requested
    // queue) and ordered per queue — the slice IS the queue's most-relevant
    // 500, not an arbitrary window. Intake-sized select, no relations
    // beyond the owner/campaign stamps the row renders.
    const rows = await db.lead.findMany({
      where: { ...scope, archived: false, ...queueWhere(queue) },
      select: ROW_SELECT,
      orderBy: rowsOrderBy,
      take: 500,
    });

    const total = rows.length;
    const start = (page - 1) * pageSize;
    const pageRows = rows.slice(start, start + pageSize).map((r) => ({
      id: r.id,
      fullName: r.fullName,
      fullNameAr: r.fullNameAr,
      phone: r.phone,
      phoneRaw: r.phoneRaw,
      whatsapp: r.whatsapp,
      source: r.source,
      campaignId: r.campaignId,
      campaignCode: r.campaignRef?.code ?? null,
      campaignName: r.campaignRef?.name ?? null,
      status: r.status,
      priority: r.priority,
      score: r.score,
      budgetMin: r.budgetMin,
      budgetMax: r.budgetMax,
      propertyType: r.propertyType,
      ownerId: r.ownerId,
      ownerName: r.owner?.name ?? null,
      createdAt: r.createdAt.toISOString(),
      lastContactAt: r.lastContactAt?.toISOString() ?? null,
      nextFollowUpAt: r.nextFollowUpAt?.toISOString() ?? null,
    }));

    return ok({
      queue,
      counts,
      total,
      page,
      pageSize,
      contactSlaHours: LEAD_CONTACT_SLA_HOURS,
      rows: pageRows,
    });
  } catch (error) {
    return fail(error);
  }
}
