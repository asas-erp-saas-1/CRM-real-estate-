// GET /api/leads/workload — the distribution read (leads.routing, MANAGER+):
//      every eligible rep's workload (active assigned / uncontacted / overdue
//      for contact / overdue follow-ups / converted) in the stable
//      deterministic order. This is the manager's "who is drowning, who is
//      idle" surface — the workload routing policy's own input, exposed.
import type { NextRequest } from "next/server";
import { eligibleAssignees } from "@/lib/server/routing";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("leads.routing");
    const assignees = await eligibleAssignees(user.orgId);
    return ok({ data: assignees });
  } catch (error) {
    return fail(error);
  }
}
