// GET /api/leads/check-duplicates?phone=&email= — pre-insert duplicate lookup.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { normalizePhone } from "@/lib/phone";
import { leadInclude, toLeadDTO } from "@/lib/server/leads";
import { fail, ok, requireUser } from "@/lib/server/session";
import { leadScope } from "@/lib/server/visibility";
import { qp } from "@/lib/server/validation";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;

    const phoneParam = qp(req, "phone");
    const emailParam = qp(req, "email")?.toLowerCase() ?? null;

    const conditions: { phone?: string; email?: { contains: string } }[] = [];
    if (phoneParam) {
      const normalized = normalizePhone(phoneParam);
      if (normalized) conditions.push({ phone: normalized });
    }
    if (emailParam) conditions.push({ email: { contains: emailParam } });

    if (conditions.length === 0) return ok({ duplicates: [] });

    // D-021 — duplicates resolve inside the caller's visibility scope: a
    // foreign duplicate is signaled existence-only (no row, no name/owner).
    const dupWhere = { orgId, OR: conditions };
    const scope = leadScope(user);
    const duplicates = await db.lead.findMany({
      where: scope ? { AND: [dupWhere, scope] } : dupWhere,
      take: 10,
      include: leadInclude,
    });
    if (duplicates.length === 0 && scope) {
      const foreignCount = await db.lead.count({ where: dupWhere });
      if (foreignCount > 0) {
        return ok({ duplicates: [], foreignBlocked: true });
      }
    }

    return ok({ duplicates: duplicates.map(toLeadDTO) });
  } catch (error) {
    return fail(error);
  }
}
