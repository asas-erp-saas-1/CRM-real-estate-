// GET /api/leads/routing — the routing console read (leads.routing, MANAGER+):
//      the persisted policy + the DRY-RUN decision (which rep would receive
//      the next routed lead, and WHY) + every eligible rep's workload. This
//      is the explainability surface: a manager sees the engine's next move
//      before any lead is routed.
// PUT /api/leads/routing — persist the policy (leads.routing, MANAGER+,
//      audited). policy: MANUAL | ROUND_ROBIN | WORKLOAD; autoAssign toggles
//      the capture/creation hook.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { decideAssignee, getRoutingConfig, routingConfigSchema, saveRoutingConfig } from "@/lib/server/routing";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("leads.routing");
    const [config, decision] = await Promise.all([getRoutingConfig(user.orgId), decideAssignee(user.orgId)]);
    return ok({
      config,
      next: { userId: decision.userId, reason: decision.reason, policy: decision.policy },
      assignees: decision.assignees,
    });
  } catch (error) {
    return fail(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await requirePermission("leads.routing");
    const body = await parseBody(req, routingConfigSchema);
    const before = await getRoutingConfig(user.orgId);

    await db.$transaction(async (tx) => {
      await saveRoutingConfig(user.orgId, body, tx);
      await logAudit(
        {
          orgId: user.orgId,
          actor: user,
          action: "ROUTING_POLICY_UPDATED",
          entity: "ORG_SETTING",
          entityId: "leads.routing",
          before: { policy: before.policy, autoAssign: before.autoAssign },
          after: { policy: body.policy, autoAssign: body.autoAssign },
        },
        tx,
      );
    });
    return ok({ config: body });
  } catch (error) {
    return fail(error);
  }
}
