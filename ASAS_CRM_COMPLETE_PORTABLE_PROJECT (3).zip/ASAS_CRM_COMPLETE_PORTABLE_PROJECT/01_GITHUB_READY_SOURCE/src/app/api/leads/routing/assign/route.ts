// POST /api/leads/routing/assign — the inbox's explicit assignment action
// (leads.assign, MANAGER+): leadIds[] + ownerId + optional reason. Writes the
// FULL trail through the routing engine's shared law (reassignLeadCascade +
// per-lead ASSIGNMENT Activity with {before, after, method, reason} + the
// LEAD_ASSIGNED audit row) — one transaction, all-or-nothing.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { assignLeadsInTx } from "@/lib/server/routing";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

const assignSchema = z.object({
  leadIds: z.array(z.string().min(1)).min(1).max(200),
  ownerId: z.string().min(1),
  reason: z.string().trim().max(500).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("leads.assign");
    const body = await parseBody(req, assignSchema);
    const orgId = user.orgId;

    // Forge guard: every lead must belong to the caller's org (mass
    // assignment across tenants is the A6 security matrix's #4 case).
    const owned = await db.lead.findMany({
      where: { id: { in: body.leadIds }, orgId },
      select: { id: true },
    });
    if (owned.length !== body.leadIds.length) {
      throw new ApiError(404, "Prospect hors périmètre (leadIds invalides)", "LEAD_NOT_FOUND");
    }
    const owner = await db.user.findFirst({ where: { id: body.ownerId, orgId, active: true } });
    if (!owner) {
      throw new ApiError(422, "Représentant introuvable ou inactif", "OWNER_NOT_FOUND");
    }

    const result = await db.$transaction((tx) =>
      assignLeadsInTx(tx, orgId, user, body.leadIds, body.ownerId, "MANUAL", body.reason ?? ""),
    );
    return ok({ data: result });
  } catch (error) {
    return fail(error);
  }
}
