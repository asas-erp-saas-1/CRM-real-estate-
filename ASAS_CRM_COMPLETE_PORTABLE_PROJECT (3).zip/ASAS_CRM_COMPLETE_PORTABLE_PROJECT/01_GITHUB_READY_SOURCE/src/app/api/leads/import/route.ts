// POST /api/leads/import — CSV import for leads (master prompt §23):
//   { action: "preview", csv, mapping? }  → parsed + validated rows w/ duplicate detection
//   { action: "commit",  csv, mapping, defaultOwnerId?, defaultSource?, fileName? }
// MANAGER+ only (mirrors export). Duplicates are ALWAYS skipped on commit:
// the phone is the unique person key (hard @@unique([orgId, phone]) backstop).
// R8-3: the LEADS_IMPORTED audit stores created lead ids in after.leadIds
// (source of truth for POST /api/leads/import/undo) and the commit response
// returns auditId so the success step can offer a one-click undo.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { SOURCES } from "@/lib/constants";
import { db } from "@/lib/db";
import { normalizePhone } from "@/lib/phone";
import { logActivity, logAudit } from "@/lib/server/audit";
import {
  IMPORT_FIELDS,
  IMPORT_MAX_CSV_BYTES,
  IMPORT_MAX_ROWS,
  autoMapHeaders,
  coercePriority,
  coercePropertyType,
  coerceSource,
  looksLikeEmail,
  parseBudget,
  parseCsv,
  type ImportField,
} from "@/lib/server/csv";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

const PREVIEW_ROW_CAP = 200; // rows returned to the client (validation still covers all)
const DB_CHUNK = 300;

// P4-8 (F-14): import counterpart of the export defang. The export route
// (leads/export/route.ts) prefixes formula-shaped cells with a `'` text
// marker; the same sigil set is mirrored here so ONE marker can be stripped
// and an exported file re-imports to its original values instead of
// accumulating apostrophes on every round-trip. Foreign cells that start
// with a RAW sigil (= + - @ …) are stored as data and never executed — the
// export boundary is where formula execution is neutralized.
const FORMULA_SIGIL = /^[=+\-@\t\r]/;

/** Strip one export defang marker: `'=SUM(1+1)` → `=SUM(1+1)`. */
function stripDefangMarker(cell: string): string {
  if (cell.length > 1 && cell[0] === "'" && FORMULA_SIGIL.test(cell.slice(1).trim())) {
    return cell.slice(1);
  }
  return cell;
}

const importSchema = z.object({
  action: z.enum(["preview", "commit"]),
  csv: z.string().min(1, "CSV vide").max(IMPORT_MAX_CSV_BYTES, "Fichier trop volumineux"),
  mapping: z.record(z.string(), z.enum(IMPORT_FIELDS)).optional(),
  defaultOwnerId: z.string().trim().optional().nullable(),
  defaultSource: z.enum(SOURCES).optional(),
  fileName: z.string().trim().max(200).optional(),
});

type RowIssue =
  | "MISSING_NAME" | "INVALID_PHONE" | "INVALID_EMAIL" | "INVALID_SOURCE"
  | "INVALID_PRIORITY" | "INVALID_BUDGET" | "BUDGET_RANGE" | "IN_FILE_DUPLICATE";

interface ValidatedRow {
  index: number; // data row number (1 = first row after header)
  values: Partial<Record<ImportField, string>>;
  status: "valid" | "duplicate" | "error";
  issues: RowIssue[];
  duplicateOf?: { id: string; fullName: string; phone: string };
}

interface ParsedLead {
  fullName: string | null;
  phone: string | null;
  phoneRaw: string | null;
  secondaryPhone: string | null;
  whatsapp: string | null;
  email: string | null;
  source: string | null;
  campaign: string | null;
  priority: string | null;
  budgetMin: number | null;
  budgetMax: number | null;
  propertyType: string | null;
  desiredLocation: string | null;
  notes: string | null;
}

/** Parse + validate every data row against the mapping. Pure (no DB). */
function validateRows(
  matrix: string[][],
  mapping: Record<number, ImportField>,
): (ValidatedRow & { parsed?: ParsedLead })[] {
  const rows: (ValidatedRow & { parsed?: ParsedLead })[] = [];
  const seenPhones = new Map<string, number>(); // phone → first data row number

  for (let r = 1; r < matrix.length; r++) {
    const raw = matrix[r];
    const issues: RowIssue[] = [];
    const lead: ParsedLead = {
      fullName: null, phone: null, phoneRaw: null, secondaryPhone: null, whatsapp: null,
      email: null, source: null, campaign: null, priority: null,
      budgetMin: null, budgetMax: null, propertyType: null, desiredLocation: null, notes: null,
    };
    const values: Partial<Record<ImportField, string>> = {};

    for (const [colStr, field] of Object.entries(mapping)) {
      // P4-8 (F-14): normalize the export defang marker before validation so
      // preview/commit/duplicate detection all see the restored value.
      const cell = stripDefangMarker((raw[Number(colStr)] ?? "").trim());
      if (!cell) continue;
      values[field] = cell;

      switch (field) {
        case "fullName":
          if (cell.length > 160) issues.push("MISSING_NAME");
          else lead.fullName = cell;
          break;
        case "phone": {
          lead.phoneRaw = cell;
          const normalized = normalizePhone(cell);
          if (!normalized) issues.push("INVALID_PHONE");
          else lead.phone = normalized;
          break;
        }
        case "secondaryPhone":
          lead.secondaryPhone = normalizePhone(cell) ?? cell;
          break;
        case "whatsapp":
          lead.whatsapp = normalizePhone(cell);
          break;
        case "email":
          if (!looksLikeEmail(cell)) issues.push("INVALID_EMAIL");
          else lead.email = cell.toLowerCase();
          break;
        case "source":
          lead.source = coerceSource(cell);
          if (!lead.source) issues.push("INVALID_SOURCE");
          break;
        case "campaign":
          lead.campaign = cell.slice(0, 120);
          break;
        case "priority":
          lead.priority = coercePriority(cell);
          if (!lead.priority) issues.push("INVALID_PRIORITY");
          break;
        case "budgetMin": {
          const v = parseBudget(cell);
          if (v === null) issues.push("INVALID_BUDGET");
          else lead.budgetMin = v;
          break;
        }
        case "budgetMax": {
          const v = parseBudget(cell);
          if (v === null) issues.push("INVALID_BUDGET");
          else lead.budgetMax = v;
          break;
        }
        case "propertyType":
          // lenient: unmappable typology just drops the value (no error)
          lead.propertyType = coercePropertyType(cell);
          break;
        case "desiredLocation":
          lead.desiredLocation = cell.slice(0, 120);
          break;
        case "notes":
          lead.notes = cell.slice(0, 5000);
          break;
      }
    }

    // Blank rows (all mapped cells empty) are skipped silently.
    if (Object.keys(values).length === 0) continue;

    if (!lead.fullName) issues.push("MISSING_NAME");
    if (!lead.phone) issues.push("INVALID_PHONE");
    if (lead.budgetMin !== null && lead.budgetMax !== null && lead.budgetMin > lead.budgetMax) {
      issues.push("BUDGET_RANGE");
    }

    const row: ValidatedRow & { parsed?: ParsedLead } = {
      index: r,
      values,
      status: "error",
      issues: [...new Set(issues)],
    };
    // provisional status — the DB duplicate pass below may downgrade to "duplicate"
    if (row.issues.length === 0) row.status = "valid";

    if (lead.phone && row.issues.length === 0) {
      if (seenPhones.has(lead.phone)) {
        // earlier row wins — this one is an in-file duplicate
        row.status = "duplicate";
        row.issues.push("IN_FILE_DUPLICATE");
      } else {
        seenPhones.set(lead.phone, r);
      }
    }
    row.parsed = lead;
    rows.push(row);
  }
  return rows;
}

/** Attach DB duplicates (same org + phone) and compute final statuses. */
async function detectDbDuplicates(
  orgId: string,
  rows: (ValidatedRow & { parsed?: ParsedLead })[],
): Promise<void> {
  const phones = [
    ...new Set(
      rows
        .filter((r) => r.parsed?.phone && r.status !== "error" && !r.issues.includes("IN_FILE_DUPLICATE"))
        .map((r) => r.parsed!.phone!),
    ),
  ];
  const existing = new Map<string, { id: string; fullName: string; phone: string }>();
  for (let i = 0; i < phones.length; i += DB_CHUNK) {
    const chunk = phones.slice(i, i + DB_CHUNK);
    const found = await db.lead.findMany({
      where: { orgId, phone: { in: chunk } },
      select: { id: true, fullName: true, phone: true },
    });
    for (const f of found) existing.set(f.phone, f);
  }
  for (const row of rows) {
    if (row.status === "error") continue;
    const phone = row.parsed?.phone;
    if (!phone) continue;
    const dup = existing.get(phone);
    if (dup) {
      row.status = "duplicate";
      if (!row.issues.includes("IN_FILE_DUPLICATE")) {
        row.duplicateOf = { id: dup.id, fullName: dup.fullName, phone: dup.phone };
      }
    } else if (row.issues.length === 0) {
      row.status = "valid";
    }
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("leads.import");
    const orgId = user.orgId;
    const body = await parseBody(req, importSchema);

    // 1) Parse the CSV matrix (header row + data rows).
    const matrix = parseCsv(body.csv);
    if (matrix.length < 2) {
      throw new ApiError(422, "CSV vide ou sans lignes de données", "EMPTY_CSV");
    }
    if (matrix.length - 1 > IMPORT_MAX_ROWS) {
      throw new ApiError(422, `Trop de lignes (${matrix.length - 1} > ${IMPORT_MAX_ROWS})`, "TOO_MANY_ROWS");
    }

    // 2) Resolve the effective column mapping (client mapping wins over auto).
    const headers = matrix[0];
    const autoMapping = autoMapHeaders(headers);
    const clientMapping: Record<number, ImportField> = {};
    if (body.mapping) {
      for (const [col, field] of Object.entries(body.mapping)) {
        const idx = Number(col);
        if (Number.isInteger(idx) && idx >= 0 && idx < headers.length) clientMapping[idx] = field;
      }
    }
    const effective: Record<number, ImportField> = { ...autoMapping, ...clientMapping };
    const hasName = Object.values(effective).includes("fullName");
    const hasPhone = Object.values(effective).includes("phone");
    if (!hasName || !hasPhone) {
      throw new ApiError(422, "Les colonnes Nom et Téléphone doivent être mappées", "MAPPING_INCOMPLETE", {
        mapping: effective,
        missing: [!hasName ? "fullName" : null, !hasPhone ? "phone" : null].filter(Boolean),
      });
    }

    // 3) Validate + duplicate-detect.
    const rows = validateRows(matrix, effective);
    await detectDbDuplicates(orgId, rows);

    const summary = {
      valid: rows.filter((r) => r.status === "valid").length,
      duplicates: rows.filter((r) => r.status === "duplicate").length,
      errors: rows.filter((r) => r.status === "error").length,
    };

    if (body.action === "preview") {
      const mappingOut: Record<string, ImportField> = {};
      for (const [k, v] of Object.entries(effective)) mappingOut[k] = v;
      return ok({
        headers,
        mapping: mappingOut,
        autoMapping,
        rowCount: matrix.length - 1,
        summary,
        rows: rows.slice(0, PREVIEW_ROW_CAP).map(({ parsed: _parsed, ...r }) => r),
      });
    }

    // 4) COMMIT — insert every valid row inside ONE transaction (rollback on
    //    unexpected failure; duplicates are skipped by design).
    if (summary.valid === 0) {
      throw new ApiError(422, "Aucune ligne valide à importer", "NOTHING_TO_IMPORT", { summary });
    }

    let defaultOwnerId: string | null = null;
    if (body.defaultOwnerId) {
      const owner = await db.user.findFirst({
        where: { id: body.defaultOwnerId, orgId, active: true },
        select: { id: true },
      });
      if (!owner) throw new ApiError(422, "Propriétaire par défaut introuvable", "OWNER_NOT_FOUND");
      defaultOwnerId = owner.id;
    }
    const defaultSource = body.defaultSource ?? "OTHER";

    const toInsert = rows.filter((r) => r.status === "valid" && r.parsed);

    const created = await db.$transaction(async (tx) => {
      const out: { id: string; fullName: string; phone: string }[] = [];
      for (const row of toInsert) {
        const p = row.parsed!;
        const lead = await tx.lead.create({
          data: {
            orgId,
            fullName: p.fullName!,
            phone: p.phone!,
            phoneRaw: p.phoneRaw,
            secondaryPhone: p.secondaryPhone,
            whatsapp: p.whatsapp ?? p.phone,
            email: p.email,
            source: p.source ?? defaultSource,
            campaign: p.campaign,
            priority: p.priority ?? "NORMAL",
            ownerId: defaultOwnerId,
            budgetMin: p.budgetMin,
            budgetMax: p.budgetMax,
            propertyType: p.propertyType,
            desiredLocation: p.desiredLocation,
            notes: p.notes,
          },
          select: { id: true, fullName: true, phone: true },
        });
        out.push(lead);
      }
      return out;
    });

    // Timeline + audit AFTER the transaction commits — the documented F-06
    // trade-off for this route (deliberate, kept as-is): folding the trail
    // into the import tx (up to IMPORT_MAX_ROWS=2000 creates) would hold it
    // open across thousands of extra activity inserts, and the R8-3 undo
    // contract needs the audit row to describe only a commit that HAPPENED
    // (an orphaned audit row with leadIds pointing at rolled-back leads
    // would poison the undo). Accepted risk, the mirror image: a crash
    // between commit and trail leaves the imported leads without their
    // LEAD_CREATED timeline rows (recoverable — the leads exist and the
    // audit row remains the source of truth for undo).
    await Promise.all(
      created.map((lead) =>
        logActivity({
          orgId,
          actorId: user.id,
          leadId: lead.id,
          type: "LEAD_CREATED",
          title: `Lead importé — ${lead.fullName}`,
          meta: { imported: true, fileName: body.fileName ?? null },
        }),
      ),
    );
    const audit = await logAudit({
      orgId,
      actor: user,
      action: "LEADS_IMPORTED",
      entity: "LEAD",
      entityId: null,
      after: {
        fileName: body.fileName ?? null,
        created: created.length,
        skippedDuplicates: summary.duplicates,
        skippedErrors: summary.errors,
        defaultOwnerId,
        leadIds: created.map((l) => l.id), // R8-3 — undo source of truth
      },
    });

    return ok({
      created: created.length,
      skippedDuplicates: summary.duplicates,
      skippedErrors: summary.errors,
      ids: created.map((l) => l.id),
      auditId: audit.id, // R8-3 — feeds the "undo this import" action
    });
  } catch (error) {
    return fail(error);
  }
}
