// POST /api/leads/import/undo — one-click reversal of a CSV import batch
// (worklog R7 recommendation #3 / R8-3). MANAGER+ only.
//   Body: { auditId } — the LEADS_IMPORTED audit entry id.
// Soft-delete ONLY: safe leads are archived (archived: true), never hard-deleted.
// A lead is "safe" when it is NOT archived, still in a pre-progress state
// (NEW | CONTACTED) and has no opportunities / visits / tasks (a reservation
// always implies an opportunity, so the opportunity count covers it).
// Leads that progressed are SKIPPED and reported by name.
// Idempotence guard: a matching LEADS_IMPORT_UNDONE audit (sourceAuditId)
// already existing → 409 ALREADY_UNDONE. The original audit row is never mutated.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

/** Statuses a lead may still be in for the import to be reversible. */
const UNDO_SAFE_STATUSES = new Set(["NEW", "CONTACTED"]);
/** Max LEADS_IMPORT_UNDONE rows scanned for the ALREADY_UNDONE guard. */
const UNDONE_SCAN_CAP = 500;

const undoSchema = z.object({
  auditId: z.string().trim().min(1, "auditId requis"),
});

/** Parse the sourceAuditId out of a LEADS_IMPORT_UNDONE after-JSON (or null). */
function sourceAuditOf(afterJson: string | null): string | null {
  if (!afterJson) return null;
  try {
    const parsed = JSON.parse(afterJson) as { sourceAuditId?: unknown };
    return typeof parsed.sourceAuditId === "string" ? parsed.sourceAuditId : null;
  } catch {
    return null;
  }
}

/**
 * Defensively extract the created lead ids from a LEADS_IMPORTED audit entry.
 * Real shape (R8-3): after.leadIds = string[]. Tolerated legacy variants:
 * after.ids = string[], after.leadIds = { ids: string[] }.
 * Returns null when nothing usable is stored (pre-R8-3 imports).
 */
function extractLeadIds(afterJson: string | null): string[] | null {
  if (!afterJson) return null;
  let after: Record<string, unknown>;
  try {
    after = JSON.parse(afterJson) as Record<string, unknown>;
  } catch {
    return null;
  }
  const asIdList = (value: unknown): string[] | null => {
    if (!Array.isArray(value)) return null;
    const ids = value.filter((v): v is string => typeof v === "string" && v.length > 0);
    return ids.length > 0 ? ids : null;
  };
  const candidates = [after.leadIds, after.ids];
  for (const candidate of candidates) {
    // direct array of ids…
    const direct = asIdList(candidate);
    if (direct) return direct;
    // …or a nested { ids: [...] } envelope
    if (candidate && typeof candidate === "object" && !Array.isArray(candidate)) {
      const nested = asIdList((candidate as Record<string, unknown>).ids);
      if (nested) return nested;
    }
  }
  return null;
}

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("leads.import");
    const orgId = user.orgId;
    const body = await parseBody(req, undoSchema);

    // 1) Load the import audit entry (org-scoped).
    const audit = await db.auditLog.findFirst({
      where: { id: body.auditId, orgId },
      select: { id: true, action: true, after: true },
    });
    if (!audit) {
      throw new ApiError(404, "Entrée d'audit introuvable", "AUDIT_NOT_FOUND");
    }
    if (audit.action !== "LEADS_IMPORTED") {
      throw new ApiError(400, "Cette entrée d'audit ne correspond pas à un import de prospects", "NOT_AN_IMPORT");
    }

    // 2) Idempotence: a LEADS_IMPORT_UNDONE row already points at this import.
    const undoneRows = await db.auditLog.findMany({
      where: { orgId, action: "LEADS_IMPORT_UNDONE" },
      select: { after: true },
      take: UNDONE_SCAN_CAP,
      orderBy: { createdAt: "desc" },
    });
    if (undoneRows.some((row) => sourceAuditOf(row.after) === audit.id)) {
      throw new ApiError(409, "Cet import a déjà été annulé", "ALREADY_UNDONE");
    }

    // 3) Extract the created lead ids (defensive — pre-R8-3 imports lack them).
    const leadIds = extractLeadIds(audit.after);
    if (!leadIds) {
      throw new ApiError(
        409,
        "Cet import ne peut plus être annulé : la liste des prospects créés n'a pas été conservée",
        "UNDO_UNAVAILABLE",
      );
    }

    // 4) Classify: safe to archive vs progressed (skip). Leads that no longer
    //    exist (hard-deleted meanwhile) are simply absent from both lists.
    const leads = await db.lead.findMany({
      where: { orgId, id: { in: leadIds } },
      select: {
        id: true,
        fullName: true,
        status: true,
        archived: true,
        _count: { select: { opportunities: true, visits: true, tasks: true } },
      },
    });
    const undoneIds: string[] = [];
    const skippedIds: string[] = [];
    const skippedNames: string[] = [];
    for (const lead of leads) {
      const progressed =
        lead.archived ||
        !UNDO_SAFE_STATUSES.has(lead.status) ||
        lead._count.opportunities > 0 ||
        lead._count.visits > 0 ||
        lead._count.tasks > 0;
      if (progressed) {
        skippedIds.push(lead.id);
        skippedNames.push(lead.fullName);
      } else {
        undoneIds.push(lead.id);
      }
    }

    // 5) Archive the safe batch — one org-scoped updateMany, never a hard delete.
    if (undoneIds.length > 0) {
      await db.lead.updateMany({
        where: { orgId, id: { in: undoneIds }, archived: false },
        data: { archived: true },
      });
    }

    // 6) Audit the reversal (append-only — the original LEADS_IMPORTED row stays).
    await logAudit({
      orgId,
      actor: user,
      action: "LEADS_IMPORT_UNDONE",
      entity: "LEAD",
      entityId: null,
      after: {
        undone: undoneIds.length,
        skipped: skippedIds.length,
        sourceAuditId: audit.id,
        undoneIds,
        skippedIds,
      },
    });

    return ok({
      undone: undoneIds.length,
      skipped: skippedIds.length,
      skippedNames: skippedNames.slice(0, 5),
    });
  } catch (error) {
    return fail(error);
  }
}
