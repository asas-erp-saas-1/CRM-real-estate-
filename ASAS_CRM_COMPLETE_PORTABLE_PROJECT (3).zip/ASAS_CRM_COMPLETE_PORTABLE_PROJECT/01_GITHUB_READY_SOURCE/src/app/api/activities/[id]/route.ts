// DELETE /api/activities/:id — remove a NOTE-type timeline entry (P4-7, UX B3).
//        System-generated activities (VISIT, STATUS_CHANGE, LEAD_CREATED, …) are
//        immutable by design: only type === "NOTE" can be deleted, and only by
//        the note's author (actorId) or MANAGER+. Deletion is audit-logged with
//        a before snapshot (same invariants as tasks/[id] DELETE).
import type { NextRequest } from "next/server";
import { atLeastRole } from "@/lib/constants";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { activityScope } from "@/lib/server/visibility";

type Ctx = { params: Promise<{ id: string }> };

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    // D-021 — scoped findFirst: a foreign-linked activity is 404 (no existence
    // leak through the note-deletion surface). The author-or-MANAGER layer below
    // still governs in-scope rows.
    const activity = await db.activity.findFirst({ where: { id, orgId, ...activityScope(user) } });
    if (!activity) throw new ApiError(404, "Activité introuvable", "ACTIVITY_NOT_FOUND");

    // System-generated timeline entries stay immutable — user notes only (B3).
    if (activity.type !== "NOTE") {
      throw new ApiError(422, "Seules les notes peuvent être supprimées", "ACTIVITY_IMMUTABLE", {
        type: activity.type,
      });
    }

    // RBAC — server-enforced: the note's author or MANAGER+ (UI hiding ≠ authorization).
    if (activity.actorId !== user.id && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(
        403,
        "Seul l'auteur de la note ou un manager peut la supprimer",
        "FORBIDDEN_ROLE"
      );
    }

    await db.activity.delete({ where: { id: activity.id } });

    await logAudit({
      orgId,
      actor: user,
      action: "ACTIVITY_DELETED",
      entity: "ACTIVITY",
      entityId: activity.id,
      before: {
        type: activity.type,
        title: activity.title,
        body: activity.body,
        leadId: activity.leadId,
        actorId: activity.actorId,
        occurredAt: activity.occurredAt,
      },
      after: null,
    });

    return ok({ deleted: true, id: activity.id });
  } catch (error) {
    return fail(error);
  }
}
