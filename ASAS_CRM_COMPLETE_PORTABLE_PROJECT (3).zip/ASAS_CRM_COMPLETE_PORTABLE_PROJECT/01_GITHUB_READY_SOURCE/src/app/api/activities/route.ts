// GET /api/activities — unified timeline feed (master prompt §12): org-wide
// when org=true (or no specific filter), or scoped to leadId/opportunityId.
// Ordered occurredAt desc, actor + lead included.
import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { ACTIVITY_TYPES } from "@/lib/constants";
import { db } from "@/lib/db";
import { fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { activityScope } from "@/lib/server/visibility";
import { qp, qpEnum } from "@/lib/server/validation";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const params = req.nextUrl.searchParams;

    const page = parseIntParam(params.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(params.get("pageSize"), 50, { min: 1, max: 100 });

    // D-021 — record visibility: below MANAGER, the timeline shows the
    // caller's own actions + activities on in-scope records (foreign-linked
    // rows are invisible — notes on another agent's lead never surface).
    const conditions: Prisma.ActivityWhereInput[] = [{ orgId, ...activityScope(user) }];

    const leadId = qp(req, "leadId");
    if (leadId) conditions.push({ leadId });

    const opportunityId = qp(req, "opportunityId");
    if (opportunityId) conditions.push({ opportunityId });

    const type = qpEnum(req, "type", ACTIVITY_TYPES);
    if (type) conditions.push({ type });

    const where: Prisma.ActivityWhereInput = conditions.length > 1 ? { AND: conditions } : conditions[0];

    const [total, activities] = await Promise.all([
      db.activity.count({ where }),
      db.activity.findMany({
        where,
        orderBy: { occurredAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          actor: { select: { id: true, name: true } },
          lead: { select: { id: true, fullName: true } },
          opportunity: { select: { id: true, title: true } },
        },
      }),
    ]);

    return ok({ data: activities, total, page, pageSize });
  } catch (error) {
    return fail(error);
  }
}
