// GET /api/documents/:id/file — streams the binary from disk with the correct
// Content-Type and an attachment Content-Disposition (filename* UTF-8 encoded
// so original Arabic/French names survive). 404 DOC_NOT_FOUND when the row is
// missing (org-scoped) or the file is gone from disk.
// ?inline=1 serves Content-Disposition: inline instead — required for the
// PDF preview dialog (browsers refuse to render an `attachment` response in
// an iframe). Only the two preview surfaces use it; every other link keeps
// the download semantics. The mime stays whitelist-gated (PDF/images only) so
// inline can never smuggle an executable content type.
//
// W3-A5 (P1) / SEC-06 — download hardening:
//   • PATH RESOLUTION — readDocFile resolves the stored name through a REALPATH
//     containment check against db/docs (symlinks followed, escapes flattened
//     to the same 404-ghost as a missing file — no oracle about WHY).
//   • CONTENT-TYPE TRUTH — the served type is RE-DERIVED from the bytes
//     (sniffMime): when the sniff recognizes a whitelisted type it wins over
//     the stored column (legacy rows uploaded before the content gate could
//     carry a lying declared value); unrecognized bytes fall back to the
//     stored (upload-gated) value. X-Content-Type-Options: nosniff stays on
//     every response — the browser never interprets a mismatched body.
//   • DOWNLOAD AUDIT — every successful egress writes ONE AuditLog row
//     (DOC_DOWNLOADED). Fire-and-forget AFTER the row/bytes resolve, BEFORE
//     streaming: a read path has no companion mutation to be atomic with, so
//     NO transaction wraps it; an audit hiccup must never block a legitimate
//     read (logged to the server console, response unaffected).
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { DOC_ALLOWED_MIME_TYPES } from "@/lib/constants";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { asciiFallbackName, readDocFile } from "@/lib/server/documents";
import { sniffMime } from "@/lib/server/file-verification";
import { fail, requireUser } from "@/lib/server/session";
import { documentScope } from "@/lib/server/visibility";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    // D-021 — scoped findFirst: the binary itself respects record visibility
    // (foreign-org / out-of-scope / nonexistent ids are 404-ghosts, byte-
    // identical — enumeration impossible).
    const document = await db.document.findFirst({
      where: { id, orgId: user.orgId, ...(await documentScope(user)) },
      select: { storedName: true, fileName: true, mimeType: true, entityType: true, entityId: true },
    });
    if (!document) {
      return NextResponse.json({ error: "Document introuvable", code: "DOC_NOT_FOUND" }, { status: 404 });
    }

    // readDocFile throws a 404 DOC_NOT_FOUND ApiError when the file is absent
    // (or resolves outside the storage root — the W3-A5 realpath guard).
    const bytes = await readDocFile(document.storedName);

    // W3-A5 (SEC-06) — the sniffed truth governs the served Content-Type
    // whenever the bytes recognize as a whitelisted type; otherwise the
    // stored (upload-gated) value stands.
    const sniffed = sniffMime(bytes);
    const serveMime =
      sniffed && (DOC_ALLOWED_MIME_TYPES as readonly string[]).includes(sniffed) ? sniffed : document.mimeType;

    // W3-A5 (SEC-06) — the egress audit row. Deliberately NOT transactional:
    // this is a read path (nothing to roll back WITH), and a trail hiccup
    // must not deny a legitimate download — best-effort with a console warn.
    try {
      await logAudit({
        orgId: user.orgId,
        actor: user,
        action: "DOC_DOWNLOADED",
        entity: document.entityType,
        entityId: document.entityId,
        after: {
          documentId: id,
          fileName: document.fileName,
          mimeType: serveMime,
          sizeBytes: bytes.length,
          inline: req.nextUrl.searchParams.get("inline") === "1",
        },
      });
    } catch (auditError) {
      console.warn("[documents] download audit row failed (download served)", { documentId: id, auditError });
    }

    // RFC 5987: ASCII fallback + UTF-8 encoded filename* (original client name).
    const fallback = asciiFallbackName(document.fileName).replace(/["\\]/g, "_");
    const encoded = encodeURIComponent(document.fileName);
    // inline=1 → embeddable (iframe preview); default stays a download.
    const disposition = `${req.nextUrl.searchParams.get("inline") === "1" ? "inline" : "attachment"}; filename="${fallback}"; filename*=UTF-8''${encoded}`;

    return new NextResponse(new Uint8Array(bytes), {
      status: 200,
      headers: {
        "Content-Type": serveMime,
        "Content-Disposition": disposition,
        "Content-Length": String(bytes.length),
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "private, no-store",
      },
    });
  } catch (error) {
    return fail(error);
  }
}
