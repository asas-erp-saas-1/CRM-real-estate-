// GET   /api/documents/:id — metadata + uploader (org-scoped).
// PATCH /api/documents/:id — title/status/notes update. Status transitions:
//        PENDING→VALIDATED|REJECTED, VALIDATED/REJECTED→PENDING (422 otherwise).
//        Every status change writes an Activity (DOCUMENT) AND an audit
//        (DOC_STATUS_CHANGED) — the governance twin DELETE/analyze already had
//        (UX-G finding: status decisions were Activity-only, invisible to the
//        admin audit trail while every sibling status flow audits).
//        API-06 (F-06): the row + Activity + audit commit as ONE transaction
//        (the upload route's law — a status decision can no longer commit
//        without its trail).
//        P2-R1 FIX 5 (F-08): uploader OR MANAGER+ only — mirrors DELETE/analyze
//        (status/notes on a colleague's document are review actions).
// DELETE /api/documents/:id — deletes row + file. Uploader or MANAGER+ only.
//        API-06 (F-06): row + DOC_DELETED audit commit as ONE transaction; the
//        PHYSICAL file delete runs AFTER the commit — a failing unlink must
//        not orphan the trail nor fail the response (warn and move on: the
//        row is already gone, deleteDocFile's own catch makes this
//        belt-and-braces).
import type { NextRequest } from "next/server";
import { z } from "zod";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { atLeastRole, DOC_STATUS_TRANSITIONS, DOCUMENT_STATUSES } from "@/lib/constants";
import { logActivity, logAudit } from "@/lib/server/audit";
import { docInclude, deleteDocFile, verifyDocEntity } from "@/lib/server/documents";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { documentScope } from "@/lib/server/visibility";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

// Activity linkage for an existing document row reuses verifyDocEntity (R7-3:
// OPPORTUNITY/RESERVATION docs climb to the lead so timeline entries surface
// on the lead drawer too).

async function findDocument(id: string, orgId: string, scope?: Prisma.DocumentWhereInput) {
  // D-021 — scoped findFirst: a foreign document (not uploaded by the caller,
  // not on a shared entity, not on an in-scope record) is 404, byte-identical
  // to a nonexistent id.
  const document = await db.document.findFirst({ where: { id, orgId, ...scope }, include: docInclude });
  if (!document) throw new ApiError(404, "Document introuvable", "DOC_NOT_FOUND");
  return document;
}

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const document = await findDocument(id, user.orgId, await documentScope(user));
    return ok({ document });
  } catch (error) {
    return fail(error);
  }
}

// ── PATCH ─────────────────────────────────────────────────────────────────────

const patchSchema = z.object({
  title: z.string().trim().min(1, "Titre requis").max(160).optional(),
  status: z.enum(DOCUMENT_STATUSES).optional(),
  notes: z.string().trim().max(2000).nullable().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    const existing = await findDocument(id, user.orgId, await documentScope(user));

    // ── P2-R1 FIX 5 (F-08): uploader OR MANAGER+ (mirrors DELETE + analyze) ──
    // PATCH previously required only org membership — any SALES_AGENT could
    // flip VALIDATED/REJECTED or rewrite a colleague's title/notes.
    if (existing.uploadedById !== user.id && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(403, "Seul l'auteur du document ou un MANAGER peut le modifier", "DOC_FORBIDDEN");
    }

    if (body.status && body.status !== existing.status) {
      const allowed = DOC_STATUS_TRANSITIONS[existing.status] ?? [];
      if (!allowed.includes(body.status)) {
        throw new ApiError(422, `Transition de statut non autorisée (${existing.status} → ${body.status})`, "INVALID_STATUS_TRANSITION", {
          from: existing.status,
          to: body.status,
          allowed,
        });
      }
    }

    const statusChanged = body.status !== undefined && body.status !== existing.status;
    // Linkage resolves BEFORE the transaction: entityType/entityId are
    // immutable through this PATCH (title/status/notes only), so the read
    // cannot drift from the write (R7-3 climb — see the note above
    // findDocument; verifyDocEntity reads with the pool client, not tx).
    const linkage = statusChanged
      ? await verifyDocEntity(user.orgId, existing.entityType, existing.entityId, user)
      : null;

    // API-06 (F-06): row + Activity + audit commit as ONE transaction (the
    // upload route's law — the upload POST already folds its trail this way).
    const document = await db.$transaction(async (tx) => {
      const row = await tx.document.update({
        where: { id: existing.id },
        data: {
          ...(body.title !== undefined ? { title: body.title } : {}),
          ...(body.status !== undefined ? { status: body.status } : {}),
          ...(body.notes !== undefined ? { notes: body.notes } : {}),
        },
        include: docInclude,
      });

      if (statusChanged && linkage) {
        await logActivity({
          orgId: user.orgId,
          actorId: user.id,
          ...linkage,
          type: "DOCUMENT",
          title: `Document ${row.status}: ${row.title}`,
          body: `${row.fileName} (${row.category})`,
          meta: {
            documentId: row.id,
            before: existing.status,
            after: row.status,
          },
        }, tx);
        // UX-G — the audit twin of the Activity above: a VALIDATED/REJECTED
        // decision is a review action; the admin trail must carry it like every
        // sibling status flow (SAV_CASE_STATUS_CHANGED, APARTMENT_STATUS_CHANGED…).
        await logAudit({
          orgId: user.orgId,
          actor: user,
          action: "DOC_STATUS_CHANGED",
          entity: row.entityType,
          entityId: row.entityId,
          before: {
            documentId: existing.id,
            title: existing.title,
            status: existing.status,
          },
          after: {
            documentId: row.id,
            status: row.status,
          },
        }, tx);
      }
      return row;
    });

    return ok({ document });
  } catch (error) {
    return fail(error);
  }
}

// ── DELETE ────────────────────────────────────────────────────────────────────

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    const existing = await findDocument(id, user.orgId, await documentScope(user));

    // Uploader OR MANAGER+ (server-side enforcement — the UI mirrors this).
    if (existing.uploadedById !== user.id && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(403, "Seul l'auteur du document ou un MANAGER peut le supprimer", "DELETE_FORBIDDEN");
    }

    // API-06 (F-06): row + DOC_DELETED audit commit as ONE transaction; the
    // physical file delete runs AFTER the commit — a failing unlink must not
    // orphan the trail (the row is already gone) nor fail the response:
    // warn and move on. deleteDocFile already swallows its own errors — the
    // try/catch is belt-and-braces so a future helper change cannot regress
    // the contract.
    await db.$transaction(async (tx) => {
      await tx.document.delete({ where: { id: existing.id } });
      await logAudit({
        orgId: user.orgId,
        actor: user,
        action: "DOC_DELETED",
        entity: existing.entityType,
        entityId: existing.entityId,
        before: {
          documentId: existing.id,
          title: existing.title,
          category: existing.category,
          fileName: existing.fileName,
          status: existing.status,
        },
      }, tx);
    });

    try {
      await deleteDocFile(existing.storedName);
    } catch (error) {
      // Row + audit are committed — the trail stands; only disk cleanup
      // failed. Log a warning, never fail the 200.
      console.warn("[documents] file cleanup failed after row delete", {
        documentId: existing.id,
        storedName: existing.storedName,
        error,
      });
    }

    return ok({ deleted: true });
  } catch (error) {
    return fail(error);
  }
}
