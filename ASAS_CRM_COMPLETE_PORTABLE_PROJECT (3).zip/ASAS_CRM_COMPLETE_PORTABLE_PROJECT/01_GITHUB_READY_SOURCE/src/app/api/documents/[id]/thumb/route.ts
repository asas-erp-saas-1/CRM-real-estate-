// GET /api/documents/:id/thumb — first-page thumbnail for the documents
// surfaces (Phase 2, Wave 3, item 3-b). ONE dumb URL contract for <img src>:
//   • image mimes  → 307 to the file route (the browser fetches the original
//     bytes — images need no rasterization);
//   • application/pdf → page 1 rasterized server-side via poppler at 72 DPI
//     (A4 ≈ 595×842 px — plenty for a 56×40 px chip, tiny payload);
//   • any other (future) mime → same 307 to the file route.
// Auth/visibility mirror the file route EXACTLY (requireUser + D-021 scoped
// findFirst); the missing-row 404 is byte-identical to its shape. A PDF
// poppler cannot open (corrupt/protected — renderPdfPages 404/422) is
// flattened to the same 404 DOC_NOT_FOUND: the only consumer is an <img>,
// whose onError drives the category-icon fallback in doc-thumb.tsx. The PNG
// is cacheable 24h — bytes per id are effectively immutable, but private
// because documents are role-scoped (dashboard route Cache-Control pattern).
import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { renderPdfPages } from "@/lib/server/documents";
import { fail, requireUser } from "@/lib/server/session";
import { documentScope } from "@/lib/server/visibility";

type Ctx = { params: Promise<{ id: string }> };

/** Image mimes (upload gate) — no rasterization, the original bytes ARE the thumbnail. */
const IMAGE_MIME = new Set(["image/png", "image/jpeg", "image/webp"]);

/** Same 404 shape as the file route — also used to flatten raster failures. */
const notFound = () =>
  NextResponse.json({ error: "Document introuvable", code: "DOC_NOT_FOUND" }, { status: 404 });

/** 307 to the file route — temporary redirect keeps the method and lets the
 *  contract evolve (a future mime could gain its own rendering here). */
function toFileRoute(req: NextRequest, id: string): NextResponse {
  return NextResponse.redirect(new URL(`/api/documents/${id}/file`, req.nextUrl.origin), 307);
}

export async function GET(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    // D-021 — scoped findFirst: the thumbnail itself respects record visibility
    // (same shape as the file route — the row AND the bytes stay scoped).
    const document = await db.document.findFirst({
      where: { id, orgId: user.orgId, ...(await documentScope(user)) },
      select: { storedName: true, mimeType: true },
    });
    if (!document) {
      return notFound();
    }

    // Images: the browser fetches the original via the file route (307).
    if (IMAGE_MIME.has(document.mimeType)) {
      return toFileRoute(req, id);
    }

    // Future mimes: same dumb contract — redirect, let the <img> onError decide.
    if (document.mimeType !== "application/pdf") {
      return toFileRoute(req, id);
    }

    // PDFs: page 1 only, 72 DPI (595×842 on A4 — sized for the 56×40 chip).
    // Raster failures (missing file / corrupt / protected PDF) are flattened
    // to 404 so the client's img onError fallback degrades gracefully.
    try {
      const [firstPage] = await renderPdfPages(document.storedName, 1, 72);
      if (!firstPage) return notFound();
      return new NextResponse(new Uint8Array(firstPage), {
        status: 200,
        headers: {
          "Content-Type": "image/png",
          "Content-Length": String(firstPage.length),
          "X-Content-Type-Options": "nosniff",
          "Cache-Control": "private, max-age=86400",
        },
      });
    } catch {
      return notFound();
    }
  } catch (error) {
    return fail(error);
  }
}
