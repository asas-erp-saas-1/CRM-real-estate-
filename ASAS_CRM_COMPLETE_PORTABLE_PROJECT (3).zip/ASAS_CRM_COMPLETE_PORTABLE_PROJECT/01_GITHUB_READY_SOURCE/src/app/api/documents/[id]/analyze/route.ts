// ASAS — AI document analysis (R5): VLM-powered OCR + verification.
//
// POST /api/documents/:id/analyze
//   Sends the stored file to the vision model (z-ai-web-dev-sdk, server-side only)
//   with a category-aware prompt, parses a structured JSON extraction, persists
//   it on the Document row (analysis + analyzedAt) and logs an Activity + Audit.
//
//   ID_SCAN       → identity fields (name, birth date, CIN number, expiry …)
//                   + readability verdict — the pre-validation helper.
//   Other categories → document type, parties, dates, amounts, summary, anomalies.
//
//   RBAC: uploader OR MANAGER+. Images (PNG/JPEG/WEBP) AND PDFs — the latter
//   are rasterized server-side via poppler (renderPdfPages, up to 3 pages)
//   and sent as one multi-image vision call (page order preserved). A PDF
//   poppler cannot open (corrupt/encrypted) returns 422 ANALYSIS_PDF_RENDER_FAILED.
//   P2-R1 FIX 6 (F-11): in-memory per-user rate limit — 30s between analyze
//   calls per userId (mirrors the copilot route's limiter pattern); 429
//   ANALYSIS_RATE_LIMITED otherwise. VLM calls cost money — no free loops.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAiProvider } from "@/lib/server/ai-provider";
import { atLeastRole } from "@/lib/constants";
import { logActivity, logAudit } from "@/lib/server/audit";
import { docInclude, readDocFile, renderPdfPages, verifyDocEntity } from "@/lib/server/documents";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { documentScope } from "@/lib/server/visibility";

type Ctx = { params: Promise<{ id: string }> };

/** Mime types eligible for analysis — images go straight to the vision model;
 * PDFs are rasterized to PNG pages first (poppler). */
const ANALYZABLE_MIME = new Set(["image/png", "image/jpeg", "image/webp", "application/pdf"]);

/** One raster page / one uploaded image fed to the vision call. */
interface VisionImage {
  mime: string;
  bytes: Buffer;
}

// P2-R1 FIX 6 (F-11): light in-memory limiter — 30s per userId. Single
// instance, resets on restart (same documented trade-off as the login and
// copilot limiters — see F-06).
const ANALYSIS_RATE_LIMIT_MS = 30_000;
const lastAnalyzeAt = new Map<string, number>();

const VERDICTS = new Set(["READABLE", "PARTIAL", "UNREADABLE"]);

/** Semantic field keys the UI knows how to translate (anything else falls back to label).
 *
 * P6-D1 (Phase 6, Agent 1 + Principal): deliberately NOT exported — Next 16
 * route type validation rejects any `export const` that is not an HTTP method
 * or segment-config field ("KNOWN_FIELD_KEYS is not a valid Route export
 * field" → `next build` exit 1). Nothing imports it (grep-verified); the
 * regression guard lives in tests/unit/route-export-contract.test.ts.
 *
 * J-3 — the leading underscore is the project's own "deliberately unused"
 * idiom (eslint varsIgnorePattern "^_"): the set is living documentation of
 * the VLM-prompt ↔ UI-i18n key contract, kept beside its consumer. */
const _KNOWN_FIELD_KEYS = new Set([
  "surname",
  "givenNames",
  "fullName",
  "dateOfBirth",
  "documentNumber",
  "issueDate",
  "expiryDate",
  "nationality",
  "sex",
  "address",
  "parties",
  "amount",
  "date",
  "reference",
  "property",
  "surface",
]);

interface ExtractedField {
  key: string;
  label: string;
  value: string;
}

interface DocAnalysis {
  documentType: string;
  fields: ExtractedField[];
  verdict: "READABLE" | "PARTIAL" | "UNREADABLE";
  confidence: number; // 0–100
  summary: string;
  anomalies: string[];
  analyzedAt: string; // ISO
}

// Activity linkage for a document row reuses verifyDocEntity (R7-3 — climbs
// OPPORTUNITY/RESERVATION docs to the lead for the timeline).

function promptFor(category: string): string {
  if (category === "ID_SCAN") {
    return `You are verifying a scan/photo of an identity document (Algerian CIN — carte nationale d'identité, or passport).
Extract the visible information and assess readability for KYC validation.
Return ONLY a JSON object, no markdown fence, in exactly this shape:
{
  "documentType": "short document type label in French (e.g. CIN algérienne, Passeport)",
  "fields": [
    { "key": "surname", "label": "Nom", "value": "…" },
    { "key": "givenNames", "label": "Prénom(s)", "value": "…" },
    { "key": "fullName", "label": "Nom complet", "value": "…" },
    { "key": "dateOfBirth", "label": "Date de naissance", "value": "…" },
    { "key": "documentNumber", "label": "N° du document", "value": "…" },
    { "key": "issueDate", "label": "Date de délivrance", "value": "…" },
    { "key": "expiryDate", "label": "Date d'expiration", "value": "…" },
    { "key": "nationality", "label": "Nationalité", "value": "…" },
    { "key": "sex", "label": "Sexe", "value": "…" },
    { "key": "address", "label": "Adresse", "value": "…" }
  ],
  "verdict": "READABLE" | "PARTIAL" | "UNREADABLE",
  "confidence": 0-100,
  "summary": "1–2 sentence French summary of the document state",
  "anomalies": ["…"]
}
Rules:
- "fields": ONLY include entries actually readable on the document; omit the rest. Use "key" values from the list above when they apply; otherwise invent a short English camelCase key with a French "label". Dates in DD/MM/YYYY as printed. Arabic-script names: transliterate to Latin AND keep the original in parentheses.
- "verdict": READABLE = all core fields legible; PARTIAL = some fields obscured/glared/blurry; UNREADABLE = cannot be used for verification.
- "anomalies": list risks — expired or expiring within 6 months, photo/ID number unreadable, signs of alteration, missing side (CIN recto/verso). Empty array when none.
- "confidence": your overall extraction confidence (0–100).
Never invent data that is not visible. Respond with the JSON object only.`;
  }
  return `You are reviewing a real-estate business document (contract, reservation form, bank slip or floor plan) for a CRM in Algeria.
Extract the key information and produce a concise review.
Return ONLY a JSON object, no markdown fence, in exactly this shape:
{
  "documentType": "short document type label in French",
  "fields": [
    { "key": "parties", "label": "Parties", "value": "…" },
    { "key": "amount", "label": "Montant", "value": "…" },
    { "key": "date", "label": "Date", "value": "…" },
    { "key": "reference", "label": "Référence", "value": "…" },
    { "key": "property", "label": "Bien concerné", "value": "…" },
    { "key": "surface", "label": "Surface", "value": "…" }
  ],
  "verdict": "READABLE" | "PARTIAL" | "UNREADABLE",
  "confidence": 0-100,
  "summary": "1–3 sentence French summary of what this document contains and its state (draft, signed, stamped…)",
  "anomalies": ["…"]
}
Rules:
- "fields": only entries actually present/readable. Keys from the list above when they apply, otherwise a short English camelCase key with a French "label". Amounts keep the currency as printed (DA / DZD).
- "anomalies": missing signatures, unsigned draft, illegible stamp, cropped pages… Empty array when none.
Never invent data that is not visible. Respond with the JSON object only.`;
}

/** Parse the model output → DocAnalysis. Tolerates markdown fences and prose wrappers. */
function parseAnalysis(raw: string): DocAnalysis {
  let text = raw.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) text = fence[1].trim();
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start >= 0 && end > start) text = text.slice(start, end + 1);

  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new ApiError(502, "Réponse IA non exploitable", "ANALYSIS_BAD_RESPONSE");
  }

  const fields = Array.isArray(parsed.fields)
    ? (parsed.fields as Record<string, unknown>[])
        .filter((f) => f && typeof f === "object")
        .map((f) => ({
          key: String(f.key ?? "other"),
          label: String(f.label ?? f.key ?? "—"),
          value: String(f.value ?? "").slice(0, 200),
        }))
        .filter((f) => f.value.trim() !== "")
        .slice(0, 14)
    : [];

  const verdictRaw = String(parsed.verdict ?? "PARTIAL").toUpperCase();
  const verdict = (VERDICTS.has(verdictRaw) ? verdictRaw : "PARTIAL") as DocAnalysis["verdict"];
  const confidenceRaw = Number(parsed.confidence);
  const confidence = Number.isFinite(confidenceRaw)
    ? Math.min(100, Math.max(0, Math.round(confidenceRaw)))
    : 50;

  return {
    documentType: String(parsed.documentType ?? "").slice(0, 120),
    fields,
    verdict,
    confidence,
    summary: String(parsed.summary ?? "").slice(0, 600),
    anomalies: Array.isArray(parsed.anomalies)
      ? parsed.anomalies.map((a) => String(a).slice(0, 200)).filter(Boolean).slice(0, 8)
      : [],
    analyzedAt: new Date().toISOString(),
  };
}

export async function POST(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    // D-021 — AI surfaces inherit record visibility: analysis can only run on
    // a document the caller is authorized to open.
    const existing = await db.document.findFirst({
      where: { id, orgId: user.orgId, ...(await documentScope(user)) },
      include: docInclude,
    });
    if (!existing) throw new ApiError(404, "Document introuvable", "DOC_NOT_FOUND");

    // H2 portability guard: resolve the AI provider BEFORE the rate limiter —
    // an unconfigured host answers 503 AI_PROVIDER_UNAVAILABLE and never
    // consumes the user's analysis budget (nor reads the file bytes).
    const zai = await requireAiProvider();

    // Light in-memory rate limit — protects the VLM budget and the DB against
    // double-fires and loops (copilot route pattern; failures count too).
    const now = Date.now();
    const last = lastAnalyzeAt.get(user.id) ?? 0;
    if (now - last < ANALYSIS_RATE_LIMIT_MS) {
      throw new ApiError(429, "Analyse très récente — patientez quelques secondes", "ANALYSIS_RATE_LIMITED");
    }
    lastAnalyzeAt.set(user.id, now);

    // Uploader OR MANAGER+ (mirrors the delete rule — analysis is a review action).
    if (existing.uploadedById !== user.id && !atLeastRole(user.role, "MANAGER")) {
      throw new ApiError(403, "Seul l'auteur du document ou un MANAGER peut lancer l'analyse", "ANALYSIS_FORBIDDEN");
    }

    if (!ANALYZABLE_MIME.has(existing.mimeType)) {
      throw new ApiError(
        415,
        "L'analyse IA est disponible pour les images (PNG, JPG, WEBP) et les PDF",
        "ANALYSIS_UNSUPPORTED_TYPE",
      );
    }

    // Vision payload: PDFs rasterize to per-page PNGs (up to 3 — budget
    // guard), images are read as-is. One vision call carries every page.
    const images: VisionImage[] = [];
    if (existing.mimeType === "application/pdf") {
      const pages = await renderPdfPages(existing.storedName);
      images.push(...pages.map((bytes) => ({ mime: "image/png", bytes })));
    } else {
      const bytes = await readDocFile(existing.storedName);
      if (bytes.length === 0) throw new ApiError(404, "Fichier document vide", "DOC_NOT_FOUND");
      images.push({ mime: existing.mimeType, bytes });
    }

    // Multi-page note — the model must consolidate N page images into ONE review.
    const pageNote =
      images.length > 1
        ? `\nThe document has ${images.length} pages — one image per page is provided in reading order (page 1 first). Consolidate ALL pages into a single JSON review of the document.`
        : "";

    // Vision call — base64 data URLs (recommended by the VLM skill docs);
    // the model accepts several image_url entries per message.
    const response = await zai.chat.completions.createVision({
      model: "glm-4.6v",
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: promptFor(existing.category) + pageNote },
            ...images.map(
              (img): { type: "image_url"; image_url: { url: string } } => ({
                type: "image_url",
                image_url: { url: `data:${img.mime};base64,${img.bytes.toString("base64")}` },
              }),
            ),
          ],
        },
      ],
      thinking: { type: "disabled" },
    });
    const content = response.choices[0]?.message?.content ?? "";
    if (!content.trim()) throw new ApiError(502, "Réponse IA vide", "ANALYSIS_BAD_RESPONSE");

    const analysis = parseAnalysis(content);

    const document = await db.document.update({
      where: { id: existing.id },
      data: { analysis: JSON.stringify(analysis), analyzedAt: new Date() },
      include: docInclude,
    });

    const linkage = await verifyDocEntity(user.orgId, document.entityType, document.entityId, user);
    await logActivity({
      orgId: user.orgId,
      actorId: user.id,
      ...linkage,
      type: "DOCUMENT",
      title: `Analyse IA: ${document.title}`,
      body: `${analysis.documentType || "Document"} — ${analysis.verdict} (${analysis.confidence}%)`,
      meta: {
        documentId: document.id,
        verdict: analysis.verdict,
        confidence: analysis.confidence,
      },
    });

    await logAudit({
      orgId: user.orgId,
      actor: user,
      action: "DOC_ANALYZED",
      entity: document.entityType,
      entityId: document.entityId,
      before: { documentId: existing.id, hadAnalysis: existing.analyzedAt != null },
      after: { documentId: document.id, verdict: analysis.verdict, confidence: analysis.confidence },
    });

    return ok({ document });
  } catch (error) {
    return fail(error);
  }
}
