// GET  /api/documents — list, newest first, org-scoped (tenant isolation).
//                      Filters: entityType, entityId, category, status.
//                      API-11: bounded scan (take: 200 — the house cap
//                      convention; see the note at the query).
// POST /api/documents — multipart formData upload (file + title + category +
//                      entityType + entityId + notes?). Any role can upload.
//                      Validates the entity exists (org-scoped), writes the
//                      file to db/docs/{storedName} FIRST, then creates the
//                      row + Activity(DOCUMENT) + Audit(DOC_UPLOADED) in ONE
//                      $transaction (G5-P3-5/F-15 — a failed insert compen-
//                      sates by deleting the file: disk and DB always agree).
//                      Responds 201 with the row.
// W3-A5 (P1) / SEC-06 — CONTENT GATE: the file type is verified from the
//                      BYTES (magic-number sniffing, file-verification.ts),
//                      NOT from the client-declared Content-Type. The sniffed
//                      MIME is the STORED truth (`Document.mimeType`); the
//                      declared value survives only inside the audit row as a
//                      discrepancy signal (declaredMimeType) when it disagrees.
//                      Bytes outside the whitelist (EXE/ELF, scripts, random
//                      data, truncated headers) → 422 INVALID_FILE_CONTENT.
import type { NextRequest } from "next/server";
import { z } from "zod";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import {
  DOC_ALLOWED_MIME_TYPES,
  DOC_ENTITY_TYPES,
  DOC_MAX_SIZE_BYTES,
  DOCUMENT_CATEGORIES,
  DOCUMENT_STATUSES,
} from "@/lib/constants";
import { logActivity, logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { docInclude, buildStoredName, verifyDocEntity, writeDocFile, deleteDocFile } from "@/lib/server/documents";
import {
  INVALID_FILE_CONTENT_MESSAGE,
  verifyFileContent,
} from "@/lib/server/file-verification";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { documentScope } from "@/lib/server/visibility";
import { qp, qpEnum, validate } from "@/lib/server/validation";

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;

    // D-021 — record visibility: below MANAGER, documents are own uploads ∨
    // shared inventory docs ∨ docs on in-scope records.
    const conditions: Prisma.DocumentWhereInput[] = [{ orgId, ...(await documentScope(user)) }];

    const entityType = qpEnum(req, "entityType", DOC_ENTITY_TYPES);
    if (entityType) conditions.push({ entityType });

    const entityId = qp(req, "entityId");
    if (entityId) conditions.push({ entityId });

    const category = qpEnum(req, "category", DOCUMENT_CATEGORIES);
    if (category) conditions.push({ category });

    const status = qpEnum(req, "status", DOCUMENT_STATUSES);
    if (status) conditions.push({ status });

    const documents = await db.document.findMany({
      where: conditions.length > 1 ? { AND: conditions } : conditions[0],
      orderBy: { createdAt: "desc" },
      include: docInclude,
      // API-11 (master audit — PERF): bounded scan cap (take: 200), the
      // installments-list convention (W3.6 take:500) sized for THIS payload:
      // document rows are the heaviest in the API (full metadata + uploader
      // + entity joins per row). Newest-first ordering makes the cap a
      // "latest 200" window; the response contract is unchanged ({ data }).
      take: 200,
    });

    return ok({ data: documents });
  } catch (error) {
    return fail(error);
  }
}

// ── POST (multipart) ──────────────────────────────────────────────────────────

const createSchema = z.object({
  title: z.string().trim().min(1, "Titre requis").max(160),
  category: z.enum(DOCUMENT_CATEGORIES),
  entityType: z.enum(DOC_ENTITY_TYPES),
  entityId: z.string().trim().min(1).max(64),
  notes: z.string().trim().max(2000).nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;

    // W1-6 (Phase 2.1 — A3#4): reject oversized uploads BEFORE req.formData()
    // buffers the full body into memory (the old order read everything first
    // and only then applied the 8 MB cap — an authenticated memory-exhaustion
    // vector). Content-Length is the transport-level truth; the post-parse
    // file.size check below remains the authoritative gate.
    const declaredLength = Number(req.headers.get("content-length") ?? "0");
    if (Number.isFinite(declaredLength) && declaredLength > DOC_MAX_SIZE_BYTES + 64 * 1024) {
      throw new ApiError(413, "Fichier trop volumineux (max 8 Mo)", "DOC_TOO_LARGE", {
        sizeBytes: declaredLength,
        maxBytes: DOC_MAX_SIZE_BYTES,
      });
    }

    let form: FormData;
    try {
      form = await req.formData();
    } catch {
      throw new ApiError(400, "Requête multipart/form-data invalide", "INVALID_FORM_DATA");
    }

    const file = form.get("file");
    if (!(file instanceof File) || file.size === 0) {
      throw new ApiError(400, "Aucun fichier fourni", "NO_FILE");
    }

    // Size cap BEFORE reading the payload into memory.
    if (file.size > DOC_MAX_SIZE_BYTES) {
      throw new ApiError(413, "Fichier trop volumineux (max 8 Mo)", "DOC_TOO_LARGE", {
        sizeBytes: file.size,
        maxBytes: DOC_MAX_SIZE_BYTES,
      });
    }

    // W3-A5 (SEC-06) — the CONTENT gate replaces the old declared-MIME gate
    // (415 DOC_BAD_TYPE): sniffing is independent of client headers, so a
    // lying declaration neither grants nor blocks anything. The sniffed type
    // must be in the whitelist (422 INVALID_FILE_CONTENT otherwise); the
    // declared type is kept aside as a discrepancy signal for the audit row.
    const bytes = Buffer.from(await file.arrayBuffer());
    const verification = verifyFileContent(bytes, file.type, DOC_ALLOWED_MIME_TYPES);
    if (!verification.allowed) {
      throw new ApiError(422, INVALID_FILE_CONTENT_MESSAGE, "INVALID_FILE_CONTENT", {
        sniffedMime: verification.sniffedMime,
        declaredMimeType: file.type || null,
        sizeBytes: file.size,
      });
    }
    const storedMimeType = verification.sniffedMime!; // allowed ⇒ sniffed ∈ whitelist

    // Text fields → zod (same 422 VALIDATION_ERROR contract as JSON routes).
    const fields = validate(createSchema, {
      title: form.get("title"),
      category: form.get("category"),
      entityType: form.get("entityType"),
      entityId: form.get("entityId"),
      notes: form.get("notes") === null ? undefined : form.get("notes"),
    });

    // The target entity must exist in the SAME org (tenant isolation) and be
    // in the caller's visibility scope (D-021 — foreign targets 404).
    const linkage = await verifyDocEntity(orgId, fields.entityType, fields.entityId, user);

    const storedName = buildStoredName(file.name);

    // G5-P3-5 (F-15): the file lands on disk BEFORE the row exists — the old
    // DB-insert-then-write order left an orphaned row pointing at nothing
    // when the disk write failed (deleteDocFile cleaned a file that was never
    // written, never the row). Filesystem writes cannot join a DB transaction,
    // so the compensation below deletes the file if the transactional
    // row+trail insert fails — either way, disk and DB agree.
    await writeDocFile(storedName, bytes);

    // The row + its Activity/Audit trail commit as ONE transaction (F-06).
    let document;
    try {
      document = await db.$transaction(async (tx) => {
        const row = await tx.document.create({
          data: {
            orgId,
            title: fields.title,
            category: fields.category,
            entityType: fields.entityType,
            entityId: fields.entityId,
            fileName: file.name,
            storedName,
            mimeType: storedMimeType, // W3-A5 (SEC-06): the SNIFFED truth, not the client declaration
            sizeBytes: file.size,
            status: "PENDING",
            uploadedById: user.id,
            notes: fields.notes ?? null,
          },
          include: docInclude,
        });
        injectTxFault(req, "documents-post");

        // Bilingual-safe activity title (token + user-supplied title).
        await logActivity({
          orgId,
          actorId: user.id,
          ...linkage,
          type: "DOCUMENT",
          title: `Document: ${row.title}`,
          body: `${row.fileName} (${row.category})`,
          meta: { documentId: row.id, category: row.category, fileName: row.fileName },
        }, tx);
        await logAudit({
          orgId,
          actor: user,
          action: "DOC_UPLOADED",
          entity: fields.entityType,
          entityId: fields.entityId,
          after: {
            documentId: row.id,
            title: row.title,
            category: row.category,
            fileName: row.fileName,
            sizeBytes: row.sizeBytes,
            // W3-A5 (SEC-06) — the sniffed type is the stored truth; the
            // client's declaration rides along ONLY when it disagreed
            // (discrepancy signal for review, never an acceptance gate).
            mimeType: row.mimeType,
            ...(verification.mismatch ? { declaredMimeType: file.type || null } : {}),
          },
        }, tx);
        return row;
      });
    } catch (error) {
      // Never leave an orphaned file behind a failed row insert (the inverse
      // of the old defect: the file predates the row, so IT is compensated).
      await deleteDocFile(storedName).catch(() => undefined);
      throw error;
    }

    return ok({ document }, 201);
  } catch (error) {
    return fail(error);
  }
}
