// GET /api/dashboard?range=7d|30d|90d|all — operational KPIs + agenda + funnel
// + source performance. Thin HTTP adapter (W2-A3, ARCH-01): requireUser →
// range validation → the dashboard projection service → ok() + the W3.5
// 30s private browser cache header. Every projection law (D-021 role-aware
// scoping, R9-5 windows, R15 trends, P18 economics, P46/P49/P50/P53
// backlogs, P20-D series) lives in src/lib/services/dashboard.ts.
import type { NextRequest } from "next/server";
import { getDashboardSnapshot, parseDashboardRange } from "@/lib/services/dashboard";
import { fail, ok, requireUser } from "@/lib/server/session";
import { qp } from "@/lib/server/validation";

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    // R9-5 — validate the period filter (422 + code on garbage).
    const range = parseDashboardRange(qp(req, "range"));
    const snapshot = await getDashboardSnapshot(user, range);
    // W3.5 (master audit — PERF-P2): 30s browser cache for expensive
    // aggregate GETs (~30 queries per dashboard GET). `private` keeps every
    // proxy/CDN out (cookie-scoped payload — never a shared cache); the
    // browser alone may reuse it for half a minute.
    const res = await ok(snapshot);
    res.headers.set("Cache-Control", "private, max-age=30");
    return res;
  } catch (error) {
    return fail(error);
  }
}
