// GET /api/health — deployment/uptime probe (W1-8, Phase 2.1 → P2/W1 v2 → P5/W2-A6).
//
// Purpose: an executable demo-mode deploy assertion. The security audit's
// top residual risk (A3#1) was that nothing FORCES ASAS_DEMO_MODE=0 in a
// deployment pipeline: the passwordless quick-login chain is default-ON and
// only document-checked. Monitors and deploy gates can now probe:
//
//   curl -fsS $ORIGIN/api/health | jq -e '.demoMode == false'
//
// Contract: unauthenticated BY DESIGN (uptime probes carry no session), zero
// data exposure (booleans, timestamps and coarse process numbers only — the
// detailed per-route metrics live behind auth on /api/metrics), no org
// scoping needed. `migrations` reflects the Prisma migration bookkeeping
// count — a schema drift or failed deploy shows up as a number below the
// chain length.
//
// P2/W1 (Agent 1) additions — runtime diagnosis without data exposure:
//   · dbLatencyMs  — measured duration of the connectivity probe itself
//                    (a slow-but-up DB becomes visible next to dbOk).
//   · uptimeSec    — process uptime (deploy/restart forensics).
//   · nodeEnv / rssMb — environment + memory posture for capacity triage.
//
// P5/W2-A6 (P4-L08) — observability without log spam. The probe is polled
// every ~30–60 s by the UI/watchdog; one log line per poll would drown the
// console and feed no alert that the STATUS doesn't already carry. So:
//   · every poll IS counted in the obs store (route stats — /api/metrics
//     now reports "GET /api/health" count/errors like any route);
//   · NO per-poll log line is emitted;
//   · exactly ONE structured line (`health_state_change`) is emitted when
//     the DB verdict TRANSITIONS ok→degraded or degraded→ok — plus once
//     when the process boots already degraded (unknown→degraded), so a
//     born-broken boot is not silent. The transition state is globalThis
//     anchored inside obs.ts (survives Turbopack chunk duplication).
// The response JSON contract is UNCHANGED (tests, watchdog and the compose
// healthcheck pin it byte-for-byte).
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logEvent } from "@/lib/server/logger";
import { recordApiRequest, recordHealthProbe } from "@/lib/server/obs";
import { isDemoMode, isDemoModeMisconfigured, requestContext } from "@/lib/server/session";

export async function GET() {
  const ctx = await requestContext();
  const demoMode = isDemoMode();
  let migrations: number | null = null;
  let dbOk = true;
  let dbLatencyMs: number | null = null;
  const probeStart = Date.now();
  try {
    // P2.2 — connectivity and migration bookkeeping are SEPARATE facts: a
    // `db push`-based environment (dev/sandbox) has no `_prisma_migrations`
    // table at all, which previously flipped the whole probe to "degraded"
    // while every real query worked. Now: SELECT 1 proves connectivity
    // (dbOk); the migration count is best-effort (null = no migration book
    // — push-based, or unreadable — reported as-is, never as "db down").
    await db.$queryRaw`SELECT 1`;
    dbLatencyMs = Date.now() - probeStart;
    try {
      migrations = await db.$queryRaw<{ n: bigint | number }[]>`SELECT COUNT(*) AS n FROM _prisma_migrations`.then(
        (rows) => Number(rows[0]?.n ?? 0),
      );
    } catch {
      migrations = null; // push-based DB — truthful absence, not an error
    }
  } catch {
    dbOk = false;
  }
  const status = dbOk ? 200 : 503;
  // P5/W2-A6 (P4-L08) — metrics-only for the steady state (no per-poll line).
  const durationMs = Math.max(Date.now() - ctx.startedAtMs, 0);
  recordApiRequest(ctx.route, ctx.method, status, durationMs);
  const previous = recordHealthProbe(dbOk);
  const transitioned = (previous === null && !dbOk) || (previous !== null && previous !== dbOk);
  if (transitioned) {
    // To-degraded is an ERROR (DB down); recovery is a WARN so it stays
    // visible at the production default level (info) without claiming the
    // emergency channel. One line per transition — never per poll.
    logEvent(dbOk ? "warn" : "error", "health_state_change", {
      requestId: ctx.requestId,
      route: ctx.route,
      method: ctx.method,
      status,
      from: previous === null ? "unknown" : previous ? "ok" : "degraded",
      to: dbOk ? "ok" : "degraded",
      dbOk,
      dbLatencyMs,
      rssMb: Math.round(process.memoryUsage().rss / (1024 * 1024)),
      uptimeSec: Math.round(process.uptime()),
    });
  }
  return NextResponse.json(
    {
      status: dbOk ? "ok" : "degraded",
      dbOk,
      dbLatencyMs,
      migrations,
      demoMode, // deploy gates assert `false` in production
      demoModeMisconfigured: isDemoModeMisconfigured(),
      // P0-3 — presence only, never the value. Deploy gates assert `true`
      // (a production boot without a session secret is crashed by
      // src/instrumentation.ts; this flag is the externally observable proof).
      sessionSecretConfigured: Boolean(process.env.ASAS_SESSION_SECRET),
      // P2/W1 additions — process posture, no request counters on the public
      // probe (those are auth-gated on /api/metrics).
      uptimeSec: Math.round(process.uptime()),
      nodeEnv: process.env.NODE_ENV ?? null,
      rssMb: Math.round(process.memoryUsage().rss / (1024 * 1024)),
      checkedAt: new Date().toISOString(),
    },
    { status, headers: { "Cache-Control": "no-store" } },
  );
}
