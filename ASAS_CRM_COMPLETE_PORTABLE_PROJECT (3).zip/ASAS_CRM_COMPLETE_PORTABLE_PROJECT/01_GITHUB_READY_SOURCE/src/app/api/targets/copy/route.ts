// /api/targets/copy — bulk month-copy for sales targets (Task 3-a, Phase 2 W3).
//
// POST /api/targets/copy  { fromMonth: "YYYY-MM", toMonth: "YYYY-MM" }  (OWNER/ADMIN only)
//        → { copied, totalDZD, fromMonth, toMonth }
//        Copies EVERY SalesTarget row of the source month onto the destination
//        month (upsert on the natural key orgId_userId_month — destination
//        amounts are OVERWRITTEN, source rows are left untouched). A source
//        month with no rows is an idempotent no-op (200, copied: 0 — the UI
//        never offers the action for an empty month, but the API stays quiet).
//        Upserts + ONE audit entry (SALES_TARGET_COPIED) share a single
//        transaction — a mid-copy failure rolls back both (no half-copied
//        month, no orphaned audit row).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

/** "YYYY-MM" with a real month number (01–12) — mirrors /api/targets. */
const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;

const copySchema = z.object({
  // Shape-only here (non-empty strings): the format itself is checked below so a
  // malformed month returns the domain's INVALID_MONTH code (the same 422 the
  // GET route raises on a bad ?month param), not the generic VALIDATION_ERROR.
  fromMonth: z.string().trim().min(1, "Mois requis"),
  toMonth: z.string().trim().min(1, "Mois requis"),
});

export async function POST(req: NextRequest) {
  try {
    const actor = await requirePermission("targets.manage"); // ADMIN rank = OWNER or ADMIN
    const body = await parseBody(req, copySchema);

    for (const field of ["fromMonth", "toMonth"] as const) {
      const value = body[field];
      if (!MONTH_RE.test(value)) {
        throw new ApiError(422, "Mois invalide (format attendu : YYYY-MM)", "INVALID_MONTH", {
          param: field,
          value,
        });
      }
    }

    if (body.fromMonth === body.toMonth) {
      throw new ApiError(422, "Le mois de destination doit être différent du mois source", "SAME_MONTH", {
        fromMonth: body.fromMonth,
        toMonth: body.toMonth,
      });
    }

    // Source rows (deterministic order → deterministic audit payload).
    const sources = await db.salesTarget.findMany({
      where: { orgId: actor.orgId, month: body.fromMonth },
      select: { userId: true, amountDZD: true },
      orderBy: { userId: "asc" },
    });

    // Idempotent no-op: nothing to copy.
    if (sources.length === 0) {
      return ok({ copied: 0, totalDZD: 0, fromMonth: body.fromMonth, toMonth: body.toMonth });
    }

    // Destination before-values (for the audit trail): previous amount per user,
    // null when the destination month has no row for that user yet.
    const destinations = await db.salesTarget.findMany({
      where: { orgId: actor.orgId, month: body.toMonth },
      select: { userId: true, amountDZD: true },
    });
    const destBefore = new Map(destinations.map((d) => [d.userId, d.amountDZD]));

    const rows = await db.$transaction(
      async (tx) => {
        const written: { userId: string; from: number | null; to: number }[] = [];
        for (const src of sources) {
          await tx.salesTarget.upsert({
            where: { orgId_userId_month: { orgId: actor.orgId, userId: src.userId, month: body.toMonth } },
            create: { orgId: actor.orgId, userId: src.userId, month: body.toMonth, amountDZD: src.amountDZD },
            update: { amountDZD: src.amountDZD },
          });
          written.push({ userId: src.userId, from: destBefore.get(src.userId) ?? null, to: src.amountDZD });
        }

        // ONE audit entry for the whole bulk operation. The targets domain
        // audits entity "USER" (SALES_TARGET_SET / SALES_TARGET_CLEARED in
        // /api/targets); for a bulk copy no single user is the subject, so
        // entityId stays null — the same bulk shape as LEADS_IMPORTED /
        // LEAD_BULK_* — while the per-user before/after detail rides in
        // before.rows [{ userId, from, to }] and the outcome summary in after.
        await logAudit(
          {
            orgId: actor.orgId,
            actor,
            action: "SALES_TARGET_COPIED",
            entity: "USER",
            entityId: null,
            before: { fromMonth: body.fromMonth, toMonth: body.toMonth, rows: written },
            after: {
              fromMonth: body.fromMonth,
              toMonth: body.toMonth,
              copied: written.length,
              totalDZD: written.reduce((sum, r) => sum + r.to, 0),
            },
          },
          tx,
        );

        return written;
      },
      { timeout: 15_000 },
    );

    const totalDZD = rows.reduce((sum, r) => sum + r.to, 0);
    return ok({ copied: rows.length, totalDZD, fromMonth: body.fromMonth, toMonth: body.toMonth });
  } catch (error) {
    return fail(error);
  }
}
