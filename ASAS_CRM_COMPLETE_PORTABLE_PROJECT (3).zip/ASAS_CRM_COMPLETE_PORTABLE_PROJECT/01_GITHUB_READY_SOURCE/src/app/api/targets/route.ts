// /api/targets — monthly sales targets (R10-4, "objectifs de vente").
//
// GET  /api/targets?month=YYYY-MM (default: current month)
//        → { month, rows, orgTarget, orgAchieved }
//        MANAGER+ (OWNER/ADMIN/MANAGER) get the ORG-wide rows; SALES_AGENT /
//        MARKETING / others get ONLY their own row (RBAC hardening — mirrors
//        how the org-scoped GET routes gate: requireUser() + atLeastRole).
//        Rows include user { id, name, role } for display plus the month's
//        achievedDZD (sum of CLOSED_WON opportunity values closedAt within the
//        month, owned by the user) and deals (count). A row exists when the
//        user has a target OR achieved > 0 — so callers can hide everything
//        when nothing is set (empty array, orgTarget 0).
//
// POST /api/targets  { userId, month: "YYYY-MM", amountDZD }  (OWNER/ADMIN only)
//        Upsert on the natural key (orgId, userId, month). amountDZD = 0 is the
//        documented CLEAR sentinel: the row is deleted (audit SALES_TARGET_CLEARED)
//        instead of storing a zero target. Any other amount upserts and audits
//        SALES_TARGET_SET with before/after amounts. (API-06: row + audit
//        commit as ONE transaction on both branches — F-06.) The target user
//        may carry ANY role (managers sell too); must exist and be org-scoped
//        (404 USER_NOT_FOUND).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { atLeastRole } from "@/lib/constants";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { MAX_MONEY_DZD, parseBody, qp } from "@/lib/server/validation";

/** "YYYY-MM" with a real month number (01–12). */
const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;

function currentMonthKey(now = new Date()): string {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
}

/** [start, end) window of a "YYYY-MM" month (end = 1st of the next month). */
function monthBounds(month: string): { start: Date; end: Date } {
  const [y, m] = month.split("-").map(Number);
  return { start: new Date(y!, m! - 1, 1), end: new Date(y!, m!, 1) };
}

interface TargetRow {
  userId: string;
  name: string;
  role: string;
  amountDZD: number;
  achievedDZD: number;
  deals: number;
}

/** Shared GET body: targets for a month + the month's won deals, merged. */
async function buildMonthPayload(orgId: string, month: string, onlyUserId?: string) {
  const { start, end } = monthBounds(month);

  const [targets, wonOpps] = await Promise.all([
    db.salesTarget.findMany({
      where: { orgId, month, ...(onlyUserId ? { userId: onlyUserId } : {}) },
      include: { user: { select: { id: true, name: true, role: true } } },
    }),
    db.opportunity.findMany({
      where: {
        orgId,
        stage: "CLOSED_WON",
        closedAt: { gte: start, lt: end },
        ...(onlyUserId ? { ownerId: onlyUserId } : {}),
      },
      select: {
        ownerId: true,
        value: true,
        owner: { select: { id: true, name: true, role: true } },
      },
    }),
  ]);

  // Merge on userId: a row exists when the user has a target OR won deals.
  const byUser = new Map<string, TargetRow>();
  for (const t of targets) {
    byUser.set(t.userId, {
      userId: t.userId,
      name: t.user.name,
      role: t.user.role,
      amountDZD: t.amountDZD,
      achievedDZD: 0,
      deals: 0,
    });
  }
  for (const opp of wonOpps) {
    // Won deals without an owner cannot be attributed to an agent — skipped.
    if (!opp.owner) continue;
    const entry =
      byUser.get(opp.owner.id) ?? {
        userId: opp.owner.id,
        name: opp.owner.name,
        role: opp.owner.role,
        amountDZD: 0,
        achievedDZD: 0,
        deals: 0,
      };
    entry.achievedDZD += opp.value ?? 0;
    entry.deals += 1;
    byUser.set(opp.owner.id, entry);
  }

  const rows = [...byUser.values()]
    .filter((r) => r.amountDZD > 0 || r.achievedDZD > 0)
    .sort((a, b) => b.achievedDZD - a.achievedDZD || b.amountDZD - a.amountDZD);

  const orgTarget = rows.reduce((sum, r) => sum + r.amountDZD, 0);
  const orgAchieved = rows.reduce((sum, r) => sum + r.achievedDZD, 0);
  return { month, rows, orgTarget, orgAchieved };
}

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const month = qp(req, "month") ?? currentMonthKey();
    if (!MONTH_RE.test(month)) {
      throw new ApiError(422, "Paramètre 'month' : format attendu YYYY-MM", "INVALID_MONTH", {
        param: "month",
        value: month,
      });
    }
    // MANAGER+ see the whole org; everyone else only their own row.
    const scope = atLeastRole(user.role, "MANAGER") ? undefined : user.id;
    return ok(await buildMonthPayload(user.orgId, month, scope));
  } catch (error) {
    return fail(error);
  }
}

// ── POST — upsert / clear a target (OWNER/ADMIN) ─────────────────────────────

const postSchema = z.object({
  userId: z.string().trim().min(1, "Utilisateur requis"),
  month: z.string().trim().regex(MONTH_RE, "Mois invalide (format attendu : YYYY-MM)"),
  // 0 is the clear sentinel; positive amounts upsert.
  // C8 (Phase 5): the ceiling is the ONE shared DZD money law (MAX_MONEY_DZD)
  // — this route previously declared a private 10_000_000_000 twin.
  amountDZD: z
    .number()
    .min(0, "Le montant doit être positif ou nul")
    .max(MAX_MONEY_DZD, "Montant trop élevé (max 10 milliards DA)"),
});

export async function POST(req: NextRequest) {
  try {
    const actor = await requirePermission("targets.manage"); // ADMIN rank = OWNER or ADMIN
    const body = await parseBody(req, postSchema);

    const target = await db.user.findFirst({
      where: { id: body.userId, orgId: actor.orgId },
      select: { id: true, name: true, role: true, active: true },
    });
    if (!target) throw new ApiError(404, "Utilisateur introuvable", "USER_NOT_FOUND");

    const existing = await db.salesTarget.findUnique({
      where: { orgId_userId_month: { orgId: actor.orgId, userId: target.id, month: body.month } },
      select: { id: true, amountDZD: true },
    });

    // ── Clear sentinel: amountDZD = 0 deletes the row (documented contract). ──
    if (body.amountDZD === 0) {
      if (existing) {
        // API-06 (F-06): the clear-delete + its audit row commit as ONE
        // transaction (single-row mutation + trail — the house law).
        await db.$transaction(async (tx) => {
          await tx.salesTarget.delete({ where: { id: existing.id } });
          await logAudit({
            orgId: actor.orgId,
            actor,
            action: "SALES_TARGET_CLEARED",
            entity: "USER",
            entityId: target.id,
            before: { userId: target.id, month: body.month, amountDZD: existing.amountDZD },
            after: { userId: target.id, month: body.month, amountDZD: 0 },
          }, tx);
        });
        return ok({ month: body.month, userId: target.id, amountDZD: 0, cleared: true });
      }
      // Idempotent: clearing a month with no target is a no-op.
      return ok({ month: body.month, userId: target.id, amountDZD: 0, cleared: false });
    }

    // API-06 (F-06): the upsert + its audit row commit as ONE transaction —
    // no committed target without its SALES_TARGET_SET trail (the single-row
    // mutation + audit house law).
    const saved = await db.$transaction(async (tx) => {
      const row = await tx.salesTarget.upsert({
        where: { orgId_userId_month: { orgId: actor.orgId, userId: target.id, month: body.month } },
        create: { orgId: actor.orgId, userId: target.id, month: body.month, amountDZD: body.amountDZD },
        update: { amountDZD: body.amountDZD },
        select: { userId: true, month: true, amountDZD: true },
      });
      await logAudit({
        orgId: actor.orgId,
        actor,
        action: "SALES_TARGET_SET",
        entity: "USER",
        entityId: target.id,
        before: existing ? { userId: target.id, month: body.month, amountDZD: existing.amountDZD } : null,
        after: { userId: target.id, month: body.month, amountDZD: row.amountDZD },
      }, tx);
      return row;
    });

    return ok({ month: saved.month, userId: saved.userId, amountDZD: saved.amountDZD });
  } catch (error) {
    return fail(error);
  }
}
