// GET  /api/lead-capture-tokens — the org's capture tokens (MANAGER+,
//      org-scoped, newest first): label / scope / derived status / expiry /
//      useCount / lastUsedAt. The tokenHash is NEVER selected (hash-only
//      storage law) and the mint secret is NEVER recoverable from here.
// POST /api/lead-capture-tokens — mint (MANAGER+). Body: { label?,
//      expiresAt? (ISO, strictly future) }. Responds 201 { token, secret } —
//      the secret appears exactly ONCE, in this response only. The audit row
//      (CAPTURE_TOKEN_CREATED) carries the token id + label, never the secret.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { listCaptureTokens, mintCaptureToken } from "@/lib/server/lead-capture";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("capture_tokens.manage");
    const tokens = await listCaptureTokens(user.orgId);
    return ok({ data: tokens });
  } catch (error) {
    return fail(error);
  }
}

// ── POST (mint) ───────────────────────────────────────────────────────────────

const mintSchema = z.object({
  label: z.string().trim().min(1).max(120, "Libellé trop long (120 caractères max)").nullable().optional(),
  // Expiry is OPTIONAL (null = no expiry) but when present it must be a
  // strictly-future ISO instant — minting an already-expired token is a
  // configuration mistake, not a state anyone needs.
  expiresAt: z
    .string()
    .datetime({ offset: true })
    .refine((v) => new Date(v).getTime() > Date.now(), "La date d'expiration doit être dans le futur")
    .nullable()
    .optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("capture_tokens.manage");
    const body = await parseBody(req, mintSchema);
    const expiresAt = body.expiresAt ? new Date(body.expiresAt) : null;
    if (expiresAt && Number.isNaN(expiresAt.getTime())) {
      throw new ApiError(422, "Date d'expiration invalide", "VALIDATION_ERROR");
    }
    const { row, secret } = await mintCaptureToken({
      orgId: user.orgId,
      minter: user,
      label: body.label ?? null,
      expiresAt,
    });
    // 201 — `secret` is the ONE-TIME plaintext. Nothing logs it (the mint
    // audit row is constructed without it; no serialization of the secret
    // exists beyond this response body).
    return ok({ token: row, secret }, 201);
  } catch (error) {
    return fail(error);
  }
}

// NOTE (documentation, no handler): the mint/list routes deliberately write NO
// Activity rows — capture tokens are configuration, not client-facing timeline
// events; the AuditLog is the trail for this lifecycle (the same split as the
// users/pipeline configuration surfaces).
