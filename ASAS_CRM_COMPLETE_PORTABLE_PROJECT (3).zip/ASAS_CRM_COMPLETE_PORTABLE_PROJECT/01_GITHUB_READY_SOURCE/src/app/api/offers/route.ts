// ASAS — Offers / Options (W1-A1, P1).
// GET  /api/offers — org-scoped, filterable list (opportunityId / status /
//        agentId / apartmentId) with pagination (the leads house pattern).
//        Runs the lazy offer expiry sweep first (the reservations GET law:
//        awaited, idempotent, indexed no-op when nothing is due).
// POST /api/offers — create an offer (DRAFT by default; `activate: true`
//        creates directly ACTIVE and takes the provisional unit hold in the
//        SAME transaction). Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import { APARTMENT_PAYMENT_PLANS, OFFER_STATUSES } from "@/lib/constants";
import { db } from "@/lib/db";
import { createOffer, offerScope, withOfferAgents, OFFER_INCLUDE } from "@/lib/server/offer-lifecycle";
import { additionalOptionsSchema } from "@/lib/server/offer-pricing";
import { ApiError, fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { oppScope } from "@/lib/server/visibility";
import { expireDueOffers } from "@/lib/server/expiry";
import { optionalId, optionalMoney, parseBody, qp, qpEnum } from "@/lib/server/validation";

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;

    // Lazy sweeper — expire past-due ACTIVE/CONFIRMED offers before reading
    // (awaited; idempotent no-op when nothing is due).
    await expireDueOffers();

    const params = req.nextUrl.searchParams;
    const page = parseIntParam(params.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(params.get("pageSize"), 200, { min: 1, max: 500 });

    const conditions: Prisma.OfferWhereInput[] = [{ orgId, ...offerScope(user) }]; // D-021 scoped
    const status = qpEnum(req, "status", OFFER_STATUSES);
    if (status) conditions.push({ status });

    const opportunityId = qp(req, "opportunityId");
    if (opportunityId) conditions.push({ opportunityId });

    const agentId = qp(req, "agentId");
    if (agentId) conditions.push({ agentId });

    // Apartment-scoped listing (the unit's live option — at most one live
    // offer per unit, partial-unique-enforced).
    const apartmentId = qp(req, "apartmentId");
    if (apartmentId) conditions.push({ apartmentId });

    const where: Prisma.OfferWhereInput = conditions.length > 1 ? { AND: conditions } : conditions[0];
    const [offers, total] = await Promise.all([
      db.offer.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: OFFER_INCLUDE,
      }),
      db.offer.count({ where }),
    ]);

    const data = await withOfferAgents(offers);
    return ok({ data, total, page, pageSize });
  } catch (error) {
    return fail(error);
  }
}

// ── POST ──────────────────────────────────────────────────────────────────────

const createSchema = z.object({
  opportunityId: z.string().min(1, "opportunityId requis"),
  // An offer can be unit-less while the negotiation is open (DRAFT price /
  // terms only) — the hold starts at the earliest ACTIVE with an apartmentId.
  apartmentId: optionalId,
  // W1-2 money law (the reservations POST contract): non-negative DZD.
  // Phase 10: the itemized path supersedes the manual amount when an
  // apartmentId is present (the engine computes finalTotal from the unit's
  // CURRENT price + parking + options − discount).
  amount: optionalMoney,
  paymentPlan: z.enum(APARTMENT_PAYMENT_PLANS).nullable().optional(),
  terms: z.string().trim().max(1000).nullable().optional(),
  expiresAt: z.coerce.date().nullable().optional(),
  // Create directly ACTIVE (requires expiresAt — service-enforced). A
  // discount beyond the agent lane routes to PENDING_APPROVAL instead (the
  // hold is NEVER taken behind an undecided discount — service law).
  activate: z.boolean().optional(),
  // ── Phase 10 (A4) — the itemized commercial proposal ──
  discountAmount: optionalMoney,
  additionalOptions: additionalOptionsSchema.nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    // Any authenticated role may create an offer (reservation POST parity);
    // the referenced opportunity must be in the caller's scope (D-021).
    const user = await requireUser();
    const orgId = user.orgId;
    const body = await parseBody(req, createSchema);

    const opportunity = await db.opportunity.findFirst({
      where: { id: body.opportunityId, orgId, ...oppScope(user) },
      select: { id: true, leadId: true, title: true, stage: true },
    });
    if (!opportunity) throw new ApiError(404, "Opportunité introuvable", "OPPORTUNITY_NOT_FOUND");

    const { offer } = await createOffer(user, opportunity, body, req);
    const [withAgent] = await withOfferAgents([offer]);
    return ok({ offer: withAgent }, 201);
  } catch (error) {
    return fail(error);
  }
}
