// ASAS — POST /api/offers/:id/cancel (W1-A1, P1): the manager's reason-gated
// cancellation (DRAFT/ACTIVE/CONFIRMED → CANCELLED) — the reason is REQUIRED
// (422 REASON_REQUIRED; consigned in the audit), the provisional hold is
// released (apartment back to AVAILABLE, guarded in-tx). Authority: MANAGER+
// (reservation-cancel parity). Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { applyOfferAction, findOffer, offerScope, withOfferAgents } from "@/lib/server/offer-lifecycle";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const cancelSchema = z.object({
  reason: z.string().trim().max(500).optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const body = await parseBody(req, cancelSchema);
    const { offer: updated } = await applyOfferAction(user, offer, "cancel", body, req);
    const [withAgent] = await withOfferAgents([updated]);
    return ok({ offer: withAgent });
  } catch (error) {
    return fail(error);
  }
}
