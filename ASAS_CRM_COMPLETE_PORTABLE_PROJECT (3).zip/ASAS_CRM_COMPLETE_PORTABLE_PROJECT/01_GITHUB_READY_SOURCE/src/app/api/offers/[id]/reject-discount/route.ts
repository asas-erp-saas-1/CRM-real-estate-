// ASAS — POST /api/offers/:id/reject-discount (Phase 10, A4): the approver
// refuses the requested discount (PENDING_APPROVAL → DRAFT for revision; the
// decision + mandatory motive are recorded). Authority: same lane law as
// approval. Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { applyOfferAction, findOffer, offerScope, withOfferAgents } from "@/lib/server/offer-lifecycle";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const rejectSchema = z.object({
  reason: z.string().trim().min(1).max(500),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requirePermission("offers.approve");
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const body = await parseBody(req, rejectSchema);
    const { offer: updated } = await applyOfferAction(user, offer, "reject_discount", body, req);
    const [withAgent] = await withOfferAgents([updated]);
    return ok({ offer: withAgent });
  } catch (error) {
    return fail(error);
  }
}
