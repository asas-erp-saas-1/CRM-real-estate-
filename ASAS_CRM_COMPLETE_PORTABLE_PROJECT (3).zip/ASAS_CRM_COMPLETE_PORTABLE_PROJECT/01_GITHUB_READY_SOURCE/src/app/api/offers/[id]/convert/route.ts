// ASAS — POST /api/offers/:id/convert (W1-A1, P1): the EXPLICIT conversion of
// a CONFIRMED offer into a Reservation — ONE transaction: offer CONVERTED +
// convertedReservationId link + apartment OPTIONED → RESERVED + the
// reservation row (through the same guard sequence POST /api/reservations
// applies: live-hold check, terminal-row revive with the dependents guard,
// one-live-hold-per-deal, stage advance). Authority: MANAGER+ (reservation
// closure parity). An offer NEVER silently becomes a reservation — this is
// the only door. Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { applyOfferAction, findOffer, offerScope, withOfferAgents } from "@/lib/server/offer-lifecycle";
import { reservationDto } from "@/lib/server/reservation-dto";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const result = await applyOfferAction(user, offer, "convert", {}, req);
    const [withAgent] = await withOfferAgents([result.offer]);
    // The created reservation rides the shared role-aware DTO (the convert
    // authority is MANAGER+, so the row passes through unchanged — the DTO is
    // the single serialization choke point, kept for contract symmetry).
    return ok({ offer: withAgent, reservation: reservationDto(user, result.reservation ?? {}) });
  } catch (error) {
    return fail(error);
  }
}
