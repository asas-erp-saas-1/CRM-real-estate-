// ASAS — POST /api/offers/:id/submit-approval (Phase 10, A4): the responsible
// rep submits the discounted proposal for the discount decision
// (DRAFT → PENDING_APPROVAL; no hold involved). Authority: the responsible
// agent OR MANAGER+. Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { applyOfferAction, findOffer, offerScope, withOfferAgents } from "@/lib/server/offer-lifecycle";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const { offer: updated } = await applyOfferAction(user, offer, "submit_approval", {}, req);
    const [withAgent] = await withOfferAgents([updated]);
    return ok({ offer: withAgent });
  } catch (error) {
    return fail(error);
  }
}
