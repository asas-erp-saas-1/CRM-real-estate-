// ASAS — Offer detail (W1-A1, P1).
// GET   /api/offers/:id — org-scoped detail (foreign ids resolve 404 —
//        byte-identical to ghosts, mandate §15).
// PATCH /api/offers/:id — edit while DRAFT/ACTIVE (amount / paymentPlan /
//        terms / expiresAt / apartmentId, with the before/after audit trail;
//        an ACTIVE offer's unit change transfers the provisional hold
//        atomically). Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { APARTMENT_PAYMENT_PLANS } from "@/lib/constants";
import {
  findOffer,
  offerScope,
  updateOffer,
  withOfferAgents,
} from "@/lib/server/offer-lifecycle";
import { additionalOptionsSchema } from "@/lib/server/offer-pricing";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { optionalId, optionalMoney, parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

// ── GET ───────────────────────────────────────────────────────────────────────

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");
    const [withAgent] = await withOfferAgents([offer]);
    return ok({ offer: withAgent });
  } catch (error) {
    return fail(error);
  }
}

// ── PATCH ─────────────────────────────────────────────────────────────────────

const patchSchema = z.object({
  apartmentId: optionalId,
  amount: optionalMoney,
  paymentPlan: z.enum(APARTMENT_PAYMENT_PLANS).nullable().optional(),
  terms: z.string().trim().max(1000).nullable().optional(),
  expiresAt: z.coerce.date().nullable().optional(),
  // ── Phase 10 (A4) — the itemized edit (DRAFT-only; recomposed against the
  //  FROZEN snapshot base by the service). ──
  discountAmount: optionalMoney,
  additionalOptions: additionalOptionsSchema.nullable().optional(),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    // D-021 — scoped findFirst: foreign offers are 404.
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const body = await parseBody(req, patchSchema);
    const { offer: updated } = await updateOffer(user, offer, body, req);
    const [withAgent] = await withOfferAgents([updated]);
    return ok({ offer: withAgent });
  } catch (error) {
    return fail(error);
  }
}
