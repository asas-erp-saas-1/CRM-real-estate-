// ASAS — POST /api/offers/:id/respond (Phase 10, A4): records the CUSTOMER's
// response on a PRESENTED (ACTIVE) offer — the client's NO closes it as
// REJECTED (terminal, hold released, response + optional note recorded).
// The client's YES is the existing confirm action (CONFIRMED — client
// commitment); this route carries the decline path. Authority: the
// responsible agent OR MANAGER+. Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { applyOfferAction, findOffer, offerScope, withOfferAgents } from "@/lib/server/offer-lifecycle";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const respondSchema = z.object({
  response: z.literal("REJECTED"),
  note: z.string().trim().max(500).optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const body = await parseBody(req, respondSchema);
    // Only the decline rides this surface — acceptance is the confirm action.
    const { offer: updated } = await applyOfferAction(user, offer, "reject_customer", { reason: body.note }, req);
    const [withAgent] = await withOfferAgents([updated]);
    return ok({ offer: withAgent });
  } catch (error) {
    return fail(error);
  }
}
