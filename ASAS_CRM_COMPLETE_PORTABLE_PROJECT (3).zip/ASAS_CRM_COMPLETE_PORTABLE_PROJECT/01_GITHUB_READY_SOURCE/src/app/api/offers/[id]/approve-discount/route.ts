// ASAS — POST /api/offers/:id/approve-discount (Phase 10, A4): the approver
// clears the discounted proposal (PENDING_APPROVAL → APPROVED). Authority:
// MANAGER+ within the manager lane; OWNER/ADMIN above it (a manager cannot
// clear an exceptional discount — offer-pricing.ts lane law). The approval
// motive is REQUIRED and consigned. Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { applyOfferAction, findOffer, offerScope, withOfferAgents } from "@/lib/server/offer-lifecycle";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const approveSchema = z.object({
  reason: z.string().trim().min(1).max(500),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    // The catalog gate (MANAGER+ rank floor); the LANE authority (manager vs
    // owner) is checked inside the lifecycle against the org's policy.
    const user = await requirePermission("offers.approve");
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const body = await parseBody(req, approveSchema);
    const { offer: updated } = await applyOfferAction(user, offer, "approve_discount", body, req);
    const [withAgent] = await withOfferAgents([updated]);
    return ok({ offer: withAgent });
  } catch (error) {
    return fail(error);
  }
}
