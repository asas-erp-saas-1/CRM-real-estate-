// ASAS — POST /api/offers/:id/revise (Phase 10, A4): creates a NEW version of
// a presented/cleared/declined/expired offer with a FRESH pricing snapshot
// (Journey G — the original stays intact as history; the chain link
// supersededById points forward). A live old offer releases its hold and
// closes CANCELLED(superseded) in the SAME transaction. Authority: the
// responsible agent OR MANAGER+. Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { findOffer, offerScope, reviseOffer, withOfferAgents } from "@/lib/server/offer-lifecycle";
import { additionalOptionsSchema } from "@/lib/server/offer-pricing";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { optionalMoney, parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const reviseSchema = z.object({
  discountAmount: optionalMoney,
  additionalOptions: additionalOptionsSchema.nullable().optional(),
  paymentPlan: z.string().trim().max(40).nullable().optional(),
  terms: z.string().trim().max(1000).nullable().optional(),
  expiresAt: z.coerce.date().nullable().optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const body = await parseBody(req, reviseSchema);
    const { offer: revised, superseded } = await reviseOffer(user, offer, body, req);
    const [withAgent] = await withOfferAgents([revised]);
    return ok({ offer: withAgent, superseded }, 201);
  } catch (error) {
    return fail(error);
  }
}
