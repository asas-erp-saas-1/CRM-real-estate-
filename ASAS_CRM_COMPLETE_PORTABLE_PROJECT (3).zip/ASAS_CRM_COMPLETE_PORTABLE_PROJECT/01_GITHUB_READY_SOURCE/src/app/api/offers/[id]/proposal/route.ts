// ASAS — GET /api/offers/:id/proposal (Phase 10, A4): the client-presentation
// payload — the agency identity, the project/unit context, the frozen itemized
// pricing snapshot, the commercial terms + validity, and the version chain.
// Scope: offerScope (the D-021 law) — a proposal is readable by exactly who
// may read the offer. NO confidential fields ride this surface: no commission,
// no margin, no internal costs (the §5-A6-D law — those never leave the
// reservation economics surfaces).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { offerScope } from "@/lib/server/offer-lifecycle";
import { parseOptions } from "@/lib/server/offer-pricing";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

/** The presentation read model — richer than OFFER_INCLUDE (unit spec +
 * project context + developer), used ONLY by this document surface. */
const PROPOSAL_INCLUDE = {
  opportunity: {
    select: { id: true, title: true, stage: true, leadId: true, lead: { select: { id: true, fullName: true, phone: true, email: true } } },
  },
  apartment: {
    select: {
      id: true,
      code: true,
      unitType: true,
      rooms: true,
      bedrooms: true,
      bathrooms: true,
      surface: true,
      totalSurface: true,
      floorNumber: true,
      orientation: true,
      view: true,
      finishing: true,
      deliveryStatus: true,
      parking: true,
      parkingPrice: true,
      paymentPlan: true,
      building: {
        select: {
          name: true,
          project: {
            select: {
              id: true,
              name: true,
              nameAr: true,
              city: true,
              district: true,
              address: true,
              status: true,
              deliveryDate: true,
              developer: { select: { name: true, nameAr: true } },
            },
          },
        },
      },
    },
  },
} as const;

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    // The scoped read (org + D-021 scope — same authority as every offer read).
    const offer = await db.offer.findFirst({
      where: { id, orgId, ...offerScope(user) },
      select: {
        id: true,
        version: true,
        status: true,
        createdAt: true,
        presentedAt: true,
        confirmedAt: true,
        expiresAt: true,
        paymentPlan: true,
        terms: true,
        basePrice: true,
        parkingPrice: true,
        additionalOptions: true,
        discountAmount: true,
        discountPercent: true,
        finalTotal: true,
        amount: true,
        discountStatus: true,
        discountApprovedAt: true,
        discountNote: true,
        customerResponse: true,
        customerResponseNote: true,
        respondedAt: true,
        opportunityId: true,
        agentId: true,
        ...PROPOSAL_INCLUDE,
      },
    });
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    // The agency + rep identities for the document header.
    const [org, rep] = await Promise.all([
      db.organization.findUnique({ where: { id: orgId }, select: { name: true } }),
      offer.agentId
        ? db.user.findUnique({ where: { id: offer.agentId }, select: { name: true, phone: true, email: true } })
        : null,
    ]);

    // The version chain — every revision with its frozen totals (the
    // proposal's interpretable history, §5-A4-G).
    const chainRows = await db.offer.findMany({
      where: { orgId, opportunityId: offer.opportunityId },
      select: {
        id: true,
        version: true,
        status: true,
        finalTotal: true,
        amount: true,
        createdAt: true,
        presentedAt: true,
      },
      orderBy: { version: "asc" },
    });

    const apartment = offer.apartment;
    const project = apartment?.building?.project ?? null;

    return ok({
      offer: {
        id: offer.id,
        version: offer.version,
        status: offer.status,
        createdAt: offer.createdAt,
        presentedAt: offer.presentedAt,
        confirmedAt: offer.confirmedAt,
        expiresAt: offer.expiresAt,
        paymentPlan: offer.paymentPlan,
        terms: offer.terms,
        // The frozen itemized snapshot (null fields = the legacy manual path)
        pricing: {
          basePrice: offer.basePrice,
          parkingPrice: offer.parkingPrice,
          additionalOptions: parseOptions(offer.additionalOptions),
          discountAmount: offer.discountAmount,
          discountPercent: offer.discountPercent,
          finalTotal: offer.finalTotal ?? offer.amount,
        },
        discount: {
          status: offer.discountStatus,
          approvedAt: offer.discountApprovedAt,
          note: offer.discountNote,
        },
        customerResponse: offer.customerResponse,
        customerResponseNote: offer.customerResponseNote,
        respondedAt: offer.respondedAt,
      },
      agency: org ? { name: org.name } : null,
      client: offer.opportunity?.lead ?? null,
      representative: rep,
      unit: apartment
        ? {
            code: apartment.code,
            unitType: apartment.unitType,
            rooms: apartment.rooms,
            bedrooms: apartment.bedrooms,
            bathrooms: apartment.bathrooms,
            surface: apartment.surface,
            totalSurface: apartment.totalSurface,
            floorNumber: apartment.floorNumber,
            orientation: apartment.orientation,
            view: apartment.view,
            finishing: apartment.finishing,
            parking: apartment.parking,
            parkingPrice: apartment.parkingPrice,
            paymentPlan: apartment.paymentPlan,
            building: apartment.building?.name ?? null,
          }
        : null,
      project: project
        ? {
            name: project.name,
            nameAr: project.nameAr,
            city: project.city,
            district: project.district,
            address: project.address,
            status: project.status,
            deliveryDate: project.deliveryDate,
            developer: project.developer ? { name: project.developer.name, nameAr: project.developer.nameAr } : null,
          }
        : null,
      versionChain: chainRows.map((r) => ({
        id: r.id,
        version: r.version,
        status: r.status,
        finalTotal: r.finalTotal ?? r.amount ?? null,
        createdAt: r.createdAt,
        presentedAt: r.presentedAt,
        isCurrent: r.id === offer.id,
      })),
    });
  } catch (error) {
    return fail(error);
  }
}
