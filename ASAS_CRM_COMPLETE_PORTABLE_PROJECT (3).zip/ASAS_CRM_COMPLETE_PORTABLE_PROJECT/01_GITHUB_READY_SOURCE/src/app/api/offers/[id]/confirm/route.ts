// ASAS — POST /api/offers/:id/confirm (W1-A1, P1): the client's commitment is
// recorded (ACTIVE → CONFIRMED, confirmedAt stamped; the hold continues).
// The live clock is a prerequisite — a past-due option is refused (422
// OFFER_EXPIRED; the sweeper owns its death). Authority: the responsible
// agent OR MANAGER+. Domain law: src/lib/server/offer-lifecycle.ts.
import type { NextRequest } from "next/server";
import { applyOfferAction, findOffer, offerScope, withOfferAgents } from "@/lib/server/offer-lifecycle";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const offer = await findOffer(user.orgId, id, offerScope(user));
    if (!offer) throw new ApiError(404, "Offre introuvable", "OFFER_NOT_FOUND");

    const { offer: updated } = await applyOfferAction(user, offer, "confirm", {}, req);
    const [withAgent] = await withOfferAgents([updated]);
    return ok({ offer: withAgent });
  } catch (error) {
    return fail(error);
  }
}
