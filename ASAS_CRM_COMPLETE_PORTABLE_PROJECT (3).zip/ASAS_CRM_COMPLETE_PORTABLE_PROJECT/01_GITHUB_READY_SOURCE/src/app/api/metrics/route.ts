// GET /api/metrics — operational metrics (P2/W1 Agent 1 + W4 Agent 5).
//
// ADMIN-and-above only: per-route latencies and request volumes are
// operational metadata that doubles as an attack-surface map (which routes
// exist, which are hot) — it does not belong on a public probe. The public
// /api/health keeps only booleans + coarse process posture.
//
// Single-instance law: the numbers describe THIS process (the deployment
// model documented since P1). A horizontal deployment needs a shared store —
// out of P2 scope by explicit mission rule (no Redis by default).
//
// Response: ObsSnapshot & { dbLatencyMs, memory }.
// Cache-Control: no-store — metrics are point-in-time by definition.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { getObsSnapshot } from "@/lib/server/obs";
import { notificationCache } from "@/lib/server/notification-cache";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";

export async function GET(_req: NextRequest) {
  try {
    await requirePermission("metrics.view");
    let dbLatencyMs: number | null = null;
    const probeStart = Date.now();
    try {
      await db.$queryRaw`SELECT 1`;
      dbLatencyMs = Date.now() - probeStart;
    } catch {
      dbLatencyMs = null; // /api/health is the DB authority; here it's context
    }
    const mem = process.memoryUsage();
    return ok({
      ...getObsSnapshot(),
      dbLatencyMs,
      // P2/W3 — the notification cache's effectiveness (hit/miss + entries),
      // same single-instance law as the rest of the snapshot.
      notificationCache: notificationCache.stats(),
      memory: {
        rssMb: Math.round(mem.rss / (1024 * 1024)),
        heapUsedMb: Math.round(mem.heapUsed / (1024 * 1024)),
        heapTotalMb: Math.round(mem.heapTotal / (1024 * 1024)),
      },
    });
  } catch (error) {
    return fail(error);
  }
}
