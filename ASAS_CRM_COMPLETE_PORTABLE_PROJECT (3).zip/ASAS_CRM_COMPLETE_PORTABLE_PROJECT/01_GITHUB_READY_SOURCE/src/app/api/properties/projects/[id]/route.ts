// GET /api/properties/projects/:id — project detail with buildings, their
// full apartment inventories, and the P18 field assignments (Équipe terrain).
// 404 when outside the org.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;

    const project = await db.project.findFirst({
      where: { id, orgId: user.orgId },
      include: {
        developer: { select: { id: true, name: true, phone: true, email: true } },
        assignments: {
          orderBy: { createdAt: "asc" },
          include: { user: { select: { id: true, name: true, role: true } } }, // P18 (D-025)
        },
        buildings: {
          orderBy: { name: "asc" },
          include: { apartments: { orderBy: { code: "asc" } } },
        },
      },
    });
    if (!project) throw new ApiError(404, "Projet introuvable", "PROJECT_NOT_FOUND");

    return ok({ project });
  } catch (error) {
    return fail(error);
  }
}
