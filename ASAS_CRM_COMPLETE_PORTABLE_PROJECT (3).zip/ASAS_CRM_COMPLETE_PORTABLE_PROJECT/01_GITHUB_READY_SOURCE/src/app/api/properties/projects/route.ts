// GET /api/properties/projects — all projects with developer and inventory
// counts (buildings, apartments, available, reserved, sold).
// POST /api/properties/projects — Phase 10 R2: create a project under an
// existing org developer (the authoring surface; MANAGER+ via
// properties.manage). Domain law: src/lib/server/property-authoring.ts
// (org-uniqueness on the project name — the CSV import resolves projects BY
// NAME, so a same-named pair in one org is refused at creation).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { PROJECT_STATUSES } from "@/lib/constants";
import { createProject } from "@/lib/server/property-authoring";
import { fail, ok, requireUser } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

export async function GET(_req: NextRequest) {
  try {
    const user = await requireUser();

    const projects = await db.project.findMany({
      where: { orgId: user.orgId },
      orderBy: { createdAt: "desc" },
      include: {
        developer: { select: { id: true, name: true, nameAr: true } },
        buildings: { select: { apartments: { select: { status: true } } } },
      },
    });

    const data = projects.map(({ buildings, ...project }) => {
      const apartments = buildings.flatMap((b) => b.apartments);
      return {
        ...project,
        developer: project.developer,
        counts: {
          buildings: buildings.length,
          apartments: apartments.length,
          available: apartments.filter((a) => a.status === "AVAILABLE").length,
          reserved: apartments.filter((a) => a.status === "RESERVED").length,
          sold: apartments.filter((a) => a.status === "SOLD").length,
        },
      };
    });

    return ok({ data });
  } catch (error) {
    return fail(error);
  }
}

const bodySchema = z.object({
  developerId: z.string().min(1),
  name: z.string().trim().min(1).max(160),
  nameAr: z.string().trim().max(160).nullable().optional(),
  city: z.string().trim().max(80).optional(),
  district: z.string().trim().max(120).nullable().optional(),
  address: z.string().trim().max(240).nullable().optional(),
  description: z.string().trim().max(2000).nullable().optional(),
  status: z.enum(PROJECT_STATUSES).optional(),
  deliveryDate: z.string().datetime().nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("properties.manage");
    const body = await parseBody(req, bodySchema);
    const project = await createProject({
      orgId: user.orgId,
      actor: user,
      developerId: body.developerId,
      name: body.name,
      nameAr: body.nameAr ?? null,
      city: body.city,
      district: body.district ?? null,
      address: body.address ?? null,
      description: body.description ?? null,
      status: body.status,
      deliveryDate: body.deliveryDate ?? null,
    });
    return ok({ project }, 201);
  } catch (error) {
    return fail(error);
  }
}
