// POST   /api/properties/projects/:id/assignments { userId } — P18 (D-025):
//        the CEO/executive assigns a FIELD_REP to the project ("when the CEO or
//        president adds a delegate, they assign them the necessary projects and
//        responsibilities"). MANAGER+ only; the assignee MUST carry the FIELD_REP
//        role (executives act by rank, not by assignment — the president may
//        conduct field visits personally) AND be active (directive §17.2: an
//        inactive user never receives new assignments). Audited PROJECT_ASSIGNED
//        with the §17.2 "affected future work" fact: the field-pending visits
//        this assignment now covers (P20-C — the §17.3 exception resolution).
//        API-06: the assignment row + its audit commit as ONE transaction (F-06).
// DELETE /api/properties/projects/:id/assignments?userId=… — unassign
//        (MANAGER+, audited PROJECT_UNASSIGNED with the affected future work:
//        field-pending visits on the project + remaining eligible field reps —
//        0 remaining + pending > 0 = the §17.3 exception is now live and the
//        dashboard surfaces it). Cascade-free by design: the join row dies, the
//        assignment history lives in the audit trail.
import type { NextRequest } from "next/server";
import { z } from "zod";
import { FIELD_PENDING_STATUSES } from "@/lib/constants";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { isPrismaKnownError, parseBody, qp } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const assignSchema = z.object({
  userId: z.string().trim().min(1, "Utilisateur requis"),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const actor = await requirePermission("properties.manage"); // assignment is executive work
    const { id } = await ctx.params;
    const body = await parseBody(req, assignSchema);

    const project = await db.project.findFirst({
      where: { id, orgId: actor.orgId },
      select: { id: true, name: true },
    });
    if (!project) throw new ApiError(404, "Projet introuvable", "PROJECT_NOT_FOUND");

    // The assignee must be an org user with the FIELD_REP role — and ACTIVE
    // (§17.2: "Never allow an inactive user to receive new assignments").
    const assignee = await db.user.findFirst({
      where: { id: body.userId, orgId: actor.orgId },
      select: { id: true, name: true, role: true, active: true },
    });
    if (!assignee) throw new ApiError(404, "Utilisateur introuvable", "USER_NOT_FOUND");
    if (assignee.role !== "FIELD_REP") {
      throw new ApiError(
        422,
        "Seul un représentant terrain (FIELD_REP) peut être assigné à un projet — la direction agit par rang, sans assignation",
        "ASSIGNEE_NOT_FIELD_REP",
      );
    }
    if (!assignee.active) {
      throw new ApiError(
        422,
        "Ce représentant terrain est désactivé — réactivez-le avant de lui confier un projet",
        "ASSIGNEE_INACTIVE",
      );
    }

    // §17.2 "affected future work": the field-pending visits this assignment
    // takes under field coverage (also the §17.3 exception it resolves when the
    // project previously had no eligible rep).
    const pendingVisitsCovered = await db.visit.count({
      where: {
        orgId: actor.orgId,
        projectId: project.id,
        status: { in: [...FIELD_PENDING_STATUSES] },
      },
    });

    try {
      // API-06 (F-06): the assignment row + its PROJECT_ASSIGNED audit commit
      // as ONE transaction — no committed assignment without its trail
      // (the single-row mutation + audit house law; the join row neither
      // lives nor dies alone).
      const assignment = await db.$transaction(async (tx) => {
        const row = await tx.projectAssignment.create({
          data: { orgId: actor.orgId, projectId: project.id, userId: assignee.id },
          include: { user: { select: { id: true, name: true, role: true } } },
        });
        await logAudit({
          orgId: actor.orgId,
          actor,
          action: "PROJECT_ASSIGNED",
          entity: "PROJECT",
          entityId: project.id,
          before: null,
          after: {
            assignmentId: row.id,
            userId: assignee.id,
            userName: assignee.name,
            projectId: project.id,
            pendingVisitsCovered,
          },
        }, tx);
        return row;
      });
      return ok({ assignment }, 201);
    } catch (error) {
      if (isPrismaKnownError(error, "P2002")) {
        throw new ApiError(409, "Ce représentant terrain est déjà assigné à ce projet", "ALREADY_ASSIGNED");
      }
      throw error;
    }
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  try {
    const actor = await requirePermission("properties.manage");
    const { id } = await ctx.params;
    const userId = qp(req, "userId");
    if (!userId) throw new ApiError(422, "Paramètre 'userId' requis", "USER_ID_REQUIRED");

    const project = await db.project.findFirst({
      where: { id, orgId: actor.orgId },
      select: { id: true, name: true },
    });
    if (!project) throw new ApiError(404, "Projet introuvable", "PROJECT_NOT_FOUND");

    const assignment = await db.projectAssignment.findUnique({
      where: { projectId_userId: { projectId: project.id, userId } },
      select: { id: true, userId: true },
    });
    if (!assignment) throw new ApiError(404, "Assignation introuvable", "ASSIGNMENT_NOT_FOUND");

    // §17.2 "affected future work", captured BEFORE the join row dies: the
    // field-pending visits losing THIS rep's coverage, and how many OTHER
    // eligible field reps remain (0 + pending > 0 = the §17.3 exception goes
    // live — the dashboard attention metric will surface it to MANAGER+).
    const [pendingVisitsAffected, remainingFieldReps] = await Promise.all([
      db.visit.count({
        where: { orgId: actor.orgId, projectId: project.id, status: { in: [...FIELD_PENDING_STATUSES] } },
      }),
      db.projectAssignment.count({
        where: {
          projectId: project.id,
          userId: { not: userId },
          user: { active: true, role: "FIELD_REP" },
        },
      }),
    ]);

    // API-06 (F-06): the join-row delete + its PROJECT_UNASSIGNED audit commit
    // as ONE transaction (the §17.2 "affected future work" facts above are
    // captured pre-delete as the before-payload — the trail preserves them
    // precisely because the row itself is about to vanish).
    await db.$transaction(async (tx) => {
      await tx.projectAssignment.delete({ where: { id: assignment.id } });
      await logAudit({
        orgId: actor.orgId,
        actor,
        action: "PROJECT_UNASSIGNED",
        entity: "PROJECT",
        entityId: project.id,
        before: {
          assignmentId: assignment.id,
          userId: assignment.userId,
          projectId: project.id,
          pendingVisitsAffected,
          remainingFieldReps,
        },
        after: null,
      }, tx);
    });
    return ok({ deleted: true, id: assignment.id });
  } catch (error) {
    return fail(error);
  }
}
