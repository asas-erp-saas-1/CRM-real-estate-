// POST /api/properties/developers — Phase 10 R2: create a developer/promoter
// record (the authoring surface; MANAGER+ via properties.manage). Domain law:
// src/lib/server/property-authoring.ts (org-uniqueness + audit in ONE tx).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { createDeveloper } from "@/lib/server/property-authoring";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

const bodySchema = z.object({
  name: z.string().trim().min(1).max(160),
  nameAr: z.string().trim().max(160).nullable().optional(),
  contactPerson: z.string().trim().max(120).nullable().optional(),
  phone: z.string().trim().max(40).nullable().optional(),
  email: z.string().trim().email().max(160).nullable().optional(),
  notes: z.string().trim().max(2000).nullable().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("properties.manage");
    const body = await parseBody(req, bodySchema);
    const developer = await createDeveloper({
      orgId: user.orgId,
      actor: user,
      name: body.name,
      nameAr: body.nameAr ?? null,
      contactPerson: body.contactPerson ?? null,
      phone: body.phone ?? null,
      email: body.email ?? null,
      notes: body.notes ?? null,
    });
    return ok({ developer }, 201);
  } catch (error) {
    return fail(error);
  }
}
