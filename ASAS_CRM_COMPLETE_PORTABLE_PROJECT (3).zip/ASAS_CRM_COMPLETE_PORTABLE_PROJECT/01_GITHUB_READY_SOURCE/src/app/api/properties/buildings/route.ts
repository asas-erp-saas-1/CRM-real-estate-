// POST /api/properties/buildings — Phase 10 R2: create a building/block inside
// an existing org project (the authoring surface; MANAGER+ via
// properties.manage). Domain law: src/lib/server/property-authoring.ts
// (per-project name uniqueness — backstopped in-race by the new DB index).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { createBuilding } from "@/lib/server/property-authoring";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

const bodySchema = z.object({
  projectId: z.string().min(1),
  name: z.string().trim().min(1).max(80),
  floors: z.number().int().min(1).max(100).optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("properties.manage");
    const body = await parseBody(req, bodySchema);
    const building = await createBuilding({
      orgId: user.orgId,
      actor: user,
      projectId: body.projectId,
      name: body.name,
      floors: body.floors,
    });
    return ok({ building }, 201);
  } catch (error) {
    return fail(error);
  }
}
