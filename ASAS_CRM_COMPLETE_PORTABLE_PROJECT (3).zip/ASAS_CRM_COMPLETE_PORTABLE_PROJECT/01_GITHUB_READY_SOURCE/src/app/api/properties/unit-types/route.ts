// GET /api/properties/unit-types — domain constant (UNIT_TYPES).
import type { NextRequest } from "next/server";
import { UNIT_TYPES } from "@/lib/constants";
import { fail, ok, requireUser } from "@/lib/server/session";

export async function GET(_req: NextRequest) {
  try {
    await requireUser();
    return ok({ data: UNIT_TYPES });
  } catch (error) {
    return fail(error);
  }
}
