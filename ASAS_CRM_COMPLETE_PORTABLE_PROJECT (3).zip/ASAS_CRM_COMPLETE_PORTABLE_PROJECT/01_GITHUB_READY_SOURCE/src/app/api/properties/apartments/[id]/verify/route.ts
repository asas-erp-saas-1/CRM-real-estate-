// POST /api/properties/apartments/:id/verify — Phase 10 (A2): the freshness
// re-anchor (an authorized user confirms the listed availability is still
// true — distinct from a transition; §5-A2-D "verified availability").
import type { NextRequest } from "next/server";
import { z } from "zod";
import { verifyApartmentAvailability } from "@/lib/server/inventory-events";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const bodySchema = z.object({
  note: z.string().trim().max(500).optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requirePermission("inventory.change_price");
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, bodySchema);

    const verifiedAt = await verifyApartmentAvailability(orgId, id, user, body.note ?? null);
    return ok({ apartmentId: id, availabilityVerifiedAt: verifiedAt.toISOString() });
  } catch (error) {
    return fail(error);
  }
}
