// POST /api/properties/apartments/:id/price — Phase 10 (A2): the traced price
// update (price + priceUpdatedAt + UnitPriceEvent + audit, ONE transaction).
// Domain law: src/lib/server/inventory-events.ts (updateApartmentPrice —
// R2: the audit row commits INSIDE the service transaction).
// R2 — money-cap closure: MAX_MONEY_DZD enforced at the validation layer
// (the money.ts single-source law; a 1e15 price no longer commits).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { MAX_MONEY_DZD } from "@/lib/money";
import { updateApartmentPrice } from "@/lib/server/inventory-events";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const bodySchema = z.object({
  price: z.number().positive().max(MAX_MONEY_DZD),
  parkingPrice: z.number().min(0).max(MAX_MONEY_DZD).nullable().optional(),
  reason: z.string().trim().max(500).optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requirePermission("inventory.change_price");
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, bodySchema);

    const apartment = await db.apartment.findFirst({ where: { id, orgId }, select: { id: true, code: true } });
    if (!apartment) throw new ApiError(404, "Appartement introuvable", "APARTMENT_NOT_FOUND");

    const { previousPrice, newPrice } = await updateApartmentPrice({
      orgId,
      apartmentId: id,
      newPrice: body.price,
      actor: user,
      reason: body.reason ?? null,
      parkingPrice: body.parkingPrice,
    });

    return ok({ apartmentId: id, previousPrice, newPrice });
  } catch (error) {
    return fail(error);
  }
}
