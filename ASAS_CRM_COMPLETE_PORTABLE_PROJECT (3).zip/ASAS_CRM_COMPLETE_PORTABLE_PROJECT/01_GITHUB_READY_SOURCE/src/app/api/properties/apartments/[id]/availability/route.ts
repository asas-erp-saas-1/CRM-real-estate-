// POST /api/properties/apartments/:id/availability — Phase 10 (A2): the
// VALIDATED manual availability transition (the explicit console law:
// MANUAL_APARTMENT_TRANSITIONS + live-hold guards). Domain law:
// src/lib/server/inventory-events.ts (transitionApartmentStatus — R2: the
// audit row commits INSIDE the service transaction; this route stays a thin
// HTTP adapter: zod + permission + scoped lookup + ok/fail).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { APARTMENT_STATUSES } from "@/lib/constants";
import { db } from "@/lib/db";
import { transitionApartmentStatus } from "@/lib/server/inventory-events";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const bodySchema = z.object({
  status: z.enum(APARTMENT_STATUSES),
  reason: z.string().trim().max(500).optional(),
  /** default true — a manual transition re-anchors availability freshness. */
  verifyAvailability: z.boolean().optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requirePermission("inventory.change_availability");
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, bodySchema);

    // Scoped existence check (org isolation — the service re-reads in-tx too).
    const apartment = await db.apartment.findFirst({ where: { id, orgId }, select: { id: true, code: true } });
    if (!apartment) throw new ApiError(404, "Appartement introuvable", "APARTMENT_NOT_FOUND");

    const { from, to } = await transitionApartmentStatus({
      orgId,
      apartmentId: id,
      to: body.status,
      actor: user,
      reason: body.reason ?? null,
      verifyAvailability: body.verifyAvailability,
    });

    return ok({ apartmentId: id, from, to });
  } catch (error) {
    return fail(error);
  }
}
