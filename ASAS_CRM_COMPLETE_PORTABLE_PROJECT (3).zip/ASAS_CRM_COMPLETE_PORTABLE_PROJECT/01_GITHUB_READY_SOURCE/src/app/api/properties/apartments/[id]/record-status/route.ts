// POST /api/properties/apartments/:id/record-status — Phase 10 R2: the
// publishing/approval lifecycle transition (DRAFT → PENDING_REVIEW →
// APPROVED / REJECTED / WITHDRAWN / ARCHIVED — the law table lives in
// constants.ts APARTMENT_RECORD_TRANSITIONS; the domain service is
// property-authoring.ts). MANAGER+ via properties.manage; every transition
// is audited; APPROVED re-anchors freshness (the reviewer vouches for the
// record's truth).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { APARTMENT_RECORD_STATUSES } from "@/lib/constants";
import { transitionRecordStatus } from "@/lib/server/property-authoring";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";

type Ctx = { params: Promise<{ id: string }> };

const bodySchema = z.object({
  recordStatus: z.enum(APARTMENT_RECORD_STATUSES),
  reason: z.string().trim().max(500).optional(),
});

export async function POST(req: NextRequest, ctx: Ctx) {
  try {
    const user = await requirePermission("properties.manage");
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, bodySchema);

    const { from, to } = await transitionRecordStatus({
      orgId,
      actor: user,
      apartmentId: id,
      to: body.recordStatus,
      reason: body.reason ?? null,
    });

    return ok({ apartmentId: id, from, to });
  } catch (error) {
    return fail(error);
  }
}
