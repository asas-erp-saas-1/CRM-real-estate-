// GET /api/properties/apartments — inventory search: status/unitType/project/
// building/price/surface/parking/code filters + pagination.
// POST /api/properties/apartments — Phase 10 R2: interactive unit creation
// (the authoring wizard's core act; MANAGER+ via properties.manage). Domain
// law: src/lib/server/property-authoring.ts — money-capped, spec-validated,
// event-anchored (availability + initial price), record lifecycle starts at
// DRAFT (submit=true → PENDING_REVIEW; publication is the explicit review
// transition, never silent).
//
// P47 (W2 — F2 closure): the `orphanHolds` derived filter — held units
// (RESERVED/OPTIONED) with NO ACTIVE reservation behind them: the R5 legacy
// data's decision surface. Derived ONLY (no schema change, no writes); the
// same inventory state any role already sees in the grid — the filter is a
// convenience for the management decision card, not an authorization
// boundary.
// Phase C Wave 3E — server-side sorting w/ an EXPLICIT allow-list (the leads
// SORT_FIELDS pattern): dataset-wide correctness for the paginated flat mode
// (the sort applies BEFORE pagination; org scoping untouched). Fields outside
// the list (or a garbage dir) fall back to the DEFAULT order — the historical
// [buildingId asc, code asc] — never a raw orderBy injection. Callers that
// omit the params behave exactly as before (contract v1 unchanged for them).
//
// R2 — the catalog boundary: SALES_AGENT / FIELD_REP queries hard-filter
// recordStatus = APPROVED (the spec's "approved inventory" contract — the
// data layer is the boundary, not the UI). MANAGER+ sees every record status
// and may filter explicitly (recordStatus param, closed vocabulary).
import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { z } from "zod";
import {
  APARTMENT_PAYMENT_PLANS,
  APARTMENT_RECORD_STATUSES,
  APARTMENT_STATUSES,
  UNIT_DELIVERY_STATUSES,
  UNIT_FINISHING,
  UNIT_TYPES,
  UNIT_VIEWS,
  atLeastRole,
} from "@/lib/constants";
import { db } from "@/lib/db";
import { MAX_MONEY_DZD } from "@/lib/money";
import { createApartment } from "@/lib/server/property-authoring";
import { fail, ok, parseIntParam, requireUser } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody, qp, qpBool, qpEnum, qpNumber } from "@/lib/server/validation";

/** Phase C Wave 3E — the server-supported sort fields (the unit table's
 *  sortable columns; the allow-list IS the contract). */
const SORT_FIELDS = ["code", "unitType", "surface", "floorNumber", "bedrooms", "price", "status"] as const;
const SORT_DIRS = ["asc", "desc"] as const;

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const params = req.nextUrl.searchParams;

    const page = parseIntParam(params.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(params.get("pageSize"), 25, { min: 1, max: 100 });

    const conditions: Prisma.ApartmentWhereInput[] = [{ orgId }];

    // R2 — the catalog boundary: floor roles see APPROVED inventory only
    // (server-side, no opt-out — the spec's "approved inventory" law).
    // MANAGER+ keeps full visibility and may filter explicitly.
    if (!atLeastRole(user.role, "MANAGER")) {
      conditions.push({ recordStatus: "APPROVED" });
    } else {
      const recordStatus = qpEnum(req, "recordStatus", APARTMENT_RECORD_STATUSES);
      if (recordStatus) conditions.push({ recordStatus });
    }

    const status = qpEnum(req, "status", APARTMENT_STATUSES);
    if (status) conditions.push({ status });

    // P47 (W2) — the R5 orphan-holds predicate: held ∧ nothing active behind
    // it. A unit with an EXPIRED/CANCELLED history only is ALSO an orphan (the
    // hold outlived its reservation — same decision-awaiting class).
    // W1-A1 (P1): an OPTIONED unit backed by a LIVE offer (ACTIVE/CONFIRMED)
    // is NOT an orphan — the provisional hold is the offer's; only units whose
    // status no live offer explains remain decision-awaiting.
    if (qpBool(req, "orphanHolds")) {
      conditions.push({
        status: { in: ["RESERVED", "OPTIONED"] },
        reservations: { none: { status: "ACTIVE" } },
        offers: { none: { status: { in: ["ACTIVE", "CONFIRMED"] } } },
      });
    }

    // D7-R3 — exact-id lookup (audit-view target resolution). Additive and
    // backward-compatible: the condition INTERSECTS the org scope above, so
    // an id from another organization yields an empty page, never a leak.
    const id = qp(req, "id");
    if (id) conditions.push({ id });

    const unitType = qpEnum(req, "unitType", UNIT_TYPES);
    if (unitType) conditions.push({ unitType });

    const projectId = qp(req, "projectId");
    if (projectId) conditions.push({ building: { projectId } });

    const buildingId = qp(req, "buildingId");
    if (buildingId) conditions.push({ buildingId });

    const minPrice = qpNumber(req, "minPrice");
    if (minPrice !== null) conditions.push({ price: { gte: minPrice } });
    const maxPrice = qpNumber(req, "maxPrice");
    if (maxPrice !== null) {
      conditions.push({ price: minPrice !== null ? { gte: minPrice, lte: maxPrice } : { lte: maxPrice } });
    }

    const minSurface = qpNumber(req, "minSurface");
    if (minSurface !== null) conditions.push({ surface: { gte: minSurface } });
    const maxSurface = qpNumber(req, "maxSurface");
    if (maxSurface !== null) {
      conditions.push({ surface: minSurface !== null ? { gte: minSurface, lte: maxSurface } : { lte: maxSurface } });
    }

    if (qpBool(req, "parking")) conditions.push({ parking: true });

    const bedroomsMin = qpNumber(req, "bedroomsMin");
    if (bedroomsMin !== null) conditions.push({ bedrooms: { gte: bedroomsMin } });

    const query = qp(req, "query");
    if (query) {
      conditions.push({
        OR: [{ code: { contains: query } }, { building: { name: { contains: query } } }],
      });
    }

    const where: Prisma.ApartmentWhereInput = conditions.length > 1 ? { AND: conditions } : conditions[0];

    // Phase C Wave 3E — the sort allow-list: an allowed field+dir REPLACES the
    // default order (with `id asc` as the stable tiebreaker — deterministic
    // pages across requests); anything else keeps the historical default.
    const sortField = (SORT_FIELDS as readonly string[]).includes(params.get("sort") ?? "")
      ? (params.get("sort") as (typeof SORT_FIELDS)[number])
      : null;
    const sortDir = (SORT_DIRS as readonly string[]).includes(params.get("dir") ?? "")
      ? (params.get("dir") as (typeof SORT_DIRS)[number])
      : null;
    const orderBy: Prisma.ApartmentOrderByWithRelationInput[] =
      sortField && sortDir ? [{ [sortField]: sortDir }, { id: "asc" }] : [{ buildingId: "asc" }, { code: "asc" }];

    const [total, apartments] = await Promise.all([
      db.apartment.count({ where }),
      db.apartment.findMany({
        where,
        orderBy,
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: {
          building: {
            select: { id: true, name: true, projectId: true, project: { select: { id: true, name: true, district: true } } },
          },
        },
      }),
    ]);

    return ok({ data: apartments, total, page, pageSize });
  } catch (error) {
    return fail(error);
  }
}

// ── POST — the interactive unit creation (Phase 10 R2) ──────────────────────

const createSchema = z.object({
  buildingId: z.string().min(1),
  code: z.string().trim().min(1).max(40),
  unitType: z.enum(UNIT_TYPES),
  rooms: z.number().int().min(0).max(30).optional(),
  bedrooms: z.number().int().min(0).max(30).optional(),
  bathrooms: z.number().int().min(0).max(20).nullable().optional(),
  surface: z.number().positive().max(100000),
  totalSurface: z.number().min(0).max(100000).nullable().optional(),
  floorNumber: z.number().int().min(-5).max(80).optional(),
  orientation: z.enum(["N", "NE", "E", "SE", "S", "SW", "W", "NW"]).nullable().optional(),
  parking: z.boolean().optional(),
  balcony: z.boolean().nullable().optional(),
  terrace: z.boolean().nullable().optional(),
  view: z.enum(UNIT_VIEWS).nullable().optional(),
  finishing: z.enum(UNIT_FINISHING).nullable().optional(),
  deliveryStatus: z.enum(UNIT_DELIVERY_STATUSES).nullable().optional(),
  price: z.number().positive().max(MAX_MONEY_DZD),
  parkingPrice: z.number().min(0).max(MAX_MONEY_DZD).nullable().optional(),
  paymentPlan: z.enum(APARTMENT_PAYMENT_PLANS).nullable().optional(),
  status: z.enum(APARTMENT_STATUSES).optional(),
  notes: z.string().trim().max(5000).nullable().optional(),
  submit: z.boolean().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const user = await requirePermission("properties.manage");
    const body = await parseBody(req, createSchema);
    const apartment = await createApartment({
      orgId: user.orgId,
      actor: user,
      buildingId: body.buildingId,
      code: body.code,
      unitType: body.unitType,
      rooms: body.rooms,
      bedrooms: body.bedrooms,
      bathrooms: body.bathrooms ?? null,
      surface: body.surface,
      totalSurface: body.totalSurface ?? null,
      floorNumber: body.floorNumber,
      orientation: body.orientation ?? null,
      parking: body.parking,
      balcony: body.balcony ?? null,
      terrace: body.terrace ?? null,
      view: body.view ?? null,
      finishing: body.finishing ?? null,
      deliveryStatus: body.deliveryStatus ?? null,
      price: body.price,
      parkingPrice: body.parkingPrice ?? null,
      paymentPlan: body.paymentPlan ?? null,
      status: body.status,
      notes: body.notes ?? null,
      submit: body.submit,
    });
    return ok({ apartment }, 201);
  } catch (error) {
    return fail(error);
  }
}
