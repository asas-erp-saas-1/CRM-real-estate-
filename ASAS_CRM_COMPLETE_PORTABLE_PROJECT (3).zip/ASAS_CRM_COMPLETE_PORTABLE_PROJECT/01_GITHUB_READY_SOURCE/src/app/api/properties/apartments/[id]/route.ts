// PATCH /api/properties/apartments/:id — spec/status/price/notes with
// data-integrity guards (master prompt §27): SOLD → AVAILABLE/OPTIONED is
// forbidden unless the body carries force:true (422 FORBIDDEN_TRANSITION).
// RESERVED → any other status is refused while a LIVE reservation exists
// (P4 coherence guard — W2.2/master audit DOM-D2: ACTIVE or CLOSURE_REQUESTED,
// a pending closure is still a hold; API-09: the live-reservation count runs
// INSIDE the mutation transaction, immediately before the update — no TOCTOU
// window on the release path). Price and status changes are audit-logged with
// before/after snapshots.
// P47 (W2): the mutation is MANAGER+-gated server-side.
// Phase 10 (A1/A2): the structured spec fields join the editable set (all
// nullable — explicit unknown, never fabricated); every price change stamps
// priceUpdatedAt + leaves a UnitPriceEvent; every status change re-anchors
// availabilityVerifiedAt + leaves a UnitAvailabilityEvent (source MANUAL) —
// all in the SAME transaction (F-06).
import type { NextRequest } from "next/server";
import { z } from "zod";
import {
  APARTMENT_STATUSES,
  FORBIDDEN_APARTMENT_TRANSITIONS,
  UNIT_FINISHING,
  UNIT_VIEWS,
  UNIT_DELIVERY_STATUSES,
} from "@/lib/constants";
import { MAX_MONEY_DZD } from "@/lib/money";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { injectTxFault } from "@/lib/server/faults";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { parseBody } from "@/lib/server/validation";
import { recordAvailabilityEvent, recordPriceEvent } from "@/lib/server/inventory-events";

type Ctx = { params: Promise<{ id: string }> };

const patchSchema = z.object({
  status: z.enum(APARTMENT_STATUSES).optional(),
  // API-05 (opaque 500): Apartment.price is NON-nullable, but optionalNumber
  // also accepted null — `data.price = null` then died on a
  // PrismaClientValidationError (opaque 500). Null is now rejected at the
  // validation layer (422 VALIDATION_ERROR); "" keeps the house "absent"
  // convention (emptyToUndef — forms submit "" for "no change"). Deliberately
  // NO min() here: the INVALID_PRICE guard below stays the sole 0/negative
  // authority (its semantics preserved byte-for-byte).
  price: z.preprocess((v) => (v === "" ? undefined : v), z.number().positive().max(MAX_MONEY_DZD).optional()),
  notes: z.string().trim().max(5000).nullable().optional(),
  force: z.boolean().optional(),
  // ── Phase 10 (A1) — structured specification fields (nullable, explicit
  // unknown; "" → undefined = "no change", null = "clear to unknown").
  bathrooms: z.preprocess((v) => (v === "" ? undefined : v), z.number().int().min(0).max(20).nullable().optional()),
  totalSurface: z.preprocess((v) => (v === "" ? undefined : v), z.number().min(0).max(100000).nullable().optional()),
  balcony: z.boolean().nullable().optional(),
  terrace: z.boolean().nullable().optional(),
  view: z.enum(UNIT_VIEWS).nullable().optional(),
  finishing: z.enum(UNIT_FINISHING).nullable().optional(),
  deliveryStatus: z.enum(UNIT_DELIVERY_STATUSES).nullable().optional(),
  parkingPrice: z.preprocess((v) => (v === "" ? undefined : v), z.number().min(0).max(MAX_MONEY_DZD).nullable().optional()),
});

export async function PATCH(req: NextRequest, ctx: Ctx) {
  try {
    // P47 (W2) — the server-side rank gate (was bare requireUser: the UI's
    // canEdit was the only barrier — a live-caught authorization gap).
    const user = await requirePermission("properties.manage");
    const orgId = user.orgId;
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    const apartment = await db.apartment.findFirst({ where: { id, orgId } });
    if (!apartment) throw new ApiError(404, "Appartement introuvable", "APARTMENT_NOT_FOUND");

    const statusChanged = body.status !== undefined && body.status !== apartment.status;
    // (null is structurally impossible post-API-05 — the schema rejects it —
    // so the old `body.price !== null` clause is dead and dropped)
    const priceChanged = body.price !== undefined && body.price !== apartment.price;

    // Transition guard — a SOLD unit cannot silently return to market.
    if (statusChanged) {
      const forbidden = FORBIDDEN_APARTMENT_TRANSITIONS[apartment.status];
      if (forbidden?.includes(body.status!) && body.force !== true) {
        throw new ApiError(
          422,
          `Transition interdite : ${apartment.status} → ${body.status}. Un appartement vendu ne peut pas revenir au marché sans confirmation explicite (force=true).`,
          "FORBIDDEN_TRANSITION",
          { from: apartment.status, to: body.status, requiresForce: true },
        );
      }
    }

    // P4 — reservation coherence: a LIVE reservation owns the RESERVED
    // status (W2.2 / master audit DOM-D2: ACTIVE or CLOSURE_REQUESTED — a
    // pending closure is still a hold on the unit); releasing it here would
    // desync the unit from its reservation (the sweeper/booking tx keep
    // that pairing invariant). API-09 (TOCTOU): the live-reservation count
    // moved INSIDE the mutation transaction (see below) — captured here as
    // a plain predicate; the reservation read now happens after the tx
    // opens, immediately before the write, so a hold minted between an
    // outside check and the update can no longer slip through the release
    // window (the opportunities/[id] W2.3/B3 in-tx guard law).
    const releasesReservedUnit =
      statusChanged &&
      apartment.status === "RESERVED" &&
      body.status !== "RESERVED" &&
      body.force !== true;

    if (priceChanged && body.price! <= 0) {
      throw new ApiError(422, "Le prix doit être positif", "INVALID_PRICE");
    }

    const data: Record<string, unknown> = {};
    if (body.status !== undefined) data.status = body.status;
    if (body.price !== undefined) data.price = body.price;
    if (body.notes !== undefined) data.notes = body.notes;
    // Phase 10 (A1) — the spec fields ride the same guarded mutation.
    if (body.bathrooms !== undefined) data.bathrooms = body.bathrooms;
    if (body.totalSurface !== undefined) data.totalSurface = body.totalSurface;
    if (body.balcony !== undefined) data.balcony = body.balcony;
    if (body.terrace !== undefined) data.terrace = body.terrace;
    if (body.view !== undefined) data.view = body.view;
    if (body.finishing !== undefined) data.finishing = body.finishing;
    if (body.deliveryStatus !== undefined) data.deliveryStatus = body.deliveryStatus;
    if (body.parkingPrice !== undefined) data.parkingPrice = body.parkingPrice;
    // Phase 10 (A2) — the traceability stamps.
    if (priceChanged) data.priceUpdatedAt = new Date();
    if (statusChanged) {
      data.availabilityVerifiedAt = new Date(); // a manual flip re-anchors freshness
      data.verifiedById = user.id; // R2 — the responsible user anchor
      data.statusReason = body.notes?.slice(0, 500) ?? apartment.statusReason;
    }

    // G5-P3-5 (F-06): status/price mutation + its audit trail commit as ONE
    // transaction (the §41 fault-injection hook proves the rollback contract:
    // no committed status change without its APARTMENT_STATUS_CHANGED row).
    const updated = await db.$transaction(async (tx) => {
      // API-09 — the release guard re-reads the live holds INSIDE the
      // transaction, right before the write it protects (race-free: the
      // count and the update can no longer straddle a concurrent booking).
      if (releasesReservedUnit) {
        const liveReservations = await tx.reservation.count({
          where: { apartmentId: apartment.id, orgId, status: { in: ["ACTIVE", "CLOSURE_REQUESTED"] } },
        });
        if (liveReservations > 0) {
          throw new ApiError(
            422,
            `Réservation en cours sur cet appartement (${liveReservations} — ACTIVE ou clôture demandée). Annulez ou laissez expirer la réservation avant de changer le statut, ou forcez explicitement (force=true).`,
            "APARTMENT_RESERVATION_ACTIVE",
            { reservationCount: liveReservations, requiresForce: true },
          );
        }
      }
      const row = await tx.apartment.update({
        where: { id: apartment.id },
        data,
        include: {
          building: {
            select: { id: true, name: true, projectId: true, project: { select: { id: true, name: true, district: true } } },
          },
        },
      });
      injectTxFault(req, "apartments-patch");

      // Phase 10 (A2) — the event stream entries (same commit as the flips).
      if (priceChanged) {
        await recordPriceEvent(tx, {
          orgId,
          apartmentId: apartment.id,
          previousPrice: apartment.price,
          newPrice: row.price,
          actorId: user.id,
          reason: body.notes?.slice(0, 500) ?? null,
          source: "MANUAL",
        });
      }
      if (statusChanged) {
        await recordAvailabilityEvent(tx, {
          orgId,
          apartmentId: apartment.id,
          from: apartment.status,
          to: row.status,
          actorId: user.id,
          reason: body.notes?.slice(0, 500) ?? (body.force === true ? "transition forcée" : null),
          source: "MANUAL",
        });
      }
      if (priceChanged) {
        await logAudit({
          orgId,
          actor: user,
          action: "PRICE_CHANGED",
          entity: "APARTMENT",
          entityId: apartment.id,
          before: { price: apartment.price },
          after: { price: row.price },
        }, tx);
      }
      if (statusChanged) {
        await logAudit({
          orgId,
          actor: user,
          action: "APARTMENT_STATUS_CHANGED",
          entity: "APARTMENT",
          entityId: apartment.id,
          before: { status: apartment.status },
          after: { status: row.status, forced: body.force === true },
        }, tx);
        // Surface forced RESERVED-releases in the audit trail explicitly.
        if (apartment.status === "RESERVED" && row.status !== "RESERVED" && body.force === true) {
          await logAudit({
            orgId,
            actor: user,
            action: "APARTMENT_RESERVED_RELEASED",
            entity: "APARTMENT",
            entityId: apartment.id,
            before: { status: apartment.status },
            after: { status: row.status, forced: true },
          }, tx);
        }
      }
      return row;
    });

    return ok({ apartment: updated });
  } catch (error) {
    return fail(error);
  }
}
