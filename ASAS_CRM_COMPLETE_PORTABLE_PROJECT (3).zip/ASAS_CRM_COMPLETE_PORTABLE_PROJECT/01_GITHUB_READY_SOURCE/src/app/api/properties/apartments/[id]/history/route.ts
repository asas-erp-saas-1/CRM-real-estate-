// GET /api/properties/apartments/:id/history — Phase 10 (A2): the unit's
// availability + price event streams (append-only history, actor-joined) +
// the freshness classification. properties.view floor (the inventory the
// caller may already see; confidential fields never ride this surface).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { classifyFreshness, getFreshnessPolicy } from "@/lib/server/inventory-events";
import { ApiError, fail, ok } from "@/lib/server/session";
import { requireUser } from "@/lib/server/session";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, ctx: Ctx) {
  try {
    const user = await requireUser();
    const orgId = user.orgId;
    const { id } = await ctx.params;

    const apartment = await db.apartment.findFirst({
      where: { id, orgId },
      select: {
        id: true,
        code: true,
        status: true,
        price: true,
        priceUpdatedAt: true,
        availabilityVerifiedAt: true,
        statusReason: true,
        updatedAt: true,
      },
    });
    if (!apartment) throw new ApiError(404, "Appartement introuvable", "APARTMENT_NOT_FOUND");

    const policy = await getFreshnessPolicy(orgId);
    const [availabilityEvents, priceEvents, users] = await Promise.all([
      db.unitAvailabilityEvent.findMany({
        where: { orgId, apartmentId: id },
        orderBy: { createdAt: "desc" },
        take: 100,
      }),
      db.unitPriceEvent.findMany({
        where: { orgId, apartmentId: id },
        orderBy: { createdAt: "desc" },
        take: 100,
      }),
      db.user.findMany({ where: { orgId }, select: { id: true, name: true } }),
    ]);

    const nameOf = (actorId: string | null) =>
      actorId ? (users.find((u) => u.id === actorId)?.name ?? null) : null;

    return ok({
      apartment: {
        ...apartment,
        freshness: classifyFreshness(apartment.availabilityVerifiedAt, policy),
      },
      freshnessPolicy: policy,
      availabilityEvents: availabilityEvents.map((e) => ({ ...e, actorName: nameOf(e.actorId) })),
      priceEvents: priceEvents.map((e) => ({ ...e, actorName: nameOf(e.actorId) })),
    });
  } catch (error) {
    return fail(error);
  }
}
