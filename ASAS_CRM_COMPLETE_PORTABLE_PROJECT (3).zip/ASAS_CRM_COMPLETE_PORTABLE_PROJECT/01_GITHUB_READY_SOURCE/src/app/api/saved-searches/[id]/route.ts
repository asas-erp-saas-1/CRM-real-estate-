// DELETE /api/saved-searches/:id — remove one of the current user's saved
//        searches — audited SAVED_SEARCH_DELETED (API-08: the owner-scoped
//        delete used to commit with ZERO trail; the name rides the payload)
//        in the SAME transaction as the row delete (API-06 — F-06).
// PATCH   /api/saved-searches/:id — toggle sharing { visibility: PRIVATE|TEAM }
//        (owner only — the row must belong to the caller; audited P7-2;
//        row + audit commit as ONE transaction — API-06/F-06).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { parseBody } from "@/lib/server/validation";

const patchSchema = z.object({
  visibility: z.enum(["PRIVATE", "TEAM"]),
});

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const body = await parseBody(req, patchSchema);

    // Owner-only: colleagues can apply a shared search but never re-scope it.
    const existing = await db.savedSearch.findFirst({
      where: { id, orgId: user.orgId, userId: user.id },
      select: { id: true, name: true, visibility: true },
    });
    if (!existing) throw new ApiError(404, "Recherche sauvegardée introuvable", "NOT_FOUND");

    if (existing.visibility === body.visibility) {
      return ok({ id: existing.id, visibility: existing.visibility });
    }

    // API-06 (F-06): the visibility flip + its audit row commit as ONE
    // transaction (single-row mutation + trail — the house law).
    const updated = await db.$transaction(async (tx) => {
      const row = await tx.savedSearch.update({
        where: { id: existing.id },
        data: { visibility: body.visibility },
        select: { id: true, visibility: true },
      });
      await logAudit({
        orgId: user.orgId,
        actor: user,
        action: body.visibility === "TEAM" ? "SAVED_SEARCH_SHARED" : "SAVED_SEARCH_PRIVATIZED",
        entity: "SAVED_SEARCH",
        entityId: existing.id,
        before: { name: existing.name, visibility: existing.visibility },
        after: { name: existing.name, visibility: body.visibility },
      }, tx);
      return row;
    });

    return ok({ id: updated.id, visibility: updated.visibility });
  } catch (error) {
    return fail(error);
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const existing = await db.savedSearch.findFirst({
      where: { id, orgId: user.orgId, userId: user.id },
      select: { id: true, name: true, visibility: true },
    });
    if (!existing) throw new ApiError(404, "Recherche sauvegardée introuvable", "NOT_FOUND");
    // API-06 + API-08: the delete + its audit row commit as ONE transaction.
    // The delete previously committed with ZERO trail — the row died
    // invisibly while every sibling mutation audits (SAVED_SEARCH_SHARED /
    // PRIVATIZED existed; the removal itself was dark). SAVED_SEARCH_DELETED
    // carries the search name (the trail names what was removed) plus its
    // visibility at removal time; after: null — nothing remains.
    await db.$transaction(async (tx) => {
      await tx.savedSearch.delete({ where: { id: existing.id } });
      await logAudit({
        orgId: user.orgId,
        actor: user,
        action: "SAVED_SEARCH_DELETED",
        entity: "SAVED_SEARCH",
        entityId: existing.id,
        before: { name: existing.name, visibility: existing.visibility },
        after: null,
      }, tx);
    });
    return ok({ deleted: true });
  } catch (error) {
    return fail(error);
  }
}
