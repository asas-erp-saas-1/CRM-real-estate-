// GET  /api/saved-searches — list saved searches for the leads toolbar:
//        the user's own searches + TEAM-shared searches from org colleagues
//        (P7-2 sharing; rows carry mine/ownerName so the UI can partition).
// POST /api/saved-searches — save { name, entity, filters, visibility? }
//        (upsert by name for the current user; visibility PRIVATE|TEAM;
//        API-06: row + audit commit as ONE transaction — F-06).
import type { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/server/audit";
import { fail, ok, requireUser } from "@/lib/server/session";
import { parseBody, qp } from "@/lib/server/validation";

const ENTITY_VALUES = ["leads"] as const;
const VISIBILITY_VALUES = ["PRIVATE", "TEAM"] as const;

const listSchema = z.object({
  entity: z.enum(ENTITY_VALUES).default("leads"),
});

const createSchema = z.object({
  name: z.string().trim().min(1, "Nom requis").max(80),
  entity: z.enum(ENTITY_VALUES).default("leads"),
  visibility: z.enum(VISIBILITY_VALUES).default("PRIVATE"),
  filters: z.record(z.string(), z.unknown()), // opaque client filter set (validated on apply)
});

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const { entity } = listSchema.parse({ entity: qp(req, "entity") ?? "leads" });
    // Own searches + org-shared ones from colleagues (read-apply for others).
    const searches = await db.savedSearch.findMany({
      where: { orgId: user.orgId, entity, OR: [{ userId: user.id }, { visibility: "TEAM" }] },
      orderBy: { updatedAt: "desc" },
      select: {
        id: true,
        name: true,
        entity: true,
        visibility: true,
        filters: true,
        createdAt: true,
        updatedAt: true,
        userId: true,
        owner: { select: { id: true, name: true } },
      },
    });
    return ok({
      data: searches.map((s) => ({
        id: s.id,
        name: s.name,
        entity: s.entity,
        visibility: s.visibility,
        filters: JSON.parse(s.filters) as Record<string, unknown>,
        createdAt: s.createdAt,
        updatedAt: s.updatedAt,
        mine: s.userId === user.id,
        ownerName: s.owner?.name ?? null,
      })),
    });
  } catch (error) {
    return fail(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireUser();
    const body = await parseBody(req, createSchema);

    // Upsert by (user, entity, name) — saving the same name replaces the filter set.
    const existing = await db.savedSearch.findFirst({
      where: { orgId: user.orgId, userId: user.id, entity: body.entity, name: body.name },
      select: { id: true, visibility: true },
    });
    const filters = JSON.stringify(body.filters);
    // API-06 (F-06): the upsert + its sharing audit row commit as ONE
    // transaction — no committed search without its SAVED_SEARCH_* trail
    // (the single-row mutation + audit house law).
    const saved = await db.$transaction(async (tx) => {
      const row = existing
        ? await tx.savedSearch.update({
            where: { id: existing.id },
            data: { filters, visibility: body.visibility },
          })
        : await tx.savedSearch.create({
            data: {
              orgId: user.orgId,
              userId: user.id,
              name: body.name,
              entity: body.entity,
              visibility: body.visibility,
              filters,
            },
          });

      if (existing?.visibility !== body.visibility) {
        await logAudit({
          orgId: user.orgId,
          actor: user,
          action: body.visibility === "TEAM" ? "SAVED_SEARCH_SHARED" : "SAVED_SEARCH_PRIVATIZED",
          entity: "SAVED_SEARCH",
          entityId: row.id,
          before: existing ? { visibility: existing.visibility } : null,
          after: { visibility: body.visibility, name: body.name },
        }, tx);
      }
      return row;
    });

    return ok(
      { id: saved.id, name: saved.name, visibility: body.visibility },
      existing ? 200 : 201,
    );
  } catch (error) {
    return fail(error);
  }
}
