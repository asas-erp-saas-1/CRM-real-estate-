// GET /api/analytics/acquisition — the Phase 11 A5 acquisition analytics read
// (analytics.view, MANAGER+ — D-021). Precise metric definitions (every number
// answers ONE question; the window applies to LEAD CREATION):
//
//   window        = leads created in the last `days` days (default 30, 7..365).
//   bySource      = per acquisition origin: leads · converted · conversion
//                   rate (converted/leads) · won value (sum of WON opportunity
//                   values of those leads, via leadId — covers legacy rows
//                   without the new sourceOrigin stamp too).
//   byCampaign    = same shape per structured campaign (campaignId), plus the
//                   planned budget (the ROI denominator — never a fabricated
//                   spend: null stays null).
//   contactDelays = distribution of first-response time (createdAt→lastContactAt)
//                   buckets for CONTACTED leads in window + never-contacted
//                   count. The "how fast are we?" law.
//   repFunnel     = the CURRENT operational snapshot (not windowed): eligible
//                   reps' live workload + lifetime conversions (the routing
//                   console's own numbers — one definition).
//   lostReasons   = CLOSED_LOST leads in window grouped by recorded reason
//                   (free text, truncated — "UNRECORDED" when absent; the G3
//                   coded taxonomy lives on Opportunity, not Lead).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { eligibleAssignees } from "@/lib/server/routing";
import { fail, ok, parseIntParam } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";

const WON_OPP_STAGES = ["CLOSED_WON"];

export async function GET(req: NextRequest) {
  try {
    // D-021 — analytics are management-only metrics (same floor as
    // /api/analytics: analytics.view, MANAGER+).
    const user = await requirePermission("analytics.view");
    const orgId = user.orgId;
    const days = parseIntParam(req.nextUrl.searchParams.get("days"), 30, { min: 7, max: 365 });
    const since = new Date(Date.now() - days * 86_400_000);

    // Windowed population + lifetime-relevant aggregates in a few batched
    // reads (no per-row loops over relations).
    const windowLeads = await db.lead.findMany({
      where: { orgId, createdAt: { gte: since } },
      select: {
        id: true, source: true, campaignId: true, status: true, lastContactAt: true,
        createdAt: true, lostReason: true, ownerId: true, archived: true,
      },
      take: 5000,
    });
    const windowIds = windowLeads.map((l) => l.id);

    const [wonOpps, campaigns] = await Promise.all([
      db.opportunity.findMany({
        where: { orgId, leadId: { in: windowIds }, stage: { in: WON_OPP_STAGES } },
        select: { leadId: true, value: true },
      }),
      db.campaign.findMany({ where: { orgId }, select: { id: true, name: true, code: true, channel: true, status: true, budgetPlanned: true } }),
    ]);
    const repFunnel = await eligibleAssignees(orgId);
    const wonByLead = new Map<string, number>();
    for (const o of wonOpps) wonByLead.set(o.leadId, (wonByLead.get(o.leadId) ?? 0) + (o.value ?? 0));

    interface SourceAgg {
      key: string;
      leads: number;
      converted: number;
      wonValue: number;
    }
    const agg = (keyOf: (l: (typeof windowLeads)[number]) => string | null): SourceAgg[] => {
      const by = new Map<string, SourceAgg>();
      for (const l of windowLeads) {
        const key = keyOf(l);
        if (key === null) continue;
        const row = by.get(key) ?? { key, leads: 0, converted: 0, wonValue: 0 };
        row.leads += 1;
        if (l.status === "CONVERTED") row.converted += 1;
        row.wonValue += wonByLead.get(l.id) ?? 0;
        by.set(key, row);
      }
      return [...by.values()].sort((a, b) => b.leads - a.leads);
    };
    const rate = (row: SourceAgg) => (row.leads > 0 ? Math.round((row.converted / row.leads) * 1000) / 10 : 0);

    // Contact-delay buckets (minutes; never-contacted is its own bucket).
    const BUCKETS = [
      { key: "under_1h", label: "< 1 h", max: 60 },
      { key: "h1_4", label: "1–4 h", max: 240 },
      { key: "h4_24", label: "4–24 h", max: 1440 },
      { key: "d1_3", label: "1–3 j", max: 4320 },
      { key: "over_3d", label: "> 3 j", max: Number.POSITIVE_INFINITY },
    ] as const;
    const contacted = windowLeads.filter((l) => l.lastContactAt !== null);
    const delays = BUCKETS.map((b, i) => {
      const min = i === 0 ? 0 : BUCKETS[i - 1].max;
      const count = contacted.filter(
        (l) => (l.lastContactAt!.getTime() - l.createdAt.getTime()) / 60_000 >= min &&
          (l.lastContactAt!.getTime() - l.createdAt.getTime()) / 60_000 < b.max,
      ).length;
      return { key: b.key, label: b.label, count };
    });
    const neverContacted = windowLeads.filter((l) => l.lastContactAt === null).length;
    const avgContactMinutes =
      contacted.length > 0
        ? Math.round(
            contacted.reduce((sum, l) => sum + (l.lastContactAt!.getTime() - l.createdAt.getTime()) / 60_000, 0) /
              contacted.length,
          )
        : null;

    // Lost reasons (the recorded free text, truncated — "UNRECORDED" when
    // absent; the G3 coded taxonomy is an Opportunity column, not a Lead one).
    const lost = windowLeads.filter((l) => l.status === "CLOSED_LOST");
    const reasonMap = new Map<string, number>();
    for (const l of lost) {
      const key = l.lostReason?.trim() ? l.lostReason.trim().slice(0, 80) : "UNRECORDED";
      reasonMap.set(key, (reasonMap.get(key) ?? 0) + 1);
    }

    return ok({
      days,
      bySource: agg((l) => l.source).map((r) => ({ ...r, conversionRate: rate(r) })),
      byCampaign: agg((l) => l.campaignId).map((r) => {
        const c = campaigns.find((x) => x.id === r.key);
        return {
          key: r.key,
          name: c?.name ?? null,
          code: c?.code ?? null,
          status: c?.status ?? null,
          budgetPlanned: c?.budgetPlanned ?? null,
          leads: r.leads,
          converted: r.converted,
          conversionRate: rate(r),
          wonValue: r.wonValue,
        };
      }),
      contactDelays: { buckets: delays, neverContacted, avgContactMinutes },
      repFunnel,
      lostReasons: [...reasonMap.entries()].map(([reason, count]) => ({ reason, count })).sort((a, b) => b.count - a.count),
      totals: {
        leads: windowLeads.length,
        converted: windowLeads.filter((l) => l.status === "CONVERTED").length,
        lost: lost.length,
        wonValue: [...wonByLead.values()].reduce((a, b) => a + b, 0),
      },
    });
  } catch (error) {
    return fail(error);
  }
}
