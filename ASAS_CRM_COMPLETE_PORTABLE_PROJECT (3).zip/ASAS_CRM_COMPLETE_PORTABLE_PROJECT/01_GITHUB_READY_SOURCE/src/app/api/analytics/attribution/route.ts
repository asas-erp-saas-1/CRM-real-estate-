// GET /api/analytics/attribution — source-effectiveness reporting (P2/W5 A6B).
//
// The mission's attribution questions, answered from the two record families:
//   · ORIGINAL-SOURCE funnel: per Lead.source — leads, opportunities, won
//     deals, won revenue, lead→won conversion (the classic "which channel
//     brings the customers who actually buy").
//   · MULTI-TOUCH engagement: per touch channel — inbound/outbound touch
//     counts (the "where do the conversations happen" view).
//   · CONVERSION attribution: for every won deal, the LAST INBOUND touch
//     before the winning reservation's creation (when touch history exists)
//     → the closing-channel distribution.
//
// MANAGER+ (same RBAC as the main analytics surface), org-scoped.
// Original sources are NEVER modified by this reporting (read-only), and the
// seed's historical leads (no touches) fall back gracefully: their conversion
// attribution bucket is the original source itself.
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { fail, ok } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";

export async function GET(_req: NextRequest) {
  try {
    const user = await requirePermission("analytics.view");
    const orgId = user.orgId;

    // 1. Original-source funnel: leads + opportunities + won + revenue.
    //    (Source lives on the LEAD — opportunities are attributed through
    //    their lead; the dataset scale makes in-memory aggregation right.)
    const [leadsBySource, opps, wonReservations] = await Promise.all([
      db.lead.groupBy({ by: ["source"], where: { orgId, archived: false }, _count: { _all: true } }),
      db.opportunity.findMany({
        where: { orgId, lead: { archived: false } },
        select: { lead: { select: { source: true } } },
      }),
      db.reservation.findMany({
        where: { orgId, status: "CONVERTED" },
        select: {
          amount: true,
          createdAt: true,
          opportunity: { select: { lead: { select: { id: true, source: true } } } },
        },
      }),
    ]);

    const leadCounts = new Map(leadsBySource.map((r) => [r.source, r._count._all]));
    const oppCounts = new Map<string, number>();
    for (const opp of opps) {
      const src = opp.lead?.source ?? "UNKNOWN";
      oppCounts.set(src, (oppCounts.get(src) ?? 0) + 1);
    }
    const wonAgg = new Map<string, { count: number; revenue: number }>();
    for (const res of wonReservations) {
      const src = res.opportunity?.lead?.source ?? "UNKNOWN";
      const agg = wonAgg.get(src) ?? { count: 0, revenue: 0 };
      agg.count += 1;
      agg.revenue += res.amount ?? 0;
      wonAgg.set(src, agg);
    }

    const sources = new Set<string>([...leadCounts.keys(), ...oppCounts.keys(), ...wonAgg.keys()]);
    const funnel = [...sources].map((source) => {
      const leads = leadCounts.get(source) ?? 0;
      const opps = oppCounts.get(source) ?? 0;
      const won = wonAgg.get(source)?.count ?? 0;
      const revenue = wonAgg.get(source)?.revenue ?? 0;
      return {
        source,
        leads,
        opportunities: opps,
        won,
        revenue,
        leadToWonPct: leads > 0 ? Math.round((won / leads) * 1000) / 10 : 0,
      };
    });
    funnel.sort((a, b) => b.revenue - a.revenue || b.leads - a.leads);

    // 2. Multi-touch engagement per channel.
    const touchAgg = await db.leadTouch.groupBy({
      by: ["channel", "direction"],
      where: { orgId },
      _count: { _all: true },
    });
    const engagement = new Map<string, { channel: string; inbound: number; outbound: number }>();
    for (const row of touchAgg) {
      const e = engagement.get(row.channel) ?? { channel: row.channel, inbound: 0, outbound: 0 };
      if (row.direction === "INBOUND") e.inbound += row._count._all;
      else e.outbound += row._count._all;
      engagement.set(row.channel, e);
    }
    const engagementRows = [...engagement.values()].sort(
      (a, b) => b.inbound + b.outbound - (a.inbound + a.outbound),
    );

    // 3. Conversion attribution: last INBOUND touch before each won
    //    reservation's creation (fallback: the original source).
    const wonLeadIds = wonReservations
      .map((r) => r.opportunity?.lead?.id)
      .filter((x): x is string => x != null);
    const touches = wonLeadIds.length
      ? await db.leadTouch.findMany({
          where: { orgId, leadId: { in: wonLeadIds }, direction: "INBOUND" },
          orderBy: { occurredAt: "asc" },
          select: { leadId: true, channel: true, occurredAt: true },
        })
      : [];
    // last inbound touch at-or-before each reservation's creation
    const closingChannel = new Map<string, number>();
    let attributed = 0;
    let fallback = 0;
    for (const res of wonReservations) {
      const leadId = res.opportunity?.lead?.id;
      if (!leadId) continue;
      const before = touches.filter(
        (t) => t.leadId === leadId && t.occurredAt.getTime() <= res.createdAt.getTime(),
      );
      const last = before[before.length - 1];
      if (last) {
        attributed += 1;
        closingChannel.set(last.channel, (closingChannel.get(last.channel) ?? 0) + 1);
      } else {
        fallback += 1;
        const src = res.opportunity?.lead?.source ?? "UNKNOWN";
        closingChannel.set(src, (closingChannel.get(src) ?? 0) + 1);
      }
    }

    return ok({
      funnel,
      engagement: engagementRows,
      conversionAttribution: {
        attributedTouches: attributed,
        fallbackToOriginalSource: fallback,
        closingChannels: [...closingChannel.entries()]
          .map(([channel, count]) => ({ channel, count }))
          .sort((a, b) => b.count - a.count),
      },
      generatedAt: new Date().toISOString(),
    });
  } catch (error) {
    return fail(error);
  }
}
