// GET /api/analytics?days=30 — analytics aggregates:
//   funnel            — windowed by `days` (leads created in window and their
//                       progression, opps won, visits completed, reservations)
//   bySource          — lead counts / qualified / won + won value per source (all-time)
//   byAgent          — per-owner opps, won, open pipeline value, conversion %
//   stageDurations    — CLOSED_WON avg cycle days + avg age of open opps per stage
//   pipelineByStage   — open opps count/value per pipeline stage (ordered)
//   monthlyTrend      — last 6 months: leads created, opps won + value
//   agentLeaderboard  — top 5 agents by won value
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { pct1, roundDays, salesCycleDays, totalAgeDays } from "@/lib/metrics";
import { fail, ok, parseIntParam } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { OPP_CLOSED_STAGES } from "@/lib/constants"; // R15 — shared stage set (was a local re-declaration)

const DAY_MS = 24 * 60 * 60 * 1000;

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export async function GET(req: NextRequest) {
  try {
    const user = await requirePermission("analytics.view"); // D-021 — analytics are management-only metrics (mandate §5/§8)
    const orgId = user.orgId;

    const days = parseIntParam(req.nextUrl.searchParams.get("days"), 30, { min: 1, max: 365 });
    const now = new Date();
    const since = new Date(now.getTime() - days * DAY_MS);

    // ── Funnel (window: last `days` days) ─────────────────────────────────
    const [
      leadsCreated,
      contactedLeads,
      qualifiedLeads,
      convertedLeads,
      oppsCreated,
      visitsCompleted,
      reservationsCreated,
      oppsWon,
    ] = await Promise.all([
      db.lead.count({ where: { orgId, createdAt: { gte: since } } }),
      db.lead.count({ where: { orgId, createdAt: { gte: since }, lastContactAt: { not: null } } }),
      db.lead.count({
        where: { orgId, createdAt: { gte: since }, status: { in: ["QUALIFIED", "CONVERTED"] } },
      }),
      db.lead.count({ where: { orgId, createdAt: { gte: since }, status: "CONVERTED" } }),
      db.opportunity.count({ where: { orgId, createdAt: { gte: since } } }),
      db.visit.count({ where: { orgId, status: "COMPLETED", scheduledAt: { gte: since } } }),
      db.reservation.count({ where: { orgId, createdAt: { gte: since } } }),
      db.opportunity.count({ where: { orgId, stage: "CLOSED_WON", closedAt: { gte: since } } }),
    ]);

    // ── bySource (all-time) ────────────────────────────────────────────────
    // P9-D21 (dashboards step 8) — the won-opp scan rides the house 5000 cap
    // (the same W2-3 law the dashboard's twin source-performance query uses):
    // the all-time per-source aggregation stays bounded instead of shipping
    // every won opp to JS. Identical values for current data shapes (≤5000
    // won opps); groupBy can't express the lead-source join, so the cap is the
    // sanctioned mirror of the dashboard pattern.
    const [leadsBySource, qualifiedBySource, wonOppsWithSource] = await Promise.all([
      db.lead.groupBy({ by: ["source"], where: { orgId }, _count: { _all: true } }),
      db.lead.groupBy({
        by: ["source"],
        where: { orgId, status: { in: ["QUALIFIED", "CONVERTED"] } },
        _count: { _all: true },
      }),
      db.opportunity.findMany({
        where: { orgId, stage: "CLOSED_WON" },
        select: { value: true, lead: { select: { source: true } } },
        take: 5000,
      }),
    ]);

    const qualifiedMap = new Map(qualifiedBySource.map((g) => [g.source, g._count._all]));
    const wonBySource = new Map<string, { won: number; wonValue: number }>();
    for (const opp of wonOppsWithSource) {
      const entry = wonBySource.get(opp.lead.source) ?? { won: 0, wonValue: 0 };
      entry.won += 1;
      entry.wonValue += opp.value ?? 0;
      wonBySource.set(opp.lead.source, entry);
    }
    const bySource = leadsBySource
      .map((g) => ({
        source: g.source,
        leads: g._count._all,
        qualified: qualifiedMap.get(g.source) ?? 0,
        won: wonBySource.get(g.source)?.won ?? 0,
        wonValue: wonBySource.get(g.source)?.wonValue ?? 0,
      }))
      .sort((a, b) => b.leads - a.leads);

    // ── byAgent (indexed groupBy queries, joined with users) ──────────────
    const [oppsByOwner, wonByOwner, openByOwner, users] = await Promise.all([
      db.opportunity.groupBy({ by: ["ownerId"], where: { orgId }, _count: { _all: true } }),
      db.opportunity.groupBy({
        by: ["ownerId"],
        where: { orgId, stage: "CLOSED_WON" },
        _count: { _all: true },
        _sum: { value: true },
      }),
      db.opportunity.groupBy({
        by: ["ownerId"],
        where: { orgId, stage: { notIn: [...OPP_CLOSED_STAGES] } },
        _sum: { value: true },
      }),
      db.user.findMany({ where: { orgId, active: true }, select: { id: true, name: true, role: true } }),
    ]);

    const userMap = new Map(users.map((u) => [u.id, u]));
    const oppsByOwnerMap = new Map(oppsByOwner.map((g) => [g.ownerId, g._count._all]));
    const wonByOwnerMap = new Map(wonByOwner.map((g) => [g.ownerId, { count: g._count._all, value: g._sum.value ?? 0 }]));
    const openByOwnerMap = new Map(openByOwner.map((g) => [g.ownerId, g._sum.value ?? 0]));

    const ownerIds = Array.from(
      new Set(
        [...oppsByOwnerMap.keys(), ...wonByOwnerMap.keys(), ...openByOwnerMap.keys()].filter(
          (id): id is string => id !== null
        )
      )
    );
    const byAgent = ownerIds
      .map((id) => {
        const agent = userMap.get(id);
        const opps = oppsByOwnerMap.get(id) ?? 0;
        const won = wonByOwnerMap.get(id)?.count ?? 0;
        return {
          agentId: id,
          agentName: agent?.name ?? "Non assigné",
          agentRole: agent?.role ?? null,
          opps,
          won,
          wonValue: wonByOwnerMap.get(id)?.value ?? 0,
          pipelineValue: openByOwnerMap.get(id) ?? 0,
          // D13 — WON_SHARE_ALL_TIME (see lib/metrics.ts): among ALL deals this
          // agent has ever owned, the share now CLOSED_WON.
          conversion: pct1(won, opps),
        };
      })
      .sort((a, b) => b.opps - a.opps);

    // ── stageDurations ─────────────────────────────────────────────────────
    // CLOSED_WON: avg days between createdAt and closedAt (sales cycle length).
    // Open stages: avg age (now - createdAt) of opps currently sitting there.
    // P9-D21 (dashboards step 8) — both row scans ride the house 5000 cap (the
    // W2-3 dashboard law): the date-diff averages can't be expressed as Prisma
    // groupBy/_avg (no date arithmetic in SQLite aggregates through Prisma),
    // so the bounded scan IS the fix — identical values for current data
    // shapes (≤5000 rows each), no unbounded JS-side row shipping.
    const [wonOpps, openOpps, pipeline] = await Promise.all([
      db.opportunity.findMany({
        where: { orgId, stage: "CLOSED_WON", closedAt: { not: null } },
        select: { createdAt: true, closedAt: true },
        take: 5000,
      }),
      db.opportunity.findMany({
        where: { orgId, stage: { notIn: [...OPP_CLOSED_STAGES] } },
        select: { stage: true, createdAt: true },
        take: 5000,
      }),
      db.pipeline.findFirst({ where: { orgId, isDefault: true } }),
    ]);

    const stageDurations: { stage: string; count: number; avgDays: number | null }[] = [];
    if (wonOpps.length > 0) {
      // D13 — sales-cycle length via the shared helper (closedAt − createdAt).
      const avg =
        wonOpps.reduce((acc, o) => acc + salesCycleDays(o.createdAt, o.closedAt!), 0) /
        wonOpps.length;
      stageDurations.push({
        stage: "CLOSED_WON",
        count: wonOpps.length,
        avgDays: roundDays(avg),
      });
    } else {
      stageDurations.push({ stage: "CLOSED_WON", count: 0, avgDays: null });
    }

    const openByStage = new Map<string, { count: number; totalAgeDays: number }>();
    for (const opp of openOpps) {
      const entry = openByStage.get(opp.stage) ?? { count: 0, totalAgeDays: 0 };
      entry.count += 1;
      // D13 — TOTAL_AGE semantics (see lib/metrics.ts): how long the DEAL has
      // existed, deliberately not days-in-stage (a stage's population
      // turnover answers a different question; the kanban owns that signal).
      entry.totalAgeDays += totalAgeDays(opp.createdAt, now);
      openByStage.set(opp.stage, entry);
    }
    for (const [stage, agg] of openByStage) {
      stageDurations.push({
        stage,
        count: agg.count,
        avgDays: agg.count > 0 ? Math.round(agg.totalAgeDays / agg.count) : null,
      });
    }

    // ── pipelineByStage (open opps, ordered by pipeline stage order) ───────
    const stages = pipeline
      ? await db.pipelineStage.findMany({ where: { pipelineId: pipeline.id }, orderBy: { order: "asc" } })
      : [];
    const openStageAgg = await db.opportunity.groupBy({
      by: ["stage"],
      where: { orgId, stage: { notIn: [...OPP_CLOSED_STAGES] } },
      _count: { _all: true },
      _sum: { value: true },
    });
    const stageAggMap = new Map(openStageAgg.map((g) => [g.stage, g]));
    const pipelineByStage = stages.map((s) => {
      const agg = stageAggMap.get(s.key);
      return {
        stage: s.key,
        label: s.label,
        count: agg?._count._all ?? 0,
        value: agg?._sum.value ?? 0,
      };
    });

    // ── monthlyTrend (last 6 months) ───────────────────────────────────────
    const months: { key: string; start: Date; end: Date }[] = [];
    for (let i = 5; i >= 0; i--) {
      const start = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const end = new Date(now.getFullYear(), now.getMonth() - i + 1, 0, 23, 59, 59, 999);
      months.push({ key: monthKey(start), start, end });
    }
    // W2-5 (Phase 2.1 — A6#12): the trend is computed SQL-side — one indexed
    // count/aggregate per (month, entity) instead of shipping every row of
    // the 6-month window to JS for bucketing (the window's row count was the
    // unbounded part; the response only ever needed per-month numbers).
    const [leadCounts, wonAggs] = await Promise.all([
      Promise.all(
        months.map((m) =>
          db.lead.count({
            where: { orgId, createdAt: { gte: m.start, lte: m.end } },
          }),
        ),
      ),
      Promise.all(
        months.map((m) =>
          db.opportunity.aggregate({
            where: { orgId, stage: "CLOSED_WON", closedAt: { gte: m.start, lte: m.end } },
            _count: { _all: true },
            _sum: { value: true },
          }),
        ),
      ),
    ]);
    const leadsPerMonth = new Map<string, number>();
    months.forEach((m, i) => leadsPerMonth.set(m.key, leadCounts[i] ?? 0));
    const wonPerMonth = new Map<string, { won: number; wonValue: number }>();
    months.forEach((m, i) => {
      const agg = wonAggs[i];
      wonPerMonth.set(m.key, { won: agg._count._all, wonValue: agg._sum.value ?? 0 });
    });
    const monthlyTrend = months.map((m) => ({
      month: m.key,
      leads: leadsPerMonth.get(m.key) ?? 0,
      won: wonPerMonth.get(m.key)?.won ?? 0,
      wonValue: wonPerMonth.get(m.key)?.wonValue ?? 0,
    }));

    // ── agentLeaderboard (top 5 by won value) ──────────────────────────────
    const agentLeaderboard = [...byAgent].sort((a, b) => b.wonValue - a.wonValue).slice(0, 5);

    // ── V1.9 (D-UX-040) — previous-window KPIs for period-over-period
    // deltas: the SAME window length immediately before the current one
    // ([2×days ago → days ago)). Pipeline value and cycle time are live
    // snapshots (not reconstructible historically) → no delta for them —
    // the meter-only-with-domain law. prev=0 → no chip (an infinite %
    // would be noise, not signal).
    const prevSince = new Date(now.getTime() - 2 * days * DAY_MS);
    const [prevLeads, prevOpps, prevWonValueAgg] = await Promise.all([
      db.lead.count({ where: { orgId, createdAt: { gte: prevSince, lt: since } } }),
      db.opportunity.count({ where: { orgId, createdAt: { gte: prevSince, lt: since } } }),
      db.opportunity.aggregate({
        _sum: { value: true },
        where: { orgId, stage: "CLOSED_WON", closedAt: { gte: prevSince, lt: since } },
      }),
    ]);

    // W3.5 (master audit — PERF-P2): 30s browser cache for expensive
    // aggregate GETs (the analytics cockpit fans out into ~20 org-scoped
    // aggregates). `private` keeps every proxy/CDN out (cookie-scoped
    // payload — never a shared cache); the browser alone may reuse it for
    // half a minute.
    const res = await ok({
      days,
      since: since.toISOString(),
      funnel: {
        leads: leadsCreated,
        contacted: contactedLeads,
        qualified: qualifiedLeads,
        converted: convertedLeads,
        opportunities: oppsCreated,
        visitsCompleted,
        reservations: reservationsCreated,
        won: oppsWon,
      },
      prevPeriod: {
        leads: prevLeads,
        opportunities: prevOpps,
        wonValue: prevWonValueAgg._sum.value ?? 0,
      },
      bySource,
      byAgent,
      stageDurations,
      pipelineByStage,
      monthlyTrend,
      agentLeaderboard,
    });
    res.headers.set("Cache-Control", "private, max-age=30");
    return res;
  } catch (error) {
    return fail(error);
  }
}
