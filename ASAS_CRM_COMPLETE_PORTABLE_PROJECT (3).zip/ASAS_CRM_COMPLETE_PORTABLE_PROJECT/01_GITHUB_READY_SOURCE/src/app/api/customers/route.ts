// GET /api/customers — the customer book (P2.2 — Task 2-a: the relationship
// management surface; the missing product page between Pipeline and Visits).
//
// THE customer list: every Contact (a converted lead's durable commercial
// identity) in the caller's D-021 visibility scope, enriched with the
// relationship-health signals a daily user triages by — NOT a flat table of
// names and numbers:
//
//   • journey stage (the CJ engine — same single source of truth as the
//     journey worklist and the drawer rail: one function, one truth),
//   • live deal value + open opportunity count (the commercial weight),
//   • won value (the relationship's realized worth),
//   • last interaction + idle tier (the "have we been neglecting them" signal),
//   • the next thing that exists on the calendar (follow-up / visit / deal
//     next-action, earliest wins — the "what do I do next" answer).
//
// Role law (visibility.ts — binding AUTHORIZATION_MODEL.md): the book is
// LEAD-scoped through the contact's 1:1 lead:
//   MANAGER+     → the whole org's customers
//   SALES_AGENT  → customers of OWN+POOL leads
//   FIELD_REP    → customers of visits on their assigned projects
// The detail/360 surface is the EXISTING lead drawer (GET /api/leads/:id —
// already scoped, no existence leak) — this route is list-only by design:
// zero new mutation surface, zero duplicated detail contract.
//
// Query params:
//   query  — free text (contact name/alias/phone/email + lead name/phone/email)
//   stage  — one JOURNEY_STAGES value (funnel segment isolation)
//   owner  — "me" | "unassigned" (MANAGER+ only; ignored below)
//   idle   — "1" → only customers with no recorded contact for > 14 days
//   sort   — "recent" (default) | "value" | "name"
//   page / pageSize — in-memory pagination over the computed book
//
// Response: { scope, kpis, data, total, page, pageSize } — the KPI block is
// computed BEFORE the stage/idle filters (book-level truth: the header chips
// describe the book, the list describes the filtered slice — the journey
// funnel-count law).
import type { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ApiError, fail, ok, requireUser } from "@/lib/server/session";
import { leadScope, seesAllRecords } from "@/lib/server/visibility";
import { qp, qpNumber } from "@/lib/server/validation";
import {
  computeJourney,
  JOURNEY_STAGES,
  type JourneyFacts,
  type JourneyStage,
} from "@/lib/journey";
import { OPP_CLOSED_STAGES } from "@/lib/constants";

// P2.2 — the fact projection the journey engine reads (the journey route's
// FACT_INCLUDE law, mirrored here so the two surfaces derive identically).
const FACT_INCLUDE = {
  owner: { select: { id: true, name: true, role: true } },
  requirements: { select: { id: true } },
  visits: { select: { status: true, scheduledAt: true } },
  opportunities: {
    select: {
      id: true,
      stage: true,
      createdAt: true,
      closedAt: true,
      value: true,
      lostReason: true,
      nextActionAt: true,
    },
  },
} as const;

const SORT_KEYS = ["recent", "value", "name"] as const;
type SortKey = (typeof SORT_KEYS)[number];

/** P2.2 — the idle threshold: a customer with no recorded interaction for
 * more than 14 days is visibly rotting (the same 14-day tier the leads
 * rotting ladder paints rose — one law, two surfaces). */
const IDLE_DAYS = 14;
const DAY_MS = 24 * 60 * 60 * 1000;

const SORT_API_FIELD: Record<SortKey, string> = {
  recent: "recent",
  value: "value",
  name: "name",
};

export async function GET(req: NextRequest) {
  try {
    const user = await requireUser();
    const now = new Date();
    void SORT_API_FIELD; // (kept for contract documentation parity with leads)

    // ---- params (validation law: garbage → 422 with the allowed set, never
    //      a silent ignore, never a raw predicate)
    const query = (qp(req, "query") ?? "").trim();
    const stageFilter = qp(req, "stage");
    if (stageFilter && !JOURNEY_STAGES.includes(stageFilter as JourneyStage)) {
      throw new ApiError(422, "Paramètre 'stage' : valeur non reconnue", "INVALID_STAGE", {
        allowed: [...JOURNEY_STAGES],
      });
    }
    const ownerFilter = qp(req, "owner");
    if (ownerFilter && ownerFilter !== "me" && ownerFilter !== "unassigned") {
      throw new ApiError(422, "Paramètre 'owner' : valeur non reconnue", "INVALID_OWNER");
    }
    const idle = qp(req, "idle") === "1";
    const rawSort = qp(req, "sort") ?? "recent";
    if (!SORT_KEYS.includes(rawSort as SortKey)) {
      throw new ApiError(422, "Paramètre 'sort' : valeur non reconnue", "INVALID_SORT", {
        allowed: [...SORT_KEYS],
      });
    }
    const sort = rawSort as SortKey;
    const page = Math.max(1, qpNumber(req, "page") ?? 1);
    const pageSize = Math.min(100, Math.max(10, qpNumber(req, "pageSize") ?? 25));
    const isManager = seesAllRecords(user);

    // ---- base scope: org tenant + the lead-visibility law through the
    //      contact's 1:1 lead (archived leads never enter the book — the
    //      same live-funnel law as the journey worklist).
    const leadWhere: Record<string, unknown> = {
      archived: false,
      ...(leadScope(user) ?? {}),
    };
    if (isManager && ownerFilter === "me") leadWhere.ownerId = user.id;
    if (isManager && ownerFilter === "unassigned") leadWhere.ownerId = null;
    const leadOr: object[] = [];
    if (query) {
      leadOr.push(
        { fullName: { contains: query } },
        { phone: { contains: query } },
        { email: { contains: query } },
      );
      // the contact's own identity fields participate too (alias + direct
      // edits that diverged from the lead's snapshot)
      const matchingContacts = await db.contact.findMany({
        where: {
          orgId: user.orgId,
          OR: [
            { fullName: { contains: query } },
            { fullNameAr: { contains: query } },
            { phone: { contains: query } },
            { email: { contains: query } },
          ],
        },
        select: { leadId: true },
      });
      if (matchingContacts.length) {
        leadOr.push({ id: { in: matchingContacts.map((c) => c.leadId) } });
      }
    }
    if (leadOr.length) leadWhere.OR = leadOr;

    const contacts = await db.contact.findMany({
      where: { orgId: user.orgId, lead: leadWhere },
      include: { lead: { include: FACT_INCLUDE } },
      orderBy: [{ createdAt: "desc" }],
      take: 500, // the honest ceiling — a live book is bounded by the org's conversions
    });

    // ---- ONE batched reservation fetch for the whole page's opportunities
    //      (the journey route's money-path join law — no N+1).
    const allOppIds = contacts.flatMap((c) => c.lead.opportunities.map((o) => o.id));
    const reservationRows = allOppIds.length
      ? await db.reservation.findMany({
          where: { orgId: user.orgId, opportunityId: { in: allOppIds } },
          select: {
            opportunityId: true,
            status: true,
            createdAt: true,
            expiresAt: true,
            amount: true,
          },
        })
      : [];
    const reservationsByOpp = new Map<string, typeof reservationRows>();
    for (const r of reservationRows) {
      const list = reservationsByOpp.get(r.opportunityId) ?? [];
      list.push(r);
      reservationsByOpp.set(r.opportunityId, list);
    }

    const idleCutoff = new Date(now.getTime() - IDLE_DAYS * DAY_MS);

    // ---- compute every row (the book), accumulating the header KPIs on the
    //      UNFILTERED set (book-level truth — the funnel-count law).
    let kpiLive = 0;
    let kpiIdle = 0;
    let kpiLiveValue = 0;

    const rows: (CustomerRow & { idle: boolean })[] = [];
    for (const contact of contacts) {
      const lead = contact.lead;
      const reservations = lead.opportunities.flatMap(
        (o) => reservationsByOpp.get(o.id) ?? [],
      );

      const facts: JourneyFacts = {
        lead: {
          status: lead.status,
          priority: lead.priority,
          score: lead.score,
          createdAt: lead.createdAt.toISOString(),
          lastContactAt: lead.lastContactAt?.toISOString() ?? null,
          nextFollowUpAt: lead.nextFollowUpAt?.toISOString() ?? null,
          lostReason: lead.lostReason,
          lostAt: lead.lostAt?.toISOString() ?? null,
          hasRequirement: lead.requirements.length > 0,
          budgetMin: lead.budgetMin,
          budgetMax: lead.budgetMax,
          archived: lead.archived,
        },
        visits: lead.visits.map((v) => ({
          status: v.status,
          scheduledAt: v.scheduledAt.toISOString(),
        })),
        opportunities: lead.opportunities.map((o) => ({
          stage: o.stage,
          createdAt: o.createdAt.toISOString(),
          closedAt: o.closedAt?.toISOString() ?? null,
          value: o.value,
          lostReason: o.lostReason,
        })),
        reservations: reservations.map((r) => ({
          status: r.status,
          createdAt: r.createdAt.toISOString(),
          expiresAt: r.expiresAt?.toISOString() ?? null,
        })),
      };
      const journey = computeJourney(facts);

      if (journey.stage !== "WON" && journey.stage !== "LOST") kpiLive += 1;
      const isIdle = lead.lastContactAt != null && lead.lastContactAt < idleCutoff;
      if (isIdle) kpiIdle += 1;

      // ---- commercial weight: open opps + their summed value; won value
      const openOpps = lead.opportunities.filter(
        (o) => !OPP_CLOSED_STAGES.includes(o.stage as never),
      );
      const liveValue = openOpps.reduce((sum, o) => sum + (o.value ?? 0), 0);
      const wonValue = lead.opportunities
        .filter((o) => o.stage === "CLOSED_WON")
        .reduce((sum, o) => sum + (o.value ?? 0), 0);
      if (liveValue > 0) kpiLiveValue += liveValue;

      // ---- the next thing on this relationship's calendar (earliest wins —
      //      the "what do I do next" column is a MIN over the recorded facts)
      const candidates: number[] = [];
      if (lead.nextFollowUpAt) candidates.push(lead.nextFollowUpAt.getTime());
      for (const o of lead.opportunities) {
        if (o.nextActionAt && !OPP_CLOSED_STAGES.includes(o.stage as never)) {
          candidates.push(o.nextActionAt.getTime());
        }
      }
      const nextVisit = [...lead.visits]
        .filter((v) => v.status === "SCHEDULED" || v.status === "CONFIRMED")
        .sort((a, b) => a.scheduledAt.getTime() - b.scheduledAt.getTime())[0];
      if (nextVisit) candidates.push(nextVisit.scheduledAt.getTime());
      const nextActionAt = candidates.length ? Math.min(...candidates) : null;

      rows.push({
        id: contact.id,
        leadId: contact.leadId,
        fullName: contact.fullName,
        fullNameAr: contact.fullNameAr,
        phone: contact.phone,
        email: contact.email,
        address: contact.address,
        type: contact.type,
        notes: contact.notes,
        createdAt: contact.createdAt.toISOString(),
        updatedAt: contact.updatedAt.toISOString(),
        owner: lead.owner ?? null,
        leadStatus: lead.status,
        stage: journey.stage,
        openOpps: openOpps.length,
        liveValue,
        wonValue,
        lastContactAt: lead.lastContactAt?.toISOString() ?? null,
        nextActionAt: nextActionAt != null ? new Date(nextActionAt).toISOString() : null,
        nextVisitAt: nextVisit?.scheduledAt.toISOString() ?? null,
        idle: isIdle,
      });
    }

    // ---- list filters (narrow the LIST; the KPIs above stay book-level)
    const filtered = rows.filter((r) => {
      if (stageFilter && r.stage !== stageFilter) return false;
      if (idle && !r.idle) return false;
      return true;
    });

    // ---- sort (in-memory over the bounded book)
    filtered.sort((a, b) => {
      if (sort === "value") {
        if (b.liveValue !== a.liveValue) return b.liveValue - a.liveValue;
        if (b.wonValue !== a.wonValue) return b.wonValue - a.wonValue;
      }
      if (sort === "name") return a.fullName.localeCompare(b.fullName, "fr");
      // "recent" — the most recent interaction first; never-contacted last
      const at = a.lastContactAt ? new Date(a.lastContactAt).getTime() : 0;
      const bt = b.lastContactAt ? new Date(b.lastContactAt).getTime() : 0;
      if (bt !== at) return bt - at;
      return a.fullName.localeCompare(b.fullName, "fr");
    });

    const total = filtered.length;
    const start = (page - 1) * pageSize;
    const data: CustomerRow[] = filtered.slice(start, start + pageSize).map((r) => {
      const { idle: _idle, ...row } = r;
      return row;
    });

    return ok({
      scope: isManager ? "org" : "own",
      kpis: {
        total: rows.length,
        live: kpiLive,
        idle: kpiIdle,
        liveValue: kpiLiveValue,
      },
      query: query || null,
      stage: stageFilter ?? null,
      owner: ownerFilter ?? null,
      idle,
      sort,
      total,
      page,
      pageSize,
      data,
    });
  } catch (error) {
    return fail(error);
  }
}

interface CustomerRow {
  id: string;
  leadId: string;
  fullName: string;
  fullNameAr: string | null;
  phone: string;
  email: string | null;
  address: string | null;
  type: string;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  owner: { id: string; name: string; role: string } | null;
  leadStatus: string;
  stage: JourneyStage;
  openOpps: number;
  liveValue: number;
  wonValue: number;
  lastContactAt: string | null;
  nextActionAt: string | null;
  nextVisitAt: string | null;
}
