// GET /api/audit — business audit trail (master prompt §26), MANAGER+ only.
// Filterable by entity/entityId/actorId, newest first.
// R9-1: `q` — full server-side search across action/entity/entityId/ip/
// before/after JSON and actor name, so hits on ANY page are found (the old
// client-side filter only saw the current 25-row page). SQLite `contains`
// maps to LIKE → case-insensitive for ASCII.
// R8-3: the response also carries `undoneAuditIds` — ids of LEADS_IMPORTED
// audits that already have a matching LEADS_IMPORT_UNDONE (sourceAuditId),
// so the audit view can hide the "Annuler" button on processed imports.
import type { NextRequest } from "next/server";
import type { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { fail, ok, parseIntParam } from "@/lib/server/session";
import { requirePermission } from "@/lib/server/authorize";
import { qp } from "@/lib/server/validation";

export async function GET(req: NextRequest) {
  try {
    const user = await requirePermission("audit.view");
    const orgId = user.orgId;
    const params = req.nextUrl.searchParams;

    const page = parseIntParam(params.get("page"), 1, { min: 1, max: 100000 });
    const pageSize = parseIntParam(params.get("pageSize"), 25, { min: 1, max: 100 });

    const conditions: Prisma.AuditLogWhereInput[] = [{ orgId }];
    const entity = qp(req, "entity");
    if (entity) conditions.push({ entity });
    const entityId = qp(req, "entityId");
    if (entityId) conditions.push({ entityId });
    const actorId = qp(req, "actorId");
    if (actorId) conditions.push({ actorId });

    // R9-1 — server-side search across the trail (see header comment).
    const q = qp(req, "q");
    if (q) {
      conditions.push({
        OR: [
          { action: { contains: q } },
          { entity: { contains: q } },
          { entityId: { contains: q } },
          { ip: { contains: q } },
          { before: { contains: q } },
          { after: { contains: q } },
          { actor: { is: { name: { contains: q } } } },
        ],
      });
    }

    const where = conditions.length > 1 ? { AND: conditions } : conditions[0];

    const [total, logs] = await Promise.all([
      db.auditLog.count({ where }),
      db.auditLog.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { actor: { select: { id: true, name: true, role: true } } },
      }),
    ]);

    // R8-3 — which imports have already been undone? (cheap scan of the
    // LEADS_IMPORT_UNDONE rows; `after` is a JSON string on SQLite, so the
    // sourceAuditId match happens app-side.)
    const undoneRows = await db.auditLog.findMany({
      where: { orgId, action: "LEADS_IMPORT_UNDONE" },
      select: { after: true },
      take: 500,
      orderBy: { createdAt: "desc" },
    });
    const undoneAuditIds: string[] = [];
    for (const row of undoneRows) {
      if (!row.after) continue;
      try {
        const parsed = JSON.parse(row.after) as { sourceAuditId?: unknown };
        if (typeof parsed.sourceAuditId === "string") undoneAuditIds.push(parsed.sourceAuditId);
      } catch {
        /* malformed legacy row — ignore */
      }
    }

    return ok({ data: logs, total, page, pageSize, undoneAuditIds });
  } catch (error) {
    return fail(error);
  }
}
