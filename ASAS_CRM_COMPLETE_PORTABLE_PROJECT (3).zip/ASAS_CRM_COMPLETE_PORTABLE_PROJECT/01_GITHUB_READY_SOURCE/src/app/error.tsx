"use client";

// Phase 1 Task 3 — application error boundary (Next.js App Router pattern:
// error.tsx catches render errors in this segment — page.tsx and everything
// inside it — while the root layout stays mounted).
//
// UX contract (Phase 1 mandate §6):
//   - a single rendering failure must not destroy the whole application
//   - safe user-facing message: NO internals — `error.digest` is a one-way
//     hash reference (safe to display), error.message/stack are NOT shown
//   - recovery path: "Réessayer" (reset() re-renders the segment) + full
//     page reload
//   - diagnostics: the full error object goes to the browser console
//     (useEffect below) — preserved for developers, hidden from users
//
// Self-contained trilingual copy (fr/en/ar + RTL): the app's i18n context
// lives INSIDE the crashed tree, so it cannot be relied on here.

import { useEffect, useState } from "react";
import { AlertTriangle, LoaderCircle, RotateCcw } from "lucide-react";

type Lang = "fr" | "en" | "ar";

const COPY: Record<
  Lang,
  {
    dir: "ltr" | "rtl";
    htmlLang: string;
    title: string;
    body: string;
    retry: string;
    retrying: string;
    reload: string;
    ref: string;
    note: string;
    langs: Record<Lang, string>;
  }
> = {
  fr: {
    dir: "ltr",
    htmlLang: "fr",
    title: "Une erreur inattendue est survenue",
    body: "L'interface a rencontré un problème temporaire. Vos données ne sont pas affectées — réessayez ou rechargez la page.",
    retry: "Réessayer",
    retrying: "Nouvelle tentative…",
    reload: "Recharger la page",
    ref: "Référence technique",
    note: "Ce code aide l'équipe technique à retrouver l'erreur dans les journaux.",
    langs: { fr: "Français", en: "English", ar: "العربية" },
  },
  en: {
    dir: "ltr",
    htmlLang: "en",
    title: "An unexpected error occurred",
    body: "The interface hit a temporary problem. Your data is unaffected — retry or reload the page.",
    retry: "Try again",
    retrying: "Retrying…",
    reload: "Reload the page",
    ref: "Technical reference",
    note: "This code helps the technical team locate the error in the logs.",
    langs: { fr: "Français", en: "English", ar: "العربية" },
  },
  ar: {
    dir: "rtl",
    htmlLang: "ar",
    title: "حدث خطأ غير متوقع",
    body: "واجهت الواجهة مشكلة مؤقتة. بياناتك لم تتأثر — أعد المحاولة أو أعد تحميل الصفحة.",
    retry: "أعد المحاولة",
    retrying: "جارٍ إعادة المحاولة…",
    reload: "إعادة تحميل الصفحة",
    ref: "المرجع التقني",
    note: "يساعد هذا الرمز الفريق التقني في تحديد الخطأ في السجلات.",
    langs: { fr: "Français", en: "English", ar: "العربية" },
  },
};

const LANG_KEYS: Lang[] = ["fr", "en", "ar"];

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  // FIX-E — start in the PERSISTED language, not always French: layout.tsx's
  // blocking pre-hydration script mirrors the zustand-persisted choice onto
  // <html lang>, so the boundary can read it SYNCHRONOUSLY on first render
  // (lazy initializer — no set-state-in-effect; the boundary mounts
  // client-side when a client error is caught, so <html lang> is already
  // settled; "fr" — the default — needs no update). The typeof-document
  // guard keeps the initializer SSR-safe.
  const [lang, setLang] = useState<Lang>(() => {
    const htmlLang = typeof document !== "undefined" ? document.documentElement.lang : "fr";
    return htmlLang === "en" || htmlLang === "ar" ? htmlLang : "fr";
  });
  const [retrying, setRetrying] = useState(false);
  const t = COPY[lang];

  // Diagnostics for developers — full error to the browser console (never
  // rendered). Next.js also logs the server-side digest mapping.
  useEffect(() => {
    console.error("[app-error-boundary]", error);
  }, [error]);

  const handleReset = () => {
    setRetrying(true);
    reset();
    // If the segment recovers, this boundary unmounts; if it throws again
    // the boundary re-renders — restore the button label either way.
    // FRONTEND-AUDIT fix — the former `return () => clearTimeout(restore)` was
    // a dead cleanup React ignores (onClick handlers have no unmount phase);
    // the timeout keeps running to restore the label either way.
    setTimeout(() => setRetrying(false), 1500);
  };

  return (
    <div
      dir={t.dir}
      lang={t.htmlLang}
      role="alert"
      className="flex min-h-screen items-center justify-center bg-background p-4"
    >
      <div className="w-full max-w-md rounded-lg border bg-card p-6 text-card-foreground shadow-sm">
        <div className="mb-4 flex items-center gap-3">
          <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-destructive/10 text-destructive">
            <AlertTriangle className="size-5" aria-hidden="true" />
          </span>
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              ASAS — CRM Immobilier
            </p>
            <h1 className="text-lg font-semibold leading-tight">{t.title}</h1>
          </div>
        </div>

        <p className="mb-5 text-sm leading-relaxed text-muted-foreground">{t.body}</p>

        {/* Recovery path — primary: re-render the failed segment; secondary: hard reload. */}
        <div className="mb-5 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleReset}
            disabled={retrying}
            className="inline-flex h-10 items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-60"
          >
            {retrying ? (
              <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
            ) : (
              <RotateCcw className="size-4" aria-hidden="true" />
            )}
            {retrying ? t.retrying : t.retry}
          </button>
          <a
            href="/"
            className="inline-flex h-10 items-center justify-center rounded-md border px-4 text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            {t.reload}
          </a>
        </div>

        {/* Technical reference — digest is a one-way hash (safe to surface). */}
        {error.digest ? (
          <div className="mb-5 rounded-md border bg-muted/50 p-3">
            <p className="mb-1 text-xs font-medium text-muted-foreground">{t.ref}</p>
            <code className="block break-all font-mono text-xs text-foreground">{error.digest}</code>
            <p className="mt-1 text-xs text-muted-foreground">{t.note}</p>
          </div>
        ) : null}

        {/* Language switch — self-contained (app i18n is inside the crashed tree). */}
        <div className="flex items-center gap-1 border-t pt-4" aria-label="Language / Langue / اللغة">
          {LANG_KEYS.map((key) => (
            <button
              key={key}
              type="button"
              onClick={() => setLang(key)}
              aria-pressed={lang === key}
              className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring ${
                lang === key
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
            >
              {COPY[lang].langs[key]}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
