// ASAS — 512×512 app icon PNG (P42 completion: the manifest's raster
// installability entry). Chrome's install criterion wants a ≥192px PNG;
// Firefox/Safari do not rasterize manifest SVGs. Served at /icon-512 via a
// plain route handler (the metadata conventions only auto-serve icon.* /
// apple-icon.*). Geometry mirrors src/app/apple-icon.tsx exactly — same
// 32-grid "A on a plinth", rounded tile, satori-rendered (no font payload).
import { ImageResponse } from "next/og";

export function GET() {
  return new ImageResponse(
    (
      <svg
        width={512}
        height={512}
        viewBox="0 0 32 32"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect x="1" y="1" width="30" height="30" rx="7" fill="#0f5d3c" />
        <g
          fill="none"
          stroke="#FBFAF8"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <path d="M16 8.2 9.2 24.2 M16 8.2 22.8 24.2" />
          <path d="M12.6 18.4 H19.4" />
          <path d="M8.2 27.6 H23.8" />
        </g>
      </svg>
    ),
    { width: 512, height: 512 },
  );
}
