# Security Policy

## Authorization model (the short version)

ASAS CRM enforces privacy in two layers — read
`docs/security/SECURITY_AND_RLS.md` before touching anything security-related:

1. **Application layer (operative)** — every API route requires an
   HMAC-signed session (`requireUser`) and composes organization-scoped
   visibility fragments ("D-021") into its Prisma queries. Ghost and
   foreign-org records return byte-identical 404s. Role checks
   (OWNER/ADMIN/MANAGER/SALES_AGENT/FIELD_REP) are server-side only.
2. **Database layer (Supabase/PostgreSQL deployments)** — Row Level Security
   is enabled on all 26 tables with default-deny, organization-scoped
   policies keyed on the request JWT `org_id` claim
   (`supabase/migrations/20261030000003_rls_policies.sql`).

Same-origin (CSRF) enforcement runs inside `requireUser()` and
`readJson()` — every mutation is Fetch-Metadata/host verified.

## Demo mode warning

`ASAS_DEMO_MODE` unset or `1` enables the persona quick-login grid and a
passwordless `{userId}` login surface for the seeded demo roster.
**Production deployments MUST set `ASAS_DEMO_MODE=0`.**

**Fail-fast (Phase 2 / W2.2):** this is enforced in code, not just documented —
a production build (`NODE_ENV=production`) with demo mode still on REFUSES the
quick-login surface outright (`500 DEMO_MODE_PRODUCTION_MISCONFIG`, remedy in
the error body) and suppresses the unauthenticated `demoUsers` listing on
`/api/auth/session` (the F-01 takeover chain is dead even if the env var was
forgotten). A one-time boot warning names the fix in the server log. The
sandbox (`NODE_ENV=development`) demo is untouched by design.

## Secrets

- The session secret: `ASAS_SESSION_SECRET` (HMAC-SHA256 cookie signing) —
  generate with `openssl rand -hex 32`; rotate by changing the value (all
  sessions invalidate).
- Supabase: the service-role key and database password are server-only —
  never in browser code, client bundles, or `NEXT_PUBLIC_*` variables.
- The real `.env` is git-ignored; only `.env.example` (placeholders) is tracked.
- If a credential is ever committed, rotation guidance is in
  `docs/security/GIT_HISTORY_PURGE.md` (history rewrite requires explicit
  owner authorization).

## Reporting a vulnerability

Please report suspected vulnerabilities privately to the repository owner.
Do not open public issues for security problems. Include reproduction steps
and the affected route/file if known.
