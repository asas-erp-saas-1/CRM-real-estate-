// ASAS CRM — vitest configuration (W5-A6', Wave 5 test suite).
//
// House law forbids `bun run build`; vitest runs directly on TypeScript
// sources (esbuild transform, no type-check, no Next build). The dev server
// on :3000 stays untouched — contract tests probe it black-box over HTTP.
//
// Aliases:
//   · "@" → src/ (mirrors tsconfig paths so src's internal "@/lib/..." imports
//     resolve),
//   · "@/lib/db" → a throwing stub (tests are pure/read-only: the SQLite file
//     is never opened — see tests/stubs/db.ts),
//   · "server-only" → empty stub (Next build-time guard, absent from
//     node_modules outside the Next compiler).
import path from "node:path";
import { defineConfig } from "vitest/config";

const r = (p: string) => path.resolve(__dirname, p);

export default defineConfig({
  resolve: {
    alias: [
      { find: "server-only", replacement: r("tests/stubs/server-only.ts") },
      { find: /^@\/lib\/db$/, replacement: r("tests/stubs/db.ts") },
      { find: /^@\/(.*)$/, replacement: r("src") + "/$1" },
    ],
  },
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
    // The contract suite hits the live dev server (first-hit route compilation
    // can take seconds); unit tests are instant. Generous ceiling, no flakes.
    testTimeout: 30_000,
    hookTimeout: 30_000,
    reporters: ["default"],
    // P0-7 — focused tests are forbidden: a stray `.only`/`describe.only`
    // silently shrinks the suite; with allowOnly:false vitest FAILS the run
    // instead (deterministic regardless of CI env vars).
    allowOnly: false,
    // P2/W2 — MEMORY LAW (evidence: OOM-killed next-server twice this session
    // at 2.3 GB / 3.2 GB RSS while 38 vitest workers each held ~120 MB in the
    // 4 GB sandbox). Uncapped per-file parallelism races the dev server for
    // memory and the kernel OOM-killer reaps next-server MID-SUITE (security
    // suites then fail at collection). 12 workers bound the suite's footprint
    // to ~1.8 GB and leave the server its verified headroom; the full gate
    // stays a few minutes instead of dying nondeterministically.
    // P6 (Phase 6 / Agent 4 + Principal): migrated from the nested
    // `poolOptions: { forks: { … } }` form — vitest 5.1 REMOVED that shape
    // (deprecation: "test.poolOptions was removed in Vitest 4. All previous
    // poolOptions are now top-level options"), so the law had silently become
    // INERT and the suite ran uncapped again, OOM-killing the CI-parity dev
    // server mid-run (docs/phase6/evidence/a4-ci/04-vitest-full.txt). Top-level
    // options restore the documented bound.
    maxWorkers: 12,
    minWorkers: 1,
  },
});
