# Contributing to ASAS CRM

## Ground rules (binding architecture invariants)

These are settled engineering decisions — reversing one requires an explicit,
recorded decision (see `docs/engineering/OWNER_DECISION_REGISTER.md`, append-only):

1. **Single `/` route** — the whole CRM lives in `src/app/page.tsx` as a
   hash-routed SPA (zustand). Never add page routes.
2. **API routes only** — no Next.js server actions. All mutations go through
   `src/app/api/**` handlers using the standard pattern:
   `requireUser()` → zod `parseBody()` → org-scoped Prisma query → side
   effects (Activity + AuditLog) → `ok()/fail()`.
3. **Enum-as-String law** — closed vocabularies live ONLY in
   `src/lib/constants.ts` (UI selects, API zod schemas, the seed and the
   PostgreSQL CHECK constraints must all consume the same lists — never
   re-declare an enum locally).
4. **D-021 row-level privacy** — every data query composes the visibility
   fragments from `src/lib/server/visibility.ts`. A ghost record and a
   foreign-org record must be **byte-identical 404s**. Never spread a scope
   fragment next to an explicit `OR` key (composition law).
5. **i18n** — every user-facing string goes through `src/lib/i18n/domains/*`
   in ALL THREE languages (fr/en/ar) with genuine Arabic. No hardcoded
   labels in components.
6. **Design system** — use the semantic type scale and existing shadcn/ui
   primitives; emerald/teal/amber/rose/violet palette only (no blue/indigo);
   logical CSS properties for RTL. `docs/ux/DESIGN_SYSTEM.md` is binding.
7. **Money** — DZD amounts are `Float` model fields by settled decision;
   do not silently change financial semantics (commission/incentive
   calculations are owner-approved models).
8. **Successful-closure gate** — every `CLOSED_WON` write requires a
   qualifying visit report (interestLevel + reportNotes + server-stamped
   reporter + timestamp) enforced server-side inside the transaction.
   `CLOSED_LOST` is exempt (with its lostReason prerequisite).

## Workflow

```bash
bun install
bun run lint          # must be clean
bun run typecheck     # must be clean (src/ + prisma/)
bun run dev           # port 3000
```

Schema changes: edit `prisma/schema.prisma` → author the migration with
`bunx prisma migrate dev` **against a scratch database only** (never the shared
one), review the SQL, commit it to the chain → apply with `bun run
db:migrate:deploy` → restart the dev server → `bun run db:migrate:status`
must be clean → then update BOTH renderings: re-generate
`prisma/schema.postgres.prisma` and, if the change is structural, extend the
`supabase/migrations/` chain (never edit an applied migration) — see
`docs/database/MIGRATIONS_AND_SCHEMA.md` and `docs/database/BP-ADR-02_SQLITE_SOURCE_OF_TRUTH.md`.

Commit style: conventional commits, one logical change each — `app:`, `db:`,
`docs:`, `security:`, `chore:`. Never mix unrelated refactors into a change.

Before opening a PR: run the gates above, exercise the affected workflow in
the browser (FR + AR RTL + 390px mobile), and check the console is clean.
CI (`.github/workflows/ci.yml`) runs install + generate + lint + typecheck
and the SQLite migration/seed/validator gates on every PR.

## Testing

The validation model is documented in `docs/engineering/TEST_STRATEGY.md`
(the five-gate protocol) — lint, typecheck, live API batteries
(`tmp-scripts/*-probe.ts`, `*-regressions.ts` against a seeded disposable
database), and browser walkthroughs. The Phase C battery
(`tmp-scripts/phase-c-probe.ts`, 80 checks) is the current regression floor.

## What not to do

- No new frameworks/libraries without a recorded justification.
- No secrets in code, commits, logs, or screenshots; `.env` is never committed.
- No demo-mode "fixes" — `ASAS_DEMO_MODE` defaults are an owner decision.
- Do not weaken any authorization boundary to make a feature work.
- Do not check in database files or real customer data.
