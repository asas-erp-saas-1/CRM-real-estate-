# ASAS CRM — Monitoring & Alerting (deployment TEMPLATES — NOT activated here)

Phase 5 / P5-W2-A6 — remediation of **P4-M09** ("no monitoring consumer"): health
v2 + ADMIN-gated `/api/metrics` existed in-process, but a fatal crash (the phase-4
OOM) was invisible to the repo. This folder is the operational CONSUMER layer as
installable templates + wiring instructions for the single-node staging model.

**Status: design + templates. Nothing in this folder is running anywhere. No
credentials, no invented services, no external dependency is activated.** The
dev sandbox deliberately has NO watchdog (the Principal's session watchdog owns
that environment); these files target the staging host the operator controls.

Contents:
- `asas-health-watch.sh` — the supervisory loop (see its header for install).
- this README — alert definitions, threshold rationale, wiring options,
  error-rate recipes, restore-drill cadence.

Companion docs: `docs/phase5/ASAS_PHASE5_OPERATIONS_RUNBOOK.md` (§2 watchdog
procedures + the kill-recovery test, §3 alerting, §4 backup monitoring),
`deploy/systemd/asas-backup.{service,timer}` (Agent 2's backup scheduler — the
watch script checks its output), `deploy/README-STAGING.md` (Agent 1 — compose
healthcheck/restart values that embed the recommendations below).

---

## 1. Coverage map — which concern is watched by what

| Concern | Mechanism | Where |
|---|---|---|
| HTTP availability (from the host) | loop curls `/api/health`, alerts on curl failure / non-200 | `asas-health-watch.sh` |
| HTTP availability (from OUTSIDE the host) | an uptime checker of your choice against `https://<host>/api/health` | §5 options + trade-offs |
| Application health / DB connectivity | `status != "ok"` or `dbOk != true` → CRITICAL | loop (health body) |
| DB latency | `dbLatencyMs ≥ 500` → WARNING | loop (health body) |
| Memory usage (P4-H01 OOM class) | `rssMb ≥ 2200` WARNING, `≥ 2600` CRITICAL | loop (health body) |
| Application crash / restart | `uptimeSec` decreases → restart event, counted/day; ≥3/day → flapping WARNING | loop (health body) |
| Disk usage (DB volume: SQLite + docs + backups) | `df` ≥ 80% WARNING, ≥ 90% CRITICAL | loop |
| Backup success/failure | newest `db/backups/backup-*/manifest.json` must exist, be < 26 h old and say `"integrity": "ok"` → else CRITICAL | loop (pairs with `asas-backup.timer`) |
| Restore-drill status | NOT automatable as an alert — a calendar cadence + checklist | §7 |
| Critical API error rate | grep recipe over the structured `api_error` log lines (§6); richer view via `/api/metrics` (ADMIN) | §6 |
| Container-level crash/OOM | Docker restart policy + `docker events` / journalctl (exit 137 = OOM) | runbook §2 |

What the in-host loop CANNOT see: the host itself dying, network/edge failure,
or DNS. That is the job of the external uptime checker (§5) — the two layers
are complementary, not redundant.

## 2. Threshold rationale (measured, not guessed)

All anchors are measured in this repo/session — evidence:
`docs/phase5/evidence/a6-ops/04-memory-evidence.txt` and the Phase-4 audit.

- **rssMb 2200 / 2600.** Fresh dev process ≈ 0.8 GB; the kernel OOM-killed the
  server at anon-rss 2.31 GiB (with a ~1 GB vitest neighbour) today and at
  ~2.55 GB in phase 4 (with a 1.3 GB neighbour). With the recommended 3 GB
  container limit (runbook §1), WARNING at 2200 leaves the operator a planned
  restart window; 2600 is past every observed kill point → act NOW.
- **dbLatencyMs 500.** Measured steady state is 1–6 ms (SQLite, local disk);
  a 100× headroom threshold flags real degradation, not noise.
- **Backup age 26 h.** The timer fires daily at 02:30 (`Persistent=true`
  catches powered-off misses at boot); 90 min of slack absorbs slow runs.
  A backup without `"integrity": "ok"` counts as NO backup (house law).
- **Disk 80/90 %.** The DB volume carries `custom.db` (grows with rows +
  WAL), `db/docs/` binaries and `db/backups/` (retention keeps 14). SQLite
  fails mid-write when the volume fills — warn well before.
- **Restarts ≥ 3/day.** One restart is an incident; three in a day is
  instability (e.g. OOM flapping) — investigate, don't endure.
- **5xx counts 10 / 50 per 15 min (§6).** Production steady state is 0
  observed 5xx; 10 is a real problem worth waking for, 50 is an outage.

Re-baseline all of these after any Node/Next major version bump or workload
change (runbook §6).

## 3. Wiring the alert channel (placeholder — you supply it)

The loop logs EVERY check to `LOG_FILE` regardless. Alerts additionally invoke
`ASAS_ALERT_CMD` (bash snippet) with the alert message as `$1`. Examples of
what an operator might set (choose YOUR channel — none of these is configured
or endorsed by this repo):

```bash
# email via the host's installed MTA (if any):
export ASAS_ALERT_CMD='mail -s "ASAS alert" ops@example.dz'

# YOUR chat webhook (fill the placeholder URL with your own endpoint):
export ASAS_ALERT_CMD='curl -fsS -m 10 -H "content-type: application/json" \
  -d @- https://YOUR-WEBHOOK.example/ <<<"{\"text\": \"$1\"}"'

# append to the ops channel file (zero-dependency default):
export ASAS_ALERT_CMD='tee -a /var/log/asas-alerts.log'
```

Per-alert-key cooldown (default 15 min) prevents alert storms. Deliberately
absent: paging integrations, escalation policies, secrets — out of scope until
the staging operator picks a channel. Never put credentials in repo files.

## 4. Wiring the LOOP itself — options compared

| Option | How | Strengths | Weaknesses |
|---|---|---|---|
| **systemd service (recommended)** | `ExecStart=/usr/local/bin/asas-health-watch.sh`, `Restart=always`, `User=asas`, `WantedBy=multi-user.target` | starts at boot, survives logouts, journald captures its own failures, `systemctl status` is one glance | one more unit to maintain |
| **docker sidecar** | run the script in a small container on the same compose network, `URL=http://asas-app:3000/api/health`, mount `db/` read-only for backup/disk checks | keeps the host clean, same lifecycle as the app | the sidecar dies with the docker daemon — host-level failure still unseen (§5) |
| **compose healthcheck only** (Agent 1 embeds) | `test: curl -fsS http://127.0.0.1:3000/api/health`, `interval: 30s`, `timeout: 5s`, `retries: 3`, `start_period: 60s`, `restart: unless-stopped` | zero extra moving parts; auto-restart on crash/OOM (exit 137) | NO alert channel, no rss/disk/backup checks — it restarts silently; `start_period` 60 s covers first-boot route compilation (measured cold first-hits 43–151 ms + dev compile; production standalone boots faster) |

The first two are not mutually exclusive with the third: the compose
healthcheck gives auto-RESTART, the loop gives human-visible ALERTS.

## 5. External uptime monitoring — honest options

The app is single-node: if the host or network path dies, nothing ON the host
can tell you. `/api/health` is deliberately safe to expose (booleans + coarse
process numbers only — no data, no counters; the detailed metrics stay behind
ADMIN auth on `/api/metrics`).

- **Self-hosted Uptime Kuma on a second host/VPS** (open source): HTTP + TLS +
  latency history + alert channels; you own the data. Cost: a second machine
  to run and patch. Recommended end-state for the "two vantage points" rule.
- **A commercial free tier** (UptimeRobot/Better Uptime/…): zero ops effort,
  decent alerts. Trade-offs: your health endpoint URL + schedule leave your
  infrastructure, free tiers poll slowly (≥ 60 s… 5 min), vendor lock-in on
  the alert channel. Acceptable for staging if the URL carries no secrets
  (it does not).
- **A cron on another machine you already run** (`curl -fsS` + existing mail):
  zero new services, weakest alerting. Honest minimum.

Whatever you pick: monitor `https://<host>/api/health`, expect HTTP 200 with
`status == "ok"`, alert after 3 consecutive failures (30–60 s cadence).

## 6. Critical API error-rate — recipes over the structured log

The app emits ONE JSON object per line (`logEvent`, `src/lib/server/logger.ts`)
on stdout; 4xx/5xx business-route failures emit `"event":"api_error"` lines,
and since P5/W2-A6 the JSON 404 catch-all does too (P4-L08 fix — the metrics
store no longer undercounts unknown paths).

```bash
LOG=/opt/asas/dev.log   # wherever the container/service redirects app stdout

# 5xx count in the last 15 minutes (ISO timestamps compare lexicographically):
SINCE=$(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M)
grep '"event":"api_error"' "$LOG" | grep '"status":5' \
  | while IFS= read -r line; do
      ts=$(printf '%s' "$line" | cut -d'"' -f4)     # "ts":"…" is field 4
      [ "${ts:0:16}" \> "$SINCE" ] && printf '%s\n' "$line"
    done | wc -l
# >10 → WARNING, >50 → CRITICAL (steady state: 0). Wire as a cron every 15 min
# or extend asas-health-watch.sh with the same pipeline.

# Quick "what broke recently" (categories, never raw messages):
grep '"event":"api_error"' "$LOG" | tail -200 \
  | grep -o '"category":"[A-Z_]*"' | sort | uniq -c | sort -rn

# Health state changes (one line per ok↔degraded TRANSITION, P4-L08):
grep '"event":"health_state_change"' "$LOG" | tail -20
```

Richer per-route p95/error rates live on `GET /api/metrics` (ADMIN+ session
required — log in as an ADMIN persona from a trusted shell, keep the cookie
out of logs). `/api/metrics` is process-local (single-instance law): counters
reset on restart (runbook §5) — rate recipes above should therefore read the
LOG, not only the live counters.

## 7. Backup operations & restore drills

- Failure detection is automated (loop: `backup_missing` / `backup_stale` /
  `backup_integrity` CRITICALs; runbook §4 has the triage commands).
- The RESTORE DRILL is a human procedure — calendar cadence: **quarterly, and
  after any OS/SQLite/Node/Next upgrade** (both backup units' headers list it
  as an operator checklist item):
  ```bash
  cd /opt/asas && bash scripts/restore.sh --drill db/backups/backup-<newest>
  ```
  PASS = the drill's final line says `artifacts verified … / integrity ok /
  census … MATCHES MANIFEST` (see `docs/phase5/ASAS_PHASE5_DATABASE_BACKUP_RECOVERY.md`
  §4 for this session's drill PASS). A missed quarter is a finding, not an
  alert — note the last drill date in the ops log.

## 8. Explicit non-coverage (honest limits)

- Nothing here is activated; the sandbox has no watchdog by design (§ top).
- No log shipping is configured (the JSON-lines seam is ready for any shipper
  an operator later attaches — that is a deliberate future decision, not an
  omission to paper over).
- The in-host loop cannot detect host/network death (§5 covers that).
- `/api/metrics`-based rates reset on restart; log-based recipes do not.
