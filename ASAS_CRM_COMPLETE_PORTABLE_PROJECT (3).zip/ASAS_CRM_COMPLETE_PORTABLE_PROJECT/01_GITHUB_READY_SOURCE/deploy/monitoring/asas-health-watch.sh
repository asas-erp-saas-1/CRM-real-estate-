#!/usr/bin/env bash
# ASAS CRM — health watchdog LOOP (deployment TEMPLATE — NOT ACTIVATED HERE).
#
# WHAT THIS IS (P5/W2-A6, remediation of P4-M09 / condition C6):
#   A dependency-light supervisory loop for the single-node staging model.
#   It curls /api/health every INTERVAL seconds and ALERTS on:
#     · HTTP availability failure (connection refused / timeout / non-200)
#     · health status != "ok" or dbOk != true (DB connectivity lost)
#     · dbLatencyMs above threshold (slow-but-up DB)
#     · rssMb crossing WARNING / CRITICAL thresholds (the P4-H01 OOM class —
#       measured kill zone: ≥ 2.3–2.55 GB RSS on a 4 GB host with a ~1 GB
#       neighbour; see docs/phase5/evidence/a6-ops/04-memory-evidence.txt)
#     · process RESTARTS (uptimeSec going backwards) — counted per day
#     · disk usage on the DB volume (SQLite + docs + backups live there)
#     · backup freshness/integrity (newest manifest.json must say
#       "integrity": "ok" and be younger than BACKUP_MAX_AGE_H)
#
#   Every check is ONE greppable line in LOG_FILE; alerts additionally invoke
#   ALERT_CMD (a placeholder the operator wires — see README.md §3). No
#   credentials, no external service: this file invents NOTHING.
#
# DEPENDENCIES: bash, curl, and (jq OR python3 OR node) for JSON parsing.
#
# INSTALL (staging host — NEVER run in the dev sandbox):
#   sudo install -m 0755 deploy/monitoring/asas-health-watch.sh /usr/local/bin/
#   Pick ONE wiring (README.md §4 compares them):
#     a) systemd service (recommended — auto-start on boot, journald log):
#        write /etc/systemd/system/asas-health-watch.service with
#          [Service] ExecStart=/usr/local/bin/asas-health-watch.sh
#          Restart=always  User=asas
#        then: sudo systemctl daemon-reload && sudo systemctl enable --now it
#     b) docker: run it in a sidecar container sharing the app network, or
#        rely on the compose healthcheck + restart policy alone (weaker: no
#        rss/disk/backup checks, no alert channel).
#     c) tmux/nohup ad-hoc (weakest — dies with the session; NOT recommended
#        beyond a first evaluation).
#
# CONFIGURATION: edit the defaults below or export the ASAS_HW_* variables.
set -u

# ── template parameters (defaults; override via environment) ────────────────
URL="${ASAS_HW_URL:-http://127.0.0.1:3000/api/health}"
INTERVAL="${ASAS_HW_INTERVAL:-30}"          # seconds between probes
DB_DIR="${ASAS_HW_DB_DIR:-/opt/asas/db}"    # volume holding custom.db + backups + docs
BACKUP_DIR="${ASAS_HW_BACKUP_DIR:-${DB_DIR}/backups}"
STATE_DIR="${ASAS_HW_STATE_DIR:-/var/tmp/asas-health-watch}"
LOG_FILE="${ASAS_HW_LOG:-${STATE_DIR}/health-watch.log}"
ALERT_CMD="${ASAS_ALERT_CMD:-}"             # e.g. a curl to YOUR webhook/mail — operator-supplied
COOLDOWN_S="${ASAS_HW_COOLDOWN:-900}"       # per-alert-key re-alert suppression (15 min)
# thresholds — rationale in deploy/monitoring/README.md §2 (measured, not guessed)
RSS_WARN="${ASAS_HW_RSS_WARN:-2200}"        # MB — approaching the observed kill zone
RSS_CRIT="${ASAS_HW_RSS_CRIT:-2600}"        # MB — past every observed kill point
DBLAT_WARN="${ASAS_HW_DBLAT_WARN:-500}"     # ms — measured steady dbLatencyMs is 1–6 ms
DISK_WARN="${ASAS_HW_DISK_WARN:-80}"        # % used on the DB volume
DISK_CRIT="${ASAS_HW_DISK_CRIT:-90}"
BACKUP_MAX_AGE_H="${ASAS_HW_BACKUP_MAX_AGE_H:-26}"  # daily 02:30 timer + 90 min slack
RESTARTS_WARN_PER_DAY="${ASAS_HW_RESTARTS_WARN:-3}" # flapping detector

mkdir -p "$STATE_DIR"
touch "$LOG_FILE"

# ── helpers ──────────────────────────────────────────────────────────────────
now_iso() { date -u +"%Y-%m-%dT%H:%M:%SZ"; }
log() { # LEVEL KEY MESSAGE...
  local level="$1" key="$2"; shift 2
  echo "$(now_iso) level=$level key=$key $*" >>"$LOG_FILE"
}
alert() { # LEVEL KEY MESSAGE...   (log + ALERT_CMD, cooldown per key)
  local level="$1" key="$2"; shift 2
  log "$level" "$key" "$*"
  local last ts msg
  last=""
  [ -f "$STATE_DIR/cooldown-$key" ] && last="$(cat "$STATE_DIR/cooldown-$key" 2>/dev/null)"
  ts=$(date +%s)
  if [ -n "$last" ] && [ "$((ts - last))" -lt "$COOLDOWN_S" ]; then
    return 0 # suppressed — already alerted within the cooldown window
  fi
  echo "$ts" >"$STATE_DIR/cooldown-$key"
  if [ -n "$ALERT_CMD" ]; then
    # P5-Principal fix: the message must reach the channel BOTH as $1
    # (webhook-style snippets, README §3) AND on stdin (mail/tee-style
    # snippets). The previous form `bash -c "$ALERT_CMD" "<msg>"` bound the
    # message to $0 only — every documented channel delivered an empty
    # message (found by P5-W2-A6-COMP review, evidence 05 §3).
    msg="$key: $* (level=$level at $(now_iso))"
    if printf '%s\n' "$msg" | bash -c "$ALERT_CMD" alert "$msg" >>"$LOG_FILE" 2>&1; then
      log info "alert_delivered" "key=$key"
    else
      log error "alert_delivery_failed" "key=$key (check ASAS_ALERT_CMD)"
    fi
  else
    log warn "alert_no_channel" "key=$key ASAS_ALERT_CMD is unset — alert logged only"
  fi
}

# JSON field extraction with graceful parser fallback (jq → python3 → node).
json_field() { # FIELD  (reads JSON from stdin, prints value or nothing)
  local field="$1" body
  body=$(cat)
  if command -v jq >/dev/null 2>&1; then
    echo "$body" | jq -r ".$field // empty" 2>/dev/null && return 0
  elif command -v python3 >/dev/null 2>&1; then
    echo "$body" | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
except Exception:
    sys.exit(0)
v = d.get('$field')
print(v if v is not None else '')" 2>/dev/null && return 0
  elif command -v node >/dev/null 2>&1; then
    echo "$body" | node -e "
let s='';process.stdin.on('data',d=>s+=d).on('end',()=>{try{const v=JSON.parse(s)['$field'];if(v!==undefined&&v!==null)console.log(v)}catch(e){}})" 2>/dev/null && return 0
  fi
  return 1
}

state_get() { [ -f "$STATE_DIR/$1" ] && cat "$STATE_DIR/$1" 2>/dev/null || echo ""; }
state_set() { echo "$2" >"$STATE_DIR/$1"; }

log info "watch_started" "url=$URL interval=${INTERVAL}s pid=$$"

# ── main loop ────────────────────────────────────────────────────────────────
while true; do
  body="$(curl -fsS -m 10 -o - -w '\n__HTTP__%{http_code}' "$URL" 2>/dev/null)"
  rc=$?
  if [ $rc -ne 0 ]; then
    alert critical "availability" "health probe FAILED (curl rc=$rc) — server unreachable at $URL"
    state_set prev_uptime "" # unknown — avoid false restart detection later
    sleep "$INTERVAL"
    continue
  fi
  http_code="${body##*__HTTP__}"
  body="${body%__HTTP__*}"
  if [ "$http_code" != "200" ]; then
    alert critical "http_status" "health endpoint answered HTTP $http_code (expected 200)"
  fi

  status=$(echo "$body" | json_field status)
  dbok=$(echo "$body" | json_field dbOk)
  dblat=$(echo "$body" | json_field dbLatencyMs)
  rss=$(echo "$body" | json_field rssMb)
  uptime=$(echo "$body" | json_field uptimeSec)

  if [ "$status" != "ok" ] || [ "$dbok" != "true" ]; then
    alert critical "health_degraded" "status=$status dbOk=$dbok (DB connectivity lost — health returns 503)"
  else
    log info "health_ok" "dbLatencyMs=$dblat rssMb=$rss uptimeSec=$uptime"
  fi

  # slow-but-up DB (health still ok)
  case "$dblat" in
    ''|*[!0-9]*) ;; # missing/non-numeric — skip
    *) if [ "$dblat" -ge "$DBLAT_WARN" ]; then
         alert warning "db_latency" "dbLatencyMs=$dblat ≥ ${DBLAT_WARN}ms (steady state is 1–6 ms)"
       fi ;;
  esac

  # memory posture (P4-H01 class)
  case "$rss" in
    ''|*[!0-9]*) ;;
    *) if [ "$rss" -ge "$RSS_CRIT" ]; then
         alert critical "rss_critical" "rssMb=$rss ≥ ${RSS_CRIT} (kill zone measured at 2.3–2.55 GB with a neighbour — expect OOM; raise the container limit or restart in a window)"
       elif [ "$rss" -ge "$RSS_WARN" ]; then
         alert warning "rss_warning" "rssMb=$rss ≥ ${RSS_WARN} — plan a restart window; do NOT let it ride to the OOM killer"
       fi ;;
  esac

  # restart detection: uptime going backwards means a NEW process
  prev=$(state_get prev_uptime)
  case "$uptime" in
    ''|*[!0-9]*) ;;
    *) if [ -n "$prev" ] && [ "$uptime" -lt "$((prev - 5))" ]; then
         today=$(date -u +%Y-%m-%d)
         if [ "$(state_get restart_day)" != "$today" ]; then
           state_set restart_day "$today"; state_set restart_count 0
         fi
         count=$(( $(state_get restart_count) + 1 ))
         state_set restart_count "$count"
         if [ "$count" -ge "$RESTARTS_WARN_PER_DAY" ]; then
           alert warning "restart_flapping" "restart #$count today (uptimeSec dropped $prev→$uptime) — check dmesg/journalctl for OOM (exit 137)"
         else
           alert warning "app_restarted" "process restarted (uptimeSec $prev→$uptime, restart #$count today)"
         fi
       fi
       state_set prev_uptime "$uptime" ;;
  esac

  # disk usage on the DB volume
  if [ -d "$DB_DIR" ]; then
    used=$(df -P "$DB_DIR" 2>/dev/null | awk 'NR==2 {gsub(/%/,"",$5); print $5}')
    case "$used" in
      ''|*[!0-9]*) ;;
      *) if [ "$used" -ge "$DISK_CRIT" ]; then
           alert critical "disk_critical" "DB volume ${used}% used (≥ ${DISK_CRIT}%) — SQLite cannot grow; backups/docs at risk"
         elif [ "$used" -ge "$DISK_WARN" ]; then
           alert warning "disk_warning" "DB volume ${used}% used (≥ ${DISK_WARN}%)"
         fi ;;
    esac
  fi

  # backup freshness + integrity (pairs with deploy/systemd/asas-backup.timer)
  newest_manifest=$(ls -1t "$BACKUP_DIR"/backup-*/manifest.json 2>/dev/null | head -1)
  if [ -z "$newest_manifest" ]; then
    alert critical "backup_missing" "no backup-*/manifest.json under $BACKUP_DIR — is asas-backup.timer enabled?"
  else
    if ! grep -q '"integrity"[[:space:]]*:[[:space:]]*"ok"' "$newest_manifest"; then
      alert critical "backup_integrity" "$newest_manifest does not say integrity:ok — treat as NO backup"
    fi
    mtime=$(stat -c %Y "$newest_manifest" 2>/dev/null || echo 0)
    age_h=$(( ( $(date +%s) - mtime ) / 3600 ))
    if [ "$age_h" -ge "$BACKUP_MAX_AGE_H" ]; then
      alert critical "backup_stale" "newest backup is ${age_h}h old (≥ ${BACKUP_MAX_AGE_H}h) — the 02:30 timer missed a run; check: systemctl list-timers asas-backup.timer; journalctl -u asas-backup.service -n 50"
    else
      log info "backup_ok" "newest=$(basename "$(dirname "$newest_manifest")") age_h=${age_h}"
    fi
  fi

  sleep "$INTERVAL"
done
