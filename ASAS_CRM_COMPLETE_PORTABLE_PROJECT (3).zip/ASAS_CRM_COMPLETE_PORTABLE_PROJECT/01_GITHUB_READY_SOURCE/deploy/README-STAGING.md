# ASAS CRM — Staging Runbook (single-node Docker)

**Phase 5 / P5-W2-A1 · conditions C1 + C2 (findings P4-H02, P4-H03, P4-M06, P4-M07).**
**Status of THIS document:** written in the development sandbox, where `docker`,
`docker build` and `bun run build` are all unavailable/forbidden by standing
rule — every command below is the EXACT procedure for the staging host, and
**nothing here has been executed yet**. The first command that runs it is the
Phase 4 **condition C1 entry gate** (§2). Companion documents:
`docs/phase5/ASAS_PHASE5_STAGING_ARCHITECTURE.md` (the decision record),
`docker-compose.staging.yml`, `Dockerfile`, `.dockerignore`,
`.env.staging.example`, `docs/phase5/ASAS_PHASE5_BUILD_AND_CI_REPORT.md`.

The hosting model is **single-node Linux VPS + Docker with persistent storage**
(Phase 4 decision, condition C2): the application is verifiably single-instance —
in-process expiry scheduler (`src/lib/server/expiry-scheduler.ts:36`, `setInterval`
on `globalThis`), process-local rate limits (`src/lib/server/lead-capture.ts`,
in-memory login-lockout window state), in-process observability/caching
(`src/lib/server/obs.ts`, `src/lib/server/notification-cache.ts`), and SQLite +
local document storage (`db/custom.db`, `db/docs/` —
`src/lib/server/documents.ts`). A single long-lived container satisfies all four
by design; serverless would require reworking every one of them (see
`docs/operations/VERCEL_SETUP.md` for that path's true cost).

---

## 1. Prerequisites

| Requirement | Value | Why |
|---|---|---|
| Host RAM | **≥ 8 GB** (audit recommendation; 4 GB hard floor) | Measured dev-server RSS ~2.0–2.5 GB, OOM-killed at **2.55 GB** on a 4 GB host (P4-H01; health `rssMb:2535`, kernel log `anon-rss 2,551,908 kB`). The container limit is 4 GB (compose) — the host needs room for the OOM-killer's alternatives, the docker daemon, and any reverse proxy. Production standalone RSS is unmeasured until C1; re-check after first boot (§8). |
| Host disk | ≥ 20 GB free | Image + volume (SQLite + documents + 14 retained backups — `ASAS_BACKUP_KEEP`, default 14). |
| Host OS | Any Linux with Docker Engine ≥ 24 + `docker compose` v2 plugin | Compose file uses the modern spec (`mem_limit`, `name:`, healthcheck array form). |
| Ports | 3000 published on **127.0.0.1 only** (compose default) | The app is TLS-less by itself; expose publicly only behind the documented reverse proxy (Caddy — `next.config.ts` W1.3 note) or via SSH tunnel (`ssh -L 3000:127.0.0.1:3000 host`). |
| Tools on host | `docker`, `docker compose`, `curl`, `jq`, `openssl`, `git` | All commands below use only these. |
| Repo | GitHub remote with the deployed tag/commit | Phase 4 gate order (history purge D-013 BEFORE any remote) still applies — it is a precondition of publishing this repo anywhere. |

Build architecture note: prisma engines are platform-specific — build the image
**on the staging host** (or a host of the same architecture) so the downloaded
engines match the runtime (amd64/arm64).

---

## 2. CONDITION C1 — the staging ENTRY GATE (verbatim procedure)

C1 (Phase 4, P4-H03): **the first-ever production build + standalone boot +
`/api/health` PASS.** It is BLOCKED in the dev sandbox (build forbidden, no
docker daemon, no git remote) and is executed HERE, as the FIRST act of
staging. Do not proceed to §3 until all three parts PASS.

### 2a. Prepare the environment (once)

```bash
# on the staging host
git clone <repo-url> asas-crm && cd asas-crm          # deployed commit/branch
# (this runbook's later sections use /opt/asas as the canonical install
#  prefix — substitute your clone location everywhere)
cp .env.staging.example .env.staging
# generate the ONE real secret this deployment needs:
openssl rand -hex 32                                    # → ASAS_SESSION_SECRET value
$EDITOR .env.staging                                    # paste secret; keep ASAS_DEMO_MODE=0
```

### 2b. Part 1 — first-ever production build

```bash
docker compose -f docker-compose.staging.yml build
```

This runs the `builder` stage (Bun 1.3.14: `bun install --frozen-lockfile` →
`bunx prisma generate` → **`bun run build`** — the first execution of
`next build` in the project's history) and assembles the runtime stage.
Expected evidence: the build log ends with the Next.js build summary table
(routes + "✓ Compiled successfully"); exit code 0.

*(CI-equivalent: when a git remote exists, the same build runs as the
`static-gates → Production build` step of `.github/workflows/ci.yml` — its
green log is the same C1 evidence, produced per-push. See
`docs/phase5/ASAS_PHASE5_BUILD_AND_CI_REPORT.md` §2.1.)*

### 2c. Part 2 — standalone boot

```bash
docker compose -f docker-compose.staging.yml up -d
docker compose -f docker-compose.staging.yml ps        # STATUS should reach (healthy)
```

The entrypoint is exactly the sanctioned start contract:
`node .next/standalone/server.js` (package.json `start`). First boot executes
the P0-3 boot gate (instrumentation.ts): with a valid `ASAS_SESSION_SECRET`
and `ASAS_DEMO_MODE=0` the server starts; with a placeholder/weak secret or
demo mode on, **the process crashes on purpose** — that is the gate working,
fix `.env.staging` and `docker compose ... up -d` again.

### 2d. Part 3 — health gate (C1 PASS criteria)

```bash
curl -fsS http://127.0.0.1:3000/api/health | tee /tmp/c1-health.json | jq .
jq -e '.dbOk == true and .demoMode == false' /tmp/c1-health.json
```

**C1 is satisfied when** the build exited 0, the container reached `healthy`,
and the final `jq -e` exits 0 (db reachable, demo mode off — the same
production-posture contract the CI negative probes encode). Record
`/tmp/c1-health.json` (it also carries `migrations`, `rssMb`, `uptimeSec`) as
the C1 receipt alongside the build log — then optionally also run the C3
quick-login refusal probe:

```bash
curl -s -o /tmp/quick.json -w "%{http_code}\n" -X POST \
  -H "Content-Type: application/json" -H "Origin: http://127.0.0.1:3000" \
  -d '{"userId":"any"}' http://127.0.0.1:3000/api/auth/login   # expect 403
jq -e '.code == "DEMO_MODE_DISABLED"' /tmp/quick.json
curl -fsS http://127.0.0.1:3000/api/auth/session | jq -e '.demoUsers | length == 0'
```

---

## 3. First boot sequence (fresh data volume)

Run AFTER C1 passes, on the empty `asas-data` volume (a fresh volume has no
`custom.db`; the health endpoint would report `dbOk:false` — expected until
step 1).

```bash
# 1. Apply the canonical migration chain (25 migrations) to the volume.
#    Uses the image's own prisma CLI; DATABASE_URL from .env.staging
#    (absolute: file:/app/db/custom.db on the volume).
docker compose -f docker-compose.staging.yml exec asas-crm \
  bunx prisma migrate deploy

# 2. Provision the initial OWNER — the SANCTIONED path (condition C4).
#    NEVER `bun run db:seed` / `db:deploy:demo`: the demo seed plants an
#    OWNER whose password is PUBLIC ("asas1234"), and prisma/seed.ts refuses
#    under NODE_ENV=production unless ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION=1 —
#    keep that variable UNSET; the guard is the last line of defense, the
#    runbook is the first. provision-owner.ts is idempotent (refuses when an
#    OWNER exists), rejects the public password and <12-char passwords, and
#    never echoes the password:
echo '<choose-a-strong-owner-password>' | docker compose -f docker-compose.staging.yml exec -T asas-crm \
  bun run scripts/provision-owner.ts --email owner@yourdomain.example --name 'Owner Name' --password-stdin

# 3. (Re)start + verify.
docker compose -f docker-compose.staging.yml restart
curl -fsS http://127.0.0.1:3000/api/health | jq -e '.dbOk == true and .demoMode == false and .migrations == 25'

# 4. Log in through the UI (or curl the credential login) with the OWNER and
#    immediately exercise: a list view, a detail view, a document upload
#    (writes to the VOLUME: /app/db/docs — verify it survives §6's restart).
```

First backup (proves the volume layout end-to-end, P4-M02 bootstrap fix
included — the scripts now mkdir their own destinations):

```bash
docker compose -f docker-compose.staging.yml exec asas-crm bash scripts/backup.sh
docker compose -f docker-compose.staging.yml exec asas-crm ls db/backups/
```

---

## 4. Backups — schedule activation (condition C5)

The backup tooling itself (VACUUM INTO snapshot + docs tarball + verified
manifest; NEVER a live file-copy) is documented in
`docs/phase5/ASAS_PHASE5_DATABASE_BACKUP_RECOVERY.md` §1–§5 — this section
only wires the SCHEDULE for the Docker model:

- **Preferred (host-level timers):** the systemd unit templates in
  `deploy/systemd/` (Agent 2's `asas-backup.service` + `asas-backup.timer`,
  daily 02:30, `Persistent=true`) are written for a bare-metal install
  (`ExecStart` runs the backup from an app prefix). For the Docker model,
  keep the SAME timer pattern and point the service's `ExecStart` at the
  container instead — one line:

  ```
  ExecStart=/usr/bin/docker compose -f /opt/asas/docker-compose.staging.yml exec -T asas-crm bash scripts/backup.sh
  ```

  (plus `docker compose ... up -d || true` as a pre-flight so a stopped
  container is started rather than silently skipped). Do not duplicate the
  units' content here — read them in `deploy/systemd/`.

- **In-container cron: NOT recommended.** The container runs one process
  (the standalone server) by design; adding cron would add a second
  supervisor inside the ephemeral layer while the whole point of the volume
  layout is that state survives without one. If host systemd is impossible,
  the fallback is a host cron line with the same `docker compose exec`
  command — still host-level.

- **Offsite copy:** follow `docs/phase5/ASAS_PHASE5_DATABASE_BACKUP_RECOVERY.md`
  §7 (rsync the verified `backup-*` dirs, manifest-last law, 14d/8w/6m
  rotation, staleness alert at >36 h).

---

## 5. Restore (reference)

Full procedure + this phase's drill PASS evidence:
`docs/phase5/ASAS_PHASE5_DATABASE_BACKUP_RECOVERY.md` §4. Docker-form of the
two commands:

```bash
# DRILL (non-destructive — writes only under /app/db/restore-drills/ on the volume):
docker compose -f docker-compose.staging.yml exec asas-crm \
  bash scripts/restore.sh db/backups/backup-<ts> --drill

# LIVE restore (destructive — both flags required, takes a safety snapshot first):
docker compose -f docker-compose.staging.yml exec asas-crm \
  bash scripts/restore.sh db/backups/backup-<ts> --confirm-restore --i-understand-this-overwrites-the-live-db
docker compose -f docker-compose.staging.yml restart     # the server must restart after a live restore
```

The live restore overwrites `custom.db` + `docs/` **on the volume** — the
image is never touched, which is the point of the storage layout.

---

## 6. Upgrade procedure

```bash
cd /opt/asas && git fetch && git checkout <new-commit>
cp .env.staging.example .env.staging.new && diff .env.staging .env.staging.new   # env contract changes?
# 1. Build the new version as a NEW tag (rollback anchor):
docker build -t asas-crm:v<new> -f Dockerfile .
# 2. Backup first (never upgrade without a fresh verified backup):
docker compose -f docker-compose.staging.yml exec asas-crm bash scripts/backup.sh
# 3. Point the service at the new tag: edit docker-compose.staging.yml
#    (comment `build:`, set image: asas-crm:v<new>) — or:
docker tag asas-crm:v<new> asas-crm:staging
# 4. Migrate the volume BEFORE the new code serves traffic (one-off container;
#    the image has no ENTRYPOINT, so the command cleanly replaces the CMD):
docker compose -f docker-compose.staging.yml run --rm asas-crm bunx prisma migrate deploy
docker compose -f docker-compose.staging.yml up -d
# 5. Health + smoke:
curl -fsS http://127.0.0.1:3000/api/health | jq -e '.dbOk == true and .demoMode == false'
#    migrations count should equal the new chain length; then log in and
#    exercise a list/detail/mutation round-trip.
```

If health fails or smoke breaks: §7.

---

## 7. Rollback procedure

The volume is NEVER rolled back by the image rollback (data written by the
new version stays — that is why step 2 of §6 takes the backup FIRST).

```bash
docker tag asas-crm:v<previous> asas-crm:staging       # or re-pin image: in compose
docker compose -f docker-compose.staging.yml up -d
curl -fsS http://127.0.0.1:3000/api/health | jq -e '.dbOk == true'
```

Schema rollback: the migration chain is additive-only by project policy
(SQLite; per-migration rollbacks are not authored — documented in
`docs/engineering/PRODUCTION_READINESS.md`). If the new version applied NEW
migrations and the old image cannot run against them, restore the §6
pre-upgrade backup instead (§5 live-restore) and re-run the old image —
accepting the data loss window between backup and rollback (documented,
deliberate: forward-fix is preferred over backward-migration).

---

## 8. Monitoring & memory (condition C6 pointer)

- **Probe:** `GET /api/health` (unauthenticated by design) — `dbOk`,
  `dbLatencyMs`, `migrations`, `demoMode`, `rssMb`, `uptimeSec`, `nodeEnv`.
  External uptime check + alert channel are condition C6's deliverable (ops
  runbook); the container already self-reports through this endpoint and
  docker's healthcheck.
- **Memory supervision:** compose `mem_limit: 4g` + `restart: unless-stopped`
  (restart policy ≈ the watchdog P4-H01 found missing). After C1, read
  `rssMb` under real load for a few days and re-size the limit
  (≈ 1.5–2× steady-state); the 4 GB figure is deliberately conservative
  against the measured 2.55 GB dev-class ceiling until production numbers
  exist.
- **Deliberate kill-recovery test** (C6 acceptance): `docker kill` the
  container mid-operation, confirm it comes back `healthy` within ~2 min and
  that the expiry sweeper resumed (in-process scheduler restarts with the
  process; sweeps also run lazily on the next GET /api/notifications — the
  idempotent backstop, `src/lib/server/expiry-scheduler.ts` design notes).

---

## 9. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Container exits immediately, log shows `[asas] PRODUCTION BOOT ABORTED` | The P0-3 gate: placeholder/weak `ASAS_SESSION_SECRET` (generate: `openssl rand -hex 32`) or `ASAS_DEMO_MODE=1` in `.env.staging`. Fix env, `up -d` again. |
| `ps` stuck `health: starting` | Within `start_period` (60 s) this is normal on cold disk. Beyond it: `docker compose logs asas-crm` — usually DB not yet migrated (§3 step 1) → `dbOk:false`. |
| Health `migrations` ≠ 25 (or null) | Volume DB was `db push`-created or migrations missing → run `bunx prisma migrate deploy` (§3). `null` = no `_prisma_migrations` table at all. |
| Uploads disappear after restart | Volume not mounted (check `docker compose ... config` → volumes) or the `/app/.next/standalone/db` symlink is missing (it is created by the Dockerfile — a hand-rolled image variant would lose `db/docs`). |
| EACCES writing under `/app/db` | Volume mounted root-owned — happens when the volume was first created by root before the image's `node`-owned `/app/db` initialization; fix: `docker compose down; docker volume inspect asas-crm-staging_asas-data` and chown via a one-shot root container (`docker run --rm -v ...:/app/db alpine chown -R 1000:1000 /app/db`). |
| OOM kills recur (exit 137) | `rssMb` near 4096 → raise `mem_limit` AND host RAM (§1 sizing law); confirm no second heavy tenant on the host (the Phase 4 kill had a concurrent 1.3 GB workload). |
| Quick-login returns 200 | STOP — security regression: `ASAS_DEMO_MODE` is not 0. Verify `jq '.demoMode' /api/health` and `.env.staging`; the boot gate should have prevented this — investigate before continuing. |

---

## 10. Honest limitations

1. **Never executed.** No docker daemon, no build, no server boot happened in
   the sandbox (standing rules). Correctness is by contract-verification
   (paths, env wiring, standalone requirements cross-checked against
   package.json / next.config.ts / the installed Next 16.1.3 server template —
   evidence `04-standalone-paths-verification.txt`) and YAML parse validation
   (`03-compose-config-validation.txt`). The first real execution is C1 (§2).
2. **Production RSS is unmeasured** — the 4 GB limit and ≥8 GB host guidance
   are derived from DEV-server measurements (Turbopack); re-size after C1.
3. **The image has never been built** — including `bun install --production`
   layer behavior (prisma engines download, bun trusted-postinstall) which is
   documented best-effort from bun/Debian contracts.
