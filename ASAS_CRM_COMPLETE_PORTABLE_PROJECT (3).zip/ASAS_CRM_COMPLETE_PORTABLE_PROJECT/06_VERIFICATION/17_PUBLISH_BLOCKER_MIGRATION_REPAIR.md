# 17 — Native-Publish Root Cause & Migration Repair — سبب فشل النشر الجذري وإصلاحه

- **Mission:** owner directive — make the Z.ai native Publish (نشر التطبيق) deploy successfully with the latest code
- **Date:** 2026-11-17 (UTC)
- **Status:** **ROOT CAUSE FOUND AND FIXED** (project-side); publish confirmation itself remains platform-side (owner's click)

---

## 1. The root cause — السبب الجذري

Migration `20261110150000_p11_lead_acquisition` (authored in Phase 11) ended with:

```sql
ALTER TABLE "Lead" ADD CONSTRAINT "Lead_campaignId_fkey" FOREIGN KEY …
```

**`ALTER TABLE … ADD CONSTRAINT` is PostgreSQL dialect — SQLite has no such statement.** Consequences:

1. Every **fresh-database** `prisma migrate deploy` failed at exactly that line (**P3018**) — the chain reached 29/30, then aborted.
2. The Z.ai native publish pipeline (`.zscripts/build.sh` → `.zscripts/database-runtime-build.sh`) initializes the artifact database via `bun run db:deploy` on a FRESH SQLite file under `set -euo pipefail` — the failure aborted the whole build → the Publish control failed deployment ("Sorry, there was a problem deploying the code"), persisting across phases (documented as the Phase 11/12 unresolved blocker).
3. The dev preview kept working only because the sandbox dev DB was reconciled separately (`prisma db push`) and later re-created schema-only by the platform's restore law — masking the broken chain.

The original file also **never created the `Opportunity.campaignId` FK** it declared in schema.prisma, and schema.prisma never declared the two P11 indexes the migration created (latent drift).

## 2. The repair — الإصلاح (2026-11-17)

| # | Change | Where |
|---:|---|---|
| 1 | Migration #30 rewritten: the two FKs are now created through the **canonical SQLite 12-step table rebuild** (data-preserving `INSERT…SELECT`, FK declared inline in the rebuilt table; full index set recreated after each rebuild) | `prisma/migrations/20261110150000_p11_lead_acquisition/migration.sql` |
| 2 | `Opportunity_campaignId_fkey` added to the chain (was missing entirely from the original migration) | same file |
| 3 | The two P11 indexes declared in the schema (convergence law): `@@index([orgId, campaignId])` on Lead, `@@index([orgId, sourceOrigin])` on Opportunity | `prisma/schema.prisma` |
| 4 | Mirrored into this archive: `02/sqlite_source` (migrations history + schema) and `01_GITHUB_READY_SOURCE` (prisma migrations + schema) — both copies now identical to the repaired live files | this archive |

## 3. Verification (all executed this session) — التحقق

| # | Check | Result |
|---:|---|---|
| 1 | Fresh-chain drill (`migrate deploy` on a brand-new SQLite file) | **30/30 applied successfully** (was P3018 at #30) |
| 2 | Convergence: `prisma migrate diff` fresh-DB → schema.prisma | **EMPTY** ("This is an empty migration") — chain end-state == schema exactly |
| 3 | Zero-users guard on the fresh artifact DB | users = 0 ✓ (Phase 7.2 artifact law holds) |
| 4 | Fresh DB integrity + FK validation | `integrity_check: ok` · `foreign_key_check: 0 violations` · both campaignId FKs present |
| 5 | Live dev DB repaired with the same rebuild SQL (pre-repair backup taken first) | both FKs added · `integrity: ok` · 0 FK violations |
| 6 | Dev ledger resolved (`prisma migrate resolve --applied`) | `prisma migrate status`: **"Database schema is up to date!"** |
| 7 | Dev preview re-seeded (R13 recovery law) + browser E2E | demo persona login → dashboard renders · zero page errors |
| 8 | Type gate + lint on the latest code | `tsc --noEmit`: 0 errors · `eslint`: 0 errors |

## 4. Honest disclosures — إفصاحات صادقة

- **No data loss occurred**: the pre-repair backup (`db/backups/backup-20261117T232723Z/`, taken BEFORE any repair statement) was verified to contain **zero users/leads/apartments** — the sandbox dev DB had already been re-created schema-only by the platform's restore law between sessions. The repair only ADDED structure.
- The artifact database remains **schema-only by law** (Phase 7.2): the published instance creates its real OWNER through the in-app first-run bootstrap (`POST /api/auth/bootstrap`) — never ships sandbox demo credentials.
- The portable archive's PostgreSQL target (`02/postgres_target/`) is unchanged and does not carry the two auxiliary P11 indexes — non-blocking for the Supabase path (add later via a PG migration if desired).
- **Publish confirmation is platform-side**: everything project-side is now green (fresh-chain 30/30, typecheck, lint, env posture `ASAS_DEMO_MODE=0`, strong session secret, standalone output verified present). The final proof requires the owner pressing **نشر** — if the platform reports anything other than success after this repair, the platform-side execute log is the next evidence source (only Z.ai can retrieve it).

## 5. What the owner should do after pressing Publish — ما بعد النشر

1. Open the publish link. The login screen appears (fresh schema-only DB — by design).
2. Use the first-run bootstrap (the login screen's activation-code / first-run flow) to create the **OWNER** account: email + name + a password ≥ 12 chars (the public demo password is rejected). You land directly in the CRM.
3. The floating download button serves the complete portable project archive from the published app.

## 6. ملخص عربي

كان السبب الجذري لفشل زر "نشر التطبيق" عبارةً عن سطر واحد بلهجة PostgreSQL داخل الترحيلة رقم 30 — لهجة لا تفهمها SQLite أبداً، فكان بناء قاعدة النشر ينهار عندها في كل مرة. أُعيدت كتابة الترحيلة بأسلوب إعادة البناء القياسي لـ SQLite (مع حفظ البيانات)، وأُضيف مفتاح كان مفقوداً أصلاً، وأُعلن الفهرسان في المخطط. أثبتَت تمريرة نظيفة كاملة نجاح 30/30 مع تقارب تام مع المخطط، وقاعدة المعاينة أُصلحت ورُسّيت وبُذرت وتم التحقق منها بالمتصفح. كل شيء في الجهة الهندسية أصبح أخضر — يبقى الضغط على "نشر" لدى المالك ثم إنشاء حساب المالك من شاشة الدخول (قانون القاعدة النظيفة).
