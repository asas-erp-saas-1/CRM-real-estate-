# 18 — v2.1 UI Audit & Fix Sweep — تدقيق واجهة المستخدم الشامل وإصلاحها

- **Mission:** owner directive — «راجع كل صفحات واجهة المستخدم، اعثر على كل أخطائها وصحّحها» (review every UI page, find every error, fix it)
- **Date:** 2026-11-18 (UTC)
- **Status:** **COMPLETE — 47 defects found and fixed; all gates green** (see §5)
- **Scope delta vs v2:** 52 source files updated, 1 dead file removed, this report + regenerated `SHA256SUMS` added

---

## 1. Method — المنهجية

Two complementary layers, nothing accepted on lint alone:

1. **Static gates:** `eslint .` (0 errors) + `tsc --noEmit` (0 errors) over the whole workspace.
2. **Five parallel code audits** (READ-ONLY agents) covering every UI surface: dashboard/analytics/journey (UI-A), leads views/drawer/dialogs (UI-B), pipeline/properties/finance (UI-C), visits/tasks/inbox/SAV/audit/settings (UI-D), shell/i18n/login/global + full AR/FR/EN key-parity programmatic check (UI-E). Combined coverage: ~150 component files + the i18n dictionaries (2,813 keys × 3 languages — parity verified programmatically: **0 mismatches**).
3. **Browser verification** (headless, real login, real data): all 13 pages swept in FR and AR, light and dark, desktop (1440) and mobile (375), plus targeted end-to-end proofs of each critical fix (§4).

## 2. Findings fixed — عيوب وُجدت وأُصلحت (47)

### HIGH (3)

| # | Where | Defect | Fix |
|---:|---|---|---|
| 1 | `views/visits/visits-calendar.tsx` | Month grid built from the cursor's week Monday — after «Aujourd'hui» (or week→month with mid-month cursor) days 1–15 of the month **vanished with their visit dots** | Grid anchored to `startOfWeek(startOfMonth(cursor))` — verified in browser: grid now renders `26…31, 1…6…` for November 2026 |
| 2 | `views/visits-view.tsx` + calendar | The MANAGER+ «Non staffées» chip was a **dead toggle in calendar mode** (active-looking chip, unfiltered grid) | `unstaffed` prop threaded into the calendar query — verified in browser: request now carries `&unstaffed=1` |
| 3 | `views/journey-view.tsx` | Phone numbers rendered **scrambled in Arabic RTL** (group order reversed: `56 34 12 0555`) | `ltr-token` bidi isolation — verified in browser: `0663 12 35 14` etc. render correctly |

### MEDIUM (27) — user-facing correctness

**Journey/analytics/dashboard (UI-A):** search-miss misdiagnosed as «Journey up to date» empty state (now a proper no-results variant + 2 i18n keys ×3 langs); funnel stage-name tooltip clipped by `overflow-hidden` (segment rounding moved to first/last); dashboard Finance/SAV attention cards silently vanished on non-403 API errors (now keep shell + `role="alert"` retry chip); hardcoded French delay units `3 j 4 h` (now `analytics.acquisition.delay.*` keys ×3 langs); month-trend axis labels stuck in the previous language after a language switch.

**Leads (UI-B):** raw i18n keys `source.EMAIL`/`source.SMS` leaked to UI (keys added ×3 langs); every 422 misreported as «no requirement» in the match flow (now only `NO_REQUIREMENT`, plus client-side `budgetMin ≤ budgetMax` validation with inline message); stale-page empty table after bulk archive (page now clamps); saved-search delete was mouse-only with no confirmation (now first-class menu items + AlertDialog confirm — keyboard reachable); single-sided budgets rendered `5M DA – —` in the drawer (now `≥`/`≤` like the list); day-chip «Hier» broke at month/year boundaries; non-CSV file misreported as «empty CSV» (new `notCsv` key); preview sources drifted from `SOURCES` constant (missing `PUBLIC_CAPTURE`) + hardcoded `OK` badge (new `rowOk` key); dead `LeadsPagination` file removed; mobile card tooltip showed the un-localized identity; task-highlight focus steal (inline callback identity); bulk Restore had no pending guard (now a `useMutation` with spinner gating).

**Pipeline/properties/finance (UI-C):** create-offer draft survived close→reopen with no dirty-guard (mount-on-open + `useDirtyGuard`); in-form stage move destroyed the unsaved edit draft (stage select disabled while editing, `oppd.edit.stageLocked` key ×3); import-units «Ignorer» was a dead option — server re-injected auto-detected columns (wire sentinel `__ignore__` honored by preview AND commit); locked terminal trust states offered illegal backward transitions that the server 422s (forward-only selects, disabled outside rebase); hardcoded `≤ 7j` chip and French sr-only table caption (2 finance keys ×3); raw reservation enum in installment detail (now `resv.status.*` with fallback); reservation picker truncated at 200 (now 500 + cap disclosure); UTC `toISOString` expiry off-by-one (now `dateInputValue`); duplicate React keys for equal option lines.

**Visits/SAV/inbox/settings (UI-D):** resolve composer never closed after success (inverted condition); French sr-only captions in SAV and team tables (2 keys ×3); deal-link lookup truncated at 200 org opportunities (now server-side `leadId` filter — route already supported it); unanchored status regex matched any string *containing* a status word (now fully anchored, includes `OPTIONED`); assign dialog flashed a false «no eligible assignees» while the roster loaded (skeleton rows); fake `tablist/tab` ARIA on queue chips (now `group` + `aria-pressed`); `ROLE_TONE.OPERATIONS` fallback referenced a nonexistent key (now `FIELD_REP`); field-visit confirm gate diverged from the shared ladder (now `ladderOf(…).canConfirm`).

**Global/session (UI-E):** expired session stranded the SPA in error shells forever (401 → `asas:session-expired` event → session refetch → LoginOverlay — **verified end-to-end in browser**: cookie cleared → automatic overlay, no manual reload); session-error card hardcoded French + raw «network» literal (trilingual keys ×3); notification popover stayed open covering the destination after selection (verified: closes + navigates); floating download pill overlapped the footer's start-side text (measured fix `ps-[160px] sm:ps-[256px]` — verified no overlap in both LTR and RTL); `⌘K` legend Mac-only (now `Ctrl K` on PC); error boundary always opened in French (now starts in the persisted `<html lang>`); compact money formatter had no milliard unit (`10 000M DA` → now `10 Md DA` / `10B DA` / `10 مليار دج`).

### LOW follow-throughs (bundled in the same sweep)

Contact-delay bucket labels were server-French (`< 1 h`…`1–3 j`) — now mapped key→label per language (5 keys ×3 langs; verified in Arabic: `< 1 س ; 1–4 س ; 4–24 س ; 1–3 ي ; > 3 ي`); the follow-up lint hardening (lazy initializer instead of set-state-in-effect; memo restructure instead of a flagged unnecessary dep).

## 3. What was audited and found CLEAN — ما فُحص وسَلِم

Explicitly verified clean (no changes needed): React key/hook rules across all audited files; hydration safety (SSR renders only the language-independent splash; locale-dependent trees mount client-only); race-condition handling (`placeholderData`, expectedUpdatedAt guards, optimistic rollbacks); RTL logical properties and icon mirroring everywhere else; loading/error/empty state ladders on every view; the full AR/FR/EN key-parity (2,813 keys per language); Arabic 6-form plural machinery call sites; drag-drop pipeline engine; zod contracts. The `999%` growth cap on analytics KPI chips is **by documented design** (display cap, in-code comment), not a defect.

## 4. Browser evidence — أدلة التحقق بالمتصفح

All 13 pages × FR/AR × light/dark × desktop/mobile: content renders with real data, **zero console errors, zero page errors**. Targeted proofs (real interactions): month-grid full-month render after «Aujourd'hui»; `&unstaffed=1` in the calendar request; RTL phone order; lead creation write-path (dialog → API → DB verified, test row cleaned up); global search results; lead drawer tabs; saved-search save→share→delete-confirm cycle; notifications popover closes and navigates; footer/pill geometry measured non-overlapping in both directions; Arabic delay units and bucket labels; 401 session-expiry → automatic LoginOverlay.

## 5. Gates — البوابات النهائية

- `bunx tsc --noEmit`: **0 errors**
- `bun run lint`: **0 errors** (7 pre-existing warnings in non-shipped folders only)
- i18n parity guard at module load: **fr = en = ar** after adding ~30 new keys
- `SHA256SUMS`: regenerated for the full v2.1 tree (see below)
- Dev server: running, hot-reloaded, no runtime errors in `dev.log`

## 6. v2.1 package delta — تغيّر الحزمة

52 files updated under `01_GITHUB_READY_SOURCE/src/`, 1 dead file deleted
(`src/components/crm/views/leads/pagination.tsx`), this report added,
`06_VERIFICATION/README.md` index updated, `SHA256SUMS` regenerated.
No other directories touched. The in-app floating download button's constants
(name/size/files/sha256) were updated to this exact artifact.
