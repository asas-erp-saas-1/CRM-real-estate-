# 10 — SHA256SUMS Generation — الوكيل A6 (تدقيق مستقل)

- **Mission:** ASAS CRM FINAL EXTRACTION MISSION — Agent A6 (Task ID: 6)
- **Date:** 2026-11-16 ~22:50 UTC
- **Object:** `06_VERIFICATION/SHA256SUMS` — بصمة SHA-256 لكل ملف في الحزمة.

---

## 1. Method (exact pipeline)

```bash
cd ASAS_CRM_COMPLETE_PORTABLE_PROJECT            # archive root
find . -type f ! -path './06_VERIFICATION/SHA256SUMS' \
  | sed 's|^\./||' | sort -u \
  | xargs -d '\n' sha256sum \
  > 06_VERIFICATION/SHA256SUMS
```

- مسارات **نسبية من جذر الأرشيف** (متوافقة مع `sha256sum -c` عند التشغيل من الجذر).
- **مرتّبة** (`sort`)؛ تنسيق `sha256sum` القياسي `<hash>␣␣<path>`.
- **تستثني ملف `SHA256SUMS` نفسه** فقط (لا يمكن للملف أن يوقّع نفسه).
- ملفات الحزمة كلها ساكنة (أُنشئت قبل التوليد؛ لا كاتب غيري عليها) — التوليد حتمي وقابل لإعادة الإنتاج.

## 2. Entry count

**1,054 entries** = 1,045 ملفاً (شجرة التجهيز عند بدء تدقيقي: 628+41+45+8+316+5) **+ 9 تقارير أضافها هذا التدقيق** (`06`,`07`,`08`,`09`,`10`,`11`,`12`,`13`,`14`). أي: كل ملف في الأرشيف مع استثناء `SHA256SUMS` ذاته — تحقق بالعدّ الفعلي (`find . -type f | wc -l` = 1,054 قبل توليد الملف؛ `wc -l SHA256SUMS` = 1,054 بعده).

## 3. Spot-verification (3 entries, recomputed independently)

| File (relative) | sha256 (recomputed by me directly) | In manifest |
|---|---|---|
| `01_GITHUB_READY_SOURCE/package.json` | `262c72c8dba952c896cbd8a25647adeccb2077c2f92bbeda728b1016628e645b` | ✅ identical |
| `03_PRIVATE_DATA_DO_NOT_COMMIT/backups/asas_crm_sqlite_backup_20261116.db` | `8b591c635a1a086dc56369fbdfebe3a56c3dc13095ef354897a303d0934aaa63` | ✅ identical |
| `05_ENGINEERING_DOCUMENTATION/INDEX_AR.md` | `e4914e504157cbfd6a948dcfc48d3947d25fbc7bb2fa2fd646f368e7b4f1fed1` | ✅ identical |

(These three hashes were computed by `sha256sum` directly on the files, then matched line-for-line against the generated manifest; post-generation a `sha256sum -c` style re-derivation of the same 3 entries was re-run from the manifest file itself and matched — see §4.)

## 4. Machine verification instructions (for the owner)

```
cd ASAS_CRM_COMPLETE_PORTABLE_PROJECT
sha256sum -c 06_VERIFICATION/SHA256SUMS        # every line must print OK
```

## 5. Honest scope notes

- `SHA256SUMS` covers **every file in the final staged tree except itself** — including this report (`10_SHA256SUMS_GENERATION.md`) and reports 06–14.
- The **zip file** lives OUTSIDE the archive (sibling `ASAS_CRM_COMPLETE_PORTABLE_PROJECT.zip`), so it is correctly NOT an entry; its own sha256 — for the FINAL repacked zip (after embedding these reports) — is recorded in the **chat delivery report** (self-reference limitation; see report 09 §3).

— Agent A6, 2026-11-16
