# VERCEL & SUPABASE READINESS — VERIFICATION REPORT (Agent A4+A5, Task ID 4)

**Scope:** read-only code investigation of the ASAS CRM source as found in the
setup environment (`/home/z/my-project`, the same code staged into
`01_GITHUB_READY_SOURCE`), plus authoring of the Vercel/Supabase guide set.
Every claim below carries a `file:line` citation from that source.

**Honest scope statement — what this report is NOT:**
- No GitHub, Supabase, or Vercel account exists in the setup environment; no
  account-side step was executed or assumed.
- The production build was **not** run — `bun run build` / `next build` is
  **forbidden by the sandbox policy** for this agent; build behavior statements
  are taken from the repository's own configuration and documented evidence
  (cited), not from a build executed here.
- The archive's `02_DATABASE_ARCHITECTURE` tooling is **now delivered and
  presence-verified** in the staging archive:
  `postgres_target/migrations/00000000000000_init_postgres/migration.sql`,
  `postgres_target/schema_postgres.prisma`, and
  `tools/sqlite_to_postgres_importer.mjs` with `--dry-run` (default),
  `--export`, `--verify` flags confirmed in the tool source (flag parsing at
  `sqlite_to_postgres_importer.mjs:69-75`; usage text declares "This tool
  NEVER connects to PostgreSQL and NEVER runs at Vercel build time"). This
  agent did not create or runtime-execute those tools; their operational
  authorship is the database track's deliverable (`IMPORTER_README_AR.md`).

---

## 1. Serverless constraints findings table (local-disk / in-process dependencies)

| # | Constraint | Evidence (file:line) | Serverless impact | Required follow-up (documented) |
|---|---|---|---|---|
| C1 | SQLite file database | `prisma/schema.prisma:9-11` (`provider = "sqlite"`, `url = env("DATABASE_URL")`); local value `file:./db/custom.db` at `.env.example:7` | Writes do not survive function recycling — fatal for any production use on Vercel | **Mandatory before production**: PostgreSQL switch via the archive's `02_DATABASE_ARCHITECTURE/postgres_target` chain + data import; repo-side reference: `prisma/schema.postgres.prisma` (provider `postgresql`), `docs/database/SUPABASE_SETUP.md` §6 (150–161) |
| C2 | Document binaries on local disk | `src/lib/server/documents.ts:19` (`DOCS_DIR = path.join(process.cwd(), "db", "docs")`); upload `writeDocFile` → `writeFile` at `documents.ts:61-64` called from `src/app/api/documents/route.ts:169`; download `readDocFile` at `documents.ts:93-100` called from `src/app/api/documents/[id]/file/route.ts:56`; delete `unlink` at `documents.ts:195-201` | Uploaded files vanish on instance recycle; DB rows persist; download then 404s `DOC_NOT_FOUND` | Supabase Storage **adapter replacing `writeDocFile/readDocFile/deleteDocFile`** — explicitly documented as *NOT implemented* ("documented next work item") in `docs/operations/VERCEL_SETUP.md:130-136`; bucket upload of existing files is covered by guide 7 (preservation), with the strict rule that `Document.storedName` must not be rewritten to URLs |
| C3 | In-process expiry scheduler | `src/lib/server/expiry-scheduler.ts:36` (`setInterval`, 60 000 ms at `:26`), booted from `src/instrumentation.ts:32`; `.unref()` at `:64`; globalThis singleton at `:32-34` | Sweeps silently stop when instances scale to zero/archive (the exact D9 regression the scheduler fixed) | External cron (e.g. Vercel Cron) hitting the demand-driven sweep routes (`/api/notifications`, `/api/reservations`, `/api/offers` — `expiry-scheduler.ts:3-5` header) |
| C4a | Lead-capture rate limits in memory | `src/lib/server/lead-capture.ts:228-229` (`hitsByToken`, `hitsByIp` Maps), `:312` (`lastSubmitAtByPhone`), `:241` (`admit`) | Per-instance budgets multiply into nothing on multi-instance serverless | Shared store (Redis-class) if these surfaces face heavy internet exposure |
| C4b | Activation-token redeem throttle in memory | `src/lib/server/auth-tokens.ts:194` (`redeemAttempts` Map) | Same as C4a | Same as C4a |
| C5 | Per-process observability & cache | `src/lib/server/obs.ts:37-38,54-60` (globalThis ring buffers/maps); `src/lib/server/notification-cache.ts:41,99-106` (30 s TTL cache); `src/lib/server/duplicates.ts:214` (aggregate cache) | Metrics/cache reset per instance/cold start; `/api/metrics` becomes per-replica, not fleet-wide | Decide what survives (external metrics sink / cache policy) — documented posture `docs/operations/VERCEL_SETUP.md:25-29` |
| C6 | PDF rasterization needs poppler binaries | `src/lib/server/documents.ts:140` (`execFileAsync("pdfinfo", …)`), `:172-175` (`execFileAsync("pdftoppm", …)`), `:166` (`mkdtemp` in `tmpdir()`) | `pdfinfo`/`pdftoppm` are absent from Vercel's function image → PDF analysis + thumbnail routes fail there; images still work (307 path: `src/app/api/documents/[id]/thumb/route.ts:52-59`) | Self-contained bundle or external conversion service if PDF analysis is required on serverless |
| C7 | AI provider file-based config | `src/lib/server/ai-provider.ts:3-8` (`.z-ai-config` resolved from `process.cwd()` → `~/.z-ai-config` → `/etc/.z-ai-config`; **no env vars**) | Expected steady state on Vercel: `503 AI_PROVIDER_UNAVAILABLE` (`ai-provider.ts:28-38`) on the two AI routes; rest of CRM unaffected | Nothing to configure; optional future provider swap behind `requireAiProvider()` |
| C8 | `process.cwd()` reads | `src/lib/server/documents.ts:19`; `src/lib/db.ts:51` (dev-only self-heal, gated `NODE_ENV !== 'production'` at `db.ts:65`); `src/lib/server/ai-provider.ts:4` (comment, config resolution) | `db.ts:51` path is dev-gated (no-op in production); the operative `process.cwd()` risk is C2 | Covered by C2/C7 follow-ups |
| C9 | Standalone output mode | `next.config.ts:10` (`output: "standalone"`) | None on Vercel — Vercel manages Next.js builds and ignores the self-hosting semantics (`docs/operations/VERCEL_SETUP.md:63-68`); `bun run start` (`package.json:9`) uses it for self-hosted Docker only | No change needed; removing it would break the sanctioned self-hosted path |
| C10 | No postinstall Prisma generation | `package.json:33-35` (only `prisma.seed` config; no postinstall hook) — finding documented in `docs/operations/VERCEL_SETUP.md:105-112` | Default build command would ship without a generated Prisma client → runtime client-initialization errors on data routes | Vercel Build Command must be `bunx prisma generate && next build` (guide 2, step 2) |

**Corrections vs. stale in-repo docs (evidence-based):**
- `docs/operations/VERCEL_SETUP.md` header note (lines 19–24) states the login
  lockout window state is in-memory; the **current code is DB-backed**
  (`src/lib/server/auth.ts:104-117` reads `db.loginFailure`; `:120-130`
  writes it) — so the lockout itself survives serverless correctly. Only C4a/C4b
  rate limits are process-local.
- `docs/operations/ENVIRONMENT_VARIABLES.md:15` still describes demo mode as
  "1/unset = ON (defaults ON)"; the governing code is strict opt-in:
  `isDemoMode()` returns true **only** for the exact string `"1"`
  (`src/lib/server/session.ts:148-150`), matching `.env.example:17-26`
  ("OFF BY DEFAULT … Unset / 0 = OFF"). Guides follow the code.

**Storage-ground-truth note (verified read-only):** `db/custom.db` in the setup
environment holds **0 rows** in `Document` (41 tables present); per the DB
track's `03_PRIVATE_DATA_DO_NOT_COMMIT/DATA_CLASSIFICATION_AR.md` §1 **all 40
user tables hold 0 rows** at backup time (only `_prisma_migrations` is
populated) — so a data import from this source yields matching zero counts
and the first production login flow is the Phase 7.2 owner bootstrap
(`src/lib/server/bootstrap.ts:17-21`, surfaced via
`src/app/api/auth/session/route.ts:26-33`) or `scripts/provision-owner.ts`.
No `db/docs/` directory exists in the checkout. The root-level `/upload/`
directory present in the setup sandbox is platform pasted-content staging
(root-owned, gitignored at `.gitignore:88`), **not** application data; the
extraction staged it as `03_PRIVATE_DATA_DO_NOT_COMMIT/uploaded_files`
(39 files + sha256 manifest) classified "possibly real → always private",
with **no `Document` rows linking to it**.

## 2. Environment variable inventory (authoritative from code)

Application-level (these are the only variables to set on Vercel):

| Variable | Usage sites (file:line) | Production value guidance | Secret? |
|---|---|---|---|
| `DATABASE_URL` | `prisma/schema.prisma:11` (`url = env("DATABASE_URL")` — read by the Prisma client at runtime); presence checked `scripts/provision-owner.ts:109`; template `.env.example:7,13` | Supabase Pooler URI. Session Pooler `postgresql://postgres.<ref>:<pw>@aws-0-<region>.pooler.supabase.com:5432/postgres` (repo-recommended, `.env.example:13`, `docs/database/SUPABASE_SETUP.md:174-178`); alternative documented for serverless pressure: Transaction Pooler `:6543` + `?pgbouncer=true` (`SUPABASE_SETUP.md:185-192`) | **Yes** (embeds DB password) |
| `ASAS_SESSION_SECRET` | `src/lib/server/session.ts:33` (HMAC key for the `asas_user` cookie); boot gate `src/lib/server/boot.ts:37,45,50` (presence / placeholder rejection / ≥32 chars); presence-only flag `src/app/api/health/route.ts:102` | Fresh `openssl rand -hex 32`; never a previously committed/shared value; placeholders rejected by name (`boot.ts:21`) | **Yes** |
| `ASAS_DEMO_MODE` | `src/lib/server/session.ts:149`; `src/lib/server/boot.ts:57`; `src/app/api/auth/login/route.ts:67,74`; `src/app/api/auth/session/route.ts:26`; `src/app/api/health/route.ts:44` | `0` — mandatory in Production (`1` crashes production boot: `src/instrumentation.ts:24`) | No |
| `ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION` | `prisma/seed.ts:791` (env name), `:799` (refusal condition), `:832` (enforcement) | **Unset** (never set in production) | No (but enabling it is a hazard) |
| `NODE_ENV` | `src/lib/server/boot.ts:34`; `src/app/api/auth/login/route.ts:40` (`secure` cookie); `src/lib/db.ts:19,65,93,118-131`; `prisma/seed.ts:799` | Managed by the platform (Vercel sets `production`); never set manually | No |

Tooling-only (NOT to be set on Vercel): `ASAS_BASE_URL`, `ASAS_PERF_USER`,
`ASAS_PERF_PASSWORD`, `ASAS_PERF_N` (`scripts/perf-baseline.ts:23-26`);
`ASAS_SQLITE3_BIN` (`scripts/lib/backup-engine.mjs:34`, exported by
`scripts/backup.sh:22`); `ASAS_BACKUP_KEEP` (`scripts/lib/backup-logic.mts:26`);
`OWNER_EMAIL`/`OWNER_NAME`/`OWNER_PASSWORD` (`scripts/provision-owner.ts:90-92`).

AI provider: **no environment variables** — file-based `.z-ai-config` only
(`src/lib/server/ai-provider.ts:3-8`); absence ⇒ `503 AI_PROVIDER_UNAVAILABLE`
(`:28-38`). No `NEXT_PUBLIC_*` variables exist (client bundle is static —
`docs/operations/ENVIRONMENT_VARIABLES.md:18`).

## 3. Demo-mode enforcement — actual behavior at `ASAS_DEMO_MODE=0` vs `1`

Gate function: `isDemoMode()` returns true **iff** the env value is exactly
`"1"` (`src/lib/server/session.ts:148-150`). Unset/`0`/anything else = OFF.

| Surface | `ASAS_DEMO_MODE=1` | `ASAS_DEMO_MODE=0` (production posture) |
|---|---|---|
| Production boot | **Crashes**: `src/instrumentation.ts:9-25` → `assertProductionEnvironment` (`src/lib/server/boot.ts:57-64`) → violation `DEMO_MODE_PRODUCTION` → `process.exit(1)` (`instrumentation.ts:24`; explicit exit because Next 16 standalone catches register() rejections — comment at `:15-23`) | Boots normally |
| Runtime drift warning | `isDemoModeMisconfigured()` warn at `session.ts:166-171` | No warning |
| Passwordless quick-login (`{userId}` to POST /api/auth/login) | Allowed, constrained to the designated demo org (first org by createdAt — `src/lib/server/demo-org.ts:22-28`) and lockout-respecting (`src/app/api/auth/login/route.ts:77-128`) | **403 `DEMO_MODE_DISABLED`** (`login/route.ts:74-76`); if also production-misconfigured: 500 `DEMO_MODE_PRODUCTION_MISCONFIG` (`:67-73`) |
| Unauthenticated `demoUsers` listing (GET /api/auth/session) | Lists up to 8 active users of the demo org (`session/route.ts:35-48`) | **Empty list** — `demoUsers: []` — plus the first-run `bootstrapAvailable` signal when zero users exist (`session/route.ts:26-33`; `src/lib/server/bootstrap.ts:17-21`) |
| Demo-password badge on the login card | Renders only when `demoUsers.length > 0` (`src/components/crm/login-overlay.tsx:1031-1048`) — discloses the documented demo password | **Never rendered** — no demo credential disclosure to visitors |
| Health probe | `demoMode:true` | `demoMode:false`, `demoModeMisconfigured:false`, `sessionSecretConfigured:true` (`src/app/api/health/route.ts:44,97-102`); deploy gate contract `curl …/api/health \| jq -e '.demoMode == false'` (`:3-8`) |
| Demo seed (`prisma/seed.ts`) | Runs in non-production; plants OWNER + 7 personas with the public password `asas1234` (`seed.ts:30`, header `:4-11`) | **Refuses** under `NODE_ENV=production` without exactly `ASAS_ALLOW_DEMO_SEED_IN_PRODUCTION=1` — exit 1, zero DB writes (`seed.ts:787-832`); sanctioned owner path is `scripts/provision-owner.ts` (rejects `asas1234` and <12-char passwords — `provision-owner.ts:18-20`) |

**Production conclusion (as coded):** with `ASAS_DEMO_MODE=0` on Vercel there
are no demo personas, no passwordless logins, no demo-credential badge, the
server refuses to boot if someone forces demo on, and the only login path is
real credentials (scrypt + DB-backed lockout).

## 4. Honest status classification

| Artifact / step | Status |
|---|---|
| `04_VERCEL_AND_SUPABASE/` — 8 Arabic guides (GitHub repo setup, Vercel deployment, Supabase setup, env vars, deployment checklist, post-deploy verification, storage migration, rollback & maintenance) | **READY** — documentation artifacts written and grounded in cited code evidence (this report) |
| `CHATGPT_GITHUB_SUPABASE_VERCEL_HANDOVER_AR.md` (archive root) — 15-step sequential owner handover with AI-assistant rules | **READY** — documentation artifact |
| GitHub private repo creation + source import (guide 1) | **REQUIRES OWNER CREDENTIALS** — account creation/ownership; no account existed or was assumed here |
| Supabase project creation, SQL chain application, data import, bucket creation (guides 3, 7; handover steps 4–10) | **REQUIRES OWNER CREDENTIALS** — all account/dashboard steps; the SQL itself was structurally validated only by the DB track (per their docs), never executed against live Supabase here |
| Vercel import, variable configuration, deployment, post-deploy verification (guides 2, 6; handover steps 11–13) | **REQUIRES OWNER CREDENTIALS** + **NOT TESTED HERE** — the actual deploy was not performed; the production build (`bun run build` / `next build`) is **forbidden by sandbox policy for this agent and was not run**; build-behavior statements derive from cited repository configuration and its documented evidence only |
| Serverless constraints remediation (storage adapter for `db/docs`, external cron for the expiry sweeper, shared rate-limit store, poppler replacement) | **NOT TESTED HERE / NOT IMPLEMENTED IN CODE** — documented follow-ups with file:line; the Supabase Storage adapter is explicitly "NOT implemented — documented next work item" (`docs/operations/VERCEL_SETUP.md:130-136`) |

## 5. Deliverables written by this agent (this mission)

1. `04_VERCEL_AND_SUPABASE/GITHUB_PRIVATE_REPO_SETUP_AR.md`
2. `04_VERCEL_AND_SUPABASE/VERCEL_DEPLOYMENT_AR.md`
3. `04_VERCEL_AND_SUPABASE/SUPABASE_SETUP_AR.md`
4. `04_VERCEL_AND_SUPABASE/ENVIRONMENT_VARIABLES_AR.md`
5. `04_VERCEL_AND_SUPABASE/DEPLOYMENT_CHECKLIST_AR.md`
6. `04_VERCEL_AND_SUPABASE/POST_DEPLOY_VERIFICATION_AR.md`
7. `04_VERCEL_AND_SUPABASE/STORAGE_MIGRATION_AR.md`
8. `04_VERCEL_AND_SUPABASE/ROLLBACK_AND_MAINTENANCE_AR.md`
9. `CHATGPT_GITHUB_SUPABASE_VERCEL_HANDOVER_AR.md` (archive root)
10. `06_VERIFICATION/04_VERCEL_SUPABASE_READINESS.md` (this report)
