# 02_DATABASE_SCHEMA_VERIFICATION.md — Agent A2 (Database Architecture, dual-track)

**Mission:** build `02_DATABASE_ARCHITECTURE/` (SQLite source preserved verbatim + a real PostgreSQL conversion with a complete independent PG init migration + Arabic docs) and verify everything.
**Date of run:** 2026-11-16 (sandbox `/home/z/my-project`, read-only; all writes confined to `tmp-extraction/ASAS_CRM_COMPLETE_PORTABLE_PROJECT/02_DATABASE_ARCHITECTURE/**` and this file).
**Tooling used:** local Prisma CLI 6.19.2 (`node_modules/.bin/prisma` / `bunx`), `bun:sqlite` (read-only DB introspection), throwaway parse/verify scripts kept OUTSIDE the deliverable during the build and deleted afterwards (method described below).

---

## 1. Actual counts (machine-verified from `prisma/schema.prisma`)

| Item | Count | How verified |
|---|---|---|
| Models | **40** (matches the mission's expectation of 40) | `grep -c "^model "` + AST parser |
| Prisma enums | **0** (ADR-001 enum-as-String; SQLite provider) | `grep -n "^enum "` — none |
| `@@map` / `@map` | **0** — table names = model names in BOTH engines (1:1 import mapping) | grep — none |
| Scalar fields (physical columns) | **516** (String 341 · DateTime 110 · Float 30 · Int 20 · Boolean 14 · BigInt 1) | AST count, cross-checked: column parity check below found exactly 516 columns in the live DB |
| Relation object fields (non-column) | 99 forward + 121 total `@relation` occurrences | AST + grep |
| Foreign-key constraints (relations with `fields:`) | **99** | AST; migration contains exactly 99 `FOREIGN KEY` statements |
| `@@index` blocks | **89** | AST |
| `@@unique` composite blocks | **15** | AST |
| Single-field `@unique` | **8** (Organization.slug, User.email, Lead.convertedContactId, Contact.leadId, Requirement.leadId, LeadCaptureToken.tokenHash, Document.storedName, AuthToken.tokenHash) | AST |
| Composite `@@id` | **2** (LeadTag, VisitApartment) | AST |
| `@default(now())` / `@updatedAt` | 39 / 38 | AST |
| Money fields converted `Float → Decimal(18,2)` | **24** | decision table §3 |
| Non-money `Float` kept (DOUBLE PRECISION) | 6 (Apartment.surface, Apartment.totalSurface, Requirement.surfaceMin/Max, PropertyMatch.score, Offer.discountPercent) | §3 |
| `@db.Text`-annotated String fields | 48 | §3 of MAPPING doc |
| Live SQLite DB (`db/custom.db`) | 41 tables (40 business + `_prisma_migrations`), **0 rows in every business table** (schema-only state), 118 indexes | read-only `bun:sqlite` introspection |
| SQLite migration chain copied | 30 timestamped dirs + `migration_lock.toml` (provider = sqlite) | `find` + diff |

---

## 2. `prisma validate` — verbatim results

### 2.1 The exact command from the mission brief

```
$ cd /home/z/my-project && bunx prisma validate --schema tmp-extraction/ASAS_CRM_COMPLETE_PORTABLE_PROJECT/02_DATABASE_ARCHITECTURE/postgres_target/schema_postgres.prisma
warn The configuration property `package.json#prisma` is deprecated and will be removed in Prisma 7. Please migrate to a Prisma config file (e.g., `prisma.config.ts`).
For more information, see: https://pris.ly/prisma-config

Environment variables loaded from .env
Prisma schema loaded from tmp-extraction/ASAS_CRM_COMPLETE_PORTABLE_PROJECT/02_DATABASE_ARCHITECTURE/postgres_target/schema_postgres.prisma
Error: Prisma schema validation - (get-config wasm)
Error code: P1012
error: Error validating datasource `db`: the URL must start with the protocol `postgresql://` or `postgres://`.
  -->  tmp-extraction/ASAS_CRM_COMPLETE_PORTABLE_PROJECT/02_DATABASE_ARCHITECTURE/postgres_target/schema_postgres.prisma:29
   |
28 |   provider = "postgresql"
29 |   url      = env("DATABASE_URL")
   | 

Validation Error Count: 1
[Context: getConfig]

Prisma CLI Version : 6.19.2
```

**Exit code 1 — and this is an ENVIRONMENT artifact, not a schema defect:** the repo `.env` (loaded automatically by the CLI, and NOT modified by this agent — the repo is read-only) contains the SQLite runtime URL `DATABASE_URL=file:...`, which the `postgresql` datasource rejects at the URL-format check *before* schema validation. No PostgreSQL URL exists anywhere in this environment (there is no live PG — see §7).

### 2.2 The same command with a process-env override (no file was touched)

```
$ cd /home/z/my-project && DATABASE_URL="postgresql://postgres:postgres@localhost:5432/asas_validation" bunx prisma validate --schema tmp-extraction/ASAS_CRM_COMPLETE_PORTABLE_PROJECT/02_DATABASE_ARCHITECTURE/postgres_target/schema_postgres.prisma
warn The configuration property `package.json#prisma is deprecated and will be removed in Prisma 7. Please migrate to a Prisma config file (e.g., `prisma.config.ts`).
For more information, see: https://pris.ly/prisma-config

Environment variables loaded from .env
Prisma schema loaded from tmp-extraction/ASAS_CRM_COMPLETE_PORTABLE_PROJECT/02_DATABASE_ARCHITECTURE/postgres_target/schema_postgres.prisma
The schema at tmp-extraction/ASAS_CRM_COMPLETE_PORTABLE_PROJECT/02_DATABASE_ARCHITECTURE/postgres_target/schema_postgres.prisma is valid 🚀
```

**Exit code 0 — PASS.** (Prisma's dotenv does not override an existing process env var, so the PG-format URL wins for this run only.)

Additional engine acceptance: `prisma format` also processed the file (canonical house formatting), and `prisma migrate diff --from-empty --to-schema-datamodel <schema_postgres.prisma> --script` generated full DDL from it without error — both are further engine parses of the same schema.

**Verdict: schema_postgres.prisma is VALID (PASS).** The bare command's failure is fully explained and reproducible; it is not a schema error.

---

## 3. Money-field mapping decision — `Decimal @db.Decimal(18,2)` (24 fields), with code evidence

**Decision:** every DZD money field becomes `Decimal @db.Decimal(18,2)` (PG `DECIMAL(18,2)`). Not `Int`, not `Float`.

| # | Evidence (file : line) | Verbatim witness |
|---|---|---|
| 1 | `src/lib/money.ts:18` | `export const MAX_MONEY_DZD = 10_000_000_000;` — integer domain cap (10 billion DZD); fits `DECIMAL(18,2)` (max 10^16) with huge headroom |
| 2 | `src/lib/format.ts:12` | `API/DB values stay raw integers everywhere.` — the house convention: stored money is integer dinars (display uses `maximumFractionDigits: 0`, format.ts:37) |
| 3 | `src/lib/server/validation.ts:114–122` | `optionalMoney: z.number().min(0, …).max(MAX_MONEY_DZD, …)` — **no `.int()`**: fractional (centime) values legally cross the API boundary today, so `Int` would reject values the current system accepts |
| 4 | `src/components/crm/money-field.tsx` (header comment “Normalization rules”) | `digits only, at most one decimal separator ("," or "." …)` — the UI money input itself can produce fractional DZD |
| 5 | `src/lib/services/payments.ts:85–88,148,155` | `export const MONEY_EPSILON = 0.01;` — “Money-scale comparison epsilon (DZD centime)”; used as `amount > remaining + MONEY_EPSILON` / `paidBefore + amount >= installmentAmount - MONEY_EPSILON` — the domain reasons in centimes ⇒ exactly 2 decimal places |
| 6 | `src/lib/services/installments.ts:84,334` | `paidAmount < row.amount - 1e-9` — today's float arithmetic already needs epsilon band-aids; `DECIMAL(18,2)` removes the artifact class instead of tolerating it |
| 7 | `docs/database/MIGRATIONS_AND_SCHEMA.md` §4 | money table records `Float → DOUBLE PRECISION` as a “semantics-preserving port” with the Decimal upgrade as “a documented FUTURE owner decision” — this conversion resolves that decision with the evidence above |
| 8 | `db/custom.db` + `03_PRIVATE_DATA_DO_NOT_COMMIT/backups/asas_crm_sqlite_backup_20261116.db` | **0 rows in all business tables** — no live money values exist to sample; the decision therefore rests on code evidence only (honest limitation) |

**The 24 money fields:** Campaign.budgetPlanned · Lead.budgetMin/budgetMax · Opportunity.value · Apartment.price/parkingPrice · Requirement.budgetMin/budgetMax · UnitPriceEvent.previousPrice/newPrice · Reservation.amount/depositPaid/commissionAmount/agentIncentive/commissionEarnedAmount/commissionReceivedAmount · Offer.amount/basePrice/parkingPrice/discountAmount/finalTotal · Installment.amount · Payment.amount · SalesTarget.amountDZD.

**The 6 Floats kept as DOUBLE PRECISION (not money):** Apartment.surface & totalSurface (m²), Requirement.surfaceMin/Max (m²), PropertyMatch.score (0–100 weighted), Offer.discountPercent (%).

**Noted trade-off (documented in MAPPING §3):** Prisma returns `Decimal` fields as `Decimal` objects (decimal.js), not JS numbers — future app runs against the PG target must adapt read/aggregation sites (`src/lib/services/payments.ts`, `installments.ts`); the SQLite runtime is unaffected.

---

## 4. PG init migration — independence & structural equivalence (verified)

**Claim:** `postgres_target/migrations/00000000000000_init_postgres/migration.sql` (1402 lines, 258 statements) is a hand-consistent DDL of `schema_postgres.prisma`, written fresh for the PostgreSQL track — NOT copied from the SQLite chain (`sqlite_source/migrations_history/`), which contains superseded intermediate shapes (finance added→removed, SAV added→removed) that a fresh PG database must never see.

**Verification method (no live PostgreSQL exists in this sandbox — see §7):**
1. Generated the Prisma **engine's own DDL** from the final schema: `DATABASE_URL=postgresql://… ./node_modules/.bin/prisma migrate diff --from-empty --to-schema-datamodel …/schema_postgres.prisma --script` → 252 statements, exit 0.
2. Wrote a comparison script: normalize both SQL files (strip comments, split on `;`, collapse whitespace) and compare statement SETS.
3. **Result: all 252 engine statements are contained in my migration (0 missing; no duplicates). My migration = engine DDL + exactly 6 documented extra statements:**
   - 4 partial unique live-hold indexes (`Reservation_apartment_live_hold_uq`, `Reservation_opportunity_live_hold_uq`, `Offer_apartment_live_hold_uq`, `Offer_opportunity_live_hold_uq`) — raw-SQL backstops documented inside `schema.prisma`'s own comments, present in the live SQLite DB and required by `docs/database/BP-ADR-02` §“Future migration trigger” item 2 (“including the partial live-hold indexes and their semantics”);
   - 2 deployed-DB parity indexes (`Lead_orgId_campaignId_idx`, `Opportunity_orgId_sourceOrigin_idx`) — see Anomaly A1.

**Statement inventory of migration.sql:** 1 `CREATE SCHEMA` · 40 `CREATE TABLE` · 23 schema uniques + 4 partial = 27 `CREATE UNIQUE INDEX` · 89 schema indexes + 2 parity = 91 `CREATE INDEX` · 99 `ALTER TABLE … ADD CONSTRAINT … FOREIGN KEY`.

---

## 5. Parity checks against the LIVE SQLite database (read-only)

1. **Index-name set equality (118 = 118):** the set of index names created by my migration is EXACTLY equal to the set of non-internal indexes in `db/custom.db` (118 names; script comparison: `in live DB but NOT in my migration: []`, `in my migration but NOT in live DB: []`). This is full index-level parity with the deployed database.
2. **Column parity (516/516, 0 mismatches):** parsed every `CREATE TABLE` in my migration and compared table names, column names and nullability against `PRAGMA table_info` of the live DB for all 40 business tables — every one of the 516 columns matches by name and nullability.
3. **Schema↔PG-variant preservation (script `ALL CHECKS PASSED`):** field-by-field comparison of `prisma/schema.prisma` vs `postgres_target/schema_postgres.prisma` — 40 models, identical field order/names/nullability/defaults/indexes/uniques; the ONLY differences are the documented native-type annotations (`Decimal @db.Decimal(18,2)` ×24, `@db.Timestamptz(3)` ×110, `@db.Text` ×48); all 121 `@relation` lines byte-preserved (whitespace-normalized), datasource provider switched, generator block unchanged.

---

## 6. sqlite_source copies — diff verification (verbatim results)

```
$ diff prisma/schema.prisma tmp-extraction/.../sqlite_source/schema_sqlite.prisma
(no output — exit 0 → byte-identical)
$ md5sum prisma/schema.prisma tmp-extraction/.../sqlite_source/schema_sqlite.prisma
8c875f9aa70220e42d89a86ed416b82b  prisma/schema.prisma
8c875f9aa70220e42d89a86ed416b82b  tmp-extraction/.../sqlite_source/schema_sqlite.prisma
$ diff -r prisma/migrations tmp-extraction/.../sqlite_source/migrations_history
(no output — exit 0 → byte-identical, 30 migration dirs + migration_lock.toml)
```

Both copies are byte-identical to the source (diff exit code 0, zero differing lines/files; md5 identical for the schema).

---

## 7. Honest limits / anomalies

- **A1 — Schema-vs-chain drift (real, found by this agent):** migrations `20261110150000_p11_lead_acquisition` creates `Lead_orgId_campaignId_idx` and `Opportunity_orgId_sourceOrigin_idx`, and both exist in the live `db/custom.db` (verified read-only), but NEITHER is declared in `prisma/schema.prisma`. `prisma/schema.postgres.prisma` (the dormant in-repo variant) also lacks them. **Handling:** `schema_postgres.prisma` mirrors the schema exactly (mission rule: no invented indexes); the two indexes are carried in `migration.sql` under a clearly labeled “deployed-DB parity extras” section so the PG target matches the deployed source shape 1:1 (this also preserves query-plan parity for the hot campaign/source-origin facets). Documented in README_AR §2 as well.
- **A2 — The bare `bunx prisma validate` command fails (P1012)** purely because the repo `.env` carries the SQLite `DATABASE_URL` and no PG URL exists in this environment; the passing run (§2.2) used a process-env override. No repo file was modified. Owner guidance: on a machine with a real Supabase/PG URL exported as `DATABASE_URL`, the bare command passes as-is.
- **A3 — No live PostgreSQL runtime in this sandbox** (no psql/docker/PG binaries — same condition the house docs record in `docs/database/MIGRATIONS_AND_SCHEMA.md` §5). The migration SQL was therefore validated by the strongest available means: (i) engine `migrate diff` equivalence (§4), (ii) full index-set and column/nullability parity vs the live SQLite DB (§5), (iii) house-convention conformance (identifiers quoted, TIMESTAMPTZ(3), TEXT ids, FK naming/on-delete semantics copied from the engine's own output). **First live execution is the owner's responsibility on Supabase** (README_AR §6).
- **A4 — `db/custom.db` and the packaged backup are EMPTY** (0 business rows; only `_prisma_migrations` bookkeeping — 30 rows). Money-type evidence therefore comes from code, not stored values (§3, row 8). An integration test of Agent A3's importer against this DB produced an export of 30 rows (all `_prisma_migrations`) — pipeline proven, data volume currently zero.
- **A5 — Mojibake in the SOURCE schema comments (pre-existing, preserved verbatim):** lines 84 and 105 of `prisma/schema.prisma` contain a corrupted byte (`â`) in two `User` comments (“watermark â —”, “â — explicit”). Copied as-is to both Prisma artifacts (byte-fidelity rule); flagged for the owner — it is comment-only, no semantic effect.
- **A6 — In-repo `prisma/schema.postgres.prisma` is STALE** (902 lines, ~26-model era, missing Offer/Campaign/AuthToken/etc.). Per `BP-ADR-02` it is a dormant artifact; the portable project's `postgres_target/schema_postgres.prisma` (1416 lines, all 40 models, engine-validated) supersedes it for the PG track. The in-repo file was NOT modified (read-only).
- **A7 — CHECK constraints / RLS are NOT part of `migration.sql`** (out of mission scope: the DDL must match `schema_postgres.prisma`). The in-repo `supabase/migrations/` chain (CHECK from constants.ts + RLS + g6-parity) remains available as optional hardening on top — referenced in README_AR §6 without being copied or executed.
- **A8 — Partial unique indexes are Prisma-inexpressible by design** (documented in the schema itself); `prisma migrate dev` against a PG database carrying them will report drift — this is the documented house “deploy-only law”, not a defect.

---

## 8. Deliverables produced (final tree)

```
02_DATABASE_ARCHITECTURE/
├── README_AR.md                       (173 lines)
├── MAPPING_SQLITE_TO_POSTGRES_AR.md  (159 lines)
├── ERD_DIAGRAM.md                     (503 lines — mermaid erDiagram, 40 entities, 99 relationships, 2 one-to-one)
├── DATA_DICTIONARY_AR.md              (1222 lines — all 40 models × all fields, generated from the schema AST)
├── sqlite_source/
│   ├── schema_sqlite.prisma           (byte-identical, verified)
│   └── migrations_history/            (30 dirs + migration_lock.toml, byte-identical, verified)
├── postgres_target/
│   ├── schema_postgres.prisma         (1416 lines, prisma validate PASS)
│   └── migrations/
│       ├── migration_lock.toml        (provider = "postgresql", exact required content)
│       └── 00000000000000_init_postgres/migration.sql  (1402 lines, 258 statements)
└── tools/                             (Agent A3's importer + its README — cross-checked: dry-run and
                                        --export both ran successfully against my schema_postgres.prisma,
                                        "40 models parsed for type mapping")
```

**Cross-agent integration test (A2 ↔ A3):** `bun tools/sqlite_to_postgres_importer.mjs --dry-run` → exit 0, “40 models parsed for type mapping”, 41 tables listed; `--export` → exit 0, wrote a valid FK-topologically-ordered SQL file (30 rows, all `_prisma_migrations`). Both consumed `postgres_target/schema_postgres.prisma` as the type-mapping source — the two deliverables interoperate.

**Summary verdict:** all mission requirements completed and machine-verified: 40/40 models preserved, type discipline applied (24 money→Decimal(18,2) with code evidence, 110 timestamps→Timestamptz(3), 48 @db.Text, 0 enums kept at 0), independent PG migration with engine-equivalence proof, byte-identical SQLite source copies, `prisma validate` PASS, full Arabic documentation set. Anomalies are enumerated above with their dispositions.
