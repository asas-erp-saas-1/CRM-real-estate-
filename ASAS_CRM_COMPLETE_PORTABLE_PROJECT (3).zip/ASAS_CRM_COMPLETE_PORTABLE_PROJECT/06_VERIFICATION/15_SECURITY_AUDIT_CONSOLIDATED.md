# 15 — Consolidated Security Audit (v2) — التدقيق الأمني الموحّد

- **Mission:** Package v2 professional reorganization — security review pass
- **Date:** 2026-11-17 (UTC)
- **Scope:** the complete `ASAS_CRM_COMPLETE_PORTABLE_PROJECT` tree (post-v2-reorg), plus source-level spot-checks of `01_GITHUB_READY_SOURCE`
- **Method:** fresh automated scans (this session) + verification of the v1 audit evidence (`07_SECRETS_SCAN_REPORT.md`) + direct code inspection of the authentication path

---

## 1. Verdict — الحكم

**PASS — zero real secrets in the archive; authentication hardening verified at source level; one external blocker (native publish) remains honestly UNRESOLVED (not a package defect).**

## 2. Fresh v2 secret scan (this session)

Patterns scanned across the entire tree (text + filenames, all 1,000+ files):

| # | Pattern class | Hits | Triage |
|---:|---|---:|---|
| 1 | Private key blocks (`BEGIN … PRIVATE KEY`) | 0 | — |
| 2 | AWS keys (`AKIA…16`), GitHub tokens (`gh[pousr]_…36`), Supabase (`sbp_…`), Slack (`xox…`), OpenAI (`sk-…`) | 0 | — |
| 3 | JWT bodies (`eyJ…eyJ…`) | 0 | — |
| 4 | Connection strings with embedded passwords (`postgres://user:pass@…`) | 1 | **Placeholder** `postgresql://u:p@h:5432/db` — documented Prisma validation technique in `11_INDEPENDENT_AUDIT_SUMMARY.md` §58. Not a credential. |
| 5 | Real assigned secret values (`ASAS_SESSION_SECRET=<hex>`, `DATABASE_URL=file:…`) | 0 | The workspace `.env` is **not** in the archive (verified: only `.env.example`, `.env.staging.example`, `.env.production` exist in `01`, all placeholder/no-secret — §3 below). |

**Cross-check with v1 evidence (07_SECRETS_SCAN_REPORT):** v1 scanned the real `.env` values (`ASAS_SESSION_SECRET` 48-hex, `DATABASE_URL=file:/home/z/my-project/db/custom.db`, `ASAS_DEMO_MODE=1`) as literal targets across text **and binary** (`rg -a`) — zero leakage. The v2 re-scan of the reorganized tree reproduces that result.

## 3. `.env` posture in `01_GITHUB_READY_SOURCE`

| File | Content | Secret risk |
|---|---|---|
| `.env.example` | Template with `replace-me-openssl-rand-hex-32` placeholders + policy pointers | None |
| `.env.staging.example` | Template, self-documents the `.gitignore` commit-note | None |
| `.env.production` | `ASAS_DEMO_MODE=0` **only** — long header documents WHY it is tracked (hosted boot gate fix, 2026-11-08); explicitly states no secret is stored here (D-012 law) | None — verified line-by-line |
| `.gitignore` | `.env*` blocked; `!.env.example`, `!.env.staging.example`, `!.env.production` whitelisted with inline rationale | Correct by design |

**No `.git` directory exists anywhere in the archive** (only `.gitattributes`, `.github/`, `.gitignore`) — no history leakage channel.

## 4. Authentication hardening — source-level verification

Direct inspection of `01_GITHUB_READY_SOURCE`:

| # | Control | Location | Verified state |
|---:|---|---|---|
| 1 | Password hashing | `src/lib/server/auth.ts` | **scrypt** (N=16384, r=8, p=1, 32-byte, `timingSafeEqual`) — OWASP-aligned |
| 2 | Session cookie flags | `src/app/api/auth/login/route.ts`, `bootstrap`, `logout`, `sessions/revoke-all` | `httpOnly: true`, `sameSite: "lax"`, path `/`, 7-day absolute cap |
| 3 | Login rate limiting | `src/app/api/auth/login/route.ts` | **5 failures / 15 min → 429 ACCOUNT_LOCKED**, audited LOGIN events |
| 4 | User-enumeration defense | same file | Non-existent email burns the **same scrypt work** (timing equalization) |
| 5 | CSRF defense | `src/lib/server/session.ts` | Layered: `sameSite=lax` + JSON-only API + origin-check defense-in-depth (documented at lines 351–383) |
| 6 | Production boot gate | `src/instrumentation.ts` → `src/lib/server/boot.ts` | `ASAS_SESSION_SECRET` strength (≥32, not placeholder) + `ASAS_DEMO_MODE≠1` enforced with **`process.exit(1)`** (real fail-fast; regression-guarded by `tests/unit/instrumentation-boot-gate.test.ts`) |
| 7 | Demo-mode isolation | P0-3 + `.env.production` | Demo chain OFF in production; passwordless quick-login is sandbox-only |
| 8 | Authorization model | `05_ENGINEERING_DOCUMENTATION/04_SECURITY_MODEL/` | Centralized RBAC/ABAC + `ROLE_DATA_VISIBILITY_MATRIX.md` + RLS policy (`SECURITY_AND_RLS.md`) |

## 5. Data privacy / private-data separation

- `03_PRIVATE_DATA_DO_NOT_COMMIT/` holds the SQLite backup + uploaded files, **physically separated** from the GitHub-ready source (`01`), with `DATA_CLASSIFICATION_AR.md` + `UPLOADS_SHA256_MANIFEST.tsv`.
- Upload filenames are **deliberately NOT renamed** in v2 — they are referenced by database rows (FileRecord); renaming would corrupt referential integrity. This is documented as an integrity law in `03/README.md`.
- Phase 12 disclosure carried forward: **the database contents are demo/seed data** (per the final extraction mission's data-fidelity rule — no fabricated business data).

## 6. Findings register (honest)

| # | Finding | Severity | Status |
|---:|---|---|---|
| F-1 | Native Z.ai Publish deployment not confirmed by owner (carried from Phase 11/12) | External blocker | **UNRESOLVED — OWNER CONFIRMATION / PLATFORM EVIDENCE REQUIRED** (see `../05_ENGINEERING_DOCUMENTATION/22_PHASE_12_FINAL_ACCEPTANCE/ASAS_PHASE12_DEPLOYMENT_BLOCKER_STATUS.md`). Not a defect of this package; the Vercel path in `04_VERCEL_AND_SUPABASE/` is the prepared remedy. |
| F-2 | Sandbox OOM-reaper can kill the dev server under heavy concurrent load (documented in Phase 12; recovery law exists) | Operational | Documented + recovery script included in source tree (`.zscripts/dev-restart.sh` referenced in evidence). |
| F-3 | Historical reference paths inside 06 reports (v1 evidence) point to pre-v2 filenames | Cosmetic | Accepted deliberately — historical records kept pristine; `05_ENGINEERING_DOCUMENTATION/RENAME_REGISTRY.md` resolves every old→new path. |

**No new security defects were found in the v2 pass. No code fixes were required; the reorganization itself fixed the navigational defect (mixed naming conventions).**

## 7. ملخص عربي — الخلاصة الأمنية

- **صفر أسرار حقيقية** في الحزمة كاملة (فحص آلي جديد + مطابقة مع أدلة الجولة الأولى v1).
- ملفات `.env` داخل المصدر كلها قوالب أو خالية من الأسرار — و`.gitignore` يمنع رفع أي ملف أسرار حقيقي، ولا يوجد تاريخ Git في الحزمة إطلاقاً.
- المصادقة مُتحقّق منها على مستوى الكود: تجزئة scrypt وفق معايير OWASP، كوكيز `httpOnly` + `sameSite`، تحديد معدل المحاولات (5/15 دقيقة → قفل)، مساواة توقيت تسجيل الدخول، بوابة إقلاع صارمة `process.exit(1)` في الإنتاج.
- البيانات الخاصة معزولة فيزيائياً في `03_PRIVATE_DATA_DO_NOT_COMMIT`، وبيانات القاعدة المعروفة **بيانات عرض/بذرة** (لا بيانات أعمال مُفبركة).
- عائق واحد صادق غير محلول: تأكيد النشر الأصلي عبر منصة Z.ai (مسؤولية خارجية) — بينما مسار Vercel/Supabase جاهز في `04_VERCEL_AND_SUPABASE/`.

---
*Audited by the v2 reorganization pass. Source files cited by exact path for re-verification.*
